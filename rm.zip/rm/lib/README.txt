This folder should contain run-time libraries required by your web application that are not already contained in the system-wide classpath
