@ecrd_utils_pkg.sql;

show errors;
/*
@ecrd_cust_cat_price_cal_obj.sql;

show errors;

@ecrd_batch_cust_cat_pkg.sql;

show errors;
*/

@ecrd_managecatalog_pkg.sql;

show errors;

@ecrd_approval_pkg.sql;

show errors;

@ecrd_maintenace_pkg.sql;

show errors;

@ecrd_managecomponent_pkg.sql;

show errors;

@ecrd_manageuser_pkg.sql;

show errors;

@ecrd_master_load_pkg.sql;

show errors;

@ecrd_repair_pkg.sql;

show errors;

@ecrd_reports_pkg.sql;

show errors;

@ecrd_upload_pkg.sql;

show errors;

@ecrd_send_notification_pkg.sql;

show errors;
