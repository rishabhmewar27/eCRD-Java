DECLARE
    v_max_catalog_id        NUMBER;
    v_curr_seq_id           NUMBER;
    temp                    NUMBER;
 BEGIN
    SELECT MAX(MODULE_SEQ_ID)
    INTO    v_max_catalog_id
    FROM    CRD_CRC_MODULE;
    SELECT CRD_CRC_MODULE_SEQ.nextval
    INTO    v_curr_seq_id
    FROM DUAL;
    FOR     cnt IN v_curr_seq_id..(v_max_catalog_id-1)
    LOOP
            SELECT CRD_CRC_MODULE_SEQ.nextval
            INTO    temp
            FROM DUAL;
    END LOOP;
 END;

 
 