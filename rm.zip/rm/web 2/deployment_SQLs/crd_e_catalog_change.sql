ALTER TABLE CRD_E_CATALOG_HISTORY ADD (Calculated_price_Default_Ind VARCHAR2(1) NULL);
COMMENT ON COLUMN CRD_E_CATALOG_HISTORY.Calculated_price_Default_Ind IS 'Indicator for default price.Source : Manual Entry Screen : Manage Cataloge';
