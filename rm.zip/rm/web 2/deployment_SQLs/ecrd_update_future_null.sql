UPDATE crd_e_repair_catalog
SET future_price = NULL
   ,future_tat   = NULL
WHERE future_effective_date IS  NULL;
   