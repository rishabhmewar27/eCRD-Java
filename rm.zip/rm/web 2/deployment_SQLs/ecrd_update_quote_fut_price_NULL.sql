
UPDATE crd_e_repair_catalog
SET future_price = NULL 
WHERE price_type= 'QUOTE'
AND future_price= 0;