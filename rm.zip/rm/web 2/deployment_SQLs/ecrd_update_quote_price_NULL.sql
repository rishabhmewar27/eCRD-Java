
UPDATE crd_e_repair_catalog
SET repair_price = NULL 
WHERE price_type= 'QUOTE'
AND repair_price= 0;