UPDATE crd_crc_user
SET active_ind = 'A'
WHERE active_ind = 'Y';
COMMIT;
UPDATE crd_crc_user
SET active_ind = 'I'
WHERE active_ind = 'N';
COMMIT;