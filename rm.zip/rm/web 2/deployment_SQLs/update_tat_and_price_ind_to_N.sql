UPDATE 
   crd_e_repair_catalog
SET 
   incremental_tat_ind = 'N'
WHERE
   incremental_tat_ind IS NULL;
   
UPDATE 
   crd_e_repair_catalog
SET 
   incremental_price_ind = 'N'
WHERE
   incremental_price_ind IS NULL;
   
COMMIT;   
   
   