function fnGetRepairDetails(strModelCode,strModuleCode,strCompCode,strRepairCode,strFlag,strRepairType)
{
	document.frmRepairList.hdnModelCode.value=strModelCode;
	document.frmRepairList.hdnModuleCode.value=strModuleCode;
	document.frmRepairList.hdnCompCode.value=strCompCode;
	document.frmRepairList.hdnRepairCode.value=strRepairCode;
	document.frmRepairList.hdnFlag.value=strFlag;
	document.frmRepairList.hdnRepairType.value=strRepairType;
	/* Patni 25-05-2006 Defect #17 For effective date to be uneditable Begin*/
	document.frmRepairList.hdnBoolEffDate.value="true";
	/* Patni 25-05-2006 Defect #17 For effective date to be uneditable End */
	
	document.frmRepairList.hdnScreenName.value="ApprCompDet";
	//document.frmRepairList.hdnScreenAction.value="eCRDLoadApprRepairDetails";
	if(document.frmRepairList.hdnGetRepairDetails.value == 'ApprovalQueue'){
		document.frmRepairList.hdnScreenAction.value="eCRDLoadApprRepairDetails";
	}
	else if(document.frmRepairList.hdnGetRepairDetails.value == 'CSMQueue'){
		document.frmRepairList.hdnScreenAction.value="eCRDLoadCSMqRepairDetails";
	}

	document.frmRepairList.submit();
}

function fnGetRepairDetailsForDraft(strModelCode,strModuleCode,strCompCode,strRepairCode,strFlag,strRepairType,strStaggingInd)
{

	document.frmRepairList.hdnModelCode.value=strModelCode;
	document.frmRepairList.hdnModuleCode.value=strModuleCode;
	document.frmRepairList.hdnCompCode.value=strCompCode;
	document.frmRepairList.hdnRepairCode.value=strRepairCode;
	document.frmRepairList.hdnFlag.value=strFlag;
	document.frmRepairList.hdnRepairType.value=strRepairType;
	
	document.frmRepairList.hdnStagingInd.value=strStaggingInd;
	/* Patni 25-05-2006 Defect #17 For effective date to be uneditable Begin*/
	document.frmRepairList.hdnBoolEffDate.value="true"; 
	/* Patni 25-05-2006 Defect #17 For effective date to be uneditable End */
	
	document.frmRepairList.hdnScreenName.value="ApprCompDet";
	document.frmRepairList.hdnScreenAction.value="eCRDLoadApprRepairDetails";

	document.frmRepairList.submit();
}


function fnChkApprvRepair()
{

	if(!fnValidateEntry())
	{
		return false;
	}
	else if(!fnValidateDate())
	{
		return false;
	}
	else
	{
		if(document.frmAppExtRepair.chkIncTAT.checked)
		{
			document.frmAppExtRepair.hdnIncTat.value='Y';
		}
		else
		{
			document.frmAppExtRepair.hdnIncTat.value='N';
		}
		if(document.frmAppExtRepair.chkIncPr.checked)
		{
			document.frmAppExtRepair.hdnIncPr.value='Y';
		}
		else
		{
			document.frmAppExtRepair.hdnIncPr.value='N';
		}
		if(fnLtrim(document.frmAppExtRepair.txtRejectComm.value)!="")
		{
			alert("You can not enter rejection comments while approving.");
			return false;
		}
		document.frmAppExtRepair.hdnScreenAction.value="eCRDApproveGroupRepair";
	
	
		document.frmAppExtRepair.hdnPrType.value=document.frmAppExtRepair.lstPrice.options[document.frmAppExtRepair.lstPrice.selectedIndex].value;
	
		document.frmAppExtRepair.submit();
	}
}

function fnGetRepairDetailsForDraft(strModelCode,strModuleCode,strCompCode,strRepairCode,strFlag,strRepairType,strStaggingInd)
{
	
	document.frmRepairList.hdnModelCode.value=strModelCode;
	document.frmRepairList.hdnModuleCode.value=strModuleCode;
	document.frmRepairList.hdnCompCode.value=strCompCode;
	document.frmRepairList.hdnRepairCode.value=strRepairCode;
	document.frmRepairList.hdnFlag.value=strFlag;
	document.frmRepairList.hdnRepairType.value=strRepairType;
	
	document.frmRepairList.hdnStagingInd.value=strStaggingInd;
	/* Patni 25-05-2006 Defect #17 For effective date to be uneditable Begin*/
	document.frmRepairList.hdnBoolEffDate.value="true";
	/* Patni 25-05-2006 Defect #17 For effective date to be uneditable End */
	
	document.frmRepairList.hdnScreenName.value="ApprCompDet";
	document.frmRepairList.hdnScreenAction.value="eCRDLoadApprRepairDetails";

	document.frmRepairList.submit();
}

//Adding CSM Queue changes - kumar(502321240)
function fnChkCSMApprRepair()
{

	if(!fnValidateEntry())
	{
		return false;
	}
	else if(!fnValidateDate())
	{
		return false;
	}
	else
	{
		if(document.frmAppExtRepair.chkIncTAT.checked)
		{
			document.frmAppExtRepair.hdnIncTat.value='Y';
		}
		else
		{
			document.frmAppExtRepair.hdnIncTat.value='N';
		}
		if(document.frmAppExtRepair.chkIncPr.checked)
		{
			document.frmAppExtRepair.hdnIncPr.value='Y';
		}
		else
		{
			document.frmAppExtRepair.hdnIncPr.value='N';
		}
		/*if(fnLtrim(document.frmAppExtRepair.txtRejectComm.value)!="")
		{
			alert("You can not enter rejection comments while approving.");
			return false;
		}*/
		document.frmAppExtRepair.hdnScreenAction.value="eCRDMoveCSMRprForApproval";
	
	
		document.frmAppExtRepair.hdnPrType.value=document.frmAppExtRepair.lstPrice.options[document.frmAppExtRepair.lstPrice.selectedIndex].value;
	
		document.frmAppExtRepair.submit();
	}
}

function fnChkRejectRepair()
{
   		if(fnLtrim(document.frmAppExtRepair.txtRejectComm.value)=="" || document.frmAppExtRepair.txtRejectComm.value==null)
		{
			
			alertMsgs(eCRDRejectComments);
         document.frmAppExtRepair.txtRejectComm.focus();
         return false;
		}
      if(document.frmAppExtRepair.txtRejectComm.value.length > 250)
      {

         alertMsgs(eCRDRejectLength);
         document.frmAppExtRepair.txtRejectComm.focus();
         return false;
      }
		else
		{
			document.frmAppExtRepair.hdnScreenAction.value="eCRDRejectRepair";
			document.frmAppExtRepair.submit();
		}
	
}

//Adding CSM Queue changes - kumar(502321240) - This fn is used to move repair to CSM queue
function fnMoveToCSMQueue()
{
		if(fnLtrim(document.frmAppExtRepair.txtRejectComm.value)=="" || document.frmAppExtRepair.txtRejectComm.value==null)
		{
			
			alertMsgs(eCRDCSMqComments);
         document.frmAppExtRepair.txtRejectComm.focus();
         return false;
		}
	      if(document.frmAppExtRepair.txtRejectComm.value.length > 250)
	      {
	
	         alertMsgs(eCRDCSMCommentLength);
	         document.frmAppExtRepair.txtRejectComm.focus();
	         return false;
	      }
		else
		{
			 document.frmAppExtRepair.hdnScreenAction.value= "eCRDMoveRepairToCSMQueue";
		 	 document.frmAppExtRepair.hdnScreenName.value= "ApprCompDet";
	   	 	 document.frmAppExtRepair.submit();
		}
	
}

//Adding CSM Queue changes - kumar(502321240)
function fnMoveToApprovalQueue(strPrice,strTAT,strPriceType,strDisplaySeq,strFuturePrice,strFutureTat,strDay,strMonth,strYear,strIncrementalTat,strIncrementalPrice)
{
	
	if(!fnValidateEntry())
	{
		return false;
	}
	else if(!fnValidateDate())
	{
		return false;
	}
	else
	{
		if(document.frmAppExtRepair.chkIncTAT.checked)
		{
			document.frmAppExtRepair.hdnIncTat.value='Y';
		}
		else
		{
			document.frmAppExtRepair.hdnIncTat.value='N';
		}
		if(document.frmAppExtRepair.chkIncPr.checked)
		{
			document.frmAppExtRepair.hdnIncPr.value='Y';
		}
		else
		{
			document.frmAppExtRepair.hdnIncPr.value='N';
		}
		 if(fnLtrim(document.frmRepairDetails.txtRejectComm.value)=="" || document.frmRepairDetails.txtRejectComm.value==null)
			{
			   alertMsgs(eCRDCSMqComments);
			   return false;
			}
		   else if(document.frmRepairDetails.txtRejectComm.value.length > 250)
			{
			      alertMsgs(eCRDCSMCommentLength);
			      document.frmRepairDetails.txtRejectComm.focus();
			      return false;		      	
	   	 	}else{
				document.frmAppExtRepair.hdnScreenAction.value= "eCRDUpdateRepairInCSMQueue";
			 	document.frmAppExtRepair.hdnScreenName.value= "ModifyRepairDetail";
				document.frmAppExtRepair.hdnPrType.value=document.frmAppExtRepair.lstPrice.options[document.frmAppExtRepair.lstPrice.selectedIndex].value;
				document.frmAppExtRepair.submit();
	   	 	}
	}	   	   
}

function fnValidateEntry()
{	
    {	
      var dayVal;
   var monthVal;
   var yearVal;
   var fullDateVal;
   var fullDateVal1;
   var isPriceTypeQuote = false;
   isPriceTypeQuote = document.frmAppExtRepair.lstPrice.options[document.frmAppExtRepair.lstPrice.selectedIndex].text=='QUOTE';

   if(document.frmAppExtRepair.txtTAT.value!="")
   {
     if(parseInt(document.frmAppExtRepair.txtTAT.value)<0)
      {         
        alertMsgs("Turn Around Time "+eCRDNonNegative);
         document.frmAppExtRepair.txtTAT.focus();
         return false;
      }
   }
   
   /*if(document.frmAppExtRepair.txtTAT.value=="")
   {
      alertMsgs(eCRDempty +"Turn Around Time");
      document.frmAppExtRepair.txtTAT.focus();
      return false;
   }

  if(parseInt(document.frmAppExtRepair.txtTAT.value)==0)
   {
      alertMsgs(eCRDempty +"Turn Around Time");
      document.frmAppExtRepair.txtTAT.focus();
      return false;
   }*/

   if(document.frmAppExtRepair.txtPr.value=="")
   {
      /*if(!isPriceTypeQuote)
      {
      	alertMsgs(eCRDempty +"Price");
      	document.frmAppExtRepair.txtPr.focus();
      	return false;
      }*/
   }
   else
   {
   	if(isPriceTypeQuote)
      {
       		alertMsgs(eCRDQUOTEPrice);
      		document.frmAppExtRepair.txtPr.focus();
      		return false;
    	}
      if(!fnCheckDecimalValue(document.frmAppExtRepair.txtPr.value))
	   {
		      alertMsgs(eCRDCheckValue);
		      document.frmAppExtRepair.txtPr.focus();
		      return false;
      }
      	/*else
      	{
      		if(parseFloat(document.frmAppExtRepair.txtPr.value)==0)
	        {
		      alertMsgs(eCRDPrice);
		      document.frmAppExtRepair.txtPr.focus();
		      return false;
      		}
         }*/
   }

   if(isPriceTypeQuote)
   {
   	if(document.frmAppExtRepair.chkIncPr.checked)
   	{
   		alertMsgs(eCRDIncrPrice);
		   document.frmAppExtRepair.txtPr.focus();
		   return false;
   	}
   }

   if(document.frmAppExtRepair.txtPr.value!="")
   {
        if(document.frmAppExtRepair.txtPr.value > 999999999999.99)
      {
        	alertMsgs(eCRDPriceLimit);
      	document.frmAppExtRepair.txtPr.focus();
      	return false;      
      }
   }

   if(document.frmAppExtRepair.txtFutPr.value!="")
   {
        if(document.frmAppExtRepair.txtFutPr.value > 999999999999.99)
      {
        	alertMsgs("Future "+eCRDPriceLimit);
      	document.frmAppExtRepair.txtFutPr.focus();
      	return false;      
      }
   }

   if(document.frmAppExtRepair.lstPrice.selectedIndex==0)
   {
      alertMsgs(eCRDSelect+ " Price Type");
      document.frmAppExtRepair.lstPrice.focus();
      return false;
   }
   if(document.frmAppExtRepair.txtFutPr.value!="")
   {
   	if(isPriceTypeQuote)
      {
       		alertMsgs(eCRDQUOTEPrice);
      		document.frmAppExtRepair.txtFutPr.focus();
      		return false;
      }
      if(!fnCheckDecimalValue(document.frmAppExtRepair.txtFutPr.value))
	   {
		      alertMsgs(eCRDCheckValue);
		      document.frmAppExtRepair.txtFutPr.focus();
		      return false;
      }
   }
   /*if(document.frmAppExtRepair.txtFutPr.value!="")
   {
      if(parseFloat(document.frmAppExtRepair.txtFutPr.value)==0)
      {
         alertMsgs(eCRDempty +"Future Price");
         document.frmAppExtRepair.txtFutPr.focus();
         return false;
      }
   }
   if(document.frmAppExtRepair.txtFutTat.value!="")
   {
      if(parseInt(document.frmAppExtRepair.txtFutTat.value)==0)
      {
         alertMsgs(eCRDempty +"Future TAT");
         document.frmAppExtRepair.txtFutTat.focus();
         return false;
      }
   }*/
   if(document.frmAppExtRepair.txtFutTat.value!="")
   {
     if(parseInt(document.frmAppExtRepair.txtFutTat.value)<0)
      {         
        alertMsgs("Future Turn Around Time "+eCRDNonNegative);
         document.frmAppExtRepair.txtFutTat.focus();
         return false;
      }
   }

   if(parseFloat(document.frmAppExtRepair.txtFutPr.value) >= 0 || parseInt(document.frmAppExtRepair.txtFutTat.value) >= 0)
   {
      if(document.frmAppExtRepair.sel_man_Startdate_DD_FUT.value=="")
      {
            alertMsgs(eCRDSelectFutureEffDate);
            document.frmAppExtRepair.sel_man_Startdate_DD_FUT.focus();
            return false;
      }
      if(document.frmAppExtRepair.sel_man_Startdate_MM_FUT.value=="")
      {
            alertMsgs(eCRDSelectMonth);
            document.frmAppExtRepair.sel_man_Startdate_MM_FUT.focus();
            return false;
      }
      if(document.frmAppExtRepair.sel_man_Startdate_YYYY_FUT.value=="")
      {
            alertMsgs(eCRDSelectYear);
            document.frmAppExtRepair.sel_man_Startdate_YYYY_FUT.focus();
            return false;
      }
   }
   /*  Added for checking if future effetcive date is greater than repair effective date   */
   //This if is added for checking whether only one select box is selected and the others are left blanck in future effective date calender object
   if(document.frmAppExtRepair.sel_man_Startdate_DD_FUT.value!="" || document.frmAppExtRepair.sel_man_Startdate_MM_FUT.value!="" || document.frmAppExtRepair.sel_man_Startdate_YYYY_FUT.value!="")
   {
       if(!(document.frmAppExtRepair.sel_man_Startdate_DD_FUT.value!="" && document.frmAppExtRepair.sel_man_Startdate_MM_FUT.value!="" && document.frmAppExtRepair.sel_man_Startdate_YYYY_FUT.value!=""))
      {
          alertMsgs(eCRDSelectFutureEffDate);
          document.frmAppExtRepair.sel_man_Startdate_DD_FUT.focus();
          return false;
      }
   }
   // To Validate Date Format 
   if(document.frmAppExtRepair.sel_man_Startdate_DD_FUT.value!="" || document.frmAppExtRepair.sel_man_Startdate_MM_FUT.value!="" || document.frmAppExtRepair.sel_man_Startdate_YYYY_FUT.value!="")
   {
      dayVal = document.frmAppExtRepair.sel_man_Startdate_DD_FUT.value;
      monthVal = document.frmAppExtRepair.sel_man_Startdate_MM_FUT.value;
      yearVal = document.frmAppExtRepair.sel_man_Startdate_YYYY_FUT.value;

      fullDateVal =monthVal+ "/" + dayVal + "/"  + yearVal;
      if(!fnValidateDateString(fullDateVal))
      {
            document.frmAppExtRepair.sel_man_Startdate_DD_FUT.focus();
            return false;
      }

      var sysFullDate = document.frmAppExtRepair.hdnSysDate.value;
      fullDateVal = yearVal + "/" +monthVal  + "/"  + dayVal;
      if(Date.parse(fullDateVal) <= Date.parse(sysFullDate))
      {
            alertMsgs(eCRDFutureRepEffectiveDate);
            return false;
      }
      else
      {
         RepEffDate=document.frmAppExtRepair.hdnRepEffDate.value;     
         fullDateVal = yearVal+ "/" + monthVal + "/"  + dayVal;        
         if(fnCompareDateFromTo(fullDateVal,RepEffDate)==false)
         {
               alertMsgs(eCRDFutureRepEffDateCheck);
               return false;
         }
      }
   }   
   return true;
   }
}

function fnShowHistory(strRepairCode,strCatalogSeqId)
{
	
//	document.frmAppExtRepair.hdn_POP_RepairCode.value=strRepairCode;
	features='toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,width=700,height=400';
	dlg = window.open(basePath+"/ecrd?hdnScreenName=ApprCompDet&hdnScreenAction=eCRDShowRepairApprHist&hdn_POP_RepairCode="+strRepairCode+"&hdn_POP_CatalogSeqId="+strCatalogSeqId+"&RandomValue="+Math.random(),"Dialog",features);
}


function fnValidateDate()
{
       // strStartDate=fnValidateCalenderDate(sel_man_Startdate_DD,sel_man_Startdate_MM,sel_man_Startdate_YYYY);
      if(document.frmAppExtRepair.sel_man_Startdate_DD_FUT.value == '' || document.frmAppExtRepair.sel_man_Startdate_MM_FUT.value =='' || document.frmAppExtRepair.sel_man_Startdate_YYYY_FUT.value =='')
		{
			return true;
		}
		else
		{
         strFutDate= fnValidateCalenderDate(document.frmAppExtRepair.sel_man_Startdate_DD_FUT
                              ,document.frmAppExtRepair.sel_man_Startdate_MM_FUT
                              ,document.frmAppExtRepair.sel_man_Startdate_YYYY_FUT);
         if(!fnValidateDateString(strFutDate))
         {
            return false;
         }
         else
         {
             return true;
         }
		}
	
}

function fnValidateCalenderDate(dayDD,monthDD,yearDD)
{
   var dayVal = dayDD.options[dayDD.selectedIndex].value;
   var monthVal = monthDD.options[monthDD.selectedIndex].value;
   var yearVal = yearDD.options[yearDD.selectedIndex].value;
   var fullDateVal = monthVal + "/" + dayVal + "/" +yearVal;
   return fullDateVal;
}
function fnClose()
{
		window.close();		

}

function fnCompareDateFromTo(start,end)
{
    if(Date.parse(start)>Date.parse(end))
    {
         return true;
    }
    else
    {
       return false;
    }
}
function fnCheckDecimalValue(strText)
{
	var strCheckArray = strText.split(".");
   if(strCheckArray.length > 2)
   {
      return false;
   }
   else
   {
      return true;
   }
}
function fnShowproposedCMOnLoad(objForm)
{
     fnCalculate(objForm);
}


function fnCalculate(objForm)
{   
   if(objForm.hdnTotalCost.length==null)
   {
         strTotalCost = parseFloat(objForm.hdnTotalCost.value);
         if(objForm.txtPr.value!="")
         {
             strPrice = objForm.txtPr.value;
             strCM = ((parseFloat(strPrice) - parseFloat(strTotalCost ))/parseFloat(strPrice)) * 100;
             objForm.txtProposedCM.value = fnRoundTwoDecimal(strCM);
         }
         else
         {
             objForm.txtProposedCM.value = "";
         }
   }
   else
   {
      for(k=0; k<objForm.hdnTotalCost.length; k++)
      {
            strTotalCost = parseFloat(objForm.hdnTotalCost[k].value);
            if(objForm.txtPr.value!="")
            {
               strPrice = objForm.txtPr.value;
               strCM = (( parseFloat(strPrice) - parseFloat(strTotalCost) )/parseFloat(strPrice)) * 100;
               objForm.txtProposedCM[k].value = fnRoundTwoDecimal(strCM);
            }
            else
            {
               objForm.txtProposedCM[k].value = "";
            }
         }
   }
}
// 13-06-2006 Patni added to handle the BACK button Begin 
function fnBackRepair()
{
document.frmAppExtRepair.hdnScreenName.value="ApprCompDet";
document.frmAppExtRepair.hdnScreenAction.value="eCRDGetApprovalRepairsList";
document.frmAppExtRepair.submit();
}
// 13-06-2006 Patni added to handle the BACK button End 