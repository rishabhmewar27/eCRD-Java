function fnChkApprvRepair()
{
	if(document.frmAppExtRepair.txtRepDesc.value=="" || document.frmAppExtRepair.txtRepDesc.value==null)
	{
		alertMsgs(eCRDRepairDesc);
		return false;
	}
	else
	{
		if(document.frmAppExtRepair.chkIncTAT.isChecked)
		{
			document.frmAppExtRepair.hdnIncTat.value='Y';
		}
		else
		{
			document.frmAppExtRepair.hdnIncTat.value='N';
		}
		if(document.frmAppExtRepair.chkIncPr.isChecked)
		{
			document.frmAppExtRepair.hdnIncPr.value='Y';
		}
		else
		{
			document.frmAppExtRepair.hdnIncPr.value='N';
		}
	if(document.frmAppExtRepair.hdnRepType.value == 'IR')
		{
			if(document.frmAppExtRepair.txtRefNum.value == "" || document.frmAppExtRepair.txtRefNum.value ==null)
			{
				alertMsgs(eCRDRepairRefNo);
				return false;
			}
			else
			{	
				document.frmAppExtRepair.hdnScreenAction.value="eCRDApproveIndRepair";
				alert(document.frmAppExtRepair.hdnScreenAction.value);
			}
		}
	else
		{
			document.frmAppExtRepair.hdnScreenAction.value="eCRDApproveGroupRepair";
			alert(document.frmAppExtRepair.hdnScreenAction.value);
		}
		alert(document.frmAppExtRepair.lstPrice.options[document.frmAppExtRepair.lstPrice.selectedIndex].value);
//		document.frmAppExtRepair.hdnPrType.value=document.frmAppExtRepair.lstPrice.options[document.frmAppExtRepair.lstPrice.selectedIndex].value;
		alert(document.frmAppExtRepair.hdnScreenAction.value);
		document.frmAppExtRepair.submit();
	}
}
function fnChkRejectRepair()
{
	document.frmAppExtRepair.hdnScreenAction.value="eCRDRejectRepair";
	alert(document.frmAppExtRepair.hdnScreenAction.value);
	document.frmAppExtRepair.submit();
}