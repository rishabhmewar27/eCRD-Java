function setPath(path)
	{
		basepathGlobal = path;
	}
	function fnDownloadBatch(objForm)
	{
		var hdnClass = objForm.selClass.options[objForm.selClass.selectedIndex].value;
		var hdnSite = objForm.selSite.options[objForm.selSite.selectedIndex].value;
		if(hdnClass == 'Select')
		{
			alertMsgs(eCRDSelect + " a class");
			objForm.selClass.focus();
			return false;
		}
		if(hdnSite == 'Select')
		{
			alertMsgs(eCRDSelect + " a site");
			objForm.selSite.focus();
			return false;
		}
		
		var strJspPath = basepathGlobal + '/ecrd/jsp/eCRDBatchDownload.jsp';
	
		//setting the features to the child window.
		features="toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=500,height=300,hide=yes";
		//opening the child window with the specified path.
		window.open(strJspPath+"?hdnClass="+hdnClass+"&hdnSite="+hdnSite,"excelfile","Batch Download","status=no,toolbar=no,menubar=no,scrollbars=no,resizable=no,width=350,height=225");
	
	}
/**************************************************************
 frmBatchUpload: On click of upload button submitCallUpload is called

 Parameters: None

 Returns: None
***************************************************************/

function submitCallUpload()
{
        
	fileName = document.frmBatchUpload.Browse.value;

    var sel = document.frmBatchUpload.selSite;
	var selIndex = sel.selectedIndex;
	var len = document.frmBatchUpload.selSite.length;
	var siteName = "";
	var siteValue ="";
	var ind = 0;
	var buf ="";


	
	if(!len>1)
	{
		alert("No Sites available to upload data");
		return fales;
	}
	else if(selIndex==0)
	{
		alert("Please select a site");
		return false;
	}
	else
	{
//	  siteName = sel.options[selIndex].value;
	  siteName = sel.options[selIndex].text;




	    document.frmBatchUpload.hdnSite.value = siteName;
		

	}
	if(fileName != null && fileName!='')
	{		
	    

		extension=fileName.substring(fileName.indexOf(".")+1, fileName.length);
		if(extension.toUpperCase() =='XLS' || extension.toUpperCase() =='XLSX')			//Changes made for Office 2010.
		{ 
			
            
			document.frmBatchUpload.hdnFile.value=fileName.substring(fileName.lastIndexOf("\\")+1, fileName.length);
			document.frmBatchUpload.hdnFilePath.value=fileName;
			document.frmBatchUpload.hdnScreenName.value = "BatchDownloadUpload";
			document.frmBatchUpload.hdnScreenAction.value = "eCRDBatchUpload";			
			
			var controller		= "";
			controller = 	document.frmBatchUpload.hdnControlPath.value;
//	        document.frmBatchUpload.action = controller+"?hdnScreenName=BatchDownloadUpload&hdnScreenAction=eCRDBatchUploadOperation&hdnFilePath=" + fileName + "&hdnSite="+siteName+"&hdnFile=" + fileName.substring(fileName.lastIndexOf("\\")+1, fileName.length);
	        document.frmBatchUpload.action = controller+"?hdnScreenName=BatchDownloadUpload&hdnScreenAction=eCRDBatchUploadOperation&hdnFilePath=" + fileName + "&hdnSite="+siteName+"&hdnFile=" + fileName; //+"&hdnsitevalues=" +buf;
			document.frmBatchUpload.submit();
			
		}
		else
		{
			alert("Please select XLS or XLSX file Only");			//Changes made for Office 2010.
			//alert(AM55);
			return false;
			
		}
	}
	else
	{
			//alert(AM56);
			alert("Please select a file to upload");
			document.frmBatchUpload.Browse.focus();
			return false;
	}

}		

function rCRDBatchUploadback()
{	
	document.frmBatchUploadResult.hdnScreenName.value = "BatchDownloadUpload";
	document.frmBatchUploadResult.hdnScreenAction.value = "eCRDBatchUploadBack";			
	document.frmBatchUploadResult.submit();
			
}