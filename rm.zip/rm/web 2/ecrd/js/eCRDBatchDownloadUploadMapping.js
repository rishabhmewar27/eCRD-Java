//This function is used to set the global path
function setPath(path)
{
		var basepathGlobal = path;
}
//END setPath method

function fnSelectEngine(objForm)
{
   var hdnEngineModel = objForm.selModel.options[objForm.selModel.selectedIndex].value;
   var hdnSite = objForm.selSite.options[objForm.selSite.selectedIndex].value;
   
   if(hdnSite == 'ALL')
   {
   	if(hdnEngineModel == 'Select')
   	{
       alertMsgs("Please select a specific engine model if you want to download data for all sites");
       objForm.selSite.focus();
   	 }
	}
}

function fnSelectSite(objForm)
{
	var hdnEngineModel = objForm.selModel.options[objForm.selModel.selectedIndex].value;
   	var hdnSite = objForm.selSite.options[objForm.selSite.selectedIndex].value;
	if(hdnEngineModel == 'Select')
	{
	   if(hdnSite == 'ALL')
   		{
       		alertMsgs("Please select a specific site if you want to download data for all engine models");
       		objForm.selSite.focus();
   		}
   	}

}



//This function is used to download the excel file of component mapping
//It validates the criteria fields.
	function fnDownloadBatch(objForm)
	{
		var hdnEngineModel;
		var EngineModel = objForm.selModel.options[objForm.selModel.selectedIndex].value;
		if(EngineModel == 'Select')
		{
			hdnEngineModel = "%%";
		}
		else
		{
			hdnEngineModel = objForm.selModel.options[objForm.selModel.selectedIndex].value;
		}
		var hdnSite = objForm.selSite.options[objForm.selSite.selectedIndex].value;
		var hdnEngineModelDesc = objForm.selModel.options[objForm.selModel.selectedIndex].text;
		if(hdnSite == 'Select')
		{
			alertMsgs(eCRDSelect + " a Site");
			objForm.selSite.focus();
			return false;
		}
		if(hdnSite == 'ALL' && EngineModel == 'Select')
   		{
   			
       			alertMsgs("Please select a specific engine model if you want to download data for all sites");
       			objForm.selSite.focus();
   	 	}
		else if(EngineModel == 'Select' && hdnSite == 'ALL')
		{
       			alertMsgs("Please select a specific site if you want to download data for all engine models");
	       		objForm.selSite.focus();
   		}
		else
		{
			var strJspPath = basePath + '/ecrd/jsp/eCRDBatchDownloadMapping.jsp';
			//setting the features to the child window.
			features="toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=500,height=300,hide=yes";
			//opening the child window with the specified path.
			window.open(strJspPath+"?hdnEngineModel="+hdnEngineModel+"&hdnEngineModelDesc="+hdnEngineModelDesc+"&hdnSite="+hdnSite,"excelfile","Batch Download Mapping","status=no,toolbar=no,menubar=no,scrollbars=no,resizable=no,width=350,height=225");
		}
	
	}


//This function is used to upload the excel file into the eCRD system.
//It validates the criteria fields
function fnsubmitCallUpload()
{
       
	var fileName = document.frmBatchUpload.Browse.value;
    var sel = document.frmBatchUpload.selSite;
	var selIndex = sel.selectedIndex;
	var len = document.frmBatchUpload.selSite.length;
	var siteName = "";
	var siteValue ="";
	var ind = 0;
	var buf ="";
	
	if(!len>1)
	{
		alert("No Sites available to upload data");
		return fales;
	}
	else if(selIndex==0)
	{
		alert("Please select a site");
		return false;
	}
	else
	{
//	  siteName = sel.options[selIndex].value;
	  siteName = sel.options[selIndex].text;
      document.frmBatchUpload.hdnSite.value = siteName;
	}
	if(fileName != null && fileName!='')
	{		
		extension=fileName.substring(fileName.indexOf(".")+1, fileName.length);
		if(extension.toUpperCase() =='XLS' || extension.toUpperCase() =='XLSX') 	//Changes made for Office 2010.
		{ 
            var controller		= "";
			document.frmBatchUpload.hdnFile.value=fileName.substring(fileName.lastIndexOf("\\")+1, fileName.length);
			document.frmBatchUpload.hdnFilePath.value=fileName;
			document.frmBatchUpload.hdnScreenName.value = "BatchDownloadUpload";
			document.frmBatchUpload.hdnScreenAction.value = "eCRDBatchUpload";		
			controller = 	document.frmBatchUpload.hdnControlPath.value;
	        document.frmBatchUpload.action = controller+"?hdnScreenName=BatchDownloadUpload&hdnScreenAction=eCRDBatchUploadMappingOperation&hdnFilePath=" + fileName + "&hdnSite="+siteName+"&hdnFile=" + fileName; //+"&hdnsitevalues=" +buf;
			document.frmBatchUpload.submit();
		}
		else
		{
			alert("Please select XLS or XLSX file Only");					//Changes made for Office 2010.
			return false;
		}
	}
	else
	{
			alert("Please select a file to upload");
			document.frmBatchUpload.Browse.focus();
			return false;
	}

}			
//END Upload method


//This function is used to direct the user back to the upload screen.
 
function fnBatchUploadback()
{	
	document.frmBatchUploadResult.hdnScreenName.value = "BatchDownloadUpload";
	document.frmBatchUploadResult.hdnScreenAction.value = "eCRDBatchUploadMappingBack";			
	document.frmBatchUploadResult.submit();
			
}
//END fnBatchUploadback method
