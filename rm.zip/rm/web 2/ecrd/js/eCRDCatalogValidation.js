function fnCancel()
{
   self.close();
}

function fnPopCopyCatalog(basePath)
{
    features='toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=no,width=600,height=500,left=50,top=50';
    dlg = window.open (basePath+"/ecrd?hdnScreenName=eCRDCustCatalogHelper&hdnScreenAction=eCRDCopyCatalog&RandomValue="+Math.random(),"Select_Catalog",features);
}

function fnSubmitCatalogList(objForm)
{

   if(objForm.hdnCatalogValue.value=="")
   {
      alertMsgs(eCRDCatalog);
   }
   else
   {
      document.frmCatalogList.submit();
      self.close();
   }
}

function fnGetCatalogValue(strCatalogValue,objForm)
{
   objForm.hdnCatalogValue.value = strCatalogValue;
}

function fnShowCatalogList(objForm)
{
   if(objForm.hdnCatalogValue.value=="")
   {
      alertMsgs(eCRDCatalogType);
   }
   else
   {
      objForm.submit();
   }
}

function fnBack(objFrm)
{
				objFrm.hdnScreenAction.value = "eCRDBackCopyExisting";
				objFrm.submit();
}