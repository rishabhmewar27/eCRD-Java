
/* String functions*/

/* Trim Function Starts */

//////////////////////////////////////////////////////
//Function Name		: fnLtrim
//Description		: Spaces to the left hand side of the value are trimmed
//Input Parameters	: string to be trimmed
//Return Value		: modified string
/////////////////////////////////////////////////////
function fnLtrim(strString)
{
    var i=0;
    var intLen = strString.length;
    while(((strString.charAt(i) == " ")||(strString.charAt(i) == "\n")||(strString.charAt(i) == "\r")) && ( i < intLen))
    {
        i++;
    }
    strString = strString.substring(i,intLen);
    return  strString;
}




//////////////////////////////////////////////////////
//Function Name		: fnRtrim
//Description		: Spaces to the right hand side of the value are trimmed
//Input Parameters	: string to be trimmed
//Return Value		: modified string
/////////////////////////////////////////////////////
function fnRtrim(strString)
{
    var intLen = strString.length;
    var intCntrLen= intLen-1;
    while((strString.charAt(intCntrLen) == " ") && ( intCntrLen > 0 ))
    {
        intCntrLen--;
    }
    strString = strString.substring(0,intCntrLen+1);
    return strString;
}

//////////////////////////////////////////////////////
//Function Name		: fnRemoveSpaces
//Description		: Removes the blank spaces from the object
//Input Parameters	: Object name
//Return Value		: modified object value
/////////////////////////////////////////////////////

function fnRemoveSpaces(strString)
{
   strString = fnLtrim(strString);
   strString = fnRtrim(strString);
   return strString;
}

//////////////////////////////////////////////////////
//Function Name		: fnTrim
//Description		: Removes the blank spaces from the object
//Input Parameters	: Object name
//Return Value		: modified object value
/////////////////////////////////////////////////////

function fnTrim(strString)
{
   strString = fnLtrim(strString);
   strString = fnRtrim(strString);
   return strString;
}

/* Trim Function Complete*/


function fnCheckNum(txtValue,strYear,precision)
{
	 txtValue = fnTrim(txtValue);
	 var alpha=/^[\-]?(([0-9]+(\.[0-9]+)?)|(\.[0-9]+)|(([0-9]+(\.[0-9]+)?)|(\.[0-9]+)))$/;
	 if (txtValue=='')
	 {	
		 alert('Please Enter Value For The Year '+strYear);
		  return 1;
	 }
	 else 
	 {
		 if(txtValue.length>6)
		 {
			alert('Please Enter Value Between 0.00 and 999.99 for '+strYear);
     		return 1;	
		 }
		 
		 if(txtValue.indexOf('-')!=-1)
		 {
			 alert('Please Enter Value Between 0.00 and 999.99 for '+strYear);
			 return 1;
		 }
		 if(txtValue.indexOf('.')!=-1)
		 {
			if(txtValue.substr(txtValue.indexOf('.')+1).length>precision)
			 {
				if (precision==0)
				{
					alert('Please enter integer value for '+strYear);
				    return 1;
				}
				else
				{
					alert('Please enter value only upto '+precision+' decimal places for '+strYear);
					return 1;
				}
			 }
		 }
		 if (txtValue.match(alpha)&(parseFloat(txtValue)>=0)&(parseFloat(txtValue)<1000))
		 {
			return 0;
		 }
		 else if ((parseFloat(txtValue)<0)|(parseFloat(txtValue)>=1000))
		 {
			 alert('Please Enter Value Between 0.00 and 999.99 for '+strYear);
			 return 1;
		 }
		 else if (!txtValue.match(alpha))
		 {
			 alert ('Please Enter Numeric Value for '+strYear);
			 return 1;
		 }
	 }
}


function fnCheckNumMax(txtValue,strYear,maxlength,precision)
{
	txtValue = fnTrim(txtValue);
	 var alpha=/^[\-]?(([0-9]+(\.[0-9]+)?)|(\.[0-9]+)|(([0-9]+(\.[0-9]+)?)|(\.[0-9]+)))$/;
	 var digits = maxlength-precision-1;
	 var limit = 0;
	 if(precision == 0)
	{
		 limit = Math.pow(10,digits) - 1;
	}
	else
	{
		 limit = Math.pow(10,digits) - 1/(Math.pow(10,precision));
	}
	 if (txtValue=='')
	 {	
		 alert('Please enter value for '+strYear);
		  return 1;
	 }
	 else 
	 {
		 if(parseFloat(txtValue)>limit)
		 {
			alert('Please enter value between 0 and '+ limit +' for '+strYear);
     		return 1;
		 }
		 
		 if(txtValue.indexOf('-')!=-1)
		 {
			 alert('Please enter value between 0 and '+ limit +' for '+strYear);
			 return 1;
		 }
		 if(txtValue.indexOf('.')!=-1)
		 {
			if(precision == 0)
			 {
				alert("The Decimal values are not allowed for "+ strYear);
				return 1;
			 }
			else
			if (txtValue.substr(txtValue.indexOf('.')+1).length>precision)
			 {
				alert('Please enter value only upto '+precision+' decimal places for '+strYear);
				return 1;
			 }
		 }
		 
		 if (txtValue.match(alpha)&(parseFloat(txtValue)>=0)&(parseFloat(txtValue)<=limit))
		 {
			return 0;
		 }
		 else if ((parseFloat(txtValue)<0)|(parseFloat(txtValue)>limit))
		 {
			 alert('Please enter value between 0 and '+limit+' for '+strYear);
			 return 1;
		 }
		 else if (!txtValue.match(alpha))
		 {
			 alert ('Please enter numeric value for '+strYear);
			 return 1;
		 }
	 }
}





function fnCheckNumMaxInt(txtValue,strYear,maxlength,precision)
{
	txtValue = fnTrim(txtValue);
	 var alpha=/^[\-]?(([0-9]+(\.[0-9]+)?)|(\.[0-9]+)|(([0-9]+(\.[0-9]+)?)|(\.[0-9]+)))$/;
	 var digits = maxlength-precision-1;
	 var limit = 0;
	 if(precision == 0)
	{
		 limit = Math.pow(10,digits);
	}
	else
	{
		 limit = Math.pow(10,digits);
	}
	 if (txtValue=='')
	 {	
		 alert('Please enter value for '+strYear);
		  return 1;
	 }
	 else 
	 {
		 if(parseFloat(txtValue)>limit)
		 {
			alert('Please enter value between 0 and '+ limit +' for '+strYear);
     		return 1;
		 }
		 
		 if(txtValue.indexOf('-')!=-1)
		 {
			 alert('Please enter value between 0 and '+ limit +' for '+strYear);
			 return 1;
		 }
		 if(txtValue.indexOf('.')!=-1)
		 {
			if(precision == 0)
			 {
				alert("The Decimal values are not allowed for "+ strYear);
				return 1;
			 }
			else
			if (txtValue.substr(txtValue.indexOf('.')+1).length>precision)
			 {
				alert('Please enter value only upto '+precision+' decimal places for '+strYear);
				return 1;
			 }
		 }
		 
		 if (txtValue.match(alpha)&(parseFloat(txtValue)>=0)&(parseFloat(txtValue)<=limit))
		 {
			return 0;
		 }
		 else if ((parseFloat(txtValue)<0)|(parseFloat(txtValue)>limit))
		 {
			 alert('Please enter value between 0 and '+limit+' for '+strYear);
			 return 1;
		 }
		 else if (!txtValue.match(alpha))
		 {
			 alert ('Please enter numeric value for '+strYear);
			 return 1;
		 }
	 }
}

function fnOnMouseOver(message)
{
	window.status = message;
	return true;
}

function fnOnMouseOut()
{
	window.status = "";
	return true;
}


function fnClose()
{
    self.close();
}

function closePopWindow()
{
    if (typeof top.winMsg == 'object')
    {
        top.winMsg.close();
    }
}




function fnChangTrack(frmObj,origValue,currValue)
{
	if(parseFloat(currValue) != parseFloat(origValue))
	{
		frmObj.hdnChangeAction.value="Changed";
		return;
	}
}





//////////////////////////////////////////////////////
//Function Name		: check valid Date
//Description		: Function for checking if the date is valid (mm/dd/yyyy format) or not
//Input Parameters	: string to be validated
//Return Value		: true or false depending upon the validity of the date
/////////////////////////////////////////////////////
function fnValidateDate(Object)
{

	var daycount = 0,monthcount = 0,yearcount = 0;
	var strDate = '',strDay = '',strMonth = '',strYear = '';
	var bFound;
	var i,j,k;	

	strDate		= Object.value; 
	arrDays 	= new Array(31,28,31,30,31,30,31,31,30,31,30,31);

	monthcount = 0;

	for ( j = 0;  j < strDate.length ; j++)
	{
		if ((strDate.substring(j,j+1) != '.') && (strDate.substring(j,j+1) != '/') && (strDate.substring(j,j+1) != '\\') && (strDate.substring(i,i+1) != '-'))

		{
			if (monthcount == 2)
			{ 
			    bFound = 0;
				break;	
			}			

			strMonth = strMonth + strDate.substring(j,j+1);
			monthcount = monthcount + 1;
		}

		else

		{
		    bFound = 1;
			break;
		}	

	}

	if (bFound == 1)

		j = j + 1;			

	daycount = 0;

	for ( i = j; i < strDate.length ; i++)

	{
		if ((strDate.substring(i,i+1) != '.') && (strDate.substring(i,i+1) != '/') && (strDate.substring(i,i+1) != '\\') && (strDate.substring(i,i+1) != '-'))

		{
			if (daycount == 2)

			{
				bFound = 0;
				break;
			}

			strDay = strDay + strDate.substring(i,i+1);
			daycount = daycount + 1;
		}
		else
		{
			bFound = 1;
			break;
		}				

	}			

	if (bFound == 1)
		i = i + 1;
	yearcount = 0;

	for ( k = i;  k <= strDate.length ; k++)

	{
		if ((strDate.substring(k,k+1) != '.') && (strDate.substring(k,k+1) != '/') && (strDate.substring(k,k+1) != '\\') && (strDate.substring(i,i+1) != '-'))

		{
			strYear = strYear + strDate.substring(k,k+1);
			yearcount = yearcount + 1;
		}

		else
		{
			break;
		}	
	}	

	if (strYear.length == 2)

	{
		if ((strYear >= 50) && (strYear <= 99))

		{
			strYear = '19' + strYear;
		}

		if ((strYear >= 00) && (strYear <= 49))

		{
			strYear = '20' + strYear;
		}
	}

	if (strDay.length == 1 )

	{
		strDay = '0' + strDay;
	}

	if (strMonth.length == 1 )

	{
		strMonth = '0' + strMonth;
	}
	
	if (strDay == 0 || strMonth == 0 || strYear== 0 )

	{
		alert ('Date should be in mm/dd/yyyy format');
		return false;
	}

	if (isNaN(strDay) || isNaN(strMonth) || isNaN(strYear))

	{
		alert ('Date should be in mm/dd/yyyy format');
		return false;
	}

	if (strMonth > 12)

	{
		alert ('Not have a Valid Month');
		return false;
	}

	if (strYear.length != 4) 

	{
		alert ('Year should be in yyyy format');
		return false;
	}			

	if (strMonth == 2)

	{
		if ( strYear%4 == 0)
      {
         if(strYear%100 == 0)
         {
            if(strYear%400==0)
            {
               	arrDays[strMonth  - 1] = 29;
            }
         }
         else
         {
            	arrDays[strMonth  - 1] = 29;
         }
      }
		
	}

	if (strDay > arrDays[strMonth  - 1])

	{
		alert('Number of days exceeded for the month');
		return false;	
	}

	strDate =  strMonth + '/' + strDay + '/' + strYear;
	Object.value = strDate;
	return true;

}





//////////////////////////////////////////////////////
//Function Name		: fnChkNumeral
//Description		: Function for checking the value is numeral or not
//Input Parameters	: Object,value of which is to be checked
//Return Value		: none
/////////////////////////////////////////////////////
function fnChkNumeral(objName){
	
	
	var i;
	var strVar = objName.value;
	if (strVar != ""){
		for(i = 0; i < strVar.length; i++){
			if((strVar.charCodeAt(i) > 47) && (strVar.charCodeAt(i) < 58)){
				continue;
			}
			else
			{
				alert("Enters numerals only");
				objName.select();
				objName.focus();
				return false;
			}
		}return true;
	}return true;
}

/*************************************************************
*************************************************/

//////////////////////////////////////////////////////
//Function Name		: fnReplaceChar
//Description		: Replaces the char char1 to char2 in strText
//Input Parameters	: String, char, char
//Return Value		: Replaced string
/////////////////////////////////////////////////////
function fnReplaceChar(strText,char1,char2)
{
  var  charTemp,strTemp,i;
  strTemp="";
  for(i = 0; i < strText.length; i++)
  {
	  charTemp =  strText.charAt(i);
	  if (charTemp==char1) charTemp=char2;
	  strTemp=strTemp+charTemp;
  }
  return strTemp;
}



/*************************************************************
*************************************************/
////////////////////////////////////////////////////////////////////////////////////////////
/////////
//Function Name		: validEmail
//Description		: validates the given email format is correcr or not
//Input Parameters	: object,value of which is to be validated
//Return Value		: false if validation fails otherwise true.
////////////////////////////////////////////////////////////////////////////////////////////
/////////
function fnvalidEmail(objEmail) {

		email = objEmail.value;
			invalidChars = " /:,;";
			if (email == "")
			{
				alertMsgs(eCRDEmail);

				return false;
				
			}
			for (i=0; i<invalidChars.length; i++) {
// does it contain any invalid characters?
				badChar = invalidChars.charAt(i);
				if (email.indexOf(badChar,0) > -1) {
					alertMsgs(eCRDEmail);
					return false;
					
				}
			}
			atPos = email.indexOf("@",1);
// there must be one "@" symbol
			if (atPos == -1) {
				alertMsgs(eCRDEmail);
				return false;
			}
			if (email.indexOf("@",atPos+1) != -1) {
				alertMsgs(eCRDEmail);
// and only one "@" symbol
				return false;
			}
			periodPos = email.indexOf(".",atPos);
			if (periodPos == -1)
			{
				alertMsgs(eCRDEmail);
// and at least one "." after the "@"
				return false;
			}
			if (periodPos+3 > email.length)	{
				alertMsgs(eCRDEmail);
// must be at least 2 characters after the "."
				return false;
			}
			return true;
}

/*************************************************************
*************************************************/

function fncheckValidAlphanumeric(field)
{
 	for (var i=0; i<(field.value).length; i++)
 	{
 		var valid = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ "
 		var temp = trim(field.value).substring(i, i+1);
 		if (valid.indexOf(temp) == "-1")
 		{
			field.focus();
 			return false;
 		}
 	}
	return true;
}


/*************************************************************
*************************************************/

function fnreplaceSubstring(inputString, fromString, toString) {
   // Goes through the inputString and replaces every occurrence of fromString with toString
   var temp = inputString;
   if (fromString == "") {
	  return inputString;
   }
   if (toString.indexOf(fromString) == -1) { // If the string being replaced is not a part of the replacement string (normal situation)
	  while (temp.indexOf(fromString) != -1) {
		 var toTheLeft = temp.substring(0, temp.indexOf(fromString));
		 var toTheRight = temp.substring(temp.indexOf(fromString)+fromString.length, temp.length);
		 temp = toTheLeft + toString + toTheRight;
	  }
   } else { // String being replaced is part of replacement string (like "+" being replaced with "++") - prevent an infinite loop
	  var midStrings = new Array("~", "`", "_", "^", "#");
	  var midStringLen = 1;
	  var midString = "";
	  // Find a string that doesn't exist in the inputString to be used
	  // as an "inbetween" string
	  while (midString == "") {
		 for (var i=0; i < midStrings.length; i++) {
			var tempMidString = "";
			for (var j=0; j < midStringLen; j++) { tempMidString += midStrings[i]; }
			if (fromString.indexOf(tempMidString) == -1) {
			   midString = tempMidString;
			   i = midStrings.length + 1;
			}
		 }
	  } // Keep on going until we build an "inbetween" string that doesn't exist
	  // Now go through and do two replaces - first, replace the "fromString" with the "inbetween" string
	  while (temp.indexOf(fromString) != -1) {
		 var toTheLeft = temp.substring(0, temp.indexOf(fromString));
		 var toTheRight = temp.substring(temp.indexOf(fromString)+fromString.length, temp.length);
		 temp = toTheLeft + midString + toTheRight;
	  }
	  // Next, replace the "inbetween" string with the "toString"
	  while (temp.indexOf(midString) != -1) {
		 var toTheLeft = temp.substring(0, temp.indexOf(midString));
		 var toTheRight = temp.substring(temp.indexOf(midString)+midString.length, 
temp.length);
		 temp = toTheLeft + toString + toTheRight;
	  }
   } // Ends the check to see if the string being replaced is part of the replacement string or not
   return temp; // Send the updated string back to the user
} // Ends the "replaceSubstring" function

/*************************************************************
*************************************************/

/*To check mentioned special chracters*/
function fnCheckSplChars(objInput)
{
    argValue = objInput.value;
    var wildCharArray = new Array('`','~','!','@','#','$','%','^','&','"','\'',';','{','}','[',']','|','\\','\/','<','>','?','+','\=');

    for(cnt =0; cnt< wildCharArray.length ;cnt++)
    {
    	if(argValue.indexOf(wildCharArray[cnt]) >=0)
        {
            objInput.select();
            objInput.focus();
            return false;
        }
    }
    return true;
}
/*************************************************************
*************************************************/

function fnValidatePositiveNumber(strText)
{
    var  strTemp;
	var  strTemp1 = strText;

    if(parseInt(strTemp1,10) < 0)
    {
    	alert("Please enter a positive number.");
        return false;
    }

    if(strText.indexOf("-") == 0)
    {
        strText = strText.substring(1,strText.length)
    }

    for(i = 0; i < strText.length; i++)
    {
        strTemp =  strText.charAt(i);
        if(strTemp.indexOf(".") != -1)
        {
            alert("Please enter a whole number");
            return false;
        }
        else if(strTemp < "0" || strTemp > "9")
        {
            alert("Please enter a valid number");
            return false;
        }
    }

    return true;
}
/*************************************************************
*************************************************/
/*************************************************************
*************************************************/
//////////////////////////////////////////////////////
//Function Name		: fnChkFloat
//Description		: Function for checking the value is float or not
//Input Parameters	: Object,value of which is to be checked
//Return Value		: none
/////////////////////////////////////////////////////
function fnChkFloat(objName){
	
	
	var i;
	var strVar = objName.value;
	fnRemoveSpaces(objName);
	if(!(ValidateText(objName)))
	{
		return false;
	}
	if (strVar != ""){
		for(i = 0; i < strVar.length; i++){
			if((strVar.charCodeAt(i) > 47) && (strVar.charCodeAt(i) < 58)){
				continue;
			}
			else if(strVar.charCodeAt(i) == 46)
			{
				continue;
			}
			else
			{
				alert("Enter float only");
				objName.select();
				objName.focus();
				return false;
			}
		}
		return true;
	}
	return true;
}
/*************************************************************
*************************************************/
//////////////////////////////////////////////////////
//Function Name		: fnCheckDecimal
//Description		: Function for checking the value is decimal with the given precision or not
//Input Parameters	: Object,value of which is to be checked
//Return Value		: none
/////////////////////////////////////////////////////
function fnCheckDecimal(Object,strFixDigit,strMantissa)
{
if(!fnChkNumeral(Object))
{
	return false;
}
var i;
var strVar   = Object.value;
var FixDigit = strFixDigit;
var Mantissa = strMantissa;
var DigitLen = Mantissa+FixDigit;
var intChk   = Object.value.indexOf(".");

if(strVar.length>FixDigit && intChk==-1)
{
	alert("Please enter number which has max length "+FixDigit+"  before decimal \n and max length "+ Mantissa +" after decimal");
	Object.select();
	Object.focus();
	return false;
}
else if(strVar.length>=FixDigit && intChk < FixDigit )
{
	Object.value = fnSetPrecision(Object.value,strMantissa);
	return true;
}
else
{
	Object.value = fnSetPrecision(Object.value,strMantissa);
	return true;
}

}

//////////////////////////////////////////////////////
//Function Name		: fnOpenDialog
//Description		: Function to Open a New Window
//Input Parameters	: ur, windowname, width, height
//Return Value		: void
/////////////////////////////////////////////////////
function fnOpenDialog(url, winName, width, height)
{
	var Nav4 = ((navigator.appName == "Netscape") && (parseInt(navigator.appVersion) == 4));
	var dialogWin = new Object();
	dialogWin.returnedValue = "";
	dialogWin.url = url;
	dialogWin.width = width;
	dialogWin.height = height;

	dialogWin.name = winName; //(new Date()).getSeconds().toString();

	if (Nav4)
	{
		dialogWin.left = window.screenX + ((window.outerWidth - dialogWin.width) / 2);
		dialogWin.top = window.screenY +  ((window.outerHeight - dialogWin.height) / 2);
		var attr = "screenX=" + dialogWin.left + ",screenY=" + dialogWin.top + ",resizable=yes,width=" +		dialogWin.width + ",height=" + dialogWin.height+",scrollbars=yes";
	}
	else
	{
		dialogWin.left = (screen.width - dialogWin.width) / 2;
		dialogWin.top = (screen.height - dialogWin.height) / 2;
		var attr = "left=" + dialogWin.left + ",top=" + dialogWin.top + ",resizable=yes,width="	+ dialogWin.width + ",height=" + dialogWin.height+",scrollbars=yes"
      }
	dialogWin.win=window.open(dialogWin.url, dialogWin.name, attr);
	dialogWin.win.focus();
}

/* Allow alphabets , numbers and special chars : _,-, whitespace */
/* rajula added..jun 04  */

function fnCheckAlphaNumeric(strFieldName,strValue)
{
    if (!fnValidateAlphaNumeric(strValue))
    {
        alert("The following reserved characters are allowed in "+strFieldName+". \n"+            ".  _  -  and whitespace.");
        return false;
    }
    return true;
}



//check if alphanumeric return false if not
function fnValidateAlphaNumeric(strValue)
{
    var i;
    if (strValue =="")
    {
        return true;
    }
    else
    {
        for(i = 0; i < strValue.length; i++)
        {
            if(strValue.charAt(i)==" "  ||
            strValue.charAt(i) == "."   ||
            strValue.charAt(i) == "_"   ||
            strValue.charAt(i) == "-")
            {
            }
            else
            {
                if(strValue.charAt(i) < "0" || strValue.charAt(i) > "9")
                {
                    if(strValue.charAt(i) < "a" || strValue.charAt(i) > "z")
                    {
                        if(strValue.charAt(i) < "A" || strValue.charAt(i) > "Z")
                        {
                          return false;
                        }
                    }
                }
            }
        }
        return true;
    }
}//end of function ValidateAlphaNumeric

function fnOpenWindow(path, title)
{
	var FcastWin;
	features = "toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes, width=800, height=250";
	FcastWin = window.open(path,title,features);
}

// function returning string which containes the features property

function fnPopUpFeatures()
{
	var features;
	features = "toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=800,height=600";
	return features;
}


function fnCheckNumEditQuarter(txtValue,strYear,maxlength,precision)
{
	txtValue = fnTrim(txtValue);
	 var alpha=/^[\-]?(([0-9]+(\.[0-9]+)?)|(\.[0-9]+)|(([0-9]+(\.[0-9]+)?)|(\.[0-9]+)))$/;
	 var digits = maxlength-precision-1;
	 var limit = 0;
	 if(precision == 0)
	{
		 limit = Math.pow(10,digits) ;
	}
	else
	{
		 limit = Math.pow(10,digits) - 1/(Math.pow(10,precision));
	}
	 if (txtValue=='')
	 {	
		 alert('Please enter value for '+strYear);
		  return 1;
	 }
	 else 
	 {
		 if(parseFloat(txtValue)>limit)
		 {
			alert('Please enter value between 0 and '+ limit +' for '+strYear);
     		return 1;
		 }
		 
		 if(txtValue.indexOf('-')!=-1)
		 {
			 alert('Please enter value between 0 and '+ limit +' for '+strYear);
			 return 1;
		 }
		 if(txtValue.indexOf('.')!=-1)
		 {
			if(precision == 0)
			 {
				alert("The Decimal values are not allowed for "+ strYear);
				return 1;
			 }
			else
			if (txtValue.substr(txtValue.indexOf('.')+1).length>precision)
			 {
				alert('Please enter value only upto '+precision+' decimal places for '+strYear);
				return 1;
			 }
		 }
		 
		 if (txtValue.match(alpha)&(parseFloat(txtValue)>=0)&(parseFloat(txtValue)<=limit))
		 {
			return 0;
		 }
		 else if ((parseFloat(txtValue)<0)|(parseFloat(txtValue)>limit))
		 {
			 alert('Please enter value between 0 and '+limit+' for '+strYear);
			 return 1;
		 }
		 else if (!txtValue.match(alpha))
		 {
			 alert ('Please enter numeric value for '+strYear);
			 return 1;
		 }
	 }
}

//////////////////////////////////////////////////////

//Function Name		: fnAddFromSourceListToTargetList
//Description		: Function to move the selected value from one list to another
//Input Parameters	: SourceList,TargetList
//Return Value		: void

/////////////////////////////////////////////////////


function fnAddFromSourceListToTargetList(SourceList,TargetList)
{
  	if(SourceList.selectedIndex >= 0)
	{
     TargetValue = SourceList.options[SourceList.selectedIndex].value;
     TargetText = SourceList.options[SourceList.selectedIndex].text;
     SourceList.options[SourceList.selectedIndex] = null;
	  size = TargetList.length;
     TargetList.length = size + 1;
     TargetList.options[size].value= TargetValue;
	  TargetList.options[size].text = TargetText;
   }
   else
	{
         alertMsgs(eCRDSelectList);          
			return false;
	}
   return true;
}

//////////////////////////////////////////////////////

//Function Name		: fnRemoveFromListToTextBox
//Description		: Function to move the selected value from list to TextBox
//Input Parameters	: SourceText,SourceList
//Return Value		: void

/////////////////////////////////////////////////////


function fnRemoveFromListToTextBox(SourceText,SourceList)
{
 	if(SourceList.selectedIndex >= 0)
	{
		if(SourceList.length >=1 && SourceList.selectedIndex != -1)
		{
	         SourceListText =SourceList.options[SourceList.selectedIndex].text;
            SourceList.options[SourceList.selectedIndex] = null;
            SourceText.value= SourceListText;
        		SourceText.focus();
   	}
	}
	else
	{
		alertMsgs(eCRDSelectList);
		SourceList.focus();
		return false;
	}
}
//////////////////////////////////////////////////////

//Function Name		: fnAddFromTextBoxToSourceList
//Description		: Function to move the entered value from TextBox to list
//Input Parameters	: SourceText,TargetList
//Return Value		: void

/////////////////////////////////////////////////////



function fnAddFromTextBoxToSourceList(SourceText,TargetList)
{
  	SourceTextVal = fnTrim(SourceText.value);
	if(!fnCheckSplChars(SourceText))
	{
   	 SourceText.focus();
 		 return false;
	}
	if(SourceTextVal != "")
	{
		for(i = 0;i < TargetList.length;i++)
      {
			if(TargetList.options[i].value == SourceTextVal)
         {
						alertMsgs(eCRDDupValues);
						SourceText.focus();
						return false;
			}
		}
		size = TargetList.length;
   	TargetList.length = size + 1;
		TargetList.options[size].value= SourceTextVal;
		TargetList.options[size].text = SourceTextVal;
		SourceText.value="";
		SourceText.focus();
      return true;
	}
  	else
	{
         alertMsgs(eCRDempty);
  			SourceText.select();
			SourceText.focus();
   }
}
//////////////////////////////////////////////////////

//Function Name		: fnRemoveFromList
//Description		: Function to remove the selected  value from the list
//Input Parameters	: SourceText,TargetList
//Return Value		: void

/////////////////////////////////////////////////////

function fnRemoveFromList(SourceList)
{
	if(SourceList.selectedIndex >= 0)
	{
		if(SourceList.length >=1 && SourceList.selectedIndex != -1)
		{
				SourceList.options[SourceList.selectedIndex] = null;
   	}
	}
	else
	{
		alertMsgs(eCRDSelectList);
		SourceList.focus();
		return false;
	}
}

//////////////////////////////////////////////////////

//Function Name		: fnMoveDown
//Description		: Function to exchange the selected value from the list with the value below it
//Input Parameters	: SourceText,ListName
//Return Value		: void

/////////////////////////////////////////////////////


function fnMoveDown(TargetList,strListName)
{
    if(TargetList.selectedIndex!=-1)
   {
      if(TargetList.selectedIndex != TargetList.length-1)
   	{
       TargetValue = TargetList.options[TargetList.selectedIndex].value;
       TargetText = TargetList.options[TargetList.selectedIndex].text;
       SourceValue= TargetList.options[TargetList.selectedIndex+1].value;
       SourceText= TargetList.options[TargetList.selectedIndex+1].text;
   
       TargetList.options[TargetList.selectedIndex+1].value = TargetValue;
       TargetList.options[TargetList.selectedIndex+1].text = TargetText;
       TargetList.options[TargetList.selectedIndex].value = SourceValue;
       TargetList.options[TargetList.selectedIndex].text = SourceText;
       TargetList.options[TargetList.selectedIndex+1].selected = true;
     	}
      else
      {
         alertMsgs("Selected " + strListName + eCRDLastPosition);
      }
   }
   else
   {
         alertMsgs(eCRDSelect + " " + strListName);
   }
}

//////////////////////////////////////////////////////

//Function Name		: fnMoveUp
//Description		: Function to exchange the selected value from the list with the value above it.
//Input Parameters	: TargetList,ListName
//Return Value		: void

/////////////////////////////////////////////////////


function fnMoveUp(TargetList,strListName)
{

   if(TargetList.selectedIndex!=-1)
   {
      if(TargetList.selectedIndex > 0)
   	{
       TargetValue = TargetList.options[TargetList.selectedIndex].value;
       TargetText = TargetList.options[TargetList.selectedIndex].text;
       SourceValue= TargetList.options[TargetList.selectedIndex-1].value;
       SourceText= TargetList.options[TargetList.selectedIndex-1].text;
   
       TargetList.options[TargetList.selectedIndex-1].value = TargetValue;
       TargetList.options[TargetList.selectedIndex-1].text = TargetText;
       TargetList.options[TargetList.selectedIndex].value = SourceValue;
       TargetList.options[TargetList.selectedIndex].text = SourceText;
       TargetList.options[TargetList.selectedIndex-1].selected = true;
     	}
      else
      {
         alertMsgs("Selected " + strListName + eCRDFirstPosition);
      }
   }
   else
   {
         alertMsgs(eCRDSelect + " " + strListName);
   }
}

function OnlyNumbers()
{
	var KNums = event.keyCode;

	if((!(KNums>=48 && KNums<=57)))event.returnValue=false;
	{
	if((KNums==45))event.returnValue=true;
	if(!(KNums=110))event.returnValue=false;
	}
}

function OnlyDecimalNumbers()
{
	var KNums = event.keyCode;
   
	if((!(KNums>=48 && KNums<=57)))event.returnValue=false;
	{
	if((KNums==46))event.returnValue=true;
	if(!(KNums=110))event.returnValue=false;
	}
}


/*added by 502633024*/
function validateSPADPrice() { 

	var KNums = event.keyCode;
	   
	if((!(KNums>=48 && KNums<=57)))event.returnValue=false;
	{
	if((KNums==46))event.returnValue=true;
	
	}
}
function validateSPADNumber() { 

	 var KNums = event.keyCode;
	    
	 if((!((KNums>=48 && KNums<=57)||(KNums>=65 && KNums<=90)||(KNums>=97 && KNums<=122))))event.returnValue=false;
	 {
	 if((KNums==45))event.returnValue=true;
	 
	 }
	}
function SPADNumberValidate(){
	
	 var x = document.getElementById("txtSPADPartNumber");
	    x.value = x.value.toUpperCase();
	
	
}
function SPADPriceValidate(){
	
	var x = /^\s*-?[1-9]\d*(\.\d{1,2})?\s*$/;
	var val = document.getElementById("txtSPADPartPrice").value;

	if(!(x.test(val))){
	alert("SPAD Price accepts only two Decimal Places");
	document.getElementById("txtSPADPartPrice").value ="";
	document.frmRepairDetails.txtSPADPartPrice.focus();
	}
}

//////////////////////////////////////////////////////
//Function Name		: fnValidateDateString
//Description		: Function for checking the date  is proper format
//Input Parameters	: String value of which is to be checked
//Return Value		: none
/////////////////////////////////////////////////////

function fnValidateDateString(strDate)
{

	var daycount = 0,monthcount = 0,yearcount = 0;
	var strDate = strDate,strDay = '',strMonth = '',strYear = '';
	var bFound;
	var i,j,k;	
	arrDays 	= new Array(31,28,31,30,31,30,31,31,30,31,30,31);

	monthcount = 0;

	for ( j = 0;  j < strDate.length ; j++)
	{
		if ((strDate.substring(j,j+1) != '.') && (strDate.substring(j,j+1) != '/') && (strDate.substring(j,j+1) != '\\') && (strDate.substring(i,i+1) != '-'))

		{
			if (monthcount == 2)
			{ 
			    bFound = 0;
				break;	
			}			

			strMonth = strMonth + strDate.substring(j,j+1);
			monthcount = monthcount + 1;
		}

		else

		{
		    bFound = 1;
			break;
		}	

	}

	if (bFound == 1)

		j = j + 1;			

	daycount = 0;

	for ( i = j; i < strDate.length ; i++)

	{
		if ((strDate.substring(i,i+1) != '.') && (strDate.substring(i,i+1) != '/') && (strDate.substring(i,i+1) != '\\') && (strDate.substring(i,i+1) != '-'))

		{
			if (daycount == 2)

			{
				bFound = 0;
				break;
			}

			strDay = strDay + strDate.substring(i,i+1);
			daycount = daycount + 1;
		}
		else
		{
			bFound = 1;
			break;
		}				

	}			

	if (bFound == 1)
		i = i + 1;
	yearcount = 0;

	for ( k = i;  k <= strDate.length ; k++)

	{
		if ((strDate.substring(k,k+1) != '.') && (strDate.substring(k,k+1) != '/') && (strDate.substring(k,k+1) != '\\') && (strDate.substring(i,i+1) != '-'))

		{
			strYear = strYear + strDate.substring(k,k+1);
			yearcount = yearcount + 1;
		}

		else
		{
			break;
		}	
	}	

	if (strYear.length == 2)

	{
		if ((strYear >= 50) && (strYear <= 99))

		{
			strYear = '19' + strYear;
		}

		if ((strYear >= 00) && (strYear <= 49))

		{
			strYear = '20' + strYear;
		}
	}

	if (strDay.length == 1 )

	{
		strDay = '0' + strDay;
	}

	if (strMonth.length == 1 )

	{
		strMonth = '0' + strMonth;
	}
	
	if (strDay == 0 || strMonth == 0 || strYear== 0 )

	{
		alert ('Date should be in mm/dd/yyyy format');
		return false;
	}

	if (isNaN(strDay) || isNaN(strMonth) || isNaN(strYear))

	{
		alert ('Date should be in mm/dd/yyyy format');
		return false;
	}

	if (strMonth > 12)

	{
		alert ('Not have a Valid Month');
		return false;
	}

	if (strYear.length != 4) 

	{
		alert ('Year should be in yyyy format');
		return false;
	}			

	if (strMonth == 2)

	{
		if ( strYear%4 == 0)
      {
         if(strYear%100 == 0)
         {
            if(strYear%400==0)
            {
               	arrDays[strMonth  - 1] = 29;
            }
         }
         else
         {
            	arrDays[strMonth  - 1] = 29;
         }
      }
		
	}

	if (strDay > arrDays[strMonth  - 1])

	{
		alert('Number of days exceeded for the month');
		return false;	
	}

	strDate =  strMonth + '/' + strDay + '/' + strYear;
	
	return true;

}

function sort(sel) 
{
  a=new Array(sel.options.length);
	 b=new Array(sel.options.length);
	 for(i=0;i<sel.options.length;i++) 
	 {
        a[i]=sel.options[i].text;
	 }
	 for(i=0;i<a.length;i++) 
	 {
        sel.options[i]=null;
	 }
	 for(i=0;i<a.length;i++) 
	 { // sorting
	   for(j=i+1;j<a.length;j++) 
	   {
	     if(a[i] > a[j]) 
	     {
									temp=a[i];
			      a[i]=a[j];
			      a[j]=temp;
		    }
	   }
	 }
	 for(i=0;i<a.length;i++) 
	 {
       b[i]= new Option(a[i],a[i]);
	 }
		for(i=0;i<a.length;i++) 
		{
	 	   sel.options[i]=b[i];
		}
}
function fnRoundTwoDecimal(fltval)
{
	if(isNaN(fltval))
	{
		return '0';
	}
	else
	{
		val = (Math.round(fltval * 100)/100) + '';
		return val;
	}
}
