function fnCheckContractualEntry()
{
   objForm = document.frmContractualRules;
   if(performValidation(document.frmContractualRules))
   {
   			objForm.hdnScreenAction.value = "eCRDCreateRules";
   			objForm.submit();
   }
}

function fnAddRows(frm)
{
   frm.hdnScreenAction.value = "eCRDAddInflation";
   frm.submit();
}

function fnDeleteRow(value,frm)
{
   frm.hdnDeleteValue.value = value;
   frm.hdnScreenAction.value = "eCRDRemoveInflation";
   frm.submit();
}
function fnDisable()
{
   objfrm = document.frmContractualRules;
			var escalation = objfrm.txtEscln.value;
			if(escalation !="")
			{
						if(!objfrm.txtindex.length)
						{
							  objfrm.txtindex.disabled  =true;
				     objfrm.txtdepend.disabled =true;
						}
						else
						{
				    for(i=0; i<objfrm.txtindex.length; i++)
					   {
					   	  objfrm.txtindex[i].disabled  =true;
				     		objfrm.txtdepend[i].disabled =true;
				    }
						}
		    objfrm.txtEscln.disabled = false;
			}
			else
			{
						if(!objfrm.txtindex.length)
						{
									objfrm.txtindex.disabled  =false;
					    objfrm.txtdepend.disabled =false;
						}
						else
						{
					    for(i=0; i<objfrm.txtindex.length; i++)
						   {
						   	  objfrm.txtindex[i].disabled  =false;
					     		objfrm.txtdepend[i].disabled =false;
					    }
						}
						objfrm.txtEscln.disabled  =true;
			}
}
/*** Addition over by Rushit ***/

function fnViewAnnualRules()
{
   objFrm = document.frmViewRules;
   if(objFrm.drpdwn_year.selectedIndex == null)
   {
      objFrm.drpdwn_year.focus();
      return false;
   }
   objFrm.hdnScreenAction.value = "eCRDViewRules";
   objFrm.submit();
}

function fnModifyRules(Year,CatalogId,ModuleId,ComponentId,RepairId,RuleCd)
{
   objForm = document.frmViewRules;
   objForm.hdnYear.value = Year;
   objForm.hdnCatalogCd = CatalogId;
   objForm.hdnModuleCd.value = ModuleId;
   objForm.hdnComponentCd.value = ComponentId;
   objForm.hdnRepairCd.value = RepairId;
   objForm.hdnRuleCd.value = RuleCd;
   objForm.hdnScreenAction.value = "eCRDModifyRule";
   objForm.submit();
}

function fnUpdateRules()
{
   objForm = document.frmContractualRules;
   if(performValidation(document.frmContractualRules))
   {
  	 		objForm.hdnScreenAction.value = "eCRDUpdateRule";
   			objForm.submit();
   }
}

function fnCopyAndApplyRules()
{
   objForm = document.frmViewRules;
   objForm.hdnScreenAction.value = "eCRDCopyAndApply";
   objForm.btnIMDone.disabled = true;
   objForm.submit();
}
//Added for applying default refresh -Kumar
function fnApplyDefaultRefreshRules()
{
   objForm = document.frmViewRules;
   objForm.hdnScreenAction.value = "eCRDApplyDefaultRefresh";
   objForm.btnDRDone.disabled = true;
   objForm.submit();
}
function fnDeleteRules(Year,CatalogId,ModuleId,ComponentId,RepairId,RuleCd)
{
	if(confirm("Are you Sure you want to delete this Rule?"))
	{
   	objForm = document.frmViewRules;
   	objForm.hdnYear.value = Year;
   	objForm.hdnCatalogCd = CatalogId;
	   objForm.hdnModuleCd.value = ModuleId;
	   objForm.hdnComponentCd.value = ComponentId;
	   objForm.hdnRepairCd.value = RepairId;
	   objForm.hdnRuleCd.value = RuleCd;
	   objForm.hdnScreenAction.value = "eCRDDeleteRule";
	   objForm.submit();
	}
}

function performValidation(objFrm)
{
	  var ruleType = objForm.hdnRuleCd.value;
//   var notFound = true;
   if(ruleType == 'C')
   {
      if((parseFloat(objForm.txtEscln.value) == 0 || objForm.txtEscln.value == '') && (parseFloat(objForm.txtDiscount.value) == 0 || objForm.txtDiscount.value == '') && (parseInt(objForm.txtTAT.value) == 0 || objForm.txtTAT.value == '') && objForm.chkFlowchange.checked == false && objForm.chkDefaultless.checked == false)
      {
         if(!objForm.txtindex.length)
         {
            if(objForm.txtindex.value == "")
            {
               alertMsgs(eCRDAtleastOneRule);
               return false;
            }
         }
         else
         {
            for(i=0; i<objForm.txtindex.length; i++)
            {
               if((objForm.txtindex[i].value == "") && (objForm.txtdepend[i].value ==""))
               {
                  alertMsgs(eCRDAtleastOneRule);
                  return false;
               }
            }
         }
      }
   }
   if(ruleType == 'C')
   {
      if(objForm.txtEscln.value == '' && objForm.chkFlowchange.checked == false && (parseFloat(objForm.txtDiscount.value) == 0 || objForm.txtDiscount.value == '') && objForm.chkDefaultless.checked == false && (parseInt(objForm.txtTAT.value) == 0 || objForm.txtTAT.value == ''))
      {
         if(!objForm.txtindex.length)
         {
            if(objForm.txtdepend.value == "" )
            {
               alertMsgs(eCRDDependency);
               objForm.txtdepend.focus();
               return false;
            }
         }
         else
         {
            for(i = 0; i < objForm.txtindex.length; i++)
            {
               strValue = objForm.txtindex[i].value;
               for(j = i+1; j < objForm.txtindex.length; j++)
               {
                  if(strValue == objForm.txtindex[j].value)
                  {
                     alertMsgs(eCRDDifferentIndex);
                     objForm.txtindex[j].focus();
                     objForm.txtindex[j].select();
                     return false;
                  }
               }
            }
            for(i = 0; i < objForm.txtdepend.length; i++)
            {
               if(objForm.txtdepend[i].value == null || objForm.txtdepend[i].value == '')
               {
                  alertMsgs(eCRDDependency+" in Row "+(i+1));
                  objForm.txtdepend[i].focus();
                  objForm.txtdepend[i].select();
                  return false;
               }
            }
         }
      }
      if(parseFloat(objForm.txtEscln.value) > 0)
      {
         if(!objForm.txtindex.length)
         {
            if(objForm.txtdepend.value != "" )
            {
               alertMsgs(eCRDEitherIndex);
               objForm.txtindex.focus();
               return false;
            }
         }
         else
         {
            for(i = 0; i < objForm.txtindex.length; i++)
            {
               strValue = objForm.txtindex[i].value;
               if(strValue != '')
               {
                  alertMsgs(eCRDEitherIndex);
                  objForm.txtindex[i].focus();
                  objForm.txtindex[i].select();
                  return false;
               }
            }
         }
      }
      if(objForm.chkFlowchange.checked == true)
      {
      				if(parseFloat(objForm.txtEscln.value) > 0 )
      				{
      								alertMsgs(eCRDAnyOneRule);
      								objForm.txtEscln.focus();
      								objForm.txtEscln.select();
      								return false;
      				}
      				else
      				{
      								if(!objForm.txtindex.length)
					         {
					            if(objForm.txtdepend.value != "" || objForm.txtindex.value != "")
					            {
					               alertMsgs(eCRDAnyOneRule);
					               objForm.txtindex.focus();
					               return false;
					            }
					         }
					         else
					         {
					            for(i = 0; i < objForm.txtindex.length; i++)
					            {
					               strValue = objForm.txtindex[i].value;
					               strDependValue = objForm.txtdepend[i].value;
		                  if(strValue != '' || strDependValue != '')
		                  {
		                     alertMsgs(eCRDAnyOneRule);
		                     objForm.txtindex[i].focus();
		                     objForm.txtindex[i].select();
		                     return false;
		                  }
					            }
					         }
      				}
      }
   }
   if(ruleType != 'C')
   {
      if((objForm.txtDiscount.value == "") && (objForm.txtTAT.value == ""))
      {
         alertMsgs(eCRDAtleastOneRule);
         return false;
      }
   }
   
   return true;
}