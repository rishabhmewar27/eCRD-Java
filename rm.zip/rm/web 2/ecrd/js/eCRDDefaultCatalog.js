function fnCreateBlankCatalog()
{	
	var objForm=document.objFormDefaultCatalog;
	var eng_Model=objForm.txtEngModel.value;
	var osb_Code=objForm.txtOSBCode.value;	
	var start_date_dd=objForm.sel_start_DD.options[objForm.sel_start_DD.selectedIndex].value;
	var start_date_mm=objForm.sel_start_MM.options[objForm.sel_start_MM.selectedIndex].value;
	var start_date_yy=objForm.sel_start_YY.options[objForm.sel_start_YY.selectedIndex].value;
	var end_date_dd=objForm.sel_end_DD.options[objForm.sel_end_DD.selectedIndex].value;
	var end_date_mm=objForm.sel_end_MM.options[objForm.sel_end_MM.selectedIndex].value;
	var end_date_yy=objForm.sel_end_YY.options[objForm.sel_end_YY.selectedIndex].value;
	var cat_Desc=objForm.txtCatDesc.value;	
	
	eng_Model=fnTrim(eng_Model);
	osb_Code=fnTrim(osb_Code);
	 
	if(eng_Model=="")
	 {
		alertMsgs(eCRDEngineModel);
		objForm.txtEngModel.focus();
		return;
	  }
	 
	 if(osb_Code=="")
	 {
		alertMsgs(eCRDOSBCode);
		objForm.txtOSBCode.focus();
		return;
	  }
	
	 if(start_date_dd=="" && start_date_mm="" start_date_yy="")
	 {
		alertMsgs(eCRDStartDate);
		objForm.start_date_dd.focus();
		return;
	 }
	if(end_date_dd=="" && end_date_mm="" end_date_yy="")
	 {
		alertMsgs(eCRDEndDate);
		objForm.end_date_dd.focus();
		return;
	 } 
     if(eng_Model != "")
     {            	
         if(fnCheckSplChars(objForm.txtEngModel) == false)
		{     	 
			objForm.txtEngModel.focus();
        	return;            
        }
     }
     
  	if(osb_Code != "")
     {            	
         if(fnCheckSplChars(objForm.txtOSBCode) == false)
        { 
        	objForm.txtOSBCode.focus();
		    return;             
		 }
     }
     alert("hiiiiiiiii");
     alert(objForm.txtCatDesc.value);
     if(objForm.txtCatDesc.value!='')
   {
	  var txtCatalogDescLength;
	txtCatalogDescLength=objForm.txtCatDesc.value.length;
	alert(txtCatalogDescLength);
	if(txtCatalogDescLength>100)
	   {
			alertMsgs(eCRDCatalogDesc);
			objForm.txtCatDesc.focus();
			return false;
		}


  }
	objForm.hdnEngineModel.value=objForm.txtEngModel.value;
	objForm.hdnScreenName.value = "eCRDDefaultCatalog";
	objForm.hdnScreenAction.value = "eCRDCreateBlankCatalog";
	objForm.submit();
}