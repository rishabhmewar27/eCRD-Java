function fnAddUserToGroup(rowcachedform)
{
       var count = 1;
	    var data = "";
         strGrp= getSelectedRadio(rowcachedform);   		
         if(strGrp=="")
         {
            alertMsgs(eCRDemptyGroup);
            return false;
         }

		for(count = 1; count < rowcachedform.elements.length; count++)
		{
			if(rowcachedform.elements[count].checked)
			{
				data = rowcachedform.elements[count].value ;
            brkIndex=data.indexOf('^')+1;
				groupCode=data.substring(0,brkIndex-1);
            data = data.substring(brkIndex);
				
             document.frmEmailGroup.hdnGroupCode.value=groupCode;
             document.frmEmailGroup.hdnGroupName.value=data;   
            document.frmEmailGroup.hdnScreenName.value="eCRDListUser";
            document.frmEmailGroup.hdnScreenAction.value="eCRDAddEmailInGrp";
            document.frmEmailGroup.submit();

         }
      }

}


  function fnAssociateEvent(rowcachedform)
  {
   
     var count = 1;
   	var data = "";

         strGrp= getSelectedRadio(rowcachedform);   		
         if(strGrp=="")
         {
            alertMsgs(eCRDemptyGroup);
            return false;
         }
		
		for(count = 1; count < rowcachedform.elements.length; count++)
		{
			if(rowcachedform.elements[count].checked)
			{
				data = rowcachedform.elements[count].value ;
            brkIndex=data.indexOf('^')+1;
				
				groupCode=data.substring(0,brkIndex-1);
            data = data.substring(brkIndex);
             document.frmEmailGroup.hdnGroupCode.value=groupCode;
             document.frmEmailGroup.hdnGroupName.value=data;   
            document.frmEmailGroup.hdnScreenName.value="eCRDListUser";
            document.frmEmailGroup.hdnScreenAction.value="eCRDAssociateEvent";
            document.frmEmailGroup.submit();

         }
      }
  }

  function fnDeleteGrp(rowcachedform)
  {
   
     var count = 1;
   	var data = "";

         strGrp= getSelectedRadio(rowcachedform);   		
         if(strGrp=="")
         {
            alertMsgs(eCRDemptyGroup);
            return false;
         }

      if (confirm(eCRDDeleteGroup))
      {      
            for(count = 1; count < rowcachedform.elements.length; count++)
            {
               if(rowcachedform.elements[count].checked)
               {
                  data = rowcachedform.elements[count].value ;
                  brkIndex=data.indexOf('^')+1;
                  
                  groupCode=data.substring(0,brkIndex-1);
                  data = data.substring(brkIndex);
                   document.frmEmailGroup.hdnGroupCode.value=groupCode;
                  document.frmEmailGroup.hdnScreenName.value="eCRDListUser";
                  document.frmEmailGroup.hdnScreenAction.value="eCRDDeleteGroup";
                  document.frmEmailGroup.submit();
               }
            }
      }
  }


function fnCreateGroup(objForm)
{
   
var groupName=fnTrim(objForm.txtGrpName.value);
if(groupName==null||groupName=="")
   {
		alertMsgs(eCRDempty+"Group Name");
		objForm.txtGrpName.select();
		objForm.txtGrpName.focus();
		return false;            

   }
    if(fnCheckSplChars(objForm.txtGrpName) == false)
	 { 
		alertMsgs(eCRDSpecialChars);
		objForm.txtGrpName.select();
		objForm.txtGrpName.focus();
		return false;            
	 }

   else
      {
      objForm.hdnGroupName.value=objForm.txtGrpName.value;
      objForm.hdnScreenName.value= "eCRDListUser";
      objForm.hdnScreenAction.value="eCRDCreateEmailGroup";
      objForm.submit();
   }

}

  function frmAddEvent()
  {
  
//     var flag=document.frmAssociateEvent.hdnFlag.value;
     //alert(document.frmAssociateEvent.hdnRsSize.value)
     //alert(document.frmAssociateEvent.hdnGroupCode.value)
     //alert(document.frmAssociateEvent.c3.checked)


   for(count = 0; count < document.frmAssociateEvent.elements.length; count++)
      {
         if(document.frmAssociateEvent.elements[count].checked == true)
         {
            document.frmAssociateEvent.hdnEvents.value = document.frmAssociateEvent.elements[count].name + "^" +document.frmAssociateEvent.hdnEvents.value;
         }
      }
    if(document.frmAssociateEvent.hdnEvents.value == "")
     {
         alertMsgs(eCRDSelect+" an Event to Associate with the Group");
         return false;
      }
      document.frmAssociateEvent.hdnScreenName.value="eCRDListUser";
     document.frmAssociateEvent.hdnScreenAction.value="eCRDAttachEvent";
     document.frmAssociateEvent.submit();
       
   }



//This function called when the user clicks find button for finding uder in Ldap
function fnFindEmailAddr()
{
   if(document.frmAddUserInGroup.txtFName.value == "" && document.frmAddUserInGroup.txtLName.value == "")
   {
  		alertMsgs(eCRDempty+" either First Name or Last Name ");
		return false;
   }      
      if(document.frmAddUserInGroup.txtLName.value == "")
      {
         if(document.frmAddUserInGroup.txtFName.value.length<3)
         {
            alertMsgs(eCRDEmailSearch);
            document.frmAddUserInGroup.txtFName.focus();
            return false;
         }
      } 
   if(document.frmAddUserInGroup.txtFName.value.indexOf("*")!=-1)
   {
        var strCheckFNameArray = document.frmAddUserInGroup.txtFName.value.split("*");
         if(strCheckFNameArray.length > 2 )
         {
            alertMsgs(eCRDWildCardTwice);
            document.frmAddUserInGroup.txtFName.focus();
            return false;
         }
   }
      if(document.frmAddUserInGroup.txtFName.value == "")
      {
         if(document.frmAddUserInGroup.txtLName.value.length<3)
         {
            alertMsgs(eCRDEmailSearch);
           document.frmAddUserInGroup.txtLName.focus();
          return false;
         }
      }
   if(document.frmAddUserInGroup.txtLName.value.indexOf("*")!=-1)
      {
         var strCheckLNameArray = document.frmAddUserInGroup.txtLName.value.split("*");
         if(strCheckLNameArray.length > 2 )
         {
            alertMsgs(eCRDWildCardTwice);
            document.frmAddUserInGroup.txtLName.focus();
            return false;
         }
      }
   
	            features='toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=620,height=350,title=LdapUser';
					dlg = window.open (basePath+"/ecrd?hdnScreenName=eCRDListUser&hdnScreenAction=eCRDSearchUserForGroup&txtFName="+document.frmAddUserInGroup.txtFName.value+"&txtLName="+document.frmAddUserInGroup.txtLName.value+"&hdnRandom="+Math.random(),'Search_User',features);    
					dlg.focus();			                     
   
}

//This function called when the user clicks Add to Gruop button for adding the email to Group
function fnAddEmailToGroup()
   {
      var EmailId=document.frmAddUserInGroup.txtEmail;
      if(EmailId.value=="")
      {
         alertMsgs(eCRDempty+" Email Address");
     		return false;
      }
      else if(!fnvalidEmail(EmailId))
      {
     		return false;
      }
      else
      {
      document.frmAddUserInGroup.hdnEmail.value=document.frmAddUserInGroup.txtEmail.value;
      document.frmAddUserInGroup.hdnScreenName.value="eCRDListUser";
      document.frmAddUserInGroup.hdnScreenAction.value="eCRDAddEmailInGroup";
      document.frmAddUserInGroup.submit();
      }
   }

//This function called close the pop up of search user page and populate the email into the email text box.
function fnAddInGroup(strFName,strLName,strEmail)
{

window.opener.document.frmAddUserInGroup.txtFName.value=strFName;
window.opener.document.frmAddUserInGroup.txtLName.value=strLName;
window.opener.document.frmAddUserInGroup.txtEmail.value=strEmail;
window.close();
}

//This function called to delete the user from the data base.
function  fnDeleteEmailFromGroup(strEmailAddress,strGroupCode)
{
      if (confirm(eCRDDeleteEmailUser))
      {      
      document.frmAddUserInGroup.hdnGroupCode.value=strGroupCode;
      document.frmAddUserInGroup.hdnEmail.value=strEmailAddress;
      document.frmAddUserInGroup.hdnScreenName.value="eCRDListUser";
      document.frmAddUserInGroup.hdnScreenAction.value="eCRDDeleteEmailFromGroup";
      document.frmAddUserInGroup.submit();
      }
}


function fnCancel()
{
	window.close();
}


//function to get the selected value of the radio button
function getSelectedRadio(rcForm)
{
   	
	var count = 1;
	var value = "";
		
		for(count = 1; count < rcForm.elements.length; count++)
		{
			if(rcForm.elements[count].checked)
			{
				value = rcForm.elements[count].value ;
			}

		}
		return value;
}