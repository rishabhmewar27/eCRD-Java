/*This file is added to Maintain Lookup Values in ECRD */
/*Added by Kumar (502321240) on 12-Jan-2016 */
function fnShowNewLookupType(objForm){
	objForm.hdnScreenAction.value = "eCRDShowNewLookupType";
	objForm.submit();	
}
function fnAddNewLookupType(objForm){
	var lookupType = objForm.txtECRDLookupType.value;	
	if(!lookupType){
		alert("Lookup type can't be empty.")
	}
	else{
	objForm.hdnScreenAction.value = "eCRDAddNewLookupType";
	objForm.submit();
	}
}
function fnAddNewLookupData(objForm){
	objForm.hdnECRDLookupData.value = objForm.txtECRDLookupData.value;
	objForm.hdnECRDLookupDesc.value = objForm.txtECRDLookupDesc.value;	
	objForm.hdnECRDLookupType.value = objForm.lstECRDLookupType.options[objForm.lstECRDLookupType.selectedIndex].value;	
	
	if(!objForm.hdnECRDLookupData.value && !objForm.hdnECRDLookupDesc.value && objForm.lstECRDLookupType.selectedIndex==0)
	{
		alert("Mandatory field can't be left blank");	
		return false;
	}else{
		if(!objForm.hdnECRDLookupData.value){
			alert("Lookup Data can't be empty.");
			return false;
		}
		//alert("Lookup Data: "+objForm.hdnECRDLookupData.value);
		if(!objForm.hdnECRDLookupDesc.value){
			alert("Lookup Description can't be empty.");
			return false;
		}
		//alert("Lookup Description: "+objForm.hdnECRDLookupDesc.value);
		if(objForm.lstECRDLookupType.selectedIndex==0){
			alert("Please select Lookup Type");
			return false;
		}
		//alert("Lookup Type: "+objForm.hdnECRDLookupType.value);		
	}
	//alert("validation done");
	objForm.hdnScreenAction.value = "eCRDAddNewLookupData";
	objForm.submit();
}

function fnViewLookupData(objForm){
	objForm.hdnECRDLookupData.value = objForm.txtECRDLookupData.value;
	objForm.hdnECRDLookupDesc.value = objForm.txtECRDLookupDesc.value;	
	objForm.hdnECRDLookupType.value = objForm.lstECRDLookupType.options[objForm.lstECRDLookupType.selectedIndex].value;	
	
	objForm.hdnScreenAction.value = "eCRDViewLookupData";
	objForm.submit();
}

function fnDeleteLookupData(){
	//alert(" inside fnDeleteLookupData ");
	//var lookupvalues = document.getElementsByName('chkLookupDataSelect');
	var objForm = null;
	var selValues = '';
	objForm = document.rowcachedform;
	//objForm.hdnCheckDeleteRows.value = objDeleteForm.chkLookupDataSelect.value;
	var chkLookupchecked = false;
	if(!objForm.chkLookupDataSelect.length)
	{
		if(objForm.chkLookupDataSelect.checked){
			chkLookupchecked = true;
			document.frmMaintainLookupData.hdnCheckDeleteRows.value = objForm.chkLookupDataSelect.value;
			selValues = objForm.chkLookupDataSelect.value + '$';
			//alert("selValues in if : "+selValues);		
			//alert("chkLookupDataSelect : "+objForm.chkLookupDataSelect.value);			
		}
	}
	else
	{
		for(var i=0;i<objForm.chkLookupDataSelect.length;i++)
		{			
			if(objForm.chkLookupDataSelect[i].checked){
				chkLookupchecked = true;
				//document.frmMaintainLookupData.hdnCheckDeleteRows[i].value = objForm.chkLookupDataSelect[i].value;
				selValues += objForm.chkLookupDataSelect[i].value + '$';
			//	alert("chkLookupDataSelect values: "+objForm.chkLookupDataSelect[i].value);
			//	alert("selValues in else : "+selValues);	
			}
		}
		document.frmMaintainLookupData.hdnCheckDeleteRows.value = selValues;
	}
	if(!chkLookupchecked){
		alert("Please select atleast one record to delete");
		return false;
	}
	objForm = document.frmMaintainLookupData;
	//objForm.hdnCheckDeleteRows.value = document.rowcachedform.chkLookupDataSelect.value;
	objForm.hdnScreenAction.value = "eCRDDeleteLookupData";
	objForm.hdnScreenName.value = "MaintainLookupValues";
	objForm.submit();
}

function fnSelectAll(objForm)
{
	if(!objForm.chkLookupDataSelect.length)
	{
		objForm.chkLookupDataSelect.checked = true;
	}
	else
	{
		for(var i=0;i<objForm.chkLookupDataSelect.length;i++)
		{
			objForm.chkLookupDataSelect[i].checked=true;
		}
	}
}

function fnResetAll(objForm)
{
	if(!objForm.chkLookupDataSelect.length)
	{
		objForm.chkLookupDataSelect.checked = false;
	}
	else
	{
		for(var i=0;i<objForm.chkLookupDataSelect.length;i++)
		{
			objForm.chkLookupDataSelect[i].checked=false;
		}
	}
}

function fnEdit(strLookupData,strLookupDesc,strLookupType){
	//document.frmMaintainLookupData.hdnScreenAction.value = "eCRDShowModifyLookupData";
	
	document.frmMaintainLookupData.hdnECRDLookupData.value = strLookupData;
	document.frmMaintainLookupData.hdnECRDLookupDesc.value = strLookupDesc;
	document.frmMaintainLookupData.hdnECRDLookupType.value = strLookupType;
	document.frmMaintainLookupData.hdnScreenAction.value = "eCRDShowModifyLookupData";
	document.frmMaintainLookupData.submit();
}

function fnModifyLookupData(objForm){
	objForm.hdnScreenAction.value = "eCRDModifyLookupData";	
	objForm.hdnECRDLookupDataNew.value = objForm.txtECRDLookupData.value;
	objForm.hdnECRDLookupDescNew.value = objForm.txtECRDLookupDesc.value;	
	objForm.hdnECRDLookupTypeNew.value = objForm.lstECRDLookupType.options[objForm.lstECRDLookupType.selectedIndex].value;	
	
	if(!objForm.hdnECRDLookupDataNew.value && !objForm.hdnECRDLookupDescNew.value && objForm.lstECRDLookupType.selectedIndex==0)
	{
		alert("Mandatory field can't be left blank");	
		return false;
	}else{
		if(!objForm.hdnECRDLookupDataNew.value){
			alert("Lookup Data can't be empty.");
			return false;
		}
		if(!objForm.hdnECRDLookupDescNew.value){
			alert("Lookup Description can't be empty.");
			return false;
		}	
		if(objForm.lstECRDLookupType.selectedIndex==0){
			alert("Please select Lookup Type");
			return false;
		}
			
	}
	objForm.submit();
}