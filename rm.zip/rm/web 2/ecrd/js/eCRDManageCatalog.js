function fnCheckForMandatory(objForm)
{
	sysDate = new Date();
	var eng_Code=fnTrim(objForm.txtEngCode.value);
	var eng_Desc=fnTrim(objForm.txtEngDesc.value);
	var cat_Desc=fnTrim(objForm.txtCatDesc.value);	

	if(eng_Code=="")
	 {
		alertMsgs(eCRDEngineCode);
		objForm.txtEngCode.focus();
		return false;
	  }
	
	if(eng_Code != "")
     	{            	
         if(fnCheckSplChars(objForm.txtEngCode) == false)
	 { 
		alertMsgs(eCRDSpecialChars);
		objForm.txtEngCode.select();
		objForm.txtEngCode.focus();
		return false;            
	 }
     	}
     
  	if(eng_Desc=="")
	 {		
		alertMsgs(eCRDEngineDescription);
		objForm.txtEngDesc.focus();
		return false;
	  }
	/* 5/5/2006 Patni For eCRD Phase I Enhancement Begin
	Added the validation for Catalog Description to be Not NULL*/
	if(fnTrim(objForm.txtCatDesc.value) == "")
	{
		alertMsgs(eCRDCatalogDescription);
		objForm.txtCatDesc.value = fnTrim(objForm.txtCatDesc.value);
		objForm.txtCatDesc.select();	
        objForm.txtCatDesc.focus();
		return false; 
	}
	/* 5/5/2006 Patni For eCRD Phase I Enhancement End
	Added the validation for Catalog Description to be Not NULL*/

	if(eng_Desc != "")
     	{            	
         	if(fnCheckSplChars(objForm.txtEngDesc) == false)
		{     	 
			alertMsgs(eCRDSpecialChars);
			objForm.txtEngDesc.select();
			objForm.txtEngDesc.focus();
			return false;            
		}
     	}
 
   if(objForm.sel_man_Startdate_DD.value=="" || objForm.sel_man_Startdate_MM.value=="" || objForm.sel_man_Startdate_YYYY.value=="")
   {

      alertMsgs(eCRDStartDate);
	  objForm.sel_man_Startdate_DD.focus();
      return false;
   }
   
   if(objForm.sel_man_Enddate_DD.value=="" || objForm.sel_man_Enddate_MM.value=="" || objForm.sel_man_Enddate_YYYY.value=="")
   {
      alertMsgs(eCRDEndDate);
      return false;
   }
 
   if(objForm.txtCatDesc.value!='')
   {
        var txtCatalogDescLength;
	txtCatalogDescLength=objForm.txtCatDesc.value.length;
	if(txtCatalogDescLength>100)
	{
		alertMsgs(eCRDCatalogDesc);
		objForm.txtCatDesc.focus();
		return false;
	}

  } 	

   if(cat_Desc != "")
    {            	
         if(fnCheckSplChars(objForm.txtCatDesc) == false)
        { 
           alertMsgs(eCRDSpecialChars);
            objForm.txtCatDesc.select();	
         	objForm.txtCatDesc.focus();
		    return false;             
		 }
     }
	with(objForm)
	{
		startDate = fnValidateCalenderDate(sel_man_Startdate_DD,sel_man_Startdate_MM,sel_man_Startdate_YYYY);
		endDate   = fnValidateCalenderDate(sel_man_Enddate_DD,sel_man_Enddate_MM,sel_man_Enddate_YYYY);
	
		if(fnCompareDateFromTo(sysDate,endDate))
		{
			alertMsgs(eCRDEffectiveEndDate);
			return false;
		}

		if(fnCompareDateFromTo(startDate,endDate))
		 {
			alertMsgs(eCRDDateMismatch);
			 return false;
		 }
		 
	}
   return true;
}

function fnValidateCalenderDate(dayDD,monthDD,yearDD)
{

   var dayVal = dayDD.options[dayDD.selectedIndex].value;
   var monthVal = monthDD.options[monthDD.selectedIndex].value;
   var yearVal = yearDD.options[yearDD.selectedIndex].value;
   var fullDateVal =yearVal+ "/" + monthVal + "/"  + dayVal ;
   return fullDateVal;
}


function fnCreateBlankCatalog()
{
	objForm=document.frmDefaultCatalog;
    if(fnCheckForMandatory(objForm)==true)
	{
		frmDefaultCatalog.hdnEngineCode.value=frmDefaultCatalog.txtEngCode.value;
		frmDefaultCatalog.hdnScreenName.value = "eCRDDefaultCatalog";
		frmDefaultCatalog.hdnScreenAction.value = "eCRDCreateBlankCatalog";
		frmDefaultCatalog.submit();
	}
}


function fnCatalogList(basePath)
{
	objForm=document.frmDefaultCatalog;
	
	if(fnCheckForMandatory(objForm)==true)
	{    
		features = "toolbar=no,location=no,width=640,height=540,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,title=Catalog List";
		win = window.open (basePath+"/ecrd?hdnScreenName=eCRDDefaultCatalog&hdnScreenAction=eCRDGetDefaultCatalogList","",features);    
		win.focus();		
	}
}
	
function fnCancel()
{
	window.close();		

}



function fnSelCatalog()
{
//	objForm=document.frmCatalogList;	
	strCatalog = getSelectedRadio(document.rowcachedform);
		 
	if(strCatalog == "")
	{
		alertMsgs(eCRDSelEngModel);
		return;
	}
	else
	{
		frm = window.opener.document.frmDefaultCatalog;
		frm.hdnEngData.value = strCatalog;
		frm.hdnScreenName.value="eCRDDefaultCatalog";
		frm.hdnScreenAction.value="eCRDCopyDefaultCatalog";
		window.opener.frmDefaultCatalog.submit();
		window.close();
	}
}

var features;



function fnCreateModuleSubmit()
{

   
document.frmCreateNewModule.txtEngModName.value=fnTrim(document.frmCreateNewModule.txtEngModName.value);
    if ((document.frmCreateNewModule.txtEngModName.value == null) || 
      (document.frmCreateNewModule.txtEngModName.value == ""))
   {

       alertMsgs(eCRDEngineModule);
      document.frmCreateNewModule.txtEngModName.focus();
   }

  else if (!fnCheckSplChars(document.frmCreateNewModule.txtEngModName))
   {
       alertMsgs(eCRDSpecialChars);

      document.frmCreateNewModule.txtEngModName.focus();
   }
   else
   {

   window.opener.frmManageEngModule.hdnCreateModuleName.value=document.frmCreateNewModule.txtEngModName.value;  
   window.opener.frmManageEngModule.hdnScreenName.value="eCRDDefaultCatalog";
  window.opener.frmManageEngModule.hdnScreenAction.value="eCRDCreateModule";
   window.opener.frmManageEngModule.submit();
   window.close();
   }
}

//function for pop up  window for create Module
function fnpopCreateModule(basePath,strEngModelCode)
{
   var strEngModelCode=strEngModelCode;

  
features='toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=no,width=500,height=300';
	dlg = window.open 
(basePath+"/ecrd?hdnScreenName=eCRDDefaultCatalog&hdnScreenAction=CreateModule&hdnEngModelCode="+strEngModelCode+"&RandomValue="+Math.random(),"Dialog",features);
}

//function for pop up  window for modify Module
function fnpopModifyModule(basePath)
{

   
features='toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=no,width=500,height=300';
dlg = window.open (basePath+"/ecrd?hdnScreenName=eCRDDefaultCatalog&hdnScreenAction=ModifyModule&RandomValue="+Math.random(),"Dialog",features);    
}

//function to validate the Modify Module Page.It includes validation for no values inserted in the Module Description text box.
function fnModifyModuleSubmit()
{
      
document.frmModifyModule.txtEngModName.value=fnTrim(document.frmModifyModule.txtEngModName.value);

    if ((document.frmModifyModule.txtEngModName.value == null) || 
      (document.frmModifyModule.txtEngModName.value == ""))
   {

       alertMsgs(eCRDEngineModule);
      document.frmModifyModule.txtEngModName.focus();
   }

  else if (!fnCheckSplChars(document.frmModifyModule.txtEngModName))
   {
       alertMsgs(eCRDSpecialChars);
        document.frmModifyModule.txtEngModName.value = "";
      document.frmModifyModule.txtEngModName.focus();
   }
   else
   {

   
window.opener.frmManageEngModule.hdnModifyModuleName.value=document.frmModifyModule.txtEngModName.value;

  
   window.opener.frmManageEngModule.hdnScreenName.value="eCRDDefaultCatalog";
   window.opener.frmManageEngModule.hdnScreenAction.value="eCRDModifyModule";
   window.opener.frmManageEngModule.submit();
   window.close();


   self.close();
   }
}


//function to delete the modules selected in the table to add to the Engine model.
function fnSelectEngineModule(strModSeqID,strModName,basePath)
{
  var strModName=strModName;
  var strEngModCode=document.frmManageEngModule.hdnEngModelCode.value;

       document.frmManageEngModule.hdnModSeqID.value=strModSeqID;
  
     document.frmManageEngModule.hdnModifyModuleName.value=strModName;
      
    
features='toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=no,width=500,height=300';
	dlg = window.open (basePath+"/ecrd?hdnScreenName=eCRDDefaultCatalog&hdnScreenAction=ModifyModule&hdnModifyModuleName="+strModName+"&hdnModSeqID="+strModSeqID+"&hdnEngModelCode="+strEngModCode+"&RandomValue="+Math.random(),"Dialog",features);       
}

//function to delete the modules selected in the table.
function fnDelEngineModule()
{
  
     var strColDelimiter=	document.frmManageEngModule.hdnColDelimiter.value ;
 
	document.frmManageEngModule.hdnDelEngModule.value = getSelectedValues(document.rowcachedform.chkEngModule,strColDelimiter);

	if(document.frmManageEngModule.hdnDelEngModule.value == "")
	{
		alertMsgs(eCRDEngineModule+" to delete ");
		return;
	}
   if(confirm(eCRDConfirmModuleDeletion))
   {
   document.frmManageEngModule.hdnScreenName.value = "eCRDDefaultCatalog";
	document.frmManageEngModule.hdnScreenAction.value = "DeleteModules";
   document.frmManageEngModule.submit();
   }
}



function fnSubMergeRepair(objForm,strRowDelimiter)
{

      selcount=getSelectedCount(document.rowcachedform.chkIndRepair);
     
       if(selcount<2)
      {
         alert(eCRDMergeRepair);
         return ;
      }

   	objForm.hdnSelectedRepair.value = getSelectedVal(document.rowcachedform.chkIndRepair,strRowDelimiter);

	if(objForm.hdnSelectedRepair.value == "")
	{
		alertMsgs(eCRDRepair);
		return;
	}

    /*  alert(objForm.hdnSelectedRepair.value);
      alert("submit");*/
      objForm.hdnScreenName.value="eCRDCustCatalogHelper";
      objForm.hdnScreenAction.value="eCRDMergeSave";
      objForm.submit();	


}


function getSelectedCount(chkBox)
{
	var count = 0;
   var selcount=0;
	if (typeof chkBox.length == 'number')
	{
		for(count = 0; count < chkBox.length; count++)
		{
			if(chkBox[count].checked)
			{ 
            selcount++;
				
			}
		}
	}
	else
	{
		if(chkBox.checked)
			{
				selcount=1;
			}
	}
		return selcount;      
}


function fnSubSplitRepair(objForm)
{
	//alert('inside fnSubSplitRepair '	);
	strCust = getSelectedRadio(document.rowcachedform);   
	if(strCust == "")
	{
		alertMsgs(eCRDRepair);
		return;
	}
	
	frmSplitRepair.hdnSelectedRepair.value=strCust;
	//alert("submit of frmSplitRepair :"+frmSplitRepair.hdnSelectedRepair.value);
	frmSplitRepair.hdnScreenName.value="eCRDCustCatalogHelper";
	frmSplitRepair.hdnScreenAction.value="eCRDSPLITSAVE";
	frmSplitRepair.submit();

}
function getSelectedVal(chkBox,strRowDelimiter)

{
	var count = 0;
	var value = "";
   var strRowDelimiter=strRowDelimiter;

	if (typeof chkBox.length == 'number')
	{
		for(count = 0; count < chkBox.length; count++)
		{
			if(chkBox[count].checked)
			{ 
				value = value + chkBox[count].value + strRowDelimiter;
			}
		}
	}
	else
	{
		if(chkBox.checked)
			{
				value = chkBox.value + strRowDelimiter;
			}
	}
     
		return value;
      
}


//function to get selected values of checkboxes in a table.
function getSelectedValues(chkBox,strColDelimiter)

{
	var count = 0;
	var value = "";
   var strColDelimiter=strColDelimiter;

	if (typeof chkBox.length == 'number')
	{
		for(count = 0; count < chkBox.length; count++)
		{
			if(chkBox[count].checked)
			{
				value = value + strColDelimiter+ chkBox[count].value ;
			}
		}
	}
	else
	{
		if(chkBox.checked)
			{
				value = chkBox.value + strColDelimiter;
			}
	}

		return value;
}


function fnAddModules()
{
   var strColDelimiter=	document.frmManageEngModule.hdnColDelimiter.value ;

	document.frmManageEngModule.hdnSelectedModule.value = getSelectedValues(document.frmManageEngModule.chkAddModule,strColDelimiter);

	if(document.frmManageEngModule.hdnSelectedModule.value == "")
	{
		alertMsgs(eCRDEngineModule+" to Add");
		return;
	}
   
   document.frmManageEngModule.hdnScreenName.value = "eCRDDefaultCatalog";
	document.frmManageEngModule.hdnScreenAction.value = "AddModules";
   document.frmManageEngModule.submit();
}

function fnAddMessage()
{
  alertMsgs(eCRDModuleAdded);
   return;
}

function fnDelMessage()
{
  alertMsgs(eCRDModuleDeleted);
   return;
}

function fnValidateCustCatalog(objForm)
{
   sysDate = new Date();
   with(objForm)
   if(fnCheckForNullValues(objForm))
   {
      startDate = fnValidateCalenderDate(sel_man_Startdate_DD,sel_man_Startdate_MM,sel_man_Startdate_YYYY);
		endDate   = fnValidateCalenderDate(sel_man_Enddate_DD,sel_man_Enddate_MM,sel_man_Enddate_YYYY);
      defaultDate = hdnDefaultDate.value;

      if(!fnCompareDateFromTo(startDate,defaultDate))
      {
          alertMsgs(eCRDCustomerCatStartDate);
          return false;
      }
      if(fnCompareDateFromTo(startDate,endDate))
      {
          alertMsgs(eCRDDateMismatch);
          return false;
      }
	  if(fnCompareDateFromTo(sysDate,endDate))
      {
          alertMsgs(eCRDEffectiveEndDate);
          return false;
      }
      /*
      Added the validation for Catalog Number to be Not Null */
      /* 24/5/2006 Patni For eCRD Phase I Enhancement Begin
	  Added the validation for Catalog Number to be Not NULL,if
	  spaces are entered fnTrim is used.*/
      	
      if(fnTrim(txtCatalogNum.value) == '')
      {
      	alertMsgs(eCRDCatalogNumber);
      	txtCatalogNum.value = fnTrim(txtCatalogNum.value);
     /* 24/5/2006 Patni For eCRD Phase I Enhancement End
	  Added the validation for Catalog Number to be Not NULL,if
	  spaces are entered fnTrim is used.*/
      	txtCatalogNum.focus();
      	return false;
      }
      /*
     	Added the validation to prevent special characters frm being inserted.
      */
      if(!fnCheckSplChars(objForm.txtCatalogNum))
      {
      	alertMsgs(eCRDSpecialChars);
      	objForm.txtCatalogNum.select();
      	objForm.txtCatalogNum.focus();
      	return false;
      }      

	  /* 5/5/2006 Patni For eCRD Phase I Enhancement Begin
		Added the validation for Catalog Description to be Not NULL*/
	  if(fnTrim(objForm.txtCatalogDesc.value) == '')
      {
      	alertMsgs(eCRDCatalogDescription);
      	objForm.txtCatalogDesc.value = fnTrim(objForm.txtCatalogDesc.value);
      	txtCatalogDesc.focus();
      	return false;
      }
	  /* 5/5/2006 Patni For eCRD Phase I Enhancement End
	  Added the validation for Catalog Description to be Not NULL*/
      /*
     	Added the validation to prevent special characters frm being inserted.
      */
      if(!fnCheckSplChars(objForm.txtCatalogDesc))
      {
      	alertMsgs(eCRDSpecialChars);
      	objForm.txtCatalogDesc.select();
      	objForm.txtCatalogDesc.focus();
      	return false;
      }
	  if(txtCatalogDesc.value!='')
	   {
		  var txtCatalogDescLength;
		txtCatalogDescLength=txtCatalogDesc.value.length;
		if(txtCatalogDescLength>100)
		   {
				alertMsgs(eCRDCatalogDesc);
				txtCatalogDesc.focus();
				return false;
			}

	  }

		with(document.frmCreateCustCatalog)
                       {
                         strStartDate=fnValidateCalenderDate(sel_man_Startdate_DD,sel_man_Startdate_MM,sel_man_Startdate_YYYY);
                         strEndDate=fnValidateCalenderDate(sel_man_Enddate_DD,sel_man_Enddate_MM,sel_man_Enddate_YYYY);
                         if(!fnValidateDateString(strStartDate))
                          {
                            sel_man_Startdate_DD.focus();
                                 return false;
                          }
                           if(!fnValidateDateString(strEndDate))
                          { 
                              sel_man_Enddate_DD.focus();
                                 return false;
                          }
                       }
       if(objForm.hdnflag.value=="true")
         {
                if(objForm.txtContractNumber.length==null)
            {
                       objForm.txtContractNumber.value=fnTrim(objForm.txtContractNumber.value) ;
						   
						 if(objForm.txtContractNumber.value=="")
                         {
                                 alertMsgs(eCRDempty+" Contract Number"); 
                                 objForm.txtContractNumber.select();
                                 objForm.txtContractNumber.focus();
                                 return false;
                          }         
                        if(!fnCheckSplChars(objForm.txtContractNumber))
                                { 
                                   alertMsgs(eCRDSpecialChars);
                                    objForm.txtContractNumber.select();	
                                    objForm.txtContractNumber.focus();
                                  return false;             
                               }
                              
					objForm.txtContractDesc.value=fnTrim(objForm.txtContractDesc.value);                      
					 if(objForm.txtContractDesc.value=="")
                         {
                                 alertMsgs(eCRDempty+" Contract Description");
                                 objForm.txtContractDesc.select();
                                 objForm.txtContractDesc.focus();
                                 return false;
                          }
                          if(!fnCheckSplChars(objForm.txtContractDesc))
                          { 
                               alertMsgs(eCRDSpecialChars);
                                objForm.txtContractDesc.select();	
                                objForm.txtContractDesc.focus();
                              return false;             
                          }
						  if(objForm.txtContractDesc.value.length>100)
						  {
								alertMsgs(eCRDContractDesc);
								  return false;
						  }
                       with(document.frmCreateCustCatalog)
                       {
                         hdnCustStartDate.value=fnValidateCalenderDate(sel_man_Startdate_DD,sel_man_Startdate_MM,sel_man_Startdate_YYYY);
                         hdnCustEndDate.value=fnValidateCalenderDate(sel_man_Enddate_DD,sel_man_Enddate_MM,sel_man_Enddate_YYYY);
                       }

        
                  }
                   else
                    {
                          for(i=0; i<objForm.txtContractNumber.length; i++)
                               {
                              
                               if(objForm.txtContractNumber[i].value=="")
                                  {
                                    alertMsgs(eCRDempty+" Contract Number");
                                    objForm.txtContractNumber[i].select();
                                    objForm.txtContractNumber[i].focus();
                                    return false;
                                  }
                              if(!fnCheckSplChars(objForm.txtContractNumber[i]))
                                { 
                                   alertMsgs(eCRDSpecialChars);
                                    objForm.txtContractNumber[i].select();	
                                    objForm.txtContractNumber[i].focus();
                                  return false;             
                               }
                                  if(objForm.txtContractDesc[i].value=="")
                                  {
                                    alertMsgs(eCRDempty+" Contract Description");
                                    objForm.txtContractDesc[i].select();
                                    objForm.txtContractDesc[i].focus();
                                    return false;
                                  }
		                          if(!fnCheckSplChars(objForm.txtContractDesc[i]))
		                          { 
		                               alertMsgs(eCRDSpecialChars);
		                                objForm.txtContractDesc[i].select();	
		                                objForm.txtContractDesc[i].focus();
		                              return false;             
		                          }
								  if(objForm.txtContractDesc[i].value.length>100)
								  {
										alertMsgs(eCRDContractDesc);
										  return false;
								  }
                               with(document.frmCreateCustCatalog)
                                {
                                  hdnCustStartDate[i].value=fnValidateCalenderDate(sel_man_Startdate_DD,sel_man_Startdate_MM,sel_man_Startdate_YYYY);
                                  hdnCustEndDate[i].value=fnValidateCalenderDate(sel_man_Enddate_DD,sel_man_Enddate_MM,sel_man_Enddate_YYYY);
                                }
                                                     
                                }
                        }

                        return true;
    }
     else
    {
            
             alertMsgs(eCRDCustomer);
            
    }
   }
}

function fnCheckForNullValues(objForm)
{
  
   if(objForm.lstEngModel.selectedIndex==0)
   {
      alertMsgs(eCRDSelEngModel);
      objForm.lstEngModel.focus();
      return false;
   }
   if(objForm.sel_man_Startdate_DD.value == "" )
			 {
				alertMsgs(eCRDSelectDate+" for Start date");
				return false;
			 }
    if( objForm.sel_man_Startdate_MM.value == "" )
        {
				alertMsgs(eCRDSelectMonth+" for Start date");
				return false;
			 }
          if(objForm.sel_man_Startdate_YYYY.value == "")
             {
				alertMsgs(eCRDSelectYear+" for Start date");
				return false;
			 }
        
	if(objForm.sel_man_Enddate_DD.value == "" )
			 {
				alertMsgs(eCRDSelectDate+" for End date");
				return false;
			 }
    if( objForm.sel_man_Enddate_MM.value == "" )
        {
				alertMsgs(eCRDSelectMonth+" for End date");
				return false;
			 }
          if(objForm.sel_man_Enddate_YYYY.value == "")
             {
				alertMsgs(eCRDSelectYear+" for End date");
				return false;
			 }

   return true;
}

//function to convert a date in proper format.
 function fnValidateCalenderDate(dayDD,monthDD,yearDD)
{

  var dayVal = dayDD.options[dayDD.selectedIndex].value;
   var monthVal = monthDD.options[monthDD.selectedIndex].value;
   var yearVal = yearDD.options[yearDD.selectedIndex].value;
    var fullDateVal =monthVal + "/" +dayVal + "/"  +yearVal  ;
    return fullDateVal;
}

function fnChangeComponent(objForm)
{
   var i=1;
   if(objForm.lstEngineModule.selectedIndex==0	)
   {
   	while(i < objForm.lstComponent.length )
	{
	    objForm.lstComponent.options[1] = null;
	}
   }
   else
   {
	   objForm.hdnEngineModule.value=objForm.lstEngineModule.options[objForm.lstEngineModule.selectedIndex].value;
	   objForm.hdnScreenName.value="eCRDCustCatalogHelper";
	   objForm.hdnScreenAction.value="eCRDMergeRepair";
	   objForm.submit();	
   }
}



//function to pop a window to display create new module page
function fnpopCustTable(basePath)
{
	if(document.frmModifyCatalog!=null)
	{
			objForm=document.frmModifyCatalog;
	}
	else if(document.frmCreateCustCatalog!=null)
	{
			objForm=document.frmCreateCustCatalog;
	}
	else if(document.frmComponentYearlyCatalog != null)
	{
			objForm = document.frmComponentYearlyCatalog;
	} 
	else if(document.frmSearchCatalog != null)
	{
		objForm = document.frmSearchCatalog;
	} 
	else if(document.frmPriceListChangesYearly != null)
	{
		objForm = document.frmPriceListChangesYearly;
	} 
	/** Start Adding for Security Checks*/
   if(!fnCheckSplChars(objForm.txtCustCode)){
 	   alertMsgs(eCRDSpecialChars);
	   return false;
   }
   /** End Here*/	
   if(objForm.txtCustCode.value.length<3)
   {
       alertMsgs(eCRDBlankCustomer);
       objForm.txtCustCode.select();
       objForm.txtCustCode.focus();
       return false;  
   }

   var strFindCust=objForm.txtCustCode.value;
   var strActive='';
   if(objForm.hdnOnlyActive!=null)
   {
   	strActive=objForm.hdnOnlyActive.value;
   }
   features='toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,width=620,height=400';
   dlg = window.open (basePath+"/ecrd?hdnScreenName=eCRDCustCatalogHelper&hdnScreenAction=CustomerTable&hdnCustomerName="+strFindCust+"&hdnOnlyActive="+strActive+"&RandomValue="+Math.random(),"Dialog",features);
}







//function to get the selected value of the radio button
function getSelectedRadioValue(radio)
{
   	var count = 1;
	var value = "";
		for(count = 1; count < radio.length; count++)
		{
			if(radio[count].checked)
			{
				value = radio[count].value ;
			}
		}
		return value;

}

function fnSaveVal(strCustContractCode)
{
      
         document.frmCreateCustCatalog.hdnCustContractName.value=strCustContractCode;
}

//function to display a new table in the same jsp to  add a customer 
function fnAddCustomerList(strCustCode)
{
   if(document.frmModifyCatalog==null)
	{
	objForm=document.frmCreateCustCatalog;
	}
	else if(document.frmCreateCustCatalog==null)
	{
	objForm=document.frmModifyCatalog;
	}

        
            if(objForm.hdnCustCode.value=="")
            {
                  alertMsgs(eCRDFindCust);
                  return;
            }
    
          objForm.hdnAddDelCust.value="AddCust";
		  
         objForm.hdnCustomerName.value=objForm.txtCustCode.value;

         if(objForm.hdnflag.value=="true")
         {
          
			  
            if(objForm.txtContractNumber.length==null)
            {
                         if(objForm.txtContractNumber.value=="")
                         {
                                 alertMsgs(eCRDempty+" Contract Number");
                                 objForm.txtContractNumber.select();
                                 objForm.txtContractNumber.focus();
                                 return false;
                          }

                             if(!fnCheckSplChars(objForm.txtContractNumber))
                                { 
                                   alertMsgs(eCRDSpecialChars);
                                    objForm.txtContractNumber.select();	
                                    objForm.txtContractNumber.focus();
                                  return false;             
                               }

                         if(objForm.txtContractDesc.value=="")
                         {
                                 alertMsgs(eCRDempty+" Contract Description");
                                 objForm.txtContractDesc.select();
                                 objForm.txtContractDesc.focus();
                                 return false;
                          }
          
					
                       
                  }
          else
            {
			  
                          for(i=0; i<objForm.txtContractNumber.length; i++)
                               {
                        
                               if(objForm.txtContractNumber[i].value=="")
                                  {
                                    alertMsgs(eCRDempty+" Contract Number");
                                    objForm.txtContractNumber[i].select();
                                    objForm.txtContractNumber[i].focus();
                                    return false;
                                  }
                                if(!fnCheckSplChars(objForm.txtContractNumber[i]))
                                { 
                                   alertMsgs(eCRDSpecialChars);
                                    objForm.txtContractNumber[i].select();	
                                    objForm.txtContractNumber[i].focus();
                                  return false;             
                               }

                                  if(objForm.txtContractDesc[i].value=="")
                                  {
                                    alertMsgs(eCRDempty+" Contract Description");
                                    objForm.txtContractDesc[i].select();
                                    objForm.txtContractDesc[i].focus();
                                    return false;
                                  }
                   
    
                                                 
                  }
            }
                             
             
        }
		
       if(objForm.name == "frmCreateCustCatalog")
		{
             fnRetainVal();
   		  objForm.hdnScreenName.value="eCRDCustCatalogHelper";
           objForm.hdnScreenAction.value="eCRDAddDelCust";   
		}
		else
	{
			
         objForm.hdnScreenAction.value="eCRDAddCustomers";
	}
         objForm.submit(); 
		   
}

function fnSplitRepair(objForm)
{
	if(objForm.lstEngineModule.selectedIndex==0)
	{
		alertMsgs(eCRDSelEngModule);
		return;
	}
	if(objForm.lstComponent.selectedIndex==0)
	{
		alertMsgs(eCRDComponentLevel);
		return;
	}
	objForm.hdnEngineModule.value=objForm.lstEngineModule.options[objForm.lstEngineModule.selectedIndex].value;
	objForm.hdnComponent.value=objForm.lstComponent.options[objForm.lstComponent.selectedIndex].value;
	objForm.hdnScreenName.value="eCRDCustCatalogHelper";
	objForm.hdnScreenAction.value="eCRDSplitRepairTable";
	objForm.submit();
}

function fnMergeRepair(objForm)
{
	if(objForm.lstEngineModule.selectedIndex==0)
	{
		alertMsgs(eCRDSelEngModule);
		return;
	}
	if(objForm.lstComponent.selectedIndex==0)
	{
		alertMsgs(eCRDComponentLevel);
		return;
	}
      
	objForm.hdnEngineModule.value=objForm.lstEngineModule.options[objForm.lstEngineModule.selectedIndex].value;
	objForm.hdnComponent.value=objForm.lstComponent.options[objForm.lstComponent.selectedIndex].value;
	objForm.hdnScreenName.value="eCRDCustCatalogHelper";
	objForm.hdnScreenAction.value="eCRDMergeRepairTable";
	objForm.submit();
}

//function to retain all the values which were persent previously in the page
function fnRetainVal()
{
      
   
            document.frmCreateCustCatalog.hdnEngModelCode.value=document.frmCreateCustCatalog.lstEngModel.options[document.frmCreateCustCatalog.lstEngModel.selectedIndex].value;   
           document.frmCreateCustCatalog.hdnCatalogNum.value=document.frmCreateCustCatalog.txtCatalogNum.value;
           document.frmCreateCustCatalog.hdnCatalogDesc.value=document.frmCreateCustCatalog.txtCatalogDesc.value;

            document.frmCreateCustCatalog.hdnStartDate_DD.value=document.frmCreateCustCatalog.sel_man_Startdate_DD.value;      
            document.frmCreateCustCatalog.hdnStartDate_MM.value=document.frmCreateCustCatalog.sel_man_Startdate_MM.value;
            document.frmCreateCustCatalog.hdnStartDate_YY.value=document.frmCreateCustCatalog.sel_man_Startdate_YYYY.value;
            document.frmCreateCustCatalog.hdnEndDate_DD.value=document.frmCreateCustCatalog.sel_man_Enddate_DD.value;
            document.frmCreateCustCatalog.hdnEndDate_MM.value=document.frmCreateCustCatalog.sel_man_Enddate_MM.value;
            document.frmCreateCustCatalog.hdnEndDate_YY.value=document.frmCreateCustCatalog.sel_man_Enddate_YYYY.value;

}




//function to collect all th values form the customer  catalog table and set the values.
function fnRetainAllVal(strStart_DD,strStart_MM,strStart_YY,strEndDate_DD,strEndDate_MM,strEndDate_YY,strCatalogNum,strCatalogDesc)
{ 
  

   document.frmCreateCustCatalog.sel_man_Startdate_DD.value=strStart_DD;
   document.frmCreateCustCatalog.sel_man_Startdate_MM.value=strStart_MM;
   document.frmCreateCustCatalog.sel_man_Startdate_YYYY.value=strStart_YY;
   document.frmCreateCustCatalog.sel_man_Enddate_DD.value=strEndDate_DD;
   document.frmCreateCustCatalog.sel_man_Enddate_MM.value=strEndDate_MM;   
   document.frmCreateCustCatalog.sel_man_Enddate_YYYY.value=strEndDate_YY;
   document.frmCreateCustCatalog.txtCatalogNum.value=strCatalogNum;
   document.frmCreateCustCatalog.txtCatalogDesc.value=strCatalogDesc;


}
 function fnSetFlag()
 {
  
    if(document.frmModifyCatalog==null)
	{
	objForm=document.frmCreateCustCatalog;
	}
	else if(document.frmCreateCustCatalog==null)
	{
	objForm=document.frmModifyCatalog;
	}
	
	
     objForm.hdnflag.value="true";

     
 }
 //function to delete customer from the page
function  fnDeleteCust(strCust,strCode)
{   if(document.frmModifyCatalog==null)
	{
	objForm=document.frmCreateCustCatalog;
	}
	else if(document.frmCreateCustCatalog==null)
	{
	objForm=document.frmModifyCatalog;
	}

     if(confirm(eCRDConfirmCustDeletion))
      {
               objForm.hdnAddDelCust.value="DelCust";
               objForm.hdnCustomerName.value=strCust;
               objForm.hdnCustCode.value=strCode;
               if(objForm.txtContractNumber.length==null)
               {

                     objForm.hdnflag.value="false";
               }
      

               if(objForm.name == "frmCreateCustCatalog")
               {
               fnRetainVal();
                 objForm.hdnScreenName.value="eCRDCustCatalogHelper";
                   objForm.hdnScreenAction.value="eCRDAddDelCust";
                   
               }
               else
                  {
                  
                        objForm.hdnScreenAction.value="eCRDAddCustomers";
                  }
               objForm.submit();
      }
       
}
//Function gets  the value of previous customer
function fnSetPreviousCustomer(strPrevCust)
{
   var strPrevCust=strPrevCust;
    document.frmCreateCustCatalog.hdnPreviousCustName.value=strPrevCust;
}
//function to clear text.
function fnClearCustCodeText()
{

	if(document.frmModifyCatalog==null)
	{
	objForm=document.frmCreateCustCatalog;
	}
	else if(document.frmCreateCustCatalog==null)
	{
	objForm=document.frmModifyCatalog;
	}

      objForm.txtCustCode.value="";
       
}





/* this is for the ViewModifyCatalog Screen*/
 function fnChkMandatory(form)	
	{
		var startDate;
		var endDate;
		with (form)
		 {
			
		   if(selEngModel.selectedIndex < 0)
			{
     		 alertMsgs(eCRDSelEngModel);
      		 return false;
			}
         
		if(sel_man_Startdate_DD.value != "" || sel_man_Startdate_MM.value != "" || sel_man_Startdate_YYYY.value != "")
      {
         if(sel_man_Startdate_DD.value == "" || sel_man_Startdate_MM.value == "" || sel_man_Startdate_YYYY.value == "")
         {
            alertMsgs(eCRDStartDate);
            sel_man_Startdate_DD.focus();
 				return false;		
         }
      }

  		if(sel_man_Enddate_DD.value != "" || sel_man_Enddate_MM.value != "" || sel_man_Enddate_YYYY.value != "")
      {
         if(sel_man_Enddate_DD.value == "" || sel_man_Enddate_MM.value == "" || sel_man_Enddate_YYYY.value == "")
         {
            alertMsgs(eCRDEndDate);
            sel_man_Enddate_DD.focus();
 				return false;		
         }
      }

		if(sel_man_Startdate_DD.value == "" || sel_man_Startdate_MM.value == "" || sel_man_Startdate_YYYY.value == "")
			 {
				startDate = "";
			 }
		else
			 {
				startDate = fnValidateCalenderDate(sel_man_Startdate_DD,sel_man_Startdate_MM,sel_man_Startdate_YYYY);
				if(!fnValidateDateString(startDate))
				{
					sel_man_Startdate_DD.focus();
					return false;		
				}
			 }
		if(sel_man_Enddate_DD.value == "" || sel_man_Enddate_MM.value == "" || sel_man_Enddate_YYYY.value == "")
			 {
							endDate   = "";
			 }
			else
				 {
							endDate   = fnValidateCalenderDate(sel_man_Enddate_DD,sel_man_Enddate_MM,sel_man_Enddate_YYYY);		
							if(!fnValidateDateString(endDate))
							{
								sel_man_Enddate_DD.focus();
								return false;		
							}
				 }

		

			
		if(fnCompareDateFromTo(startDate,endDate))
			 {
				alertMsgs(eCRDDateMismatch);
				return false;
				//sel_man_Enddate_DD.focus();
			 }
		/** Start Adding for Security Checks*/
		else if(!fnCheckSplChars(txtCatalogNum))
			{
				   alertMsgs(eCRDSpecialChars);
				   return false;
			}
		/** End Here*/
		else
		 {
			hdnStartDate.value		 = startDate;
			hdnEndDate.value		 = endDate;
			submit();

		 }
	 }
 }

function fnBack(objForm)
{
	with(objForm)
	{
		hdnScreenAction.value = "eCRDViewModifyCatlog";
		submit();
	}
}
function fnCompareDateFromTo(start,end)
{
    if ( Date.parse(start)>=Date.parse(end))
    {
         return true;
    }
    else
    {
       return false;
    }
}
/* 25/5/2006 Patni For eCRD Phase I Enhancement Begin
Added function to check Contract End Date to be less or equal to End date of Catalog*/
function fnCompareDateFromTo1(start,end)
{
    if ( Date.parse(start)>Date.parse(end))
    {
         return true;
    }
    else
    {
       return false;
    }
}
/* 25/5/2006 Patni For eCRD Phase I Enhancement End
Added function to check Contract End Date to be less or equal to End date of Catalog*/

/* this is for the ViewModifyCatalog Screen*/

/* this is for the ViewEngineCatalog Screen*/
function ModifyCatalog(form)
{
	with(form)
	form.action=basePath+"/ecrd";
	form.submit();
}
function fnSelectEngineModel( Catalog_Seq_Id,Catalog_Type)
{
	with(document.frmResultsEngineCatalog)
	{
		
		hdnCatalog_Seq_Id.value = Catalog_Seq_Id;
		hdnCatalogType.value    = Catalog_Type;
		submit();
	} 	
}


/* Ehren start */

function fnSelectEngineModelCSC(Catalog_Seq_Id,Catalog_Type, enginemodel)	
	 {
		var endDate = "";
		with (document.frmResultsEngineCatalog)
		{
		hdnCatalog_Seq_Id.value = Catalog_Seq_Id;
		hdnCatalogType.value    = Catalog_Type;			
		document.frmResultsEngineCatalog.hdnScreenAction.value = "eCRDCompListingAddModifyCSC";
		document.frmResultsEngineCatalog.action=basePath+"/ecrd";
		document.frmResultsEngineCatalog.submit();
		 }
    	}


function fndisplayDefaultComponentListing(form)
{
	with(form)
	if(selModule.selectedIndex == 0)
	{
		alertMsgs(eCRDSelEngModule);
		return false;
	}
	else
	{
		
		hdnScreenAction.value  ="eCRDDefaultComponentListingRC";
		submit();
	}
	
}

function fnSelectDefaultRepairComponent(componentCode,moduleSeqId)
{
	with(document.frmComponentListing)
	{
		hdnComponentCode.value = componentCode;
		hdnScreenAction.value  = "eCRDComponentToRepairListing";
		hdnScreenName.value = "ecrdListRepair";
		submit();
	}
}
/*Ehren end */

function fnSelectEngineModelForReport( Catalog_Seq_Id,Catalog_Type)
{
	with(document.frmResultsEngineCatalog)
	{
		
		hdnCatalog_Seq_Id.value = Catalog_Seq_Id;
		hdnCatalogType.value    = Catalog_Type;
      hdnScreenAction.value = "eCRDShowModuleForPriceListingReport";
   	submit();
	} 	
}

/* this is for the ViewEngineCatalog Screen*/

/* this is for the ModifyEngineCatalog Screen*/

/* Patni 23-May-2006 Begin Add Contract Start and End Date 
* New function to validate the dates and append 0 if day/month less than 9.
*/
function fnValidateDateString1(strDate)
{

	var daycount = 0,monthcount = 0,yearcount = 0;
	var strDate = strDate,strDay = '',strMonth = '',strYear = '';
	var bFound;
	var i,j,k;	
	arrDays 	= new Array(31,28,31,30,31,30,31,31,30,31,30,31);

	monthcount = 0;

	for ( j = 0;  j < strDate.length ; j++)
	{
		if ((strDate.substring(j,j+1) != '.') && (strDate.substring(j,j+1) != '/') && (strDate.substring(j,j+1) != '\\') && (strDate.substring(i,i+1) != '-'))

		{
			if (monthcount == 2)
			{ 
			    bFound = 0;
				break;	
			}			

			strMonth = strMonth + strDate.substring(j,j+1);
			monthcount = monthcount + 1;
		}

		else

		{
		    bFound = 1;
			break;
		}	

	}

	if (bFound == 1)

		j = j + 1;			

	daycount = 0;

	for ( i = j; i < strDate.length ; i++)

	{
		if ((strDate.substring(i,i+1) != '.') && (strDate.substring(i,i+1) != '/') && (strDate.substring(i,i+1) != '\\') && (strDate.substring(i,i+1) != '-'))

		{
			if (daycount == 2)

			{
				bFound = 0;
				break;
			}

			strDay = strDay + strDate.substring(i,i+1);
			daycount = daycount + 1;
		}
		else
		{
			bFound = 1;
			break;
		}				

	}			

	if (bFound == 1)
		i = i + 1;
	yearcount = 0;

	for ( k = i;  k <= strDate.length ; k++)

	{
		if ((strDate.substring(k,k+1) != '.') && (strDate.substring(k,k+1) != '/') && (strDate.substring(k,k+1) != '\\') && (strDate.substring(i,i+1) != '-'))

		{
			strYear = strYear + strDate.substring(k,k+1);
			yearcount = yearcount + 1;
		}

		else
		{
			break;
		}	
	}	

	if (strYear.length == 2)

	{
		if ((strYear >= 50) && (strYear <= 99))

		{
			strYear = '19' + strYear;
		}

		if ((strYear >= 00) && (strYear <= 49))

		{
			strYear = '20' + strYear;
		}
	}

	if (strDay.length == 1 )

	{
		strDay = '0' + strDay;
	}

	if (strMonth.length == 1 )

	{
		strMonth = '0' + strMonth;
	}
	
	if (strDay == 0 || strMonth == 0 || strYear== 0 )

	{
		alert ('Date should be in mm/dd/yyyy format');
		return false;
	}

	if (isNaN(strDay) || isNaN(strMonth) || isNaN(strYear))

	{
		alert ('Date should be in mm/dd/yyyy format');
		return false;
	}

	if (strMonth > 12)

	{
		alert ('Not have a Valid Month');
		return false;
	}

	if (strYear.length != 4) 

	{
		alert ('Year should be in yyyy format');
		return false;
	}			

	if (strMonth == 2)

	{
		if ( strYear%4 == 0)
      {
         if(strYear%100 == 0)
         {
            if(strYear%400==0)
            {
               	arrDays[strMonth  - 1] = 29;
            }
         }
         else
         {
            	arrDays[strMonth  - 1] = 29;
         }
      }
		
	}

	if (strDay > arrDays[strMonth  - 1])

	{
		alert('Number of days exceeded for the month');
		return false;	
	}

	strDate =  strMonth + '/' + strDay + '/' + strYear;
	
	return strDate;

}


function fnSaveCatalogDetails(form,startDate,Count)
{
var endDate   = null;
/* Patni 23-May-2006 Begin Add Contract Start and End Date */
var flag1= false;
var endDate1 =  null;
/* Patni 23-May-2006 End Add Contract Start and End Date */
 with (form)
	{	
	 			
		{
			
			if(sel_man_Enddate_DD.value == "" || sel_man_Enddate_DD.value == null || sel_man_Enddate_MM.value == "" || sel_man_Enddate_MM.value == null || sel_man_Enddate_YYYY.value ==null || sel_man_Enddate_YYYY.value ==null)
			{
				alertMsgs(eCRDEndDate);
				return false;
			}
			else
			{ 
				if(sel_man_Enddate_DD.options[sel_man_Enddate_DD.selectedIndex].value.length == 1){
				sel_man_Enddate_DD.options[sel_man_Enddate_DD.selectedIndex].value = "0"+sel_man_Enddate_DD.options[sel_man_Enddate_DD.selectedIndex].value;
				}
				if(sel_man_Enddate_MM.options[sel_man_Enddate_MM.selectedIndex].value.length == 1){
				sel_man_Enddate_MM.options[sel_man_Enddate_MM.selectedIndex].value = "0"+sel_man_Enddate_MM.options[sel_man_Enddate_MM.selectedIndex].value;
				}
			
			endDate   = fnValidateCalenderDate(sel_man_Enddate_DD,sel_man_Enddate_MM,sel_man_Enddate_YYYY);
				if(!fnValidateDateString(endDate))
				{
					sel_man_Enddate_DD.focus();
					return false;		
				}
			}
			if(fnCompareDateFromTo(startDate,endDate))
			 { 
				alertMsgs(eCRDDateMismatch);
				return false;
			}
			/*Patni changes 7/11/2007 start to chech if the Catalog Date is less than sysdate*/
			if(!fnValidateCatalogContractDate(endDate))
					{
						alert(eCRDCatalogDateMismatch);
						sel_man_Enddate_DD.focus();
						return false;
					}
			/*Patni Changes End-7/11/2007*/
			
			/* Patni 23-May-2006 Begin Add Contract Start and End Date */
			for(i=0; i<Count; i++)
                { 
		            var dd=eval("form.sel_man_Enddate_DD"+i);			
		            var mm=eval("form.sel_man_Enddate_MM"+i);
		            var yy=eval("form.sel_man_Enddate_YYYY"+i); 
		            /*Patni -- Begin -- 11/27/2007 -- Allow user to extend catalog without extending contract*/
		            var hdnCntrctDay = eval("form.hdnContractDay"+i);
		            var hdnCntrctMonth = eval("form.hdnContractMonth"+i);
		            var hdnCntrctYear = eval("form.hdnContractYear"+i);
					/*Satheesh Start1*/
					var catEndDD= eval("form.sel_man_Enddate_DD");
					var catEndMM= eval("form.sel_man_Enddate_MM");
					var catEndYY= eval("form.sel_man_Enddate_YYYY");
					/*Satheesh End1*/
		            /*Patni -- End -- 11/27/2007 -- Allow user to extend catalog without extending contract*/					
				     
		               if(dd.value == "" || dd.value == null || mm.value == "" || mm.value == null || yy.value ==null || yy.value ==null)
						{						
						alertMsgs(eCRDEndDate);
						dd.focus();
						return false;
					}
					else
					{
					endDate1   = fnValidateCalenderDate(dd,mm,yy);				
						if(!fnValidateDateString(endDate1))
						{
							dd.focus();
							return false;		
						}
					}
					if(fnCompareDateFromTo(startDate,endDate1))
					 {
						alertMsgs(eCRDDateMismatch);
						dd.focus();
						return false;
					}
				/*Patni -- Begin -- 11/27/2007 -- Allow user to extend catalog without extending contract*/
				//if(dd.value !=catEndDD.value || mm.value != catEndMM.value || yy.value != catEndYY.value )
				/*Satheesh Start2*/
				if(dd.value !=catEndDD.value || mm.value != catEndMM.value || yy.value != catEndYY.value )
				/*Satheesh End2*/	
				{
				/*Patni -- End -- 11/27/2007 -- Allow user to extend catalog without extending contract*/
/* 25/5/2006 Patni For eCRD Phase I Enhancement Begin
Added validation to check Contract End Date to be less or equal to End date of Catalog*/
					if(fnCompareDateFromTo1(endDate1,endDate))
					 {
						alertMsgs(eCRDContractDateMismatch);
						dd.focus();
						return false;
					}					
/* 25/5/2006 Patni For eCRD Phase I Enhancement End
Added validation to check Contract End Date to be less or equal to End date of Catalog*/
/*7/11/2007 Patni changes to check if Contract End Date is less than sysdate*/
					if(!fnValidateCatalogContractDate(endDate1))
					{
						alert(eCRDContractEndDateMismatch);
						dd.focus();
						return false;
					}
				}
/*Patni changes 7/11/2007 End*/
					endDate1=fnValidateDateString1(endDate1);
					// 31/05/2006 Patni Defect #62 Begin
					if(Count == 1)
					{
						form.CntrctEndDate.value=fnValidateDateString1(form.CntrctEndDate.value);
						if(form.CntrctEndDate.value!=endDate1)
						{
							flag1=true;
						}
						form.CntrctEndDate.value=endDate1;
					}else
					// 31/05/2006 Patni Defect #62 End
					{
						form.CntrctEndDate[i].value=fnValidateDateString1(form.CntrctEndDate[i].value);
						if(form.CntrctEndDate[i].value!=endDate1)
						{
							flag1=true;
						}
						form.CntrctEndDate[i].value=endDate1;
					}
                }
			/* Patni 23-May-2006 End Add Contract Start and End Date */
			if(hdnflag.value=="true")	
			{
				if(txtContractNumber.length == null)
				{
					txtContractNumber.value=fnTrim(txtContractNumber.value);
					if(txtContractNumber.value == "" || txtContractNumber.value == null)
					{
						alertMsgs(eCRDempty+" Contract Number"); 
						txtContractNumber.focus();
						return false;
					}
                        if(!fnCheckSplChars(form.txtContractNumber))
                                { 
                                   alertMsgs(eCRDSpecialChars);
                                    form.txtContractNumber.select();	
                                    form.txtContractNumber.focus();
                                  return false;             
                               }

					txtContractDesc.value=fnTrim(txtContractDesc.value);
					if(txtContractDesc.value == "" || txtContractDesc.value == null)
					{
						alertMsgs(eCRDempty+" Contract Description"); 
						txtContractDesc.focus();
						return false;
					}
                      if(!fnCheckSplChars(form.txtContractDesc))
                      { 
                           alertMsgs(eCRDSpecialChars);
                            form.txtContractDesc.select();	
                            form.txtContractDesc.focus();
                          return false;             
                      }
               		if(txtContractDesc.value.length > 100)
					{
						alertMsgs(eCRDContractDesc); 
						txtContractDesc.focus();
						return false;
					}
				}
				else
				{
                 for(i=0; i<form.txtContractNumber.length; i++)
                {                       
                     if(txtContractNumber[i].value == "" || txtContractNumber[i].value == null)
                     {
                        alertMsgs(eCRDempty+" Contract Number");
                        txtContractNumber[i].focus();
                        return false;
                     }
                      if(!fnCheckSplChars(form.txtContractNumber[i]))
                        { 
                           alertMsgs(eCRDSpecialChars);
                            form.txtContractNumber[i].select();	
                            form.txtContractNumber[i].focus();
                          return false;             
                       }
                     if(txtContractDesc[i].value == "" || txtContractDesc[i].value == null)
                     {
                        alertMsgs(eCRDempty+" Contract Description");
                        txtContractDesc[i].focus();
                        return false;
                     }
                      if(!fnCheckSplChars(form.txtContractDesc[i]))
                      { 
                           alertMsgs(eCRDSpecialChars);
                            form.txtContractDesc[i].select();	
                            form.txtContractDesc[i].focus();
                          return false;             
                      }
                     if(txtContractDesc[i].value.length > 100)
                     {
                        alertMsgs(eCRDContractDesc); 
                        txtContractDesc[i].focus();
                        return false;
                     }
                }
				}
			}
			
			hdnScreenAction.value = "eCRDUpdateEngineDetails";
			hdnEndDate.value = endDate;
			/*the  date from DB is coming in the format 02/03/2000 with 0 preceding  the month and day  if either is less than 10
			 to convert it to date without preceding 0s we call this fnc*/
			// alert(hdnPreviousEndDate.value);
			hdnPreviousEndDate.value = fnConvertDate(hdnPreviousEndDate.value);
			// alert(hdnPreviousEndDate.value);	
			/* 5/5/2006 Patni For eCRD Phase I Enhancement Begin
				Added the validation for Catalog Description to be Not NULL*/
			if(fnTrim(txtDesc.value) == "")
			{
				alertMsgs(eCRDCatalogDescription);
				txtDesc.value = fnTrim(txtDesc.value);
				txtDesc.focus();
				return false; 
			}
			/* 5/5/2006 Patni For eCRD Phase I Enhancement End
			Added the validation for Catalog Description to be Not NULL*/
	      /*
	     	Added the validation to prevent special characters frm being inserted.
	      */
	      if(!fnCheckSplChars(form.txtDesc))
	      {
	      	alertMsgs(eCRDSpecialChars);
	      	form.txtDesc.select();
	      	form.txtDesc.focus();
	      	return false;
	      }
			if(txtDesc.value!='')
				{
		  	var txtCatalogDescLength;
			txtCatalogDescLength=txtDesc.value.length;
			if(txtCatalogDescLength>100)
		   {
				alertMsgs(eCRDCatalogDesc);
				txtDesc.focus();
				return false;
			}
				}
			/** Patni 23-May-2006 Add Contract Start and End Date 
			 * Added another check in the below string for any change in contract end dates
			 * flag1
			*/	
			if(hdnflag.value=="true" || hdnPreviousEndDate.value != endDate || hdnPreviousDescription.value != txtDesc.value || flag1)
			{
				
				submit();
			}
			else
			{
				alertMsgs(eCRDNoChanges);
			}
			
		}
	}
}
/*conerts date of the form 02/03/2000 to 2/3/2000*/
function fnConvertDate(strEndDate)
{
			intMMIndex = strEndDate.indexOf("/");
			endDateMM = strEndDate.substring(0,intMMIndex);
			strEndDate = strEndDate.substring(intMMIndex+1,strEndDate.length);
			if(endDateMM.length>1 && parseInt(endDateMM) < 10)
			{
				endDateMM = endDateMM.substring(1,endDateMM.length);
			}
			intDDIndex = strEndDate.indexOf("/");
			endDateDD = strEndDate.substring(0,intDDIndex);
			if(endDateDD.length>1 && parseInt(endDateDD) < 10)
			{
				endDateDD = endDateDD.substring(1,endDateDD.length);
			}
			strEndDate = strEndDate.substring(intDDIndex+1,strEndDate.length);
			endDateYY = strEndDate;

			strEndDate = endDateMM + "/" +endDateDD + "/" +endDateYY;
			return strEndDate;
}

function fnModifycatalog(form)	
	 {
		var endDate = "";
		with (form)
		{
			
		
		/*	 if(sel_man_Enddate_DD.value == "" || sel_man_Enddate_MM.value == "" ,sel_man_Enddate_YYYY.value == "")
				 {
					alertMsgs(eCRDemptyEndDate);
					return false;
				 }
	
			else*/
			 {
		//		endDate   = fnValidateCalenderDate(sel_man_Enddate_DD,sel_man_Enddate_MM,sel_man_Enddate_YYYY);
				hdnScreenAction.value = "eCRDComponentListing";
				hdnEndDate.value = endDate;
				submit();
			 }
    	 }
	}


/* this is for the ModifyEngineCatalog Screen*/
/* this is for the ComponentListing Screen*/

function fndisplayComponentListing(form)
{
 with(form)
	 if(selModule.selectedIndex == 0)
	{
		alertMsgs(eCRDSelEngModule);
		return false;
	}
	else
	{
		
		hdnScreenAction.value  ="eCRDComponentListingRC";
		submit();
	}
	
}
/* this is for the ComponentListing Screen*/


/* this is for the AddComponent repair tab Screen*/





function fnAddCustomer(form)
{
  
      with(form)
	{
		var startDate;
		var endDate;
		if(txtCustCode.value=="")
	   {
			alertMsgs(eCRDemptyCustomer);
			return false;
	   }
	   else
		{
			
			hdnAddDelCust.value   = "AddCust";
			hdnCustomerName.value = txtCustCode.value;
			/*if(!fnValidateDate(document.form.txtStartDate))			
			{
				document.form.txtStartDate.select();
                document.form.txtStartDate.focus();
                return false;
			}
			if(!fnValidateDate(document.form.txtStartDate))			
			{
				document.form.txtStartDate.select();
                document.form.txtStartDate.focus();
                return false;
			}*/

			hdnScreenAction.value ="eCRDManageModifyCustomerCatalog";

			submit();
		}
	}
}






function  fnDeleteCustomer(strCust)
{

 with(document.frmModifyCatalog)
	{
	 hdnAddDelCust.value="DelCust";
	 hdnCustomerName.value = strCust;
     hdnScreenAction.value="eCRDManageModifyCustomerCatalog";
     submit();
	}
}

function fnpopUpCustTable(basePath)
{

	var strCustName = "";
	strCustName = document.frmModifyCatalog.txtCustCode.value;
	if(strCustName.length < 3)
	{
		 alertMsgs(eCRDBlankCustomer);
		 return false;
	}
    features='toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,width=700,height=400';
	dlg = window.open (basePath+"/ecrd?hdnScreenName=eCRDManageCatalogRowCacheHelper&hdnScreenAction=eCRDCustomerTable&hdnCustomerName="+strCustName+"&RandomValue="+Math.random(),"Dialog",features);

    
}
function getSelectedRadio(rcForm)
{
   	
	var count = 1;
	var value = "";
		
		for(count = 1; count < rcForm.elements.length; count++)
		{
			if(rcForm.elements[count].checked)
			{
				value = rcForm.elements[count].value ;
			}

		}
		return value;
}


function  fnCheckFind()
{
	if(document.frmModifyCatalog==null)
	{
	objForm=document.frmCreateCustCatalog;
	}
	else if(document.frmCreateCustCatalog==null)
	{
	objForm=document.frmModifyCatalog;
	}


   objForm.hdnCustCode.value="";

}

function fnSubmitCustTable(objectForm,STRCOLUMNDELIM)
{

	 if(window.opener.document.frmModifyCatalog!=null)
		{
					objForm=window.opener.document.frmModifyCatalog;
		}
		else if(window.opener.document.frmCreateCustCatalog!=null)
		{
					objForm=window.opener.document.frmCreateCustCatalog;
		}
		else if(window.opener.document.frmComponentYearlyCatalog!=null)
		{
					objForm=window.opener.document.frmComponentYearlyCatalog;
		}
	   else if(window.opener.document.frmSearchCatalog != null)
	   {
  				objForm = window.opener.document.frmSearchCatalog;
		} 
      else if(window.opener.document.frmPriceListChangesYearly != null)
	   {
  				objForm = window.opener.document.frmPriceListChangesYearly;
		}

   strCustCode = "";
   strCustName = "";
   if(objectForm==null)
   {
      alertMsgs(eCRDNoCustomer);
       return false;
   }
   strCust = getSelectedRadio(objectForm);   

   if(strCust=="")
   {
      alertMsgs(eCRDemptyCustomer);
      return false;
   }
	

      for(x=0;x<=strCust.length;x++)
   {

      if(strCust.substring(x,x+1)==STRCOLUMNDELIM)
      {
         break;
      }         
    }

	
        strCustCode = strCust.substring(0,x);
         strCustName = strCust.substring(x+1,strCust.length);
     objForm.hdnCustCode.value = strCustCode ;
				 objForm.txtCustCode.value = strCustName ;

				 //alert("inside managaecatalog.js");

      self.close();
} 

function fnCancel()
{
	      self.close();
}




function fnDeleteComponents(rcForm,STRCOLUMNDELIM,STRROWDELIM)
{
	var count = 1;
	var strInParam = "";
	for(count = 1; count < rcForm.elements.length; count++)
		{
			
			if(rcForm.elements[count].checked)
			{
						
					strInParam = strInParam + rcForm.elements[count].value + STRCOLUMNDELIM + STRROWDELIM ;
			}
			

		}

	if(strInParam == "" || strInParam == null)
	{
		alertMsgs(eCRDComponent);
		return false;
	}
	if(confirm(eCRDConfirmComponentDeletion))
    {
        
      
		document.frmComponentListing.hdnScreenAction.value	 = "eCRDDeleteComponent";
		document.frmComponentListing.hdnInParam.value		 = strInParam;
		document.frmComponentListing.submit();
	}
}


function fnSubmitCreateCustCatalog(objForm)
{

   if(fnValidateCustCatalog(objForm))
   {
       with(document.frmCreateCustCatalog)
         {
              hdnStartDate.value=fnValidateCalenderDate(sel_man_Startdate_DD,sel_man_Startdate_MM,sel_man_Startdate_YYYY);
              hdnEndDate.value=fnValidateCalenderDate(sel_man_Enddate_DD,sel_man_Enddate_MM,sel_man_Enddate_YYYY);
              hdnAddDelCust.value = 'AddCust';    
         }
      objForm.hdnScreenName.value="eCRDCustCatalogHelper";
      objForm.hdnScreenAction.value="eCRDCreateBlankCust";
      objForm.submit();
   }
}
    
  
function fnPopCopyCatalog(basePath,objForm)
{
   if(fnValidateCustCatalog(objForm))
   {
       with(objForm)
      {
           hdnStartDate.value=fnValidateCalenderDate(sel_man_Startdate_DD,sel_man_Startdate_MM,sel_man_Startdate_YYYY);
           hdnEndDate.value=fnValidateCalenderDate(sel_man_Enddate_DD,sel_man_Enddate_MM,sel_man_Enddate_YYYY);
           hdnAddDelCust.value = 'AddCust';
      } 
      objForm.hdnEngModelCode.value =  objForm.lstEngModel.options[objForm.lstEngModel.selectedIndex].value;
      objForm.hdnEngModelDesc.value =  objForm.lstEngModel.options[objForm.lstEngModel.selectedIndex].text;
      objForm.hdnScreenName.value="eCRDCustCatalogHelper";
      objForm.hdnScreenAction.value="eCRDCopyCatalog";
      objForm.submit();
//       features='toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=no,width=600,height=500,left=50,top=50';
//       dlg = window.open (basePath+"/ecrd?hdnScreenName=eCRDCustCatalogHelper&hdnScreenAction=eCRDCopyCatalog&hdnEngModelCode="+strModelCode+"&hdnEngModelDesc="+strModelDesc+"&RandomValue="+Math.random(),"Select_Catalog",features);
   }
}

function fnSelectComponent(strComponentCode)
{
	document.frmComponentListing.hdnScreenAction = "eCRDRepairListing";
	document.frmComponentListing.submit();
}
function fnLoadDetails(frm)
{
			var ruleCd = frm.drpdwn_Rule.options[frm.drpdwn_Rule.selectedIndex].value;
 //  frm.hdnRuleCd.value = frm.drpdwn_Rule.options[frm.drpdwn_Rule.selectedIndex].value;
//   if(ruleCd != 'C')
//   {
      frm.hdnScreenAction.value = 'eCRDLoadDetails';
      frm.submit();
//   }
}

function fnLoadComponents(frm)
{
//   alert(frm);
			var ruleCd = frm.drpdwn_Rule.options[frm.drpdwn_Rule.selectedIndex].value;
   var Year = frm.drpdwn_year.options[frm.drpdwn_year.selectedIndex].value;
   var ModuleCd = frm.drpdwn_Module.options[frm.drpdwn_Module.selectedIndex].value;
  // alert(frm.hdnRuleCd.value);
   if(ruleCd =='CO' || ruleCd == 'R')
   {
      ModuleCd = frm.drpdwn_Module.options[frm.drpdwn_Module.selectedIndex].value;
//      alert(frm.hdnModuleCd.value);
      frm.hdnScreenAction.value = 'eCRDLoadDetails';
      frm.submit();
   }
   
}

function fnLoadRepairs(frm)
{
   var ruleCd = frm.drpdwn_Rule.options[frm.drpdwn_Rule.selectedIndex].value;
   var ModuleCd = frm.drpdwn_Module.options[frm.drpdwn_Module.selectedIndex].value;
   var ComponentCd = frm.drpdwn_Component.options[frm.drpdwn_Component.selectedIndex].value;
   if(ruleCd =='R')
   {
      ComponentCd = frm.drpdwn_Component.options[frm.drpdwn_Component.selectedIndex].value;
      frm.hdnScreenAction.value = 'eCRDLoadDetails';
      frm.submit();
   }
}

function fnContinue(frm)
{
			var ruleCd = frm.drpdwn_Rule.options[frm.drpdwn_Rule.selectedIndex].value;	
   if(frm.drpdwn_year.options[frm.drpdwn_year.selectedIndex].value == '')
   {
      alert(eCRDYear);
      frm.drpdwn_year.focus();
      return false;
   }
   if(ruleCd == '')
   {
      alert(eCRDRuleType);
      frm.drpdwn_Rule.focus();
      return false;
   }
   else if(ruleCd == 'M')
   {
      if(frm.drpdwn_Module.options[frm.drpdwn_Module.selectedIndex].value == '')
      {
         alertMsgs(eCRDModuleLevel);
         frm.drpdwn_Module.focus();
         return false;
      }
   }
   else if(ruleCd == 'CO')
   {
      if(frm.drpdwn_Module.options[frm.drpdwn_Module.selectedIndex].value == '')
      {
         alertMsgs(eCRDModuleLevel);
         frm.drpdwn_Module.focus();
         return false;
      }
      if(frm.drpdwn_Component.options[frm.drpdwn_Component.selectedIndex].value == '')
      {
         alertMsgs(eCRDComponentLevel);
         frm.drpdwn_Component.focus();
         return false;
      }
   }
   else if(ruleCd == 'R')
   {
      if(frm.drpdwn_Module.options[frm.drpdwn_Module.selectedIndex].value == '')
      {
         alertMsgs(eCRDModuleLevel);
         frm.drpdwn_Module.focus();
         return false;
      }
      if(frm.drpdwn_Component.options[frm.drpdwn_Component.selectedIndex].value == '')
      {
         alertMsgs(eCRDComponentLevel);
         frm.drpdwn_Component.focus();
         return false;
      }
      if(frm.drpdwn_Repair.options[frm.drpdwn_Repair.selectedIndex].value == '')
      {
         alertMsgs(eCRDRepair);
         frm.drpdwn_Repair.focus();
         return false;
      }
   }
   frm.hdnScreenAction.value = "eCRDLoadContractualRules";
   frm.submit();
}


function fnSelectRepairComponent(componentCode,moduleSeqId)
{
	with(document.frmComponentListing)
	{
		hdnComponentCode.value = componentCode;
		hdnScreenAction.value  = "eCRDComponentToRepairListing";
		hdnScreenName.value = "ecrdListRepair";
		submit();
	}
}

function fnOpenCatalogPricing(objForm)
{
   objForm.hdnScreenName.value = "eCRDCustCatalogHelper";	
   objForm.hdnScreenAction.value = "eCRDComponentListing";
   objForm.submit();
}

function fnOpenRulesCriteria()
{
   document.frmCompRepairListing.hdnScreenName.value = "eCRDCustCatalogHelper";
   document.frmCompRepairListing.hdnScreenAction.value = "eCRDRulesCriteria";
   document.frmCompRepairListing.submit();
}

function fnBatchUploadDownLoad()
	{
		with(document.frmModifyCatalog)		
		{
			hdnScreenAction.value = "eCRDBatchDownLoadUpload";
			submit();
		}
	}

function fnShowMerge(objForm)
{
	objForm.hdnScreenName.value = "eCRDCustCatalogHelper";
	objForm.hdnScreenAction.value = "eCRDMergeRepair";
	objForm.hdnEngineModule.value="";
	objForm.hdnComponent.value="";
	objForm.submit();
}

function fnSplitModifyRepair(strRepSeqId)
{
	document.frmSplitRepair.hdnScreenName.value = "eCRDCustCatalogHelper";
	document.frmSplitRepair.hdnScreenAction.value = "eCRDSplitSelectForSave";
	document.frmSplitRepair.strRepairCode.value=strRepSeqId;
	document.frmSplitRepair.submit();
}
function fnSplit()
{
	if(document.frmSplitRepair.hdnAllRepsSaved.value=='Y')
	{
		document.frmSplitRepair.hdnScreenName.value = "eCRDCustCatalogHelper";
		document.frmSplitRepair.hdnScreenAction.value = "eCRDSplitIndSave";
		document.frmSplitRepair.submit();
	}
	else
	{
		alertMsgs(eCRDSaveAllSplit);
	}
}
function fnCreateSpecialforCust(objForm)
{
	objForm.hdnScreenName.value="eCRDCustCatalogHelper";
	objForm.hdnScreenAction.value="eCRDCreateSpeicalForCust";
	objForm.submit();
}
function fnSelectRepairComponentFromDefault(componentCode,moduleSeqId)
{
	with(document.frmComponentListing)
	{
		hdnComponentCode.value = componentCode;
		hdnScreenAction.value  = "eCRDComponentToRepairListingFromDefault";
		hdnScreenName.value = "eCRDManageCatalogRowCacheHelper";
		submit();
	}
}
function fnSelectAll(objForm)
{
	if(!objForm.chkRepairSelect.length)
	{
		objForm.chkRepairSelect.checked = true;
	}
	else
	{
		for(var i=0;i<objForm.chkRepairSelect.length;i++)
		{
			objForm.chkRepairSelect[i].checked=true;
		}
	}
}

function fnResetAll(objForm)
{
	if(!objForm.chkRepairSelect.length)
	{
		objForm.chkRepairSelect.checked = false;
	}
	else
	{
		for(var i=0;i<objForm.chkRepairSelect.length;i++)
		{
			objForm.chkRepairSelect[i].checked=false;
		}
	}
}
function fnAddRepairtoCSC(objForm)
{
	var chk = 0;
	if(!objForm.chkRepairSelect.length)
	{
		if(objForm.chkRepairSelect.checked == false)
		{
			alertMsgs(eCRDSelectRepair);
			return false;
		}
	}
	else
	{
		for(var i=0;i<objForm.chkRepairSelect.length;i++)
		{
			if(objForm.chkRepairSelect[i].checked==true)
			{
				chk++;
			}
		}
		if(chk == 0)
		{
			alertMsgs(eCRDSelectRepair);
			return false;
		}
	}
	objForm.hdnScreenAction.value = "eCRDAddRepairtoCSC";
	objForm.hdnScreenName.value = "ecrdListRepair";
	objForm.submit();
}
/*Begin-Patni Changes-7/11/2007-for validating the catalog end date greater that or equal to sysdate*/
function fnValidateCatalogContractDate(endDate)
{			
					currDate=new Date();
					sysDate=(currDate.getMonth()+1)+"/"+(currDate.getDate()+1)+"/"+currDate.getYear()
					if(Date.parse(endDate)<Date.parse(sysDate))
					{
						return false;

					}
					else
					{
						return true;
					}

}
/*End-Patni Changes-7/11/2007*/
