var repairEffdate = null;
var futureEffDate = null;
// Function for filling up the rows on the click of the Apply All button
function fnApplyAll()
{
	var frmObj = document.frmAddCompRepair;
	var count = document.frmAddCompRepair.hdnAddDelChk.value;
	alert(count);
	var i;
	i = parseInt(i);
	if(count ==1)
	{
		
	  	frmObj.txtMatCost.value =frmObj.txtApplyMatCost.value;
		frmObj.txtLabourHrs.value = frmObj.txtApplyLabourHrs.value;
	}
	else
	{
	for(i=0;i<count;i++)
	{
		frmObj.txtMatCost[i].value =frmObj.txtApplyMatCost.value;
		frmObj.txtLabourHrs[i].value = frmObj.txtApplyLabourHrs.value;
	}
	}
}


//Function to check whether all mandatory fields are filled
function fnValidate()
{
	var form = document.frmAddCompRepair;
	var strRefNo;
	var strRefFormat;
	var intHypPos;
	var strSpacePos;
	with(form)
	{
		if(description.value == "")
		{
			alert("Please Enter Repair Description value");
			return false;
		}
		
		if(isNaN(txtRepVol.value))
		{
			alert("Please Enter valid numeric Repair Volume");
			txttxtRepVol.focus();
			return;
					
		}
	
		if(lstRprRfr.selectedIndex == 0)
		{
			alert("Please Select Repair Reference from Drop down list");
			return false;
		}
		/*if(txtTurnAround.value == "")
		{
			alert("Please Enter Turn Around Time");
			
			return false;
		}*/
		if(isNaN(txtTurnAround.value))
		{
				alert("Please Enter valid numeric turn around time");
				txtTurnAround.focus();
				return;
			
		}
	
/*		if(txtPrice.value == "")
		{
			alert("Please Enter Price");
			return false;
		}*/
		
		if(isNaN(txtPrice.value))
		{
				alert("Please Enter valid numeric Price");
				txtPrice.focus();
				return;
					
		}
		
		if(txtRefNum.value == "")
		{
			alert("Please Enter Price");
			return false;
		}
		
		if(txtRefNum.value != "")
		{
			
		      strRefNo = txtRefNum.value;
		      strRefFormat = lstRprRfr.options[lstRprRfr.selectedIndex].value;
		      
		      
		}
		
		
		/*if(txtFutureTAT.value != "")
		{
			if(fnChkNumeral(txtFutureTAT)==false)
			{
				txtFutureTAT.focus();
				return;
			}
		}*/

		if(lstPriceType.selectedIndex == 0)
		{
			alert("Please Select Price Type from drop down");
			return false;
		}
	
		if(txtDisplaySeq.value == "")
		{
			alert("Please Enter Display Sequence number");
			return false;
		}
		/* Patni 29-May-2006 Begin Do not allow '0' in Display Seq Id*/	
		if(txtDisplaySeq.value == 0)
		{
			alert(eCRDDispSeqNonZero);
			txtDisplaySeq.focus();
			return false;
		}		
	    /* Patni 29-May-2006 End Do not allow '0' in Display Seq Id*/	
		//form.hdnrepairEffdate.value = repairEffdate;
		//form.hdnfutureEffDate.value = futureEffDate;
		
		form.hdnScreenAction.value = "CreateIndividualReapir";
	
		alert(form.hdnEngineModel.value);
		
		form.submit();
			
  	}
}
function fnReloadGroupedRepair()
{
	var form = document.frmAddCompRepair;
        if(form.lstRepairType.selectedIndex == 2)
	{
		form.hdnScreenAction.value = "GroupRepair";
		form.hdnGroupRepair.value = "True";
		form.submit();
		
	}
	else if(form.lstRepairType.selectedIndex == 1)
	{
		form.hdnScreenAction.value = "IndRepair";
		form.hdnGroupRepair.value = "false";
		form.submit();
	}
}

/*function getDate(dayDD,monthDD,yearDD)
{

   var dayVal = dayDD.options[dayDD.selectedIndex].value;
   var monthVal = monthDD.options[monthDD.selectedIndex].value;
   var yearVal = yearDD.options[yearDD.selectedIndex].value;
   var dayVal = dayDD.value;
   var monthVal = monthDD.value;
   var yearVal = yearDD.value;
    var fullDateVal =yearVal+ "/" + monthVal + "/"  + dayVal ;
    return fullDateVal;
	
}*/




function fnAddSites()
{
   
   var count = document.frmAddCompRepair.hdnAddDelChk.value;
   count = parseInt(count);
   alert(count);
   var form = document.frmAddCompRepair;   
   form.hdnAddDelChk.value = parseInt(document.frmAddCompRepair.hdnAddDelChk.value)+1;
   
  //if(count>1)
  //{
  	//form.txtMatCost[count-1].value =form.hdnMaterialCost[count-1].value;
  	//form.txtLabourHrs[count-1].value = form.hdnLaborHours[count-1].value;
  //}
	
  // form.hdnLaborHours.value = document.frmAddCompRepair.txtApplyLabourHrs.value;
   form.hdnScreenName.value="ecrdRepairDetail";
   form.hdnScreenAction.value = "AddSite";
    form.submit();
}



function fnSelectSite()
{
	var form = document.frmAddCompRepair; 
	var count = document.frmAddCompRepair.hdnAddDelChk.value;
	alert(count);
	count = parseInt(count);
	if(count==1)
	{
		form.txtLocLabourRate.value = form.hdnLaborRate.value;
		form.hdnSiteCode.value = form.lstSelectSite.options[form.lstSelectSite.selectedIndex].value;
	}
	else if(count>1)
	{
		form.txtLocLabourRate[count-1].value = form.hdnLaborRate[count-1].value;
		//form.txtMatCost[count-1].value =form.hdnMaterialCost.value;
		//form.txtLabourHrs[count-1].value = form.hdnLaborHours.value;
		//form.txtLocLabourRate[count-1].value = form.hdnLaborRate[count-1].value;
		form.hdnSiteCode.value = form.lstSelectSite[count-1].options[form.lstSelectSite[count-1].selectedIndex].value;
	}
	
	//form.hdnMaterialCost.value = form.txtMatCost.value;
	//form.hdnLaborHours.value = form.txtLabourHrs.value;
	//alert(form.txtLocLabourRate.value);
	//form.action = "/ess/ecrd?hdnScreenName=AddRepair&hdnScreenAction=getLocationRate";
	//form.submit();
	
}





function fnDelSites()
{
   var form = document.frmAddCompRepair;   	
   form.hdnAddDelChk.value = parseInt(form.hdnAddDelChk.value)-1;
   form.hdnMaterialCost.value = form.txtApplyMatCost.value;
   form.hdnLaborHours.value = form.txtApplyLabourHrs.value;
   form.hdnScreenName.value="ecrdRepairDetail";
   form.hdnScreenAction.value = "DelSite";
   form.submit();
}



function fnAddGrpSites()
{
   var form = document.frmAddCompRepair;  
   form.hdnAddDelGrpChk.value = parseInt(form.hdnAddDelGrpChk.value)+1;
   alert(form.hdnAddDelGrpChk.value);
   form.hdnMaterialCost.value = form.txtApplyMatCost.value;
   form.hdnLaborHours.value = form.txtApplyLabourHrs.value;
   form.hdnScreenName.value="ecrdRepairDetail";
   form.hdnScreenAction.value = "AddGroupSite";
   form.submit();
}


function fnDelGrpSites()
{
   var form = document.frmAddCompRepair;  	
   form.hdnAddDelGrpChk.value = parseInt(form.hdnAddDelGrpChk.value)-1;
   form.hdnMaterialCost.value = form.txtApplyMatCost.value;
   form.hdnLaborHours.value = form.txtApplyLabourHrs.value;
   form.hdnScreenName.value="ecrdRepairDetail";
   form.hdnScreenAction.value = "DelGroupSite";
   form.submit();
}

	function fnSaveRepair(objFrm)
	{
		with (objFrm)
		{
			/*if(txtTurnAround.value == "" || txtTurnAround.value == null)
			{
				alertMsgs(eCRDTurnAround);
				return false;
			}
			*/			
			if(selectPrice.options[selectPrice.selectedIndex].value == "")
			{
				alertMsgs(eCRDPriceType);
				return false;
			}
		
			/*if(txtPrice.value== "" || txtPrice.value == null)
			{

				alertMsgs(eCRDPrice);
				return false;
			}
			*/
			if(txtDispSequence.value== "" || txtDispSequence.value== null)
			{
				alertMsgs(eCRDDisplaySeq);
				return false;
			}
			/* Patni 29-May-2006 Begin Do not allow '0' in Display Seq Id*/	
			if(txtDispSequence.value == 0)
			{
				alert(eCRDDispSeqNonZero);
				txtDispSequence.focus();
				return false;
			}		
	    	/* Patni 29-May-2006 End Do not allow '0' in Display Seq Id*/
				
		}
	}

function fnLoadComponent(form)
{
	with(form)
	{
		hdnScreenName.value = "eCRDCustCatalogHelper";
		hdnScreenAction.value = "ecrdComponentTabs";
		submit();
	}
}

function fnChkComponent(form)
{
	with(form)
	{
		if(selEngineModule.selectedIndex == 0)
		{
			alertMsgs(eCRDemptyEngineModule);
		}
		else
			if(selComponent.selectedIndex == 0)
		{
			alertMsgs(eCRDemptyComponent);
		}
		else
		{
			submit;
		}
	}
}

function fnSpecialIndividualRepair(objForm)
{
	with(objForm)
	{
		hdnScreenName.value="ecrdRepairDetail";
		hdnScreenAction.value="eCRDAddSpecialGrpIndRepair";
		hdnRepairType.value="SI";
		submit();
	}
}

function fnSpecialGroupRepair(objForm)
{
	with(objForm)
	{
		hdnScreenName.value="ecrdRepairDetail";
		hdnScreenAction.value="eCRDAddSpecialGrpIndRepair";
		hdnRepairType.value="SG";
		submit();
	}
}
