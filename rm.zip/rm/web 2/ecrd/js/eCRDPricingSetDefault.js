
// object to contain message against input field name attribute
var nameValueMsgArr = new Object();
nameValueMsgArr.defaultEsc = "Default Escalation";
nameValueMsgArr.winLowLow = "Tech level value for matrix Low Tech Low";
nameValueMsgArr.winHighLow = "Tech level value for matrix Low Tech High";
nameValueMsgArr.winLowMed = "Tech level value for matrix Medium Tech Low";
nameValueMsgArr.winHighMed = "Tech level value for matrix Medium Tech High";
nameValueMsgArr.winLowHigh = "Tech level value for matrix High Tech Low";
nameValueMsgArr.winHighHigh = "Tech level value for matrix High Tech High";
nameValueMsgArr.lowWinPercentage = "Low Win Percentage";
nameValueMsgArr.saudiDiscount = "Saudi Discount";

/*
 * This method is called from 'set default all' screen at the time of save event.
 */
function fnSaveDefaults(objForm, action) {

	var isBlank = fnCheckInputFld(objForm.defaultEsc);
	if(!isBlank) isBlank = fnCheckInputFld(objForm.winLowLow);
	if(!isBlank) isBlank = fnCheckInputFld(objForm.winHighLow);
	if(!isBlank) isBlank = fnCheckInputFld(objForm.winLowMed);
	if(!isBlank) isBlank = fnCheckInputFld(objForm.winHighMed);
	if(!isBlank) isBlank = fnCheckInputFld(objForm.winLowHigh);
	if(!isBlank) isBlank = fnCheckInputFld(objForm.winHighHigh);
	if(!isBlank) isBlank = fnCheckInputFld(objForm.lowWinPercentage);

	if(!isBlank) {
		objForm.hdnScreenAction.value = action;
		objForm.submit();
		return true;
	} else {
		return false;
	}

}

/*
 * This method is called from 'set default engine line' screen at the time of save event.
 */
function fnSaveDefaultsForEngLn(objForm, action) {
	if(objForm.engineLine.options[objForm.engineLine.selectedIndex].text == "---Select---") {
		alert("Please select an engine line.");
		return false;
	} else {
		fnSaveDefaults(objForm, action);
	}

}

/*
 * This method is called from 'Add edit scenario' screen in case of re calculate scenario event.
 */
function fnSaveScenario(objForm, action) {

	if(!fnTrim(objForm.ScenarioName.value)) {
		alert("Please enter the scenario name");
		objForm.ScenarioName.focus();
		return false;
	} else if(!fnCheckSplChars(objForm.ScenarioName)) {
		alert("Please enter proper scenario name, without special characters.");
		objForm.ScenarioName.focus();
		return false;
	} else {

		var isBlank;
		if(objForm.defaultEscChkd.checked) {
			isBlank = fnCheckInputFld(objForm.defaultEsc);
		} else {
			if(!isBlank) isBlank = fnCheckInputFld(objForm.winLowLow);
			if(!isBlank) isBlank = fnCheckInputFld(objForm.winHighLow);
			if(!isBlank) isBlank = fnCheckInputFld(objForm.winLowMed);
			if(!isBlank) isBlank = fnCheckInputFld(objForm.winHighMed);
			if(!isBlank) isBlank = fnCheckInputFld(objForm.winLowHigh);
			if(!isBlank) isBlank = fnCheckInputFld(objForm.winHighHigh);
			if(!isBlank) isBlank = fnCheckInputFld(objForm.lowWinPercentage);
		}

		if(!isBlank) isBlank = fnCheckInputFld(objForm.saudiDiscount);

		if(!isBlank) {

			objForm.hdnScreenAction.value = action;
			objForm.submit();
			return true;
		} else {
			return false;
		}


	}
}

function fnDeleteScenario(objForm, action) {
	if (fnTrim(objForm.hdnScenarioId.value)) {
			objForm.hdnScreenAction.value = action;
			objForm.submit();
			return true;
	} else {
		alert("Please enter the scenario name");
		objForm.ScenarioName.focus();
		return false;
	}
}

function fnFinalizeScenario(objForm, action) {

	  var nextyear=new Date().getFullYear();
         nextyear=parseInt(nextyear)+1;

	 if (fnTrim(objForm.hdnScenarioId.value)) {

		 var isConfirmed = confirm(document.addEditScenarioForm.hdnFinalizeMsg.value);
		 if(isConfirmed){

         var futureDate=prompt("Enter Future Effective Date in format MM/DD/YYYY","01/01/"+nextyear);

       if(fn_checkDate(futureDate))
         {
          objForm.hdnFutureDate.value=futureDate;
         return fnSaveScenario(objForm, action);
         }
         else
         {
         	alert("Please Enter valid Future Effective Date");
             return false;
         }
		}
	} else {
		alert("Please enter the scenario name");
		objForm.ScenarioName.focus();
		return false;
	}
}

function fnCheckInputFld(inputFld) {
	if(!inputFld) {
		return false;
	}
	if (fnTrim(inputFld.value)) {
		if (isNaN(inputFld.value)) {
			alert(nameValueMsgArr[inputFld.name] + " should be a number.");
			inputFld.focus();
			return true;
		} else {
			return false;
		}
	} else {
		alert(nameValueMsgArr[inputFld.name] + " is blank.");
		inputFld.focus();
		return true;
	}
}

function fnOnEngLineChange(el) {
//	alert("inside fnOnEngLineChange(). " + el.value);

	var objForm = document.SetDefaultEngLineForm;
	objForm.hdnScreenAction.value = "eCRDPricingDefaultEngLnDataActn";
	objForm.hdnEngLine.value = el.value;
	objForm.submit();

}

function fnSvRepairDetails(form, action) {
	form.hdnScreenAction.value = action;
	if (fnTrim(form.manualOverrideEsc.value)) {
		form.submit();
	} else if (isNaN(form.manualOverrideEsc.value)) {
		alert("Manual Override Escalation value is not a number.");
		form.manualOverrideEsc.focus();
	} else {
		alert("Manual Override Escalation value is blank.");
		form.manualOverrideEsc.focus();
	}
}

function fnApplyRepairDetails(form, action) {
	form.hdnScreenName.value = "eCRDAddEditScenarioHelperScr";
	form.hdnScreenAction.value = action;
	if (fnTrim(form.manualOverrideEsc.value)) {
		form.submit();
	} else if (isNaN(form.manualOverrideEsc.value)) {
		alert("Manual Override Escalation value is not a number.");
		form.manualOverrideEsc.focus();
	} else {
		alert("Manual Override Escalation value is blank.");
		form.manualOverrideEsc.focus();
	}
}

function fnDisableEnableEscFields(form) {
	if (form.defaultEscChkd.checked) {
		form.defaultEsc.disabled=false;
		form.winLowLow.disabled=true;
		form.winHighLow.disabled=true;
		form.winLowMed.disabled=true;
		form.winHighMed.disabled=true;
		form.winLowHigh.disabled=true;
		form.winHighHigh.disabled=true;
		form.lowWinPercentage.disabled=true;

	} else {
		form.defaultEsc.disabled=true;
		form.winLowLow.disabled=false;
		form.winHighLow.disabled=false;
		form.winLowMed.disabled=false;
		form.winHighMed.disabled=false;
		form.winLowHigh.disabled=false;
		form.winHighHigh.disabled=false;
		form.lowWinPercentage.disabled=false;
	}
}


/**
 * To export scenario data in excel
 * @param form
 * @returns {Boolean}
 */
function fnExcelExport(form, basePath) {
	var isChanged = false;
	// To check checkbox value change
	isChanged = (form.defaultEscChkd.defaultChecked != form.defaultEscChkd.checked) || isChanged;
	if(form.hdnScenarioId.value=='')
	{
		alert("Please enter scenario name.");
		return false;
	}


	// To check escalation value according the defaultEscChkd checkbox status
	if (form.defaultEscChkd.checked) {
		isChanged = (form.defaultEsc.defaultValue != form.defaultEsc.value) || isChanged;
	} else {
		isChanged = (form.winLowLow.defaultValue != form.winLowLow.value) || isChanged;
		isChanged = (form.winHighLow.defaultValue != form.winHighLow.value) || isChanged;
		isChanged = (form.winLowMed.defaultValue != form.winLowMed.value) || isChanged;
		isChanged = (form.winHighMed.defaultValue != form.winHighMed.value) || isChanged;
		isChanged = (form.winLowHigh.defaultValue != form.winLowHigh.value) || isChanged;
		isChanged = (form.winHighHigh.defaultValue != form.winHighHigh.value) || isChanged;
		isChanged = (form.lowWinPercentage.defaultValue != form.lowWinPercentage.value) || isChanged;
	}

	// To alert user of changed values.
	if(isChanged) {
		var isConfirmed = window.confirm("Please re-calculate the scenario to get latest calculated values.");
		if(isConfirmed){
			return false;
		}
	}

	document.navframe.location = (basePath + '/ecrd/jsp/pricing/ScenarioXlDownload.jsp?defaultEscChkd=' + form.defaultEscChkd.checked);
	return true;

}

function fn_checkDate(dateObj){

    var objDateWT = dateObj;
 var objDate = trim(objDateWT );
 var l = objDate.length;
 var m = objDate.indexOf("/",1);
 var n = objDate.indexOf("/",4);
 var year = objDate.substr(6,4);
    var day = objDate.substr(3,2);
    var month = objDate.substr(0,2);
 var flag1 = -1;
 var flag2 = -1;
 var flag3 = -1;
 var flag4 = -1;




 if((l==10)&&(m==2)&&(n==5)){
         flag1 = 0;
 }
    else{
           flag1 = 1;
           alert('Please Enter Date in given format(MM/DD/YYYY)...');

        return false;
 }

 if(month == 02){
     if(day <= 29)
     {

        if((year%400 == 0) || ((year%4 == 0) && (year%100 != 0)))
          flag2 = 0;
        else
        {
              flag2 = 1;
             alert('Feb month cannot have 29 days except leap year');
        }
     }
    else{
       flag2 = 1;
    alert('Feb month cannot have 30 or more days');
    }
    }

  if((day<1)||(day>31)){
          flag3 = 1;
    alert('"DD" should be in between 1 to 31...');

      return false;
 }
     else{
  flag3 = 0;

 }

      if((month<1)||(month>12)){
          flag4 = 1;
    alert('"MM" should be in between 1 to 12...');

      return false;
 }
     else{
  flag4 = 0;
 }

 if((/[^0-9]/.test(year))||(/[^0-9]/.test(day))||(/[^0-9]/.test(month))){
            flag5 = 1;
            alert('"mm","dd","yyyy" can be numeric only');

      return false;
 }
  else{
  flag5 = 0;
 }

 if((flag1 == 0)&&((flag2 == 0)||(flag2 == -1))&&(flag3 == 0)&&(flag4 == 0)&&(flag5 == 0)){
   return true;
 }
    else{
return false;
 }
  }


  function trim(str) {
    return str.replace(/^\s+|\s+$/g,'');
}

