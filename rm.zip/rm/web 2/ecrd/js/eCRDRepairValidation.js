// This function is used to validate add repair details
function fnValidateAddRepair(objForm)
{
   if(objForm.lstEngineModel.selectedIndex==0)
   {
       alertMsgs(eCRDSelEngModel);
       objForm.lstEngineModel.focus();
       return false;
   }
   else
   {
       if(objForm.lstEngineModule.selectedIndex==0)
      {
          alertMsgs(eCRDSelEngModule);
          objForm.lstEngineModule.focus();
          return false;
      }
      if(objForm.lstComponent.selectedIndex==0 )
      {
         alertMsgs(eCRDSelect+ " Component Code/Description");
         objForm.lstComponent.focus();
         return false;
      }
      if(objForm.txtComponent.value=="")
      {
         objForm.txtComponent.focus();
         alertMsgs(eCRDempty + "Component "  +objForm.lstComponent.options[objForm.lstComponent.selectedIndex].text);
         return false;
      }
      if(objForm.hdnComponentCode.value=="")
      {
         if(objForm.lstComponent.options[objForm.lstComponent.selectedIndex].text=="Description")
         {
            if(objForm.txtComponent.value=="")
            {    
                 alertMsgs(eCRDempty + "Component Description");
                 return false;
            }
         }
      }
      objForm.hdnComponent.value =objForm.lstComponent.options[objForm.lstComponent.selectedIndex].text;
      objForm.hdnComponentType.value =objForm.lstComponent.options[objForm.lstComponent.selectedIndex].value;
      objForm.hdnComponentCode.value = objForm.txtComponent.value;
      objForm.hdnEngineModuleDesc.value= objForm.lstEngineModule.options[objForm.lstEngineModule.selectedIndex].text;
      objForm.hdnEngineModel.value = objForm.lstEngineModel.options[objForm.lstEngineModel.selectedIndex].value;
      objForm.hdnEngineModule.value = objForm.lstEngineModule.options[objForm.lstEngineModule.selectedIndex].value;
      return true;
   }
}

// This is used for Adding individuyal repair
function fnSubmitAddIndvidualRepair(objForm)
{
   if(fnValidateAddRepair(objForm))
   {
      objForm.hdnRepairType.value = "IR";
      objForm.hdnScreenAction.value="ecrdAddRepairDetailAction";
      objForm.submit();
   }
}

// This function is uses for adding grouped repair
function fnSubmitAddGroupRepair(objForm)
{
   if(fnValidateAddRepair(objForm))
   {
      objForm.hdnRepairType.value = "PR";
      objForm.hdnScreenAction.value="ecrdAddRepairDetailAction";
      objForm.submit();
   }
}

// This function is used to change the values of the Engine Module corresponding to the // value of the Engine Model 
function fnChangeEngineModule(objForm)
{
   objForm.hdnEngineModelDesc.value=objForm.lstEngineModel.options[objForm.lstEngineModel.selectedIndex].value;
   objForm.submit();
}

// This function is used to check if user has selected engine model
function fnSelectEngineModule(objForm)
{
   if(objForm.lstEngineModel.selectedIndex==0)
   {
       alertMsgs(eCRDSelect+ " Engine Model");
       objForm.lstEngineModel.focus();
   }
}

// This function is used to pop up the component list
function fnPopComponentTable(objForm,basePath)
{
   var strEngineModel = objForm.lstEngineModel.options[objForm.lstEngineModel.selectedIndex].value;
   var strEngineModule = objForm.lstEngineModule.options[objForm.lstEngineModule.selectedIndex].value;
   if(objForm.lstEngineModel.selectedIndex==0 || strEngineModel=="")
   {
       alertMsgs(eCRDSelEngModel);
       objForm.lstEngineModel.focus();
       return false;
   }
    if(objForm.lstEngineModule.selectedIndex==0)
   {
          alertMsgs(eCRDSelEngModule);
          objForm.lstEngineModule.focus();
          return false;
   }
   if(objForm.lstComponent.selectedIndex==0)
   {
       alertMsgs(eCRDSelect+ " Component Code/Description");
       objForm.lstComponent.focus();
       return false;
   }
   var strComponentCode = objForm.txtComponent.value;
   if(strComponentCode=="")
   {
      objForm.txtComponent.focus();
      alertMsgs(eCRDempty + "Component "  +objForm.lstComponent.options[objForm.lstComponent.selectedIndex].text);
      return false;
   }
   else
   {
      strComponent =  objForm.lstComponent.options[objForm.lstComponent.selectedIndex].text;
      features='toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,width=500,height=300';
      dlg = window.open (basePath+"/ecrd?hdnScreenName=eCRDManageComponent&hdnScreenAction=eCRDComponentTable&hdnEngineModuleDesc=" + strEngineModule +"&hdnEngineModelDesc=" + strEngineModel + "&hdnComponent=" + strComponent +"&hdnComponentValue=" + strComponentCode+"&RandomValue="+Math.random(),"Dialog",features);
   }
}

// This function is used to validate Child repairs information
function fnValidateChildRepair(objForm)
{
   if(objForm.txtDisplaySequence.length==null)
   {
      if(objForm.txtDisplaySequence.value=="")
      {
         alertMsgs(eCRDempty +"Display Sequence Id");
         objForm.txtDisplaySequence.select();
         objForm.txtDisplaySequence.focus();
         return false;
      }
      /* Patni 29-May-2006 Begin Do not allow '0' in Display Seq Id*/	
		if(objForm.txtDisplaySequence.value == 0)
		{
			alert(eCRDDispSeqNonZero);
			objForm.txtDisplaySequence.focus();
			return false;
		}		
	  /* Patni 29-May-2006 End Do not allow '0' in Display Seq Id*/
      if(isNaN(objForm.txtDisplaySequence.value))
      {
         alertMsgs("Display Sequence Id "+eCRDNotNumeric);
         objForm.txtDisplaySequence.select();
         objForm.txtDisplaySequence.focus();
         return false;
      }
      if(objForm.txtDisplaySequence.value.indexOf("-")!=-1)
      {
            alertMsgs(eCRDCheckValue);
            objForm.txtDisplaySequence.focus();
            return false;
      }

      if(objForm.txtRepairDesc.value=="")
      {
         alertMsgs(eCRDempty +"Repair Description");
         objForm.txtRepairDesc.select();
         objForm.txtRepairDesc.focus();
         return false;
      }
      //SAP feature quantity validation for child repairs added by Kumar
      if(objForm.selectChildSapFlag.selectedIndex==0 && objForm.txtChildSapFeatureQuantity.value != '')
     {
         alertMsgs("SAP feature quantity is needed only if SAP Flag type is IF or FR");        
         objForm.txtChildSapFeatureQuantity.value = "";
         objForm.txtChildSapFeatureQuantity.focus();
         return false;
      }
    //RD Number mandatory - 502321240
      var getElement = document.getElementById("selectModeOfRepair");
  	  var getElementValue = getElement.options[getElement.selectedIndex].value;
      if(objForm.txtRDNumber.value == '' && getElementValue=="NM")
      {     	      
          alertMsgs("Please enter RD Number");
          objForm.txtRDNumber.focus();
     	  return false;
       }
     /* if(objForm.txtRDNumber.value != '' && getElementValue=="M"){
    	   alertMsgs("RD Number is not required if Mode of Repair is Manual");
           //objForm.txtRDNumber.value="";
          objForm.txtRDNumber.focus();
     	  return false;
       }*/
      
      if(objForm.txtRepairDesc.value.length > 255)
      {
         alertMsgs(eCRDRepairDescLength);
         objForm.txtRepairDesc.select();
         objForm.txtRepairDesc.focus();
         return false;
      }

      if(!fnCheckSplChars(objForm.txtRepairDesc))
      {
         objForm.txtRepairDesc.focus();
         alertMsgs(eCRDSpecialChars + " For Repair Description");
         return false;
      }
      if(objForm.lstRepairFormat.selectedIndex!=0)
      {
         if(!fnCheckRepairReferenceFormat(objForm.lstRepairFormat,objForm.txtRepairFormat))
         {
            return false;
         }
      }
      if(objForm.txtComments.value!="")
      {
         if(!fnCheckSplChars(objForm.txtComments))
         {
            objForm.txtComments.focus();
            alertMsgs(eCRDSpecialChars + " For Repair Comments");
            return false;
         }
         if(objForm.txtComments.value.length>250)
         {
            objForm.txtComments.focus();
            alertMsgs(eCRDComments);
            return false;
         }
      }

      if(!objForm.lstRepairFormat.selectedIndex==0 || objForm.txtRepairFormat.value!="")
      {
               if(objForm.lstRepairFormat.selectedIndex==0 && objForm.txtRepairFormat.value!="")
               {
                  alertMsgs(eCRDSelect+ " Repair Reference Format");
                  objForm.lstRepairFormat.focus();
                   return false;
               }

               if(!objForm.lstRepairFormat.selectedIndex==0 && objForm.txtRepairFormat.value =="")
               {
                  alertMsgs(eCRDempty +"Repair Reference");
                  objForm.txtRepairFormat.focus();
                   return false;
               }
               if(!fnCheckRepairReferenceFormat(objForm.lstRepairFormat,objForm.txtRepairFormat))
               {
                     objForm.txtRepairFormat.focus();
                    return false;
               }
       }

      if(objForm.txtRDComments.value!="")
      {
         if(!fnCheckSplChars(objForm.txtRDComments))
         {
            objForm.txtRDComments.focus();
            alertMsgs(eCRDSpecialChars + " For RD Number Comments");
            return false;
         }
         if(objForm.txtRDComments.value.length>250)
         {
            objForm.txtRDComments.focus();
            alertMsgs(eCRDComments);
            return false;
         }
      }
   }
   else
   {
	   for(i=0; i<objForm.txtDisplaySequence.length; i++)
      {
           if(objForm.txtDisplaySequence[i].value=="")
           {
              alertMsgs(eCRDempty +"Display Sequence Id");
              objForm.txtDisplaySequence[i].select();
              objForm.txtDisplaySequence[i].focus();
              return false;
           }
      /* Patni 29-May-2006 Begin Do not allow '0' in Display Seq Id*/	
			if(objForm.txtDisplaySequence[i].value == 0)
			{
				alert(eCRDDispSeqNonZero);
				objForm.txtDisplaySequence[i].focus();
				return false;
			}		
	  /* Patni 29-May-2006 End Do not allow '0' in Display Seq Id*/
           if(isNaN(objForm.txtDisplaySequence[i].value))
           {
               alertMsgs("Display Sequence Id "+eCRDNotNumeric);
               objForm.txtDisplaySequence[i].select();
               objForm.txtDisplaySequence[i].focus();
               return false;
           }
      if(objForm.txtDisplaySequence[i].value.indexOf("-")!=-1)
      {
            alertMsgs(eCRDCheckValue);
            objForm.txtDisplaySequence[i].focus();
            return false;
      }

      }
      for(i=0; i<objForm.txtDisplaySequence.length; i++)
      {
            for(j=i+1;j<objForm.txtDisplaySequence.length;j++)
            {
                  if(objForm.txtDisplaySequence[i].value ==objForm.txtDisplaySequence[j].value)
                  {
                        alertMsgs(eCRDDispSeqIdNotUnique);
                        objForm.txtDisplaySequence[j].select();
                        objForm.txtDisplaySequence[j].focus();
                        return false;
                  } 
            }
       }
      for(i=0; i<objForm.txtRepairDesc.length; i++)
      {
            for(j=i+1;j<objForm.txtRepairDesc.length;j++)
            {
                  if(fnTrim(objForm.txtRepairDesc[i].value) ==fnTrim(objForm.txtRepairDesc[j].value))
                  {
                        alertMsgs(eCRDRepairDescNotUnique);
                        objForm.txtRepairDesc[j].select();
                        objForm.txtRepairDesc[j].focus();
                        return false;
                  } 
            }
       }
      for(i=0; i<objForm.txtDisplaySequence.length; i++)
      {
           if(objForm.txtRepairDesc[i].value=="")
           {
               alertMsgs(eCRDempty +"Repair Description");
               objForm.txtRepairDesc[i].select();
               objForm.txtRepairDesc[i].focus();
               return false;
           }
           if(!fnCheckSplChars(objForm.txtRepairDesc[i]))
           {
               objForm.txtRepairDesc[i].focus();
               alertMsgs(eCRDSpecialChars + " For Repair Description");
               return false;
            }
            if(objForm.txtRepairDesc[i].value.length > 255)
            {
               alertMsgs(eCRDRepairDescLength);
               objForm.txtRepairDesc[i].select();
               objForm.txtRepairDesc[i].focus();
               return false;
            }

      }
      for(i=0; i<objForm.txtDisplaySequence.length; i++)
      {
         if(objForm.lstRepairFormat[i].selectedIndex!=0)
         {
            if(!fnCheckRepairReferenceFormat(objForm.lstRepairFormat[i],objForm.txtRepairFormat[i]))
            {
               return false;
            }
         }
      }
      //SAP feature quantity validation for child repairs added by Kumar    
      for(i=0; i<objForm.txtDisplaySequence.length; i++)
      {
           if(document.frmRepairDetails.selectChildSapFlag[i].selectedIndex==0 && objForm.txtChildSapFeatureQuantity[i].value != '')
           {
        	   alertMsgs("SAP feature quantity is needed only if SAP Flag type is IF or FR"); 
        	   objForm.txtChildSapFeatureQuantity[i].value = "";
        	   objForm.txtChildSapFeatureQuantity[i].focus();
               return false;
           }          

      }

      //RD Number mandatory - 502321240
      var getElement = document.getElementById("selectModeOfRepair");
  	  var getElementValue = getElement.options[getElement.selectedIndex].value;
  	  
      for(i=0; i<objForm.txtRDNumber.length; i++)
      {
           if(objForm.txtRDNumber[i].value == '' && getElementValue=="NM")
           {
        	   alertMsgs("Please enter RD Number");         	   
        	   objForm.txtRDNumber[i].focus();
               return false;
      }
           /*if(objForm.txtRDNumber[i].value != '' && getElementValue=="M"){
        	   alertMsgs("RD Number is not required if Mode of Repair is Manual");
               //objForm.txtRDNumber[i].value="";
               objForm.txtRDNumber.focus();
          	  return false;
           }*/
      }
      
      for(i=0; i<objForm.txtDisplaySequence.length; i++)
      {
         if(objForm.txtComments[i].value!="")
         {
            if(!fnCheckSplChars(objForm.txtComments[i]))
            {
               objForm.txtComments[i].focus();
               alertMsgs(eCRDSpecialChars + " For Repair Comments");
               return false;
            }
            if(objForm.txtComments[i].value.length>250)
            {
               objForm.txtComments[i].focus();
               alertMsgs(eCRDComments);
               return false;
            }
         }   
            if(!objForm.lstRepairFormat[i].selectedIndex==0 || objForm.txtRepairFormat[i].value!="")
            {
                     if(objForm.lstRepairFormat[i].selectedIndex==0 && objForm.txtRepairFormat[i].value!="")
                     {
                        alertMsgs(eCRDSelect+ " Repair Reference Format");
                        objForm.lstRepairFormat[i].focus();
                         return false;
                     }

                     if(!objForm.lstRepairFormat[i].selectedIndex==0 && objForm.txtRepairFormat[i].value =="")
                     {
                        alertMsgs(eCRDempty +"Repair Reference");
                        objForm.txtRepairFormat[i].focus();
                         return false;
                     }
                     if(!fnCheckRepairReferenceFormat(objForm.lstRepairFormat[i],objForm.txtRepairFormat[i]))
                     {
                           objForm.txtRepairFormat[i].focus();
                          return false;
                     }
             }
         
      }

      for(i=0; i<objForm.txtDisplaySequence.length; i++)
      {
         if(objForm.txtRDComments[i].value!="")
         {
            if(!fnCheckSplChars(objForm.txtRDComments[i]))
            {
               objForm.txtRDComments[i].focus();
               alertMsgs(eCRDSpecialChars + " For RD Number Comments");
               return false;
            }
            if(objForm.txtRDComments[i].value.length>250)
            {
               objForm.txtRDComments[i].focus();
               alertMsgs(eCRDComments);
               return false;
            }
         }
      }
   }
   return true;
}

// This function is used to add child repair
function fnAddChildRepair(objForm)
{
   if(fnValidateChildRepair(objForm))
   {
         objForm.hdnChildRepairAction.value= "AddChildRepair";
         objForm.hdnRepairSiteAction.value= "AddMoreSites";
         objForm.hdnCheckSiteOrChildRepair.value = "AddChildRepair";
         objForm.hdnScreenAction.value = "eCRDAddChildRepair";

		for(i=0; i<objForm.txtRDNumber.length; i++)
		{
	         objForm.hdnchildRowNumber.value = i+1;
		}
         objForm.submit();
   }
}

// This function is used to delete the child repair 
function fnDeleteRepair(objForm,strDelDisSeq,strRepairSeqId)
{
   if(objForm.txtDisplaySequence.length==null)
   {
      alertMsgs(eCRDChildRepair);
   }
   else
   {
      if(confirm(eCRDConfirmChildRepairDelete))
      {
             if(strDelDisSeq!="")
            {
               objForm.hdnDelDisSeq.value= strDelDisSeq;
            }
            else
            {
                 objForm.hdnDelDisSeq.value= "-1";
            }
            objForm.hdnChildRepairAction.value= "DelChildRepair";
            objForm.hdnChildRepairSeqId.value= strRepairSeqId;
            objForm.hdnRepairSiteAction.value= "AddMoreSites";  
            objForm.hdnCheckSiteOrChildRepair.value = "AddChildRepair";
            objForm.hdnScreenAction.value = "eCRDAddChildRepair";
            /* Patni 5-06-2006 Defect #77 For effective date to be uneditable Begin */
            objForm.hdnStrFlag.value = "true";
            /* Patni 5-06-2006 Defect #77 For effective date to be uneditable Begin */
            objForm.submit();
      }
   }
}

// This function is used to convert text to uppercase
function fnConvUpperCase(inputString)
{
	var finalData='';
	for(var cntLn=0;cntLn<inputString.length;cntLn++)
	{
		var store=inputString.substring(cntLn,cntLn+1);
		if((store>='a')||(store <='z')||(store>='A')||(store <='Z'))
		{

			finalData+= store.toUpperCase();
		}
		else
		{
			finalData+= store;
		}
	}
	return finalData;
}

//function to check blank field
function fnIsNotEmpty(aTheField)
{
	var lFieldVal; 		// Used to store the value of the passed field
	lFieldVal = aTheField;
	if((lFieldVal == null) || (lFieldVal.length == 0) || (lFieldVal == ""))
	{
		return false;
	}
	else
	{
		return true;
	}
}

// This function is used to check repair reference format onchange of its text
function fnCheckRepairReferenceFormat(format,RepairfieldValue)
{
   fieldFormat =format.options[format.selectedIndex].text;
   RepairfieldValue.value = fnConvUpperCase(RepairfieldValue.value);
   fieldValue = RepairfieldValue.value;
   if(!fnValidateRepairRefFormat(fnConvUpperCase(fieldFormat),fieldValue,RepairfieldValue))
   {
      return false;
   }
   return true;
}

// This function is used to validate repair reference format
function fnValidateRepairRefFormat(fieldFormat,fieldValue,field)
{
   if(fnIsNotEmpty(fieldValue))
	{
		if(fieldFormat!="OTHERS")
		{
			if(!(fieldFormat.length == fieldValue.length))
		   {
	   		alert("Please enter the value in "+fieldFormat+" format");
            field.focus();
	   		return false;
		   }
   		for(var i = 0 ;i<fieldFormat.length;i++)
	   	{
   			check = fieldValue.charAt(i);
				if(fieldFormat.charAt(i)=='X')
				{
   				if (!(((check >='a')&&(check <='z'))||((check >='A')&&(check <='Z'))||((check >='0')&&(check <='9'))))
					{
						alert("Please enter the value in "+fieldFormat+" format");
                  field.focus();
						return false;
					}
				}
				else
				{
					if(check != fieldFormat.charAt(i))
					{
							alert("Please enter the value in "+fieldFormat+" format");
                     field.focus();
							return false;
					}
				}
			}
		}
		//else
	}
   else
   {
      alertMsgs(eCRDempty + "Repair Reference");
      field.focus();
      return false;
   }
   return true;
}

// This function is used to add sites for repair
function fnAddMoreSites(objForm)
{
   if(fnValidateAddSites(objForm,"Sites"))
   {
      if(objForm.hdnRepairType.value=="PR")
      {
            objForm.hdnChildRepairAction.value= "AddChildRepair";
      }
      objForm.hdnRepairSiteAction.value= "AddMoreSites";
      objForm.hdnCheckSiteOrChildRepair.value = "AddMoreSites";
      objForm.hdnScreenAction.value = "eCRDAddMoreSites";
      objForm.submit();
   }
}

// This function is used to validate repair sites information
function fnValidateAddSites(objForm,strCheckAction)
{
   var strTotalCost="";
   var strCM = "";
   if(strCheckAction=="Sites")
   {
      if(objForm.txtMatCost.length)
      {
         if(objForm.lstSite[0].length -1 == objForm.txtMatCost.length)
         {
            alertMsgs(eCRDMaxRepairSites);
            return false;
         }
      }
      else
      {
         if(objForm.lstSite.length==2)
         {
            alertMsgs(eCRDMaxRepairSites);
            return false;
         }
      }
   }
   if(!objForm.txtMatCost.length)
   {
      if(objForm.lstSite.selectedIndex ==0)
      {
         alertMsgs(eCRDSelect + " Site");
         objForm.lstSite.focus();
         return false;
      }
      if(objForm.txtMatCost.value=="")
      {
         alertMsgs(eCRDempty + "Material Cost");
         objForm.txtMatCost.focus();
         return false;
     }
     if(isNaN(objForm.txtMatCost.value))
     {
         alertMsgs("Material Cost "+eCRDNotNumeric);
         objForm.txtMatCost.select();
         objForm.txtMatCost.focus();
         return false;
     }
     if(objForm.txtLabourHrs.value=="")
     {
         alertMsgs(eCRDempty + " Labour Hours");
         objForm.txtLabourHrs.focus();
         return false;
      }
      if(isNaN(objForm.txtLabourHrs.value))
      {
         alertMsgs("Labour Hours "+eCRDNotNumeric);
         objForm.txtLabourHrs.select();
         objForm.txtLabourHrs.focus();
         return false;
      }
      fnCalculate(objForm);
   }
   else
   {
      for(i=0; i<objForm.txtMatCost.length; i++)
      {
         //if(objForm.lstSite[i].selectedIndex ==0)
         if(objForm.lstSite[i].value == "")
         {
            alertMsgs(eCRDSelect + " Site");
            objForm.lstSite[i].focus();
            return false;
         }
         for(k=0; k<objForm.txtMatCost.length; k++)
         {
            for(j=k+1;j<objForm.txtMatCost.length;j++)
            {
                  //if(objForm.lstSite[k].options[objForm.lstSite[k].selectedIndex].value ==objForm.lstSite[j].options[objForm.lstSite[j].selectedIndex].value)
                  if(objForm.lstSite[k].value ==objForm.lstSite[j].value)
                  {
                        alertMsgs(eCRDUniqueRepairSite);
                        objForm.lstSite[j].focus();
                        return false;
                  } 
             }
         }
         if(objForm.txtMatCost[i].value=="")
         {
               alertMsgs(eCRDempty + " Material Cost");
               objForm.txtMatCost[i].focus();
               return false;
         }
         if(isNaN(objForm.txtMatCost[i].value))
         {
            alertMsgs("Material Cost "+eCRDNotNumeric);
            objForm.txtMatCost[i].select();
            objForm.txtMatCost[i].focus();
            return false;
         }
         if(objForm.txtLabourHrs[i].value=="")
         {
            alertMsgs(eCRDempty + " Labour Hours");
            objForm.txtLabourHrs[i].focus();
            return false;
         }
         if(isNaN(objForm.txtLabourHrs[i].value))
         {
            alertMsgs("Labour Hours "+eCRDNotNumeric);
            objForm.txtLabourHrs[i].select();
            objForm.txtLabourHrs[i].focus();
            return false;
         }
         fnCalculate(objForm);
      }
   }
   return true;   
}

// This function is used to set the Location labour rate dependign on the site selected
function fnSetLocLabourRate(objForm)
{
   var strSiteValue="";
   var strLocLabourRate="";
   if(objForm.txtMatCost.length==null)
   {
      strSiteValue = objForm.lstSite.value;
      arrayOfStrings = strSiteValue.split("^")
      if(strSiteValue!="")
      {
         objForm.txtLocLabourRate.value = parseFloat(arrayOfStrings[1]); 
         fnCalculate(objForm);
      }
      else
      {
            objForm.txtMatCost.value="";
            objForm.txtLabourHrs.value= "";
            objForm.txtLocLabourRate.value="";
            objForm.txtTotalCost.value ="";
            objForm.txtCM.value ="";
      }
   }
   else
   {
      for(i=0; i<objForm.txtMatCost.length; i++)
      {
         strSiteValue = "";
         strTemp ="";
         strLocLabourRate = "";
         strSiteValue = objForm.lstSite[i].value;
         if(strSiteValue!="")
         {
            arrayOfStrings = strSiteValue.split("^")
            objForm.txtLocLabourRate[i].value = parseFloat(arrayOfStrings[1]); 
            fnCalculate(objForm);
         }
         else
         {
            objForm.txtMatCost[i].value="";
            objForm.txtLabourHrs[i].value= "";
            objForm.txtLocLabourRate[i].value="";
            objForm.txtTotalCost[i].value ="";
            objForm.txtCM[i].value ="";
         }
      }
   }
}

// This function is used to delete the site associated with the repair
function fnDeleteRepairSite(objForm,strDeleteSiteCode)
{
   if(objForm.txtMatCost.length==null)
   {
       alertMsgs(eCRDAtLeastOneRepairSite);
   }
   else
   {
      if(confirm(eCRDConfirmSiteDelete))
      {
            if(objForm.hdnRepairType.value=="PR")
            {
                  objForm.hdnChildRepairAction.value= "AddChildRepair";
            }
            if(strDeleteSiteCode!="")
            {
               objForm.hdnDeleteSiteCode.value = objForm.lstSite[strDeleteSiteCode].options[objForm.lstSite[strDeleteSiteCode].selectedIndex].value;
            }
            else
            {
               objForm.hdnDeleteSiteCode.value = "-1";
            }
            objForm.hdnRepairSiteAction.value= "DeleteRepairSite";
            objForm.hdnScreenAction.value = "eCRDAddMoreSites";
            objForm.hdnCheckSiteOrChildRepair.value = "AddMoreSites";
            /* Patni 25-05-2006 Defect #17 For effective date to be uneditable Begin */
            /* Patni 5-06-2006 Defect #77 For effective date to be uneditable Begin */
          //  	objForm.hdnBoolEffDate.value = "true";
            objForm.hdnStrFlag.value = "true";
            /* Patni 5-06-2006 Defect #77 For effective date to be uneditable End */
            /* Patni 25-05-2006 Defect #17 For effective date to be uneditable End */
            objForm.submit();
      }
   }
}

// This function is used to apply the values of Mat Cost and Labour Rate to all sites
function fnApplyAll(objForm)
{
   if(objForm.txtApplyMatCost.value=="" && objForm.txtApplyLabourHrs.value=="")
   {
        alertMsgs(eCRDempty + " Material Cost or Labour Hours");
        objForm.txtApplyMatCost.focus();
        return false;
   }
   if(objForm.txtApplyMatCost.value!="")
   {
      if(isNaN(objForm.txtApplyMatCost.value))
     {
         alertMsgs("Material Cost "+eCRDNotNumeric);
         objForm.txtApplyMatCost.select();
         objForm.txtApplyMatCost.focus();
         return false;
     }
     if(objForm.txtMatCost.length==null)
      {
         objForm.txtMatCost.value=objForm.txtApplyMatCost.value;
     } 
      else
      {
         for(i=0; i<objForm.txtMatCost.length; i++)
         {
            objForm.txtMatCost[i].value=objForm.txtApplyMatCost.value;
         }   
      }
      fnCalculate(objForm);
   }
   if(objForm.txtApplyLabourHrs.value!="")
   {
      if(isNaN(objForm.txtApplyLabourHrs.value))
     {
         alertMsgs("Labor Hrs "+eCRDNotNumeric);
         objForm.txtApplyLabourHrs.select();
         objForm.txtApplyLabourHrs.focus();
         return false;
     }
       if(objForm.txtLabourHrs.length==null)
      {
         objForm.txtLabourHrs.value=objForm.txtApplyLabourHrs.value;
      } 
      else
      {
         for(i=0; i<objForm.txtLabourHrs.length; i++)
         {
            objForm.txtLabourHrs[i].value=objForm.txtApplyLabourHrs.value;
         }   
      }
      fnCalculate(objForm);
   }
}

// This function is used to calculate total cost and CM
function fnCalculate(objForm)
{   
   if(objForm.hdnPriceOverWriteInd.value!="true")
   {
      if(objForm.txtMatCost.length==null)
      {
         if(objForm.txtMatCost.value!="" && objForm.txtLabourHrs.value!="" && objForm.txtLocLabourRate.value!="")
         {
            strTotalCost =( parseFloat(objForm.txtLabourHrs.value) * parseInt(objForm.txtLocLabourRate.value) ) + parseFloat(objForm.txtMatCost.value);
            objForm.txtTotalCost.value = strTotalCost;
            if(objForm.txtPrice.value!="")
            {
                strPrice = objForm.txtPrice.value;
                strCM = ((parseFloat(strPrice) - parseFloat(strTotalCost ))/parseFloat(strPrice)) * 100;
                objForm.txtCM.value = fnRoundTwoDecimal(strCM);
            }
            else
            {
                objForm.txtCM.value = "";
            }
         }
      }
      else
      {
         for(k=0; k<objForm.txtMatCost.length; k++)
         {
             if(objForm.txtMatCost[k].value!="" && objForm.txtLabourHrs[k].value!="" && objForm.txtLocLabourRate[k].value!="")
            {
               strTotalCost =( parseFloat(objForm.txtLabourHrs[k].value) * parseInt(objForm.txtLocLabourRate[k].value) ) + parseFloat(objForm.txtMatCost[k].value);
               objForm.txtTotalCost[k].value = strTotalCost;
               if(objForm.txtPrice.value!="")
               {
                  strPrice = objForm.txtPrice.value;
                  strCM = (( parseFloat(strPrice) - parseFloat(strTotalCost) )/parseFloat(strPrice)) * 100;
                  objForm.txtCM[k].value = fnRoundTwoDecimal(strCM);
               }
               else
               {
                  objForm.txtCM[k].value = "";
               }
            }
         }
      }
   }
}


/*//By 502622936 for cr0020 when material of primary site is 0 then change price type to flp+
function checkPrimaryMaterial(objForm){
	if(objForm.txtMatCost.length==null){
		alert("the value and lenght are :::"+objForm.txtMatCost.value +"::::"+ 
				objForm.txtMatCost.length);
		
		if(objForm.txtMatCost.value==0){
			objForm.lstPriceType.value="FPL_PLUS";
			alert("Price Type has been changed to ::"+objForm.lstPriceType.value+" \n"+"Since the material cost of primary site was 0, \nonly one site was selected.");
		}
	}else{
		if(objForm.txtMatCost[0].value==0){
			objForm.lstPriceType.value="FPL_PLUS";
			alert("Price Type has been changed to ::"+objForm.lstPriceType.value+"\n"+"Since the material cost of primary site was 0.");
		}
	}
}*/




// This function is used to validate repair details
function fnRepairDetailValidation(strOperation)
{
   var dayVal;
   var monthVal;
   var yearVal;
   var fullDateVal;
   var isPriceTypeQuote = false;
   //Patni 17-May-2006 Begin Repair Effective Date of the Repair should not be updatable.
   var fullDateVal1;
   var fullDateVal2;
   var isEffDate = true;
   isEffDate = document.frmRepairDetails.hdnBoolEffDate.value;
   //Patni 17-May-2006 End Repair Effective Date of the Repair should not be updatable.
   /* Patni 7-06-2006 Defect #77 For effective date to be uneditable Begin */
   document.frmRepairDetails.hdnStrFlag.value = "true";
   /* Patni 7-06-2006 Defect #77 For effective date to be uneditable End */
   isPriceTypeQuote = document.frmRepairDetails.lstPriceType.options[document.frmRepairDetails.lstPriceType.selectedIndex].text=='QUOTE';
 if(document.frmRepairDetails.txtRepairDescription.value=="")
   {
      alertMsgs(eCRDempty +"Repair Description");
      document.frmRepairDetails.txtRepairDescription.focus();
      return false;
   }
 /*502622936*/
 if(document.frmRepairDetails.txtRepairFre.value!=null ||document.frmRepairDetails.txtRepairFre.value!=""){
	 
 
 if (isNaN(document.frmRepairDetails.txtRepairFre.value))
 {
	    alert("Please enter numeric value only");
	    document.frmRepairDetails.txtRepairFre.focus();
	    return false;
	    
	}
 else if(document.frmRepairDetails.txtRepairFre.value < 0 || document.frmRepairDetails.txtRepairFre.value > 100){
	 alert("Value of Repair Frequency Should be in the range of 0 - 100");
	    document.frmRepairDetails.txtRepairFre.focus();
	    return false;
 }
 }
 if(strOperation =="Create"){
	/* if(document.frmRepairDetails.txtRepairFre.value=="")
	 {
	    alertMsgs(eCRDempty +"Repair Frequency");
	    document.frmRepairDetails.txtRepairFre.focus();
	    return false;
	 }*/
 }
 
 if(strOperation =="Modify"){
	 if(document.frmRepairDetails.txtRationale.value=="")
	 {
	    alertMsgs(eCRDempty +"Rationale for Change");
	    document.frmRepairDetails.txtRationale.focus();
	    return false;
	 }
 }
 if(strOperation=="Create" || strOperation=="Modify"){
	 //502622936---selectRepairFlg
	 /*alert("strOperation==Create || strOperation==Modify");*/
     if(document.frmRepairDetails.txtLabourHrs.value==0 && !(document.frmRepairDetails.selectRepairFlg.value =="EX"))
     {
         alert("Repair Flag must be External Repair in case Labour Hours is Zero");
         document.frmRepairDetails.selectRepairFlg.focus();
         return false;
      }
 }
 
   
    if(document.frmRepairDetails.txtRepairDescription.value.length > 255)
   {
      alertMsgs(eCRDRepairDescLength);
      document.frmRepairDetails.txtRepairDescription.focus();
      return false;
   }
   if(!fnCheckSplChars(document.frmRepairDetails.txtRepairDescription))
   {
       document.frmRepairDetails.txtRepairDescription.focus();
       alertMsgs(eCRDSpecialChars + " For Repair Description");
 	    return false;
   }
   if(document.frmRepairDetails.hdnRepairType.value=="IR")
   {
      if(document.frmRepairDetails.lstRepairReference.selectedIndex==0)
      {
         alertMsgs(eCRDSelect+ " Repair Reference Format");
         document.frmRepairDetails.lstRepairReference.focus();
         return false;
      }
      if(document.frmRepairDetails.txtRepairReference.value=="")
      {
         alertMsgs(eCRDempty +"Repair Reference");
         document.frmRepairDetails.txtRepairReference.focus();
         return false;
      }
      if(!fnCheckRepairReferenceFormat(document.frmRepairDetails.lstRepairReference,document.frmRepairDetails.txtRepairReference))
      {
         return false;
      }
   }

   if(document.frmRepairDetails.selectRprType.selectedIndex==0)
   {
      // commented on 15/11/2006 on Santosh observation (asked to do like this)
      //if (!confirm('NPI Classification is mandatory. Do you want to leave it blank ?'))
      //{
		  alert('NPI Classification is mandatory');
	      document.frmRepairDetails.selectRprType.focus();
	      return false;
      //}
   }
   /*502634089 */
	
if(document.frmRepairDetails.hdnMandatorymode.value=="y"){
	if(document.frmRepairDetails.selectModeOfRepair.selectedIndex == 0){
		alert('Mode of repair is mandatory');
		document.frmRepairDetails.selectModeOfRepair.focus();
		return false;
		
	}
}
//502622936-hdnMandatoryLevel
if(document.frmRepairDetails.hdnMandatoryLevel.value=="y"){
	if(document.frmRepairDetails.selectLevelOfDifficulty.selectedIndex == 0){
		alert('Level of Difficulty is mandatory');
		document.frmRepairDetails.selectLevelOfDifficulty.focus();
		return false;
	}
}
	if(document.frmRepairDetails.selectModeOfRepair.selectedIndex == 1 && document.frmRepairDetails.url.value !="" ){
		
		var validateUrl= /^(http[s]?:\/\/){0,1}(www\.){0,1}[a-zA-Z0-9\.\-]+\.[a-zA-Z]{2,5}[\.]{0,1}/;
		
		if(!(validateUrl.test(document.frmRepairDetails.url.value))){
			alert("please enter Link to view Engine Service Manual in the url format");
			document.frmRepairDetails.url.focus();
			return false;
		}
	}
   //SAP feature quantity validation for repairs added by Kumar
   if(document.frmRepairDetails.selectSapFlag.selectedIndex==0 && document.frmRepairDetails.txtSapFeatureQuantity.value != '')
   {		 
	      alertMsgs("SAP feature quantity is needed only if SAP Flag type is IF or FR"); 
	      document.frmRepairDetails.txtSapFeatureQuantity.value = "";
	      document.frmRepairDetails.txtSapFeatureQuantity.focus();
	      return false;
   }
   
   if(document.frmRepairDetails.txtRepairVolume.value!="")
   {
         if(document.frmRepairDetails.txtRepairVolume.value.indexOf("-")!=-1)
         {
            alertMsgs(eCRDCheckValue);
            document.frmRepairDetails.txtRepairVolume.focus();
            return false;
         }
   }
 //Patni 17-May-2006 Begin Repair Effective Date of the Repair should not be updatable.
   if(!isEffDate)
   {
	   
   	if(document.frmRepairDetails.sel_man_Startdate_DD.value=="")
   	{
         alertMsgs(eCRDSelectDate);
         document.frmRepairDetails.sel_man_Startdate_DD.focus();
         return false;
   	}
    if(document.frmRepairDetails.sel_man_Startdate_MM.value=="")
   {
         alertMsgs(eCRDSelectMonth);
         document.frmRepairDetails.sel_man_Startdate_MM.focus();
         return false;
   }
   if(document.frmRepairDetails.sel_man_Startdate_YYYY.value=="")
   {
         alertMsgs(eCRDSelectYear);
         document.frmRepairDetails.sel_man_Startdate_YYYY.focus();
         return false;
   }
         dayVal = document.frmRepairDetails.sel_man_Startdate_DD.value;
         monthVal = document.frmRepairDetails.sel_man_Startdate_MM.value;
         yearVal = document.frmRepairDetails.sel_man_Startdate_YYYY.value;
         fullDateVal2 =monthVal + "/" +dayVal + "/"  + yearVal;
         //This if is added to check whether the effective date is proper or not.
         if(!fnValidateDateString(fullDateVal2))
         {
                     document.frmRepairDetails.sel_man_Startdate_DD.focus();
                     return false;
        }
        fullDateVal =yearVal + "/" + monthVal+ "/"  + dayVal ;
    }
   		/*Patni 26-5-06 Begin Defect#17 When creating new repair Component Effectiv Date should be displayed*/
   		if(fullDateVal==null ||fullDateVal == "")
   		{
   		fullDateVal = document.frmRepairDetails.hdnEffDate.value; 
   		}
   		/*Patni 26-5-06 End Defect#17 When creating new repair Component Effectiv Date should be displayed*/
   		//Patni 17-May-2006 End Repair Effective Date of the Repair should not be updatable.
        CompEffDate=document.frmRepairDetails.hdnComponentEffectiveDate.value;     
        sysDate= document.frmRepairDetails.hdnRepairSysDate.value;                
        arrayOfStrings = document.frmRepairDetails.hdnComponentEffectiveDate.value.split("/");
        strCompEffDayToDisplay = arrayOfStrings[1]+"/"+arrayOfStrings[2]+"/"+arrayOfStrings[0];
       /* if(strOperation=="Approve")
        {
              RepEffDate = document.frmRepairDetails.hdnRepairEffDate.value;      
              arrayOfStrings = document.frmRepairDetails.hdnRepairEffDate.value.split("/");
              strRepEffDayToDisplay = arrayOfStrings[1]+"/"+arrayOfStrings[2]+"/"+arrayOfStrings[0];
              if(fnCompareDateFromTo(fullDateVal,CompEffDate)==false)
              {
                   alertMsgs(eCRDRepairEfftDate+"("+strCompEffDayToDisplay+")");
                   return false;
              }
              if(fnCompareDateFromTo(fullDateVal,sysDate)==false)
              {
                         if(fnCompareDateFromTo(fullDateVal,RepEffDate)==false)
                        {
                              alertMsgs(eCRDRepairEfftectiveDate+"("+strRepEffDayToDisplay+")");
                            return false;
                        }                                              
              }
        }*/
        if(strOperation=="Create" || strOperation=="Split" || strOperation=="Merge")
        {
                    if(fnCompareDateFromTo(fullDateVal,CompEffDate)==false)
                     {
                        alertMsgs(eCRDRepairEfftDate+"("+strCompEffDayToDisplay+")");
                        return false;
                     }
                     if(fnCompareDateFromTo(fullDateVal,sysDate)==false)
                     {
                       alertMsgs(eCRDEffectiveDate); 
                       return false;
                     }                                              
        }
        if(strOperation=="Modify")
        {
                     if(fnCompareDateFromTo(fullDateVal,CompEffDate)==false)
                     {
                        alertMsgs(eCRDRepairEfftDate+"("+strCompEffDayToDisplay+")");  
                        return false;
                     }
        }
        if(document.frmRepairDetails.txtRepairComments.value!="")
        {
            if(!fnCheckSplChars(document.frmRepairDetails.txtRepairComments))
            {
                document.frmRepairDetails.txtRepairComments.focus();
                alertMsgs(eCRDSpecialChars + " For Repair Comments");
                return false;
            }
            if(document.frmRepairDetails.txtRepairComments.value.length >250)
            {
                document.frmRepairDetails.txtRepairComments.focus();
                alertMsgs(eCRDComments);
                return false;
            }
        }
   if(document.frmRepairDetails.hdnRepairType.value=="IR" || document.frmRepairDetails.hdnRepairType.value=="SI")
   {
	   //RD Number mandatory - 502321240
	   //if(strOperation=="Create" && document.frmRepairDetails.txtRDNumber.value == '')
	   var getElement = document.getElementById("selectModeOfRepair");
	   var getElementValue = getElement.options[getElement.selectedIndex].value;
	   //alert("selectModeOfRepair value: "+getElementValue);
	   if(document.frmRepairDetails.txtRDNumber.value == '' && getElementValue == "NM")
	   {
	      //alertMsgs("Please enter RD Number. It is mandatory for all the newly created repairs");
		   alertMsgs("Please enter RD Number");
	      document.frmRepairDetails.txtRDNumber.focus();
	      return false;
	   }
	  /* if(document.frmRepairDetails.txtRDNumber.value != '' && getElementValue == "M"){
    	   alertMsgs("RD Number is not required if Mode of Repair is Manual");
    	   //document.frmRepairDetails.txtRDNumber.value="";
    	   document.frmRepairDetails.txtRDNumber.focus();
    	   document.frmRepairDetails.txtRDNumber.readOnly = true;
      	  return false;
       }
*/
        if(document.frmRepairDetails.txtRDComments.value!="")
        {
            if(!fnCheckSplChars(document.frmRepairDetails.txtRDComments))
            {
                document.frmRepairDetails.txtRDComments.focus();
                alertMsgs(eCRDSpecialChars + " For RD Number Comments");
                return false;
            }
            if(document.frmRepairDetails.txtRDComments.value.length >250)
            {
                document.frmRepairDetails.txtRDComments.focus();
                alertMsgs(eCRDComments);
                return false;
            }
        }
   }
         if(document.frmRepairDetails.txtTurnAround.value!="")
         {
            if(parseInt(document.frmRepairDetails.txtTurnAround.value)<0)
            {         
              alertMsgs("Turn Around Time "+eCRDNonNegative);
               document.frmRepairDetails.txtTurnAround.focus();
               return false;
            }
            if(document.frmRepairDetails.txtTurnAround.value.indexOf("-")!=-1)
            {         
               alertMsgs(eCRDCheckValue);
               document.frmRepairDetails.txtTurnAround.focus();
               return false;
            }            
         }

   /*if(document.frmRepairDetails.txtTurnAround.value=="")
   {
      alertMsgs(eCRDempty +"Turn Around Time");
      document.frmRepairDetails.txtTurnAround.focus();
      return false;
   }*/
   /*if(parseInt(document.frmRepairDetails.txtTurnAround.value)==0)
   {
      alertMsgs(eCRDempty +"Turn Around Time");
      document.frmRepairDetails.txtTurnAround.focus();
      return false;
   }*/
   if(document.frmRepairDetails.txtPrice.value=="")
   {
      /*if(!isPriceTypeQuote)
      {
      	alertMsgs(eCRDempty +"Price");
      	document.frmRepairDetails.txtPrice.focus();
      	return false;
      }*/
   }
   else
   {
   	/*if(isPriceTypeQuote)
      {
       		alertMsgs(eCRDQUOTEPrice);
      		document.frmRepairDetails.txtPrice.focus();
      		return false;
      }
*/      if(!fnCheckDecimalValue(document.frmRepairDetails.txtPrice.value))
	   {
		      alertMsgs(eCRDCheckValue);
		      document.frmRepairDetails.txtPrice.focus();
		      return false;
      }
      	/*else
      	{
      		/*if(parseFloat(document.frmRepairDetails.txtPrice.value)==0)
	        {
		      alertMsgs(eCRDPrice);
		      document.frmRepairDetails.txtPrice.focus();
		      return false;
      		}
         }*/
   }
   if(isPriceTypeQuote)
   {
   	if(document.frmRepairDetails.chkIncPrice.checked)
   	{
   		alertMsgs(eCRDIncrPrice);
		   document.frmRepairDetails.txtPrice.focus();
		   return false;
   	}
   }

       if(document.frmRepairDetails.txtPrice.value!="")
      {
           if(document.frmRepairDetails.txtPrice.value > 999999999999.99)
         {
            alertMsgs(eCRDPriceLimit);
            document.frmRepairDetails.txtPrice.focus();
            return false;      
         }
      }

   if(document.frmRepairDetails.lstPriceType.selectedIndex==0)
   {
      alertMsgs(eCRDSelect+ " Price Type");
      document.frmRepairDetails.lstPriceType.focus();
      return false;
   }
   if(document.frmRepairDetails.txtDisplaySeq.value=="")
   {
      alertMsgs(eCRDempty +"Display Sequence");
      document.frmRepairDetails.txtDisplaySeq.focus();
      return false;
   }
   /* Patni 29-May-2006 Begin Do not allow '0' in Display Seq Id*/	
	if(document.frmRepairDetails.txtDisplaySeq.value == 0)
	{
		alert(eCRDDispSeqNonZero);
		document.frmRepairDetails.txtDisplaySeq.focus();
		return false;
	}		
  /* Patni 29-May-2006 End Do not allow '0' in Display Seq Id*/
   if(document.frmRepairDetails.txtDisplaySeq.value.indexOf("-")!=-1)
   {
      alertMsgs(eCRDCheckValue);
      document.frmRepairDetails.txtDisplaySeq.focus();
      return false;
   }
   if(document.frmRepairDetails.txtFuturePrice !=null)
   {
            if(document.frmRepairDetails.txtFuturePrice.value!="")
            {
               if(isPriceTypeQuote)
               {
                     alertMsgs(eCRDQUOTEPrice);
                     document.frmRepairDetails.txtFuturePrice.focus();
                     return false;
               }
               if(!fnCheckDecimalValue(document.frmRepairDetails.txtFuturePrice.value))
               {
                     alertMsgs(eCRDCheckValue);
                     document.frmRepairDetails.txtFuturePrice.focus();
                     return false;
               }

         if(document.frmRepairDetails.txtFuturePrice.value!="")
         {
              if(document.frmRepairDetails.txtFuturePrice.value > 999999999999.99)
            {
               alertMsgs("Future "+eCRDPriceLimit);
               document.frmRepairDetails.txtFuturePrice.focus();
               return false;      
            }
         }

      /*else
      {
         if(parseFloat(document.frmRepairDetails.txtFuturePrice.value)==0)
         {
            alertMsgs(eCRDempty +"Future Price");
            document.frmRepairDetails.txtFuturePrice.focus();
            return false;
         }
      }*/
      }
   /*if(document.frmRepairDetails.txtFutureTAT.value!="")
   {
      if(parseInt(document.frmRepairDetails.txtFutureTAT.value)==0)
      {
         alertMsgs(eCRDempty +"Future TAT");
         document.frmRepairDetails.txtFutureTAT.focus();
         return false;
      }
   }*/
           if(document.frmRepairDetails.txtFutureTAT.value!="")
            {
               if(parseInt(document.frmRepairDetails.txtFutureTAT.value)<0)
               {         
                 alertMsgs("Future Turn Around Time "+eCRDNonNegative);
                  document.frmRepairDetails.txtFutureTAT.focus();
                  return false;
               }
               if(document.frmRepairDetails.txtFutureTAT.value.indexOf("-")!=-1)
               {         
                  alertMsgs(eCRDCheckValue);
                  document.frmRepairDetails.txtFutureTAT.focus();
                  return false;
               }            

            }

            if(parseFloat(document.frmRepairDetails.txtFuturePrice.value) >= 0 || parseInt(document.frmRepairDetails.txtFutureTAT.value) >= 0)
            {
                           if(document.frmRepairDetails.sel_man_Startdate_DD1.value=="")
                           {
                                 alertMsgs(eCRDSelectFutureEffDate);
                                 document.frmRepairDetails.sel_man_Startdate_DD1.focus();
                                 return false;
                           }
                           if(document.frmRepairDetails.sel_man_Startdate_MM1.value=="")
                           {
                                 alertMsgs(eCRDSelectMonth);
                                 document.frmRepairDetails.sel_man_Startdate_MM1.focus();
                                 return false;
                           }
                           if(document.frmRepairDetails.sel_man_Startdate_YYYY1.value=="")
                           {
                                 alertMsgs(eCRDSelectYear);
                                 document.frmRepairDetails.sel_man_Startdate_YYYY1.focus();
                                 return false;
                           }
            }
   
//This if is added for checking whether only one select box is selected and the others are left blanck in future effective date calender object
   if(document.frmRepairDetails.sel_man_Startdate_DD1.value!="" || document.frmRepairDetails.sel_man_Startdate_MM1.value!="" || document.frmRepairDetails.sel_man_Startdate_YYYY1.value!="")
   {
       if(!(document.frmRepairDetails.sel_man_Startdate_DD1.value!="" && document.frmRepairDetails.sel_man_Startdate_MM1.value!="" && document.frmRepairDetails.sel_man_Startdate_YYYY1.value!=""))
      {
          alertMsgs(eCRDSelectFutureEffDate);
          document.frmRepairDetails.sel_man_Startdate_DD1.focus();
          return false;
      }
   }

   if(document.frmRepairDetails.sel_man_Startdate_DD1.value!="" && document.frmRepairDetails.sel_man_Startdate_MM1.value!="" && document.frmRepairDetails.sel_man_Startdate_YYYY1.value!="")
   {
      /* if(document.frmRepairDetails.txtFuturePrice.value=="" &&  document.frmRepairDetails.txtFutureTAT.value=="")
       {
            if(isPriceTypeQuote)
            {
               alertMsgs(eCRDempty + eCRDFutureTATCheck);
               document.frmRepairDetails.txtFutureTAT.focus();
               return false;
            }
            else
            {
                  alertMsgs(eCRDempty + "Either " + eCRDFuturePriceCheck + " Or " +  eCRDFutureTATCheck);
                  document.frmRepairDetails.txtFuturePrice.focus();
                  return false;
            }
      }*/
      

      if(!fnValidateCalenderDate(document.frmRepairDetails))
      {
         //Patni 17-May-2006 Begin Repair Effective Date of the Repair should not be updatable.
         /** dayVal = document.frmRepairDetails.sel_man_Startdate_DD.value;
         monthVal = document.frmRepairDetails.sel_man_Startdate_MM.value;
         yearVal = document.frmRepairDetails.sel_man_Startdate_YYYY.value;
         fullDateVal =yearVal+ "/" + monthVal + "/"  + dayVal;*/
         //Patni 17-May-2006 End Repair Effective Date of the Repair should not be updatable.
         fullDateVal = document.frmRepairDetails.hdnEffDate.value;
         dayVal = document.frmRepairDetails.sel_man_Startdate_DD1.value;
         monthVal = document.frmRepairDetails.sel_man_Startdate_MM1.value;
         yearVal = document.frmRepairDetails.sel_man_Startdate_YYYY1.value;
         fullDateVal1 =monthVal+ "/" + dayVal + "/"  + yearVal;
            //This if condition is added for checking whether the future effective date entered is proper .
              if(!fnValidateDateString(fullDateVal1))
              {
                     document.frmRepairDetails.sel_man_Startdate_DD1.focus();
                     return false;
              }

         fullDateVal1 =yearVal+ "/" + monthVal + "/"  + dayVal;
	      if(fnCompareDateFromTo(fullDateVal,fullDateVal1))
	      {
            alertMsgs(eCRDFutureEffDateCheck);
		      return false;
         }
      }
      else
      {
            alertMsgs(eCRDFutureRepEffectiveDate);
            return false;
      }
   }
 }
   if(document.frmRepairDetails.chkIncrTime.checked)
   {
      document.frmRepairDetails.hdnIncrTime.value ="true";
   }
   else
   {
      document.frmRepairDetails.hdnIncrTime.value ="false";
   }
   if(document.frmRepairDetails.chkIncPrice.checked)
   {
      document.frmRepairDetails.hdnIncrPrice.value ="true";
   }
   else
   {
      document.frmRepairDetails.hdnIncrPrice.value ="false";
   }
   if(!fnValidateAddSites(document.frmRepairDetails,"Repair"))
   {
      return false;
   }
   
   /*Rollback*/
   
 /*  
  // For checking material cost* 502622936/ 
   if(document.frmRepairDetails.txtMatCost.length==null)
   	{
	   if(document.frmRepairDetails.txtMatCost.value==0 && document.frmRepairDetails.lstPriceType.value!="FPL_PLUS"){
			alert("Price Type must be FPL+ in case of Material Cost is 0 for Primary Site!");
			document.frmRepairDetails.lstPriceType.focus();
			var userResponse = confirm("Price Type must be FPL+ in case of Material Cost is 0 for Primary Site!");
				 	if(userResponse){
				 		document.frmRepairDetails.lstPriceType.value="FPL_PLUS";
				 	}else{
				 		return false;
				 	}
			return false;
	   }
   	}else{
			if(document.frmRepairDetails.txtMatCost[0].value==0 && document.frmRepairDetails.lstPriceType.value!="FPL_PLUS"){
				alert("Price Type must be FPL+ in case of Material Cost is 0 for Primary Site!");
				document.frmRepairDetails.lstPriceType.focus();
				
				
				var userResponse = confirm("Price Type must be FPL+ in case of Material Cost is 0 for Primary Site!");
			 	if(userResponse){
			 		document.frmRepairDetails.lstPriceType.value="FPL_PLUS";
			 	}else{
			 		return false;
			 	}
				return false;
			}
		}

*/
   //isPriceTypeQuote = document.frmRepairDetails.lstPriceType.options[document.frmRepairDetails.lstPriceType.selectedIndex].text=='QUOTE';
   if(document.frmRepairDetails.txtPrice.value !="" && isPriceTypeQuote && document.frmRepairDetails.hdnMandatoryPrice.value=="n")
   {
	   	alertMsgs("Price value should be empty, when Price Type is Quote");
      	document.frmRepairDetails.txtPrice.focus();
      	return false;
    }
   
   if(document.frmRepairDetails.hdnMandatoryPrice.value=="y"){
	var tempFlag ="";
		if(isPriceTypeQuote && document.frmRepairDetails.txtPrice.value != ""){  
				alert("Price value should be empty, when Price Type is Quote");
				//document.frmRepairDetails.hdnMandatoryPrice.value = "n";
				document.frmRepairDetails.hdnFlag.value="n";
				//document.frmRepairDetails.txtPrice.value="";
				document.frmRepairDetails.txtPrice.focus();
				document.getElementById("spanValue").innerHTML = "";
				
				
				/*var userResponse = confirm("You have selected QUOTE as Price Type, Price value should be empty.\n Want to continue?");
			 	if(userResponse){
			 	
			 		document.frmRepairDetails.hdnMandatoryPrice.value = "n";
					document.frmRepairDetails.txtPrice.value="";
					document.frmRepairDetails.txtPrice.focus();
					document.getElementById("spanValue").innerHTML = "";
				}else{
			 		document.frmRepairDetails.hdnMandatoryPrice.value = "y";
					document.frmRepairDetails.lstPriceType.focus();
					document.getElementById("spanValue").innerHTML = "*";
			 		return false;
			 	}*/
				return false;
		
	}else if(document.frmRepairDetails.txtPrice.value=="" && document.frmRepairDetails.lstPriceType.value !="QUOTE"){
	 alertMsgs(eCRDPriceIsEmpty);
	 	document.getElementById("spanValue").innerHTML = "*";
     	 document.frmRepairDetails.txtPrice.focus();
     	 return false;
		}
}
/*if(document.frmRepairDetails.txtPrice.value=="" && document.frmRepairDetails.lstPriceType.value !="QUOTE" && document.frmRepairDetails.hdnFlag.value != "n"){
	 alertMsgs(eCRDPriceIsEmpty);
    	 document.frmRepairDetails.txtPrice.focus();
    	 document.frmRepairDetails.hdnFlag.value = "";
    	 //document.frmRepairDetails.hdnMandatoryPrice.value = "y";
    	 document.getElementById("spanValue").innerHTML = "*";
    	 alert("3");
    	 return false;
		}*/
return true;
}

// This function is used to create new repair
function fnCreateNewRepair()
{

   if(document.frmRepairDetails.hdnRepairType.value=="IR" || document.frmRepairDetails.hdnRepairType.value=="SI")
   {
	if(fnRepairDetailValidation("Create"))
         {
	
            document.frmRepairDetails.hdnScreenAction.value = "eCRDCreateIndividualRepair";
            
            document.frmRepairDetails.hdnCheckIfRepairAdded.value = "true";
            
            document.frmRepairDetails.submit();
        }
   }
   /*Checking if the price is empty based on the flag value from db - Farid(502622936)*/
   /*if(document.frmRepairDetails.hdnMandatoryPrice=="y"){
  	 if(document.frmRepairDetails.txtPrice.value==""){    
      	 alertMsgs(eCRDPriceIsEmpty);
      	 document.frmRepairDetails.txtPrice.focus();
      	 return false;
       }
   }*/
   
   
   /*
  By 502622936 - CR006 - Checking if the price field should be mandatory or not based on flag value from db
   if(document.frmRepairDetails.hdnMandatoryPrice.value=="y"){
  	 //alert("value of mandatory flag for price field is : "+document.frmRepairDetails.hdnMandatoryPrice.value);
  	 if(document.frmRepairDetails.txtPrice.value==""){
  		 //alert("value of mandatory flag is inside level2: "+document.frmRepairDetails.hdnMandatoryPrice.value);
      	 alertMsgs(eCRDPriceIsEmpty);
      	 document.frmRepairDetails.txtPrice.focus();
      	 return false;
       }
   }	
   */
   if(document.frmRepairDetails.hdnRepairType.value=="PR" || document.frmRepairDetails.hdnRepairType.value=="SG")
   {
      if(fnRepairDetailValidation("Create"))
      {
    	  function isNumberKey(evt) {
    		    var charCode = (evt.which) ? evt.which : event.keyCode;
    		    if ((charCode > 47 && charCode < 58)||charCode==45||charCode==40||charCode==41||charCode==43||charCode==44||charCode==59||charCode==46)
    		        return true;
    	  	}  
    	  
    	  
    	  
    	  if(!fnValidateChildRepair(document.frmRepairDetails))
            {
                return false;
            }
            else
            {
               document.frmRepairDetails.hdnScreenAction.value = "eCRDCreateGroupedRepair";
               document.frmRepairDetails.hdnCheckIfRepairAdded.value = "true";
			   /* Patni 5-06-2006 Defect #77 For effective date to be uneditable Begin */
               document.frmRepairDetails.hdnStrFlag.value = "true";
               /* Patni 5-06-2006 Defect #77 For effective date to be uneditable End */
               document.frmRepairDetails.submit();   
            }
      }
  }
}

// This function is used to validate date
function fnValidateCalenderDate(objForm)
{
 	var sysFullDate = objForm.hdnSysDate.value;
   var dayVal = objForm.sel_man_Startdate_DD1.value;
   var monthVal = objForm.sel_man_Startdate_MM1.value;
   var yearVal = objForm.sel_man_Startdate_YYYY1.value;
   var fullDateVal = yearVal + "/" +monthVal  + "/"  + dayVal;
    if(Date.parse(fullDateVal)>Date.parse(sysFullDate))
    {       
       return false;
    }
    else
    { 
         return true;
    }
}

// This function is used to compare two dates
function fnCompareDateFromTo(start,end)
{
	if(Date.parse(start)>=Date.parse(end))
    {
        return true;         
    }
    else
    {
       return false;
         
    }
}

// This function is used to approve the repair
function fnApproveRepair()
{
	if(!fnRepairDetailValidation("Approve"))
	{
		return false;
	}
	if(document.frmRepairDetails.hdnRepairType.value=="PR")
	{
		if(!fnValidateChildRepair(document.frmRepairDetails))
		{
		  return false;
		}
	}
	if(fnLtrim(document.frmRepairDetails.txtRejectComm.value)!="")
	{
		alert("You can not enter rejection comments while approving.");
		return false;
	}
	document.frmRepairDetails.hdnScreenAction.value="eCRDApproveNewRepair";
        document.frmRepairDetails.submit();	
}

// This function is used to reject the repair
function fnRejectRepair()
{
	if(!fnRepairDetailValidation("RejectRepair"))
	{
		return false;
	}
	else
	{
		if(fnLtrim(document.frmRepairDetails.txtRejectComm.value)=="" || document.frmRepairDetails.txtRejectComm.value==null)
		{
		   alertMsgs(eCRDRejectComments);
		}
		else
		{
		   if(document.frmRepairDetails.txtRejectComm.value.length > 250)
		   {
		      alertMsgs(eCRDRejectLength);
		      document.frmRepairDetails.txtRejectComm.focus();
		      return false;
      		   }
	 	   document.frmRepairDetails.hdnScreenAction.value="eCRDRejectRepair";
	 	   document.frmRepairDetails.hdnScreenName.value="ApprCompDet";
   	 	   document.frmRepairDetails.submit();
   	 	}
	}
}

//Adding CSM Queue changes - kumar(502321240) - This fn is used to move repair to CSM queue
function fnMoveToCSMQueue()
{
	//alert("inside fnMoveToCSMQueue in js");
	if(!fnRepairDetailValidation("RejectRepair"))
	{
		return false;
	}
	else
	{
		if(fnLtrim(document.frmRepairDetails.txtRejectComm.value)=="" || document.frmRepairDetails.txtRejectComm.value==null)
		{
		   alertMsgs(eCRDCSMqComments);
		}
		else
		{
		   if(document.frmRepairDetails.txtRejectComm.value.length > 250)
		   {
		      alertMsgs(eCRDCSMCommentLength);
		      document.frmRepairDetails.txtRejectComm.focus();
		      return false;
      		   }
		   //alert("inside fnMoveToCSMQueue in js end...");
	 	   document.frmRepairDetails.hdnScreenAction.value= "eCRDMoveRepairToCSMQueue";
	 	   document.frmRepairDetails.hdnScreenName.value= "ApprCompDet";
   	 	   document.frmRepairDetails.submit();
   	 	}
	}
}
//Adding CSM Queue changes - kumar(502321240)
function fnMoveToApprovalQueue(strPrice,strTAT,strPriceType,strDisplaySeq,strFuturePrice,strFutureTat,strDay,strMonth,strYear,strIncrementalTat,strIncrementalPrice)
{
	//Updating the repair before moving to approval Queue
	   with(document.frmRepairDetails)
	   {     
	      document.frmRepairDetails.hdnTCModify.value="true";
	      /*if(document.frmRepairDetails.sel_man_Startdate_DD1!=null)
	      {
	                     if(strDay!="" && strMonth!="" && strYear!="")
	                     {
	                              var strDayChk=sel_man_Startdate_DD1[sel_man_Startdate_DD1.selectedIndex].value;
	                              var strMonthChk=sel_man_Startdate_MM1[sel_man_Startdate_MM1.selectedIndex].value;                  
	                              if(strDayChk.length==1)
	                              {
	                                 strDayChk="0"+strDayChk;
	                              }
	                              if(strDayChk!=strDay||strMonthChk!=strMonth||strYear!=sel_man_Startdate_YYYY1[sel_man_Startdate_YYYY1.selectedIndex].value)
	                              {
	                                 document.frmRepairDetails.hdnTCModify.value="false";
	                              }   
	                     } 
	                     else
	                     {
	                         var strDayChk=sel_man_Startdate_DD1.value;
	                         var strMonthChk=sel_man_Startdate_MM1.value; 
	                         var strYearChk=sel_man_Startdate_YYYY1.value;
	                           if(strDayChk!="" && strMonthChk!="" && strYearChk!="")
	                           {
	                                 document.frmRepairDetails.hdnTCModify.value="false";
	                           }                  
	                     }
	      }*/
	      //502622936 - CR0020
	      //IfPriceTypeQuote();
	      //checkPrimaryMaterial(document.frmRepairDetails); 
	      if(strIncrementalTat=="on")
	      {
	            if(!document.frmRepairDetails.chkIncrTime.checked)
	            {
	               document.frmRepairDetails.hdnTCModify.value="false";
	             } 
	      }
	      else
	      {
	            if(document.frmRepairDetails.chkIncrTime.checked)
	            {
	               document.frmRepairDetails.hdnTCModify.value="false";
	             } 
	 
	      }

	     if(strIncrementalPrice=="on")
	      {
	            if(!document.frmRepairDetails.chkIncPrice.checked)
	            {
	               document.frmRepairDetails.hdnTCModify.value="false";
	             } 
	      }
	      else
	      {
	            if(document.frmRepairDetails.chkIncPrice.checked)
	            {
	               document.frmRepairDetails.hdnTCModify.value="false";
	             } 
	 
	      }

	      if(strPrice!="" || txtPrice.value!="")
	      {
	         if(parseFloat(strPrice)!=parseFloat(txtPrice.value))
	         {
	            document.frmRepairDetails.hdnTCModify.value="false";
	         }
	      }

	      if(strDisplaySeq!="" || txtDisplaySeq.value!="")
	      {
	         if(parseFloat(strDisplaySeq)!=parseFloat(txtDisplaySeq.value))
	         {
	            document.frmRepairDetails.hdnTCModify.value="false";
	         }
	      }
	      /* Patni 29-May-2006 Begin Do not allow '0' in Display Seq Id*/	
			if(txtDisplaySeq.value == 0)
			{
				alert(eCRDDispSeqNonZero);
				txtDisplaySeq.focus();
				return false;
			}		
		  /* Patni 29-May-2006 End Do not allow '0' in Display Seq Id*/
	       if(strTAT!="" || txtTurnAround.value!="")
	      {
	            if(parseFloat(strTAT)!=parseFloat(txtTurnAround.value))
	            {
	               document.frmRepairDetails.hdnTCModify.value="false";
	            }
	      }      

	      if(document.frmRepairDetails.txtFuturePrice!=null)
	      {
	             if(strFuturePrice!="" || txtFuturePrice.value!="")
	            {
	               if(parseFloat(strFuturePrice)!=parseFloat(txtFuturePrice.value))
	               {
	                  document.frmRepairDetails.hdnTCModify.value="false";
	               }
	            }
	      }

	      if(document.frmRepairDetails.txtFutureTAT!=null)
	      {      
	            if(strFutureTat!="" || txtFutureTAT.value!="")
	            {
	               if(parseFloat(strFutureTat)!=parseFloat(txtFutureTAT.value))
	               {
	                  document.frmRepairDetails.hdnTCModify.value="false";
	               }
	            }
	      }

	      if(strPriceType!=lstPriceType[lstPriceType.selectedIndex].value)
	      {    
	            document.frmRepairDetails.hdnTCModify.value="false";
	      }   
	  }
	   if(fnRepairDetailValidation("Modify"))
	   {
		   
		   if(fnLtrim(document.frmRepairDetails.txtRejectComm.value)=="" || document.frmRepairDetails.txtRejectComm.value==null)
			{
			   alertMsgs(eCRDRejectComments);
			}
			else
			{
			   if(document.frmRepairDetails.txtRejectComm.value.length > 250)
			   {
			      alertMsgs(eCRDRejectLength);
			      document.frmRepairDetails.txtRejectComm.focus();
			      return false;
			   }
			   //alert("inside fnMoveToCSMQueue in js end...");
			   if(fnLtrim(document.frmRepairDetails.txtRejectComm.value)=="" || document.frmRepairDetails.txtRejectComm.value==null)
				{
				   alertMsgs(eCRDCSMqComments);
				   return false;
				}
			   else if(document.frmRepairDetails.txtRejectComm.value.length > 250)
				{
				      alertMsgs(eCRDCSMCommentLength);
				      document.frmRepairDetails.txtRejectComm.focus();
				      return false;		      	
		   	 	}else{
			   	 	if(document.frmRepairDetails.hdnRepairType.value=="PR" || document.frmRepairDetails.hdnRepairType.value=="SG" || document.frmRepairDetails.hdnRepairType.value=="MR")
				      {
				         if(!fnValidateChildRepair(document.frmRepairDetails))
				         {
				            return false;
				         }
				         else
				         {
				        	 document.frmRepairDetails.hdnScreenAction.value= "eCRDUpdateRepairInCSMQueue";
						 	 document.frmRepairDetails.hdnScreenName.value= "ModifyRepairDetail";
					   	 	 document.frmRepairDetails.submit();
				         }
				      }
				      else
				      {
				    	  document.frmRepairDetails.hdnScreenAction.value= "eCRDUpdateRepairInCSMQueue";
					 	  document.frmRepairDetails.hdnScreenName.value= "ModifyRepairDetail";
				   	 	  document.frmRepairDetails.submit();
				      }	
		   	 	}			   		   		 	  
			}	    
	   }
	   else
	   {
		   return false;
	   }	   
}


//Sushant start here
function fnPopRDOverride(objForm,basePath,childRowNumber) 
{
   var strRDNumber = objForm.txtRDNumber.value;
   var strRDReason = objForm.txtRDOverride.value;

	for(i=0; i<objForm.txtRDNumber.length; i++)
	{
		if (childRowNumber == i) {
			strRDNumber = objForm.txtRDNumber[i].value;
			strRDReason = objForm.txtRDOverride[i].value;
			break;
		}
	}
   if(objForm.txtRDNumber.length==""||objForm.txtRDNumber.length==null) {
	   childRowNumber = "";
   }

   features='toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,width=650,height=500';
   dlg = window.open (basePath+"/ecrd?hdnScreenName=AddRepair&hdnScreenAction=eCRDRDOverride&hdnRDNumber=" + strRDNumber + "&hdnRDReason=" + strRDReason + "&hdnChildRowNumber=" + childRowNumber +"&RandomValue="+Math.random(),"Dialog",features);
}

function fnChageRDNumber(objForm) 
{
   var strRDOverrideComment = objForm.selectRDOverrideComment[objForm.selectRDOverrideComment.selectedIndex].value;
   
   if(strRDOverrideComment == "RD Number not required" )
   {
	   objForm.txtRDOverrideNumber.value = "000-0000-00";
   }
   else{
   	   objForm.txtRDOverrideNumber.value = "";
   }
   return true;
}

function fnSubmitRDOverride(objForm) 
{
   	objForm.hdnRDReason.value = objForm.selectRDOverrideComment[objForm.selectRDOverrideComment.selectedIndex].value;

   	if(objForm.hdnRDReason.value== "-1" )
   	{
   		alert('Please Select Reason for RD Number Override');
   		return false;	
   	}

	objForm.hdnRDNumber.value = objForm.txtRDOverrideNumber.value;
	if(objForm.hdnRDNumber.value==""||objForm.hdnRDNumber.value== null)
   	{
   		alert('Please Enter RD Number');
   		return false;
   	}

	if(objForm.hdnRDNumber.value!="")
   	{
		if(!isRDNumber(objForm.hdnRDNumber.value) && objForm.hdnRDNumber.value !="000-0000-00"
			&& objForm.hdnRDNumber.value !=" 000-000-00")
	   	{
	   		alert('RD Number must be changed to nnn-nnn-xn/nnn-nnnn-xn format.');
	   		return false;
   		}
   	}

	   if(window.opener.document.frmRepairDetails!=null)
		{
		   if(objForm.hdnChildRowNumber.value==''||objForm.hdnChildRowNumber.value==null) {
		      window.opener.document.frmRepairDetails.txtRDNumber.value = fnConvUpperCase(objForm.hdnRDNumber.value);
		      window.opener.document.frmRepairDetails.txtRDOverride.value = objForm.hdnRDReason.value;
		   }
		   else {
		      window.opener.document.frmRepairDetails.txtRDNumber[objForm.hdnChildRowNumber.value].value = fnConvUpperCase(objForm.hdnRDNumber.value);
		      window.opener.document.frmRepairDetails.txtRDOverride[objForm.hdnChildRowNumber.value].value = objForm.hdnRDReason.value;
	      }
		}
   self.close();
}

function fnRDReasonValidate(objForm,basePath,childRowNumber)
{
	objForm.txtRDOverride.value = "";

	for(i=0; i<objForm.txtRDNumber.length; i++)
	{
		if (childRowNumber == i) {
			objForm.txtRDOverride[i].value = "";
			break;
		}
	}
}

function fnRDAssociationValidate(objForm,childRowNumber)
{
	if (objForm.hdnRDAssociation.value == "N") {
		if (objForm.txtRDNumber.value==""||objForm.txtRDNumber.value== null) {
			objForm.chkRDAssociation.checked = false;
			alert('RD Number can not be blank for child repair associated to parent repair.');
			return;
		}
		objForm.hdnRDAssociation.value = "Y";
		objForm.chkRDAssociation.checked = true;
		return;
	} else if(objForm.hdnRDAssociation.value == "Y") {
		objForm.hdnRDAssociation.value = "N";
		objForm.chkRDAssociation.checked = false;
		return;
	}

	if ((objForm.hdnRDAssociation[childRowNumber].value == "N") && 
		(objForm.txtRDNumber[childRowNumber].value==""||objForm.txtRDNumber[childRowNumber].value== null)) {
			objForm.chkRDAssociation[childRowNumber].checked = false;
			alert('RD Number can not be blank for child repair associated to parent repair.');
			return;
	}

	for(i=0; i<objForm.txtRDNumber.length; i++)
	{
		if (childRowNumber == i) {
			if (objForm.hdnRDAssociation[i].value == "N") {
				objForm.hdnRDAssociation[i].value = "Y";
				objForm.chkRDAssociation[i].checked = true;
			} else {
				objForm.hdnRDAssociation[i].value = "N";
				objForm.chkRDAssociation[i].checked = false;
			}
		} else{
				objForm.hdnRDAssociation[i].value = "N";
				objForm.chkRDAssociation[i].checked = false;
		}
	}
}

//function to populate RD Number from database in a popup window
function fnPopRDTable(objForm,basePath,childRowNumber)
{
	var strRDNumber = objForm.txtRDNumber.value;

	for(i=0; i<objForm.txtRDNumber.length; i++)
	{
		if (childRowNumber == i) {
			strRDNumber = objForm.txtRDNumber[i].value;
			break;
		}
	}
   if(objForm.txtRDNumber.length==""||objForm.txtRDNumber.length==null) {
	   childRowNumber = "";
   }

   if(strRDNumber=="" ||strRDNumber== null)
   {
      alert("Please Enter RD Number");
      return false;
   }
   features='toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,width=650,height=500';
   dlg = window.open (basePath+"/ecrd?hdnScreenName=AddRepair&hdnScreenAction=eCRDRDTable&hdnRDNumber=" + strRDNumber + "&hdnchildRowNumber=" + childRowNumber +"&RandomValue="+Math.random(),"Dialog",features);
}

// This function is used to submit RD table to form added by sushant
function fnSubmitRDTable(objForm)
{
   if(objForm.hdnRDNumber.value==""||objForm.hdnRDNumber.value== null)
   {
   		objForm.hdnRDNumber.focus = true;
   		alert('Please Select a RD Number');
   		return false;	
   }
   else{
	   if(window.opener.document.frmRepairDetails!=null)
		{
		   if(objForm.hdnchildRowNumber.value==''||objForm.hdnchildRowNumber.value==null) {
		      window.opener.document.frmRepairDetails.txtRDNumber.value = objForm.hdnRDNumber.value;
		   } 
		   else {
		      window.opener.document.frmRepairDetails.txtRDNumber[objForm.hdnchildRowNumber.value].value = objForm.hdnRDNumber.value;
	      }
		}
	}
   self.close();
}

// This function is used to get the RD Number Selected in the popup window
function fnGetRDNumber(RDNumber,objForm)
{
   if(objForm.hdnRDNumber.value != null)
   {
       objForm.hdnRDNumber.value = RDNumber;
   }
   
}

function isRDNumber(strRDNumber)
{
	strRDNumber = fnConvUpperCase(strRDNumber);

	if(!((strRDNumber.length ==10) || (strRDNumber.length ==11)))
	{

		return false;
	}

	if (!((strRDNumber.substring(strRDNumber.length-2,strRDNumber.length-1) =='S')
		|| (strRDNumber.substring(strRDNumber.length-2,strRDNumber.length-1) =='P')))
	{
		return false;
	}

	if(((strRDNumber.substring(3,4)!='-') || (strRDNumber.substring(7,8)!='-')
	||isNaN(strRDNumber.substring(0,3)) || isNaN(strRDNumber.substring(4,7))
	||isNaN(strRDNumber.substring(strRDNumber.length-1,strRDNumber.length))) && (strRDNumber.length ==10))
	{
		return false;
	}

	if(((strRDNumber.substring(3,4)!='-') || (strRDNumber.substring(8,9)!='-')
	||isNaN(strRDNumber.substring(0,3)) || isNaN(strRDNumber.substring(4,8))
	||isNaN(strRDNumber.substring(strRDNumber.length-1,strRDNumber.length))) && (strRDNumber.length ==11))
	{
		return false;
	}
   return true;
}
// addition End by Sushant

// This function is used to modify the repair
function fnModifyRepair(strPrice,strTAT,strPriceType,strDisplaySeq,strFuturePrice,strFutureTat,strDay,strMonth,strYear,strIncrementalTat,strIncrementalPrice)
{														

   with(document.frmRepairDetails)
   {     
      document.frmRepairDetails.hdnTCModify.value="true";
      if(document.frmRepairDetails.sel_man_Startdate_DD1!=null)
      {
                     if(strDay!="" && strMonth!="" && strYear!="")
                     {
                              var strDayChk=sel_man_Startdate_DD1[sel_man_Startdate_DD1.selectedIndex].value;
                              var strMonthChk=sel_man_Startdate_MM1[sel_man_Startdate_MM1.selectedIndex].value;                  
                              if(strDayChk.length==1)
                              {
                                 strDayChk="0"+strDayChk;
                              }
                              if(strDayChk!=strDay||strMonthChk!=strMonth||strYear!=sel_man_Startdate_YYYY1[sel_man_Startdate_YYYY1.selectedIndex].value)
                              {
                                 document.frmRepairDetails.hdnTCModify.value="false";
                              }   
                     } 
                     else
                     {
                         var strDayChk=sel_man_Startdate_DD1.value;
                         var strMonthChk=sel_man_Startdate_MM1.value; 
                         var strYearChk=sel_man_Startdate_YYYY1.value;
                           if(strDayChk!="" && strMonthChk!="" && strYearChk!="")
                           {
                                 document.frmRepairDetails.hdnTCModify.value="false";
                           }                  
                     }
      }
      
      
      if(strIncrementalTat=="on")
      {
            if(!document.frmRepairDetails.chkIncrTime.checked)
            {
               document.frmRepairDetails.hdnTCModify.value="false";
             } 
      }
      else
      {
            if(document.frmRepairDetails.chkIncrTime.checked)
            {
               document.frmRepairDetails.hdnTCModify.value="false";
             } 
 
      }

     if(strIncrementalPrice=="on")
      {
            if(!document.frmRepairDetails.chkIncPrice.checked)
            {
               document.frmRepairDetails.hdnTCModify.value="false";
             } 
      }
      else
      {
            if(document.frmRepairDetails.chkIncPrice.checked)
            {
               document.frmRepairDetails.hdnTCModify.value="false";
             } 
 
      }
     
     
     
   

      if(strPrice!="" || txtPrice.value!="")
      {
         if(parseFloat(strPrice)!=parseFloat(txtPrice.value))
         {
            document.frmRepairDetails.hdnTCModify.value="false";
         }
      }

      if(strDisplaySeq!="" || txtDisplaySeq.value!="")
      {
         if(parseFloat(strDisplaySeq)!=parseFloat(txtDisplaySeq.value))
         {
            document.frmRepairDetails.hdnTCModify.value="false";
         }
      }
      /* Patni 29-May-2006 Begin Do not allow '0' in Display Seq Id*/	
		if(txtDisplaySeq.value == 0)
		{
			alert(eCRDDispSeqNonZero);
			txtDisplaySeq.focus();
			return false;
		}		
	  /* Patni 29-May-2006 End Do not allow '0' in Display Seq Id*/
       if(strTAT!="" || txtTurnAround.value!="")
      {
            if(parseFloat(strTAT)!=parseFloat(txtTurnAround.value))
            {
               document.frmRepairDetails.hdnTCModify.value="false";
            }
      }      

      if(document.frmRepairDetails.txtFuturePrice!=null)
      {
             if(strFuturePrice!="" || txtFuturePrice.value!="")
            {
               if(parseFloat(strFuturePrice)!=parseFloat(txtFuturePrice.value))
               {
                  document.frmRepairDetails.hdnTCModify.value="false";
               }
            }
      }
if(document.frmRepairDetails.txtFutureTAT!=null)
      {      
            if(strFutureTat!="" || txtFutureTAT.value!="")
            {
               if(parseFloat(strFutureTat)!=parseFloat(txtFutureTAT.value))
               {
                  document.frmRepairDetails.hdnTCModify.value="false";
               }
            }
      }

      if(strPriceType!=lstPriceType[lstPriceType.selectedIndex].value)
      {    
            document.frmRepairDetails.hdnTCModify.value="false";
      }   
  }
   if(fnRepairDetailValidation("Modify"))
   {
      if(document.frmRepairDetails.hdnRepairType.value=="PR" || document.frmRepairDetails.hdnRepairType.value=="SG" || document.frmRepairDetails.hdnRepairType.value=="MR")
      {
         if(!fnValidateChildRepair(document.frmRepairDetails))
         {
            return false;
         }
         else
         {
           document.frmRepairDetails.hdnScreenAction.value="ecrdModifyRepairAction";
            document.frmRepairDetails.submit();
         }
      }
      else
      {
            document.frmRepairDetails.hdnScreenAction.value="ecrdModifyRepairAction";
            document.frmRepairDetails.submit();
      }
   }
}

// This function is used to show pricing information page
function fnShowPricingInfo()
{
   if(document.frmRepairDetails.chkPriceOverWriteInd.checked)
   {
         document.frmRepairDetails.hdnPriceOverWriteInd.value = "true";
         document.frmRepairDetails.hdnScreenAction.value = "eCRDShowPricingInfoEditable";
         document.frmRepairDetails.submit();
   }
   else
   {
   	if(confirm(eCRDUncheckPriceOverWriteInd))
   	{
         document.frmRepairDetails.hdnPriceOverWriteInd.value = "false";
         document.frmRepairDetails.hdnScreenAction.value = "eCRDShowPricingInfoEditable";
         document.frmRepairDetails.submit();
   	}
   	else
   	{
   		document.frmRepairDetails.chkPriceOverWriteInd.checked = true;
   		document.frmRepairDetails.hdnPriceOverWriteInd.value = "true";
   	}
   }
}

// This function is used to save pricing information
function fnSavePricingInfo()
{
   if(fnValidatePricingInfo())
   {
      document.frmRepairDetails.hdnScreenAction.value = "eCRDSavePricingInfo";
      document.frmRepairDetails.submit();
   }
}

// This function is used to validate pricing information
function fnValidatePricingInfo()
{
   var isPriceTypeQuote = false;
   var isEffDate = true;
   isPriceTypeQuote = document.frmRepairDetails.lstPriceType.options[document.frmRepairDetails.lstPriceType.selectedIndex].text=='QUOTE';
/*if(document.frmRepairDetails.txtTurnAround.value=="")
   {
      alertMsgs(eCRDempty +"Turn Around Time");
      document.frmRepairDetails.txtTurnAround.focus();
      return false;
   }*/
   if(document.frmRepairDetails.lstPriceType.selectedIndex==0)
   {
      alertMsgs(eCRDSelect+ " Price Type");
      document.frmRepairDetails.lstPriceType.focus();
      return false;
  }
   if(document.frmRepairDetails.txtPrice.value=="")
   {
      /*if(!isPriceTypeQuote)
      {
      	alertMsgs(eCRDempty +"Price");
      	document.frmRepairDetails.txtPrice.focus();
      	return false;
      }*/
   }
   else
   {
	 
   	if(isPriceTypeQuote)
      {
       		alertMsgs(eCRDQUOTEPrice);
      		document.frmRepairDetails.txtPrice.focus();
      		return false;
      }
      else
      {
      		/*if(parseFloat(document.frmRepairDetails.txtPrice.value)==0)
	        {
   		      alertMsgs(eCRDPrice);
	   	      document.frmRepairDetails.txtPrice.focus();
		         return false;
      		}*/
      }
   }
   if(isPriceTypeQuote)
   {
   	if(document.frmRepairDetails.chkIncPrice.checked)
   	{
   		alertMsgs(eCRDIncrPrice);
		   document.frmRepairDetails.txtPrice.focus();
		   return false;
   	}
   }
   if(document.frmRepairDetails.txtFuturePrice!=null)
   {
            if(document.frmRepairDetails.txtFuturePrice.value!="")
            {
               if(isPriceTypeQuote)
               {
                     alertMsgs(eCRDQUOTEPrice);
                     document.frmRepairDetails.txtFuturePrice.focus();
                     return false;
               }
               /*else
               {
                  if(parseFloat(document.frmRepairDetails.txtFuturePrice.value)==0)
                  {
                     alertMsgs(eCRDempty +"Future Price");
                     document.frmRepairDetails.txtFuturePrice.focus();
                     return false;
                  }
               }*/
               }
            /*if(document.frmRepairDetails.txtFutureTAT.value!="")
            {
               if(parseInt(document.frmRepairDetails.txtFutureTAT.value)==0)
               {
                  alertMsgs(eCRDempty +"Future TAT");
                  document.frmRepairDetails.txtFutureTAT.focus();
                  return false;
               }
            }*/
            if(parseFloat(document.frmRepairDetails.txtFuturePrice.value) >= 0 || parseInt(document.frmRepairDetails.txtFutureTAT.value) >= 0)
            {
               if(document.frmRepairDetails.sel_man_Startdate_DD1.value=="")
               {
                     alertMsgs(eCRDSelectFutureEffDate);
                     document.frmRepairDetails.sel_man_Startdate_DD1.focus();
                     return false;
               }
               if(document.frmRepairDetails.sel_man_Startdate_MM1.value=="")
               {
                     alertMsgs(eCRDSelectMonth);
                     document.frmRepairDetails.sel_man_Startdate_MM1.focus();
                     return false;
               }
               if(document.frmRepairDetails.sel_man_Startdate_YYYY1.value=="")
               {
                     alertMsgs(eCRDSelectYear);
                     document.frmRepairDetails.sel_man_Startdate_YYYY1.focus();
                     return false;
               }
            }
   }

   if(document.frmRepairDetails.chkIncrTime.checked)
   {
      document.frmRepairDetails.hdnIncrTime.value ="true";
   }
   else
   {
      document.frmRepairDetails.hdnIncrTime.value ="false";
   }
   if(document.frmRepairDetails.chkIncPrice.checked)
   {
      document.frmRepairDetails.hdnIncrPrice.value ="true";
   }
   else
   {
      document.frmRepairDetails.hdnIncrPrice.value ="false";
   }

   if(document.frmRepairDetails.txtFuturePrice!=null)
   {
            if(document.frmRepairDetails.sel_man_Startdate_DD1.value!="" && document.frmRepairDetails.sel_man_Startdate_MM1.value!="" && document.frmRepairDetails.sel_man_Startdate_YYYY1.value!="")
            {
         /*     if(document.frmRepairDetails.txtFuturePrice.value=="" &&  document.frmRepairDetails.txtFutureTAT.value=="")
                {
                     if(isPriceTypeQuote)
                     {
                        alertMsgs(eCRDempty + eCRDFutureTATCheck);
                        document.frmRepairDetails.txtFutureTAT.focus();
                        return false;
                     }
                     else
                     {
                           alertMsgs(eCRDempty + "Either " + eCRDFuturePriceCheck + " Or " +  eCRDFutureTATCheck);
                           document.frmRepairDetails.txtFuturePrice.focus();
                           return false;
                     }
               }*/
               dayVal = document.frmRepairDetails.sel_man_Startdate_DD1.value;
               monthVal = document.frmRepairDetails.sel_man_Startdate_MM1.value;
               yearVal = document.frmRepairDetails.sel_man_Startdate_YYYY1.value;
               fullDateVal = yearVal + "/" + monthVal + "/"  + dayVal;
               effDateVal = document.frmRepairDetails.hdnEffDate.value;
               isEffDate = document.frmRepairDetails.hdnBoolEffDate.value;

               if(fnCompareDateFromTo(document.frmRepairDetails.hdnRepairSysDate.value,fullDateVal))
               {
                  alertMsgs("Future"+eCRDEffectiveDate);
                  return false;
               }
               
               	if(fnCompareDateFromTo(effDateVal,fullDateVal))
               	{
                     alertMsgs(eCRDFutureEffDateCheck);
                     return false;
               	}
             }
   }
    return true;
}

// This function is usec to delete repair
function fnRemoveRepair()
{
	if(document.frmRepairDetails.hdnIsLastRepair.value == "Y")
	{
		if(confirm(eCRDConfirmLastRepairDelete))
		{
			document.frmRepairDetails.hdnScreenName.value="ModifyRepairDetail";
			document.frmRepairDetails.hdnScreenAction.value="eCRDDeleteRepair";
			document.frmRepairDetails.submit();
		}
	}
	else if(document.frmRepairDetails.hdnIsLastRepair.value == "D")
	{
		alertMsgs(eCRDDeletedRepair);
		return;
	}
	else
	{
		if(confirm(eCRDConfirmRepairDelete))
		{
		document.frmRepairDetails.hdnScreenName.value="ModifyRepairDetail";
		document.frmRepairDetails.hdnScreenAction.value="eCRDDeleteRepair";
		document.frmRepairDetails.submit();
		}
	}
}


function fnBackToRepairList(objForm)
{
	with(objForm)
	{
		objForm.hdnScreenAction.value = "eCRDShowComponentApprvRepairList";
		objForm.hdnScreenName.value = "eCRDManageComponent";
		submit();
	}
}

function fnSaveRepairDetails(objForm)
{
  	if(!fnRepairDetailValidation("Approve"))
	{
		return false;
	}
  if(document.frmRepairDetails.hdnRepairType.value=="PR")
   {
         if(!fnValidateChildRepair(document.frmRepairDetails))
         {
             return false;
         }
   }
		objForm.hdnScreenAction.value = "eCRDSaveRepair";
		objForm.hdnScreenName.value = "ecrdRepairDetail";
		objForm.submit();
}

function fnSaveMergeRepair()
{
	if(fnRepairDetailValidation("Merge"))
	{
		if(!fnValidateChildRepair(document.frmRepairDetails))
      {
	         return false;
      }
      else
      {
			document.frmRepairDetails.hdnScreenName.value="ecrdRepairDetail";
			document.frmRepairDetails.hdnScreenAction.value="eCRDSaveMergeRepair";
			document.frmRepairDetails.hdnFrom.value="MERGE";
			document.frmRepairDetails.submit();
		}
	}
}

function fnSplitContinueRepair()
{
	if(fnRepairDetailValidation("Split"))
	{
		document.frmRepairDetails.hdnScreenName.value="ecrdRepairDetail";
		document.frmRepairDetails.hdnScreenAction.value="eCRDSplitContinue";
		document.frmRepairDetails.hdnFrom.value="SPLIT";
		document.frmRepairDetails.submit();
	}
}

function fnCheckDecimalValue(strText)
{
	var strCheckArray = strText.split(".");
   if(strCheckArray.length > 2)
   {
      return false;
   }
   else
   {
      return true;
   }
}
// 15-06-2006 Patni added to handle the BACK button Begin 
function fnBackRepair()
{
document.frmRepairDetails.hdnScreenName.value="ApprCompDet";
document.frmRepairDetails.hdnScreenAction.value="eCRDGetApprovalRepairsList";
document.frmRepairDetails.submit();
}
// 15-06-2006 Patni added to handle the BACK button End 
/* SAP columns addition start Kumar */
function fnSelectSAPFlag(){
	var selectobj=document.frmRepairDetails.selectSapFlag;
	var optionsobj=selectobj.options[selectobj.selectedIndex].value;
	
	var	featurequantitytext=document.frmRepairDetails.txtSapFeatureQuantity;
	if (optionsobj == 'CP' || optionsobj == 'SR' ||optionsobj == 'DR'|| selectobj.selectedIndex==0) {
	
		featurequantitytext.value = "";
		featurequantitytext.readOnly= true;
    } else {
    	
    	featurequantitytext.readOnly = false;
    }
}
function fnSelectChildSapFlag(){
	var objForm = document.frmRepairDetails;	
	if(objForm.txtDisplaySequence.length==null)
	{
		if(objForm.selectChildSapFlag.options[objForm.selectChildSapFlag.selectedIndex].value == 'CP' ||
       		 objForm.selectChildSapFlag.options[objForm.selectChildSapFlag.selectedIndex].value == 'SR' ||
       		 objForm.selectChildSapFlag.options[objForm.selectChildSapFlag.selectedIndex].value == 'DR' ||
       		objForm.selectChildSapFlag.selectedIndex == 0)
        {
			
       	 objForm.txtChildSapFeatureQuantity.readOnly = true;  
       	 objForm.txtChildSapFeatureQuantity.value = "";
        }
        else{
        	
       	 objForm.txtChildSapFeatureQuantity.readOnly = false; 
        }
	}
	else
	{
		for(i=0; i<objForm.txtDisplaySequence.length; i++)
	    {
	         if(objForm.selectChildSapFlag[i].options[objForm.selectChildSapFlag[i].selectedIndex].value == 'CP' ||
	        		 objForm.selectChildSapFlag[i].options[objForm.selectChildSapFlag[i].selectedIndex].value == 'SR' ||
	        		 objForm.selectChildSapFlag[i].options[objForm.selectChildSapFlag[i].selectedIndex].value == 'DR' ||
	        		 objForm.selectChildSapFlag[i].selectedIndex == 0)	        	 
	         {
	        	 objForm.txtChildSapFeatureQuantity[i].readOnly = true;  
	        	 objForm.txtChildSapFeatureQuantity[i].value = "";
	         }
	         else{
	        	 objForm.txtChildSapFeatureQuantity[i].readOnly = false; 
	         }
	    }	
	}		
}
/* 502634089 */

function fnChangeModeOfRepair(strLinkServiceEngineer) {
	var dburl =strLinkServiceEngineer;


	var getElement = document.getElementById("selectModeOfRepair");

	var getElementValue = getElement.options[getElement.selectedIndex].value;
	if (getElementValue =="") {
		
		document.frmRepairDetails.url.value ="";
		document.getElementById('uri').style.display = 'none';
		document.getElementById('url').style.display = 'inline';
		document.frmRepairDetails.url.readOnly=true;
		document.getElementById('edited').style.display = 'none';
		document.getElementById('saved').style.display = 'none';
		
		return false;
	} else if (getElementValue =="M" && dburl =="") {
		
		

		document.frmRepairDetails.url.readOnly=false;
		document.getElementById('uri').style.display = 'none';
		document.getElementById('url').style.display = 'inline';
		document.getElementById('saved').style.display = 'inline';
		document.getElementById('edited').style.display = 'none';

	} else if (getElementValue =="NM") {
		document.frmRepairDetails.url.value = "";

		document.getElementById('uri').style.display = 'none';
		document.getElementById('url').style.display = 'inline';
		document.frmRepairDetails.url.readOnly=true;
		document.getElementById('saved').style.display = 'none';
		document.getElementById('edited').style.display = 'none';

	} else if (getElementValue =="M" && dburl !="") {
		
		document.frmRepairDetails.url.value = dburl;
		document.getElementById('uri').style.display = 'inline';
		document.getElementById('url').style.display = 'none';
		document.getElementById('saved').style.display = 'none';
		document.getElementById('edited').style.display = 'inline';

		if(dburl.indexOf("http")>-1){
			var str = dburl.link('dburl');
			var link = '';
			link = '<a href ="' + editedval + ' " target="_blank">' + editedval + '</a>'
			
			document.getElementById('uri').innerHTML = link;
			document.getElementById('saved').style.display = 'none';
			document.getElementById('edited').style.display = 'inline';
		}else {
		var str = dburl.link('dburl');
		var link = '';
	link = '<a href ="//' + editedval + ' " target="_blank">' + editedval + '</a>'

		document.getElementById('uri').innerHTML = link;
	document.getElementById('saved').style.display = 'none';
	document.getElementById('edited').style.display = 'inline';
		}
		
		
		document.getElementById('saved').style.display = 'none';
		document.getElementById('edited').style.display = 'inline';
		/*document.getElementById('edit').style.visibility = 'visible';*/

	}/*else if(getElementValue =="NM" && document.frmRepairDetails.uri.value !=""){
		var msg=prompt("selecting non-manual will lead to lose of link");
		if(msg!=null){
			document.frmRepairDetails.url.value = "";

			document.getElementById('uri').style.display = 'none';
			document.getElementById('url').style.display = 'inline';
			document.frmRepairDetails.url.readOnly=true;
			document.getElementById('saved').style.display = 'none';
			document.getElementById('edited').style.display = 'none';
			
		}
	}*/

}

function edit(strEngineServiceManual) {
	
	document.getElementById('edited').style.display = 'none';
	document.getElementById('saved').style.display = 'inline';
	document.getElementById('uri').style.display = 'none';
	document.getElementById('url').style.display = 'inline';
	
	var getElement = document.getElementById("selectModeOfRepair");
	var getElementValue = getElement.options[getElement.selectedIndex].value;

	var dburl =strEngineServiceManual;
	if (dburl != "" && getElementValue=="M") {
		var url = document.getElementById('uri').innerHTML;
		

		document.frmRepairDetails.url.value =dburl;
var editreadonly=document.frmRepairDetails.url;
            editreadonly.readOnly=false;
		document.getElementById('edited').style.display ='none';
		document.getElementById('saved').style.display = 'inline';
		

	} else if (getElementValue =="NM") {
		document.frmRepairDetails.url.value ="";
		document.frmRepairDetails.url.readOnly=true;
		document.getElementById('saved').style.display ='none';
		document.getElementById('edited').style.display ='none';

	}else if(getElementValue==""){
		document.getElementById('uri').innerHTML ="";
		document.getElementById('saved').style.display ='none';
		document.getElementById('edited').style.display ='none';
	}

}
function save() {
	var validateUrl= /^(http[s]?:\/\/){0,1}(www\.){0,1}[a-zA-Z0-9\.\-]+\.[a-zA-Z]{2,5}[\.]{0,1}/;
	
	var getElement = document.getElementById("selectModeOfRepair");
	var getElementValue = getElement.options[getElement.selectedIndex].value;
	var editedval=document.getElementById('url').value;
	
	

	if (editedval != "" && getElementValue == "M") {
		
		if(!(validateUrl.test(editedval))){
			document.getElementById('uri').style.display = 'none';
			document.getElementById('url').style.display = 'inline';
			document.getElementById('edited').style.display = 'none';
			document.getElementById('saved').style.display = 'inline';
			alert("please enter Link to view Engine Service Manual in the url format");
			document.frmRepairDetails.url.focus();
			return false;
		}else{
			document.getElementById('uri').style.display = 'inline';
			document.getElementById('edited').style.display = 'inline';
			document.getElementById('saved').style.display = 'none';
			document.getElementById('url').style.display = 'none';
			
			if(editedval.indexOf("http")>-1){
				var str = editedval.link('editedval');
				var link = '';
				link = '<a href ="' + editedval + ' " target="_blank">' + editedval + '</a>'
				
				document.getElementById('uri').innerHTML = link;
			}else {
		var str = editedval.link('editedval');
		var link = '';
		link = '<a href ="//' + editedval + ' " target="_blank">' + editedval + '</a>'
		
		document.getElementById('uri').innerHTML = link;
			}
		
		}

	} else if (getElementValue == "NM") {
		document.getElementById('uri').innerHTML ="";
		document.frmRepairDetails.url.value ="";
		var readonly1 =document.frmRepairDetails.url;
		alert(document.frmRepairDetails.url);
		readonly1.readOnly=true;
		document.getElementById('saved').style.display = 'none';
		document.getElementById('edited').style.display = 'none';
		
	}else if (getElementValue==""){
		document.getElementById('uri').innerHTML ="";
		document.frmRepairDetails.url.value ="";
		document.frmRepairDetails.url.readOnly=true;
		document.getElementById('saved').style.display = 'none';
		document.getElementById('edited').style.display = 'none';
	}
}


function fnSaveRepair()
{

   if(document.frmRepairDetails.hdnRepairType.value=="IR" || document.frmRepairDetails.hdnRepairType.value=="SI")
   {
	   
         if(fnRepairDetailValidationForSave())
         {
        	
        	 document.frmRepairDetails.hdnScreenAction.value = "eCRDCreateIndividualRepair";
             document.frmRepairDetails.hdnCheckIfRepairAdded.value = "true";
             document.frmRepairDetails.hdnsave.value="D";
             document.frmRepairDetails.submit();
            
        }
   }
   if(document.frmRepairDetails.hdnRepairType.value=="PR" || document.frmRepairDetails.hdnRepairType.value=="SG")
   {
      if(fnRepairDetailValidationForSave())
      {
           if(!fnValidateChildRepairForSave())
            {
                return false;
            }
            else
            {
               document.frmRepairDetails.hdnScreenAction.value = "eCRDCreateGroupedRepair";
               document.frmRepairDetails.hdnCheckIfRepairAdded.value = "true";
               document.frmRepairDetails.hdnsaved.value="D";
			   /* Patni 5-06-2006 Defect #77 For effective date to be uneditable Begin */
               document.frmRepairDetails.hdnStrFlag.value = "true";
               /* Patni 5-06-2006 Defect #77 For effective date to be uneditable End */
               document.frmRepairDetails.submit();   
            }
      }
  }
}


function fnRepairDetailValidationForSave()
{
	
 if(document.frmRepairDetails.txtRepairDescription.value=="")
   {
      alertMsgs(eCRDempty +"Repair Description");
      document.frmRepairDetails.txtRepairDescription.focus();
      return false;
   }
   
    if(document.frmRepairDetails.txtRepairDescription.value.length > 255)
   {
      alertMsgs(eCRDRepairDescLength);
      document.frmRepairDetails.txtRepairDescription.focus();
      return false;
   }
   if(!fnCheckSplChars(document.frmRepairDetails.txtRepairDescription))
   {
       document.frmRepairDetails.txtRepairDescription.focus();
       alertMsgs(eCRDSpecialChars + " For Repair Description");
 	    return false;
   }
if(document.frmRepairDetails.hdnRepairType.value=="IR")
   {
	   
	   if(!fnCheckRepairReferenceFormatForSave(document.frmRepairDetails.lstRepairReference,document.frmRepairDetails.txtRepairReference))
	      {
		   
	         return false;
	      }
   }
  if(document.frmRepairDetails.txtRepairComments.value!="")
   {
     
      if(document.frmRepairDetails.txtRepairComments.value.length>250)
      {
         document.frmRepairDetails.txtRepairComments.focus();
         alertMsgs(eCRDComments);
         return false;
      }
     
   }
	 /* if(document.frmRepairDetails.txtRDComments.value!="")
     {
         if(document.frmRepairDetails.txtRDComments.value.length >250)
         {
             document.frmRepairDetails.txtRDComments.focus();
             alertMsgs(eCRDComments);
             return false;
         }
     }*/
	   
	  if(document.frmRepairDetails.url.value !="")
	   {
	   
	   if(document.frmRepairDetails.url.value.length >1000)
	            {
	                document.frmRepairDetails.url.focus();
	                alertMsgs(eCRDComments);
	                return false;
	            }
	   }
	  
	  if(!fnValidateAddSitesForSave(document.frmRepairDetails,"Repair"))
	   {
	      return false;
	   }
	   return true;
   }


function fnValidateAddSitesForSave(objForm,strCheckAction)
{
   var strTotalCost="";
   var strCM = "";
   if(strCheckAction=="Sites")
   {
      if(objForm.txtMatCost.length)
      {
         if(objForm.lstSite[0].length -1 == objForm.txtMatCost.length)
         {
            alertMsgs(eCRDMaxRepairSites);
            return false;
         }
      }
      else
      {
         if(objForm.lstSite.length==2)
         {
            alertMsgs(eCRDMaxRepairSites);
            return false;
         }
      }
   }
   if(!objForm.txtMatCost.length)
   {
      if(objForm.lstSite.selectedIndex !=0)
      {
      
      if(objForm.txtMatCost.value=="")
      {
         alertMsgs(eCRDempty + "Material Cost");
         objForm.txtMatCost.focus();
         return false;
     }
     if(isNaN(objForm.txtMatCost.value))
     {
         alertMsgs("Material Cost "+eCRDNotNumeric);
         objForm.txtMatCost.select();
         objForm.txtMatCost.focus();
         return false;
     }
     if(objForm.txtLabourHrs.value=="")
     {
         alertMsgs(eCRDempty + " Labour Hours");
         objForm.txtLabourHrs.focus();
         return false;
      }
      if(isNaN(objForm.txtLabourHrs.value))
      {
         alertMsgs("Labour Hours "+eCRDNotNumeric);
         objForm.txtLabourHrs.select();
         objForm.txtLabourHrs.focus();
         return false;
      }
      fnCalculate(objForm);
   }
   }
   else
   {
      for(i=0; i<objForm.txtMatCost.length; i++)
      {
         //if(objForm.lstSite[i].selectedIndex ==0)
         if(objForm.lstSite[i].value != "")
         {
            
         
         for(k=0; k<objForm.txtMatCost.length; k++)
         {
            for(j=k+1;j<objForm.txtMatCost.length;j++)
            {
                  //if(objForm.lstSite[k].options[objForm.lstSite[k].selectedIndex].value ==objForm.lstSite[j].options[objForm.lstSite[j].selectedIndex].value)
                  if(objForm.lstSite[k].value ==objForm.lstSite[j].value)
                  {
                        alertMsgs(eCRDUniqueRepairSite);
                        objForm.lstSite[j].focus();
                        return false;
                  } 
             }
         }
         if(objForm.txtMatCost[i].value=="")
         {
               alertMsgs(eCRDempty + " Material Cost");
               objForm.txtMatCost[i].focus();
               return false;
         }
         if(isNaN(objForm.txtMatCost[i].value))
         {
            alertMsgs("Material Cost "+eCRDNotNumeric);
            objForm.txtMatCost[i].select();
            objForm.txtMatCost[i].focus();
            return false;
         }
         if(objForm.txtLabourHrs[i].value=="")
         {
            alertMsgs(eCRDempty + " Labour Hours");
            objForm.txtLabourHrs[i].focus();
            return false;
         }
         if(isNaN(objForm.txtLabourHrs[i].value))
         {
            alertMsgs("Labour Hours "+eCRDNotNumeric);
            objForm.txtLabourHrs[i].select();
            objForm.txtLabourHrs[i].focus();
            return false;
         }
         fnCalculate(objForm);
      }
   }
   }
   return true;   
}

function fnCheckRepairReferenceFormatForSave(format,RepairfieldValue)
{
   fieldFormat =format.options[format.selectedIndex].text;
   RepairfieldValue.value = fnConvUpperCase(RepairfieldValue.value);
   fieldValue = RepairfieldValue.value;
   if(!fnValidateRepairRefFormatForSave(fnConvUpperCase(fieldFormat),fieldValue,RepairfieldValue))
   {
	   
      return false;
   }
   
   return true;
}

function fnValidateRepairRefFormatForSave(fieldFormat,fieldValue,field)
{
   if(fnIsNotEmpty(fieldValue))
	{
		if(fieldFormat!="OTHERS")
		{
			if(!(fieldFormat.length == fieldValue.length))
		   {
	   		alert("Please enter the value in "+fieldFormat+" format");
            field.focus();
	   		return false;
		   }
   		for(var i = 0 ;i<fieldFormat.length;i++)
	   	{
   			check = fieldValue.charAt(i);
				if(fieldFormat.charAt(i)=='X')
				{
   				if (!(((check >='a')&&(check <='z'))||((check >='A')&&(check <='Z'))||((check >='0')&&(check <='9'))))
					{
						alert("Please enter the value in "+fieldFormat+" format");
                  field.focus();
						return false;
					}
				}
				else
				{
					if(check != fieldFormat.charAt(i))
					{
							alert("Please enter the value in "+fieldFormat+" format");
                     field.focus();
							return false;
					}
				}
			}
		}
		//else
	}
  
   return true;
}

function fnValidateChildRepairForSave()
{
   if(document.frmRepairDetails.txtDisplaySequence.length==null)
   {
      if(document.frmRepairDetails.txtDisplaySequence.value=="")
      {
         alertMsgs(eCRDempty +"Display Sequence Id");
         document.frmRepairDetails.txtDisplaySequence.select();
         document.frmRepairDetails.txtDisplaySequence.focus();
         return false;
      }
     	
	  /* Patni 29-May-2006 End Do not allow '0' in Display Seq Id*/
      if(isNaN(document.frmRepairDetails.txtDisplaySequence.value))
      {
         alertMsgs("Display Sequence Id "+eCRDNotNumeric);
         document.frmRepairDetails.txtDisplaySequence.select();
         document.frmRepairDetails.txtDisplaySequence.focus();
         return false;
      }
      if(document.frmRepairDetails.txtDisplaySequence.value.indexOf("-")!=-1)
      {
            alertMsgs(eCRDCheckValue);
            document.frmRepairDetails.txtDisplaySequence.focus();
            return false;
      }

      if(document.frmRepairDetails.txtRepairDesc.value=="")
      {
         alertMsgs(eCRDempty +"Repair Description");
         document.frmRepairDetails.txtRepairDesc.select();
         document.frmRepairDetails.txtRepairDesc.focus();
         return false;
      }
      //SAP feature quantity validation for child repairs added by Kumar
      if(document.frmRepairDetails.selectChildSapFlag.selectedIndex==0 && document.frmRepairDetails.txtChildSapFeatureQuantity.value != '')
     {
         alertMsgs("SAP feature quantity is needed only if SAP Flag type is IF or FR");        
         document.frmRepairDetails.txtChildSapFeatureQuantity.value = "";
         document.frmRepairDetails.txtChildSapFeatureQuantity.focus();
         return false;
      }
   
     /* if(document.frmRepairDetails.txtRDNumber.value != '' && getElementValue=="M"){
    	   alertMsgs("RD Number is not required if Mode of Repair is Manual");
           //document.frmRepairDetails.txtRDNumber.value="";
          document.frmRepairDetails.txtRDNumber.focus();
     	  return false;
       }*/
        if(document.frmRepairDetails.txtRepairDesc.value.length > 255)
      {
         alertMsgs(eCRDRepairDescLength);
         document.frmRepairDetails.txtRepairDesc.select();
         document.frmRepairDetails.txtRepairDesc.focus();
         return false;
      }
    

      if(!fnCheckSplChars(document.frmRepairDetails.txtRepairDesc))
      {
         document.frmRepairDetails.txtRepairDesc.focus();
         alertMsgs(eCRDSpecialChars + " For Repair Description");
         return false;
      }
      if(document.frmRepairDetails.lstRepairFormat.selectedIndex!=0)
      {
         if(!fnCheckRepairReferenceFormat(document.frmRepairDetails.lstRepairFormat,document.frmRepairDetails.txtRepairFormat))
         {
            return false;
         }
      }
      if(document.frmRepairDetails.txtComments.value!="")
      {
         if(!fnCheckSplChars(document.frmRepairDetails.txtComments))
         {
            document.frmRepairDetails.txtComments.focus();
            alertMsgs(eCRDSpecialChars + " For Repair Comments");
            return false;
         }
         if(document.frmRepairDetails.txtComments.value.length>250)
         {
            document.frmRepairDetails.txtComments.focus();
            alertMsgs(eCRDComments);
            return false;
         }
      }

      if(!document.frmRepairDetails.lstRepairFormat.selectedIndex==0 || document.frmRepairDetails.txtRepairFormat.value!="")
      {
               if(document.frmRepairDetails.lstRepairFormat.selectedIndex==0 && document.frmRepairDetails.txtRepairFormat.value!="")
               {
                  alertMsgs(eCRDSelect+ " Repair Reference Format");
                  document.frmRepairDetails.lstRepairFormat.focus();
                   return false;
               }

               if(!document.frmRepairDetails.lstRepairFormat.selectedIndex==0 && document.frmRepairDetails.txtRepairFormat.value =="")
               {
                  alertMsgs(eCRDempty +"Repair Reference");
                  document.frmRepairDetails.txtRepairFormat.focus();
                   return false;
               }
               if(!fnCheckRepairReferenceFormat(document.frmRepairDetails.lstRepairFormat,document.frmRepairDetails.txtRepairFormat))
               {
                     document.frmRepairDetails.txtRepairFormat.focus();
                    return false;
               }
       }

      if(document.frmRepairDetails.txtRDComments.value!="")
      {
         if(!fnCheckSplChars(document.frmRepairDetails.txtRDComments))
         {
            document.frmRepairDetails.txtRDComments.focus();
            alertMsgs(eCRDSpecialChars + " For RD Number Comments");
            return false;
         }
         if(document.frmRepairDetails.txtRDComments.value.length>250)
         {
            document.frmRepairDetails.txtRDComments.focus();
            alertMsgs(eCRDComments);
            return false;
         }
      }
   }
   else
   {
	   for(i=0; i<document.frmRepairDetails.txtDisplaySequence.length; i++)
      {
           if(document.frmRepairDetails.txtDisplaySequence[i].value=="")
           {
              alertMsgs(eCRDempty +"Display Sequence Id");
              document.frmRepairDetails.txtDisplaySequence[i].select();
              document.frmRepairDetails.txtDisplaySequence[i].focus();
              return false;
           }
      /* Patni 29-May-2006 Begin Do not allow '0' in Display Seq Id*/	
			if(document.frmRepairDetails.txtDisplaySequence[i].value == 0)
			{
				alert(eCRDDispSeqNonZero);
				document.frmRepairDetails.txtDisplaySequence[i].focus();
				return false;
			}		
	  /* Patni 29-May-2006 End Do not allow '0' in Display Seq Id*/
           if(isNaN(document.frmRepairDetails.txtDisplaySequence[i].value))
           {
               alertMsgs("Display Sequence Id "+eCRDNotNumeric);
               document.frmRepairDetails.txtDisplaySequence[i].select();
               document.frmRepairDetails.txtDisplaySequence[i].focus();
               return false;
           }
      if(document.frmRepairDetails.txtDisplaySequence[i].value.indexOf("-")!=-1)
      {
            alertMsgs(eCRDCheckValue);
            document.frmRepairDetails.txtDisplaySequence[i].focus();
            return false;
      }

      }
      for(i=0; i<document.frmRepairDetails.txtDisplaySequence.length; i++)
      {
            for(j=i+1;j<document.frmRepairDetails.txtDisplaySequence.length;j++)
            {
                  if(document.frmRepairDetails.txtDisplaySequence[i].value ==document.frmRepairDetails.txtDisplaySequence[j].value)
                  {
                        alertMsgs(eCRDDispSeqIdNotUnique);
                        document.frmRepairDetails.txtDisplaySequence[j].select();
                        document.frmRepairDetails.txtDisplaySequence[j].focus();
                        return false;
                  } 
            }
       }
      for(i=0; i<document.frmRepairDetails.txtRepairDesc.length; i++)
      {
            for(j=i+1;j<document.frmRepairDetails.txtRepairDesc.length;j++)
            {
                  if(fnTrim(document.frmRepairDetails.txtRepairDesc[i].value) ==fnTrim(document.frmRepairDetails.txtRepairDesc[j].value))
                  {
                        alertMsgs(eCRDRepairDescNotUnique);
                        document.frmRepairDetails.txtRepairDesc[j].select();
                        document.frmRepairDetails.txtRepairDesc[j].focus();
                        return false;
                  } 
            }
       }
      for(i=0; i<document.frmRepairDetails.txtDisplaySequence.length; i++)
      {
           if(document.frmRepairDetails.txtRepairDesc[i].value=="")
           {
               alertMsgs(eCRDempty +"Repair Description");
               document.frmRepairDetails.txtRepairDesc[i].select();
               document.frmRepairDetails.txtRepairDesc[i].focus();
               return false;
           }
           if(!fnCheckSplChars(document.frmRepairDetails.txtRepairDesc[i]))
           {
               document.frmRepairDetails.txtRepairDesc[i].focus();
               alertMsgs(eCRDSpecialChars + " For Repair Description");
               return false;
            }
            if(document.frmRepairDetails.txtRepairDesc[i].value.length > 255)
            {
               alertMsgs(eCRDRepairDescLength);
               document.frmRepairDetails.txtRepairDesc[i].select();
               document.frmRepairDetails.txtRepairDesc[i].focus();
               return false;
            }

      }
      for(i=0; i<document.frmRepairDetails.txtDisplaySequence.length; i++)
      {
         if(document.frmRepairDetails.lstRepairFormat[i].selectedIndex!=0)
         {
            if(!fnCheckRepairReferenceFormat(document.frmRepairDetails.lstRepairFormat[i],document.frmRepairDetails.txtRepairFormat[i]))
            {
               return false;
            }
         }
      }
      //SAP feature quantity validation for child repairs added by Kumar    
      for(i=0; i<document.frmRepairDetails.txtDisplaySequence.length; i++)
      {
           if(document.frmRepairDetails.selectChildSapFlag[i].selectedIndex==0 && document.frmRepairDetails.txtChildSapFeatureQuantity[i].value != '')
           {
        	   alertMsgs("SAP feature quantity is needed only if SAP Flag type is IF or FR"); 
        	   document.frmRepairDetails.txtChildSapFeatureQuantity[i].value = "";
        	   document.frmRepairDetails.txtChildSapFeatureQuantity[i].focus();
               return false;
           }          

      }

    
      
      for(i=0; i<document.frmRepairDetails.txtDisplaySequence.length; i++)
      {
         if(document.frmRepairDetails.txtComments[i].value!="")
         {
            if(!fnCheckSplChars(document.frmRepairDetails.txtComments[i]))
            {
               document.frmRepairDetails.txtComments[i].focus();
               alertMsgs(eCRDSpecialChars + " For Repair Comments");
               return false;
            }
            if(document.frmRepairDetails.txtComments[i].value.length>250)
            {
               document.frmRepairDetails.txtComments[i].focus();
               alertMsgs(eCRDComments);
               return false;
            }
         }   
            if(!document.frmRepairDetails.lstRepairFormat[i].selectedIndex==0 || document.frmRepairDetails.txtRepairFormat[i].value!="")
            {
                     if(document.frmRepairDetails.lstRepairFormat[i].selectedIndex==0 && document.frmRepairDetails.txtRepairFormat[i].value!="")
                     {
                        alertMsgs(eCRDSelect+ " Repair Reference Format");
                        document.frmRepairDetails.lstRepairFormat[i].focus();
                         return false;
                     }

                     if(!document.frmRepairDetails.lstRepairFormat[i].selectedIndex==0 && document.frmRepairDetails.txtRepairFormat[i].value =="")
                     {
                        alertMsgs(eCRDempty +"Repair Reference");
                        document.frmRepairDetails.txtRepairFormat[i].focus();
                         return false;
                     }
                     if(!fnCheckRepairReferenceFormat(document.frmRepairDetails.lstRepairFormat[i],document.frmRepairDetails.txtRepairFormat[i]))
                     {
                           document.frmRepairDetails.txtRepairFormat[i].focus();
                          return false;
                     }
             }
         
      }

      for(i=0; i<document.frmRepairDetails.txtDisplaySequence.length; i++)
      {
         if(document.frmRepairDetails.txtRDComments[i].value!="")
         {
            if(!fnCheckSplChars(document.frmRepairDetails.txtRDComments[i]))
            {
               document.frmRepairDetails.txtRDComments[i].focus();
               alertMsgs(eCRDSpecialChars + " For RD Number Comments");
               return false;
            }
            if(document.frmRepairDetails.txtRDComments[i].value.length>250)
            {
               document.frmRepairDetails.txtRDComments[i].focus();
               alertMsgs(eCRDComments);
               return false;
            }
         }
      }
   }
   return true;
}
   function fnCheckRepairReferenceFormat(format,RepairfieldValue)
{
   fieldFormat =format.options[format.selectedIndex].text;
   RepairfieldValue.value = fnConvUpperCase(RepairfieldValue.value);
   fieldValue = RepairfieldValue.value;
   if(!fnValidateRepairRefFormat(fnConvUpperCase(fieldFormat),fieldValue,RepairfieldValue))
   {
	   
      return false;
   }
   
   return true;
}
   
   function fnModifyDraftRepair(strPrice,strTAT,strPriceType,strDisplaySeq,strFuturePrice,strFutureTat,strDay,strMonth,strYear,strIncrementalTat,strIncrementalPrice)
   {									

      with(document.frmRepairDetails)
      {     
         document.frmRepairDetails.hdnTCModify.value="true";
         if(document.frmRepairDetails.sel_man_Startdate_DD1!=null)
         {
                        if(strDay!="" && strMonth!="" && strYear!="")
                        {
                                 var strDayChk=sel_man_Startdate_DD1[sel_man_Startdate_DD1.selectedIndex].value;
                                 var strMonthChk=sel_man_Startdate_MM1[sel_man_Startdate_MM1.selectedIndex].value;                  
                                 if(strDayChk.length==1)
                                 {
                                    strDayChk="0"+strDayChk;
                                 }
                                 if(strDayChk!=strDay||strMonthChk!=strMonth||strYear!=sel_man_Startdate_YYYY1[sel_man_Startdate_YYYY1.selectedIndex].value)
                                 {
                                    document.frmRepairDetails.hdnTCModify.value="false";
                                 }   
                        } 
                        else
                        {
                            var strDayChk=sel_man_Startdate_DD1.value;
                            var strMonthChk=sel_man_Startdate_MM1.value; 
                            var strYearChk=sel_man_Startdate_YYYY1.value;
                              if(strDayChk!="" && strMonthChk!="" && strYearChk!="")
                              {
                                    document.frmRepairDetails.hdnTCModify.value="false";
                              }                  
                        }
         }
         
         
         if(strIncrementalTat=="on")
         {
               if(!document.frmRepairDetails.chkIncrTime.checked)
               {
                  document.frmRepairDetails.hdnTCModify.value="false";
                } 
         }
         else
         {
               if(document.frmRepairDetails.chkIncrTime.checked)
               {
                  document.frmRepairDetails.hdnTCModify.value="false";
                } 
    
         }

        if(strIncrementalPrice=="on")
         {
               if(!document.frmRepairDetails.chkIncPrice.checked)
               {
                  document.frmRepairDetails.hdnTCModify.value="false";
                } 
         }
         else
         {
               if(document.frmRepairDetails.chkIncPrice.checked)
               {
                  document.frmRepairDetails.hdnTCModify.value="false";
                } 
    
         }
        
        
        
      

         if(strPrice!="" || txtPrice.value!="")
         {
            if(parseFloat(strPrice)!=parseFloat(txtPrice.value))
            {
               document.frmRepairDetails.hdnTCModify.value="false";
            }
         }

         if(strDisplaySeq!="" || txtDisplaySeq.value!="")
         {
            if(parseFloat(strDisplaySeq)!=parseFloat(txtDisplaySeq.value))
            {
               document.frmRepairDetails.hdnTCModify.value="false";
            }
         }
         /* Patni 29-May-2006 Begin Do not allow '0' in Display Seq Id*/	
   	/*	if(txtDisplaySeq.value == 0)
   		{
   			alert(eCRDDispSeqNonZero);
   			txtDisplaySeq.focus();
   			return false;
   		}	*/	
   	  /* Patni 29-May-2006 End Do not allow '0' in Display Seq Id*/
          if(strTAT!="" || txtTurnAround.value!="")
         {
               if(parseFloat(strTAT)!=parseFloat(txtTurnAround.value))
               {
                  document.frmRepairDetails.hdnTCModify.value="false";
               }
         }      

         if(document.frmRepairDetails.txtFuturePrice!=null)
         {
                if(strFuturePrice!="" || txtFuturePrice.value!="")
               {
                  if(parseFloat(strFuturePrice)!=parseFloat(txtFuturePrice.value))
                  {
                     document.frmRepairDetails.hdnTCModify.value="false";
                  }
               }
         }
   if(document.frmRepairDetails.txtFutureTAT!=null)
         {      
               if(strFutureTat!="" || txtFutureTAT.value!="")
               {
                  if(parseFloat(strFutureTat)!=parseFloat(txtFutureTAT.value))
                  {
                     document.frmRepairDetails.hdnTCModify.value="false";
                  }
               }
         }

         if(strPriceType!=lstPriceType[lstPriceType.selectedIndex].value)
         {    
               document.frmRepairDetails.hdnTCModify.value="false";
         }   
     }
       if(fnRepairDetailValidationForSave())
      {
         if(document.frmRepairDetails.hdnRepairType.value=="PR" || document.frmRepairDetails.hdnRepairType.value=="SG" || document.frmRepairDetails.hdnRepairType.value=="MR")
         {
            if(!fnValidateChildRepairForSave())
            {
               return false;
            }
            else
            {
            	document.frmRepairDetails.hdnsaved.value="D";
            	document.frmRepairDetails.hdnStagingIndValue.value="D";
              document.frmRepairDetails.hdnScreenAction.value="ecrdModifyRepairAction";
               document.frmRepairDetails.submit();
            }
         }
         else
         {
        	 document.frmRepairDetails.hdnsave.value="D";
        	   document.frmRepairDetails.hdnStagingIndValue.value="D";
               document.frmRepairDetails.hdnScreenAction.value="ecrdModifyRepairAction";
               document.frmRepairDetails.submit();
         }
      }
   }
   
   function fnCreateNewRepairForSaved()
   {

      if(document.frmRepairDetails.hdnRepairType.value=="IR" || document.frmRepairDetails.hdnRepairType.value=="SI")
      {
   	if(fnRepairDetailValidation("Create"))
            {
   		/*alert("in cerate function");*/
               document.frmRepairDetails.hdnScreenAction.value = "eCRDCreateIndividualRepair";
               document.frmRepairDetails.hdnFrom.value="AddRepair";
               document.frmRepairDetails.hdnCheckIfRepairAdded.value = "true";
               document.frmRepairDetails.hdnAddrepair.value = "A"; 
               document.frmRepairDetails.submit();
           }
      }
      /*Checking if the price is empty based on the flag value from db - Farid(502622936)*/
      /*if(document.frmRepairDetails.hdnMandatoryPrice=="y"){
     	 if(document.frmRepairDetails.txtPrice.value==""){    
         	 alertMsgs(eCRDPriceIsEmpty);
         	 document.frmRepairDetails.txtPrice.focus();
         	 return false;
          }
      }*/
      
      
      /*
     By 502622936 - CR006 - Checking if the price field should be mandatory or not based on flag value from db
      if(document.frmRepairDetails.hdnMandatoryPrice.value=="y"){
     	 //alert("value of mandatory flag for price field is : "+document.frmRepairDetails.hdnMandatoryPrice.value);
     	 if(document.frmRepairDetails.txtPrice.value==""){
     		 //alert("value of mandatory flag is inside level2: "+document.frmRepairDetails.hdnMandatoryPrice.value);
         	 alertMsgs(eCRDPriceIsEmpty);
         	 document.frmRepairDetails.txtPrice.focus();
         	 return false;
          }
      }	
      */
      if(document.frmRepairDetails.hdnRepairType.value=="PR" || document.frmRepairDetails.hdnRepairType.value=="SG")
      {
         if(fnRepairDetailValidation("Create"))
         {
               if(!fnValidateChildRepair(document.frmRepairDetails))
               {
                   return false;
               }
               else
               {
                  document.frmRepairDetails.hdnScreenAction.value = "eCRDCreateGroupedRepair";
                  document.frmRepairDetails.hdnFrom.value="AddRepair";
                  document.frmRepairDetails.hdnCheckIfRepairAdded.value = "true";
   			   /* Patni 5-06-2006 Defect #77 For effective date to be uneditable Begin */
                  document.frmRepairDetails.hdnStrFlag.value = "true";
                  document.frmRepairDetails.hdnAddrepair.value = "A"; 
                  /* Patni 5-06-2006 Defect #77 For effective date to be uneditable End */
                  document.frmRepairDetails.submit();   
               }
         }
     }
   }
   
  


function checkSAPFeatureQuantity(){	
	fnSelectSAPFlag();
	fnSelectChildSapFlag();
}
window.onload = checkSAPFeatureQuantity;
/* SAP columns addition end*/
 