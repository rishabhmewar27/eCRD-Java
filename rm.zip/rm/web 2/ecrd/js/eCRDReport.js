/* Search functionality for Customer Adhoc Changes -Prathima*/

function fnSearchCheckForMandatory(objForm)
{
	//alert("Inside search form"+objForm);
	//String[] values = null;
	 if(objForm.lstEngModel.selectedIndex == 0)
		{
		 alertMsgs(eCRDSelEngModel);
		  objForm.lstEngModel.focus();
			return false;
		}
/*	if(objForm.lstEngModel.options[objForm.lstEngModel.selectedIndex].value == "")
  	{
      alertMsgs(eCRDSelEngModel);
	  objForm.lstEngModel.focus();
      return false;
  	}*/
	else if(objForm.txtCustCode.value=="")
	   {
		// alertMsgs(eCRDemptyCustomer);
		 alertMsgs(eCRDBlankCustomer);
	       objForm.txtCustCode.select();
	       objForm.txtCustCode.focus();
	       return false;  
	   }
	else
		{
		//alert("Inside search form action");
		objForm.hdnScreenAction.value 	="eCRDCustomerCatalogListingRC";
		//objForm.hdnScreenName.value 	= "eCRDReports";
		//alert("Inside search form action"+objForm.hdnScreenName.value);
		//values = objForm2.chk_SelCol.value;
		//System.out.println("Check Box values in ecrdReport.js"+values);
		objForm.submit();
		}

}

 /* Search functionality for Customer Adhoc Changes END -Prathima*/
/* cust adhoc changes --Prathima*/
function fnpopCustTableReport(basePath)
{
	if(document.frmViewReports1 != null)
	{
		objForm = document.frmViewReports1;
	} 
	/** Start Adding for Security Checks*/
   if(!fnCheckSplChars(objForm.txtCustCode)){
 	   alertMsgs(eCRDSpecialChars);
	   return false;
   }
   /** End Here*/	
   if(objForm.txtCustCode.value.length<3)
   {
       alertMsgs(eCRDBlankCustomer);
       objForm.txtCustCode.select();
       objForm.txtCustCode.focus();
       return false;  
   }

   var strFindCust = objForm.txtCustCode.value;
   //var strEngModel = objForm.lstEngModel.value;
   var strEngModel = objForm.lstEngModel.options[objForm.lstEngModel.selectedIndex].value;
   //alert("Engine Model"+strEngModel);
   var strActive='';
   if(objForm.hdnOnlyActive!=null)
   {
   	strActive=objForm.hdnOnlyActive.value;
   }
   //alert("inside report.js");
   features='toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,width=620,height=400';
   dlg = window.open (basePath+"/ecrd?hdnScreenName=eCRDCustCatalogHelper&hdnScreenAction=CustomerTableReport&hdnCustomerName="+strFindCust+"&hdnEngineModel="+strEngModel+"&hdnOnlyActive="+strActive+"&RandomValue="+Math.random(),"Dialog",features);
}


/*End*/


/* -------------Added By Prathima--------------*/

function fnSubmitCustTableReport(objectForm,STRCOLUMNDELIM)
{

	 if(window.opener.document.frmViewReports1!=null)
		{
					objForm=window.opener.document.frmViewReports1;
		}
		
	 //alert("obj Form"+objectForm.radio);
   strCustCode = "";
   strCustName = "";
   if(objectForm==null)
   {
      alertMsgs(eCRDNoCustomer);
       return false;
   }
   strCust = getSelectedRadio(objectForm);   
   
   if(strCust=="")
   {
      alertMsgs(eCRDemptyCustomer);
      return false;
   }
	

      for(x=0;x<=strCust.length;x++)
   {

      if(strCust.substring(x,x+1)==STRCOLUMNDELIM)
      {
         break;
      }         
    }

	 
        strCustCode = strCust.substring(0,x);
        strCustName = strCust.substring(x+1,strCust.length);
		objForm.hdnCustCode.value = strCustCode ;
		objForm.txtCustCode.value = strCustName ;
	   // alert("inside managaecatalog.js"+objForm.hdnCustCode.value);

	    //alert("inside managaecatalog.js"+objForm.txtCustCode.value);

      self.close();
} 

function fnCancel()
{
	      self.close();
}

function getSelectedRadioValue(radio)
{
   	var count = 1;
	var value = "";
		for(count = 1; count < radio.length; count++)
		{
			if(radio[count].checked)
			{
				value = radio[count].value ;
			}
		}
		return value;

}

/*function getSelectedRadio(radio)
{
   	var count = 0;
	var value = "";
	
	alert("radio length"+radio.length);
	alert("radio val"+radio[count].checked);
	if(radio[count].checked)
	{
		value = radio[count].value ;
	}
		for(count = 0; count <= radio.length; count++)
		{
			if(radio[count].checked)
			{
				value = radio[count].value ;
			}
		}
		return value;

}
*/

function getSelectedRadio(rcForm)
{
   	
	var count = 1;
	var value = "";
	
		for(count = 1; count < rcForm.elements.length; count++)
		{
			if(rcForm.elements[count].checked)
			{
				value = rcForm.elements[count].value ;
			}

		}
		return value;
}

/* -------------Added By Prathima--------------*/


function fnCheckForMandatory(objForm)
{
	if(objForm.lstEngModel.options[objForm.lstEngModel.selectedIndex].value == "")
  	{
      alertMsgs(eCRDSelEngModel);
	  objForm.lstEngModel.focus();
      return false;
  	}
  	if(objForm.lstFeature.options[objForm.lstFeature.selectedIndex].value == "")
  	{
      alertMsgs(eCRDSelFeature);
	   objForm.lstFeature.focus();
      return false;
   }

   if(objForm.sel_man_Startdate_DD.value=="" || objForm.sel_man_Startdate_MM.value=="" || objForm.sel_man_Startdate_YYYY.value=="")
   {
      alertMsgs(eCRDStartDate);
	  objForm.sel_man_Startdate_DD.focus();
      return false;
   }
   with(objForm)
   {
         startDate = fnValidateCalenderDate(sel_man_Startdate_DD,sel_man_Startdate_MM,sel_man_Startdate_YYYY);
       if(!fnValidateDateString(startDate))
       {

            objForm.sel_man_Startdate_DD.focus();
            return false;
       }
   }
   if(objForm.sel_man_Enddate_DD.value=="" || objForm.sel_man_Enddate_MM.value=="" || objForm.sel_man_Enddate_YYYY.value=="")
   {
      alertMsgs(eCRDEndDate);
      objForm.sel_man_Enddate_DD.focus();
      return false;
   }
   with(objForm)
   {
    endDate   = fnValidateCalenderDate(sel_man_Enddate_DD,sel_man_Enddate_MM,sel_man_Enddate_YYYY);
    if(!fnValidateDateString(endDate))
    {
         objForm.sel_man_Enddate_DD.focus();
         return false;
    }
   }
	with(objForm)
	{
		startDate = fnValidateCalenderDate(sel_man_Startdate_DD,sel_man_Startdate_MM,sel_man_Startdate_YYYY);
		endDate   = fnValidateCalenderDate(sel_man_Enddate_DD,sel_man_Enddate_MM,sel_man_Enddate_YYYY);
		objForm.hdnStartDate.value=startDate ;
		objForm.hdnEndDate.value=endDate ;
		
		if(fnCompareDateFromTo(startDate,endDate))
	 	{
			alertMsgs(eCRDDateMismatch);
			return false;
		}
	}
   return true;
}

/*Added By Santosh   */
function fnCheckForMandatoryForRepair(objForm)
{
	if(objForm.lstEngModel.options[objForm.lstEngModel.selectedIndex].value == "")
  	{
      alertMsgs(eCRDSelEngModel);
	  objForm.lstEngModel.focus();
      return false;
  	}
  	if(objForm.lstFeature.options[objForm.lstFeature.selectedIndex].value == "")
  	{
      alertMsgs(eCRDSelFeature);
	   objForm.lstFeature.focus();
      return false;
   }

   if(objForm.sel_man_Startdate_DD.value=="" || objForm.sel_man_Startdate_MM.value=="" || objForm.sel_man_Startdate_YYYY.value=="")
   {
      alertMsgs(eCRDStartDate);
	  objForm.sel_man_Startdate_DD.focus();
      return false;
   }
   with(objForm)
   {
         startDate = fnValidateCalenderDate(sel_man_Startdate_DD,sel_man_Startdate_MM,sel_man_Startdate_YYYY);
       if(!fnValidateDateString(startDate))
       {

            objForm.sel_man_Startdate_DD.focus();
            return false;
       }
   }
   if(objForm.sel_man_Enddate_DD.value=="" || objForm.sel_man_Enddate_MM.value=="" || objForm.sel_man_Enddate_YYYY.value=="")
   {
      alertMsgs(eCRDEndDate);
      objForm.sel_man_Enddate_DD.focus();
      return false;
   }
   with(objForm)
   {
    endDate   = fnValidateCalenderDate(sel_man_Enddate_DD,sel_man_Enddate_MM,sel_man_Enddate_YYYY);
    if(!fnValidateDateString(endDate))
    {
         objForm.sel_man_Enddate_DD.focus();
         return false;
    }
   }
	with(objForm)
	{
		startDate = fnValidateCalenderDate(sel_man_Startdate_DD,sel_man_Startdate_MM,sel_man_Startdate_YYYY);
		endDate   = fnValidateCalenderDate(sel_man_Enddate_DD,sel_man_Enddate_MM,sel_man_Enddate_YYYY);
		objForm.hdnStartDate.value=startDate ;
		objForm.hdnEndDate.value=endDate ;
		/* Santosh Added for checking start date and End date */
		
		if(fnCompareDateFromTo(startDate,endDate)==false)
		{
			var d = Date.parse(startDate);
	    	var d1 = Date.parse(endDate);
	    	var sec = d/1000;
	    	var min = sec/60;
	   	 	var hr = min/60;
	    	var day = hr/24;
	    	var sec1 = d1/1000;
	    	var min1 = sec1/60;
	    	var hr1 = min1/60;
	    	var day1 = hr1/24;
	    	var diff= day1-day;
	    	
	    	if(diff<=1096)
	    	{
	         return true;
	        }
	        else
	        {
	        alert("Start Date and End Date difference must be less than or equal to 3 years");
	        return false;
	        }
	    	/* Santosh Ended for checking start date and End date */
		}
		if(fnCompareDateFromTo(startDate,endDate))
	 	{
			alertMsgs(eCRDDateMismatch);
			return false;
		}
	}
   return true;
}

/*Ended By Santosh   */


function fnValidateCalenderDate(dayDD,monthDD,yearDD)
{

   var dayVal = dayDD.options[dayDD.selectedIndex].value;
   var monthVal = monthDD.options[monthDD.selectedIndex].value;
   var yearVal = yearDD.options[yearDD.selectedIndex].value;
   var fullDateVal =monthVal+ "/" + dayVal + "/"  + yearVal ;
   return fullDateVal;

}

function fnCompareDateFromTo(start,end)
{
    if ( Date.parse(start)>Date.parse(end))
    {
    	return true;
    }
    else
    {
       return false;
    }
}

function fnViewPriceList()
{
	
	objForm=document.frmPriceList;
	
    	if(fnCheckForMandatoryForRepair(objForm)==true)
	{
		objForm.hdnEngModelDesc.value = objForm.lstEngModel.options[objForm.lstEngModel.selectedIndex].text;
		objForm.hdnFeature.value = objForm.lstFeature.options[objForm.lstFeature.selectedIndex].text;
		objForm.hdnScreenName.value   = "eCRDPriceListChanges";
		objForm.hdnScreenAction.value = "eCRDPriceListReport";
		objForm.submit();
	}
}

//Component listing changes start Kumar
function fnViewComponentList()
{
	objForm=document.frmComponentList;
    	if(fnCheckForMandatory(objForm)==true)
	{
		objForm.hdnEngModelDesc.value = objForm.lstEngModel.options[objForm.lstEngModel.selectedIndex].text;
		objForm.hdnFeature.value = objForm.lstFeature.options[objForm.lstFeature.selectedIndex].text;
		objForm.hdnScreenName.value   = "eCRDComponentListChanges";
		objForm.hdnScreenAction.value = "eCRDComponentListReport";
		objForm.submit();
	}
}
//Component listing changes end

function fnDownLoadReport(strValue,basePath)
{
	objForm = document.frmCompYearlyCatResults;
	var strLoc = "";
	if(strValue == 'Back')
	{
		objForm.hdnScreenAction.value = "";
		objForm.submit();
	}
	else
	{
		if(objForm.hdnCatalogValue.value == '')
		{
			alertMsgs(eCRDCatalog);
			return false;
		}
		strCatalog = objForm.hdnCatalogValue.value;
		strCatalogNumber = objForm.hdnCatalogNumber.value;
		strRprEffDate = objForm.hdnRprEffDate.value;

		strAlert = objForm.hdnRprEffDateAlert.value;


		if(strValue == 'Excel')
		{
			//objForm.hdnScreenAction.value = "eCRDDownLoadExcel";
			var strJspPath = basePath + '/ecrd/jsp/eCRDDownloadExcel.jsp';
			strLoc= strJspPath+"?hdnCatalogValue="+strCatalog+"&hdnCatalogNumber="+strCatalogNumber+"&hdnRprEffDate="+strRprEffDate+"&hdnReportType=";
			if(objForm.hdnReportType.value=="")
			{
			   strLoc+="eCRDDownLoadExcel";
			}
			else
			{
			  strLoc+=objForm.hdnReportType.value;
			}
			document.navframe.location = strLoc;
			if(strAlert == 1)
				alertMsgs(eCRDRprEffDateCompEndDateAlert);
		}
		else if(strValue == 'PDF')
		{
			objForm.hdnScreenAction.value = "eCRDDownLoadPDF";
			var strJspPath = basePath + '/ecrd/jsp/eCRDDownloadPDF.jsp';
			document.navframe.location = strJspPath+"?hdnCatalogValue="+strCatalog+"&hdnCatalogNumber="+strCatalogNumber+"&hdnRprEffDate="+strRprEffDate;
			if(strAlert == 1)
				alertMsgs(eCRDRprEffDateCompEndDateAlert);
			//setting the features to the child window.
//			features="toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=500,height=300,hide=yes";
			//opening the child window with the specified path.
//			window.open(basePath+"/ecrd?hdnScreenName=eCRDReports&hdnScreenAction=eCRDDownLoadPDF&hdnCatalogValue ="+objForm.hdnCatalogValue.value,"excelfile","Component Yearly Catalog Download",features);
		}
	}
}

function fnSearch()
{
	objForm = document.frmComponentYearlyCatalog;
	/*
	startDate = fnValidateCalenderDate(objForm.sel_man_StartDate_DD,objForm.sel_man_StartDate_MM,objForm.sel_man_StartDate_YYYY);
	endDate   = fnValidateCalenderDate(objForm.sel_man_EndDate_DD,objForm.sel_man_EndDate_MM,objForm.sel_man_EndDate_YYYY);
	if(objForm.lstEngModel.value == '')
	{
		alert(eCRDSelEngModel);
		objForm.lstEngModel.focus();
		return false;
	}

	if(fnCompareDateFromTo(startDate,endDate))
	{
		alertMsgs(eCRDDateMismatch);
		return false;
	}*/
	var startDate;
	var endDate;
	with (objForm)
	{
	   if(lstEngModel.selectedIndex == 0)
		{
    		 alertMsgs(eCRDSelEngModel);
    		 lstEngModel.focus();
     		 return false;
  		}

		if(sel_man_StartDate_DD.value != "" || sel_man_StartDate_MM.value != "" || sel_man_StartDate_YYYY.value != "")
      {
         if(sel_man_StartDate_DD.value == "" || sel_man_StartDate_MM.value == "" || sel_man_StartDate_YYYY.value == "")
         {
            alertMsgs(eCRDStartDate);
            sel_man_StartDate_DD.focus();
 				return false;
         }
      }

  		if(sel_man_EndDate_DD.value != "" || sel_man_EndDate_MM.value != "" || sel_man_EndDate_YYYY.value != "")
      {
         if(sel_man_EndDate_DD.value == "" || sel_man_EndDate_MM.value == "" || sel_man_EndDate_YYYY.value == "")
         {
            alertMsgs(eCRDEndDate);
            sel_man_EndDate_DD.focus();
 				return false;
         }
      }



		if(sel_man_StartDate_DD.value == "" || sel_man_StartDate_MM.value == "" || sel_man_StartDate_YYYY.value == "")
		{
			startDate = "";
		}
		else
		{
			startDate = fnValidateCalenderDate(sel_man_StartDate_DD,sel_man_StartDate_MM,sel_man_StartDate_YYYY);
			if(!fnValidateDateString(startDate))
			{
				//sel_man_StartDate_DD.focus();
				return false;
			}
		}
		if(sel_man_EndDate_DD.value == "" || sel_man_EndDate_MM.value == "" || sel_man_EndDate_YYYY.value == "")
		{
			endDate   = "";
		}
		else
		{
			endDate   = fnValidateCalenderDate(sel_man_EndDate_DD,sel_man_EndDate_MM,sel_man_EndDate_YYYY);
			if(!fnValidateDateString(endDate))
			{
				//sel_man_EndDate_DD.focus();
				return false;
			}
		}




		if(fnCompareDateFromTo(startDate,endDate))
	 	{
			alertMsgs(eCRDDateMismatch);
			return false;
		}


		if(sel_repair_eff_DD.value == "" || sel_repair_eff_MM.value == "" || sel_repair_eff_YYYY.value == "")
		{
			rprEffDate   = "";
		}
		else
		{
			rprEffDate   = fnValidateCalenderDate(sel_repair_eff_DD,sel_repair_eff_MM,sel_repair_eff_YYYY);
			if(!fnValidateDateString(rprEffDate))
			{
				//sel_man_EndDate_DD.focus();
				return false;
			}
		}

	}
	/*if(objForm.hdnCustReqd.value=="YES")
	{
		if(objForm.hdnCustCode.value=="")
		{
			alertMsgs(eCRDemptyCustomer);
			return;
		}
	}*/


<!-- Start For Repair Effective Date on 08Nov2005 By Rajiv -->

	var sysdate = new Date() ;
	var theyear = sysdate.getFullYear();
	var themonth = (sysdate.getMonth()+1);
	var thetoday = sysdate.getDate();

	var one_day=1000*60*60*24;
	today = themonth+"/"+thetoday+"/"+theyear;
	var DateDifference = Math.ceil((sysdate.getTime()-new Date(rprEffDate).getTime())/(one_day));

	/** Start Adding for Security Checks*/
//	alert("objForm.hdnCustReqd.value = " + objForm.hdnCustReqd.value);
	if(objForm.hdnCustReqd.value == "NO"){ 
//		alert("insideee");
		if(!fnCheckSplChars(objForm.txtCatalogNum))
		{
		   alertMsgs(eCRDSpecialChars);
		   return false;
		}
//		alert("outsideee");
	}
	/** End Here*/
	
if(DateDifference > 1 && rprEffDate!="")
{
	alertMsgs(eCRDRprEffDateSysdate);
	return false;
}else
{
<!-- End For Repair Effective Date on 08Nov2005 By Rajiv -->

	objForm.hdnEngineText.value = objForm.lstEngModel[objForm.lstEngModel.selectedIndex].text;
	objForm.hdnScreenName.value = "eCRDReports";
	objForm.hdnScreenAction.value = "eCRDSearchCatalog";
	objForm.submit();
}

}

function fnGetCatalogValue(strCatalog,strCatalogNumber,objFrom)
{
	objFrom.hdnCatalogValue.value = strCatalog;
	objFrom.hdnCatalogNumber.value = strCatalogNumber;
}

<!-- Start For Repair Effective Date on 08Nov2005 By Rajiv -->
function fnGetCatalogValueForRprEffDate(strCatalog,strCatalogNumber,strCatalogEffDate,strRprEffDate,objFrom)
{
	objFrom.hdnCatalogValue.value = strCatalog;
	objFrom.hdnCatalogNumber.value = strCatalogNumber;

	objFrom.hdnRprEffDate.value = strRprEffDate;
	var one_day=1000*60*60*24;
	var DateDifference = Math.ceil((new Date(strRprEffDate).getTime() - new Date(strCatalogEffDate).getTime())/(one_day));
	if(DateDifference > 1 && strRprEffDate !="")
	{
		objFrom.hdnRprEffDateAlert.value = "1";
	}
	else
	{
		objFrom.hdnRprEffDateAlert.value = "0";
	}
}
<!-- End For Repair Effective Date on 08Nov2005 By Rajiv -->


function fnSelectAll(objForm)
{
	for(var i=0;i<objForm.chk_SelCol.length;i++)
	{
		objForm.chk_SelCol[i].checked=true;
	}
	
}
function fnUnSelectAll(objForm)
{
	for(var i=0;i<objForm.chk_SelCol.length;i++)
	{
		objForm.chk_SelCol[i].checked=false;
	}
	
}


/* Added By Prathima  */

/*function fnSelectAllCust(objForm)
{
	//alert("inside select All cust");
	for(var i=0;i<=objForm.checkBox.length;i++)
	{
		objForm.checkBox[i].checked=true;
	}
}
function fnUnSelectAllCust(objForm)
{
	//alert("inside unselect All cust");
	for(var i=0;i<=objForm.checkBox.length;i++)
	{
		objForm.checkBox[i].checked=false;
	}
}*/


function fnSelectAllCust(objForm)
{
	//alert("inside select All cust");
	if(!objForm.checkBox.length)
	{
		objForm.checkBox.checked = true;
	}
	else
	{
	for(var i=0;i<objForm.checkBox.length;i++)
	{
		objForm.checkBox[i].checked=true;
	}
}
}
function fnUnSelectAllCust(objForm)
{
	//alert("inside unselect All cust");
	if(!objForm.checkBox.length)
	{
		objForm.checkBox.checked = false;
	}
	else
	{
	for(var i=0;i<objForm.checkBox.length;i++)
	{
		objForm.checkBox[i].checked=false;
	}
}
}

/* Ended By Prathima  */

//Modified by Bora
function fnGenerateReport(objForm,strColDelim,basePath,defSelected,defSeq)
{
     var colsSel = 0 ;
     var isCriteriaSel = false;
     var isCostReqdChanged = false;
     objForm.hdnSelColumns.value=defSelected;
     /*
     if cost criteria selected then site should be one at a time
     */
     if((objForm.cmb_whereCost.selectedIndex!=0) && (objForm.txt_Cost.value!=''))
     {
     	objForm.hdnIsCostReqd.value='Y';
     	isCostReqdChanged =true;
     }
     for(var i=0;i<objForm.chk_SelCol.length;i++)
     {
	if(objForm.chk_SelCol[i].checked)
	{
		colsSel++;
		//alert(objForm.chk_SelCol[i].value)
		if(objForm.chk_SelCol[i].value=='COST' || objForm.chk_SelCol[i].value=='CM' )
		{
			objForm.hdnIsCostReqd.value =  "Y";
			isCostReqdChanged =true;
			//alert('if cost is selected:'+objForm.hdnIsCostReqd.value);
		}
		else
		{
			if(!isCostReqdChanged)
			{
				objForm.hdnIsCostReqd.value =  "N";
			}
		}
		if(objForm.chk_SelCol[i].value=='LOCATION')
		{
			objForm.hdnIsSiteSel.value='Y';
			//alert('if location '+objForm.hdnIsCostReqd.value);
			if(objForm.hdnIsCostReqd.value=='Y')
			{
				//alert('LOCATION_IND');
				objForm.hdnSelColumns.value=objForm.hdnSelColumns.value+"LOCATION_IND"+strColDelim;
			}
			else
			{
				objForm.hdnSelColumns.value=objForm.hdnSelColumns.value+objForm.chk_SelCol[i].value+strColDelim;
			}
			objForm.hdnSelColumns.value=objForm.hdnSelColumns.value+"LOCATION_HIDDEN_INDICATOR"+strColDelim;
		}
		else
		{
			objForm.hdnSelColumns.value=objForm.hdnSelColumns.value+objForm.chk_SelCol[i].value+strColDelim;
		}
		if(objForm.chk_SelCol[i].value=='TAT')
		{
			//objForm.hdnSelEnColumns.value=objForm.hdnSelEnColumns.value+objForm.chk_SelCol[i].value+strColDelim;
			objForm.hdnSelColumns.value=objForm.hdnSelColumns.value+"TAT_INCREMENTAL"+strColDelim;
		}
		if(objForm.chk_SelCol[i].value=='PRICE')
		{
			//objForm.hdnSelEnColumns.value=objForm.hdnSelEnColumns.value+objForm.chk_SelCol[i].value+strColDelim;
			objForm.hdnSelColumns.value=objForm.hdnSelColumns.value+"PRICE_INCREMENTAL"+strColDelim;
		}		
	 }
     }
     if(colsSel==0)
     {
     	alertMsgs(eCRDAdhocColSelect);
     	return;
     }
     /*
     Checking for price where clause to be proper
     */
     if(objForm.cmb_wherePrice.selectedIndex==0)
     {
     	if(objForm.txt_Price.value!='')
     	{
     	  alertMsgs(eCRDEnterPricCond);
     	  return;
     	}
     }
     else
     {
     	if(objForm.txt_Price.value=='')
	   {
	  alertMsgs(eCRDPrice);
	  return;
     	}
     	else
     	{
     	 isCriteriaSel =true;
     	}
     }
     if(objForm.hdnIsSiteSel.value!='Y' && objForm.hdnIsCostReqd.value=='Y')
     {
      	alert(eCRDSiteDisplayable);
	return;
     }
     /*
          Checking for Cost where clause to be proper
     */
     if(objForm.cmb_whereCost.selectedIndex==0)
     {
	if(objForm.txt_Cost.value!='')
	{
	  alertMsgs(eCRDEnterCostCond);
	  return;
	}
     }
     else
     {
       	if(objForm.txt_Cost.value=='')
     	{
     	  alertMsgs(eCRDEnterCost);
     	  return;
       	}
       	else
	{
	 isCriteriaSel =true;
	 /*
	 if(objForm.hdnIsSiteSel.value!='Y' || objForm.hdnIsCostReqd.value!='Y')
	 {
	  	alert("Please select site or cost as a displayable column");
	  	return;
	 }
	 */
	 if(objForm.hdnIsSiteSel.value!='Y' )
	 {
	 	alert(eCRDSiteDisplayable);
	 	return;
	 }
     	}
     }
     /*
     Checking for price type
     */
     if( (objForm.cmb_wherePriceType.selectedIndex!=0 && objForm.cmb_priceType.selectedIndex==0)
     ||(objForm.cmb_wherePriceType.selectedIndex==0 && objForm.cmb_priceType.selectedIndex!=0) )
     {
     	alertMsgs(eCRDEnterPriceCrit);
     	return;
     }
     if(objForm.cmb_wherePriceType.selectedIndex!=0 || objForm.cmb_priceType.selectedIndex!=0)
     {
     	isCriteriaSel =true;
     }
     if(objForm.chkPartNum.checked)
     {
     	objForm.hdnPartNum.value='Y';
     	isCriteriaSel =true;
     }
     else
     {
     	objForm.hdnPartNum.value='N';
     }

     if(objForm.chkRepairNum.checked)
     {
	objForm.hdnRepairNum.value='Y';
	isCriteriaSel =true;
     }
     else
     {
	objForm.hdnRepairNum.value='N';
     }
   //06-07-06 Patni checking Engine model selection Begin 
	/* if(objForm.cmb_engmodel.selectedIndex!=0)
	 {
		 isCriteriaSel =true;
	 }*/
	//Added By Santosh
	    var oselecteng = objForm.cmb_engmodel;
	    var count = 0;
	    for(var i=0;i<oselecteng.options.length;i++){
			if(oselecteng.options[i].selected)
			{
				count++;
			}
		}
	    if(count<1)
	    	{
	    	alert("Please select Engine Model !");
	    	return;
	    	}
	    else
	    	{
	    	isCriteriaSel =true;
	    	}
	  //Ended By Santosh
	
   //06-07-06 Patni checking Engine model selection Begin 

     if(isCriteriaSel)
     {
	var strJspPath = basePath + '/ecrd/jsp/eCRDDownloadExcel.jsp';
	strLoc= strJspPath+"?hdnCatalogValue=Adhoc_Report&hdnReportType="+objForm.hdnReportType.value;
	strLoc+="&hdnSeqOfColums="+objForm.hdnSeqOfColums.value;
	strLoc+="&hdnSelColumns="+objForm.hdnSelColumns.value;
	strLoc+="&hdnPartNum="+objForm.hdnPartNum.value;
	strLoc+="&hdnRepairNum="+objForm.hdnRepairNum.value;
	strLoc+="&cmb_whereCost="+objForm.cmb_whereCost.options[objForm.cmb_whereCost.selectedIndex].value;
	strLoc+="&cmb_whereCost_text="+objForm.cmb_whereCost.options[objForm.cmb_whereCost.selectedIndex].text;
	strLoc+="&txt_Cost="+objForm.txt_Cost.value;
	strLoc+="&cmb_wherePrice="+objForm.cmb_wherePrice.options[objForm.cmb_wherePrice.selectedIndex].value;
	strLoc+="&cmb_wherePrice_text="+objForm.cmb_wherePrice.options[objForm.cmb_wherePrice.selectedIndex].text;
	strLoc+="&txt_Price="+objForm.txt_Price.value;
	strLoc+="&cmb_wherePriceType="+objForm.cmb_wherePriceType.options[objForm.cmb_wherePriceType.selectedIndex].value;
	strLoc+="&cmb_wherePriceType_text="+objForm.cmb_wherePriceType.options[objForm.cmb_wherePriceType.selectedIndex].text;
	strLoc+="&cmb_priceType=" +objForm.cmb_priceType.options[objForm.cmb_priceType.selectedIndex].value;
	strLoc+="&cmb_incPrice="  +objForm.cmb_incPrice.options[objForm.cmb_incPrice.selectedIndex].value;
	strLoc+="&cmb_incTAT="    +objForm.cmb_incTAT.options[objForm.cmb_incTAT.selectedIndex].value;
	strLoc+="&hdnIsCostReqd=" +objForm.hdnIsCostReqd.value;
	strLoc+="&hdnIsSiteSel="  +objForm.hdnIsSiteSel.value;
    // 11-06-2006 Patni passing Engine model Begin 
    //strLoc+="&cmb_engmodel="  +objForm.cmb_engmodel.options[objForm.cmb_engmodel.selectedIndex].value;
   // strLoc+="&cmb_engmodel_text="+objForm.cmb_engmodel.options[objForm.cmb_engmodel.selectedIndex].text;
  //Added By Santosh
	var oselect = objForm.cmb_engmodel;
	
	//var oselect=document.getElementById("engmdl_id");
	var strEngMdls='';
	var strEngMdl_txt='';
	for(var i=0;i<oselect.options.length;i++){
		if(oselect.options[i].selected)
		{
			strEngMdls = strEngMdls +oselect.options[i].value+ "^";
			strEngMdl_txt = strEngMdl_txt + oselect.options[i].text+"^";
		}
	}
	
	var oselectsite = objForm.cmb_site;

	var strSite='';
	var strSite_txt='';
	for(var i=0;i<oselectsite.options.length;i++){
		if(oselectsite.options[i].selected)
		{
			strSite = strSite +oselectsite.options[i].value+ "^";
			strSite_txt = strSite_txt + oselectsite.options[i].text+"^";
		}
	}
	
    strLoc+="&cmb_engmodel="+strEngMdls;
    strLoc+="&cmb_engmodel_text="+strEngMdl_txt;
    strLoc+="&cmb_site="+strSite;
    strLoc+="&cmb_site_test="+strSite_txt;
    features="toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=400,height=200,hide=yes";
    window.open(strLoc,"excelfile","Download Report","status=no,toolbar=no,menubar=no,scrollbars=no,resizable=no,width=350,height=225");
	
    
    // Ended By Santosh
    
    
    
    
    
    
	// 11-06-2006 Patni passing Engine model End 
	
	//document.navframe.location = strLoc;
	//alert(objForm.hdnIsCostReqd.value)
	objForm.hdnIsCostReqd.value='';
	objForm.hdnIsSiteSel.value='';
	objForm.hdnPartNum.value='';
	objForm.hdnRepairNum.value='';
	objForm.reset();
	objForm.hdnSeqOfColums.value=defSeq;
	objForm.hdnSelColumns.value=defSelected;
	objForm.hdnReportType.value="eCRDADHOCREPORT";
     }
     else
     {
     	alertMsgs(eCRDEnterRepCrit);
     }

}

// Added By Prathima

function fnGenerateCustomerReport(objFormRep,objForm,rcForm,strColDelim,basePath,defSelected,defSeq)
{
	//alert("Inside the generate report");
     var colsSel = 0 ;
     var isCriteriaSel = false;
     var isCostReqdChanged = false;
     objFormRep.hdnSelColumns.value=defSelected;
     
     for(var i=0;i<objForm.chk_SelCol.length;i++)
     {
		if(objForm.chk_SelCol[i].checked)
		{
			colsSel++;
			//alert("inside check box"+objForm.chk_SelCol[i].value)
		if(objForm.chk_SelCol[i].value=='COST' || objForm.chk_SelCol[i].value=='CM' )
		{
			objFormRep.hdnIsCostReqd.value =  "Y";
			isCostReqdChanged =true;
			//alert('if cost is selected:'+objFormRep.hdnIsCostReqd.value);
		}
		else
		{
			if(!isCostReqdChanged)
			{
				objFormRep.hdnIsCostReqd.value =  "N";
			}
		}
		if(objForm.chk_SelCol[i].value=='LOCATION')
		{
			objFormRep.hdnIsSiteSel.value='Y';
			//alert('if location '+objFormRep.hdnIsCostReqd.value);
			if(objFormRep.hdnIsCostReqd.value=='Y')
			{
				//alert('LOCATION_IND');
				objFormRep.hdnSelColumns.value=objFormRep.hdnSelColumns.value+"LOCATION_IND"+strColDelim;
			}
			else
			{
				objFormRep.hdnSelColumns.value=objFormRep.hdnSelColumns.value+objForm.chk_SelCol[i].value+strColDelim;
			}
			objFormRep.hdnSelColumns.value=objFormRep.hdnSelColumns.value+"LOCATION_HIDDEN_INDICATOR"+strColDelim;
		}
		else
		{
			objFormRep.hdnSelColumns.value=objFormRep.hdnSelColumns.value+objForm.chk_SelCol[i].value+strColDelim;
		}
		if(objForm.chk_SelCol[i].value=='TAT')
		{
			//objForm.hdnSelEnColumns.value=objForm.hdnSelEnColumns.value+objForm.chk_SelCol[i].value+strColDelim;
			objFormRep.hdnSelColumns.value=objFormRep.hdnSelColumns.value+"TAT_INCREMENTAL"+strColDelim;
		}
		if(objForm.chk_SelCol[i].value=='PRICE')
		{
			//objForm.hdnSelEnColumns.value=objForm.hdnSelEnColumns.value+objForm.chk_SelCol[i].value+strColDelim;
			objFormRep.hdnSelColumns.value=objFormRep.hdnSelColumns.value+"PRICE_INCREMENTAL"+strColDelim;
		}		
	 }
     }
     if(colsSel==0)
     {
     	alertMsgs(eCRDAdhocColSelect);
     	return;
     }
	 else
	 {
		isCriteriaSel = true;
	 }
	 
     
    
    var count = 1;
	var oselectCatalog = "";
	for(count = 1; count < rcForm.elements.length; count++)
		{
			
			if(rcForm.elements[count].checked)
			{
						
					oselectCatalog = oselectCatalog + rcForm.elements[count].value + '$' ;
					//alert('Checked value of catalog'+oselectCatalog);
			}
			

		}

	if(oselectCatalog == "" || oselectCatalog == null)
	{
		alert('Please Select Calataog !');
		return false;
	}
	else
	{
		isCriteriaSel = true;
	}
	
     
	 
	

     if(isCriteriaSel)
     {
    	 var reptype = "eCRDCUSTADHOCREPORT";
    	 //alert('Inside submit the form');
	var strJspPath = basePath + '/ecrd/jsp/eCRDDownloadExcel.jsp';
	strLoc= strJspPath+"?hdnCatalogValue=Adhoc_Report&hdnReportType="+reptype;
	strLoc+="&hdnSeqOfColums="+objFormRep.hdnSeqOfColums.value;
	strLoc+="&hdnSelColumns="+objFormRep.hdnSelColumns.value;
	//strLoc+="&hdnEngineModel="+objForm.lstEngModel.options[objForm.lstEngModel.selectedIndex].value;
	//strLoc+="&hdnEngineModelText="+objForm.lstEngModel.options[objForm.lstEngModel.selectedIndex].text;
	//strLoc+="&txtCustCode="+objForm.txtCustCode.value;
	strLoc+="&oselectedCatalog="+oselectCatalog;
	
	objFormRep.hdnSeqOfColums.value=defSeq;
    objFormRep.hdnSelColumns.value=defSelected;
    objFormRep.hdnReportType.value="eCRDCUSTADHOCREPORT";
	
	
    features="toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=400,height=200,hide=yes";
    window.open(strLoc,"excelfile","Download Report","status=no,toolbar=no,menubar=no,scrollbars=no,resizable=no,width=350,height=225");

	//objForm.reset();
    
     }
     else
     {
     	alertMsgs(eCRDEnterRepCrit);
     }

}

function fnGenerateEnhancedCustReport(objFormRep,objForm,rcForm,strColDelim,basePath,defSelected,defSeq)
{
	//alert("Inside the generate report");
     var colsSel = 0 ;
     var isCriteriaSel = false;
     var isCostReqdChanged = false;
     objFormRep.hdnSelColumns.value=defSelected;
     
     for(var i=0;i<objForm.chk_SelCol.length;i++)
     {
		if(objForm.chk_SelCol[i].checked)
		{
			colsSel++;
			//alert("inside check box"+objForm.chk_SelCol[i].value)
		if(objForm.chk_SelCol[i].value=='COST' || objForm.chk_SelCol[i].value=='CM' )
		{
			objFormRep.hdnIsCostReqd.value =  "Y";
			isCostReqdChanged =true;
			//alert('if cost is selected:'+objFormRep.hdnIsCostReqd.value);
		}
		else
		{
			if(!isCostReqdChanged)
			{
				objFormRep.hdnIsCostReqd.value =  "N";
			}
		}
		if(objForm.chk_SelCol[i].value=='LOCATION')
		{
			objFormRep.hdnIsSiteSel.value='Y';
			//alert('if location '+objFormRep.hdnIsCostReqd.value);
			if(objFormRep.hdnIsCostReqd.value=='Y')
			{
				//alert('LOCATION_IND');
				objFormRep.hdnSelColumns.value=objFormRep.hdnSelColumns.value+"LOCATION_IND"+strColDelim;
			}
			else
			{
				objFormRep.hdnSelColumns.value=objFormRep.hdnSelColumns.value+objForm.chk_SelCol[i].value+strColDelim;
			}
			objFormRep.hdnSelColumns.value=objFormRep.hdnSelColumns.value+"LOCATION_HIDDEN_INDICATOR"+strColDelim;
		}
		else
		{
			objFormRep.hdnSelColumns.value=objFormRep.hdnSelColumns.value+objForm.chk_SelCol[i].value+strColDelim;
		}
		if(objForm.chk_SelCol[i].value=='TAT')
		{
			//objForm.hdnSelEnColumns.value=objForm.hdnSelEnColumns.value+objForm.chk_SelCol[i].value+strColDelim;
			objFormRep.hdnSelColumns.value=objFormRep.hdnSelColumns.value+"TAT_INCREMENTAL"+strColDelim;
		}
		if(objForm.chk_SelCol[i].value=='PRICE')
		{
			//objForm.hdnSelEnColumns.value=objForm.hdnSelEnColumns.value+objForm.chk_SelCol[i].value+strColDelim;
			objFormRep.hdnSelColumns.value=objFormRep.hdnSelColumns.value+"PRICE_INCREMENTAL"+strColDelim;
		}		
	 }
     }
     if(colsSel==0)
     {
     	alertMsgs(eCRDAdhocColSelect);
     	return;
     }
	 else
	 {
		isCriteriaSel = true;
	 }
	 
     
    
    var count = 1;
	var oselectCatalog = "";
	for(count = 1; count < rcForm.elements.length; count++)
		{
			
			if(rcForm.elements[count].checked)
			{
						
					oselectCatalog = oselectCatalog + rcForm.elements[count].value + '$' ;
					//alert('Checked value of catalog'+oselectCatalog);
			}
			

		}

	if(oselectCatalog == "" || oselectCatalog == null)
	{
		alert('Please Select Calataog !');
		return false;
	}
	else
	{
		isCriteriaSel = true;
	}
	
     
	 
	

     if(isCriteriaSel)
     {
    	 var reptype = "eCRDENHCUSTADHOCREPORT";
    	// alert('Inside submit the form');
	var strJspPath = basePath + '/ecrd/jsp/eCRDDownloadExcel.jsp';
	strLoc= strJspPath+"?hdnCatalogValue=Adhoc_Report&hdnReportType="+reptype;
	strLoc+="&hdnSeqOfColums="+objFormRep.hdnSeqOfColums.value;
	strLoc+="&hdnSelColumns="+objFormRep.hdnSelColumns.value;
	//strLoc+="&hdnEngineModel="+objForm.lstEngModel.options[objForm.lstEngModel.selectedIndex].value;
	//strLoc+="&hdnEngineModelText="+objForm.lstEngModel.options[objForm.lstEngModel.selectedIndex].text;
	//strLoc+="&txtCustCode="+objForm.txtCustCode.value;
	strLoc+="&oselectedCatalog="+oselectCatalog;
	objFormRep.hdnSeqOfEnColums.value=defSeq;
    objFormRep.hdnSelEnColumns.value=defSelected;
    //objFormRep.hdnReportType.value="eCRDCUSTADHOCREPORT";
	
	
    features="toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=400,height=200,hide=yes";
    window.open(strLoc,"excelfile","Download Report","status=no,toolbar=no,menubar=no,scrollbars=no,resizable=no,width=350,height=225");

	//objForm.reset();
    
     }
     else
     {
     	alertMsgs(eCRDEnterRepCrit);
     }

}

//Added by Bora
function fnGenerateEnhancedReport(objForm,strColDelim,basePath,defSelected,defSeq)
{
    var colsSel = 0 ;
    var isCriteriaSel = false;
    var isCostReqdChanged = false;
    objForm.hdnSelEnColumns.value=defSelected;
    /*
    if cost criteria selected then site should be one at a time
    */
    if((objForm.cmb_whereCost.selectedIndex!=0) && (objForm.txt_Cost.value!=''))
    {
    	objForm.hdnIsCostReqd.value='Y';
    	isCostReqdChanged =true;
    }
    for(var i=0;i<objForm.chk_SelCol.length;i++)
    {
	if(objForm.chk_SelCol[i].checked)
	{
		colsSel++;
		//alert(objForm.chk_SelCol[i].value)
		if(objForm.chk_SelCol[i].value=='COST' || objForm.chk_SelCol[i].value=='CM' )
		{
			objForm.hdnIsCostReqd.value =  "Y";
			isCostReqdChanged =true;
			//alert('if cost is selected:'+objForm.hdnIsCostReqd.value);
		}
		else
		{
			if(!isCostReqdChanged)
			{
				objForm.hdnIsCostReqd.value =  "N";
			}
		}
		if(objForm.chk_SelCol[i].value=='LOCATION')
		{
			objForm.hdnIsSiteSel.value='Y';
			//alert('if location '+objForm.hdnIsCostReqd.value);
			if(objForm.hdnIsCostReqd.value=='Y')
			{
				//alert('LOCATION_IND');
				objForm.hdnSelEnColumns.value=objForm.hdnSelEnColumns.value+"LOCATION_IND"+strColDelim;
			}
			else
			{
				objForm.hdnSelEnColumns.value=objForm.hdnSelEnColumns.value+objForm.chk_SelCol[i].value+strColDelim;
			}
			objForm.hdnSelEnColumns.value=objForm.hdnSelEnColumns.value+"LOCATION_HIDDEN_INDICATOR"+strColDelim;
		}
		if(objForm.chk_SelCol[i].value=='TAT')
		{
			objForm.hdnSelEnColumns.value=objForm.hdnSelEnColumns.value+objForm.chk_SelCol[i].value+strColDelim;
			objForm.hdnSelEnColumns.value=objForm.hdnSelEnColumns.value+"TAT_INCREMENTAL"+strColDelim;
		}
		if(objForm.chk_SelCol[i].value=='PRICE')
		{
			objForm.hdnSelEnColumns.value=objForm.hdnSelEnColumns.value+objForm.chk_SelCol[i].value+strColDelim;
			objForm.hdnSelEnColumns.value=objForm.hdnSelEnColumns.value+"PRICE_INCREMENTAL"+strColDelim;
		}
		else
		{
			objForm.hdnSelEnColumns.value=objForm.hdnSelEnColumns.value+objForm.chk_SelCol[i].value+strColDelim;
		}
	}
    }
    if(colsSel==0)
    {
    	alertMsgs(eCRDAdhocColSelect);
    	return;
    }
    /*
    Checking for price where clause to be proper
    */
    if(objForm.cmb_wherePrice.selectedIndex==0)
    {
    	if(objForm.txt_Price.value!='')
    	{
    	  alertMsgs(eCRDEnterPricCond);
    	  return;
    	}
    }
    else
    {
    	if(objForm.txt_Price.value=='')
	   {
	  alertMsgs(eCRDPrice);
	  return;
    	}
    	else
    	{
    	 isCriteriaSel =true;
    	}
    }
    if(objForm.hdnIsSiteSel.value!='Y' && objForm.hdnIsCostReqd.value=='Y')
    {
     	alert(eCRDSiteDisplayable);
	return;
    }
    /*
         Checking for Cost where clause to be proper
    */
    if(objForm.cmb_whereCost.selectedIndex==0)
    {
	if(objForm.txt_Cost.value!='')
	{
	  alertMsgs(eCRDEnterCostCond);
	  return;
	}
    }
    else
    {
      	if(objForm.txt_Cost.value=='')
    	{
    	  alertMsgs(eCRDEnterCost);
    	  return;
      	}
      	else
	{
	 isCriteriaSel =true;
	 /*
	 if(objForm.hdnIsSiteSel.value!='Y' || objForm.hdnIsCostReqd.value!='Y')
	 {
	  	alert("Please select site or cost as a displayable column");
	  	return;
	 }
	 */
	 if(objForm.hdnIsSiteSel.value!='Y' )
	 {
	 	alert(eCRDSiteDisplayable);
	 	return;
	 }
    	}
    }
    /*
    Checking for price type
    */
    if( (objForm.cmb_wherePriceType.selectedIndex!=0 && objForm.cmb_priceType.selectedIndex==0)
    ||(objForm.cmb_wherePriceType.selectedIndex==0 && objForm.cmb_priceType.selectedIndex!=0) )
    {
    	alertMsgs(eCRDEnterPriceCrit);
    	return;
    }
    if(objForm.cmb_wherePriceType.selectedIndex!=0 || objForm.cmb_priceType.selectedIndex!=0)
    {
    	isCriteriaSel =true;
    }
    if(objForm.chkPartNum.checked)
    {
    	objForm.hdnPartNum.value='Y';
    	isCriteriaSel =true;
    }
    else
    {
    	objForm.hdnPartNum.value='N';
    }

    if(objForm.chkRepairNum.checked)
    {
	objForm.hdnRepairNum.value='Y';
	isCriteriaSel =true;
    }
    else
    {
	objForm.hdnRepairNum.value='N';
    }
  //06-07-06 Patni checking Engine model selection Begin 
	 /*if(objForm.cmb_engmodel.options.length!=0)
	 {
		 isCriteriaSel =true;
	 }
	 */
    //Added By Santosh
    var oselecteng = objForm.cmb_engmodel;
    var count = 0;
    for(var i=0;i<oselecteng.options.length;i++){
		if(oselecteng.options[i].selected)
		{
			count++;
		}
	}
    if(count<1)
    	{
    	alert("Please select Engine Model !");
    	return;
    	}
    else
    	{
    	isCriteriaSel =true;
    	}
  //Ended By Santosh
  //06-07-06 Patni checking Engine model selection Begin 

    if(isCriteriaSel)
    {
	    //objForm.hdnReportType.value="eCRDENHADHOCREPORT";
	    var rptType="eCRDENHADHOCREPORT";
		var strJspPath = basePath + '/ecrd/jsp/eCRDDownloadExcel.jsp';
		strLoc= strJspPath+"?hdnCatalogValue=Adhoc_Report&hdnReportType="+rptType;
		strLoc+="&hdnSeqOfEnColums="+objForm.hdnSeqOfEnColums.value;
		strLoc+="&hdnSelEnColumns="+objForm.hdnSelEnColumns.value;
		strLoc+="&hdnPartNum="+objForm.hdnPartNum.value;
		strLoc+="&hdnRepairNum="+objForm.hdnRepairNum.value;
		strLoc+="&cmb_whereCost="+objForm.cmb_whereCost.options[objForm.cmb_whereCost.selectedIndex].value;
		strLoc+="&cmb_whereCost_text="+objForm.cmb_whereCost.options[objForm.cmb_whereCost.selectedIndex].text;
		strLoc+="&txt_Cost="+objForm.txt_Cost.value;
		strLoc+="&cmb_wherePrice="+objForm.cmb_wherePrice.options[objForm.cmb_wherePrice.selectedIndex].value;
		strLoc+="&cmb_wherePrice_text="+objForm.cmb_wherePrice.options[objForm.cmb_wherePrice.selectedIndex].text;
		strLoc+="&txt_Price="+objForm.txt_Price.value;
		strLoc+="&cmb_wherePriceType="+objForm.cmb_wherePriceType.options[objForm.cmb_wherePriceType.selectedIndex].value;
		strLoc+="&cmb_wherePriceType_text="+objForm.cmb_wherePriceType.options[objForm.cmb_wherePriceType.selectedIndex].text;
		strLoc+="&cmb_priceType=" +objForm.cmb_priceType.options[objForm.cmb_priceType.selectedIndex].value;
		strLoc+="&cmb_incPrice="  +objForm.cmb_incPrice.options[objForm.cmb_incPrice.selectedIndex].value;
		strLoc+="&cmb_incTAT="    +objForm.cmb_incTAT.options[objForm.cmb_incTAT.selectedIndex].value;
		strLoc+="&hdnIsCostReqd=" +objForm.hdnIsCostReqd.value;
		strLoc+="&hdnIsSiteSel="  +objForm.hdnIsSiteSel.value;
	    // 11-06-2006 Patni passing Engine model Begin 
		// strLoc+="&cmb_engmodel="  +objForm.cmb_engmodel.options[objForm.cmb_engmodel.selectedIndex].value;
		// strLoc+="&cmb_engmodel_text="+objForm.cmb_engmodel.options[objForm.cmb_engmodel.selectedIndex].text;
		
		//Added By Santosh
		var oselect = objForm.cmb_engmodel;
		
		//var oselect=document.getElementById("engmdl_id");
		var strEngMdls='';
		var strEngMdl_txt='';
		for(var i=0;i<oselect.options.length;i++){
			if(oselect.options[i].selected)
			{
				strEngMdls = strEngMdls +oselect.options[i].value+ "^";
				strEngMdl_txt = strEngMdl_txt + oselect.options[i].text+"^";
			}
		}
		
		var oselectsite = objForm.cmb_site;

		var strSite='';
		var strSite_txt='';
		for(var i=0;i<oselectsite.options.length;i++){
			if(oselectsite.options[i].selected)
			{
				strSite = strSite +oselectsite.options[i].value+ "^";
				strSite_txt = strSite_txt + oselectsite.options[i].text+"^";
			}
		}
		
	    strLoc+="&cmb_engmodel="+strEngMdls;
	    strLoc+="&cmb_engmodel_text="+strEngMdl_txt;
	    strLoc+="&cmb_site="+strSite;
	    strLoc+="&cmb_site_test="+strSite_txt;
	    
	   // var strJspPath1 = basePath + '/ecrd/jsp/DownloadingPage.jsp';
	    
	    features="toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=400,height=200,hide=yes";
	    window.open(strLoc,"excelfile","Download Report","status=no,toolbar=no,menubar=no,scrollbars=no,resizable=no,width=350,height=225");
		//newwin.document.write("<img src='"+basePath + "/ecrd/img/download_status.gif' align='middle'>");
		//newwin.document.write("<h2>Loading....</h2>");
	    
	    // Ended By Santosh
		// 11-06-2006 Patni passing Engine model End 
		
		//document.navframe.location = strLoc;
		//alert(objForm.hdnIsCostReqd.value)
		objForm.hdnIsCostReqd.value='';
		objForm.hdnIsSiteSel.value='';
		objForm.hdnPartNum.value='';
		objForm.hdnRepairNum.value='';
		objForm.reset();
		objForm.hdnSeqOfEnColums.value=defSeq;
		objForm.hdnSelEnColumns.value=defSelected;
		//objForm.hdnReportType.value="eCRDADHOCREPORT";
		//var strJspPath1 = basePath + '/ecrd/jsp/DownloadingPage.jsp';
		
    }
    else
    {
    	alertMsgs(eCRDEnterRepCrit);
    }

}
//End Bora

//Adding Customer Adhoc Repair Reports started DES1121903 sujitha

function fnGenerateCustReport(objForm,strColDelim,basePath,defSelected,defSeq)
{
     var colsSel = 0 ;
     var isCriteriaSel = false;
     var isCostReqdChanged = false;
     objForm.hdnSelColumns.value=defSelected;
     /*
     if cost criteria selected then site should be one at a time
     */
     if((objForm.cmb_whereCost.selectedIndex!=0) && (objForm.txt_Cost.value!=''))
     {
     	objForm.hdnIsCostReqd.value='Y';
     	isCostReqdChanged =true;
     }
     for(var i=0;i<objForm.chk_SelCol.length;i++)
     {
	if(objForm.chk_SelCol[i].checked)
	{
		colsSel++;
		//alert(objForm.chk_SelCol[i].value)
		if(objForm.chk_SelCol[i].value=='COST' || objForm.chk_SelCol[i].value=='CM' )
		{
			objForm.hdnIsCostReqd.value =  "Y";
			isCostReqdChanged =true;
			//alert('if cost is selected:'+objForm.hdnIsCostReqd.value);
		}
		else
		{
			if(!isCostReqdChanged)
			{
				objForm.hdnIsCostReqd.value =  "N";
			}
		}
		if(objForm.chk_SelCol[i].value=='LOCATION')
		{
			objForm.hdnIsSiteSel.value='Y';
			//alert('if location '+objForm.hdnIsCostReqd.value);
			if(objForm.hdnIsCostReqd.value=='Y')
			{
				//alert('LOCATION_IND');
				objForm.hdnSelColumns.value=objForm.hdnSelColumns.value+"LOCATION_IND"+strColDelim;
			}
			else
			{
				objForm.hdnSelColumns.value=objForm.hdnSelColumns.value+objForm.chk_SelCol[i].value+strColDelim;
			}
			objForm.hdnSelColumns.value=objForm.hdnSelColumns.value+"LOCATION_HIDDEN_INDICATOR"+strColDelim;
		}
		else
		{
			objForm.hdnSelColumns.value=objForm.hdnSelColumns.value+objForm.chk_SelCol[i].value+strColDelim;
		}
		if(objForm.chk_SelCol[i].value=='TAT')
		{
			//objForm.hdnSelEnColumns.value=objForm.hdnSelEnColumns.value+objForm.chk_SelCol[i].value+strColDelim;
			objForm.hdnSelColumns.value=objForm.hdnSelColumns.value+"TAT_INCREMENTAL"+strColDelim;
		}
		if(objForm.chk_SelCol[i].value=='PRICE')
		{
			//objForm.hdnSelEnColumns.value=objForm.hdnSelEnColumns.value+objForm.chk_SelCol[i].value+strColDelim;
			objForm.hdnSelColumns.value=objForm.hdnSelColumns.value+"PRICE_INCREMENTAL"+strColDelim;
		}		
	 }
     }
     if(colsSel==0)
     {
     	alertMsgs(eCRDAdhocColSelect);
     	return;
     }
     /*
     Checking for price where clause to be proper
     */
     if(objForm.cmb_wherePrice.selectedIndex==0)
     {
     	if(objForm.txt_Price.value!='')
     	{
     	  alertMsgs(eCRDEnterPricCond);
     	  return;
     	}
     }
     else
     {
     	if(objForm.txt_Price.value=='')
	   {
	  alertMsgs(eCRDPrice);
	  return;
     	}
     	else
     	{
     	 isCriteriaSel =true;
     	}
     }
     if(objForm.hdnIsSiteSel.value!='Y' && objForm.hdnIsCostReqd.value=='Y')
     {
      	alert(eCRDSiteDisplayable);
	return;
     }
     /*
          Checking for Cost where clause to be proper
     */
     if(objForm.cmb_whereCost.selectedIndex==0)
     {
	if(objForm.txt_Cost.value!='')
	{
	  alertMsgs(eCRDEnterCostCond);
	  return;
	}
     }
     else
     {
       	if(objForm.txt_Cost.value=='')
     	{
     	  alertMsgs(eCRDEnterCost);
     	  return;
       	}
       	else
	{
	 isCriteriaSel =true;
	 /*
	 if(objForm.hdnIsSiteSel.value!='Y' || objForm.hdnIsCostReqd.value!='Y')
	 {
	  	alert("Please select site or cost as a displayable column");
	  	return;
	 }
	 */
	 if(objForm.hdnIsSiteSel.value!='Y' )
	 {
	 	alert(eCRDSiteDisplayable);
	 	return;
	 }
     	}
     }
     /*
     Checking for price type
     */
     if( (objForm.cmb_wherePriceType.selectedIndex!=0 && objForm.cmb_priceType.selectedIndex==0)
     ||(objForm.cmb_wherePriceType.selectedIndex==0 && objForm.cmb_priceType.selectedIndex!=0) )
     {
     	alertMsgs(eCRDEnterPriceCrit);
     	return;
     }
     if(objForm.cmb_wherePriceType.selectedIndex!=0 || objForm.cmb_priceType.selectedIndex!=0)
     {
     	isCriteriaSel =true;
     }
     if(objForm.chkPartNum.checked)
     {
     	objForm.hdnPartNum.value='Y';
     	isCriteriaSel =true;
     }
     else
     {
     	objForm.hdnPartNum.value='N';
     }

     if(objForm.chkRepairNum.checked)
     {
	objForm.hdnRepairNum.value='Y';
	isCriteriaSel =true;
     }
     else
     {
	objForm.hdnRepairNum.value='N';
     }
   //06-07-06 Patni checking Engine model selection Begin 
	/* if(objForm.cmb_engmodel.selectedIndex!=0)
	 {
		 isCriteriaSel =true;
	 }*/
	//Added By Santosh
	    var oselecteng = objForm.cmb_engmodel;
	    var count = 0;
	    for(var i=0;i<oselecteng.options.length;i++){
			if(oselecteng.options[i].selected)
			{
				count++;
			}
		}
	    if(count<1)
	    	{
	    	alert("Please select Engine Model !");
	    	return;
	    	}
	    else
	    	{
	    	isCriteriaSel =true;
	    	}
	  //Ended By Santosh
	
   //06-07-06 Patni checking Engine model selection Begin 

     if(isCriteriaSel)
     {
	var strJspPath = basePath + '/ecrd/jsp/eCRDDownloadExcel.jsp';
	strLoc= strJspPath+"?hdnCatalogValue=Adhoc_Report&hdnReportType="+objForm.hdnReportType.value;
	strLoc+="&hdnSeqOfColums="+objForm.hdnSeqOfColums.value;
	strLoc+="&hdnSelColumns="+objForm.hdnSelColumns.value;
	strLoc+="&hdnPartNum="+objForm.hdnPartNum.value;
	strLoc+="&hdnRepairNum="+objForm.hdnRepairNum.value;
	strLoc+="&cmb_whereCost="+objForm.cmb_whereCost.options[objForm.cmb_whereCost.selectedIndex].value;
	strLoc+="&cmb_whereCost_text="+objForm.cmb_whereCost.options[objForm.cmb_whereCost.selectedIndex].text;
	strLoc+="&txt_Cost="+objForm.txt_Cost.value;
	strLoc+="&cmb_wherePrice="+objForm.cmb_wherePrice.options[objForm.cmb_wherePrice.selectedIndex].value;
	strLoc+="&cmb_wherePrice_text="+objForm.cmb_wherePrice.options[objForm.cmb_wherePrice.selectedIndex].text;
	strLoc+="&txt_Price="+objForm.txt_Price.value;
	strLoc+="&cmb_wherePriceType="+objForm.cmb_wherePriceType.options[objForm.cmb_wherePriceType.selectedIndex].value;
	strLoc+="&cmb_wherePriceType_text="+objForm.cmb_wherePriceType.options[objForm.cmb_wherePriceType.selectedIndex].text;
	strLoc+="&cmb_priceType=" +objForm.cmb_priceType.options[objForm.cmb_priceType.selectedIndex].value;
	strLoc+="&cmb_incPrice="  +objForm.cmb_incPrice.options[objForm.cmb_incPrice.selectedIndex].value;
	strLoc+="&cmb_incTAT="    +objForm.cmb_incTAT.options[objForm.cmb_incTAT.selectedIndex].value;
	strLoc+="&hdnIsCostReqd=" +objForm.hdnIsCostReqd.value;
	strLoc+="&hdnIsSiteSel="  +objForm.hdnIsSiteSel.value;
    // 11-06-2006 Patni passing Engine model Begin 
    //strLoc+="&cmb_engmodel="  +objForm.cmb_engmodel.options[objForm.cmb_engmodel.selectedIndex].value;
   // strLoc+="&cmb_engmodel_text="+objForm.cmb_engmodel.options[objForm.cmb_engmodel.selectedIndex].text;
  //Added By Santosh
	var oselect = objForm.cmb_engmodel;
	
	//var oselect=document.getElementById("engmdl_id");
	var strEngMdls='';
	var strEngMdl_txt='';
	for(var i=0;i<oselect.options.length;i++){
		if(oselect.options[i].selected)
		{
			strEngMdls = strEngMdls +oselect.options[i].value+ "^";
			strEngMdl_txt = strEngMdl_txt + oselect.options[i].text+"^";
		}
	}
	
	var oselectsite = objForm.cmb_site;

	var strSite='';
	var strSite_txt='';
	for(var i=0;i<oselectsite.options.length;i++){
		if(oselectsite.options[i].selected)
		{
			strSite = strSite +oselectsite.options[i].value+ "^";
			strSite_txt = strSite_txt + oselectsite.options[i].text+"^";
		}
	}
	
    strLoc+="&cmb_engmodel="+strEngMdls;
    strLoc+="&cmb_engmodel_text="+strEngMdl_txt;
    strLoc+="&cmb_site="+strSite;
    strLoc+="&cmb_site_test="+strSite_txt;
    features="toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=400,height=200,hide=yes";
    window.open(strLoc,"excelfile","Download Report","status=no,toolbar=no,menubar=no,scrollbars=no,resizable=no,width=350,height=225");
	
    
    // Ended By Santosh
    
    
    
    
    
    
	// 11-06-2006 Patni passing Engine model End 
	
	//document.navframe.location = strLoc;
	//alert(objForm.hdnIsCostReqd.value)
	objForm.hdnIsCostReqd.value='';
	objForm.hdnIsSiteSel.value='';
	objForm.hdnPartNum.value='';
	objForm.hdnRepairNum.value='';
	objForm.reset();
	objForm.hdnSeqOfColums.value=defSeq;
	objForm.hdnSelColumns.value=defSelected;
	objForm.hdnReportType.value="eCRDCUSTADHOCREPORT";
     }
     else
     {
     	alertMsgs(eCRDEnterRepCrit);
     }

}

/*function fnGenerateEnhancedCustReport(objForm,strColDelim,basePath,defSelected,defSeq)
{
    var colsSel = 0 ;
    var isCriteriaSel = false;
    var isCostReqdChanged = false;
    objForm.hdnSelEnColumns.value=defSelected;
    
    if cost criteria selected then site should be one at a time
    
    if((objForm.cmb_whereCost.selectedIndex!=0) && (objForm.txt_Cost.value!=''))
    {
    	objForm.hdnIsCostReqd.value='Y';
    	isCostReqdChanged =true;
    }
    for(var i=0;i<objForm.chk_SelCol.length;i++)
    {
	if(objForm.chk_SelCol[i].checked)
	{
		colsSel++;
		//alert(objForm.chk_SelCol[i].value)
		if(objForm.chk_SelCol[i].value=='COST' || objForm.chk_SelCol[i].value=='CM' )
		{
			objForm.hdnIsCostReqd.value =  "Y";
			isCostReqdChanged =true;
			//alert('if cost is selected:'+objForm.hdnIsCostReqd.value);
		}
		else
		{
			if(!isCostReqdChanged)
			{
				objForm.hdnIsCostReqd.value =  "N";
			}
		}
		if(objForm.chk_SelCol[i].value=='LOCATION')
		{
			objForm.hdnIsSiteSel.value='Y';
			//alert('if location '+objForm.hdnIsCostReqd.value);
			if(objForm.hdnIsCostReqd.value=='Y')
			{
				//alert('LOCATION_IND');
				objForm.hdnSelEnColumns.value=objForm.hdnSelEnColumns.value+"LOCATION_IND"+strColDelim;
			}
			else
			{
				objForm.hdnSelEnColumns.value=objForm.hdnSelEnColumns.value+objForm.chk_SelCol[i].value+strColDelim;
			}
			objForm.hdnSelEnColumns.value=objForm.hdnSelEnColumns.value+"LOCATION_HIDDEN_INDICATOR"+strColDelim;
		}
		if(objForm.chk_SelCol[i].value=='TAT')
		{
			objForm.hdnSelEnColumns.value=objForm.hdnSelEnColumns.value+objForm.chk_SelCol[i].value+strColDelim;
			objForm.hdnSelEnColumns.value=objForm.hdnSelEnColumns.value+"TAT_INCREMENTAL"+strColDelim;
		}
		if(objForm.chk_SelCol[i].value=='PRICE')
		{
			objForm.hdnSelEnColumns.value=objForm.hdnSelEnColumns.value+objForm.chk_SelCol[i].value+strColDelim;
			objForm.hdnSelEnColumns.value=objForm.hdnSelEnColumns.value+"PRICE_INCREMENTAL"+strColDelim;
		}
		else
		{
			objForm.hdnSelEnColumns.value=objForm.hdnSelEnColumns.value+objForm.chk_SelCol[i].value+strColDelim;
		}
	}
    }
    if(colsSel==0)
    {
    	alertMsgs(eCRDAdhocColSelect);
    	return;
    }
    
    Checking for price where clause to be proper
    
    if(objForm.cmb_wherePrice.selectedIndex==0)
    {
    	if(objForm.txt_Price.value!='')
    	{
    	  alertMsgs(eCRDEnterPricCond);
    	  return;
    	}
    }
    else
    {
    	if(objForm.txt_Price.value=='')
	   {
	  alertMsgs(eCRDPrice);
	  return;
    	}
    	else
    	{
    	 isCriteriaSel =true;
    	}
    }
    if(objForm.hdnIsSiteSel.value!='Y' && objForm.hdnIsCostReqd.value=='Y')
    {
     	alert(eCRDSiteDisplayable);
	return;
    }
    
         Checking for Cost where clause to be proper
    
    if(objForm.cmb_whereCost.selectedIndex==0)
    {
	if(objForm.txt_Cost.value!='')
	{
	  alertMsgs(eCRDEnterCostCond);
	  return;
	}
    }
    else
    {
      	if(objForm.txt_Cost.value=='')
    	{
    	  alertMsgs(eCRDEnterCost);
    	  return;
      	}
      	else
	{
	 isCriteriaSel =true;
	 
	 if(objForm.hdnIsSiteSel.value!='Y' || objForm.hdnIsCostReqd.value!='Y')
	 {
	  	alert("Please select site or cost as a displayable column");
	  	return;
	 }
	 
	 if(objForm.hdnIsSiteSel.value!='Y' )
	 {
	 	alert(eCRDSiteDisplayable);
	 	return;
	 }
    	}
    }
    
    Checking for price type
    
    if( (objForm.cmb_wherePriceType.selectedIndex!=0 && objForm.cmb_priceType.selectedIndex==0)
    ||(objForm.cmb_wherePriceType.selectedIndex==0 && objForm.cmb_priceType.selectedIndex!=0) )
    {
    	alertMsgs(eCRDEnterPriceCrit);
    	return;
    }
    if(objForm.cmb_wherePriceType.selectedIndex!=0 || objForm.cmb_priceType.selectedIndex!=0)
    {
    	isCriteriaSel =true;
    }
    if(objForm.chkPartNum.checked)
    {
    	objForm.hdnPartNum.value='Y';
    	isCriteriaSel =true;
    }
    else
    {
    	objForm.hdnPartNum.value='N';
    }

    if(objForm.chkRepairNum.checked)
    {
	objForm.hdnRepairNum.value='Y';
	isCriteriaSel =true;
    }
    else
    {
	objForm.hdnRepairNum.value='N';
    }
  //06-07-06 Patni checking Engine model selection Begin 
	 if(objForm.cmb_engmodel.options.length!=0)
	 {
		 isCriteriaSel =true;
	 }
	 
    //Added By Santosh
    var oselecteng = objForm.cmb_engmodel;
    var count = 0;
    for(var i=0;i<oselecteng.options.length;i++){
		if(oselecteng.options[i].selected)
		{
			count++;
		}
	}
    if(count<1)
    	{
    	alert("Please select Engine Model !");
    	return;
    	}
    else
    	{
    	isCriteriaSel =true;
    	}
  //Ended By Santosh
  //06-07-06 Patni checking Engine model selection Begin 

    if(isCriteriaSel)
    {
	    //objForm.hdnReportType.value="eCRDENHADHOCREPORT";
	    var rptType="eCRDENHCUSTADHOCREPORT";
		var strJspPath = basePath + '/ecrd/jsp/eCRDDownloadExcel.jsp';
		strLoc= strJspPath+"?hdnCatalogValue=Adhoc_Report&hdnReportType="+rptType;
		strLoc+="&hdnSeqOfEnColums="+objForm.hdnSeqOfEnColums.value;
		strLoc+="&hdnSelEnColumns="+objForm.hdnSelEnColumns.value;
		strLoc+="&hdnPartNum="+objForm.hdnPartNum.value;
		strLoc+="&hdnRepairNum="+objForm.hdnRepairNum.value;
		strLoc+="&cmb_whereCost="+objForm.cmb_whereCost.options[objForm.cmb_whereCost.selectedIndex].value;
		strLoc+="&cmb_whereCost_text="+objForm.cmb_whereCost.options[objForm.cmb_whereCost.selectedIndex].text;
		strLoc+="&txt_Cost="+objForm.txt_Cost.value;
		strLoc+="&cmb_wherePrice="+objForm.cmb_wherePrice.options[objForm.cmb_wherePrice.selectedIndex].value;
		strLoc+="&cmb_wherePrice_text="+objForm.cmb_wherePrice.options[objForm.cmb_wherePrice.selectedIndex].text;
		strLoc+="&txt_Price="+objForm.txt_Price.value;
		strLoc+="&cmb_wherePriceType="+objForm.cmb_wherePriceType.options[objForm.cmb_wherePriceType.selectedIndex].value;
		strLoc+="&cmb_wherePriceType_text="+objForm.cmb_wherePriceType.options[objForm.cmb_wherePriceType.selectedIndex].text;
		strLoc+="&cmb_priceType=" +objForm.cmb_priceType.options[objForm.cmb_priceType.selectedIndex].value;
		strLoc+="&cmb_incPrice="  +objForm.cmb_incPrice.options[objForm.cmb_incPrice.selectedIndex].value;
		strLoc+="&cmb_incTAT="    +objForm.cmb_incTAT.options[objForm.cmb_incTAT.selectedIndex].value;
		strLoc+="&hdnIsCostReqd=" +objForm.hdnIsCostReqd.value;
		strLoc+="&hdnIsSiteSel="  +objForm.hdnIsSiteSel.value;
	    // 11-06-2006 Patni passing Engine model Begin 
		// strLoc+="&cmb_engmodel="  +objForm.cmb_engmodel.options[objForm.cmb_engmodel.selectedIndex].value;
		// strLoc+="&cmb_engmodel_text="+objForm.cmb_engmodel.options[objForm.cmb_engmodel.selectedIndex].text;
		
		//Added By Santosh
		var oselect = objForm.cmb_engmodel;
		
		//var oselect=document.getElementById("engmdl_id");
		var strEngMdls='';
		var strEngMdl_txt='';
		for(var i=0;i<oselect.options.length;i++){
			if(oselect.options[i].selected)
			{
				strEngMdls = strEngMdls +oselect.options[i].value+ "^";
				strEngMdl_txt = strEngMdl_txt + oselect.options[i].text+"^";
			}
		}
		
		var oselectsite = objForm.cmb_site;

		var strSite='';
		var strSite_txt='';
		for(var i=0;i<oselectsite.options.length;i++){
			if(oselectsite.options[i].selected)
			{
				strSite = strSite +oselectsite.options[i].value+ "^";
				strSite_txt = strSite_txt + oselectsite.options[i].text+"^";
			}
		}
		
	    strLoc+="&cmb_engmodel="+strEngMdls;
	    strLoc+="&cmb_engmodel_text="+strEngMdl_txt;
	    strLoc+="&cmb_site="+strSite;
	    strLoc+="&cmb_site_test="+strSite_txt;
	    
	   // var strJspPath1 = basePath + '/ecrd/jsp/DownloadingPage.jsp';
	    
	    features="toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=400,height=200,hide=yes";
	    window.open(strLoc,"excelfile","Download Report","status=no,toolbar=no,menubar=no,scrollbars=no,resizable=no,width=350,height=225");
		//newwin.document.write("<img src='"+basePath + "/ecrd/img/download_status.gif' align='middle'>");
		//newwin.document.write("<h2>Loading....</h2>");
	    
	    // Ended By Santosh
		// 11-06-2006 Patni passing Engine model End 
		
		//document.navframe.location = strLoc;
		//alert(objForm.hdnIsCostReqd.value)
		objForm.hdnIsCostReqd.value='';
		objForm.hdnIsSiteSel.value='';
		objForm.hdnPartNum.value='';
		objForm.hdnRepairNum.value='';
		objForm.reset();
		objForm.hdnSeqOfEnColums.value=defSeq;
		objForm.hdnSelEnColumns.value=defSelected;
		//objForm.hdnReportType.value="eCRDADHOCREPORT";
		//var strJspPath1 = basePath + '/ecrd/jsp/DownloadingPage.jsp';
		
    }
    else
    {
    	alertMsgs(eCRDEnterRepCrit);
    }

}
*/

//Adding Customer Adhoc Repair Reports ended

function fnShowSiteSeq(objForm,basePath,ecrdServ)
{
	window.open(basePath+"/ecrd?hdnScreenName=eCRDReports&hdnScreenAction=eCRDAdhocSeq","win_seqCol","toolbar=no,location=no,width=640,height=500,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,title=Specify Column Sequence");
}

//Added by Bora
function fnShowEnSiteSeq(objForm,basePath,ecrdServ)
{
	window.open(basePath+"/ecrd?hdnScreenName=eCRDReports&hdnScreenAction=eCRDEnAdhocSeq","win_EnSeqCol","toolbar=no,location=no,width=640,height=500,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,title=Specify Column Sequence");
}
//End Bora
//Adding Customer Adhoc Repair Reports started DES1121903 sujitha 

function fnShowCustSiteSeq(objForm,basePath,ecrdServ)
{
	window.open(basePath+"/ecrd?hdnScreenName=eCRDReports&hdnScreenAction=eCRDCustadhocSeq","win_seqCol","toolbar=no,location=no,width=640,height=500,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,title=Specify Column Sequence");
}

function fnShowEnCustSiteSeq(objForm,basePath,ecrdServ)
{
	
	//window.open(basePath+"/ecrd?hdnScreenName=eCRDReports&hdnScreenAction=eCRDEnCustadhocSeq","win_EnSeqCol","toolbar=no,location=no,width=640,height=500,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,title=Specify Column Sequence");
	window.open(basePath+"/ecrd?hdnScreenName=eCRDReports&hdnScreenAction=eCRDCustadhocSeq","win_EnSeqCol","toolbar=no,location=no,width=640,height=500,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,title=Specify Column Sequence");

}

//Adding Customer Adhoc Repair Reports ended
function fnDoneWithSeq(objForm,strColDel)
{
	window.opener.document.frmViewReports.hdnSeqOfColums.value="";
	for(var i=0;i<objForm.lstSeqCols.length;i++)
	{
		window.opener.document.frmViewReports.hdnSeqOfColums.value
		=window.opener.document.frmViewReports.hdnSeqOfColums.value+
		objForm.lstSeqCols.options[i].value+strColDel;
	}

	window.close();
}

//Added by Bora
function fnDoneWithEnSeq(objForm,strColDel)
{
	window.opener.document.frmViewReports.hdnSeqOfEnColums.value="";
	for(var i=0;i<objForm.lstSeqCols.length;i++)
	{
		window.opener.document.frmViewReports.hdnSeqOfEnColums.value
		=window.opener.document.frmViewReports.hdnSeqOfEnColums.value+
		objForm.lstSeqCols.options[i].value+strColDel;
	}

	window.close();
}
//End Bora
//Adding Customer Adhoc Repair Reports started DES1121903 sujitha  

function fnDoneWithCustSeq(objForm,strColDel)
{
	

	window.opener.document.frmViewReports2.hdnSeqOfColums.value="";
	for(var i=0;i<objForm.lstSeqCols.length;i++)
	{
		window.opener.document.frmViewReports2.hdnSeqOfColums.value
		=window.opener.document.frmViewReports2.hdnSeqOfColums.value+
		objForm.lstSeqCols.options[i].value+strColDel;
	}

	window.close();
}


function fnDoneWithEnCustSeq(objForm,strColDel)
{
	window.opener.document.frmViewReports.hdnSeqOfEnColums.value="";
	for(var i=0;i<objForm.lstSeqCols.length;i++)
	{
		window.opener.document.frmViewReports.hdnSeqOfEnColums.value
		=window.opener.document.frmViewReports.hdnSeqOfEnColums.value+
		objForm.lstSeqCols.options[i].value+strColDel;
	}

	window.close();
}
//Adding Customer Adhoc Repair Reports ended
function fnGoToColSel(objForm)
{
	var selIndex = objForm.cmbEngModel.selectedIndex;
	if(selIndex == 0)
	{
		alertMsgs(eCRDSelEngModel);
		return;
	}
	else
	{
		objForm.hdnEngModelCd.value=objForm.cmbEngModel.options[selIndex ].text;
		objForm.hdnEngModelDesc.value=objForm.cmbEngModel.options[selIndex ].value;
		objForm.submit();
	}
}
function fnCostReqd(objCheckBox)
{
	if( objCheckBox.value == "LOCATION" )
	{
		if( objCheckBox.checked )
		{
		     document.frmViewReports.hdnIsSiteSel.value  =  "Y";
		}
		else
		{
		    document.frmViewReports.hdnIsSiteSel.value  =  "N";
		}
	}
	if( objCheckBox.checked )
	{
	   if( objCheckBox.checked )
	   {
		document.frmViewReports.hdnIsCostReqd.value  =  "Y";
	   }
	   else
	   {
	       document.frmViewReports.hdnIsCostReqd.value  =  "N";
	   }
	}
}

// This function is used to display the Price Changes Listing Report Yearly

function fnViewPriceChangeListingReportYearly(objForm)
{
    if(objForm.lstModule.selectedIndex ==0)
   {
      alertMsgs(eCRDSelEngModule);
      return;
   }
   else
   {
      objForm.hdnScreenName.value = "eCRDPriceListChanges";
      objForm.hdnScreenAction.value = "eCRDViewPriceChangeListingReportYearly";
      objForm.submit();
   }
}
