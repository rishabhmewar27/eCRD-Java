function fnLoadComponent(form)
	{
		with(form)
		{
			
			strEngModule = selEngineModule.value;
			hdnEngineModule.value = strEngModule;
			action = basePath+"/ecrd?hdnScreenName=testing&hdnScreenAction=addcomponent";
			submit();
		}
	}