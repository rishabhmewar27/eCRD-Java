// This function is used to change the values of the Engine Module corresponding
// to the value of the Engine Model

function fnChangeEngineModule(objForm)
{
   objForm.hdnEngineModelDesc.value=objForm.lstEngineModel.options[objForm.lstEngineModel.selectedIndex].value;
   objForm.submit();
}

// This function is used to pop up the component table page
function fnPopComponentTable(objForm,basePath)
{
   var strEngineModel = objForm.lstEngineModel.options[objForm.lstEngineModel.selectedIndex].value;
   var strEngineModule = objForm.lstEngineModule.options[objForm.lstEngineModule.selectedIndex].value;
   var strEngineModuleDescription =objForm.lstEngineModule.options[objForm.lstEngineModule.selectedIndex].text;
   
  
   if(objForm.lstEngineModel.selectedIndex==0 || strEngineModel=="")
   {
       alert(eCRDSelect+ " Engine Model");
       objForm.lstEngineModel.focus();
       return false;
   }
   
   if(objForm.lstComponent.selectedIndex==0)
   {
       alertMsgs(eCRDSelect+ " Component Code / Description");
       objForm.lstComponent.focus();
       return false;
   }
   var strComponentCode = objForm.txtComponent.value;
   strComponentCode = fnRemoveSpaces(strComponentCode);
   
   if(strComponentCode=="")
   {
      objForm.txtComponent.focus();
      alertMsgs(eCRDempty + "Component "  +objForm.lstComponent.options[objForm.lstComponent.selectedIndex].text);
      objForm.txtComponent.value="";
      return false;
   }
   else
   {
   	  if(strComponentCode.length>3)	{
   	  objForm.txtComponent.focus();
      alertMsgs(eCRDempty + "Correct Value or '%%%' for Search");
      objForm.txtComponent.value="";
      return false;
   	  }
   
      strComponent =  objForm.lstComponent.options[objForm.lstComponent.selectedIndex].text;
      features='toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,width=500,height=300';
      dlg = window.open (basePath+"/ecrd?hdnScreenName=eCRDManageComponent&hdnScreenAction=eCRDViewModifyComponentTable&hdnEngineModelDesc=" + strEngineModel + "&hdnEngineModuleDesc=" + strEngineModule +"&hdnComponent=" + strComponent +"&hdnComponentValue=" + strComponentCode +"&hdnEngineModuleDescription="+strEngineModuleDescription+"&RandomValue="+Math.random(),"Dialog",features);
   }
}


// This function is used to check if user has selected engine model

function fnSelectEngineModule(objForm)
{
   if(objForm.lstEngineModel.selectedIndex==0)
   {
       alertMsgs(eCRDSelect+ " Engine Model");
       objForm.lstEngineModel.focus();
   }
}
//TO Download Component Details
function fnDownloadBatch(objForm,basepath)
	{
		var strEngineModel 		= objForm.lstEngineModel.options[objForm.lstEngineModel.selectedIndex].value;
		var strEngineModelDesc 	= objForm.lstEngineModel.options[objForm.lstEngineModel.selectedIndex].text;
		var strEngineModule 	= objForm.lstEngineModule.options[objForm.lstEngineModule.selectedIndex].value; 
		var strComponentVal 	= objForm.txtComponent.value;
   		var strLocationVal  	= objForm.lstCompLocation.options[objForm.lstCompLocation.selectedIndex].value; 
		
		if(objForm.lstEngineModel.selectedIndex==0 || strEngineModel=="")
   		{
	       alertMsgs(eCRDSelEngModel);
	       objForm.lstEngineModel.focus();
	       return false;
   		}
		
		var strJspPath = basepath + '/ecrd/jsp/eCRDComponentDownload.jsp';
	
		//setting the features to the child window.
		features="toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=500,height=300,hide=yes";
		//opening the child window with the specified path.
		window.open(strJspPath+"?hdnEngineModel="+strEngineModel+"&hdnEngineModelDesc="+strEngineModelDesc+"&hdnEngineModule="+strEngineModule+"&hdnComponentCode="+strComponentVal+"&hdnCompLocation="+strLocationVal,"excelfile","Component Download","status=no,toolbar=no,menubar=no,scrollbars=no,resizable=no,width=350,height=225");
	
	}
// To Upload Component Details
function submitCallUpload()
{
    var controller	= "";    
	var fileName = document.frmComponentUpload.Browse.value;
	var strEngineModel = document.frmComponentUpload.lstEngineModel.options[document.frmComponentUpload.lstEngineModel.selectedIndex].value;
	var strEngineModelDesc 	= document.frmComponentUpload.lstEngineModel.options[document.frmComponentUpload.lstEngineModel.selectedIndex].text;
    	
	if(document.frmComponentUpload.lstEngineModel.selectedIndex==0 || strEngineModel=="")
   	{
	       alertMsgs(eCRDSelEngModel);
	       objForm.lstEngineModel.focus();
	       return false;
   	}
	if(fileName != null && fileName!='')
	{		
		var extension=fileName.substring(fileName.indexOf(".")+1, fileName.length);
		if(extension.toUpperCase() =='XLS' || extension.toUpperCase() =='XLSX')			//Changes made for Office 2010.
		{ 
			document.frmComponentUpload.hdnFile.value=fileName.substring(fileName.lastIndexOf("\\")+1, fileName.length);
			document.frmComponentUpload.hdnFilePath.value=fileName;
			document.frmComponentUpload.hdnEngineModel.value = strEngineModel;
			document.frmComponentUpload.hdnEngineModelDesc.value = strEngineModelDesc;
			document.frmComponentUpload.hdnScreenName.value = "BatchDownloadUpload";
			document.frmComponentUpload.hdnScreenAction.value = "eCRDComponentUploadOperation";			
			controller = 	document.frmComponentUpload.hdnControlPath.value;
	        document.frmComponentUpload.action = controller+"?hdnScreenName=BatchDownloadUpload&hdnScreenAction=eCRDComponentUploadOperation&hdnFilePath=" + fileName + "&hdnEngineModel="+strEngineModel+"&hdnFile=" + fileName+"&hdnEngineModelDesc="+strEngineModelDesc;
			document.frmComponentUpload.submit();
		}
		else
		{
			alert("Please select XLS or XLSX file Only");			//Changes made for Office 2010.
			return false;
		}
	}
	else
	{
			alert("Please select a file to upload");
			document.frmComponentUpload.Browse.focus();
			return false;
	}
}
//TO Navigate back to View/modify Component page		
function fnComponentUploadback(objForm)
{
	objForm.hdnScreenName.value = "eCRDManageComponent";
	objForm.hdnScreenAction.value = "eCRDViewModifyComponent";	
	objForm.submit();
}