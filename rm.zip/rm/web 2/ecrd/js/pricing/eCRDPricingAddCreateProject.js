
function getProjectDetails()
{

///	alert("getProjectDetails");
	document.createProject.hdnScreenName.value="eCRDAddProjectHelperScr";
    document.createProject.hdnScreenAction.value="ecrdProjectDetails";
   
    document.createProject.submit();
}



	
function calculateExtVisit()
{
	///alert("calculateExtVisit" + document.createProject.saudiRag.value);

	var csa = document.createProject.csaShopVisit.value;
	var ww = document.createProject.wwShopVisit.value;
	var tm = document.createProject.tmShopVisit.value;
	var sd = document.createProject.saudiRag.value;
	
	var tmp = ww-csa-sd;
	var tmp = tmp - tm;
	
	if(ww<0)
	{
		alert("WW Shop Visit cannot be negative ");
		 

		document.createProject.wwShopVisit.value="";
		document.getElementById("externalSpVst").innerHTML = "";
		
		return false;
	}
	else if (sd<0)
	{
		alert("Saudi Rag Shop Visit cannot be negative ");
		 

		document.createProject.saudiRag.value="";
		document.getElementById("externalSpVst").innerHTML = "";
		
		return false;
	}
	else if( csa<0)
	{
	
		alert("CSA Shop Visit cannot be negative");
		document.createProject.csaShopVisit.value="";
		document.getElementById("externalSpVst").innerHTML = "";
		return false;
	}
	else if( tm<0)
	{
	
		alert("TM Shop Visit cannot be negative ");
		document.createProject.tmShopVisit.value="";
		document.getElementById("externalSpVst").innerHTML = "";
		return false;
	} else if(tmp<0){
		document.getElementById("externalSpVst").innerHTML = "";
		alert("External Shop visit cannot be negative.");
		return false;
	} else {
		document.getElementById("externalSpVst").innerHTML = tmp;
		return true;
	}
	
	
	}

function fnValidateAddProject(objForm, action)
{

	
var date1 = document.createProject.sel_man_StartMonth.value+"-"+document.createProject.sel_man_StartDay.value+"-"+document.createProject.sel_man_StartYear.value;
var date2 = document.createProject.sel_man_EndMonth.value+"-"+document.createProject.sel_man_EndDay.value+"-"+document.createProject.sel_man_EndYear.value;
var startDate=new Date(date1);
var endDate=new Date(date2);	
        
var csa1 = document.createProject.csaShopVisit.value;
var ww1 = document.createProject.wwShopVisit.value;
var tm1 = document.createProject.tmShopVisit.value;

var ext1 = ww1-csa1;
ext1 = ext1 - tm1;



 var el = document.createProject.projectList;
  
  //var projectName = 1;
 /// alert(document.createProject.txtProjectName.value);
  for( var i=0; i<el.options.length; i++) {
    obj = el.options[i];
  //	alert(obj.text);
  	if(obj.text == document.createProject.txtProjectName.value) {
  		alert(document.createProject.txtProjectName.value+" already exists. Please enter another project name");
  		return false;
  	}
  }
   	

	
if(startDate >= endDate){
	alert("Start Date is greater or same as the End Date");
	return false;
	}
	
	
	if(!fnCheckSplChars(document.createProject.txtProjectName))
   {
        
        alertMsgs(eCRDSpecialChars + " For Project Name");
       return false;
   }
	
	
	if((document.getElementById("checkbox").checked) && (document.createProject.projectList.value==null  || document.createProject.projectList.value==''))
	{
		alert("Please Select a project");
		return false;
	}
	else if( document.createProject.txtProjectName.value==null  || document.createProject.txtProjectName.value=='')
	{
		alert("Project Name is blank ");
		return false;
	}
	else if( createProject.catalogSelect.options[createProject.catalogSelect.selectedIndex].text==null  || createProject.catalogSelect.options[createProject.catalogSelect.selectedIndex].text=='')
	{
		alert("Default Catalog is blank");
		return false;
	}
	
	else if(document.createProject.wwShopVisit.value==-1.0  ||  document.createProject.wwShopVisit.value=='')
	{
		
		alert("WW Shop Visit is blank ");
		return false;
	}
	
	else if (document.createProject.wwShopVisit.value != Math.round(document.createProject.wwShopVisit.value)){
		alert("WW Shop Visit must be a interger value. ");
		return false;
	}
	

	
	else if( document.createProject.csaShopVisit.value==-1.0  ||   document.createProject.csaShopVisit.value=='')
	{
		
		alert("CSA Shop Visit is blank ");
		return false;
	}
	else if (document.createProject.csaShopVisit.value != Math.round(document.createProject.csaShopVisit.value)){
		alert("CSA Shop Visit must be a interger value. ");
		return false;
	}
	else if( document.createProject.tmShopVisit.value==-1.0  ||   document.createProject.tmShopVisit.value=='')
	{
		alert("TM Shop Visit is blank ");
		return false;
	}
	else if (document.createProject.tmShopVisit.value != Math.round(document.createProject.tmShopVisit.value)){
		alert("TM Shop Visit must be a interger value. ");
		return false;
	}
	else if(ww1<0)
	{
		alert("WW Shop Visit cannot be negative ");
		return false;
	}
	else if( csa1<0)
	{
		alert("CSA Shop Visit cannot be negative");
		return false;
	}
	else if( tm1<0)
	{
		alert("TM Shop Visit cannot be negative ");
		return false;
	}
		else if( ext1<0)
	{
		alert("Please reenter the value for TM/ CSA/ WW Shop visit and recalculate the External Shop Visit.");
		return false;
	}
	
	else if(document.createProject.avgDiscount.value==-1.0  ||  document.createProject.avgDiscount.value=='')
	{
		alert("Average Discount is blank ");
		return false;
	}
	else if(document.createProject.annualFactor.value==-1.0 ||  document.createProject.annualFactor.value=='')
	{
		alert("Annual Factor is blank ");
		return false;
	}
	
	
	document.createProject.extShopVisit.value=document.getElementById("externalSpVst").innerHTML;
	
        
         document.createProject.hdnScreenName.value="eCRDEditProjectHelperScr";
         document.createProject.hdnScreenAction.value="ecrdCreateProject";
         
         
         document.createProject.meteroStartDate.value=document.createProject.sel_man_StartDay.value+"/"+document.createProject.sel_man_StartMonth.value+"/"+document.createProject.sel_man_StartYear.value;
         document.createProject.meteroEndDate.value=document.createProject.sel_man_EndDay.value+"/"+document.createProject.sel_man_EndMonth.value+"/"+document.createProject.sel_man_EndYear.value;
         //alert(document.createProject.meteroStartDate.value);
         //alert(document.createProject.meteroEndDate.value);
         ///alert(document.createProject.externalShopVisit.value);
         
         document.createProject.submit();
      
   
}

function fnValidateCalenderDate(dayDD,monthDD,yearDD)
{

   var dayVal = dayDD.options[dayDD.selectedIndex].value;
   var monthVal = monthDD.options[monthDD.selectedIndex].value;
   var yearVal = yearDD.options[yearDD.selectedIndex].value;
   var fullDateVal =yearVal+ "/" + monthVal + "/"  + dayVal ;
   return fullDateVal;
}

function onChngPrjct() {
	
	if(document.getElementById("prjct").value =="1") {		
		document.getElementById("catLog").value ="1";
		d
		/*document.getElementById("csa").value = 95;
		document.getElementById("tm").value = 116;
		document.getElementById("ext").value = 630;*/
	}
	if(document.getElementById("prjct").value =="2") {
		document.getElementById("catLog").value ="1";
		/*document.getElementById("csa").value = 98;
		document.getElementById("tm").value = 132;
		document.getElementById("ext").value = 649;*/
	}
	if(document.getElementById("prjct").value =="0") {
		document.getElementById("catLog").value ="0";
		/*document.getElementById("csa").value = "";
		document.getElementById("tm").value = "";
		document.getElementById("ext").value = "";*/
	}
	
}

function checkBoxSelect() {

	if(document.getElementById("checkbox").checked)
  	{	
	  	///alert("Check box checked");
	  	
		document.getElementById("type1").style.visibility	="visible";
		document.getElementById("type1").style.position		="relative";
		
		
	
	}
	else
  	{	
		///alert("Check box checked");
		
		document.getElementById("type1").style.visibility	="hidden";
		document.getElementById("type1").style.position		="absolute";
		document.createProject.hdnScreenName.value="eCRDAddProjectHelperScr";
	    document.createProject.hdnScreenAction.value="ecrdProjectList";
	    document.createProject.submit();
  	}
			
}

function fnnOpenExcel() {
	document.frmUXSummaryScoreCard.action = 'WipExcel.html';
	document.frmUXSummaryScoreCard.submit();
}

function changeCombo() {
	if(document.getElementById("catLog").value !="0")
	{
	document.getElementById("csa").value = 92;
	document.getElementById("tm").value = 112;
	document.getElementById("ext").value = 629;
	}
	else{
	
	document.getElementById("csa").value = "";
	document.getElementById("tm").value = "";
	document.getElementById("ext").value = "";
	}
}