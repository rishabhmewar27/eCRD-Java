

function getProjectDetails()
{
	document.createProject.hdnScreenName.value="eCRDViewModifyProjectHelperScr";
    document.createProject.hdnScreenAction.value="ecrdProjectDetails";
  //  alert("document.createProject.hdnScreenAction.value: "+document.createProject.hdnScreenAction.value);
    document.createProject.submit();
}


function calculateExtVisit(catlogtype)
{
	
	var sd = 0;
	var csa = document.createProject.csaShopVisit.value;
	var ww = document.createProject.wwShopVisit.value;
	var tm = document.createProject.tmShopVisit.value;
	if(catlogtype == "soudi")
	{
	   sd = document.createProject.txtSaudiRag.value;
	}
	var tmp = ww-csa-sd;
	var tmp = tmp - tm;
	
	if(ww<0)
	{
		alert("WW Shop Visit cannot be negative ");
		 

		document.createProject.wwShopVisit.value="";
		document.getElementById("externalSpVst").innerHTML = "";
		
		return false;
	}
	else if( csa<0)
	{
	
		alert("CSA Shop Visit cannot be negative");
		document.createProject.csaShopVisit.value="";
		document.getElementById("externalSpVst").innerHTML = "";
		return false;
	}
	
	else if (sd<0)
	{
		alert("WW Shop Visit cannot be negative ");
		 

		document.createProject.wwShopVisit.value="";
		document.getElementById("externalSpVst").innerHTML = "";
		
		return false;
	}
	else if( tm<0)
	{
	
		alert("TM Shop Visit cannot be negative ");
		document.createProject.tmShopVisit.value="";
		document.getElementById("externalSpVst").innerHTML = "";
		return false;
	} else if(tmp<0){
		document.getElementById("externalSpVst").innerHTML = "";
		alert("External Shop visit cannot be negative.");
		return false;
	} else {
		document.getElementById("externalSpVst").innerHTML = tmp;
		return true;
	}
	
	
	}

function fnValidateDeleteProject()
{
	//alert("Delete Project");
	if( document.createProject.projectList.value==null  || document.createProject.projectList.value=='')
	{
		alert("Please Select a Project");
		return false;
	}
	else
	{
		
		var answer = confirm("Are you sure you want to Delete this project?");

		////alert("fnValidateDeleteProject");
		if (answer){

		  document.createProject.hdnScreenName.value="eCRDEditProjectHelperScr";
	      document.createProject.hdnScreenAction.value="eCRDDeleteProjects";

	      document.createProject.submit();
		}
		
	}
	var date1 = document.createProject.sel_man_StartMonth.value+"-"+document.createProject.sel_man_StartDay.value+"-"+document.createProject.sel_man_StartYear.value;
	var date2 = document.createProject.sel_man_EndMonth.value+"-"+document.createProject.sel_man_EndDay.value+"-"+document.createProject.sel_man_EndYear.value;
	msd=new Date(date1);
	med=new Date(date2);
	
	
	
	  document.createProject.hdnScreenName.value="eCRDEditProjectHelperScr";
      document.createProject.hdnScreenAction.value="eCRDDeleteProjects";
      //document.createProject.submit();

	
	}
function fnValidateEditProject()
{
	var str1 = document.createProject.sel_man_StartDay.value +"/"+
	document.createProject.sel_man_StartMonth.value +"/"+ document.createProject.sel_man_StartYear.value;
	   var str2 = document.createProject.sel_man_EndDay.value +"/"+
	   document.createProject.sel_man_EndMonth.value +"/"+ document.createProject.sel_man_EndYear.value;
		
	    var date1 = document.createProject.sel_man_StartMonth.value+"-"+document.createProject.sel_man_StartDay.value+"-"+document.createProject.sel_man_StartYear.value;
		var date2 = document.createProject.sel_man_EndMonth.value+"-"+document.createProject.sel_man_EndDay.value+"-"+document.createProject.sel_man_EndYear.value;
		var startDate=new Date(date1);
		var endDate=new Date(date2);
		
	        
	var csa1 = document.createProject.csaShopVisit.value;
	var ww1 = document.createProject.wwShopVisit.value;
	var tm1 = document.createProject.tmShopVisit.value;
	
	var ext1 = ww1-csa1;
	ext1 = ext1 - tm1;

		
		if(startDate>endDate){
		alert("Start Date is greater than End Date");
		return false;
		}
	
	if( document.createProject.projectList.value==null  || document.createProject.projectList.value=='')
	{
		alert("Please Select a Project");
		return false;
	}
	else if(document.createProject.wwShopVisit.value==-1.0  ||  document.createProject.wwShopVisit.value=='')
	{
		alert("WW Shop Visit is blank ");
		return false;
	}
	else if( document.createProject.csaShopVisit.value==-1.0  ||   document.createProject.csaShopVisit.value=='')
	{
		alert("CSA Shop Visit is blank ");
		return false;
	}
	else if( document.createProject.tmShopVisit.value==-1.0  ||   document.createProject.tmShopVisit.value=='')
	{
		alert("TM Shop Visit is blank ");
		return false;
	}
	else if(ww1<0)
	{
		alert("WW Shop Visit cannot be negative ");
		return false;
	}
	else if( csa1<0)
	{
		alert("CSA Shop Visit cannot be negative");
		return false;
	}
	else if( tm1<0)
	{
		alert("TM Shop Visit cannot be negative ");
		return false;
	}
		else if( ext1<0)
	{
		alert("Please reenter the value for TM/ CSA/ WW Shop visit and recalculate the External Shop Visit.");
		return false;
	}
	
	else if(document.createProject.avgDiscount.value==-1.0  ||  document.createProject.avgDiscount.value=='')
	{
		alert("Average Discount is blank ");
		return false;
	}
	else if(document.createProject.annualFactor.value==-1.0 ||  document.createProject.annualFactor.value=='')
	{
		alert("Annual Factor is blank ");
		return false;
	}

	else
	{var frm = document.createProject;
	if(fnTrim(frm.projectName.value)) {
		if(fnTrim(frm.projectId.value)) {
			if(fnTrim(frm.catalog.value)) {
				frm.scenarioName.value = frm.catalog.options[frm.catalog.selectedIndex].text;
				frm.hdnScreenName.value="eCRDAddEditScenarioHelperScr";
				frm.hdnScreenAction.value="eCRDPricingGetScenarionAllDataActn";
				} 
		} else {
			alert("Unable to get ProjectId.");
			return false;
		}
	} else {
		alert("Please select a Project.");
		return false;
	}
		////alert("All Complete");
		var answer = confirm("Are you sure you want to save this project?");

		////alert("fnValidateDeleteProject");
		if (answer){

		  document.createProject.hdnScreenName.value="eCRDEditProjectHelperScr";
	      document.createProject.hdnScreenAction.value="eCRDUpdateProjects";
	      document.createProject.meteroStartDate.value=document.createProject.sel_man_StartDay.value+"/"+document.createProject.sel_man_StartMonth.value+"/"+document.createProject.sel_man_StartYear.value;
	      document.createProject.meteroEndDate.value=document.createProject.sel_man_EndDay.value+"/"+document.createProject.sel_man_EndMonth.value+"/"+document.createProject.sel_man_EndYear.value;
	      document.createProject.extShopVisit.value = document.getElementById("externalSpVst").innerHTML;
	      document.createProject.submit();
		}
		
	}
	
	document.createProject.extShopVisit.value=document.getElementById("externalSpVst").innerHTML;
		//document.createProject.projectName.value=;
		

         document.createProject.hdnScreenName.value="eCRDEditProjectHelperScr";
         document.createProject.hdnScreenAction.value="eCRDUpdateProjects";
         
		
         
         //alert(document.createProject.meteroStartDate.value);
         //alert(document.createProject.meteroEndDate.value);
         ///alert(document.createProject.externalShopVisit.value);
         
        //document.createProject.submit();
      
   
}

//to submit request to edit a scenario
function fnEditScenario(isChanged) {
////alert("fnEditScenario");
	
	if(isChanged) {
	var answer = confirm("Please save project before you edit scenario");
	return false;
	
	
	}
	///alert("Edit Scenario");
	
	var date1 = document.createProject.sel_man_StartMonth.value+"-"+document.createProject.sel_man_StartDay.value+"-"+document.createProject.sel_man_StartYear.value;
	var date2 = document.createProject.sel_man_EndMonth.value+"-"+document.createProject.sel_man_EndDay.value+"-"+document.createProject.sel_man_EndYear.value;
	msd=new Date(date1);
	med=new Date(date2);
	
	
	if( document.createProject.projectList.value==null  || document.createProject.projectList.value=='')
	{
		alert("Please Select a Project");
		return false;
	}
	else if(document.createProject.wwShopVisit.value==-1.0  ||  document.createProject.wwShopVisit.value=='')
	{
		alert("WW Shop Visit is blank ");
		return false;
	}
	else if( document.createProject.csaShopVisit.value==-1.0  ||   document.createProject.csaShopVisit.value=='')
	{
		alert("CSA Shop Visit is blank ");
		return false;
	}
	else if( document.createProject.tmShopVisit.value==-1.0  ||   document.createProject.tmShopVisit.value=='')
	{
		alert("TM Shop Visit is blank ");
		return false;
	}
	
	else if(document.createProject.avgDiscount.value==-1.0  ||  document.createProject.avgDiscount.value=='')
	{
		alert("Average Discount is blank ");
		return false;
	}
	else if(document.createProject.annualFactor.value==-1.0 ||  document.createProject.annualFactor.value=='')
	{
		alert("Annual Factor is blank ");
		return false;
	}
	else if(msd >= med)
	{
		alert("Start date is greater than or equals end date");
		return false;
		
	}
	
	var frm = document.createProject;
	if(fnTrim(frm.projectName.value)) {
		if(fnTrim(frm.projectId.value)) {
			if(fnTrim(frm.catalog.value)) {
				frm.scenarioName.value = frm.catalog.options[frm.catalog.selectedIndex].text;
				frm.hdnScreenName.value="eCRDAddEditScenarioHelperScr";
				frm.hdnScreenAction.value="eCRDPricingGetScenarionAllDataActn";
				frm.submit();
			} else {
				alert("Please select a Scenario.");
				return false;
			}
		} else {
			alert("Unable to get ProjectId.");
			return false;
		}
	} else {
		alert("Please select a Project.");
		return false;
	}
}

//to submit request to create a scenario
function fnCrtScenario(isChanged) {
	if(isChanged) {
		var answer = confirm("Please save project before you edit scenario");
		return false;
	}
	//alert("Create Scenario");
	var date1 = document.createProject.sel_man_StartMonth.value+"-"+document.createProject.sel_man_StartDay.value+"-"+document.createProject.sel_man_StartYear.value;
	var date2 = document.createProject.sel_man_EndMonth.value+"-"+document.createProject.sel_man_EndDay.value+"-"+document.createProject.sel_man_EndYear.value;
	msd=new Date(date1);
	med=new Date(date2);
	
	if( document.createProject.projectList.value==null  || document.createProject.projectList.value=='')
	{
		alert("Please Select a Project");
		return false;
	}
	else if(document.createProject.wwShopVisit.value==0.0  ||  document.createProject.wwShopVisit.value=='')
	{
		alert("WW Shop Visit is blank ");
		return false;
	}
	else if( document.createProject.csaShopVisit.value==-1.0  ||   document.createProject.csaShopVisit.value=='')
	{
		alert("CSA Shop Visit is blank ");
		return false;
	}
	else if( document.createProject.tmShopVisit.value==-1.0  ||   document.createProject.tmShopVisit.value=='')
	{
		alert("TM Shop Visit is blank ");
		return false;
	}
	
	else if(document.createProject.avgDiscount.value==-1.0  ||  document.createProject.avgDiscount.value=='')
	{
		alert("Average Discount is blank ");
		return false;
	}
	else if(document.createProject.annualFactor.value==-1.0 ||  document.createProject.annualFactor.value=='')
	{
		alert("Annual Factor is blank ");
		return false;
	}
	else if(msd>=med)
	{
		alert("Start date is greater than or equals end date");
		return false;
		
	}
	
	var frm = document.createProject;
	if(fnTrim(frm.projectName.value)) {
		if(fnTrim(frm.projectId.value)) {
			frm.hdnScreenName.value="eCRDAddEditScenarioHelperScr";
			frm.hdnScreenAction.value="eCRDPricingScenarionDataActn";
			frm.submit();
		} else {
			alert("Unable to get ProjectId.");
			return false;
		}
	} else {
		alert("Please select a Project.");
		return false;
	}
}

function fnValidateCalenderDate(dayDD,monthDD,yearDD)
{

   var dayVal = dayDD.options[dayDD.selectedIndex].value;
   var monthVal = monthDD.options[monthDD.selectedIndex].value;
   var yearVal = yearDD.options[yearDD.selectedIndex].value;
   var fullDateVal =yearVal+ "/" + monthVal + "/"  + dayVal ;
   return fullDateVal;
}

function onChngPrjct() {
	
	if(document.getElementById("prjct").value =="1") {		
		document.getElementById("catLog").value ="1";
		/*document.getElementById("csa").value = 95;
		document.getElementById("tm").value = 116;
		document.getElementById("ext").value = 630;*/
	}
	if(document.getElementById("prjct").value =="2") {
		document.getElementById("catLog").value ="1";
		/*document.getElementById("csa").value = 98;
		document.getElementById("tm").value = 132;
		document.getElementById("ext").value = 649;*/
	}
	if(document.getElementById("prjct").value =="0") {
		document.getElementById("catLog").value ="0";
		/*document.getElementById("csa").value = "";
		document.getElementById("tm").value = "";
		document.getElementById("ext").value = "";*/
	}
	document.getElementById("catalogSelect").disabled=false
}

function checkBoxSelect() {
	if(document.getElementById("checkbox").checked)
  	{	
	  	//alert("Check box checked");
		document.getElementById("type1").style.visibility	="visible";
		document.getElementById("type1").style.position		="relative";
		
		
	
	}
	else
  	{	
		document.getElementById("type1").style.visibility	="hidden";
		document.getElementById("type1").style.position		="absolute";
		document.getElementById("catalogSelect").disabled=false;
  	}
			
}

function fnnOpenExcel() {
	document.frmUXSummaryScoreCard.action = 'WipExcel.html';
	document.frmUXSummaryScoreCard.submit();
}

function changeCombo() {
	if(document.getElementById("catLog").value !="0")
	{
	document.getElementById("csa").value = 92;
	document.getElementById("tm").value = 112;
	document.getElementById("ext").value = 629;
	}
	else{
	
	document.getElementById("csa").value = "";
	document.getElementById("tm").value = "";
	document.getElementById("ext").value = "";
	}
}
