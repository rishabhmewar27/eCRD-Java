create or replace package ECRD_UPLOAD_COMPONENT_PKG is

  -- Created : 9/27/2006 4:12:17 PM
  -- Purpose : To upload Component Locations in Batch
  TYPE input_array IS VARRAY(4000) OF VARCHAR2(32767) ;
  type result_cursor is REF CURSOR;
  
 /************************************************************************/
  -- Procedure Name                : ecrd_master_module_loc_prc 
  -- Purpose                       : This procedure is used to get component Locations
  -- Input Parameters              : p_in_engine_model crd_crc_module.eng_mdl_number%type
  -- Input Parameters              : p_in_engine_module crd_crc_module.module_seq_id%type
  -- Input Parameters              : p_in_component_description varchar2
  -- Input Parameters              : p_in_component_value varchar2
  -- Output Parameters             : p_out_location_list result_cursor
  -- Called Procedures/Functions   : None
  -- Calling Procedures/ Functions : None
  /***********************************************************************/

    PROCEDURE ecrd_master_module_loc_prc (
              p_in_engine_model          IN crd_crc_module.eng_mdl_number%TYPE,
              p_out_module_cur           OUT result_cursor,
              p_out_location_list        OUT result_cursor
    );


  /***********************************************************************/
  -- Procedure Name                : ecrd_component_download_prc 
  -- Purpose                       : This procedure is used to get component Locations
  -- Input Parameters              : p_in_engine_model crd_crc_module.eng_mdl_number%type
  -- Input Parameters              : p_in_engine_module crd_crc_module.module_seq_id%type
  -- Input Parameters              : p_in_component_description varchar2
  -- Input Parameters              : p_in_component_value varchar2
  -- Output Parameters             : p_out_location_list result_cursor
  -- Called Procedures/Functions   : None
  -- Calling Procedures/ Functions : None
  /***********************************************************************/

    PROCEDURE ecrd_component_download_prc(
              p_in_engine_model          IN crd_crc_module.eng_mdl_number%TYPE,
              p_in_engine_module         IN crd_crc_module.module_seq_id%TYPE,
              p_in_component_description IN VARCHAR2,
              p_in_component_code        IN VARCHAR2,
              p_in_location_code         IN crd_e_component_location.location_id%TYPE,
              p_out_compoent_list        OUT result_cursor
    );
  
  
  /****************************************************************************************
  * Function  Name                : ECRD_UPLOAD_COMPONENT_PRC                            *
  * Purpose                       : This procedure is used to update component location  *                                 relations                                                        *
  *                                 EngineModle Code                                     *
  *                                 and Component Description for selected Engine Modle  *                         
  * Called Procedures/Functions   :                                                      *
  * Calling Procedures/ Functions :                                                      *
  *****************************************************************************************/

  PROCEDURE ECRD_UPLOAD_COMPONENT_PRC(
            as_engine_code	IN 	VARCHAR2,
            as_user_id 		  IN 	VARCHAR2,
            as_is_admin		  IN	VARCHAR2,
            as_sheet_name	  IN	VARCHAR2,
            as_data1_in		  IN 	VARCHAR2,
            as_data2_in		  IN 	VARCHAR2,
            as_data3_in		  IN 	VARCHAR2,
            as_data4_in		  IN 	VARCHAR2,
            as_data5_in		  IN 	VARCHAR2,
            as_data6_in		  IN 	VARCHAR2,
            as_data7_in		  IN 	VARCHAR2,
            as_data8_in		  IN 	VARCHAR2,
            as_data9_in		  IN 	VARCHAR2,
            as_data10_in	  IN 	VARCHAR2,
            as_data1_out		OUT VARCHAR2,
            as_data2_out		OUT VARCHAR2,
            as_data3_out		OUT VARCHAR2,
            as_data4_out		OUT VARCHAR2,
            as_data5_out		OUT VARCHAR2,
            as_data6_out		OUT VARCHAR2,
            as_data7_out		OUT VARCHAR2,
            as_data8_out		OUT VARCHAR2,
            as_data9_out		OUT VARCHAR2,
            as_data10_out		OUT VARCHAR2,
            as_data11_out		OUT VARCHAR2,
            as_data12_out		OUT VARCHAR2,
            as_data13_out		OUT VARCHAR2,
            as_data14_out		OUT VARCHAR2,
            as_data15_out		OUT VARCHAR2
           );

END ECRD_UPLOAD_COMPONENT_PKG;
/
create or replace package body ECRD_UPLOAD_COMPONENT_PKG is
   
   /***********************************************************************/
  -- Procedure Name                : ecrd_master_module_loc_prc 
  -- Purpose                       : This procedure is used to get component Locations
  -- Input Parameters              : p_in_engine_model crd_crc_module.eng_mdl_number%type
  -- Input Parameters              : p_in_engine_module crd_crc_module.module_seq_id%type
  -- Input Parameters              : p_in_component_description varchar2
  -- Input Parameters              : p_in_component_value varchar2
  -- Output Parameters             : p_out_location_list result_cursor
  -- Called Procedures/Functions   : None
  -- Calling Procedures/ Functions : None
  /***********************************************************************/

  PROCEDURE ecrd_master_module_loc_prc  (
            p_in_engine_model          IN crd_crc_module.eng_mdl_number%TYPE,
            p_out_module_cur           OUT result_cursor,
            p_out_location_list        OUT result_cursor
  ) IS
  
  --v_sql will hold the dynamic sql to get the corresponding engine,module, component
  v_sql VARCHAR2(32767) := NULL;
  
  BEGIN
       --This block is fetching all the modules related to a selected model
       BEGIN
            -- Retrive list of Modules from the database for engine model
            OPEN p_out_module_cur FOR
            	   SELECT CM.MODULE_SEQ_ID, 
                        CM.MODULE_NAME
                 FROM   CRD_CRC_MODULE CM
		             WHERE  CM.ENG_MDL_NUMBER = p_in_engine_model
		             ORDER BY	CM.MODULE_NAME;
                 
       EXCEPTION
            WHEN NO_DATA_FOUND THEN
                 RAISE_APPLICATION_ERROR(-20051, 
                 'NO_MODULES_FOUND ERROR IN ECRD_UPLOAD_COMPONENT_PKG.ecrd_find_location_prc' ||SQLCODE ||  ' - ' || SQLERRM);
            
            WHEN OTHERS THEN
                  RAISE_APPLICATION_ERROR(-20001,
                  'ERROR IN ECRD_UPLOAD_COMPONENT_PKG.ecrd_find_location_prc' ||SQLCODE ||  ' - ' || SQLERRM);
       END;                  
       
       BEGIN
            OPEN p_out_location_list FOR
                 SELECT distinct loc.location_id,
                        loc.site_name
                  FROM  crd_crc_module module, 
                        crd_e_component_location cecl,
                        crd_location loc
                  WHERE module.eng_mdl_number = p_in_engine_model   
                  AND   cecl.module_seq_id = module.module_seq_id 
                  AND   loc.location_id = cecl.location_id 
                  AND   cecl.active_ind =  'Y'  ;
       
       EXCEPTION
            WHEN NO_DATA_FOUND THEN
                 RAISE_APPLICATION_ERROR(-20051, 
                 'NO_MODULES_FOUND ERROR IN ECRD_UPLOAD_COMPONENT_PKG.ecrd_find_location_prc' ||SQLCODE ||  ' - ' || SQLERRM);
            
            WHEN OTHERS THEN
                  RAISE_APPLICATION_ERROR(-20001,
                  'ERROR IN ECRD_UPLOAD_COMPONENT_PKG.ecrd_find_location_prc' ||SQLCODE ||  ' - ' || SQLERRM);
       END;                          
       
  END ecrd_master_module_loc_prc ;
  -- End of function.

  /***********************************************************************/
  -- Procedure Name                : ecrd_component_download_prc
  -- Purpose                       : This procedure is used to get component Locations
  -- Input Parameters              : p_in_engine_model crd_crc_module.eng_mdl_number%type
  -- Input Parameters              : p_in_engine_module crd_crc_module.module_seq_id%type
  -- Input Parameters              : p_in_component_description varchar2
  -- Input Parameters              : p_in_component_value varchar2
  -- Output Parameters             : p_out_location_list result_cursor
  -- Called Procedures/Functions   : None
  -- Calling Procedures/ Functions : None
  /***********************************************************************/
  PROCEDURE ecrd_component_download_prc(
          p_in_engine_model          IN crd_crc_module.eng_mdl_number%TYPE,
          p_in_engine_module         IN crd_crc_module.module_seq_id%TYPE,
          p_in_component_description IN VARCHAR2,
          p_in_component_code        IN VARCHAR2,
          p_in_location_code         IN crd_e_component_location.location_id%TYPE,
          p_out_compoent_list        OUT result_cursor
  ) IS
  
  --v_sql will hold the dynamic sql to get the corresponding engine,module, component
  v_sql VARCHAR2(32767) := NULL; 
  
  BEGIN
       v_sql :=  'SELECT  DISTINCT  
                          module.module_seq_id "Module Sequence",
                          module.module_name "Module Name",
                          comp.component_code "Component Code",
                          comp.component_description "Component Description",
                          cecl.location_id "Location ID",
                          loc.site_name "Location Description",
                          CASE WHEN  cecl.SITE_SEQUENCE_NUMBER = ( 
                                                                   SELECT MIN(SITE_SEQUENCE_NUMBER) 
                                                                   FROM   CRD_CRC_MODULE            A,
                                                                          CRD_E_COMPONENT_LOCATION  B
                                                                   WHERE  B.MODULE_SEQ_ID = A.MODULE_SEQ_ID
                                                                   AND    A.ENG_MDL_NUMBER = module.eng_mdl_number
                                                                   AND    B.COMPONENT_CODE = cecl.component_code
                                                                 ) THEN ''Y''
                               ELSE ''N'' 
                          END "Primary Site",
                          NVL(cecl.hide_component_ind,''N'') "Hidden Site",
                          ''N'' "Delete Site"
                          
                          
                  FROM   crd_crc_module module, 
                         crd_e_component comp,
                         crd_e_component_location cecl,
                         crd_location loc
                  
                  WHERE  comp.module_seq_id = module.module_seq_id 
                  AND    module.eng_mdl_number = ';
     --putting the engine model in the where clause to filter the results
       v_sql := v_sql||''''||p_in_engine_model||''''; 
       v_sql := v_sql||' AND cecl.module_seq_id = module.module_seq_id 
                  AND    cecl.component_code =   comp.component_code
                  AND    cecl.location_id = loc.location_id
                  AND    cecl.active_ind =  ''Y''  
                  AND    (comp.component_end_date IS NULL OR comp.component_end_date >  SYSDATE )'; 
       -- if p_in_engine_module is not empty then have to add in the sql
       IF(p_in_engine_module !='' OR p_in_engine_module IS NOT NULL ) THEN
                  v_sql := v_sql||' AND module.module_seq_id = ';
                  v_sql := v_sql||p_in_engine_module;
       END IF;
       
       -- if p_in_component_code is not empty then have to add in the sql
       IF(p_in_component_description !='' OR p_in_component_description IS NOT NULL ) THEN
                  v_sql := v_sql||' AND comp.component_description = ';
                  v_sql := v_sql||''''||p_in_component_description||'''';
       END IF;
       
       -- if p_in_component_code is not empty then have to add in the sql
       IF(p_in_component_code !='' OR p_in_component_code IS NOT NULL ) THEN
                  v_sql := v_sql||' AND comp.component_code = ';
                  v_sql := v_sql||''''||p_in_component_code||'''';
       END IF;
       
       -- if p_in_location_code is not empty then dynamic sql should be appended
       IF(p_in_location_code IS NOT NULL OR p_in_location_code !='') THEN 
                  v_sql := v_sql||' AND cecl.location_id = ';
                  v_sql := v_sql||''''||p_in_location_code||'''';                             
       END IF;
                  
       v_sql := v_sql||' ORDER BY module.module_name,
                           comp.component_code,
                           cecl.location_id ';
        
       --opening the cursor for the dynamic sql;
       OPEN p_out_compoent_list FOR v_sql;
       
       --when Exception occurs
       EXCEPTION
            WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20051, 'NO_COMPONENTS_FOUND ERROR IN ECRD_UPLOAD_COMPONENT_PKG.ecrd_component_download_prc' ||SQLCODE ||  ' - ' || SQLERRM); 
             
            WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR (-20001,'Error in ECRD_UPLOAD_COMPONENT_PKG.ecrd_component_download_prc -'||SQLCODE||'-'||SUBSTR(SQLERRM,1,100));

  
  END ecrd_component_download_prc;
 
 /****************************************************************************************
  * Function  Name                : ECRD_UPLOAD_COMPONENT_PRC                            *
  * Purpose                       : This procedure is used to update component location  *                                 relations                                                        *
  *                                 EngineModle Code                                     *
  *                                 and Component Description for selected Engine Modle  *                         
  * Called Procedures/Functions   :                                                      *
  * Calling Procedures/ Functions :                                                      *
  *****************************************************************************************/
  
 PROCEDURE ECRD_UPLOAD_COMPONENT_PRC(
            as_engine_code	IN 	VARCHAR2,
            as_user_id 		  IN 	VARCHAR2,
            as_is_admin		  IN	VARCHAR2,
            as_sheet_name	  IN	VARCHAR2,
            as_data1_in		  IN 	VARCHAR2,
            as_data2_in		  IN 	VARCHAR2,
            as_data3_in		  IN 	VARCHAR2,
            as_data4_in		  IN 	VARCHAR2,
            as_data5_in		  IN 	VARCHAR2,
            as_data6_in		  IN 	VARCHAR2,
            as_data7_in		  IN 	VARCHAR2,
            as_data8_in		  IN 	VARCHAR2,
            as_data9_in		  IN 	VARCHAR2,
            as_data10_in	  IN 	VARCHAR2,
            as_data1_out		OUT VARCHAR2,
            as_data2_out		OUT VARCHAR2,
            as_data3_out		OUT VARCHAR2,
            as_data4_out		OUT VARCHAR2,
            as_data5_out		OUT VARCHAR2,
            as_data6_out		OUT VARCHAR2,
            as_data7_out		OUT VARCHAR2,
            as_data8_out		OUT VARCHAR2,
            as_data9_out		OUT VARCHAR2,
            as_data10_out		OUT VARCHAR2,
            as_data11_out		OUT VARCHAR2,
            as_data12_out		OUT VARCHAR2,
            as_data13_out		OUT VARCHAR2,
            as_data14_out		OUT VARCHAR2,
            as_data15_out		OUT VARCHAR2
           ) AS

   
   in_data                  input_array;
   
   ls_rem_data		          LONG;
   ls_row_comp		          LONG;
   lb_not_eof		            BOOLEAN;
   ls_row_no		            VARCHAR2(500);
   ls_module_seq            VARCHAR2(500);
   ls_module_desc           VARCHAR2(500);
   ls_comp_code             VARCHAR2(500);
   ls_comp_desc             VARCHAR2(500);
   ls_location_id           VARCHAR2(500);
   ls_location_desc         VARCHAR2(500);
   ls_primary_site          VARCHAR2(500);
   ls_hidden_site           VARCHAR2(500);
   ls_delete_site           VARCHAR2(500);

   temp_module_seq_id       NUMBER := NULL;
   temp_component           NUMBER := NULL;
   temp_location            NUMBER := NULL;
   temp_update              NUMBER := NULL;
   temp_sheetname           VARCHAR2(500) := NULL;
   temp_dual                DATE;
   /*
   This procedure is meant to populate the incoming data from 
   ECRD_UPLOAD_COMPONENT_PRC.
   */
   PROCEDURE populate_in_data
   AS
   
   BEGIN
   
    	in_data(1) := as_data1_in;
    	in_data.EXTEND(1);
    	in_data(2) := as_data2_in;
    	in_data.EXTEND(1);
    	in_data(3) := as_data3_in;
    	in_data.EXTEND(1);
    	in_data(4) := as_data4_in;
    	in_data.EXTEND(1);
    	in_data(5) := as_data5_in;
    	in_data.EXTEND(1);
    	in_data(6) := as_data6_in;
    	in_data.EXTEND(1);
    	in_data(7) := as_data7_in;
    	in_data.EXTEND(1);
    	in_data(8) := as_data8_in;
    	in_data.EXTEND(1);
    	in_data(9) := as_data9_in;
      in_data.EXTEND(1);
    	in_data(10):= as_data10_in;
   
   END populate_in_data;

   
   FUNCTION return_string(
                          aInStr    IN LONG,
                          separator IN VARCHAR2,
                          mode_type IN VARCHAR2
                          ) 
   RETURN  LONG IS
   
    	p_outStr  LONG;
   BEGIN
    	IF (mode_type = 'BEF') THEN
    		p_outStr := SUBSTR(aInStr, 1, INSTR(aInStr, separator) - 1) ;
    	ELSIF (mode_type = 'AFT') THEN
    		p_outStr := SUBSTR(aInStr, INSTR(aInStr, separator) + 1) ;
    	END IF;
    
    	return p_outStr;
   END return_string;
   
   
   /*
    This method is used to populate the Error Msgs encounterd while
    Updating the Component Location Relations, and will be returned 
    back to Front End for Display.
    */
    PROCEDURE add_error(aErrMsg IN VARCHAR2)
    IS
    
    BEGIN
    	IF ( LENGTH(NVL(as_data1_out,' ')) + LENGTH(aErrMsg) < 4000 ) THEN
    	   as_data1_out := as_data1_out || aErrMsg;
      ELSIF (LENGTH(NVL(as_data2_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
    		as_data2_out := as_data2_out || aErrMsg;
    	ELSIF (LENGTH(NVL(as_data3_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
    		as_data3_out := as_data3_out || aErrMsg;
    	ELSIF (LENGTH(NVL(as_data4_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
    		as_data4_out := as_data4_out || aErrMsg;
    	ELSIF (LENGTH(NVL(as_data5_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
    		as_data5_out := as_data5_out || aErrMsg;
    	ELSIF (LENGTH(NVL(as_data6_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
    		as_data6_out := as_data6_out || aErrMsg;
    	ELSIF (LENGTH(NVL(as_data7_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
    		as_data7_out := as_data7_out || aErrMsg;
    	ELSIF (LENGTH(NVL(as_data8_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
    		as_data8_out := as_data8_out || aErrMsg;
    	ELSIF (LENGTH(NVL(as_data9_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
    		as_data9_out := as_data9_out || aErrMsg;
    	ELSIF (LENGTH(NVL(as_data10_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
    		as_data10_out := as_data10_out || aErrMsg;
    	ELSIF (LENGTH(NVL(as_data11_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
    		as_data11_out := as_data11_out || aErrMsg;
    	ELSIF (LENGTH(NVL(as_data12_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
    		as_data12_out := as_data12_out || aErrMsg;
    	ELSIF (LENGTH(NVL(as_data13_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
    		as_data13_out := as_data13_out || aErrMsg;
    	ELSIF (LENGTH(NVL(as_data14_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
    		as_data14_out := as_data14_out || aErrMsg;
    	ELSIF (LENGTH(NVL(as_data15_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
    		as_data15_out := as_data15_out || aErrMsg;
    	END IF;
    END add_error;
    
    
   /****************************************************************************************
   * Function  Name                : ecrd_validate_sheet                                   *
   * Purpose                       : This procedure is used to validate Sheet Name with    *
   *                                 EngineModle Code                                      *
   *                                 and Component Description for selected Engine Modle   *                         
   * Input Parameters              : p_in_engMdlNum CRD_CRC_ENG_MDL_DISPLAY.ENG_MDL_NUMBER%type   *
   * Called Procedures/Functions   : None                                                  *
   * Calling Procedures/ Functions : from ECRD_UPLOAD_COMPONENT_PRC                        *
   *****************************************************************************************/
   FUNCTION ECRD_VALIDATE_SHEET( p_in_engMdlNum     IN VARCHAR2 )
   RETURN VARCHAR2 AS
   
   ENGINE_MODULE_DESC VARCHAR2(200) := NULL;
   
   BEGIN
   
	      -- Retrive list of engine models from the database
	      SELECT DISTINCT ENG_MDL_DESC 
        INTO   ENGINE_MODULE_DESC
	      FROM 	 CRD_CRC_ENG_MDL_DISPLAY 
        WHERE	 ENG_MDL_NUMBER = p_in_engMdlNum;
        --
    
   RETURN ENGINE_MODULE_DESC; 
    
   EXCEPTION
        WHEN NO_DATA_FOUND THEN
             RAISE_APPLICATION_ERROR(-20050,
             'NO_ENGINE_MODELS_FOUND ERROR IN ECRD_UPLOAD_COMPONENT_PKG.ECRD_VALIDATE_SHEET' ||
             SQLCODE ||  ' - ' || SQLERRM);
        WHEN OTHERS THEN
             RAISE_APPLICATION_ERROR(-20001,
             'ERROR IN ECRD_UPLOAD_COMPONENT_PKG.ECRD_VALIDATE_SHEET' ||
             SQLCODE ||  ' - ' || SQLERRM);
   END ECRD_VALIDATE_SHEET;
    
    
   /***************************************************************************************
   * Procedure Name                : ecrd_validate_module                                *
   * Purpose                       : This procedure is used to validate Eng Module Seq ID*
   *                                 and Module Name for selected Engine Modle           *                         
   * Input Parameters              : p_in_engine_model crd_crc_module.eng_mdl_number%type*
   * Input Parameters              : p_in_engine_module crd_crc_module.module_name%type  *
   * Input Parameters              : p_RowNum VARCHAR2                                   *
   * Called Procedures/Functions   : None                                                *
   * Calling Procedures/ Functions : ECRD_UPLOAD_COMPONENT_PRC                           *
   **************************************************************************************/
   FUNCTION ecrd_validate_module(
                           p_in_engine_model    IN CRD_CRC_ENG_MDL_DISPLAY.ENG_MDL_DESC%type,
                           p_in_model_seq_id    IN crd_crc_module.eng_mdl_number%type, 
                           p_in_engine_module   IN crd_crc_module.module_name%type,
                           p_RowNum             IN VARCHAR2
                          )
   RETURN NUMBER IS
       p_count         NUMBER := NULL;
       p_module_seq_id NUMBER := NULL;
  
  BEGIN
       p_module_seq_id := NULL;

       BEGIN 
           SELECT DISTINCT MODULE_SEQ_ID
           INTO   p_module_seq_id
           FROM   CRD_CRC_MODULE MD
           WHERE  UPPER(MD.ENG_MDL_NUMBER) = UPPER(TRIM(p_in_engine_model))
           AND    UPPER(MD.MODULE_SEQ_ID) = UPPER(TRIM(p_in_model_seq_id));
           
       EXCEPTION
           WHEN NO_DATA_FOUND THEN
                p_module_seq_id := NULL;
       END;
       
  
      IF (p_module_seq_id IS NOT NULL) THEN
          --RETURN p_module_seq_id;
          p_count := 0 ;
  	  ELSE
          add_error('Error in Row Number '|| p_RowNum|| ', Engine Module Seq Id ' || p_in_model_seq_id || ' does not exist for Engine Model '||ECRD_VALIDATE_SHEET(p_in_engine_model)||' ^');
      END IF;
      
      BEGIN
          SELECT COUNT(1)
          INTO   p_count
          FROM   CRD_CRC_MODULE   
          WHERE  UPPER(ENG_MDL_NUMBER) = UPPER(TRIM(p_in_engine_model))
          AND    UPPER(MODULE_SEQ_ID) = UPPER(TRIM(p_in_model_seq_id)) 
          AND    UPPER(MODULE_NAME) = UPPER(TRIM(p_in_engine_module));
       END;
      
          IF( p_count = 0 ) THEN 
              add_error('Error in Row Number '|| p_RowNum|| ', Engine Module '||p_in_engine_module||' is not valid for Engine Module Seq Id ' || p_in_model_seq_id || ' ^');          
              RETURN 0;
          ELSE
              RETURN p_module_seq_id;
          END IF;
  		    
  	  
  END ecrd_validate_module;

     
  /***************************************************************************************
   * Procedure Name                : ecrd_validate_component                             *
   * Purpose                       : This procedure is used to validate Component Code   *
   *                                 and Component Description for selected Engine Modle *                         
   * Input Parameters              : p_in_moduleSeqId crd_crc_module.module_seq_id%type  *
   * Input Parameters              : p_RowNum VARCHAR2                                   *
   * Called Procedures/Functions   : None                                                *
   * Calling Procedures/ Functions : from ECRD_UPLOAD_COMPONENT_PRC                      *
   **************************************************************************************/
   FUNCTION ecrd_validate_component(
                              p_in_moduleSeqId     IN VARCHAR2,
                              p_in_component_code  IN crd_e_component.component_code%type,
                              p_in_component_description   IN crd_e_component.component_description%type,
                              aRowNum              IN VARCHAR2
                             )
   RETURN NUMBER IS

	    p_count NUMBER := NULL;
  BEGIN
    	SELECT COUNT(1)
    	INTO p_count
    	FROM crd_e_component
    	WHERE Module_Seq_id = p_in_moduleSeqId
      AND   Component_Code = TRIM(p_in_component_code);
      
      
    	IF (p_count = 1) THEN
        -- To Validate Component Description for the Module Sequence ID
        SELECT COUNT(1)
        INTO p_count
        FROM crd_e_component
        WHERE Module_Seq_id = p_in_moduleSeqId
        AND   Component_Code = TRIM(p_in_component_code)
        AND   UPPER(COMPONENT_DESCRIPTION) = UPPER(TRIM(p_in_component_description));
        
        IF(p_count = 1) THEN
        		RETURN 1;
        ELSE 
        		add_error('Error in Row Number '|| aRowNum || ' Component Description ' || p_in_component_description || ' does not exist^');
            RETURN 0;
        END IF; 
    	-- if Error then add to error msg	
    	ELSE
    		add_error('Error in Row Number '|| aRowNum || ' Component Code ' || p_in_component_code || ' does not exist^');
    		RETURN 0;
    	END IF;
      
   END ecrd_validate_component;
   
     
   
   /***************************************************************************************
   * Procedure Name                : ecrd_validate_location                               *
   * Purpose                       : This procedure is used to validate Location Code     *
   *                                 and Component Description for selected Engine Modle  *                         
   * Input Parameters              : p_in_moduleSeqId crd_crc_module.module_seq_id%type   *
   * Input Parameters              : p_in_component_code crd_e_component.component_code%type*
   * Input Parameters              : p_RowNum VARCHAR2                                    *
   * Called Procedures/Functions   : None                                                 *
   * Calling Procedures/ Functions : from ECRD_UPLOAD_COMPONENT_PRC                       *
   ****************************************************************************************/
   FUNCTION ecrd_validate_location(
                              p_in_moduleSeqId     IN VARCHAR2,
                              p_in_component_code  IN crd_e_component.component_code%type,
                              p_in_locationId      IN crd_e_component_location.location_id%type,
                              p_in_location_name   IN crd_location.site_name%type,
                              aRowNum              IN VARCHAR2
                             )
   RETURN NUMBER IS
          
         p_count NUMBER := NULL; -- To Hold the Return Value
         p_loc   NUMBER := NULL; --

   BEGIN
    	SELECT COUNT(1)
    	INTO p_count
    	FROM crd_e_component_location
    	WHERE Module_Seq_id = p_in_moduleSeqId
      AND   Component_Code = TRIM(p_in_component_code)
      AND   UPPER(Location_id)= UPPER(TRIM(p_in_locationId));
    
    	IF (p_count = 1) THEN
        -- To Validate Location Description for the Location ID
        SELECT COUNT(1)
        INTO p_loc
        FROM CRD_LOCATION
        WHERE LOCATION_ID=TRIM(p_in_locationId)
        AND   UPPER(SITE_NAME) = UPPER(TRIM(p_in_location_name));
        
        IF(p_loc = 1) THEN
        		RETURN 1;
        ELSE 
        		add_error('Error in Row Number '|| aRowNum || ' Location Name ' || p_in_location_name || ' does not exist^');
            RETURN 0;
        END IF;
    	ELSE
          IF (p_count = 0) THEN
              -- To Validate Location Description for the Location ID
              SELECT COUNT(1)
              INTO p_loc
              FROM CRD_LOCATION
              WHERE LOCATION_ID=TRIM(p_in_locationId)
              AND   UPPER(SITE_NAME) = UPPER(TRIM(p_in_location_name));
        
              IF(p_loc = 1) THEN
        		      RETURN 1;
              ELSE 
        		      add_error('Error in Row Number '|| aRowNum || ' Location Name ' || p_in_location_name || ' does not exist^');
              RETURN 0;
              END IF;   
          ELSE
    		      add_error('Error in Row Number '|| aRowNum || ' Location Id ' || p_in_locationId || ' does not exist^');
          END IF;
           
    		RETURN 0;
    	END IF;
   END ecrd_validate_location;      -- End of Procedure
   
   
   /***************************************************************************************
   * Procedure Name                : ecrd_update_site                                     *
   * Purpose                       : This procedure is used to validate Location Code     *
   *                                 and Component Description for selected Engine Modle  *                         
   * Input Parameters              : p_in_moduleSeqId crd_crc_module.module_seq_id%type   *
   * Input Parameters              : p_in_component_code crd_e_component.component_code%type*
   * Input Parameters              : p_RowNum VARCHAR2                                    *
   * Called Procedures/Functions   : None                                                 *
   * Calling Procedures/ Functions : from ECRD_UPLOAD_COMPONENT_PRC                       *
   ****************************************************************************************/
   FUNCTION ecrd_update_site(
                              p_in_modulenumber    IN VARCHAR2,
                              p_in_moduleSeqId     IN VARCHAR2,
                              p_in_component_code  IN crd_e_component.component_code%type,
                              p_in_locationId      IN crd_e_component_location.location_id%type,
                              P_in_primary_site    IN VARCHAR2,
                              p_in_hidden_site     IN VARCHAR2,
                              p_in_delete_site     IN VARCHAR2,
                              p_RowNum             IN VARCHAR2,
                              p_isAdmin            IN VARCHAR2,
                              p_in_userID          IN VARCHAR
                             )
   RETURN NUMBER IS
   
        v_min_site_seq        NUMBER := NULL;
        v_nonprim_primy_seq   NUMBER := NULL;
        v_primary_site        crd_e_component_location.location_id%type := NULL;
        v_nonprim_component   crd_e_component.component_code%type :=NULL;
        v_nonprim_locationId  crd_e_component_location.location_id%type := NULL;
        v_isPrimary_Site      BOOLEAN := FALSE;
        v_temp_site           VARCHAR2(50) := NULL;
        v_temp_newsite        BOOLEAN := FALSE;
        v_temp_newloc         NUMBER  := NULL;
        
        
   BEGIN
        
            -- If the user is an Admin do the changes into direct tables
            -- else in crd_e_comp_location_hist with staging_history_ind = 'H'
            IF( p_isAdmin IS NOT NULL AND UPPER(p_isAdmin)='Y' ) THEN 
                ----
                --This block will check for new site addition to component
                SELECT COUNT(*) 
                INTO v_temp_newloc 
                FROM  CRD_E_COMPONENT_LOCATION
                WHERE MODULE_SEQ_ID = p_in_moduleSeqId
                AND   UPPER(COMPONENT_CODE) = UPPER(p_in_component_code)
                AND   UPPER(LOCATION_ID) = UPPER(p_in_locationId) ;
        
                -- if no records exist for the incomming row in crd_e_component_location table 
                -- then its a new site for the corrsponding component code
                IF( v_temp_newloc = 0 ) THEN 
                    v_temp_newsite := TRUE;
                END IF;
 
                -- if the site is new then insert that row into crd_e_component_location
                IF (v_temp_newsite) THEN 
                    BEGIN
                         --Inserting new site informations into CRD_E_COMPONENT_LOCATION table
                         INSERT INTO CRD_E_COMPONENT_LOCATION(
                                     MODULE_SEQ_ID,
                                     COMPONENT_CODE,
                                     LOCATION_ID,
                                     ACTIVE_IND,
                                     SITE_SEQUENCE_NUMBER,
                                     HIDE_COMPONENT_IND,
                                     CREATED_BY,
                                     CREATION_DATE,
                                     LAST_UPDATE_DATE,
                                     LAST_UPDATED_BY
                                    )
                         VALUES(
                                     TO_NUMBER(p_in_moduleSeqId),
                                     UPPER(p_in_component_code),
                                     UPPER(p_in_locationId),
                                     'Y',
                                     ( SELECT SITE_SEQUENCE_NUMBER FROM (
                                       SELECT MAX(SITE_SEQUENCE_NUMBER) + 1 "SITE_SEQUENCE_NUMBER" 
                                       FROM   CRD_E_COMPONENT_LOCATION
                                       WHERE  ACTIVE_IND = 'Y'
                                       AND    MODULE_SEQ_ID = p_in_moduleSeqId
                                       AND    COMPONENT_CODE = p_in_component_code
                                       )),
                                       UPPER(p_in_hidden_site),
                                       p_in_userID,
                                       SYSDATE,
                                       SYSDATE,
                                       p_in_userID
                               );
                               -- if record inserts successfully then commit the transaction
                               COMMIT;
                    EXCEPTION
                        WHEN OTHERS THEN
                             ROLLBACK;
                             add_error('Error in adding new site '||p_in_locationId||' to component '||p_in_component_code||' ^');
                    END;
                END IF;
                -- End of new site addition to component
        
                -- if the site information is existing in crd_e_component_location table then
                -- need to be updated for the incomming data 
                
                
                --To collect minimum site sequnece number for the Prime Site              
                SELECT MIN(SITE_SEQUENCE_NUMBER) 
                INTO   v_min_site_seq
                FROM   CRD_E_COMPONENT_LOCATION
                WHERE  ACTIVE_IND = 'Y'
                AND    MODULE_SEQ_ID = p_in_moduleSeqId
                AND    UPPER(COMPONENT_CODE) = UPPER(p_in_component_code) ;

                
                -- To collect the existing Primary Site locationID
                SELECT LOCATION_ID
                INTO   v_primary_site
                FROM   CRD_E_COMPONENT_LOCATION
                WHERE  ACTIVE_IND = 'Y'
                AND    MODULE_SEQ_ID = p_in_moduleSeqId
                AND    UPPER(COMPONENT_CODE) = UPPER(p_in_component_code)
                AND    SITE_SEQUENCE_NUMBER = (SELECT MIN(SITE_SEQUENCE_NUMBER)
                                               FROM   CRD_E_COMPONENT_LOCATION
                                               WHERE  ACTIVE_IND='Y'
                                               AND    MODULE_SEQ_ID = p_in_moduleSeqId
                                               AND    UPPER(COMPONENT_CODE) = UPPER(p_in_component_code)
                                              );
                
                                                          
                IF( v_primary_site IS NOT NULL  AND v_primary_site = p_in_locationId ) THEN
                    v_isPrimary_Site := TRUE;
                ELSE
                    v_isPrimary_Site := FALSE;
                END IF;
                
                -- if incoming data  has PrimarySite = 'Y' then
                IF( p_in_primary_site IS NOT NULL AND UPPER(p_in_primary_site)='Y') THEN
                    -- If the site is an existing Primary site, indicates no changes to be done
                    IF( v_isPrimary_Site = FALSE ) THEN
                        
                        v_nonprim_component :=  p_in_component_code;
                        v_nonprim_locationId:=  p_in_locationId;
                        
                        SELECT SITE_SEQUENCE_NUMBER 
                        INTO   v_nonprim_primy_seq
                        FROM   CRD_E_COMPONENT_LOCATION
                        WHERE  ACTIVE_IND='Y'
                        AND    MODULE_SEQ_ID = p_in_moduleSeqId
                        AND    UPPER(COMPONENT_CODE) = UPPER(p_in_component_code)
                        AND    UPPER(LOCATION_ID) = UPPER(p_in_locationId);
                        
                        BEGIN
                            --To update the Site Sequence Number of Existing Primary Site
                            UPDATE CRD_E_COMPONENT_LOCATION
                            SET    SITE_SEQUENCE_NUMBER = v_nonprim_primy_seq,
                                   LAST_UPDATED_BY = p_in_userID,
                                   LAST_UPDATE_DATE = SYSDATE
                            WHERE  ACTIVE_IND='Y'                             
                            AND    MODULE_SEQ_ID = p_in_moduleSeqId
                            AND    UPPER(COMPONENT_CODE) = UPPER(p_in_component_code)
                            AND    UPPER(LOCATION_ID) = UPPER(v_primary_site);
                            
                            --To Update the new site as Primary Site
                            UPDATE CRD_E_COMPONENT_LOCATION
                            SET    SITE_SEQUENCE_NUMBER = v_min_site_seq,
                                   HIDE_COMPONENT_IND = UPPER(p_in_hidden_site),
                                   LAST_UPDATED_BY = p_in_userID,
                                   LAST_UPDATE_DATE = SYSDATE
                            WHERE  ACTIVE_IND = 'Y'                             
                            AND    MODULE_SEQ_ID = p_in_moduleSeqId
                            AND    UPPER(COMPONENT_CODE) = UPPER(p_in_component_code)
                            AND    UPPER(LOCATION_ID) = UPPER(p_in_locationId);
                            
                            -- If every thing goes well commit the transaction
                            COMMIT;
                           
                        EXCEPTION
                            WHEN OTHERS THEN
                                ROLLBACK;
                                add_error('Error in updating row num '||p_RowNum||' data for primary site '||p_in_primary_site||' ^');
                                RETURN 0;
                        END; -- End of Begin block for primary site updation
    
                    END IF;  -- isPrimarySite if block
                   
                END IF;  -- End of p_in_primary_site='Y' IF block
                
                --If the HiddenSite = 'Y' then updata accordingly in crd_e_component_location
                IF(p_in_hidden_site IS NOT NULL AND UPPER(p_in_hidden_site) = 'Y') THEN
                    BEGIN
                        --To update the Hide_component_ind for hiddensite in crd_e_component_location
                        UPDATE CRD_E_COMPONENT_LOCATION
                        SET    HIDE_COMPONENT_IND = 'Y',
                               LAST_UPDATE_DATE = SYSDATE,
                               LAST_UPDATED_BY = p_in_userID
                        WHERE  MODULE_SEQ_ID = p_in_moduleSeqId
                        AND    UPPER(COMPONENT_CODE) = UPPER(p_in_component_code)
                        AND    UPPER(LOCATION_ID) = UPPER(p_in_locationId);
                            
                        -- If every thing goes well commit the transaction
                        COMMIT;
                    EXCEPTION
                        WHEN OTHERS THEN
                             ROLLBACK;
                             add_error('Error in updating row num '||p_RowNum||' data for hidden site '||p_in_hidden_site||' ^');
                             RETURN 0;
                    END; -- End of Begin block for hidden site updation block
                        
                --if the Hidden_site_ind changed from 'Y' to 'N'
                ELSE 
                     IF ( p_in_hidden_site IS NOT NULL AND UPPER(p_in_hidden_site) = 'N' ) THEN
                     BEGIN
                            --To update the Hide_component_ind in crd_e_component_location
                            UPDATE CRD_E_COMPONENT_LOCATION
                            SET    HIDE_COMPONENT_IND = 'N',
                                   LAST_UPDATE_DATE = SYSDATE,
                                   LAST_UPDATED_BY = p_in_userID
                            WHERE  MODULE_SEQ_ID = p_in_moduleSeqId
                            AND    UPPER(COMPONENT_CODE) = UPPER(p_in_component_code)
                            AND    UPPER(LOCATION_ID) = UPPER(p_in_locationId);
                            
                            -- If every thing goes well commit the transaction
                            COMMIT;
                     EXCEPTION
                            WHEN OTHERS THEN
                                 ROLLBACK;
                                 add_error('Error in updating row num '||p_RowNum||' data for hidden site '||p_in_hidden_site||' ^');
                                 RETURN 0;
                     END;    -- End of Begin block for hidden_site_ind = 'N'
                     END IF; -- End of hidden_site = 'N'

                END IF; -- End of HiddenSite ='Y' block
                
                -- if DeleteSite= 'Y' then update the Active_ind = 'N' in crd_e_component_location table
                IF( p_in_delete_site IS NOT NULL AND UPPER(p_in_delete_site) = 'Y' ) THEN
                    
                    BEGIN
                         --To update the Site Sequence Number of Existing Primary Site
                         UPDATE CRD_E_COMPONENT_LOCATION
                         SET    ACTIVE_IND = 'N',
                                LAST_UPDATE_DATE = SYSDATE,
                                LAST_UPDATED_BY = p_in_userID
                         WHERE  ACTIVE_IND = 'Y'
                         AND    MODULE_SEQ_ID = p_in_moduleSeqId
                         AND    UPPER(COMPONENT_CODE) = UPPER(p_in_component_code)
                         AND    UPPER(LOCATION_ID) = UPPER(p_in_locationId) ;
                            
                         -- If every thing goes well commit the transaction
                         COMMIT;
                    EXCEPTION
                         WHEN OTHERS THEN
                              ROLLBACK;
                              add_error('Error in updating row num '||p_RowNum||' data for delete site '||p_in_delete_site||' ^');
                              RETURN 0;
                    END; -- End of Begin block
                
                -- if the site is inactive and now wants to be an active one then make the 
                -- ACTIVE_IND = 'Y' in crd_e_component_loction table   
                ELSE 
                     IF( p_in_delete_site IS NOT NULL AND UPPER(p_in_delete_site) = 'N' ) THEN
                         BEGIN
                              --To update the Site Sequence Number of Existing Primary Site
                              UPDATE CRD_E_COMPONENT_LOCATION
                              SET    ACTIVE_IND = 'Y',
                                     LAST_UPDATE_DATE = SYSDATE,
                                     LAST_UPDATED_BY = p_in_userID
                              WHERE  MODULE_SEQ_ID = p_in_moduleSeqId
                              AND    UPPER(COMPONENT_CODE) = UPPER(p_in_component_code)
                              AND    UPPER(LOCATION_ID) = UPPER(p_in_locationId);
                                    
                              -- If every thing goes well commit the transaction
                              COMMIT;
                         EXCEPTION
                              WHEN OTHERS THEN
                                   ROLLBACK;
                                   add_error('Error in updating row num '||p_RowNum||' data for delete site '||p_in_delete_site||' ^');
                              RETURN 0;
                         END;    -- End of Begin block 
                     END IF; -- End of p_in_delete_site = 'N'
                END IF; -- End of hidden_site ='Y' 
                
            ----
            ---- If the user is other than admin then update in crd_e_comp_location_hist table
            ELSE  

                ----
                --This block will check for new site addition to component by non admin guys
                -- so will deal with corresponding history table
                SELECT COUNT(*) 
                INTO v_temp_newloc 
                FROM  CRD_E_COMP_LOCATION_HIST
                WHERE MODULE_SEQ_ID = p_in_moduleSeqId
                AND   UPPER(COMPONENT_CODE) = UPPER(p_in_component_code)
                AND   UPPER(LOCATION_ID) = UPPER(p_in_locationId) ;
        
                -- if no records exist for the incomming row in crd_e_component_location table 
                -- then its a new site for the corrsponding component code
                IF( v_temp_newloc = 0 ) THEN 
                    v_temp_newsite := TRUE;
                END IF;
 
                -- if the site is new then insert that row into crd_e_component_location
                IF (v_temp_newsite) THEN 
                    BEGIN
                         --Inserting new site informations into CRD_E_COMPONENT_LOCATION table
                         INSERT INTO CRD_E_COMP_LOCATION_HIST(
                                     MODULE_SEQ_ID,
                                     COMPONENT_CODE,
                                     STAGING_HISTORY_IND,
                                     LOCATION_ID,
                                     ACTIVE_IND,
                                     SITE_SEQUENCE_NUMBER,
                                     HIDE_COMPONENT_IND,
                                     CREATED_BY,
                                     CREATION_DATE,
                                     LAST_UPDATE_DATE,
                                     LAST_UPDATED_BY
                                    )
                         VALUES(
                                     TO_NUMBER(p_in_moduleSeqId),
                                     UPPER(p_in_component_code),
                                     'S',
                                     UPPER(p_in_locationId),
                                     'Y',
                                     ( SELECT SITE_SEQUENCE_NUMBER FROM (
                                       SELECT MAX(SITE_SEQUENCE_NUMBER) + 1 "SITE_SEQUENCE_NUMBER" 
                                       FROM   CRD_E_COMP_LOCATION_HIST
                                       WHERE  ACTIVE_IND = 'Y'
                                       AND    MODULE_SEQ_ID = p_in_moduleSeqId
                                       AND    COMPONENT_CODE = p_in_component_code
                                       )),
                                       UPPER(p_in_hidden_site),
                                       p_in_userID,
                                       SYSDATE,
                                       SYSDATE,
                                       p_in_userID
                               );
                               -- if record inserts successfully then commit the transaction
                               COMMIT;
                    EXCEPTION
                        WHEN OTHERS THEN
                             ROLLBACK;
                             add_error('Error in adding new site '||p_in_locationId||' to component '||p_in_component_code||' ^');
                    END;
                END IF;
                -- End of new site addition to component
        
                -- if the site information is existing in crd_e_component_location table then
                -- need to be updated for the incomming data 
                
                
                --To collect minimum site sequnece number for the Prime Site              
                SELECT MIN(SITE_SEQUENCE_NUMBER) 
                INTO   v_min_site_seq
                FROM   CRD_E_COMP_LOCATION_HIST
                WHERE  ACTIVE_IND = 'Y'
                AND    MODULE_SEQ_ID = p_in_moduleSeqId
                AND    UPPER(COMPONENT_CODE) = UPPER(p_in_component_code) ;

                
                -- To collect the existing Primary Site locationID
                SELECT LOCATION_ID
                INTO   v_primary_site
                FROM   CRD_E_COMP_LOCATION_HIST
                WHERE  ACTIVE_IND = 'Y'
                AND    MODULE_SEQ_ID = p_in_moduleSeqId
                AND    UPPER(COMPONENT_CODE) = UPPER(p_in_component_code)
                AND    SITE_SEQUENCE_NUMBER = (SELECT MIN(SITE_SEQUENCE_NUMBER)
                                               FROM   CRD_E_COMP_LOCATION_HIST
                                               WHERE  ACTIVE_IND='Y'
                                               AND    MODULE_SEQ_ID = p_in_moduleSeqId
                                               AND    UPPER(COMPONENT_CODE) = UPPER(p_in_component_code)
                                              );
                
                                                          
                IF( v_primary_site IS NOT NULL  AND v_primary_site = p_in_locationId ) THEN
                    v_isPrimary_Site := TRUE;
                ELSE
                    v_isPrimary_Site := FALSE;
                END IF;
                
                -- if incoming data  has PrimarySite = 'Y' then
                IF( p_in_primary_site IS NOT NULL AND UPPER(p_in_primary_site)='Y') THEN
                    -- If the site is an existing Primary site, indicates no changes to be done
                    IF( v_isPrimary_Site = FALSE ) THEN
                        
                        v_nonprim_component :=  p_in_component_code;
                        v_nonprim_locationId:=  p_in_locationId;
                        
                        SELECT SITE_SEQUENCE_NUMBER 
                        INTO   v_nonprim_primy_seq
                        FROM   CRD_E_COMP_LOCATION_HIST
                        WHERE  ACTIVE_IND='Y'
                        AND    MODULE_SEQ_ID = p_in_moduleSeqId
                        AND    UPPER(COMPONENT_CODE) = UPPER(p_in_component_code)
                        AND    UPPER(LOCATION_ID) = UPPER(p_in_locationId);
                        
                        BEGIN
                            --To update the Site Sequence Number of Existing Primary Site
                            UPDATE CRD_E_COMP_LOCATION_HIST
                            SET    SITE_SEQUENCE_NUMBER = v_nonprim_primy_seq,
                                   STAGING_HISTORY_IND = 'S',
                                   LAST_UPDATED_BY = p_in_userID,
                                   LAST_UPDATE_DATE = SYSDATE
                            WHERE  ACTIVE_IND='Y'                             
                            AND    MODULE_SEQ_ID = p_in_moduleSeqId
                            AND    UPPER(COMPONENT_CODE) = UPPER(p_in_component_code)
                            AND    UPPER(LOCATION_ID) = UPPER(v_primary_site);
                            
                            --To Update the new site as Primary Site
                            UPDATE CRD_E_COMP_LOCATION_HIST
                            SET    SITE_SEQUENCE_NUMBER = v_min_site_seq,
                                   STAGING_HISTORY_IND = 'S',
                                   HIDE_COMPONENT_IND = UPPER(p_in_hidden_site),
                                   LAST_UPDATED_BY = p_in_userID,
                                   LAST_UPDATE_DATE = SYSDATE
                            WHERE  ACTIVE_IND = 'Y'                             
                            AND    MODULE_SEQ_ID = p_in_moduleSeqId
                            AND    UPPER(COMPONENT_CODE) = UPPER(p_in_component_code)
                            AND    UPPER(LOCATION_ID) = UPPER(p_in_locationId);
                            
                            -- If every thing goes well commit the transaction
                            COMMIT;
                           
                        EXCEPTION
                            WHEN OTHERS THEN
                                ROLLBACK;
                                add_error('Error in updating row num '||p_RowNum||' data for primary site '||p_in_primary_site||' ^');
                                RETURN 0;
                        END; -- End of Begin block for primary site updation
    
                    END IF;  -- isPrimarySite if block
                   
                END IF;  -- End of p_in_primary_site='Y' IF block
                
                --If the HiddenSite = 'Y' then updata accordingly in crd_e_component_location
                IF(p_in_hidden_site IS NOT NULL AND UPPER(p_in_hidden_site) = 'Y') THEN
                    BEGIN
                        --To update the Hide_component_ind for hiddensite in crd_e_component_location
                        UPDATE CRD_E_COMP_LOCATION_HIST
                        SET    STAGING_HISTORY_IND = 'S',
                               HIDE_COMPONENT_IND = 'Y',
                               LAST_UPDATE_DATE = SYSDATE,
                               LAST_UPDATED_BY = p_in_userID
                        WHERE  MODULE_SEQ_ID = p_in_moduleSeqId
                        AND    UPPER(COMPONENT_CODE) = UPPER(p_in_component_code)
                        AND    UPPER(LOCATION_ID) = UPPER(p_in_locationId);
                            
                        -- If every thing goes well commit the transaction
                        COMMIT;
                    EXCEPTION
                        WHEN OTHERS THEN
                             ROLLBACK;
                             add_error('Error in updating row num '||p_RowNum||' data for hidden site '||p_in_hidden_site||' ^');
                             RETURN 0;
                    END; -- End of Begin block for hidden site updation block
                        
                --if the Hidden_site_ind changed from 'Y' to 'N'
                ELSE 
                     IF ( p_in_hidden_site IS NOT NULL AND UPPER(p_in_hidden_site) = 'N' ) THEN
                     BEGIN
                            --To update the Hide_component_ind in crd_e_component_location
                            UPDATE CRD_E_COMP_LOCATION_HIST
                            SET    STAGING_HISTORY_IND = 'S',
                                   HIDE_COMPONENT_IND = 'N',
                                   LAST_UPDATE_DATE = SYSDATE,
                                   LAST_UPDATED_BY = p_in_userID
                            WHERE  MODULE_SEQ_ID = p_in_moduleSeqId
                            AND    UPPER(COMPONENT_CODE) = UPPER(p_in_component_code)
                            AND    UPPER(LOCATION_ID) = UPPER(p_in_locationId);
                            
                            -- If every thing goes well commit the transaction
                            COMMIT;
                     EXCEPTION
                            WHEN OTHERS THEN
                                 ROLLBACK;
                                 add_error('Error in updating row num '||p_RowNum||' data for hidden site '||p_in_hidden_site||' ^');
                                 RETURN 0;
                     END;    -- End of Begin block for hidden_site_ind = 'N'
                     END IF; -- End of hidden_site = 'N'

                END IF; -- End of HiddenSite ='Y' block
                
                -- if DeleteSite= 'Y' then update the Active_ind = 'N' in crd_e_component_location table
                IF( p_in_delete_site IS NOT NULL AND UPPER(p_in_delete_site) = 'Y' ) THEN
                    
                    BEGIN
                         --To update the Site Sequence Number of Existing Primary Site
                         UPDATE CRD_E_COMP_LOCATION_HIST
                         SET    STAGING_HISTORY_IND = 'S',
                                ACTIVE_IND = 'N',
                                LAST_UPDATE_DATE = SYSDATE,
                                LAST_UPDATED_BY = p_in_userID
                         WHERE  ACTIVE_IND = 'Y'
                         AND    MODULE_SEQ_ID = p_in_moduleSeqId
                         AND    UPPER(COMPONENT_CODE) = UPPER(p_in_component_code)
                         AND    UPPER(LOCATION_ID) = UPPER(p_in_locationId) ;
                            
                         -- If every thing goes well commit the transaction
                         COMMIT;
                    EXCEPTION
                         WHEN OTHERS THEN
                              ROLLBACK;
                              add_error('Error in updating row num '||p_RowNum||' data for delete site '||p_in_delete_site||' ^');
                              RETURN 0;
                    END; -- End of Begin block
                
                -- if the site is inactive and now wants to be an active one then make the 
                -- ACTIVE_IND = 'Y' in crd_e_component_loction table   
                ELSE 
                     IF( p_in_delete_site IS NOT NULL AND UPPER(p_in_delete_site) = 'N' ) THEN
                         BEGIN
                              --To update the Site Sequence Number of Existing Primary Site
                              UPDATE CRD_E_COMP_LOCATION_HIST
                              SET    STAGING_HISTORY_IND = 'S',
                                     ACTIVE_IND = 'Y',
                                     LAST_UPDATE_DATE = SYSDATE,
                                     LAST_UPDATED_BY = p_in_userID
                              WHERE  MODULE_SEQ_ID = p_in_moduleSeqId
                              AND    UPPER(COMPONENT_CODE) = UPPER(p_in_component_code)
                              AND    UPPER(LOCATION_ID) = UPPER(p_in_locationId);
                                    
                              -- If every thing goes well commit the transaction
                              COMMIT;
                         EXCEPTION
                              WHEN OTHERS THEN
                                   ROLLBACK;
                                   add_error('Error in updating row num '||p_RowNum||' data for delete site '||p_in_delete_site||' ^');
                              RETURN 0;
                         END;    -- End of Begin block 
                     END IF; -- End of p_in_delete_site = 'N'
                END IF; -- End of hidden_site ='Y'             
                                
            END IF; -- End of Admin and non admin user updation block
        
        RETURN 1;
   END ecrd_update_site;

   
   
   /*
   The Main Processing block for UploadComponent Procedure
   */
   BEGIN
      
      --validating sheetname with engine model       
      temp_sheetname := ECRD_VALIDATE_SHEET( as_engine_code );
      
      -- if sheetname is not matcing with engine model come out of procedure 
      -- report the error msg in out parameter
      IF ( UPPER(temp_sheetname) != UPPER(as_sheet_name) ) THEN
         add_error('sheetname '|| as_sheet_name || ' and engine model '|| temp_sheetname || ' mismatch, please select appropriate engine model ^');
      
         -- moving outof procedure ECRD_UPLOAD_COMPONENT_PRC
         GOTO OUTOFPROC;
      END IF;
      
      --declares an empty VARRAY
	    in_data := input_array('');
      --populates the VARRAY with the incomming Long Data
	    populate_in_data();
      
      --Loops through the VARRAY to do the splitting of the data
	    FOR i IN 1..10 LOOP
          --checks if elements of VARRAY is not null then proceeds
	        IF in_data(i) IS NOT NULL THEN
		         ls_rem_data := in_data(i);
		         lb_not_eof  := TRUE;
          END IF;
		      WHILE lb_not_eof LOOP
			          ls_row_comp := return_string(ls_rem_data,'|','BEF');
    	          ls_rem_data := return_string(ls_rem_data,'|','AFT');

			          IF ls_rem_data IS NULL THEN
				           lb_not_eof := FALSE ;
			          END IF;

          			ls_row_no     := return_string(ls_row_comp,'^','BEF');
          			ls_row_comp   := return_string(ls_row_comp,'^','AFT');
                
                /* Extracting data for a single row and processed further*/
                ls_module_seq := return_string(ls_row_comp,'^','BEF');
			          ls_row_comp   := return_string(ls_row_comp,'^','AFT');

			          ls_module_desc:= return_string(ls_row_comp,'^','BEF');
			          ls_row_comp   := return_string(ls_row_comp,'^','AFT');
                
                --beging validating engine_module_sequence_id and module_desc
                temp_module_seq_id := ecrd_validate_module(as_engine_code,
                                                           ls_module_seq,
                                                           ls_module_desc,
                                                           ls_row_no
                                                          );
                --end validating engine_module_sequence_id  and module_desc
			          ls_comp_code  := return_string(ls_row_comp,'^','BEF');
			          ls_row_comp   := return_string(ls_row_comp,'^','AFT');

			          ls_comp_desc  := return_string(ls_row_comp,'^','BEF');
			          ls_row_comp   := return_string(ls_row_comp,'^','AFT');
                
                -- Validating the component based on the given Module Seq Id 
			          temp_component := ecrd_validate_component( ls_module_seq,
                                                           ls_comp_code,
                                                           ls_comp_desc,
                                                           ls_row_no
                                                         );
                -- Validating the component based on the given Module Seq Id - End 

                ls_location_id:= return_string(ls_row_comp,'^','BEF');
			          ls_row_comp   := return_string(ls_row_comp,'^','AFT');

			          ls_location_desc := return_string(ls_row_comp,'^','BEF');
			          ls_row_comp   := return_string(ls_row_comp,'^','AFT');
                
                -- Validating Location for the Engine Module Begin
			          temp_location :=ecrd_validate_location( ls_module_seq,
                                                        ls_comp_code,
                                                        ls_location_id,
                                                        ls_location_desc,
                                                        ls_row_no
                                                      );
                -- Validating Location for the Engine Module End 
                
                ls_primary_site:= return_string(ls_row_comp,'^','BEF');
			          ls_row_comp    := return_string(ls_row_comp,'^','AFT');

			          ls_hidden_site := return_string(ls_row_comp,'^','BEF');
			          ls_row_comp    := return_string(ls_row_comp,'^','AFT');
                
                ls_delete_site := return_string(ls_row_comp,'^','BEF');
			          ls_row_comp    := return_string(ls_row_comp,'^','AFT');               
                
                IF ( temp_module_seq_id = ls_module_seq 
                     AND temp_component = 1
                     AND temp_location = 1 
                    )
                THEN
                    temp_update := ecrd_update_site(
                                                    as_engine_code,
                                                    ls_module_seq,
                                                    ls_comp_code,
                                                    ls_location_id,
                                                    ls_primary_site,
                                                    ls_hidden_site,
                                                    ls_delete_site,
                                                    ls_row_no,
                                                    as_is_admin,
                                                    as_user_id
                                                   );
                
                 END IF;
          END LOOP;
      END LOOP;
      
      -- OUTOFPROC block starts from here
      <<OUTOFPROC>>
      BEGIN
           SELECT SYSDATE INTO temp_dual FROM DUAL;
      END;
      -- End of OUTOFPROC 

   END ECRD_UPLOAD_COMPONENT_PRC;
   -- End of procedure ECRD_UPLOAD_COMPONENT_PRC; 
 
  
END ECRD_UPLOAD_COMPONENT_PKG;
/
