/***********************************************************************/
-- Copyright Message 	   : Copyright(c) 2004 GE Aircraft Engines
-- Title                   : Create_Default_Catalog_pls.pls
-- Author                  : Patni Offshore
-- Company           	   : GE Aircraft Engines
-- Date                    : November 2004
-- Purpose             	   : PLS Block file for Package Spec and body for Procs
--                           for Catalog Creation
--
-- Modifications      	   : Description
-- [DD-MMM-YYYY]             Creation of the new catalog when the old catalog's 
--			     			 end date is today's date	
-- 01-Nov-2004         	     New Code First Version
--
/***********************************************************************/


DECLARE -- start processing block
    
    -- Declaration of variables
    s_user_name VARCHAR2(10)  := 'MSORBATCH';
    v_updcount	number := 0;
    s_eng_mdl_number CRD_E_CATALOG.ENG_MDL_NUMBER%TYPE;
    s_catalog_number CRD_E_CATALOG.CATALOG_NUMBER%TYPE;
    s_catalog_description CRD_E_CATALOG.CATALOG_DESCRIPTION%TYPE;
    dt_catalog_effective_date CRD_E_CATALOG.CATALOG_EFFECTIVE_DATE%TYPE;
    dt_catalog_end_date CRD_E_CATALOG.CATALOG_END_DATE%TYPE;
    s_catalog_type CRD_E_CATALOG.CATALOG_TYPE%TYPE;
    s_parent_catalog_seq_id CRD_E_CATALOG.PARENT_CATALOG_SEQ_ID%TYPE;
    s_active_ind CRD_E_CATALOG.ACTIVE_IND%TYPE;
    n_catalog_seq_id NUMBER;
    n_old_catalog_seq_id CRD_E_CATALOG.CATALOG_SEQ_ID%TYPE;
        
    -- Cursor for fetching the catalog's end date is today's date - 1
    CURSOR cur_catalog_link        
    IS      
    SELECT CATALOG_SEQ_ID,ENG_MDL_NUMBER,CATALOG_NUMBER, 
    CATALOG_DESCRIPTION,CATALOG_EFFECTIVE_DATE,CATALOG_END_DATE,  
    CATALOG_TYPE,PARENT_CATALOG_SEQ_ID, 
    ACTIVE_IND 
    FROM CRD_E_CATALOG 
    WHERE CATALOG_TYPE = 'D' 
    AND (TRUNC(CATALOG_END_DATE)  = TRUNC(SYSDATE-1)
    OR CATALOG_END_DATE IS NULL); 
    
   	

BEGIN -- start block 1
	
	FOR counter IN cur_catalog_link 
	LOOP 
		
		s_eng_mdl_number := counter.ENG_MDL_NUMBER;
		n_old_catalog_seq_id := counter.CATALOG_SEQ_ID;
		s_catalog_number := counter.CATALOG_NUMBER;
		s_catalog_description := counter.CATALOG_DESCRIPTION;
		dt_catalog_effective_date := sysdate;
		dt_catalog_end_date := add_months((sysdate),12);
		s_parent_catalog_seq_id := counter.PARENT_CATALOG_SEQ_ID;
		
		SELECT CRD_E_CATALOG_seq.NEXTVAL into 
		n_catalog_seq_id from dual;
				
		
		-- This query inserts a new catalog into the tables
		-- where end date is today's date
		
		INSERT INTO 
		CRD_E_CATALOG 
		(CATALOG_SEQ_ID, 
		ENG_MDL_NUMBER, 
		CATALOG_NUMBER, 
		CATALOG_DESCRIPTION, 
		CATALOG_EFFECTIVE_DATE, 
		CATALOG_END_DATE, 
		CATALOG_TYPE, 
		PARENT_CATALOG_SEQ_ID, 
		ACTIVE_IND, 
		CREATION_DATE, 
		CREATED_BY, 
		LAST_UPDATE_DATE, 
		LAST_UPDATED_BY 
		)
		VALUES 
		(
		n_catalog_seq_id,
		s_eng_mdl_number,
		s_catalog_number,
		s_catalog_description,
		dt_catalog_effective_date,
		dt_catalog_end_date,
		'D',
		s_parent_catalog_seq_id,
		'Y',
		sysdate,
		s_user_name,
		sysdate,
		s_user_name
		);
		
		-- This query inserts repairs into the catalog into the tables 
		-- where end date is today's date 
	
			INSERT INTO 
			CRD_E_REPAIR_CATALOG  
			(SELECT 
			REPAIR_SEQ_ID,
			n_catalog_seq_id,
			dt_catalog_effective_date,
			REPAIR_PRICE,
			INCREMENTAL_PRICE_IND,
			REPAIR_TAT,
			INCREMENTAL_TAT_IND,
			FUTURE_PRICE,
			FUTURE_EFFECTIVE_DATE,
			PRICE_TYPE,
			REPAIR_END_DATE,
			REPAIR_DISPLAY_SEQ_ID,
			FUTURE_TAT,
			PRICE_OVERWRITE_FLAG_IND,
			s_user_name,
			SYSDATE,
			SYSDATE,
			s_user_name 
			FROM CRD_E_REPAIR_CATALOG 
			where 
			catalog_seq_id = n_old_catalog_seq_id);
			
			-- After insertion of new catalogs 
			-- the future tat, future effective date and future price of 
			-- old catalog is made null.
			
			UPDATE CRD_E_REPAIR_CATALOG 
			SET FUTURE_PRICE = NULL, 
			FUTURE_TAT = NULL, 
			FUTURE_EFFECTIVE_DATE = NULL, 
			LAST_UPDATE_DATE = sysdate, 
			LAST_UPDATED_BY = s_user_name 
			where  CATALOG_SEQ_ID = n_old_catalog_seq_id;
				
				
		COMMIT;
		
	END LOOP;
		
	IF v_updcount>0 THEN 
		dbms_output.put_line('                                                 ');
		dbms_output.put_line('Number of Repair record(s) updated on '||to_Char(sysdate,'DD-MON-YYYY HH24:MI:SS AM'));
		dbms_output.put_line('Number of Repair record(s) updated: '||v_updcount);
	ELSE 
		dbms_output.put_line('                                                 ');
		dbms_output.put_line('No records to update');
	END IF; 
	
	EXCEPTION 
	WHEN OTHERS THEN 
	ROLLBACK;
	RAISE_APPLICATION_ERROR(-20601, SQLCODE || '-' || SQLERRM);

END;        

/
