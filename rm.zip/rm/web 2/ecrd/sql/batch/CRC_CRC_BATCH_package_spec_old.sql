
-- Start of DDL script for CRD_CRC_BATCH
-- Generated 30-Jan-04  12:01:27 pm
-- from evnodsd2-CRD:1

-- Package CRD_CRC_BATCH

CREATE OR REPLACE
PACKAGE CRD_CRC_BATCH IS
/*****************************************************************************
  Application Name     : Component Repair Detail (CRD)
  Subsystem            : Batch jobs
  Package Name         : CRD_CRC_BATCH
  Purpose              : Contains procedures for processing Bath jobs.
  Author               : TCS
  Date (DD-MON-YYYY)   : November-2002
  Revision History     :
  Version  Date         Author           Description
  -------  -----------  ---------------  -------------------------------------
  1.0.0    11-Nov-2002  PCS      		 First version.
  1.0.1    15-Jan-2003  PCS              Modified to remove to_char conversion of
                                         RPR_REF_SNUM and CHLD_REF_SNUM before doing the
                                         the substring as it was creating problem in
                                         production environment.
******************************************************************************/
pragma SERIALLY_REUSABLE;
TYPE result_cursor IS REF CURSOR;
PROCEDURE CRC_FUT_PRICE_CHANGE_PRC
	(errcode out varchar2,
	retcode out number);
PROCEDURE CRD_CRC_UPDATE_END_DATE
	(errcode out varchar2,
	retcode out number);
PROCEDURE CRD_CRC_UPDATE_START_DATE
	(locid in varchar2,
	errcode out varchar2,
	retcode out number);
PROCEDURE CRD_CRC_DEL_TEMP_RECORD
	(errcode out varchar2,
	retcode out number);
PROCEDURE CRD_CRC_INSERT_TEMP_TABLE_PRC
	(startdate in VARCHAR2,
	enddate in VARCHAR2,
	loc_id in varchar2,
--	catsts_ind in varchar2,
	errcode out varchar2,
	retcode out number);
PROCEDURE CRD_CRC_INSERT_RECORD
	(errcode out varchar2,
	retcode out number);
PROCEDURE CRD_CRC_EXTRACT_PART_NUMBER
	(errcode out varchar2,
	retcode out number);
end CRD_CRC_BATCH;
/

