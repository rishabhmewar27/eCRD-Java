
CREATE OR REPLACE
PACKAGE CRD_CRC_BATCH IS
/*****************************************************************************
  Application Name     : Component Repair Detail (CRD)
  Subsystem            : Batch jobs
  Package Name         : CRD_CRC_BATCH
  Purpose              : Contains procedures for processing Bath jobs.
  Author               : TCS
  Date (DD-MON-YYYY)   : November-2002
  Revision History     :
  Version  Date         Author           Description
  -------  -----------  ---------------  -------------------------------------
  1.0.0    11-Nov-2002  PCS      		 First version.
  1.0.1    15-Jan-2003  PCS              Modified to remove to_char conversion of
                                         RPR_REF_SNUM and CHLD_REF_SNUM before doing the
                                         the substring as it was creating problem in
                                         production environment.
******************************************************************************/
pragma SERIALLY_REUSABLE;
TYPE result_cursor IS REF CURSOR;
PROCEDURE CRC_FUT_PRICE_CHANGE_PRC
	(errcode out varchar2,
	retcode out number);
PROCEDURE CRD_CRC_UPDATE_END_DATE
	(errcode out varchar2,
	retcode out number);
PROCEDURE CRD_CRC_UPDATE_START_DATE
	(locid in varchar2,
	errcode out varchar2,
	retcode out number);
PROCEDURE CRD_CRC_DEL_TEMP_RECORD
	(errcode out varchar2,
	retcode out number);
PROCEDURE CRD_CRC_INSERT_TEMP_TABLE_PRC
	(startdate in VARCHAR2,
	enddate in VARCHAR2,
	loc_id in varchar2,
--	catsts_ind in varchar2,
	errcode out varchar2,
	retcode out number);
PROCEDURE CRD_CRC_INSERT_RECORD
	(errcode out varchar2,
	retcode out number);
PROCEDURE CRD_CRC_EXTRACT_PART_NUMBER
	(errcode out varchar2,
	retcode out number);
end CRD_CRC_BATCH;
/


-- Package body CRD_CRC_BATCH

CREATE OR REPLACE
PACKAGE BODY CRD_CRC_BATCH AS
pragma SERIALLY_REUSABLE;
PROCEDURE CRC_FUT_PRICE_CHANGE_PRC
	(errcode out varchar2,
	retcode out number)
is
 v_errcode	   varchar2(1000);
 v_updcount	   number:=0;
  cursor futcur is
  select REPAIR_SEQ_ID,FUTURE_EFFECTIVE_DATE,FUTURE_PRICE
  from crd_e_repair_catalog
  where	  FUTURE_EFFECTIVE_DATE <= sysdate;
begin
	for  futcur_rec in futcur
	loop
		begin
			update crd_e_Repair_catalog
			set
			REPAIR_PRICE = futcur_rec.FUTURE_PRICE,
			FUTURE_EFFECTIVE_DATE='',
	    	        FUTURE_PRICE='',
			LAST_UPDATE_DATE=sysdate,
			EFFECTIVE_DATE = sysdate
			where
			repair_seq_id = futcur_rec.REPAIR_SEQ_ID;
		if sql%notfound then
		   v_errcode:=sqlerrm;
		end if;
		end;
    		v_updcount:=v_updcount+1;
			/* After successful completion*/
	 end loop;
	    commit;
    		if v_errcode<>' ' then
				retcode:=1;
				errcode:=v_errcode;
        		dbms_output.put_line('Number of Repair record(s) updated on '||to_Char(sysdate,'DD-MON-YYYY HH24:MI:SS AM'));
 	        	dbms_output.put_line('Number of Repair record(s) updated :'||v_updcount);
		else
			retcode:=0;
 			if v_updcount>0 then
			dbms_output.put_line('                                                 ');
			dbms_output.put_line('Number of Repair record(s) updated on '||to_Char(sysdate,'DD-MON-YYYY HH24:MI:SS AM'));
			dbms_output.put_line('Number of Repair record(s) updated: '||v_updcount);
			else
			dbms_output.put_line('                                                 ');
			dbms_output.put_line('No records to update');
			end if;
		end if;
end CRC_FUT_PRICE_CHANGE_PRC;
PROCEDURE CRD_CRC_UPDATE_END_DATE
	(errcode out varchar2,
	retcode out number)
AS
 	v_errcode	 varchar2(1000);
 	v_jobind 	 varchar2(1);
 	locid	   varchar2(20);
 	cursor selcur is
		select LOCATION_ID,JOB_INDICATOR
		from
			CRD_E_OSB_JOBS   ;
begin
		OPEN selcur;
		LOOP
		FETCH selcur INTO locid,v_jobind;
		EXIT WHEN selcur%NOTFOUND;
		if(v_jobind = 'A') then
		update 	CRD_E_OSB_JOBS   
		set     JOB_END_DATE = sysdate
			where LOCATION_ID = locid;
		end if;
		END LOOP;
	CLOSE selcur;
commit;
		if sql%notfound then
		   v_errcode:=sqlerrm;
		end if;
    		if v_errcode<>' ' then
				retcode:=1;
				errcode:=v_errcode;
		else
			retcode:=0;
		end if;
end CRD_CRC_UPDATE_END_DATE;
PROCEDURE CRD_CRC_UPDATE_START_DATE
	(locid in varchar2,
	errcode out varchar2,
	retcode out number)
AS
 	v_errcode	 varchar2(1000);
 	v_jobind 		 varchar2(1);
begin
select JOB_INDICATOR into v_jobind from CRD_E_OSB_JOBS   
WHERE LOCATION_ID = locid;
if(v_jobind = 'A') then
update 	CRD_E_OSB_JOBS   
set     JOB_START_DATE = sysdate
	where LOCATION_ID = locid;
end if;
commit;
		if sql%notfound then
		   v_errcode:=sqlerrm;
		end if;
    		if v_errcode<>' ' then
				retcode:=1;
				errcode:=v_errcode;
		else
			retcode:=0;
		end if;
end CRD_CRC_UPDATE_START_DATE;
PROCEDURE CRD_CRC_DEL_TEMP_RECORD
	(errcode out varchar2,
	retcode out number)
AS
 	v_errcode	   	varchar2(1000);
 	v_updcount	   	number:=0;
begin
	delete from CRD_E_OSB_REPAIR_STG;
		commit;
    		if v_errcode<>' ' then
				retcode:=1;
				errcode:=v_errcode;
		else
			retcode:=0;
		end if;
end CRD_CRC_DEL_TEMP_RECORD;
PROCEDURE CRD_CRC_INSERT_RECORD
	(errcode out varchar2,
	retcode out number)
AS
	v_errcode	varchar2(1000);
	p_startdate      varchar2(10);
	p_enddate      varchar2(10);
	p_loc_id	   varchar2(20);
	p_retcode    number;
 cursor selcur is
	select LOCATION_ID,
	       to_char(JOB_START_DATE,'dd-mon-yy'),
	       to_char(JOB_END_DATE,'dd-mon-yy')
	from
		CRD_E_OSB_JOBS   ;
begin
	OPEN selcur;
	LOOP
	FETCH selcur INTO p_loc_id,p_startdate,p_enddate;
	EXIT WHEN selcur%NOTFOUND;
 CRD_CRC_INSERT_TEMP_TABLE_PRC
	(p_startdate,
	p_enddate,
	p_loc_id,
--	catsts_ind, 
	v_errcode,
	p_retcode);
	END LOOP;
	CLOSE selcur;
		if sql%notfound then
		   v_errcode:=sqlerrm;
		end if;
    		if v_errcode<>' ' then
			retcode:=1;
			errcode:=v_errcode;
		else
			retcode:=0;
		end if;
end CRD_CRC_INSERT_RECORD;
PROCEDURE CRD_CRC_INSERT_TEMP_TABLE_PRC
/***************************************************************************

Project Name :- Electronic Catalogue Repair Directory (eCRD)
Module Name  :- eCRD-OSB Batch Interface
Name of code :- CRD_BATCH
Created by   :- Patni
Creation Date:-
Decription   :- This interface runs on a daily basis which selects all records
		from the eCRD system and loads them into a Staging table.

Revision History

Revision no    Revision Date   Revised by      Reason for change

****************************************************************************/
	(startdate  IN VARCHAR2,
  	 enddate    IN VARCHAR2,
	 loc_id     IN VARCHAR2,
	-- catsts_ind IN VARCHAR2
	errcode out varchar2,
	retcode out number
	)
AS

        /*Variable Declaration*/
	v_updcount		NUMBER:=0;
	p_startdate     	VARCHAR2(12);
	p_compUpdStatus 	VARCHAR2(1);
	p_rprUpdStatus  	VARCHAR2(1);
	p_rprDispSeq		NUMBER(3);
	p_parSeqId      	NUMBER;
	p_chldDispSeq		NUMBER(7);
	p_chldrepSeqid		NUMBER(9);
	p_TATIncreInd		VARCHAR2(1);
	p_rprTAT		NUMBER(7,2);
	p_priceIncreInd		VARCHAR2(1);
	p_rprPrice		NUMBER(20);
	p_rprQuoteInd		VARCHAR2(1);
	p_rprIndvRefNbr		VARCHAR2(50);
	p_chldRefNbr		VARCHAR2(50);
	p_rprDesc		VARCHAR2(255);
	p_rprComment		VARCHAR2(255);
	p_chldComment		VARCHAR2(255);
	p_rprType		VARCHAR2(20);
	p_rprDocRef		VARCHAR2(50);
	p_rprRefNbr		VARCHAR2(50);
	p_priceTypeSeq  	VARCHAR2(10);
	p_rprSeqId 		NUMBER(9);
	p_rprSeqIdOld 		NUMBER:=0;
	p_chldIniDispId 	NUMBER(7);
	v_errcode		VARCHAR2(1000);
	crcFutPrice    		NUMBER(20);
	crcRprSeqId 		NUMBER(9);
	v_dbms_cmd 		VARCHAR2(5000);
	v_dbms_curs		NUMBER;
	num_recs		INTEGER;
	p_jobInd		VARCHAR2(1);
	v_startdate 		VARCHAR2(12);
	v_comp_hist_flg 	VARCHAR2(1);
	v_repair_hist_flg 	VARCHAR2(1) := 'N'; 
	p_rpr_actn_flg  	VARCHAR(1); 
	p_catseqid      	NUMBER(9); 
	v_chldmin_lastupdt 	DATE;
	v_parmin_lastupdt 	DATE;
	v_parhist_seqid    	NUMBER(7); 
	v_chldhist_seqid   	NUMBER(7);
	v_parhist_seqid_val    	NUMBER(7); 
	v_chldhist_seqid_val   	NUMBER(7);
	p_rprHistDispSeq   	NUMBER(7);
	v_pareffDt		CRD_E_REPAIR_CATALOG_HIST.EFFECTIVE_DATE%TYPE;
	v_par_efftDt		CRD_E_REPAIR_CATALOG_HIST.EFFECTIVE_DATE%TYPE;
	v_chld_efftDt		CRD_E_REPAIR_CATALOG_HIST.EFFECTIVE_DATE%TYPE;
	t_startdate 		VARCHAR2(1) := NULL;
	cnt			number := 0;

/* Cursor to fetch data from the eCRD main tables. All records are selected from the main eCRD tables
   The records fetched consists of one full record based consisting of parent and child details if the
   record type is a Grouped record or a complete record if it is a Individual record. 
*/
TYPE OSB_DATA_REFCUR is REF CURSOR;      
OSB_DATA_CUR OSB_DATA_REFCUR;

TYPE CATALOG_RECORD IS RECORD
	(
	CatSeqId 		  crd_e_catalog.CATALOG_SEQ_ID%TYPE,
	CatNbr  		  crd_e_catalog.CATALOG_NUMBER%TYPE,
	CatDescr 		  crd_e_catalog.CATALOG_DESCRIPTION%TYPE,
	CatStartDt		  crd_e_catalog.CATALOG_EFFECTIVE_DATE%TYPE,
	CatEndDt 		  crd_e_catalog.CATALOG_END_DATE%TYPE, 
	ACTIVE_IND 		  crd_e_catalog.ACTIVE_IND%TYPE,
	CustCode 		  crd_e_customer_contract.CUSTOMER_CODE%TYPE,
	ContrNbr 		  crd_e_customer_contract.CONTRACT_NUMBER%TYPE,
	ContrDesc     		  crd_e_customer_contract.CUSTOMER_CONTRACT_DESCRIPTION%TYPE,
	engModNum 		  crd_crc_module.ENG_MDL_NUMBER%TYPE,
	locId 			  crd_location.LOCATION_ID%TYPE,
	compCode 		  crd_e_component.COMPONENT_CODE%TYPE,
	CompDocRef 		  crd_e_component.ATA_REFERENCE_SNUM%TYPE,
	baselineTAT 		  crd_e_component.BASELINE_TAT%TYPE,
	compEndDate 		  crd_e_component.COMPONENT_END_DATE%TYPE,
	rprOSBNbr 		  crd_e_repair.RPR_OSB_UNIQUE_NUMBER%TYPE,
	parSeqId  		  crd_e_repair.PARENT_REPAIR_SEQ_ID%TYPE,
	chldDispSeq 		  crd_e_repair_catalog.REPAIR_DISPLAY_SEQ_ID%TYPE, 
	TATIncreInd 		  crd_e_repair_catalog.INCREMENTAL_TAT_IND%TYPE,
	rprTAT 			  crd_e_repair_catalog.REPAIR_TAT%TYPE,
	priceIncreInd 		  crd_e_repair_catalog.INCREMENTAL_PRICE_IND%TYPE,
	rprPrice 		  crd_e_repair_catalog.REPAIR_PRICE%TYPE,
	rprEndDate 		  crd_e_repair_catalog.REPAIR_END_DATE%TYPE,
	prcEffDate 		  crd_e_repair_catalog.EFFECTIVE_DATE%TYPE,
	chldRefNbr		  crd_e_repair.REPAIR_REFERENCE%TYPE,
	chldRprDesc 		  crd_e_repair.REPAIR_DESCRIPTION%TYPE,
	chldComment 		  crd_e_repair.REPAIR_COMMENTS%TYPE,       
	rprType 		  crd_e_repair.REPAIR_TYPE%TYPE,
	compUpdDate 		  crd_e_component.LAST_UPDATE_DATE%TYPE,
	compCreDate 	          crd_e_component.CREATION_DATE%TYPE,
	rprUpdDate 		  crd_e_repair.LAST_UPDATE_DATE%TYPE,
	rprCreDate 		  crd_e_repair.CREATION_DATE%TYPE,
	ChldUpdDate 		  crd_e_repair_catalog.LAST_UPDATE_DATE%TYPE,
	ChldCreDate 		  crd_e_repair_catalog.CREATION_DATE%TYPE,
	priceTypeSeq 		  crd_e_repair_catalog.PRICE_TYPE%TYPE,
	rprSeqId  		  crd_e_repair.REPAIR_SEQ_ID%TYPE
	);

	OSB_DATA_RECS CATALOG_RECORD;

/* Main PL/SQL Body */	
BEGIN

/* Delete the staginf table before starting the Batch Interface */
delete CRD_E_OSB_REPAIR_STG;
commit;

/* Set the start date to the start date mentioned in the OSB_JOBS interface control table*/
p_startdate:=startdate;


/* Get the job control indicator from the OSB_JOBS interface control table */
SELECT job_indicator INTO p_jobInd FROM CRD_E_OSB_JOBS WHERE location_id = loc_id;

/* Opening Ref cursor based on the interface control table status. IF the job is running to migrate
   all the active catalogs at the end of the year then the start date is set to null in the 
   interface control table. 
   Note: Need to put the condition for disassociation of site . If active ind in component_Code table 
   is N then populate repair end_Date with sysdate + 1
*/
   
IF startdate IS NOT NULL THEN
OPEN OSB_DATA_CUR FOR
SELECT  T0.CATALOG_SEQ_ID CatSeqId,
        T0.CATALOG_NUMBER CatNbr,
        T0.CATALOG_DESCRIPTION CatDescr,
        T0.CATALOG_EFFECTIVE_DATE CatStartDt,
        T0.CATALOG_END_DATE CatEndDt, 
        T0.ACTIVE_IND,
        T8.CUSTOMER_CODE CustCode,
        T8.CONTRACT_NUMBER ContrNbr,
        T8.CUSTOMER_CONTRACT_DESCRIPTION ContrDesc,
        SUBSTR(T1.ENG_MDL_NUMBER,0,2) engModNum,
        SUBSTR(T2.LOCATION_ID,0,3) locId,
        SUBSTR(T4.COMPONENT_CODE,0,4) compCode,
        SUBSTR(T4.ATA_REFERENCE_SNUM,0,20) CompDocRef,
        SUBSTR(TO_CHAR(T4.BASELINE_TAT),0,5) baselineTAT,
        TO_CHAR(T4.COMPONENT_END_DATE,'dd-mon-yy') compEndDate,
        SUBSTR(TO_CHAR(T5.RPR_OSB_UNIQUE_NUMBER),0,5) rprOSBNbr,
        T5.PARENT_REPAIR_SEQ_ID   parSeqId,
        SUBSTR(TO_CHAR(T7.REPAIR_DISPLAY_SEQ_ID),0,3) chldDispSeq, 
        SUBSTR(T7.INCREMENTAL_TAT_IND,0,1) TATIncreInd,
        SUBSTR(TO_CHAR(T7.REPAIR_TAT),0,5) rprTAT,
        SUBSTR(T7.INCREMENTAL_PRICE_IND,0,1) priceIncreInd,
        SUBSTR(TO_CHAR(T7.REPAIR_PRICE),0,17) rprPrice,
        DECODE(T3.ACTIVE_IND,'Y',TO_CHAR(T7.REPAIR_END_DATE,'dd-mon-yy'),TO_CHAR(sysdate + 1,'dd-mon-yy')) rprEndDate,
        TO_CHAR(T7.EFFECTIVE_DATE,'dd-mon-yy') prcEffDate,
  	--SUBSTR(T5.REPAIR_REFERENCE,0,20) rprIndvRefNbr,
        SUBSTR(T5.REPAIR_REFERENCE,0,20) chldRefNbr,
  	--SUBSTR(T5.REPAIR_DESCRIPTION,0,255) rprDesc,
        SUBSTR(T5.REPAIR_DESCRIPTION,0,255) chldRprDesc,
  	--SUBSTR(T5.REPAIR_COMMENTS,0,255) rprComment,
        SUBSTR(T5.REPAIR_COMMENTS,0,255) chldComment,       
        T5.REPAIR_TYPE rprType,
        TO_CHAR(T4.LAST_UPDATE_DATE,'dd-mon-yy') compUpdDate,
        TO_CHAR(T4.CREATION_DATE,'dd-mon-yy') compCreDate,
        TO_CHAR(T5.LAST_UPDATE_DATE,'dd-mon-yy') rprUpdDate,
        TO_CHAR(T5.CREATION_DATE,'dd-mon-yy') rprCreDate,
        TO_CHAR(T7.LAST_UPDATE_DATE,'dd-mon-yy') ChldUpdDate,
        TO_CHAR(T7.CREATION_DATE,'dd-mon-yy') ChldCreDate,
        TO_CHAR(T7.PRICE_TYPE) priceTypeSeq,
        T5.REPAIR_SEQ_ID rprSeqId
  FROM  crd_e_catalog T0,
        crd_crc_module T1,
        crd_location T2,
        crd_e_component_location T3,
        crd_e_component T4,
        crd_e_repair T5,
        crd_e_repair_catalog T7,
        crd_e_customer_contract T8
  WHERE	T1.ENG_MDL_NUMBER 	= T0.ENG_MDL_NUMBER
        AND T0.CATALOG_SEQ_ID 	= T8.CATALOG_SEQ_ID(+)
 	AND T2.LOCATION_ID 	= LOC_ID
 	AND T0.catalog_type	IN ('C','D')
	AND T2.LOCATION_ID 	= T3.LOCATION_ID
	AND T3.MODULE_SEQ_ID 	= T1.MODULE_SEQ_ID
	AND T3.MODULE_SEQ_ID 	= T4.MODULE_SEQ_ID
	AND T3.COMPONENT_CODE 	= T4.COMPONENT_CODE
	AND T4.COMPONENT_CODE 	= T5.COMPONENT_CODE
	AND T4.MODULE_SEQ_ID  	= T5.MODULE_SEQ_ID
	AND T5.REPAIR_SEQ_ID 	= T7.REPAIR_SEQ_ID
	AND T7.CATALOG_SEQ_ID 	= T0.CATALOG_SEQ_ID
	AND T5.REPAIR_TYPE 	<> 'PR' 
	AND T3.COMPONENT_CODE 	= '57J'
	AND T1.ENG_MDL_NUMBER 	= '50'
	AND TO_DATE(TO_CHAR(T4.CREATION_DATE,'dd-mon-yy'),'dd-mon-yy') <= TO_DATE(enddate,'dd-mon-yy')
	AND TO_DATE(TO_CHAR(T4.LAST_UPDATE_DATE,'dd-mon-yy'),'dd-mon-yy') <= TO_DATE(enddate,'dd-mon-yy')
	AND TO_DATE(TO_CHAR(T5.LAST_UPDATE_DATE,'dd-mon-yy'),'dd-mon-yy') <= TO_DATE(enddate,'dd-mon-yy')
	AND TO_DATE(TO_CHAR(T5.CREATION_DATE,'dd-mon-yy'),'dd-mon-yy') <= TO_DATE(enddate,'dd-mon-yy')
	AND ((TO_DATE(TO_CHAR(T4.CREATION_DATE,'dd-mon-yy'),'dd-mon-yy') >= TO_DATE(startdate,'dd-mon-yy')) OR (TO_DATE(TO_CHAR(T4.LAST_UPDATE_DATE,'dd-mon-yy'),'dd-mon-yy') >= TO_DATE(startdate,'dd-mon-yy'))
	OR  (TO_DATE(TO_CHAR(T5.LAST_UPDATE_DATE,'dd-mon-yy'),'dd-mon-yy') >= TO_DATE(startdate,'dd-mon-yy')) OR (TO_DATE(TO_CHAR(T5.CREATION_DATE,'dd-mon-yy'),'dd-mon-yy') >= TO_DATE(startdate,'dd-mon-yy'))
	OR  (TO_DATE(TO_CHAR(T7.LAST_UPDATE_DATE,'dd-mon-yy'),'dd-mon-yy') >= TO_DATE(startdate,'dd-mon-yy')) OR (TO_DATE(TO_CHAR(T7.CREATION_DATE,'dd-mon-yy'),'dd-mon-yy') >= TO_DATE(startdate,'dd-mon-yy')))
	--AND T0.active_ind = CATSTS_IND;
      ORDER BY T1.ENG_MDL_NUMBER,T0.CATALOG_SEQ_ID,T4.Component_Code,T5.PARENT_REPAIR_SEQ_ID,T5.REPAIR_SEQ_ID;

ELSE

OPEN OSB_DATA_CUR FOR
SELECT  T0.CATALOG_SEQ_ID CatSeqId,
        T0.CATALOG_NUMBER CatNbr,
        T0.CATALOG_DESCRIPTION CatDescr,
        T0.CATALOG_EFFECTIVE_DATE CatStartDt,
        T0.CATALOG_END_DATE CatEndDt, 
        T0.ACTIVE_IND,
        T8.CUSTOMER_CODE CustCode,
        T8.CONTRACT_NUMBER ContrNbr,
        T8.CUSTOMER_CONTRACT_DESCRIPTION ContrDesc,
        SUBSTR(T1.ENG_MDL_NUMBER,0,2) engModNum,
        SUBSTR(T2.LOCATION_ID,0,3) locId,
        SUBSTR(T4.COMPONENT_CODE,0,4) compCode,
        SUBSTR(T4.ATA_REFERENCE_SNUM,0,20) CompDocRef,
        SUBSTR(TO_CHAR(T4.BASELINE_TAT),0,5) baselineTAT,
        TO_CHAR(T4.COMPONENT_END_DATE,'dd-mon-yy') compEndDate,
        SUBSTR(TO_CHAR(T5.RPR_OSB_UNIQUE_NUMBER),0,5) rprOSBNbr,
        T5.PARENT_REPAIR_SEQ_ID   parSeqId,
        SUBSTR(TO_CHAR(T7.REPAIR_DISPLAY_SEQ_ID),0,3) chldDispSeq, 
        SUBSTR(T7.INCREMENTAL_TAT_IND,0,1) TATIncreInd,
        SUBSTR(TO_CHAR(T7.REPAIR_TAT),0,5) rprTAT,
        SUBSTR(T7.INCREMENTAL_PRICE_IND,0,1) priceIncreInd,
        SUBSTR(TO_CHAR(T7.REPAIR_PRICE),0,17) rprPrice,
        TO_CHAR(T7.REPAIR_END_DATE,'dd-mon-yy') rprEndDate,
        TO_CHAR(T7.EFFECTIVE_DATE,'dd-mon-yy') prcEffDate,
  	--SUBSTR(T5.REPAIR_REFERENCE,0,20) rprIndvRefNbr,
        SUBSTR(T5.REPAIR_REFERENCE,0,20) chldRefNbr,
  	--SUBSTR(T5.REPAIR_DESCRIPTION,0,255) rprDesc,
        SUBSTR(T5.REPAIR_DESCRIPTION,0,255) chldRprDesc,
  	--SUBSTR(T5.REPAIR_COMMENTS,0,255) rprComment,
        SUBSTR(T5.REPAIR_COMMENTS,0,255) chldComment,       
        T5.REPAIR_TYPE rprType,
        TO_CHAR(T4.LAST_UPDATE_DATE,'dd-mon-yy') compUpdDate,
        TO_CHAR(T4.CREATION_DATE,'dd-mon-yy') compCreDate,
        TO_CHAR(T5.LAST_UPDATE_DATE,'dd-mon-yy') rprUpdDate,
        TO_CHAR(T5.CREATION_DATE,'dd-mon-yy') rprCreDate,
        TO_CHAR(T7.LAST_UPDATE_DATE,'dd-mon-yy') ChldUpdDate,
        TO_CHAR(T7.CREATION_DATE,'dd-mon-yy') ChldCreDate,
        TO_CHAR(T7.PRICE_TYPE) priceTypeSeq,
        T5.REPAIR_SEQ_ID rprSeqId
  FROM  crd_e_catalog T0,
        crd_crc_module T1,
        crd_location T2,
        crd_e_component_location T3,
        crd_e_component T4,
        crd_e_repair T5,
        crd_e_repair_catalog T7,
        crd_e_customer_contract T8
  WHERE	T1.ENG_MDL_NUMBER 	= T0.ENG_MDL_NUMBER
        AND T0.CATALOG_SEQ_ID 	= T8.CATALOG_SEQ_ID(+)
 	AND T2.LOCATION_ID 	= LOC_ID
 	AND T0.catalog_type 	IN ('C','D')
	AND T2.LOCATION_ID 	= T3.LOCATION_ID
	AND T3.MODULE_SEQ_ID 	= T1.MODULE_SEQ_ID
	AND T3.MODULE_SEQ_ID 	= T4.MODULE_SEQ_ID
	AND T3.COMPONENT_CODE 	= T4.COMPONENT_CODE
	AND T4.COMPONENT_CODE 	= T5.COMPONENT_CODE
	AND T4.MODULE_SEQ_ID  	= T5.MODULE_SEQ_ID
	AND T5.REPAIR_SEQ_ID 	= T7.REPAIR_SEQ_ID
	AND T7.CATALOG_SEQ_ID 	= T0.CATALOG_SEQ_ID
	AND T5.REPAIR_TYPE 	<> 'PR' 
--	AND T3.COMPONENT_CODE 	= '211'
--	AND T1.ENG_MDL_NUMBER 	= '06'
	AND TO_DATE(TO_CHAR(T4.CREATION_DATE,'dd-mon-yy'),'dd-mon-yy') <= TO_DATE(enddate,'dd-mon-yy')
	AND TO_DATE(TO_CHAR(T4.LAST_UPDATE_DATE,'dd-mon-yy'),'dd-mon-yy') <= TO_DATE(enddate,'dd-mon-yy')
	AND TO_DATE(TO_CHAR(T5.LAST_UPDATE_DATE,'dd-mon-yy'),'dd-mon-yy') <= TO_DATE(enddate,'dd-mon-yy')
	AND TO_DATE(TO_CHAR(T5.CREATION_DATE,'dd-mon-yy'),'dd-mon-yy') <= TO_DATE(enddate,'dd-mon-yy')
	AND T4.COMPONENT_END_DATE IS NULL
	AND T7.REPAIR_END_DATE 	  IS NULL
	--      AND T0.active_ind = CATSTS_IND;
      ORDER BY T1.ENG_MDL_NUMBER,T0.CATALOG_SEQ_ID,T4.Component_Code,T5.PARENT_REPAIR_SEQ_ID,T5.REPAIR_SEQ_ID;

END IF; -- End of startdate null check

/* Check if start date is null. IF yes assign it a default value*/
IF(startdate IS NULL) THEN
   p_startdate:='01-jan-2000';
END IF;

/* Open Cursor to get the data to be sent to OSB based on Creation date and end dates */
LOOP
FETCH osb_data_cur into osb_Data_Recs;
cnt := cnt + 1;
EXIT WHEN osb_data_cur%NOTFOUND;
p_chldrepSeqid := osb_data_recs.rprSeqId;

/* Fetch the parent record details for the child record*/
IF (osb_data_recs.parSeqId IS NOT NULL) THEN

	BEGIN
		SELECT REPAIR_DISPLAY_SEQ_ID ,REPAIR_TAT, PRICE_TYPE,  REPAIR_PRICE
		INTO p_rprDispSeq, p_rprTAT, p_priceTypeSeq, p_rprPrice
		FROM CRD_E_REPAIR_CATALOG
		WHERE REPAIR_SEQ_ID = OSB_DATA_RECS.parSeqId
		AND  CATALOG_SEQ_ID = OSB_DATA_RECS.CatSeqId;
	EXCEPTION
		WHEN OTHERS THEN 
		DBMS_OUTPUT.PUT_LINE(SQLCODE || SQLERRM);
		DBMS_OUTPUT.PUT_LINE('Error in fetching Parent Repair Details for child from Repair Catalog table for :'||OSB_DATA_RECS.parSeqId);
	END;
	
	
	BEGIN
		SELECT REPAIR_REFERENCE,  REPAIR_DESCRIPTION, REPAIR_COMMENTS 
		INTO  p_rprIndvRefNbr, p_rprDesc, p_rprComment
		FROM CRD_E_REPAIR
		WHERE REPAIR_SEQ_ID = OSB_DATA_RECS.parSeqId;
	EXCEPTION
		WHEN OTHERS THEN 
		DBMS_OUTPUT.PUT_LINE('Error in fetching Parent Repair Details for child from Repair table for:'||OSB_DATA_RECS.parSeqId);
	END;
 
 	/* Setting the Repair sequence id to parent repair sequence id value */
 	p_rprSeqId 	:= osb_data_recs.parSeqId; 
-- 	p_chldIniDispId := osb_data_recs.chldDispSeq;
--	p_chldDispSeq   := osb_data_recs.chldDispSeq;

ELSE

/* This initilisation is for non Grouped Repairs, like IR */
       p_rprIndvRefNbr := osb_data_recs.chldRefNbr;  -- Because both the column is one. This is for IR type repairs
       p_rprPrice      := osb_data_recs.rprPrice ;
       p_priceTypeSeq  := osb_data_recs.priceTypeSeq;
       p_rprTAT        := osb_data_recs.rprTAT;
       p_rprDesc       := osb_data_recs.chldRprDesc; -- For IR repairs, since only one reocrd is fetched.
       p_rprComment    := osb_data_recs.chldComment; -- For IR type repairs.
       p_rprDispSeq    := osb_data_recs.chldDispSeq;
       p_rprSeqId      := osb_data_recs.rprSeqId; 
--     p_chldIniDispId := osb_data_recs.chldDispSeq;
	
END IF; -- END of Fetching PArent repair details for child repairs.


 /* Check price type seq*/
 IF (p_priceTypeSeq = 'QUOTE') THEN
  	p_rprQuoteInd:='Q';
 ELSE
  	p_rprQuoteInd:=' ';
 END IF;
 
 
 /*Check the TAT Increment Indicator*/
 IF (osb_data_recs.TATIncreInd = 'Y') THEN
 	p_TATIncreInd:='+';
 ELSE
 	p_TATIncreInd:=' ';
 END IF;
 
 
 /*Check the price increment indicator*/
 IF (osb_data_recs.priceIncreInd = 'Y') THEN
 	p_priceIncreInd:='+';
 ELSE
 	p_priceIncreInd:=' ';
 END IF;
 
 
 /*Check the repair seq id*/
 IF(p_rprSeqIdOld != p_rprSeqId) THEN
 	p_rprSeqIdOld  := p_rprSeqId;
 	p_chldIniDispId:= osb_data_recs.chldDispSeq - 5;
 END IF;
 
/* Check the job indicator status in the Interface control table. Fetch the future price from the repair catalog table */
IF(p_jobInd = 'Y') THEN
	BEGIN
	  SELECT substr(to_char(FUTURE_PRICE),0,17) INTO crcFutPrice
	  FROM crd_e_repair_catalog
	  WHERE	  to_date(to_char(FUTURE_EFFECTIVE_DATE,'dd-mon-yy'),'dd-mon-yy') <= to_date(ENDdate,'dd-mon-yy')
	  AND REPAIR_SEQ_ID=osb_data_recs.rprSeqId;
	  IF(crcFutPrice IS NOT NULL) THEN
		p_rprPrice:=crcFutPrice;
	  END IF;
	EXCEPTION 
	  WHEN NO_DATA_FOUND THEN
                NULL;
          WHEN OTHERS THEN      
                DBMS_OUTPUT.PUT_LINE('Error Occurred while fetching future price');
	END;
END IF;

/* Setting the repair price */
p_rprPrice:=p_rprPrice*1000;

/*If Condition to process the cursor records based on the condition if it is a IR or any other type of repair*/
IF (osb_data_recs.rprType='IR') then -- Need to add Split Repair

IF((substr(p_rprIndvRefNbr,1,1) >='0') AND (substr(p_rprIndvRefNbr,1,1)<='9') AND (substr(p_rprIndvRefNbr,2,1) >='0') AND (substr(p_rprIndvRefNbr,2,1)<='9')) THEN
	p_rprDocRef:= p_rprIndvRefNbr;
	p_rprRefNbr:=' ';
ELSIF(substr(p_rprIndvRefNbr,0,5) = 'CINSP') then
	p_rprDocRef:= p_rprIndvRefNbr;
	p_rprRefNbr:=' ';
ELSE
	p_rprDocRef:=' ';
	p_rprRefNbr:= p_rprIndvRefNbr;
END IF;


/* Check Repair History table if for the following record the REPAIR_DISP_SEQ_ID 
   is modified or not. If Yes we need to send this record to OSB indicating that the 
   corresponding record in OSB needs to be deleted, while the new record needs to 
   inserted 
*/
	BEGIN
		 SELECT MIN(LAST_UPDATE_DATE), REPAIR_DISPLAY_SEQ_ID, EFFECTIVE_DATE
		 INTO v_parmin_lastupdt, v_parhist_seqid , v_pareffDt
		 FROM CRD_E_REPAIR_CATALOG_HIST
		 WHERE repair_seq_id = osb_data_recs.rprSeqId
		 AND catalog_seq_id  = osb_data_recs.catseqid
		 AND LAST_UPDATE_DATE BETWEEN STARTDATE AND ENDDATE
		 GROUP BY REPAIR_DISPLAY_SEQ_ID, EFFECTIVE_DATE;
	EXCEPTION
		 WHEN NO_DATA_FOUND THEN
		   v_parhist_seqid   := NULL;
		   v_pareffDt        := NULL;
		   v_repair_hist_flg := 'N';
		 WHEN OTHERS THEN
		   DBMS_OUTPUT.PUT_LINE('No data found at IR level for :'||osb_data_recs.rprSeqId||''||osb_data_recs.catseqid);
		   DBMS_OUTPUT.PUT_LINE(SQLCODE || SQLERRM);
	END;

/* Check to see if the sequence id is modified in the history table as it is part of 
   the PK in OSB. If Yes then we need to send the value to OSB  so that they can soft 
   delete the repair in their system
*/
	IF ((p_rprDispSeq <> v_parhist_seqid) OR (osb_data_recs.prcEffDate <> v_parEffDt)) THEN
		   v_repair_hist_flg := 'Y';
		   p_rprHistDispSeq  := v_parhist_seqid;
	END IF;   


/* These two inserts basically insert data into the Staging table with the actual values 
   from the regular tables. If the repair has comments then another similar record with 
   the comment inserted into the description is inserted.
*/
	INSERT INTO CRD_E_OSB_REPAIR_STG(OSB_INFC_RPR_SEQ_ID, CATALOG_SEQ_ID, CATALOG_NUMBER, CATALOG_DESCRIPTION,CATALOG_EFFECTIVE_DATE,CATALOG_END_DATE,
	                ENG_MDL_NUMBER, RPR_UPDATE_STS,
			COMPONENT_CODE, COMPONENT_DOC_REF, LOCATION_ID,
			COMPONENT_UPDATE_STS, COMPONENT_TYPE,RPR_END_DATE,
			BASELINE_TAT,RPR_TAT,RPR_PRICE,
			OSB_UNIQUE_NUMBER, PRICE_QUOTE_IND, COMPONENT_END_DATE,
			PRICE_INCREMENT_IND, TAT_INCREMENT_IND,WRKSCP_DISP_SEQ_ID,
			RPR_DOC_REF,RPR_DISP_SEQ_ID,RPR_DESC,
			RPR_REF_SNUM,NOTE_IND,PRICE_EFFECTIVE_DATE,RPR_ACTN_FLG,REPAIR_SEQ_ID,AR_ORACLE_USER,CONTRACT_NUMBER,CONTRACT_DESCRIPTION,
			CREATED_BY,CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE)
		VALUES (CRD_CRC_OSB_REPAIR_STG_SEQ.nextval, osb_data_recs.CatSeqId, osb_data_recs.CatNbr, osb_data_recs.CatDescr, osb_data_recs.CatStartDt, osb_data_recs.CatEndDt, 
		 	osb_data_recs.engModNum, p_rprUpdStatus,
			osb_data_recs.compCode, osb_data_recs.CompDocRef, osb_data_recs.locId,
			p_compUpdStatus,'C',to_date(osb_data_recs.rprEndDate,'dd-mon-yy'),
			osb_data_recs.baselineTAT,p_rprTAT,p_rprPrice,
			osb_data_recs.rprOSBNbr, p_rprQuoteInd, to_date(osb_data_recs.compEndDate,'dd-mon-yy'),
			p_priceIncreInd, p_TATIncreInd, p_rprDispSeq,
			p_rprDocRef,p_rprDispSeq,p_rprDesc,
			substr(p_rprRefNbr,0,15),'',osb_Data_recs.prcEffDate, p_rpr_actn_flg,p_chldrepSeqid,osb_data_recs.CustCode, osb_data_recs.ContrNbr, osb_data_recs.ContrDesc,
			'Batch Process', sysdate, 'Batch Process', sysdate);
			v_updcount:=v_updcount+1;
/*Check to see if the record has a comment fld, If yes another insert is done with the comments placed in the description column */
	IF (p_rprComment <> ' ') THEN
		p_rprComment:='*'||p_rprComment;
	INSERT INTO CRD_E_OSB_REPAIR_STG(OSB_INFC_RPR_SEQ_ID, CATALOG_SEQ_ID, CATALOG_NUMBER, CATALOG_DESCRIPTION,CATALOG_EFFECTIVE_DATE,CATALOG_END_DATE,
			ENG_MDL_NUMBER, RPR_UPDATE_STS,
			COMPONENT_CODE, COMPONENT_DOC_REF, LOCATION_ID,
			COMPONENT_UPDATE_STS, COMPONENT_TYPE,RPR_END_DATE,
			BASELINE_TAT,RPR_TAT,RPR_PRICE,
			OSB_UNIQUE_NUMBER, PRICE_QUOTE_IND, COMPONENT_END_DATE,
			PRICE_INCREMENT_IND, TAT_INCREMENT_IND,WRKSCP_DISP_SEQ_ID,
			RPR_DOC_REF,RPR_DISP_SEQ_ID,RPR_DESC,
			RPR_REF_SNUM,NOTE_IND,PRICE_EFFECTIVE_DATE,RPR_ACTN_FLG,REPAIR_SEQ_ID,AR_ORACLE_USER,CONTRACT_NUMBER,CONTRACT_DESCRIPTION,
			CREATED_BY,CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE)
		VALUES (CRD_CRC_OSB_REPAIR_STG_SEQ.nextval, osb_data_recs.CatSeqId, osb_data_recs.CatNbr, osb_data_recs.CatDescr, osb_data_recs.CatStartDt, osb_data_recs.CatEndDt, 
			osb_data_recs.engModNum, p_rprUpdStatus,
			osb_data_recs.compCode, osb_data_recs.CompDocRef, osb_data_recs.locId,
			p_compUpdStatus,'C',to_date(osb_data_recs.rprEndDate,'dd-mon-yy'),
			osb_data_recs.baselineTAT,p_rprTAT,p_rprPrice,
			osb_data_recs.rprOSBNbr, p_rprQuoteInd, to_date(osb_data_recs.compEndDate,'dd-mon-yy'),
			p_priceIncreInd, p_TATIncreInd,p_rprDispSeq,
			'',p_rprDispSeq+5,p_rprComment,
			'','*',osb_Data_recs.prcEffDate, p_rpr_actn_flg,p_chldrepSeqid ,osb_data_recs.CustCode, osb_data_recs.ContrNbr, osb_data_recs.ContrDesc,
			'Batch Process', sysdate, 'Batch Process', sysdate);
			v_updcount:=v_updcount+1;
              END IF; -- End of the repair comments equal to space check
              
/* Checking if history record exists . If yes then we need to fetch the value of the 
   sequence id and check to see if it is modified.If Yes we need to send this record to OSB 
*/              
	IF v_repair_hist_flg = 'Y' THEN
	INSERT INTO CRD_E_OSB_REPAIR_STG(OSB_INFC_RPR_SEQ_ID, CATALOG_SEQ_ID, CATALOG_NUMBER, CATALOG_DESCRIPTION,CATALOG_EFFECTIVE_DATE,CATALOG_END_DATE,
	                ENG_MDL_NUMBER, RPR_UPDATE_STS,
			COMPONENT_CODE, COMPONENT_DOC_REF, LOCATION_ID,
			COMPONENT_UPDATE_STS, COMPONENT_TYPE,RPR_END_DATE,
			BASELINE_TAT,RPR_TAT,RPR_PRICE,
			OSB_UNIQUE_NUMBER, PRICE_QUOTE_IND, COMPONENT_END_DATE,
			PRICE_INCREMENT_IND, TAT_INCREMENT_IND,WRKSCP_DISP_SEQ_ID,
			RPR_DOC_REF,RPR_DISP_SEQ_ID,RPR_DESC,
			RPR_REF_SNUM,NOTE_IND,PRICE_EFFECTIVE_DATE,RPR_ACTN_FLG,REPAIR_SEQ_ID,AR_ORACLE_USER,CONTRACT_NUMBER,CONTRACT_DESCRIPTION,
			CREATED_BY,CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE)
		VALUES (CRD_CRC_OSB_REPAIR_STG_SEQ.nextval, osb_data_recs.CatSeqId, osb_data_recs.CatNbr, osb_data_recs.CatDescr, osb_data_recs.CatStartDt, osb_data_recs.CatEndDt, 
		 	osb_data_recs.engModNum, p_rprUpdStatus,
			osb_data_recs.compCode, osb_data_recs.CompDocRef, osb_data_recs.locId,
			p_compUpdStatus,'C',sysdate + 1,
			osb_data_recs.baselineTAT,p_rprTAT,p_rprPrice,
			osb_data_recs.rprOSBNbr, p_rprQuoteInd, to_date(osb_data_recs.compEndDate,'dd-mon-yy'),
			p_priceIncreInd, p_TATIncreInd, p_rprHistDispSeq,
			p_rprDocRef,p_rprHistDispSeq,p_rprDesc,
			substr(p_rprRefNbr,0,15),'',v_parEffDt, p_rpr_actn_flg,p_chldrepSeqid ,osb_data_recs.CustCode, osb_data_recs.ContrNbr, osb_data_recs.ContrDesc,
			'Batch Process', sysdate, 'Batch Process', sysdate);
v_updcount:=v_updcount+1;

/* If Record has comments, then insert a fresh record with same values, with the description 
   field having the comment values 
*/
	IF (p_rprComment <> ' ') THEN
		p_rprComment:='*'||p_rprComment;
	INSERT INTO CRD_E_OSB_REPAIR_STG(OSB_INFC_RPR_SEQ_ID, CATALOG_SEQ_ID, CATALOG_NUMBER, CATALOG_DESCRIPTION,CATALOG_EFFECTIVE_DATE,CATALOG_END_DATE,
			ENG_MDL_NUMBER, RPR_UPDATE_STS,
			COMPONENT_CODE, COMPONENT_DOC_REF, LOCATION_ID,
			COMPONENT_UPDATE_STS, COMPONENT_TYPE,RPR_END_DATE,
			BASELINE_TAT,RPR_TAT,RPR_PRICE,
			OSB_UNIQUE_NUMBER, PRICE_QUOTE_IND, COMPONENT_END_DATE,
			PRICE_INCREMENT_IND, TAT_INCREMENT_IND,WRKSCP_DISP_SEQ_ID,
			RPR_DOC_REF,RPR_DISP_SEQ_ID,RPR_DESC,
			RPR_REF_SNUM,NOTE_IND,PRICE_EFFECTIVE_DATE,RPR_ACTN_FLG,REPAIR_SEQ_ID,AR_ORACLE_USER,CONTRACT_NUMBER,CONTRACT_DESCRIPTION,
			CREATED_BY,CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE)
		VALUES (CRD_CRC_OSB_REPAIR_STG_SEQ.nextval, osb_data_recs.CatSeqId, osb_data_recs.CatNbr, osb_data_recs.CatDescr, osb_data_recs.CatStartDt, osb_data_recs.CatEndDt, 
			osb_data_recs.engModNum, p_rprUpdStatus,
			osb_data_recs.compCode, osb_data_recs.CompDocRef, osb_data_recs.locId,
			p_compUpdStatus,'C',sysdate + 1,
			osb_data_recs.baselineTAT,p_rprTAT,p_rprPrice,
			osb_data_recs.rprOSBNbr, p_rprQuoteInd, to_date(osb_data_recs.compEndDate,'dd-mon-yy'),
			p_priceIncreInd, p_TATIncreInd,p_rprHistDispSeq,
			'',p_rprHistDispSeq+5 ,p_rprComment,
			'','*',v_parEffDt, p_rpr_actn_flg,p_chldrepSeqid,osb_data_recs.CustCode, osb_data_recs.ContrNbr, osb_data_recs.ContrDesc,
			'Batch Process', sysdate, 'Batch Process', sysdate);
			v_updcount:=v_updcount+1;
              END IF; -- End of the repair comments equal to space check
              
END IF;              

ELSE -- Else part of Repair type check. This Else type check to see if the Repair is PR type.

/* Check the Repair Reference number*/
IF((substr(osb_data_recs.chldRefNbr,1,1) >='0') AND (substr(osb_data_recs.chldRefNbr,1,1)<='9') AND (substr(osb_data_recs.chldRefNbr,2,1) >='0') AND (substr(p_chldRefNbr,2,1)<='9')) THEN
	p_rprDocRef:=osb_data_recs.chldRefNbr;
	p_rprRefNbr:=' ';
ELSIF(substr(osb_data_recs.chldRefNbr,0,5) = 'CINSP') THEN
	p_rprDocRef:=osb_data_recs.chldRefNbr;
	p_rprRefNbr:=' ';
ELSE
 	p_rprDocRef:=' ';
	p_rprRefNbr:=osb_data_recs.chldRefNbr;
END IF;

/*Check the repair sequence id columns to see if they are same*/
	IF(p_rprSeqIdOld = p_rprSeqId) THEN
		p_chldIniDispId:=p_chldIniDispId + 5;
	ELSE
		p_chldIniDispId:=osb_data_recs.chldDispSeq;
	END IF;

	
/* Following If condition checks to see if there is a corresponding record in the 
   Repair Catalog history table which has the display sequence id modified. IF Yes 
   we need to send to OSB so that they could do a soft delete at their end
*/   
IF (osb_data_recs.parSeqId IS NOT NULL) THEN

/* Condition checks to see if the PArent records Sequence id is modified */
	BEGIN
		 SELECT MIN(LAST_UPDATE_DATE), REPAIR_DISPLAY_SEQ_ID, EFFECTIVE_DATE
		 INTO v_parmin_lastupdt, v_parhist_seqid, v_par_efftDt
		 FROM CRD_E_REPAIR_CATALOG_HIST
		 WHERE repair_seq_id = osb_data_recs.parseqid
		 AND catalog_seq_id  = osb_data_recs.catseqid
		 AND LAST_UPDATE_DATE BETWEEN STARTDATE and ENDDATE
		 GROUP BY REPAIR_DISPLAY_SEQ_ID, EFFECTIVE_DATE;
		
		v_parhist_seqid_val := v_parhist_seqid;
		 
	EXCEPTION
	         WHEN NO_DATA_FOUND THEN
	           v_parhist_seqid 	:= p_rprDispSeq;
	           v_parhist_seqid_val 	:= NULL;
	           v_repair_hist_flg 	:= 'N';
		 WHEN OTHERS THEN
		   DBMS_OUTPUT.PUT_LINE('No data found at parent level while fetching data for Grouped Repair'); 
		   DBMS_OUTPUT.PUT_LINE(SQLCODE || SQLERRM);
	END;

/* Condition checks to see if the Child records Sequence id is modified */
	BEGIN
		 SELECT MIN(LAST_UPDATE_DATE), REPAIR_DISPLAY_SEQ_ID, EFFECTIVE_DATE
		 INTO v_chldmin_lastupdt, v_chldhist_seqid, v_chld_efftDt
		 FROM CRD_E_REPAIR_CATALOG_HIST
		 WHERE repair_seq_id = osb_data_recs.rprSeqId
		 AND catalog_seq_id  = osb_data_recs.catseqid
		 AND LAST_UPDATE_DATE BETWEEN STARTDATE and ENDDATE
		 GROUP BY REPAIR_DISPLAY_SEQ_ID, EFFECTIVE_DATE;
		 
		 v_chldhist_seqid_val := v_chldhist_seqid; 
	EXCEPTION
	         WHEN NO_DATA_FOUND THEN
	           v_chldhist_seqid 	:= p_chldIniDispId;
	           v_chldhist_seqid_val := NULL;
	           v_repair_hist_flg	:= 'N';
		 WHEN OTHERS THEN
		   DBMS_OUTPUT.PUT_LINE('No data found at child level while fetching data for Grouped Repair');
		   DBMS_OUTPUT.PUT_LINE(SQLCODE || SQLERRM);
	END;
	
/* Set the history flag to Y to indicate that the record needs to be sent to OSB */
	IF ((p_rprDispSeq <> v_parhist_seqid_val) OR (osb_Data_Recs.prcEffDate <> v_par_efftDt)) THEN
	   v_repair_hist_flg := 'Y';
	END IF;   
	IF ((osb_data_recs.chldDispSeq <> v_chldhist_seqid_val) OR (osb_Data_Recs.prcEffDate <> v_par_efftDt)) THEN
	   v_repair_hist_flg := 'Y';
	END IF;   

END IF; -- End of the history data record check

/*Insert regular record into the staging table */
		INSERT INTO CRD_E_OSB_REPAIR_STG(OSB_INFC_RPR_SEQ_ID, CATALOG_SEQ_ID, CATALOG_NUMBER, CATALOG_DESCRIPTION,CATALOG_EFFECTIVE_DATE,CATALOG_END_DATE,
			ENG_MDL_NUMBER, RPR_UPDATE_STS,
			COMPONENT_CODE, COMPONENT_DOC_REF, LOCATION_ID,
			COMPONENT_UPDATE_STS, COMPONENT_TYPE,RPR_END_DATE,
			BASELINE_TAT,RPR_TAT,RPR_PRICE,
			OSB_UNIQUE_NUMBER, PRICE_QUOTE_IND, COMPONENT_END_DATE,
			PRICE_INCREMENT_IND, TAT_INCREMENT_IND,WRKSCP_DISP_SEQ_ID,
			RPR_DOC_REF,RPR_DISP_SEQ_ID,RPR_DESC,
			RPR_REF_SNUM,NOTE_IND,PRICE_EFFECTIVE_DATE,RPR_ACTN_FLG,REPAIR_SEQ_ID,AR_ORACLE_USER,CONTRACT_NUMBER,CONTRACT_DESCRIPTION,
			CREATED_BY,CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE)
		VALUES (CRD_CRC_OSB_REPAIR_STG_SEQ.nextval, osb_data_recs.CatSeqId, osb_data_recs.CatNbr, osb_data_recs.CatDescr, osb_data_recs.CatStartDt, osb_data_recs.CatEndDt, 
			osb_data_recs.engModNum, p_rprUpdStatus,
			osb_data_recs.compCode, osb_data_recs.CompDocRef, osb_data_recs.locId,
			p_compUpdStatus,'C',to_date(osb_data_recs.rprEndDate,'dd-mon-yy'),
			osb_data_recs.baselineTAT,p_rprTAT,p_rprPrice,
			osb_data_recs.rprOSBNbr, p_rprQuoteInd, to_date(osb_data_recs.compEndDate,'dd-mon-yy'),
			p_priceIncreInd, p_TATIncreInd,p_rprDispSeq,
			p_rprDocRef,p_chldIniDispId,osb_data_recs.chldRprDesc,
			substr(p_rprRefNbr,0,15),'',osb_Data_recs.prcEffDate,p_rpr_actn_flg,p_chldrepSeqid,osb_data_recs.CustCode, osb_data_recs.ContrNbr, osb_data_recs.ContrDesc ,
			'Batch Process', sysdate, 'Batch Process', sysdate);
			v_updcount:=v_updcount+1;

/* If the record has a child comment insert a fresh record with the repair description part consisting the comments*/
		IF (osb_data_recs.chldComment <> ' ') THEN
			p_chldComment  :='*'||osb_data_recs.chldComment;
			p_chldIniDispId:=p_chldIniDispId + 5;
			
		INSERT INTO CRD_E_OSB_REPAIR_STG(OSB_INFC_RPR_SEQ_ID, CATALOG_SEQ_ID, CATALOG_NUMBER, CATALOG_DESCRIPTION,CATALOG_EFFECTIVE_DATE,CATALOG_END_DATE,
			ENG_MDL_NUMBER, RPR_UPDATE_STS,
			COMPONENT_CODE, COMPONENT_DOC_REF, LOCATION_ID,
			COMPONENT_UPDATE_STS, COMPONENT_TYPE,RPR_END_DATE,
			BASELINE_TAT,RPR_TAT,RPR_PRICE,
			OSB_UNIQUE_NUMBER, PRICE_QUOTE_IND, COMPONENT_END_DATE,
			PRICE_INCREMENT_IND, TAT_INCREMENT_IND,WRKSCP_DISP_SEQ_ID,
			RPR_DOC_REF,RPR_DISP_SEQ_ID,RPR_DESC,
			RPR_REF_SNUM,NOTE_IND,PRICE_EFFECTIVE_DATE,RPR_ACTN_FLG,REPAIR_SEQ_ID,AR_ORACLE_USER,CONTRACT_NUMBER,CONTRACT_DESCRIPTION,
			CREATED_BY,CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE)
		VALUES (CRD_CRC_OSB_REPAIR_STG_SEQ.nextval, osb_data_recs.CatSeqId, osb_data_recs.CatNbr, osb_data_recs.CatDescr, osb_data_recs.CatStartDt, osb_data_recs.CatEndDt, 
			osb_data_recs.engModNum, p_rprUpdStatus,
			osb_data_recs.compCode, osb_data_recs.CompDocRef, osb_data_recs.locId,
			p_compUpdStatus,'C',to_date(osb_data_recs.rprEndDate,'dd-mon-yy'),
			osb_data_recs.baselineTAT,p_rprTAT,p_rprPrice,
			osb_data_recs.rprOSBNbr, p_rprQuoteInd, to_date(osb_data_recs.compEndDate,'dd-mon-yy'),
			p_priceIncreInd, p_TATIncreInd,p_rprDispSeq,
			'',p_chldIniDispId,p_chldComment,
			'','*',osb_Data_recs.prcEffDate, p_rpr_actn_flg,p_chldrepSeqid ,osb_data_recs.CustCode, osb_data_recs.ContrNbr, osb_data_recs.ContrDesc,
			'Batch Process', sysdate, 'Batch Process', sysdate);
			v_updcount:=v_updcount+1;
		END IF;
		
/* Check to see if the history record exists for which the OSB PK is modified. 
   If yes, insert record into table 
*/
	IF v_repair_hist_flg = 'Y' THEN
	
		INSERT INTO CRD_E_OSB_REPAIR_STG(OSB_INFC_RPR_SEQ_ID, CATALOG_SEQ_ID, CATALOG_NUMBER, CATALOG_DESCRIPTION,CATALOG_EFFECTIVE_DATE,CATALOG_END_DATE,
			ENG_MDL_NUMBER, RPR_UPDATE_STS,
			COMPONENT_CODE, COMPONENT_DOC_REF, LOCATION_ID,
			COMPONENT_UPDATE_STS, COMPONENT_TYPE,RPR_END_DATE,
			BASELINE_TAT,RPR_TAT,RPR_PRICE,
			OSB_UNIQUE_NUMBER, PRICE_QUOTE_IND, COMPONENT_END_DATE,
			PRICE_INCREMENT_IND, TAT_INCREMENT_IND,WRKSCP_DISP_SEQ_ID,
			RPR_DOC_REF,RPR_DISP_SEQ_ID,RPR_DESC,
			RPR_REF_SNUM,NOTE_IND,PRICE_EFFECTIVE_DATE,RPR_ACTN_FLG,REPAIR_SEQ_ID,AR_ORACLE_USER,CONTRACT_NUMBER,CONTRACT_DESCRIPTION,
			CREATED_BY,CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE)
		VALUES (CRD_CRC_OSB_REPAIR_STG_SEQ.nextval, osb_data_recs.CatSeqId, osb_data_recs.CatNbr, osb_data_recs.CatDescr, osb_data_recs.CatStartDt, osb_data_recs.CatEndDt, 
			osb_data_recs.engModNum, p_rprUpdStatus,
			osb_data_recs.compCode, osb_data_recs.CompDocRef, osb_data_recs.locId,
			p_compUpdStatus,'C',sysdate + 1,
			osb_data_recs.baselineTAT,p_rprTAT,p_rprPrice,
			osb_data_recs.rprOSBNbr, p_rprQuoteInd, to_date(osb_data_recs.compEndDate,'dd-mon-yy'),
			p_priceIncreInd, p_TATIncreInd,v_parhist_seqid,
			p_rprDocRef,v_chldhist_seqid,osb_data_recs.chldRprDesc,
			substr(p_rprRefNbr,0,15),'',osb_Data_recs.prcEffDate,p_rpr_actn_flg,p_chldrepSeqid,osb_data_recs.CustCode, osb_data_recs.ContrNbr, osb_data_recs.ContrDesc,
			'Batch Process', sysdate, 'Batch Process', sysdate);
			v_updcount:=v_updcount+1;
		IF (osb_data_recs.chldComment <> ' ') THEN
			p_chldComment  :='*'||osb_data_recs.chldComment;
			p_chldIniDispId:=p_chldIniDispId;

		INSERT INTO CRD_E_OSB_REPAIR_STG(OSB_INFC_RPR_SEQ_ID, CATALOG_SEQ_ID, CATALOG_NUMBER, CATALOG_DESCRIPTION,CATALOG_EFFECTIVE_DATE,CATALOG_END_DATE,
			ENG_MDL_NUMBER, RPR_UPDATE_STS,
			COMPONENT_CODE, COMPONENT_DOC_REF, LOCATION_ID,
			COMPONENT_UPDATE_STS, COMPONENT_TYPE,RPR_END_DATE,
			BASELINE_TAT,RPR_TAT,RPR_PRICE,
			OSB_UNIQUE_NUMBER, PRICE_QUOTE_IND, COMPONENT_END_DATE,
			PRICE_INCREMENT_IND, TAT_INCREMENT_IND,WRKSCP_DISP_SEQ_ID,
			RPR_DOC_REF,RPR_DISP_SEQ_ID,RPR_DESC,
			RPR_REF_SNUM,NOTE_IND,PRICE_EFFECTIVE_DATE,RPR_ACTN_FLG,REPAIR_SEQ_ID,AR_ORACLE_USER,CONTRACT_NUMBER,CONTRACT_DESCRIPTION,
			CREATED_BY,CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE)
		VALUES (CRD_CRC_OSB_REPAIR_STG_SEQ.nextval, osb_data_recs.CatSeqId, osb_data_recs.CatNbr, osb_data_recs.CatDescr, osb_data_recs.CatStartDt, osb_data_recs.CatEndDt, 
			osb_data_recs.engModNum, p_rprUpdStatus,
			osb_data_recs.compCode, osb_data_recs.CompDocRef, osb_data_recs.locId,
			p_compUpdStatus,'C',sysdate + 1,
			osb_data_recs.baselineTAT,p_rprTAT,p_rprPrice,
			osb_data_recs.rprOSBNbr, p_rprQuoteInd, to_date(osb_data_recs.compEndDate,'dd-mon-yy'),
			p_priceIncreInd, p_TATIncreInd,v_parhist_seqid,
			'',v_chldhist_seqid,p_chldComment,
			'','*',osb_Data_recs.prcEffDate, p_rpr_actn_flg,p_chldrepSeqid ,osb_data_recs.CustCode, osb_data_recs.ContrNbr, osb_data_recs.ContrDesc,
			'Batch Process', sysdate, 'Batch Process', sysdate);
			v_updcount:=v_updcount+1;
		END IF;
		v_repair_hist_flg := 'N'; 
	END IF; -- check if hist flag is set
 END IF; -- End of the IR loop check
END LOOP; -- End of osb_data_cur 

/* Commit the records inserted into the staging table */
COMMIT; 

/* Message to indicate the job completed successfully */
DBMS_OUTPUT.PUT_LINE('Batch Job run successfully for :');
DBMS_OUTPUT.PUT_LINE('Start Date :'||to_date(startdate,'DD-MON-YY'));
DBMS_OUTPUT.PUT_LINE('End Date   :'||to_date(enddate,'DD-MON-YYYY'));
DBMS_OUTPUT.PUT_LINE('Location   :'||loc_id);
DBMS_OUTPUT.PUT_LINE('Number of Repair record(s)  :'||v_updcount);

/* Display error message if generated while batch process runs */
EXCEPTION
  WHEN OTHERS THEN
     DBMS_OUTPUT.PUT_LINE('Following Error Occurred while processing: ');
     DBMS_OUTPUT.PUT_LINE(SQLCODE || SQLERRM);
 
end CRD_CRC_INSERT_TEMP_TABLE_PRC;

PROCEDURE CRD_CRC_EXTRACT_PART_NUMBER
	(errcode out varchar2,
	retcode out number)
AS
	v_EngModel		varchar2(2);
	v_CompCode		varchar2(4);
	v_PartNum		varchar2(20);
 	v_errcode	   	varchar2(1000);
  cursor partcur is
	select T3.ENG_MDL_NUMBER,substr(T1.COMPONENT_CODE,0,4),substr(T2.PART_NUMBER,0,20)
	from
	crd_e_component T1,
	crd_e_part T2,
	crd_crc_module T3
	where
	T2.COMPONENT_CODe = T1.COMPONENT_CODE
	and T2.MODULE_SEQ_ID = T1.MODULE_SEQ_ID
	and T3.MODULE_SEQ_ID = T1.MODULE_SEQ_ID
	and T1.COMPONENT_END_DATE IS NULL;
begin
	OPEN partcur;
		LOOP
		FETCH partcur INTO v_EngModel, v_CompCode, v_PartNum;
		dbms_output.put_line(v_EngModel||''||
			     	     rpad(v_CompCode,4,' ')||''||
			     	     rpad(v_PartNum,20,' '));
		if sql%notfound then
		   v_errcode:=sqlerrm;
		end if;
	EXIT WHEN partcur%NOTFOUND;
			/* After successful completion*/
	 	end loop;
	 CLOSE partcur;
    		if v_errcode<>' ' then
				retcode:=1;
				errcode:=v_errcode;
		else
			retcode:=0;
		end if;
end CRD_CRC_EXTRACT_PART_NUMBER;
END CRD_CRC_BATCH;
/
SHOW ERRORS
/


