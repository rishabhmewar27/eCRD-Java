set heading off;
/*******************************************************************************
**                                                                            **
**  Purpose: To move the Future Price to Current Price procedure Appworx
**  AppWorx Module :                                                          **
**                                                                            **
*******************************************************************************/
/*******************************  CHANGE LOG  **********************************
**                                                                            **
**    Date   Developer            Version         Change Reference            **
** --------  ------------     -----------------  ---------------------        **
**                                                                            **
** 09/26/2002  TCS           1            No Previous Version          **
**                                                                            **
*******************************************************************************/
set linesize 400;
set serveroutput on size 20000;
spool /evnodsp1/apps/crc/out/crc_fut_price_mesg.txt
set term off;    
set feedback off;
whenever sqlerror continue;
set verify off;
declare

  p_errcode    VARCHAR2(20000);
  p_retcode	   NUMBER:=0;
  v_value	   NUMBER;
  program_abend    EXCEPTION;
begin

  	DBMS_OUTPUT.PUT_LINE('CRC Future Price Conversion Process as of :' ||
				to_Char(sysdate,'DD-MON-YYYY HH24:MI:SS AM'));
	DBMS_OUTPUT.PUT_LINE('                                                     ');

	DBMS_OUTPUT.PUT_LINE('                                                     ');

  ecrd_crc_batch.crc_fut_price_change_prc(
    	p_errcode,
	p_retcode);

  
  IF p_retcode = 1 THEN
    RAISE program_abend;
  END IF;

EXCEPTION
  WHEN program_abend THEN
    DBMS_OUTPUT.PUT_LINE('************************************************');
    DBMS_OUTPUT.PUT_LINE('*************** Program Abend ******************');
    DBMS_OUTPUT.PUT_LINE('************************************************');
    DBMS_OUTPUT.PUT_LINE('Return  Code    :   '||TO_CHAR(p_retcode)         );
    DBMS_OUTPUT.PUT_LINE('Date/Time       :   '||to_Char(sysdate,'DD-MON-YYYY HH24:MI:SS AM'));
    DBMS_OUTPUT.PUT_LINE('Error is        :   '||p_errcode);
    DBMS_OUTPUT.PUT_LINE('Normal Error in Processing PL/SQL Contact Sys Adm.');
    DBMS_OUTPUT.PUT_LINE('************************************************');
    DBMS_OUTPUT.PUT_LINE('*************** Program Abend ******************');
    DBMS_OUTPUT.PUT_LINE('************************************************');
    DBMS_OUTPUT.PUT_LINE('exit 1');
end;
/
spool off
