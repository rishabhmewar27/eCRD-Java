# This is process which takes 'crc_fut_price_mesg.txt' file and sends it to mailid which comes from crcmaillist.mail file.

# To delete previous generated files in out folder.

# find /apps/crc/out -ctime +1 -name 'crc_fut_price_mesg*' |xargs -I {} \rm -f {}
# find /apps/crc/out -ctime +1 -name 'o*' |xargs -I {} \rm -f {}
#rm -f ../out/crc_fut*
#sqlplus -s ../sql/crc_fut_price_sql.sql
# Loop to get all mailid

for x in `cat /evnodsp1/apps/crc/bin/crcmaillist.mail`
do
cat  /evnodsp1/apps/crc/out/crc_fut_price_mesg.txt |mailx -s "CRC Future Price Change" $x 
done


