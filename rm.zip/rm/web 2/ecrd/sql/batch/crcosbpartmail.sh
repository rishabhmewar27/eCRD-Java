# This is process which takes 'crc_osb_part_mesg.txt' file and sends it to mailid which comes from crcmaillist.mail file.

mv /evnodsp1/apps/crc/data/CRCPART.lst /evnodsp1/apps/crc/data/CRCPART

for x in `cat /evnodsp1/apps/crc/bin/crcmaillist.mail`
do
cat  /evnodsp1/apps/crc/out/crc_osb_part_mesg.txt |mailx -s "CRC OSB Part Extract" $x 
done


