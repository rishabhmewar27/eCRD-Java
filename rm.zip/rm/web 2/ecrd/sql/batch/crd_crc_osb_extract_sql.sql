set heading off; 
/*******************************************************************************
**                                                                            **
**  Purpose: Extract CRD OSB record(s) for Appworx
**  AppWorx Module :                                                          **
**                                                                            **
*******************************************************************************/
/*******************************  CHANGE LOG  **********************************
**                                                                            **
**    Date   Developer            Version         Change Reference            **
** --------  ------------     -----------------  ---------------------        **
**                                                                            **
** 10/26/2002  Patni	           1            No Previous Version          **
**                                                                            **
*******************************************************************************/
set linesize 629;
SET TERMOUT OFF
SET HEADING OFF
SET FEEDBACK OFF
SET VERIFY OFF
SET TAB OFF
SET TRIMOUT OFF
SET ECHO OFF
SET FLUSH ON
SET PAGESIZE 0
SET NEWPAGE 0
SET SPACE 0
set serveroutput on size 999999;
spool /evnodsp1/apps/crc/out/crc_osb_repair_mesg.txt
whenever sqlerror continue;
declare 

  p_errcode        VARCHAR2(20000);
  p_retcode	   NUMBER:=0;
  program_abend    EXCEPTION;
  
begin

ECRD_CRC_BATCH.CRD_CRC_DEL_TEMP_RECORD(
    	p_errcode,
	p_retcode);  
	DBMS_OUTPUT.PUT_LINE('CRC OSB Extract Repair Record Process as of :' ||to_Char(sysdate,'DD-MON-YYYY HH24:MI:SS AM'));			
ECRD_CRC_BATCH.CRD_CRC_INSERT_RECORD(
    	p_errcode,
	p_retcode);
end;
/	
spool off

spool /evnodsp1/apps/crc/data/CRCREPAIRS.EV
 select 
  rpad(nvl(substr(CATALOG_SEQ_ID,0,9),' '),9,' ')||''||
  rpad(nvl(substr(CONTRACT_NUMBER,0,9),' '),9,' ')||''||
  rpad(nvl(substr(CONTRACT_DESCRIPTION,0,100),' '),100,' ')||''||
  rpad(nvl(substr(AR_ORACLE_USER,0,30),' '),30,' ')||''||
  T1.ENG_MDL_NUMBER||''||
  rpad(nvl(substr(T1.CATALOG_NUMBER,0,25),' '),25,' ')||''||
  rpad(nvl(substr(T1.CATALOG_DESCRIPTION,0,50),' '),50,' ')||''||
  rpad(NVL(to_char(T1.CATALOG_EFFECTIVE_DATE,'dd-mon-yyyy'),' '),11,' ')||''||
  rpad(NVL(to_char(T1.CATALOG_END_DATE,'dd-mon-yyyy'),' '),11,' ')||''||
  rpad(NVL(T1.COMPONENT_CODE,' '),4,' ')||''||
  rpad(NVL(T1.COMPONENT_DOC_REF,' '),20,' ')||''||
  rpad(NVL(to_char(T1.BASELINE_TAT),' '),5,' ')||''||
  rpad(NVL(to_char(T1.WRKSCP_DISP_SEQ_ID),' '),3,' ')||''||
  rpad(NVL(to_char(T1.PRICE_EFFECTIVE_DATE,'dd-mon-yyyy'),' '),11,' ')||''||
  rpad(NVL(T1.OSB_UNIQUE_NUMBER,' '),15,' ')||''||
  rpad(NVL(to_char(T1.RPR_END_DATE,'dd-mon-yyyy'),' '),11,' ')||''||
  rpad(NVL(to_char(T1.TAT_INCREMENT_IND),' '),1,' ')||''||
  rpad(NVL(to_char(T1.RPR_TAT),' '),5,' ')||''||
  rpad(NVL(T1.PRICE_INCREMENT_IND,' '),1,' ')||''||
  rpad(NVL(to_char(T1.RPR_PRICE),' '),14,' ')||''||
  rpad(NVL(T1.PRICE_QUOTE_IND,' '),1,' ')||''|| 
  rpad(NVL(to_char(T1.RPR_DISP_SEQ_ID),' '),3,' ')||''|| 
  rpad(NVL(T1.RPR_DOC_REF,' '),15,' ')||''||
  rpad(NVL(T1.RPR_REF_SNUM,' '),8,' ')||''||
  rpad(NVL(substr(T1.RPR_DESC,0,255),' '),255,' ')||''||
  rpad(NVL(substr(T1.REPAIR_SEQ_ID,0,9),' '),9,' ')||''||
  'N'
--  rpad(NVL(T2.JOB_INDICATOR,' '),1,' ')||''||
--  rpad(NVL(to_char(T2.JOB_START_DATE,'dd-mon-yyyy'),' '),11,' ')||''||
--  rpad(to_char(T2.JOB_END_DATE,'dd-mon-yyyy'),11,' ')
  from  CRD_E_OSB_REPAIR_STG T1,
	CRD_E_OSB_JOBS    T2
where T1.LOCATION_ID='EV'
and T2.LOCATION_ID=T1.LOCATION_ID
  order by OSB_INFC_RPR_SEQ_ID;

spool /evnodsp1/apps/crc/data/CRCREPAIRS.JA
  select 
   rpad(nvl(substr(CATALOG_SEQ_ID,0,9),' '),9,' ')||''||
   rpad(nvl(substr(CONTRACT_NUMBER,0,9),' '),9,' ')||''||
   rpad(nvl(substr(CONTRACT_DESCRIPTION,0,100),' '),100,' ')||''||
   rpad(nvl(substr(AR_ORACLE_USER,0,30),' '),30,' ')||''||
   T1.ENG_MDL_NUMBER||''||
   rpad(nvl(substr(T1.CATALOG_NUMBER,0,25),' '),25,' ')||''||
   rpad(nvl(substr(T1.CATALOG_DESCRIPTION,0,50),' '),50,' ')||''||
   rpad(NVL(to_char(T1.CATALOG_EFFECTIVE_DATE,'dd-mon-yyyy'),' '),11,' ')||''||
   rpad(NVL(to_char(T1.CATALOG_END_DATE,'dd-mon-yyyy'),' '),11,' ')||''||
   rpad(NVL(T1.COMPONENT_CODE,' '),4,' ')||''||
   rpad(NVL(T1.COMPONENT_DOC_REF,' '),20,' ')||''||
   rpad(NVL(to_char(T1.BASELINE_TAT),' '),5,' ')||''||
   rpad(NVL(to_char(T1.WRKSCP_DISP_SEQ_ID),' '),3,' ')||''||
   rpad(NVL(to_char(T1.PRICE_EFFECTIVE_DATE,'dd-mon-yyyy'),' '),11,' ')||''||
   rpad(NVL(T1.OSB_UNIQUE_NUMBER,' '),15,' ')||''||
   rpad(NVL(to_char(T1.RPR_END_DATE,'dd-mon-yyyy'),' '),11,' ')||''||
   rpad(NVL(to_char(T1.TAT_INCREMENT_IND),' '),1,' ')||''||
   rpad(NVL(to_char(T1.RPR_TAT),' '),5,' ')||''||
   rpad(NVL(T1.PRICE_INCREMENT_IND,' '),1,' ')||''||
   rpad(NVL(to_char(T1.RPR_PRICE),' '),14,' ')||''||
   rpad(NVL(T1.PRICE_QUOTE_IND,' '),1,' ')||''|| 
   rpad(NVL(to_char(T1.RPR_DISP_SEQ_ID),' '),3,' ')||''|| 
   rpad(NVL(T1.RPR_DOC_REF,' '),15,' ')||''||
   rpad(NVL(T1.RPR_REF_SNUM,' '),8,' ')||''||
   rpad(NVL(substr(T1.RPR_DESC,0,255),' '),255,' ')||''||
   rpad(NVL(substr(T1.REPAIR_SEQ_ID,0,9),' '),9,' ')||''||
  'N'
--   rpad(NVL(T2.JOB_INDICATOR,' '),1,' ')||''||
--   rpad(NVL(to_char(T2.JOB_START_DATE,'dd-mon-yyyy'),' '),11,' ')||''||
--   rpad(to_char(T2.JOB_END_DATE,'dd-mon-yyyy'),11,' ')
   from  CRD_E_OSB_REPAIR_STG T1,
	CRD_E_OSB_JOBS    T2
where T1.LOCATION_ID='JA'
and T2.LOCATION_ID=T1.LOCATION_ID
  order by OSB_INFC_RPR_SEQ_ID;

spool /evnodsp1/apps/crc/data/CRCREPAIRS.SO
 select 
  rpad(nvl(substr(CATALOG_SEQ_ID,0,9),' '),9,' ')||''||
  rpad(nvl(substr(CONTRACT_NUMBER,0,9),' '),9,' ')||''||
  rpad(nvl(substr(CONTRACT_DESCRIPTION,0,100),' '),100,' ')||''||
  rpad(nvl(substr(AR_ORACLE_USER,0,30),' '),30,' ')||''||
  T1.ENG_MDL_NUMBER||''||
  rpad(nvl(substr(T1.CATALOG_NUMBER,0,25),' '),25,' ')||''||
  rpad(nvl(substr(T1.CATALOG_DESCRIPTION,0,50),' '),50,' ')||''||
  rpad(NVL(to_char(T1.CATALOG_EFFECTIVE_DATE,'dd-mon-yyyy'),' '),11,' ')||''||
  rpad(NVL(to_char(T1.CATALOG_END_DATE,'dd-mon-yyyy'),' '),11,' ')||''||
  rpad(NVL(T1.COMPONENT_CODE,' '),4,' ')||''||
  rpad(NVL(T1.COMPONENT_DOC_REF,' '),20,' ')||''||
  rpad(NVL(to_char(T1.BASELINE_TAT),' '),5,' ')||''||
  rpad(NVL(to_char(T1.WRKSCP_DISP_SEQ_ID),' '),3,' ')||''||
  rpad(NVL(to_char(T1.PRICE_EFFECTIVE_DATE,'dd-mon-yyyy'),' '),11,' ')||''||
  rpad(NVL(T1.OSB_UNIQUE_NUMBER,' '),15,' ')||''||
  rpad(NVL(to_char(T1.RPR_END_DATE,'dd-mon-yyyy'),' '),11,' ')||''||
  rpad(NVL(to_char(T1.TAT_INCREMENT_IND),' '),1,' ')||''||
  rpad(NVL(to_char(T1.RPR_TAT),' '),5,' ')||''||
  rpad(NVL(T1.PRICE_INCREMENT_IND,' '),1,' ')||''||
  rpad(NVL(to_char(T1.RPR_PRICE),' '),14,' ')||''||
  rpad(NVL(T1.PRICE_QUOTE_IND,' '),1,' ')||''|| 
  rpad(NVL(to_char(T1.RPR_DISP_SEQ_ID),' '),3,' ')||''|| 
  rpad(NVL(T1.RPR_DOC_REF,' '),15,' ')||''||
  rpad(NVL(T1.RPR_REF_SNUM,' '),8,' ')||''||
  rpad(NVL(substr(T1.RPR_DESC,0,255),' '),255,' ')||''||
  rpad(NVL(substr(T1.REPAIR_SEQ_ID,0,9),' '),9,' ')||''||
  'N'
--  rpad(NVL(T2.JOB_INDICATOR,' '),1,' ')||''||
--  rpad(NVL(to_char(T2.JOB_START_DATE,'dd-mon-yyyy'),' '),11,' ')||''||
--  rpad(to_char(T2.JOB_END_DATE,'dd-mon-yyyy'),11,' ')
  from  CRD_E_OSB_REPAIR_STG T1,
	CRD_E_OSB_JOBS    T2
where T1.LOCATION_ID='SI'
and T2.LOCATION_ID=T1.LOCATION_ID
  order by OSB_INFC_RPR_SEQ_ID;

spool /evnodsp1/apps/crc/data/CRCREPAIRS.HG
 select 
  rpad(nvl(substr(CATALOG_SEQ_ID,0,9),' '),9,' ')||''||
  rpad(nvl(substr(CONTRACT_NUMBER,0,9),' '),9,' ')||''||
  rpad(nvl(substr(CONTRACT_DESCRIPTION,0,100),' '),100,' ')||''||
  rpad(nvl(substr(AR_ORACLE_USER,0,30),' '),30,' ')||''||
  T1.ENG_MDL_NUMBER||''||
  rpad(nvl(substr(T1.CATALOG_NUMBER,0,25),' '),25,' ')||''||
  rpad(nvl(substr(T1.CATALOG_DESCRIPTION,0,50),' '),50,' ')||''||
  rpad(NVL(to_char(T1.CATALOG_EFFECTIVE_DATE,'dd-mon-yyyy'),' '),11,' ')||''||
  rpad(NVL(to_char(T1.CATALOG_END_DATE,'dd-mon-yyyy'),' '),11,' ')||''||
  rpad(NVL(T1.COMPONENT_CODE,' '),4,' ')||''||
  rpad(NVL(T1.COMPONENT_DOC_REF,' '),20,' ')||''||
  rpad(NVL(to_char(T1.BASELINE_TAT),' '),5,' ')||''||
  rpad(NVL(to_char(T1.WRKSCP_DISP_SEQ_ID),' '),3,' ')||''||
  rpad(NVL(to_char(T1.PRICE_EFFECTIVE_DATE,'dd-mon-yyyy'),' '),11,' ')||''||
  rpad(NVL(T1.OSB_UNIQUE_NUMBER,' '),15,' ')||''||
  rpad(NVL(to_char(T1.RPR_END_DATE,'dd-mon-yyyy'),' '),11,' ')||''||
  rpad(NVL(to_char(T1.TAT_INCREMENT_IND),' '),1,' ')||''||
  rpad(NVL(to_char(T1.RPR_TAT),' '),5,' ')||''||
  rpad(NVL(T1.PRICE_INCREMENT_IND,' '),1,' ')||''||
  rpad(NVL(to_char(T1.RPR_PRICE),' '),14,' ')||''||
  rpad(NVL(T1.PRICE_QUOTE_IND,' '),1,' ')||''|| 
  rpad(NVL(to_char(T1.RPR_DISP_SEQ_ID),' '),3,' ')||''|| 
  rpad(NVL(T1.RPR_DOC_REF,' '),15,' ')||''||
  rpad(NVL(T1.RPR_REF_SNUM,' '),8,' ')||''||
  rpad(NVL(substr(T1.RPR_DESC,0,255),' '),255,' ')||''||
  rpad(NVL(substr(T1.REPAIR_SEQ_ID,0,9),' '),9,' ')||''||
  'N'
--  rpad(NVL(T2.JOB_INDICATOR,' '),1,' ')||''||
--  rpad(NVL(to_char(T2.JOB_START_DATE,'dd-mon-yyyy'),' '),11,' ')||''||
--  rpad(to_char(T2.JOB_END_DATE,'dd-mon-yyyy'),11,' ')
  from  CRD_E_OSB_REPAIR_STG T1,
	CRD_E_OSB_JOBS    T2
where T1.LOCATION_ID='HG'
and T2.LOCATION_ID=T1.LOCATION_ID
  order by OSB_INFC_RPR_SEQ_ID;

spool /evnodsp1/apps/crc/data/CRCREPAIRS.MC
  select 
   rpad(nvl(substr(CATALOG_SEQ_ID,0,9),' '),9,' ')||''||
   rpad(nvl(substr(CONTRACT_NUMBER,0,9),' '),9,' ')||''||
   rpad(nvl(substr(CONTRACT_DESCRIPTION,0,100),' '),100,' ')||''||
   rpad(nvl(substr(AR_ORACLE_USER,0,30),' '),30,' ')||''||
   T1.ENG_MDL_NUMBER||''||
   rpad(nvl(substr(T1.CATALOG_NUMBER,0,25),' '),25,' ')||''||
   rpad(nvl(substr(T1.CATALOG_DESCRIPTION,0,50),' '),50,' ')||''||
   rpad(NVL(to_char(T1.CATALOG_EFFECTIVE_DATE,'dd-mon-yyyy'),' '),11,' ')||''||
   rpad(NVL(to_char(T1.CATALOG_END_DATE,'dd-mon-yyyy'),' '),11,' ')||''||
   rpad(NVL(T1.COMPONENT_CODE,' '),4,' ')||''||
   rpad(NVL(T1.COMPONENT_DOC_REF,' '),20,' ')||''||
   rpad(NVL(to_char(T1.BASELINE_TAT),' '),5,' ')||''||
   rpad(NVL(to_char(T1.WRKSCP_DISP_SEQ_ID),' '),3,' ')||''||
   rpad(NVL(to_char(T1.PRICE_EFFECTIVE_DATE,'dd-mon-yyyy'),' '),11,' ')||''||
   rpad(NVL(T1.OSB_UNIQUE_NUMBER,' '),15,' ')||''||
   rpad(NVL(to_char(T1.RPR_END_DATE,'dd-mon-yyyy'),' '),11,' ')||''||
   rpad(NVL(to_char(T1.TAT_INCREMENT_IND),' '),1,' ')||''||
   rpad(NVL(to_char(T1.RPR_TAT),' '),5,' ')||''||
   rpad(NVL(T1.PRICE_INCREMENT_IND,' '),1,' ')||''||
   rpad(NVL(to_char(T1.RPR_PRICE),' '),14,' ')||''||
   rpad(NVL(T1.PRICE_QUOTE_IND,' '),1,' ')||''|| 
   rpad(NVL(to_char(T1.RPR_DISP_SEQ_ID),' '),3,' ')||''|| 
   rpad(NVL(T1.RPR_DOC_REF,' '),15,' ')||''||
   rpad(NVL(T1.RPR_REF_SNUM,' '),8,' ')||''||
   rpad(NVL(substr(T1.RPR_DESC,0,255),' '),255,' ')||''||
   rpad(NVL(substr(T1.REPAIR_SEQ_ID,0,9),' '),9,' ')||''||
  'N'
   --rpad(NVL(T2.JOB_INDICATOR,' '),1,' ')||''||
   --rpad(NVL(to_char(T2.JOB_START_DATE,'dd-mon-yyyy'),' '),11,' ')||''||
   --rpad(to_char(T2.JOB_END_DATE,'dd-mon-yyyy'),11,' ')
   from  CRD_E_OSB_REPAIR_STG T1,
	CRD_E_OSB_JOBS    T2
where T1.LOCATION_ID='MC'
and T2.LOCATION_ID=T1.LOCATION_ID
  order by OSB_INFC_RPR_SEQ_ID;
  
spool /evnodsp1/apps/crc/data/CRCREPAIRS.ST
  select 
   rpad(nvl(substr(CATALOG_SEQ_ID,0,9),' '),9,' ')||''||
   rpad(nvl(substr(CONTRACT_NUMBER,0,9),' '),9,' ')||''||
   rpad(nvl(substr(CONTRACT_DESCRIPTION,0,100),' '),100,' ')||''||
   rpad(nvl(substr(AR_ORACLE_USER,0,30),' '),30,' ')||''||
   T1.ENG_MDL_NUMBER||''||
   rpad(nvl(substr(T1.CATALOG_NUMBER,0,25),' '),25,' ')||''||
   rpad(nvl(substr(T1.CATALOG_DESCRIPTION,0,50),' '),50,' ')||''||
   rpad(NVL(to_char(T1.CATALOG_EFFECTIVE_DATE,'dd-mon-yyyy'),' '),11,' ')||''||
   rpad(NVL(to_char(T1.CATALOG_END_DATE,'dd-mon-yyyy'),' '),11,' ')||''||
   rpad(NVL(T1.COMPONENT_CODE,' '),4,' ')||''||
   rpad(NVL(T1.COMPONENT_DOC_REF,' '),20,' ')||''||
   rpad(NVL(to_char(T1.BASELINE_TAT),' '),5,' ')||''||
   rpad(NVL(to_char(T1.WRKSCP_DISP_SEQ_ID),' '),3,' ')||''||
   rpad(NVL(to_char(T1.PRICE_EFFECTIVE_DATE,'dd-mon-yyyy'),' '),11,' ')||''||
   rpad(NVL(T1.OSB_UNIQUE_NUMBER,' '),15,' ')||''||
   rpad(NVL(to_char(T1.RPR_END_DATE,'dd-mon-yyyy'),' '),11,' ')||''||
   rpad(NVL(to_char(T1.TAT_INCREMENT_IND),' '),1,' ')||''||
   rpad(NVL(to_char(T1.RPR_TAT),' '),5,' ')||''||
   rpad(NVL(T1.PRICE_INCREMENT_IND,' '),1,' ')||''||
   rpad(NVL(to_char(T1.RPR_PRICE),' '),14,' ')||''||
   rpad(NVL(T1.PRICE_QUOTE_IND,' '),1,' ')||''|| 
   rpad(NVL(to_char(T1.RPR_DISP_SEQ_ID),' '),3,' ')||''|| 
   rpad(NVL(T1.RPR_DOC_REF,' '),15,' ')||''||
   rpad(NVL(T1.RPR_REF_SNUM,' '),8,' ')||''||
   rpad(NVL(substr(T1.RPR_DESC,0,255),' '),255,' ')||''||
   rpad(NVL(substr(T1.REPAIR_SEQ_ID,0,9),' '),9,' ')||''||
  'N'
   --rpad(NVL(T2.JOB_INDICATOR,' '),1,' ')||''||
   --rpad(NVL(to_char(T2.JOB_START_DATE,'dd-mon-yyyy'),' '),11,' ')||''||
   --rpad(to_char(T2.JOB_END_DATE,'dd-mon-yyyy'),11,' ')
   from  CRD_E_OSB_REPAIR_STG T1,
	CRD_E_OSB_JOBS    T2
where T1.LOCATION_ID='KS'
and T2.LOCATION_ID=T1.LOCATION_ID
  order by OSB_INFC_RPR_SEQ_ID;
  
  
	
declare

  p_errcode        VARCHAR2(20000);
  p_retcode	   NUMBER:=0;
  program_abend    EXCEPTION;
begin
  IF p_retcode = 1 THEN
    RAISE program_abend;
  END IF;

EXCEPTION
  WHEN program_abend THEN
    DBMS_OUTPUT.PUT_LINE('************************************************');
    DBMS_OUTPUT.PUT_LINE('*************** Program Abend ******************');
    DBMS_OUTPUT.PUT_LINE('************************************************');
    DBMS_OUTPUT.PUT_LINE('Return  Code    :   '||TO_CHAR(p_retcode)         );
    DBMS_OUTPUT.PUT_LINE('Date/Time       :   '||TO_CHAR(SYSDATE,'HH24:MI:SS'));
    DBMS_OUTPUT.PUT_LINE('Error is        :   '||p_errcode);
    DBMS_OUTPUT.PUT_LINE('Normal Error in Processing PL/SQL Contact Sys Adm.');
    DBMS_OUTPUT.PUT_LINE('************************************************');
    DBMS_OUTPUT.PUT_LINE('*************** Program Abend ******************');
    DBMS_OUTPUT.PUT_LINE('************************************************');
    DBMS_OUTPUT.PUT_LINE('exit 1');
end;
/
spool off
SET FEEDBACK 6
SET HEADING ON
SET ECHO ON
SET EMBEDDED OFF
SET TERMOUT ON
