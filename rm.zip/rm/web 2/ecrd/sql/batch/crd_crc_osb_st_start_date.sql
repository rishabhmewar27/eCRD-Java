set heading off;
/*******************************************************************************
**                                                                            **
**  Purpose: Extract CRD OSB record(s) for Appworx
**  AppWorx Module :                                                          **
**                                                                            **
*******************************************************************************/
/*******************************  CHANGE LOG  **********************************
**                                                                            **
**    Date   Developer            Version         Change Reference            **
** --------  ------------     -----------------  ---------------------        **
**                                                                            **
** 10/26/2002  TCS	           1            No Previous Version          **
**                                                                            **
*******************************************************************************/
set linesize 4;
set term off;    
set feedback off;
set serveroutput on size 20000;
whenever sqlerror continue;
set verify off;
declare

  p_errcode        VARCHAR2(20000);
  p_retcode	   NUMBER:=0;
  program_abend    EXCEPTION;
  p_locId	   VARCHAR2(20000);
  
begin
p_locId:='KS';
ECRD_CRC_BATCH.CRD_CRC_UPDATE_START_DATE(
	p_locId,
    	p_errcode,
	p_retcode);
	
  IF p_retcode = 1 THEN
    RAISE program_abend;
  END IF;

EXCEPTION
  WHEN program_abend THEN
    DBMS_OUTPUT.PUT_LINE('************************************************');
    DBMS_OUTPUT.PUT_LINE('*************** Program Abend ******************');
    DBMS_OUTPUT.PUT_LINE('************************************************');
    DBMS_OUTPUT.PUT_LINE('Return  Code    :   '||TO_CHAR(p_retcode)         );
    DBMS_OUTPUT.PUT_LINE('Date/Time       :   '||TO_CHAR(SYSDATE,'HH24:MI:SS'));
    DBMS_OUTPUT.PUT_LINE('Error is        :   '||p_errcode);
    DBMS_OUTPUT.PUT_LINE('Normal Error in Processing PL/SQL Contact Sys Adm.');
    DBMS_OUTPUT.PUT_LINE('************************************************');
    DBMS_OUTPUT.PUT_LINE('*************** Program Abend ******************');
    DBMS_OUTPUT.PUT_LINE('************************************************');
    DBMS_OUTPUT.PUT_LINE('exit 1');
end;
/
spool off
