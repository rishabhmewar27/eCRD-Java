/*******************************************************************************
**                                                                            **
**  Purpose: Extract part record(s) for Appworx
**  AppWorx Module :                                                          **
**                                                                            **
*******************************************************************************/
/*******************************  CHANGE LOG  **********************************
**                                                                            **
**    Date   Developer            Version         Change Reference            **
** --------  ------------     -----------------  ---------------------        **
**                                                                            **
** 10/26/2004  Patni	           1             No Previous Version          **
**                                                                            **
*******************************************************************************/
set linesize 26;
set term off;    
set heading off; 
set feedback off;
set serveroutput on size 999999;
whenever sqlerror continue;
spool /evnodsp1/apps/crc/data/CRCPART 
set verify off;
declare

  p_errcode        VARCHAR2(2000);
  p_retcode	   NUMBER:=0;
  v_value	   NUMBER;
  program_abend  EXCEPTION;
begin
  ECRD_CRC_BATCH.CRD_CRC_EXTRACT_PART_NUMBER(
    	p_errcode,
	p_retcode);
  
  IF p_retcode = 1 THEN
    RAISE program_abend;
  END IF;
  end;
/
set linesize 100;
spool /evnodsp1/apps/crc/out/crc_osb_part_mesg.txt
  	select 'CRC OSB Part Extract Process as of :' ||
		to_Char(sysdate,'DD-MON-YYYY HH24:MI:SS AM') from dual;
  	select 'Number of Part Record(s) in the flat file : '||''||
	count(T2.PART_NUMBER)
	from
	crd_e_component T1,
	crd_e_part T2,
	crd_crc_module T3
	where
	T2.COMPONENT_CODe = T1.COMPONENT_CODE
	and T2.MODULE_SEQ_ID = T1.MODULE_SEQ_ID
	and T3.MODULE_SEQ_ID = T1.MODULE_SEQ_ID
	and T1.COMPONENT_END_DATE IS NULL;

declare

  p_errcode        VARCHAR2(20000);
  p_retcode	   NUMBER:=0;
  program_abend    EXCEPTION;
begin
  IF p_retcode = 1 THEN
    RAISE program_abend;
  END IF;

EXCEPTION
  WHEN program_abend THEN
    DBMS_OUTPUT.PUT_LINE('************************************************');
    DBMS_OUTPUT.PUT_LINE('*************** Program Abend ******************');
    DBMS_OUTPUT.PUT_LINE('************************************************');
    DBMS_OUTPUT.PUT_LINE('Return  Code    :   '||TO_CHAR(p_retcode)         );
    DBMS_OUTPUT.PUT_LINE('Date/Time       :   '||TO_CHAR(SYSDATE,'HH24:MI:SS'));
    DBMS_OUTPUT.PUT_LINE('Error is        :   '||p_errcode);
    DBMS_OUTPUT.PUT_LINE('Normal Error in Processing PL/SQL Contact Sys Adm.');
    DBMS_OUTPUT.PUT_LINE('************************************************');
    DBMS_OUTPUT.PUT_LINE('*************** Program Abend ******************');
    DBMS_OUTPUT.PUT_LINE('************************************************');
    DBMS_OUTPUT.PUT_LINE('exit 1');
end;
/
spool off

