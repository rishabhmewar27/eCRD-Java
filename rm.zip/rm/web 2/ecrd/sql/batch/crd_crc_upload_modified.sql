/*****************************************************************************
  Application Name     : e Component Repair Detail (eCRD)
  Subsystem            : Component Repair Catalog
  Package Name         : CRD_CRC_UPLOAD
  Purpose              : Contains procedures for Uploading of data obtained 
  								 through excel file.
  Author               : PATNI
  Date (DD-MON-YYYY)   : Nov-2004
  Revision History     :
  Version  Date         Author           Description
  -------  -----------  ---------------  -------------------------------------
  1.0.0    04-Nov-2004  PATNI      		 First version.
******************************************************************************/
CREATE OR REPLACE package CRD_CRC_UPLOAD
IS
PROCEDURE CRD_CRC_UPLOAD_DATA(
as_engine_code	IN 	VARCHAR2,
as_module_desc	IN 	VARCHAR2,
as_site_name	IN		VARCHAR2,
as_user_id 		IN 	VARCHAR2,
as_catalog_id	IN VARCHAR2,
as_data1_in		IN 	LONG,
as_data2_in		IN 	LONG,
as_data3_in		IN 	LONG,
as_data4_in		IN 	LONG,
as_data5_in		IN 	LONG,
as_data6_in		IN 	LONG,
as_data7_in		IN 	LONG,
as_data8_in		IN 	LONG,
as_data9_in		IN 	LONG,
as_data10_in		IN 	LONG,
as_data1_out		OUT 	VARCHAR2,
as_data2_out		OUT 	VARCHAR2,
as_data3_out		OUT 	VARCHAR2,
as_data4_out		OUT 	VARCHAR2,
as_data5_out		OUT 	VARCHAR2,
as_data6_out		OUT 	VARCHAR2,
as_data7_out		OUT 	VARCHAR2,
as_data8_out		OUT 	VARCHAR2,
as_data9_out		OUT 	VARCHAR2,
as_data10_out		OUT 	VARCHAR2,
as_data11_out		OUT 	VARCHAR2,
as_data12_out		OUT 	VARCHAR2,
as_data13_out		OUT 	VARCHAR2,
as_data14_out		OUT 	VARCHAR2,
as_data15_out		OUT 	VARCHAR2
);

TYPE input_array IS VARRAY(4000) OF VARCHAR2(32767) ;

END CRD_CRC_UPLOAD;
/

CREATE OR REPLACE package body CRD_CRC_UPLOAD
IS
PROCEDURE CRD_CRC_UPLOAD_DATA(
as_engine_code	IN 	VARCHAR2,
as_module_desc	IN 	VARCHAR2,
as_site_name	IN		VARCHAR2,
as_user_id 		IN 	VARCHAR2,
as_catalog_id	IN VARCHAR2,
as_data1_in		IN 	LONG,
as_data2_in		IN 	LONG,
as_data3_in		IN 	LONG,
as_data4_in		IN 	LONG,
as_data5_in		IN 	LONG,
as_data6_in		IN 	LONG,
as_data7_in		IN 	LONG,
as_data8_in		IN 	LONG,
as_data9_in		IN 	LONG,
as_data10_in		IN 	LONG,
as_data1_out		OUT 	VARCHAR2,
as_data2_out		OUT 	VARCHAR2,
as_data3_out		OUT 	VARCHAR2,
as_data4_out		OUT 	VARCHAR2,
as_data5_out		OUT 	VARCHAR2,
as_data6_out		OUT 	VARCHAR2,
as_data7_out		OUT 	VARCHAR2,
as_data8_out		OUT 	VARCHAR2,
as_data9_out		OUT 	VARCHAR2,
as_data10_out		OUT 	VARCHAR2,
as_data11_out		OUT 	VARCHAR2,
as_data12_out		OUT 	VARCHAR2,
as_data13_out		OUT 	VARCHAR2,
as_data14_out		OUT 	VARCHAR2,
as_data15_out		OUT 	VARCHAR2
)
AS
ls_mod_seq_id	CRD_E_COMPONENT.MODULE_SEQ_ID%TYPE;
ls_rem_data		LONG;
ls_row_comp		LONG;
lb_not_eof		BOOLEAN;
ls_row_no		VARCHAR2(50);
ls_comp_code CRD_E_COMPONENT.COMPONENT_CODE%TYPE;
ls_comp_desc CRD_E_COMPONENT.COMPONENT_DESCRIPTION%TYPE;
ls_comp_doc_ref CRD_E_COMPONENT.ATA_REFERENCE_SNUM%TYPE;
ls_rep_desc CRD_E_REPAIR.REPAIR_DESCRIPTION%TYPE;
ls_rep_ref	CRD_E_REPAIR.REPAIR_REFERENCE_FORMAT%TYPE;
ls_rep_TAT VARCHAR2(500);
ls_rep_Future_TAT	VARCHAR2(500);
ls_rep_price VARCHAR2(500);
ls_rep_Future_price VARCHAR2(500);
ls_rep_price_inc_ind CRD_E_REPAIR_CATALOG.INCREMENTAL_PRICE_IND%TYPE;
ls_rep_TAT_inc_ind CRD_E_REPAIR_CATALOG.INCREMENTAL_TAT_IND%TYPE;
ln_rep_seq_id	CRD_E_REPAIR.REPAIR_SEQ_ID%TYPE;
ln_price_type_id CRD_E_REPAIR_CATALOG.PRICE_TYPE%TYPE;
ln_labor_cost	LONG;
ln_material_cost	LONG;
ls_future_date	VARCHAR2(20);
ln_temp NUMBER;
p_location_id  crd_location.location_id%TYPE;
v_v_eng_mod_cd CRD_CRC_ENG_MDL_DISPLAY.ENG_MDL_NUMBER%TYPE;

in_data input_array;

PROCEDURE populate_in_data
AS
BEGIN
	in_data(1) := as_data1_in;
	in_data.EXTEND(1);
	in_data(2) := as_data2_in;
	in_data.EXTEND(1);
	in_data(3) := as_data3_in;
	in_data.EXTEND(1);
	in_data(4) := as_data4_in;
	in_data.EXTEND(1);
	in_data(5) := as_data5_in;
	in_data.EXTEND(1);
	in_data(6) := as_data6_in;
	in_data.EXTEND(1);
	in_data(7) := as_data7_in;
	in_data.EXTEND(1);
	in_data(8) := as_data8_in;
	in_data.EXTEND(1);
	in_data(9) := as_data9_in;	
	in_data.EXTEND(1);
	in_data(10) := as_data10_in;
END populate_in_data;

FUNCTION return_string(aInStr IN LONG,separator IN VARCHAR2,mode_type IN VARCHAR2)
RETURN LONG
IS
	p_outStr LONG;
BEGIN
	IF (mode_type = 'BEF') THEN
		p_outStr := SUBSTR(aInStr, 1, INSTR(aInStr, separator) - 1) ;
	ELSIF (mode_type = 'AFT') THEN
		p_outStr := SUBSTR(aInStr, INSTR(aInStr, separator) + 1) ;	
	END IF;

	return p_outStr;
END return_string;

PROCEDURE add_error(aErrMsg IN VARCHAR2)
IS
BEGIN
	IF (LENGTH(NVL(as_data1_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
		as_data1_out := as_data1_out || aErrMsg;
	ELSIF (LENGTH(NVL(as_data2_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
		as_data2_out := as_data2_out || aErrMsg;
	ELSIF (LENGTH(NVL(as_data3_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
		as_data3_out := as_data3_out || aErrMsg;
	ELSIF (LENGTH(NVL(as_data4_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
		as_data4_out := as_data4_out || aErrMsg;
	ELSIF (LENGTH(NVL(as_data5_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
		as_data5_out := as_data5_out || aErrMsg;
	ELSIF (LENGTH(NVL(as_data6_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
		as_data6_out := as_data6_out || aErrMsg;
	ELSIF (LENGTH(NVL(as_data7_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
		as_data7_out := as_data7_out || aErrMsg;
	ELSIF (LENGTH(NVL(as_data8_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
		as_data8_out := as_data8_out || aErrMsg;
	ELSIF (LENGTH(NVL(as_data9_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
		as_data9_out := as_data9_out || aErrMsg;
	ELSIF (LENGTH(NVL(as_data10_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
		as_data10_out := as_data10_out || aErrMsg;
	ELSIF (LENGTH(NVL(as_data11_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
		as_data11_out := as_data11_out || aErrMsg;
	ELSIF (LENGTH(NVL(as_data12_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
		as_data12_out := as_data12_out || aErrMsg;
	ELSIF (LENGTH(NVL(as_data13_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
		as_data13_out := as_data13_out || aErrMsg;
	ELSIF (LENGTH(NVL(as_data14_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
		as_data14_out := as_data14_out || aErrMsg;
	ELSIF (LENGTH(NVL(as_data15_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
		as_data15_out := as_data15_out || aErrMsg;
	END IF;
END add_error;

FUNCTION validate_component(aCompCode IN LONG,aRowNum IN VARCHAR2)
RETURN NUMBER
IS
	p_count NUMBER;
BEGIN
	SELECT COUNT(1)
	INTO p_count 
	FROM CRD_E_COMPONENT
	WHERE Component_Code = TRIM(aCompCode) 
	AND Module_Seq_id = ls_mod_seq_id;
		
	IF (p_count = 1) 
	THEN
		RETURN 1;
	ELSE
		add_error('Error in Row Number '|| aRowNum || ' Component Code ' || aCompCode || ' does not exist^');
		RETURN 0;
	END IF;
END validate_component;

FUNCTION validate_repair(aCompCode IN VARCHAR2,aRepDesc IN LONG,aRowNum IN VARCHAR2)
RETURN NUMBER
IS
	p_rep_seq_id NUMBER(9);
	p_count NUMBER;
BEGIN
	SELECT COUNT(1) 
	INTO p_count 
	FROM CRD_E_REPAIR 
	WHERE TRIM(UPPER(Repair_Description)) = TRIM(UPPER(aRepDesc))
	AND Component_Code = aCompCode 
	AND EXISTS (SELECT 1 
			    FROM CRD_E_COMPONENT 
			    WHERE Component_Code = aCompCode 
			    AND Module_Seq_id = ls_mod_seq_id);

	IF (p_count = 1) 
	THEN
		SELECT repair_seq_id 
		INTO p_rep_seq_id 
		FROM CRD_E_REPAIR 
		WHERE TRIM(UPPER(Repair_Description)) = TRIM(UPPER(aRepDesc))
		AND Component_Code = aCompCode 
		AND EXISTS (SELECT 1 
					FROM CRD_E_COMPONENT 
					WHERE Component_Code = aCompCode 
					AND Module_Seq_id = ls_mod_seq_id);
		
		RETURN p_rep_seq_id;
	ELSE
		IF (p_count = 0)
		THEN
			add_error('Error in Row Number '|| aRowNum || ' Repair ' || aRepDesc || ' does not exist^');
		ELSE
			add_error('Error in Row Number '|| aRowNum || ' Repair ' || aRepDesc || ' has too Many Matches^');
		END IF;
		RETURN 0;
	END IF;
END validate_repair;

/*
Begin of main proc
*/
BEGIN
	BEGIN
	
		SELECT eng_mdl_number 
		INTO v_v_eng_mod_cd
		FROM CRD_CRC_ENG_MDL_DISPLAY
		WHERE TRIM(UPPER(eng_mdl_desc)) = TRIM(UPPER(as_engine_code));
	EXCEPTION
		WHEN NO_DATA_FOUND
		THEN
		    v_v_eng_mod_cd :=NULL;
		    add_error('Engine Model '||as_engine_code||' Not Found^');
	END;	
	
/*	BEGIN
		SELECT location_id 
		INTO p_location_id
		FROM CRD_LOCATION
		WHERE TRIM(UPPER(location_desc)) =TRIM(UPPER( as_site_name));		
	EXCEPTION
		WHEN NO_DATA_FOUND
		THEN
		    p_location_id :=NULL;
	    	    add_error('Site name : ' || as_site_name||' Not Found ^');
	END;    	    */

IF (v_v_eng_mod_cd IS NOT NULL)
	THEN
		BEGIN	
			SELECT module_seq_id 
			INTO ls_mod_seq_id
			FROM CRD_CRC_MODULE
			WHERE TRIM(UPPER(module_name))= TRIM(UPPER(as_module_desc))
			AND eng_mdl_number = v_v_eng_mod_cd;
		EXCEPTION
			WHEN NO_DATA_FOUND
			THEN
				add_error('Module Not found for Engine Model ' || as_engine_code||'^');
				v_v_eng_mod_cd :=NULL;
		END;		    
END IF;	

IF  (ls_mod_seq_id IS NOT NULL)	    	    
THEN
	in_data := input_array('');
	populate_in_data();

	FOR i IN 1..10 LOOP
	IF in_data(i) IS NOT NULL 
	THEN
		ls_rem_data := in_data(i);
		lb_not_eof := TRUE;
		
		WHILE lb_not_eof 
		LOOP
			ls_row_comp := return_string(ls_rem_data,'|','BEF');
			ls_rem_data := return_string(ls_rem_data,'|','AFT');

			IF ls_rem_data IS NULL 
			THEN
				lb_not_eof := FALSE ;
			END IF;

			ls_row_no := return_string(ls_row_comp,'^','BEF');
			ls_row_comp := return_string(ls_row_comp,'^','AFT');

			ls_comp_desc := return_string(ls_row_comp,'^','BEF');
			ls_row_comp := return_string(ls_row_comp,'^','AFT');

			ls_comp_code := return_string(ls_row_comp,'^','BEF');
			ls_row_comp := return_string(ls_row_comp,'^','AFT');

			ls_comp_doc_ref := return_string(ls_row_comp,'^','BEF');
			ls_row_comp := return_string(ls_row_comp,'^','AFT');

			ln_temp := validate_component(ls_comp_code,ls_row_no);

			IF (ln_temp = 1) 
			THEN
				ls_rep_ref := return_string(ls_row_comp,'^','BEF');
				ls_row_comp := return_string(ls_row_comp,'^','AFT');

				ls_rep_desc := return_string(ls_row_comp,'^','BEF');
				ls_row_comp := return_string(ls_row_comp,'^','AFT');
				
				ln_price_type_id := return_string(ls_row_comp,'^','BEF');
				ls_row_comp := return_string(ls_row_comp,'^','AFT');

				ls_rep_TAT := return_string(ls_row_comp,'^','BEF');
				ls_row_comp := return_string(ls_row_comp,'^','AFT');

				ls_rep_price := return_string(ls_row_comp,'^','BEF');
				ls_row_comp := return_string(ls_row_comp,'^','AFT');

				ls_rep_Future_TAT := return_string(ls_row_comp,'^','BEF');
				ls_row_comp := return_string(ls_row_comp,'^','AFT');

				ls_rep_Future_price := return_string(ls_row_comp,'^','BEF');
				ls_row_comp := return_string(ls_row_comp,'^','AFT');
				
				ls_future_date := return_string(ls_row_comp,'^','BEF');
				ls_row_comp := return_string(ls_row_comp,'^','AFT');
				
				ln_labor_cost := return_string(ls_row_comp,'^','BEF');
				ls_row_comp := return_string(ls_row_comp,'^','AFT');
				
				ln_material_cost := ls_row_comp;

				IF (INSTR(ls_rep_TAT,'+') > 0) 
				THEN
					ls_rep_TAT_inc_ind := 'Y';
					ls_rep_TAT := SUBSTR(ls_rep_TAT,2);
				ELSE
					ls_rep_TAT_inc_ind := 'N';
				END IF;

				IF (INSTR(ls_rep_price,'+') > 0) 
				THEN
					ls_rep_price_inc_ind := 'Y';
					ls_rep_price := SUBSTR(ls_rep_price,2);
				ELSE
					ls_rep_price_inc_ind := 'N';
				END IF;

				IF (ls_rep_desc IS NOT NULL) 
				THEN
					ln_rep_seq_id := validate_repair(ls_comp_code,ls_rep_desc,ls_row_no);

					IF ((ls_future_date IS NULL) AND ((ls_rep_Future_TAT IS NOT NULL) OR (ls_rep_Future_price IS NOT NULL)))
					THEN
						add_error('Error Future TAT or Future Price present when Future date is null for Repair '||ls_rep_desc|| ' on row number ' || ls_row_no || '^');
					ELSE
						IF ((ln_rep_seq_id <> 0) AND (ls_rep_TAT IS NOT NULL) OR (ls_rep_price IS NOT NULL) AND (ln_price_type_id IS NOT NULL))
						THEN
						    IF ((ls_rep_Future_TAT IS NULL) OR (ls_rep_Future_price IS  NULL))THEN
								UPDATE CRD_E_REPAIR_CATALOG
								SET repair_TAT = ls_rep_TAT,
									repair_Price = ls_rep_price,
									future_TAT = NULL,
									future_Price = NULL,
									future_effective_date = TO_DATE(ls_future_date,'MM/DD/YY HH:MI:SS'),
									price_type = ln_price_type_id,
									incremental_price_ind = ls_rep_price_inc_ind,
									incremental_tat_ind = ls_rep_TAT_inc_ind
								WHERE
									repair_seq_id = ln_temp;
							EXCEPTION
							WHEN OTHERS 
							THEN
							add_error('Error Updating CRD_CRC_REPAIR Table for Repair '||ls_rep_desc|| ' on row number ' || ls_row_no || '^');
							END;
						    
						    ELSE
							BEGIN
								UPDATE CRD_E_REPAIR_CATALOG
								SET repair_TAT = ls_rep_TAT,
									repair_Price = ls_rep_price,
									future_TAT = ls_rep_Future_TAT,
									future_Price = ls_rep_Future_price,
									future_effective_date = TO_DATE(ls_future_date,'MM/DD/YY HH:MI:SS'),
									price_type = ln_price_type_id,
									incremental_price_ind = ls_rep_price_inc_ind,
									incremental_tat_ind = ls_rep_TAT_inc_ind
								WHERE
									repair_seq_id = ln_temp;
							EXCEPTION
							WHEN OTHERS 
							THEN
							add_error('Error Updating CRD_CRC_REPAIR Table for Repair '||ls_rep_desc|| ' on row number ' || ls_row_no || '^');
							END;
							COMMIT;
						    END IF;	
						ELSIF (ln_rep_seq_id <> 0)
						THEN
							BEGIN
								UPDATE CRD_E_REPAIR_CATALOG
								SET future_TAT = ls_rep_Future_TAT,
									future_Price = ls_rep_Future_price,
									future_effective_date = TO_DATE(ls_future_date,'MM/DD/YY HH:MI:SS'),
									incremental_price_ind = ls_rep_price_inc_ind,
									incremental_tat_ind = ls_rep_TAT_inc_ind
								WHERE
									repair_seq_id = ln_temp;
							EXCEPTION
							WHEN OTHERS 
							THEN
							add_error('Error Updating CRD_CRC_REPAIR Table for Repair '||ls_rep_desc||'^');
							END;
							COMMIT;
						END IF;
					END IF;
				ELSE 
					add_error('Error in Row Number '|| ls_row_no || ' Repair description is null^');
				END IF;
			END IF;
		END LOOP;

	END IF;	
	END LOOP;
			
END IF;	

EXCEPTION
WHEN OTHERS 
THEN
	add_error('Error in uploading of data^');
END CRD_CRC_UPLOAD_DATA;
END CRD_CRC_UPLOAD;
/
