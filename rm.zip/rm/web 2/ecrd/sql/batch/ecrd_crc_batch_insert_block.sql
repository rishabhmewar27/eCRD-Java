declare
/***************************************************************************

Project Name :- Electronic Catalogue Repair Directory (eCRD)
Module Name  :- eCRD-OSB Batch Interface
Name of code :- CRD_BATCH
Created by   :- Patni
Creation Date:-
Decription   :- This interface runs on a daily basis which selects all records
      from the eCRD system and loads them into a Staging table.

Revision History

Revision no    Revision Date   Revised by      Reason for change

****************************************************************************/
    p_startdate      VARCHAR2(12) := '';
    enddate          VARCHAR2(12) := '';
    loc_id           VARCHAR2(3)  := '';
    errcode          VARCHAR2(200);
    retcode          NUMBER;
    v_di_filedir     VARCHAR2(100) ;


        /*Variable Declaration*/
   v_updcount     NUMBER:=0;
   v_commit_cnt            NUMBER:=0;
   startdate         VARCHAR2(12);
   p_compUpdStatus   VARCHAR2(1);
   p_rprUpdStatus    VARCHAR2(1);
   p_rprDispSeq      NUMBER(3);
   p_parSeqId        NUMBER;
   p_chldDispSeq     NUMBER(7);
   p_chldrepSeqid    NUMBER(9);
   p_TATIncreInd     VARCHAR2(1);
   p_rprTAT    NUMBER(7,2);
   p_priceIncreInd      VARCHAR2(1);
   -- PHA 01/19/2005 Corrected repair price oracle data type.
   p_rprPrice     crd_e_repair_catalog.REPAIR_PRICE%TYPE;
   p_rprQuoteInd     VARCHAR2(1);
   p_rprIndvRefNbr      VARCHAR2(50);
   p_chldRefNbr      VARCHAR2(50);
   p_rprDesc      VARCHAR2(255);
   p_rprComment      VARCHAR2(255);
   p_chldComment     VARCHAR2(255);
   p_rprType      VARCHAR2(20);
   p_rprDocRef    VARCHAR2(50);
   p_rprRefNbr    VARCHAR2(50);
   p_priceTypeSeq    VARCHAR2(10);
   p_rprSeqId     NUMBER(9);
   p_rprSeqIdOld     NUMBER:=0;
   p_chldIniDispId   NUMBER(7);
   v_errcode      VARCHAR2(1000);
   -- PHA 01/19/2005 Corrected future price oracle data type.
   crcFutPrice          crd_e_repair_catalog.FUTURE_PRICE%TYPE;
   crcRprSeqId       NUMBER(9);
   v_dbms_cmd     VARCHAR2(5000);
   v_dbms_curs    NUMBER;
   num_recs    INTEGER;
   p_jobInd    VARCHAR2(1);
   v_startdate       VARCHAR2(12);
   v_comp_hist_flg   VARCHAR2(1);
   v_repair_hist_flg    VARCHAR2(1) := 'N';

   -- Added on 03-Feb to store if PK of child repair has changed
   v_child_repair_hist_flg    VARCHAR2(1) := 'N';
   -- End of changes

   p_rpr_actn_flg    VARCHAR(1);
   p_catseqid        NUMBER(9);
   v_chldmin_lastupdt   DATE;
   v_parmin_lastupdt    DATE;
   v_parhist_seqid      NUMBER(7);
   v_chldhist_seqid     NUMBER(7);
   v_parhist_seqid_val     NUMBER(7);
   v_chldhist_seqid_val    NUMBER(7);
   p_rprHistDispSeq     NUMBER(7);
   v_pareffDt     CRD_E_REPAIR_CATALOG_HIST.EFFECTIVE_DATE%TYPE;
   v_par_efftDt      CRD_E_REPAIR_CATALOG_HIST.EFFECTIVE_DATE%TYPE;
   v_chld_efftDt     CRD_E_REPAIR_CATALOG_HIST.EFFECTIVE_DATE%TYPE;
   t_repair_end_date CRD_E_REPAIR_CATALOG.REPAIR_END_DATE%TYPE;
   t_startdate       VARCHAR2(1) := NULL;
   v_cat_stdt     CRD_E_CATALOG.CATALOG_EFFECTIVE_DATE%TYPE;
   v_cat_enddt    CRD_E_CATALOG.CATALOG_END_DATE%TYPE;
   v_cat_hist_flg          VARCHAR2(1);
   V_CAT_LASTUPDT          CRD_E_CATALOG_HISTORY.LAST_UPDATE_DATE%TYPE;
   v_log_filename    VARCHAR2(100) := 'ecrd_osb_intf.log';
   v_global_name     VARCHAR2(100);
   ECRD_FileHandle   UTL_FILE.FILE_TYPE;
   v_return_number      NUMBER;
   p_incremental_tat_ind   CRD_E_REPAIR_CATALOG.INCREMENTAL_TAT_IND%TYPE;
   p_incremental_price_ind CRD_E_REPAIR_CATALOG.INCREMENTAL_PRICE_IND%TYPE;

-- Varaiables added on 10-Feb to take care of Non-Key field changes
   v_old_rep_desc    CRD_E_REPAIR.REPAIR_DESCRIPTION%TYPE := NULL;
   v_old_rep_reference  CRD_E_REPAIR.REPAIR_REFERENCE_FORMAT%TYPE := NULL;
   v_repair_desc_flg    VARCHAR2(1) := 'N';

-- End of changes



/* Cursor to fetch data from the eCRD main tables. All records are selected from the main eCRD tables
   The records fetched consists of one full record based consisting of parent and child details if the
   record type is a Grouped record or a complete record if it is a Individual record.
*/
TYPE OSB_DATA_REFCUR is REF CURSOR;
OSB_DATA_CUR OSB_DATA_REFCUR;

TYPE CATALOG_RECORD IS RECORD
   (
   CatSeqId         crd_e_catalog.CATALOG_SEQ_ID%TYPE,
   CatNbr        crd_e_catalog.CATALOG_NUMBER%TYPE,
   CatDescr         crd_e_catalog.CATALOG_DESCRIPTION%TYPE,
   CatStartDt       crd_e_catalog.CATALOG_EFFECTIVE_DATE%TYPE,
   CatEndDt         crd_e_catalog.CATALOG_END_DATE%TYPE,
   ACTIVE_IND       crd_e_catalog.ACTIVE_IND%TYPE,
   CustCode         crd_e_customer_contract.CUSTOMER_CODE%TYPE,
   ContrNbr         crd_e_customer_contract.CONTRACT_NUMBER%TYPE,
   ContrDesc           crd_e_customer_contract.CUSTOMER_CONTRACT_DESCRIPTION%TYPE,
   engModNum        crd_crc_module.ENG_MDL_NUMBER%TYPE,
   locId            crd_location.LOCATION_ID%TYPE,
   compCode         crd_e_component.COMPONENT_CODE%TYPE,
   CompDocRef       crd_e_component.ATA_REFERENCE_SNUM%TYPE,
   baselineTAT         crd_e_component.BASELINE_TAT%TYPE,
   compEndDate         crd_e_component.COMPONENT_END_DATE%TYPE,
   rprOSBNbr        crd_e_repair.RPR_OSB_UNIQUE_NUMBER%TYPE,
   parSeqId         crd_e_repair.PARENT_REPAIR_SEQ_ID%TYPE,
   chldDispSeq         crd_e_repair_catalog.REPAIR_DISPLAY_SEQ_ID%TYPE,
   TATIncreInd         crd_e_repair_catalog.INCREMENTAL_TAT_IND%TYPE,
   rprTAT           crd_e_repair_catalog.REPAIR_TAT%TYPE,
   priceIncreInd       crd_e_repair_catalog.INCREMENTAL_PRICE_IND%TYPE,
   rprPrice         crd_e_repair_catalog.REPAIR_PRICE%TYPE,
   rprEndDate       VARCHAR2(11), --crd_e_repair_catalog.REPAIR_END_DATE%TYPE,
   prcEffDate       VARCHAR2(11), --crd_e_repair_catalog.EFFECTIVE_DATE%TYPE,
   chldRefNbr       crd_e_repair.REPAIR_REFERENCE%TYPE,
   chldRprDesc         crd_e_repair.REPAIR_DESCRIPTION%TYPE,
   chldComment         crd_e_repair.REPAIR_COMMENTS%TYPE,
   rprType       crd_e_repair.REPAIR_TYPE%TYPE,
   compUpdDate         crd_e_component.LAST_UPDATE_DATE%TYPE,
   compCreDate              crd_e_component.CREATION_DATE%TYPE,
   rprUpdDate       crd_e_repair.LAST_UPDATE_DATE%TYPE,
   rprCreDate       crd_e_repair.CREATION_DATE%TYPE,
   ChldUpdDate         crd_e_repair_catalog.LAST_UPDATE_DATE%TYPE,
   ChldCreDate         crd_e_repair_catalog.CREATION_DATE%TYPE,
   priceTypeSeq        crd_e_repair_catalog.PRICE_TYPE%TYPE,
   rprSeqId         crd_e_repair.REPAIR_SEQ_ID%TYPE
   );

   OSB_DATA_RECS CATALOG_RECORD;

-- PSS-15-eb-05 - Added code to retrieve start date/End date by location from Job Control Table
   v_enddate      varchar2(12);
   v_loc_id    varchar2(20);

 CURSOR  selcur
 IS
 SELECT  LOCATION_ID,
           to_char(JOB_START_DATE,'dd-mon-yyyy'),
           to_char(JOB_END_DATE,'dd-mon-yyyy')
 FROM
         CRD_E_OSB_JOBS
 WHERE      job_indicator = 'A'; -- Active jobs only

/* Main PL/SQL Body */
BEGIN

-- PSS-15-Feb-05 - Changes done for Automation

-- Delete the staging table
delete CRD_E_OSB_REPAIR_STG;
commit;

-- Added Cursor loop to iterate through location list

OPEN selcur;

LOOP
FETCH selcur INTO v_loc_id,v_startdate,v_enddate;
EXIT WHEN selcur%NOTFOUND;

    p_startdate := v_startdate;  -- Start Date
    enddate     := v_enddate;      -- End Date
    loc_id      := v_loc_id;       -- Location (Site)

    v_updcount := 0;          -- Initialize the variable

-- PSS-15-Feb-05 - End of changes

/* Set the start date to the start date mentioned in the OSB_JOBS interface control table*/
startdate:=p_startdate;
/* Check if start date is null. IF yes assign it a default value */

IF(startdate IS NULL) THEN
   startdate:= '01-jan-2000';
END IF;



/* Get the job control indicator from the OSB_JOBS interface control table */
BEGIN
SELECT job_indicator INTO p_jobInd FROM CRD_E_OSB_JOBS WHERE location_id = loc_id;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    DBMS_OUTPUT.PUT_LINE('No Data Found in the Interface Control table for the specified location');
END;

/* Opening Ref cursor based on the interface control table status. IF the job is running to migrate
   all the active catalogs at the end of the year then the start date is set to null in the
   interface control table. A Union is taken in the two queries to check if there are any
   advanced escalated records created in the repair catalog hist table with staging history indicator set
   to 'A'.
*/
IF startdate IS NOT NULL THEN
OPEN OSB_DATA_CUR FOR
SELECT  T0.CATALOG_SEQ_ID CatSeqId,
        DECODE(T0.CATALOG_TYPE,'D','Default Catalog','R',T0.CATALOG_NUMBER,T0.CATALOG_NUMBER ) CatNbr,
        T0.CATALOG_DESCRIPTION CatDescr,
        --T0.CATALOG_EFFECTIVE_DATE CatStartDt,
        --T0.CATALOG_END_DATE CatEndDt,
        DECODE(T0.CATALOG_TYPE,'D',T0.CATALOG_EFFECTIVE_DATE,T8.CONTRACT_START_DATE)  CatStartDt,
   DECODE(T0.CATALOG_TYPE,'D',T0.CATALOG_END_DATE ,T8.CONTRACT_END_DATE) CatEndDt,
        T0.ACTIVE_IND,
        DECODE(T0.CATALOG_TYPE,'D','Default','R',T8.CUSTOMER_CODE ,T8.CUSTOMER_CODE ) CustCode,
        DECODE(T0.CATALOG_TYPE,'D','Default','R',T8.CONTRACT_NUMBER,T8.CONTRACT_NUMBER ) ContrNbr,
        DECODE(T0.CATALOG_TYPE,'D','Default','R',T8.CUSTOMER_CONTRACT_DESCRIPTION,T8.CUSTOMER_CONTRACT_DESCRIPTION ) ContrDesc,
        SUBSTR(T1.ENG_MDL_NUMBER,0,2) engModNum,
        SUBSTR(T2.LOCATION_ID,0,3) locId,
        SUBSTR(T4.COMPONENT_CODE,0,4) compCode,
        SUBSTR(T4.ATA_REFERENCE_SNUM,0,20) CompDocRef,
        SUBSTR(TO_CHAR(T4.BASELINE_TAT),0,5) baselineTAT,
        TO_CHAR(T4.COMPONENT_END_DATE,'dd-mon-yyyy') compEndDate,
        SUBSTR(TO_CHAR(T5.RPR_OSB_UNIQUE_NUMBER),0,5) rprOSBNbr,
        T5.PARENT_REPAIR_SEQ_ID   parSeqId,
        SUBSTR(TO_CHAR(T7.REPAIR_DISPLAY_SEQ_ID),0,3) chldDispSeq,
        SUBSTR(T7.INCREMENTAL_TAT_IND,0,1) TATIncreInd,
        SUBSTR(TO_CHAR(T7.REPAIR_TAT),0,5) rprTAT,
        SUBSTR(T7.INCREMENTAL_PRICE_IND,0,1) priceIncreInd,
        SUBSTR(TO_CHAR(T7.REPAIR_PRICE),0,17) rprPrice,
        DECODE(T3.ACTIVE_IND,'Y',TO_CHAR(T7.REPAIR_END_DATE,'dd-mon-yyyy'),TO_CHAR(sysdate + 1,'dd-mon-yyyy')) rprEndDate,
        --TO_CHAR(T7.REPAIR_END_DATE,'dd-mon-yyyy') rprEndDate,
        TO_CHAR(T7.EFFECTIVE_DATE,'dd-mon-yyyy') prcEffDate,
   --SUBSTR(T5.REPAIR_REFERENCE,0,20) rprIndvRefNbr,
        SUBSTR(T5.REPAIR_REFERENCE,0,20) chldRefNbr,
   --SUBSTR(T5.REPAIR_DESCRIPTION,0,255) rprDesc,
        SUBSTR(T5.REPAIR_DESCRIPTION,0,255) chldRprDesc,
   --SUBSTR(T5.REPAIR_COMMENTS,0,255) rprComment,
        SUBSTR(T5.REPAIR_COMMENTS,0,255) chldComment,
        T5.REPAIR_TYPE rprType,
        TO_CHAR(T4.LAST_UPDATE_DATE,'dd-mon-yyyy') compUpdDate,
        TO_CHAR(T4.CREATION_DATE,'dd-mon-yyyy') compCreDate,
        TO_CHAR(T5.LAST_UPDATE_DATE,'dd-mon-yyyy') rprUpdDate,
        TO_CHAR(T5.CREATION_DATE,'dd-mon-yyyy') rprCreDate,
        TO_CHAR(T7.LAST_UPDATE_DATE,'dd-mon-yyyy') ChldUpdDate,
        TO_CHAR(T7.CREATION_DATE,'dd-mon-yyyy') ChldCreDate,
        --TO_CHAR(T7.PRICE_TYPE) priceTypeSeq,
        T7.PRICE_TYPE priceTypeSeq,
        T5.REPAIR_SEQ_ID rprSeqId
  FROM  crd_e_catalog T0,
        crd_crc_module T1,
        crd_location T2,
        crd_e_component_location T3,
        crd_e_component T4,
        crd_e_repair T5,
        crd_e_repair_catalog T7,
        crd_e_customer_contract T8
  WHERE  T1.ENG_MDL_NUMBER    = T0.ENG_MDL_NUMBER
        AND T0.CATALOG_SEQ_ID    = T8.CATALOG_SEQ_ID(+)
   AND T2.LOCATION_ID   = LOC_ID
   AND T0.catalog_type   IN ('C','D')
   AND T2.LOCATION_ID   = T3.LOCATION_ID
   AND T3.MODULE_SEQ_ID    = T1.MODULE_SEQ_ID
   AND T3.MODULE_SEQ_ID    = T4.MODULE_SEQ_ID
   AND T3.COMPONENT_CODE   = T4.COMPONENT_CODE
   AND T4.COMPONENT_CODE   = T5.COMPONENT_CODE
   AND T4.MODULE_SEQ_ID    = T5.MODULE_SEQ_ID
   AND T5.REPAIR_SEQ_ID    = T7.REPAIR_SEQ_ID
   AND T7.CATALOG_SEQ_ID   = T0.CATALOG_SEQ_ID
   AND T5.REPAIR_TYPE   NOT IN ('PR','MR','SG')
   AND T7.REPAIR_DISPLAY_SEQ_ID is not null
   AND TO_DATE(TO_CHAR(T4.CREATION_DATE,'dd-mon-yyyy'),'dd-mon-yyyy')     <= TO_DATE(enddate,'dd-mon-yyyy')
   AND TO_DATE(TO_CHAR(T4.LAST_UPDATE_DATE,'dd-mon-yyyy'),'dd-mon-yyyy')  <= TO_DATE(enddate,'dd-mon-yyyy')
   AND TO_DATE(TO_CHAR(T5.LAST_UPDATE_DATE,'dd-mon-yyyy'),'dd-mon-yyyy')  <= TO_DATE(enddate,'dd-mon-yyyy')
   AND TO_DATE(TO_CHAR(T5.CREATION_DATE,'dd-mon-yyyy'),'dd-mon-yyyy')     <= TO_DATE(enddate,'dd-mon-yyyy')
   AND ((TO_DATE(TO_CHAR(T4.CREATION_DATE,'dd-mon-yyyy'),'dd-mon-yyyy')   >= TO_DATE(startdate,'dd-mon-yyyy')) OR (TO_DATE(TO_CHAR(T4.LAST_UPDATE_DATE,'dd-mon-yyyy'),'dd-mon-yyyy') >= TO_DATE(startdate,'dd-mon-yyyy'))
   OR  (TO_DATE(TO_CHAR(T5.LAST_UPDATE_DATE,'dd-mon-yyyy'),'dd-mon-yyyy') >= TO_DATE(startdate,'dd-mon-yyyy')) OR (TO_DATE(TO_CHAR(T5.CREATION_DATE,'dd-mon-yyyy'),'dd-mon-yyyy') >= TO_DATE(startdate,'dd-mon-yyyy'))
   OR  (TO_DATE(TO_CHAR(T7.LAST_UPDATE_DATE,'dd-mon-yyyy'),'dd-mon-yyyy') >= TO_DATE(startdate,'dd-mon-yyyy')) OR (TO_DATE(TO_CHAR(T7.CREATION_DATE,'dd-mon-yyyy'),'dd-mon-yyyy') >= TO_DATE(startdate,'dd-mon-yyyy'))
   OR  (TO_DATE(TO_CHAR(T3.LAST_UPDATE_DATE,'dd-mon-yyyy'),'dd-mon-yyyy') >= TO_DATE(startdate,'dd-mon-yyyy')) OR (TO_DATE(TO_CHAR(T3.CREATION_DATE,'dd-mon-yyyy'),'dd-mon-yyyy') >= TO_DATE(startdate,'dd-mon-yyyy'))
   OR  (TO_DATE(TO_CHAR(T8.LAST_UPDATE_DATE,'dd-mon-yyyy'),'dd-mon-yyyy') >= TO_DATE(startdate,'dd-mon-yyyy')) OR (TO_DATE(TO_CHAR(T8.CREATION_DATE,'dd-mon-yyyy'),'dd-mon-yyyy') >= TO_DATE(startdate,'dd-mon-yyyy'))
   OR  (TO_DATE(TO_CHAR(T0.LAST_UPDATE_DATE,'dd-mon-yyyy'),'dd-mon-yyyy') >= TO_DATE(startdate,'dd-mon-yyyy')) OR (TO_DATE(TO_CHAR(T0.CREATION_DATE,'dd-mon-yyyy'),'dd-mon-yyyy') >= TO_DATE(startdate,'dd-mon-yyyy')))
   AND T0.active_ind IN ('Y','A')
   -- Adding where clause not to send future dated catalogs until
   -- the actual price is calculated by the escalation batch job.
   AND TRUNC(T0.CATALOG_EFFECTIVE_DATE) <= TRUNC(SYSDATE)
      UNION
   SELECT  T0.CATALOG_SEQ_ID CatSeqId,
        DECODE(T0.CATALOG_TYPE,'D','Default Catalog','R',T0.CATALOG_NUMBER,T0.CATALOG_NUMBER ) CatNbr,
        T0.CATALOG_DESCRIPTION CatDescr,
        --T0.CATALOG_EFFECTIVE_DATE CatStartDt,
        --T0.CATALOG_END_DATE CatEndDt,
        DECODE(T0.CATALOG_TYPE,'D',T0.CATALOG_EFFECTIVE_DATE,T8.CONTRACT_START_DATE)  CatStartDt,
   DECODE(T0.CATALOG_TYPE,'D',T0.CATALOG_END_DATE ,T8.CONTRACT_END_DATE) CatEndDt,
        T0.ACTIVE_IND,
        DECODE(T0.CATALOG_TYPE,'D','Default','R',T8.CUSTOMER_CODE ,T8.CUSTOMER_CODE ) CustCode,
        DECODE(T0.CATALOG_TYPE,'D','Default','R',T8.CONTRACT_NUMBER,T8.CONTRACT_NUMBER ) ContrNbr,
        DECODE(T0.CATALOG_TYPE,'D','Default','R',T8.CUSTOMER_CONTRACT_DESCRIPTION,T8.CUSTOMER_CONTRACT_DESCRIPTION ) ContrDesc,
        SUBSTR(T1.ENG_MDL_NUMBER,0,2) engModNum,
        SUBSTR(T2.LOCATION_ID,0,3) locId,
        SUBSTR(T4.COMPONENT_CODE,0,4) compCode,
        SUBSTR(T4.ATA_REFERENCE_SNUM,0,20) CompDocRef,
        SUBSTR(TO_CHAR(T4.BASELINE_TAT),0,5) baselineTAT,
        TO_CHAR(T4.COMPONENT_END_DATE,'dd-mon-yyyy') compEndDate,
        SUBSTR(TO_CHAR(T5.RPR_OSB_UNIQUE_NUMBER),0,5) rprOSBNbr,
        T5.PARENT_REPAIR_SEQ_ID   parSeqId,
        SUBSTR(TO_CHAR(T7.REPAIR_DISPLAY_SEQ_ID),0,3) chldDispSeq,
        SUBSTR(T7.INCREMENTAL_TAT_IND,0,1) TATIncreInd,
        SUBSTR(TO_CHAR(T7.REPAIR_TAT),0,5) rprTAT,
        SUBSTR(T7.INCREMENTAL_PRICE_IND,0,1) priceIncreInd,
        SUBSTR(TO_CHAR(T7.REPAIR_PRICE),0,17) rprPrice,
        DECODE(T3.ACTIVE_IND,'Y',TO_CHAR(T7.REPAIR_END_DATE,'dd-mon-yyyy'),TO_CHAR(sysdate + 1,'dd-mon-yyyy')) rprEndDate,
        --TO_CHAR(T7.REPAIR_END_DATE,'dd-mon-yyyy') rprEndDate,
        TO_CHAR(T7.EFFECTIVE_DATE,'dd-mon-yyyy') prcEffDate,
      --SUBSTR(T5.REPAIR_REFERENCE,0,20) rprIndvRefNbr,
        SUBSTR(T5.REPAIR_REFERENCE,0,20) chldRefNbr,
      --SUBSTR(T5.REPAIR_DESCRIPTION,0,255) rprDesc,
        SUBSTR(T5.REPAIR_DESCRIPTION,0,255) chldRprDesc,
      --SUBSTR(T5.REPAIR_COMMENTS,0,255) rprComment,
        SUBSTR(T5.REPAIR_COMMENTS,0,255) chldComment,
        T5.REPAIR_TYPE rprType,
        TO_CHAR(T4.LAST_UPDATE_DATE,'dd-mon-yyyy') compUpdDate,
        TO_CHAR(T4.CREATION_DATE,'dd-mon-yyyy') compCreDate,
        TO_CHAR(T5.LAST_UPDATE_DATE,'dd-mon-yyyy') rprUpdDate,
        TO_CHAR(T5.CREATION_DATE,'dd-mon-yyyy') rprCreDate,
        TO_CHAR(T7.LAST_UPDATE_DATE,'dd-mon-yyyy') ChldUpdDate,
        TO_CHAR(T7.CREATION_DATE,'dd-mon-yyyy') ChldCreDate,
        --TO_CHAR(T7.PRICE_TYPE) priceTypeSeq,
        T7.PRICE_TYPE priceTypeSeq,
        T5.REPAIR_SEQ_ID rprSeqId
   FROM crd_e_catalog T0,
        crd_crc_module T1,
        crd_location T2,
        crd_e_component_location T3,
        crd_e_component T4,
        crd_e_repair T5,
        crd_e_repair_catalog_hist T7,
        crd_e_customer_contract T8
   WHERE T1.ENG_MDL_NUMBER    = T0.ENG_MDL_NUMBER
        AND T0.CATALOG_SEQ_ID    = T8.CATALOG_SEQ_ID(+)
   AND T2.LOCATION_ID   = LOC_ID
   AND T0.catalog_type   IN ('C','D')
   AND T2.LOCATION_ID   = T3.LOCATION_ID
   AND T3.MODULE_SEQ_ID    = T1.MODULE_SEQ_ID
   AND T3.MODULE_SEQ_ID    = T4.MODULE_SEQ_ID
   AND T3.COMPONENT_CODE   = T4.COMPONENT_CODE
   AND T4.COMPONENT_CODE   = T5.COMPONENT_CODE
   AND T4.MODULE_SEQ_ID    = T5.MODULE_SEQ_ID
   AND T5.REPAIR_SEQ_ID    = T7.REPAIR_SEQ_ID
   AND T7.CATALOG_SEQ_ID   = T0.CATALOG_SEQ_ID
   AND T5.REPAIR_TYPE   NOT IN ('PR','MR','SG')
   AND T7.staging_history_ind = 'A'
   AND T7.REPAIR_DISPLAY_SEQ_ID is not null
   AND TO_DATE(TO_CHAR(T4.CREATION_DATE,'dd-mon-yyyy'),'dd-mon-yyyy')     <= TO_DATE(enddate,'dd-mon-yyyy')
   AND TO_DATE(TO_CHAR(T4.LAST_UPDATE_DATE,'dd-mon-yyyy'),'dd-mon-yyyy')  <= TO_DATE(enddate,'dd-mon-yyyy')
   AND TO_DATE(TO_CHAR(T5.LAST_UPDATE_DATE,'dd-mon-yyyy'),'dd-mon-yyyy')  <= TO_DATE(enddate,'dd-mon-yyyy')
   AND TO_DATE(TO_CHAR(T5.CREATION_DATE,'dd-mon-yyyy'),'dd-mon-yyyy')     <= TO_DATE(enddate,'dd-mon-yyyy')
   AND ((TO_DATE(TO_CHAR(T4.CREATION_DATE,'dd-mon-yyyy'),'dd-mon-yyyy')   >= TO_DATE(startdate,'dd-mon-yyyy')) OR (TO_DATE(TO_CHAR(T4.LAST_UPDATE_DATE,'dd-mon-yyyy'),'dd-mon-yyyy') >= TO_DATE(startdate,'dd-mon-yyyy'))
   OR  (TO_DATE(TO_CHAR(T5.LAST_UPDATE_DATE,'dd-mon-yyyy'),'dd-mon-yyyy') >= TO_DATE(startdate,'dd-mon-yyyy')) OR (TO_DATE(TO_CHAR(T5.CREATION_DATE,'dd-mon-yyyy'),'dd-mon-yyyy') >= TO_DATE(startdate,'dd-mon-yyyy'))
   OR  (TO_DATE(TO_CHAR(T7.LAST_UPDATE_DATE,'dd-mon-yyyy'),'dd-mon-yyyy') >= TO_DATE(startdate,'dd-mon-yyyy')) OR (TO_DATE(TO_CHAR(T7.CREATION_DATE,'dd-mon-yyyy'),'dd-mon-yyyy') >= TO_DATE(startdate,'dd-mon-yyyy'))
   OR  (TO_DATE(TO_CHAR(T3.LAST_UPDATE_DATE,'dd-mon-yyyy'),'dd-mon-yyyy') >= TO_DATE(startdate,'dd-mon-yyyy')) OR (TO_DATE(TO_CHAR(T3.CREATION_DATE,'dd-mon-yyyy'),'dd-mon-yyyy') >= TO_DATE(startdate,'dd-mon-yyyy'))
   OR  (TO_DATE(TO_CHAR(T8.LAST_UPDATE_DATE,'dd-mon-yyyy'),'dd-mon-yyyy') >= TO_DATE(startdate,'dd-mon-yyyy')) OR (TO_DATE(TO_CHAR(T8.CREATION_DATE,'dd-mon-yyyy'),'dd-mon-yyyy') >= TO_DATE(startdate,'dd-mon-yyyy'))
   OR  (TO_DATE(TO_CHAR(T0.LAST_UPDATE_DATE,'dd-mon-yyyy'),'dd-mon-yyyy') >= TO_DATE(startdate,'dd-mon-yyyy')) OR (TO_DATE(TO_CHAR(T0.CREATION_DATE,'dd-mon-yyyy'),'dd-mon-yyyy') >= TO_DATE(startdate,'dd-mon-yyyy')))
   AND T0.active_ind IN ('Y','A')
   -- Adding where clause not to send future dated catalogs until
   -- the actual price is calculated by the escalation batch job.
   AND TRUNC(T0.CATALOG_EFFECTIVE_DATE) <= TRUNC(SYSDATE)
       ORDER BY engModNum, catseqid, CompCode, parSeqId, rprseqid;

ELSE

OPEN OSB_DATA_CUR FOR
SELECT  T0.CATALOG_SEQ_ID CatSeqId,
        DECODE(T0.CATALOG_TYPE,'D','Default Catalog','R',T0.CATALOG_NUMBER,T0.CATALOG_NUMBER ) CatNbr,
        T0.CATALOG_DESCRIPTION CatDescr,
        --T0.CATALOG_EFFECTIVE_DATE CatStartDt,
        --T0.CATALOG_END_DATE CatEndDt,
        DECODE(T0.CATALOG_TYPE,'D',T0.CATALOG_EFFECTIVE_DATE,T8.CONTRACT_START_DATE)  CatStartDt,
   DECODE(T0.CATALOG_TYPE,'D',T0.CATALOG_END_DATE ,T8.CONTRACT_END_DATE) CatEndDt,
        T0.ACTIVE_IND,
        DECODE(T0.CATALOG_TYPE,'D','Default','R',T8.CUSTOMER_CODE ,T8.CUSTOMER_CODE ) CustCode,
   DECODE(T0.CATALOG_TYPE,'D','Default','R',T8.CONTRACT_NUMBER,T8.CONTRACT_NUMBER ) ContrNbr,
        DECODE(T0.CATALOG_TYPE,'D','Default','R',T8.CUSTOMER_CONTRACT_DESCRIPTION,T8.CUSTOMER_CONTRACT_DESCRIPTION ) ContrDesc,
        SUBSTR(T1.ENG_MDL_NUMBER,0,2) engModNum,
        SUBSTR(T2.LOCATION_ID,0,3) locId,
        SUBSTR(T4.COMPONENT_CODE,0,4) compCode,
        SUBSTR(T4.ATA_REFERENCE_SNUM,0,20) CompDocRef,
        SUBSTR(TO_CHAR(T4.BASELINE_TAT),0,5) baselineTAT,
        TO_CHAR(T4.COMPONENT_END_DATE,'dd-mon-yyyy') compEndDate,
        SUBSTR(TO_CHAR(T5.RPR_OSB_UNIQUE_NUMBER),0,5) rprOSBNbr,
        T5.PARENT_REPAIR_SEQ_ID   parSeqId,
        SUBSTR(TO_CHAR(T7.REPAIR_DISPLAY_SEQ_ID),0,3) chldDispSeq,
        SUBSTR(T7.INCREMENTAL_TAT_IND,0,1) TATIncreInd,
        SUBSTR(TO_CHAR(T7.REPAIR_TAT),0,5) rprTAT,
        SUBSTR(T7.INCREMENTAL_PRICE_IND,0,1) priceIncreInd,
        SUBSTR(TO_CHAR(T7.REPAIR_PRICE),0,17) rprPrice,
        DECODE(T3.ACTIVE_IND,'Y',TO_CHAR(T7.REPAIR_END_DATE,'dd-mon-yyyy'),TO_CHAR(sysdate + 1,'dd-mon-yyyy')) rprEndDate,
        --TO_CHAR(T7.REPAIR_END_DATE,'dd-mon-yyyy') rprEndDate,
        TO_CHAR(T7.EFFECTIVE_DATE,'dd-mon-yyyy') prcEffDate,
   --SUBSTR(T5.REPAIR_REFERENCE,0,20) rprIndvRefNbr,
        SUBSTR(T5.REPAIR_REFERENCE,0,20) chldRefNbr,
   --SUBSTR(T5.REPAIR_DESCRIPTION,0,255) rprDesc,
        SUBSTR(T5.REPAIR_DESCRIPTION,0,255) chldRprDesc,
   --SUBSTR(T5.REPAIR_COMMENTS,0,255) rprComment,
        SUBSTR(T5.REPAIR_COMMENTS,0,255) chldComment,
        T5.REPAIR_TYPE rprType,
        TO_CHAR(T4.LAST_UPDATE_DATE,'dd-mon-yyyy') compUpdDate,
        TO_CHAR(T4.CREATION_DATE,'dd-mon-yyyy') compCreDate,
        TO_CHAR(T5.LAST_UPDATE_DATE,'dd-mon-yyyy') rprUpdDate,
        TO_CHAR(T5.CREATION_DATE,'dd-mon-yyyy') rprCreDate,
        TO_CHAR(T7.LAST_UPDATE_DATE,'dd-mon-yyyy') ChldUpdDate,
        TO_CHAR(T7.CREATION_DATE,'dd-mon-yyyy') ChldCreDate,
        --TO_CHAR(T7.PRICE_TYPE) priceTypeSeq,
        T7.PRICE_TYPE priceTypeSeq,
        T5.REPAIR_SEQ_ID rprSeqId
  FROM  crd_e_catalog T0,
        crd_crc_module T1,
        crd_location T2,
        crd_e_component_location T3,
        crd_e_component T4,
        crd_e_repair T5,
        crd_e_repair_catalog T7,
        crd_e_customer_contract T8
  WHERE  T1.ENG_MDL_NUMBER    = T0.ENG_MDL_NUMBER
        AND T0.CATALOG_SEQ_ID    = T8.CATALOG_SEQ_ID(+)
   AND T2.LOCATION_ID   = LOC_ID
   AND T0.catalog_type  IN ('C','D')
   AND T2.LOCATION_ID   = T3.LOCATION_ID
   AND T3.MODULE_SEQ_ID    = T1.MODULE_SEQ_ID
   AND T3.MODULE_SEQ_ID    = T4.MODULE_SEQ_ID
   AND T3.COMPONENT_CODE   = T4.COMPONENT_CODE
   AND T4.COMPONENT_CODE   = T5.COMPONENT_CODE
   AND T4.MODULE_SEQ_ID    = T5.MODULE_SEQ_ID
   AND T5.REPAIR_SEQ_ID    = T7.REPAIR_SEQ_ID
   AND T7.CATALOG_SEQ_ID   = T0.CATALOG_SEQ_ID
   AND T5.REPAIR_TYPE   NOT IN  ('PR' ,'MR','SG')
        AND TO_DATE(TO_CHAR(T4.CREATION_DATE,'dd-mon-yyyy'),'dd-mon-yyyy') <= TO_DATE(enddate,'dd-mon-yyyy')
   AND TO_DATE(TO_CHAR(T4.LAST_UPDATE_DATE,'dd-mon-yyyy'),'dd-mon-yyyy') <= TO_DATE(enddate,'dd-mon-yyyy')
   AND TO_DATE(TO_CHAR(T5.LAST_UPDATE_DATE,'dd-mon-yyyy'),'dd-mon-yyyy') <= TO_DATE(enddate,'dd-mon-yyyy')
   AND TO_DATE(TO_CHAR(T5.CREATION_DATE,'dd-mon-yyyy'),'dd-mon-yyyy') <= TO_DATE(enddate,'dd-mon-yyyy')
   AND T4.COMPONENT_END_DATE IS NULL
   AND T7.REPAIR_END_DATE    IS NULL
   AND T0.active_ind IN ('Y','A')
   -- Adding where clause not to send future dated catalogs until
   -- the actual price is calculated by the escalation batch job.
   AND TRUNC(T0.CATALOG_EFFECTIVE_DATE) <= TRUNC(SYSDATE)
UNION
   SELECT  T0.CATALOG_SEQ_ID CatSeqId,
        DECODE(T0.CATALOG_TYPE,'D','Default Catalog','R',T0.CATALOG_NUMBER,T0.CATALOG_NUMBER ) CatNbr,
        T0.CATALOG_DESCRIPTION CatDescr,
        --T0.CATALOG_EFFECTIVE_DATE CatStartDt,
        --T0.CATALOG_END_DATE CatEndDt,
        DECODE(T0.CATALOG_TYPE,'D',T0.CATALOG_EFFECTIVE_DATE,T8.CONTRACT_START_DATE)  CatStartDt,
   DECODE(T0.CATALOG_TYPE,'D',T0.CATALOG_END_DATE ,T8.CONTRACT_END_DATE) CatEndDt,
        T0.ACTIVE_IND,
        DECODE(T0.CATALOG_TYPE,'D','Default','R',T8.CUSTOMER_CODE ,T8.CUSTOMER_CODE ) CustCode,
   DECODE(T0.CATALOG_TYPE,'D','Default','R',T8.CONTRACT_NUMBER,T8.CONTRACT_NUMBER ) ContrNbr,
        DECODE(T0.CATALOG_TYPE,'D','Default','R',T8.CUSTOMER_CONTRACT_DESCRIPTION,T8.CUSTOMER_CONTRACT_DESCRIPTION ) ContrDesc,
        SUBSTR(T1.ENG_MDL_NUMBER,0,2) engModNum,
        SUBSTR(T2.LOCATION_ID,0,3) locId,
        SUBSTR(T4.COMPONENT_CODE,0,4) compCode,
        SUBSTR(T4.ATA_REFERENCE_SNUM,0,20) CompDocRef,
        SUBSTR(TO_CHAR(T4.BASELINE_TAT),0,5) baselineTAT,
        TO_CHAR(T4.COMPONENT_END_DATE,'dd-mon-yyyy') compEndDate,
        SUBSTR(TO_CHAR(T5.RPR_OSB_UNIQUE_NUMBER),0,5) rprOSBNbr,
        T5.PARENT_REPAIR_SEQ_ID   parSeqId,
        SUBSTR(TO_CHAR(T7.REPAIR_DISPLAY_SEQ_ID),0,3) chldDispSeq,
        SUBSTR(T7.INCREMENTAL_TAT_IND,0,1) TATIncreInd,
        SUBSTR(TO_CHAR(T7.REPAIR_TAT),0,5) rprTAT,
        SUBSTR(T7.INCREMENTAL_PRICE_IND,0,1) priceIncreInd,
        SUBSTR(TO_CHAR(T7.REPAIR_PRICE),0,17) rprPrice,
        DECODE(T3.ACTIVE_IND,'Y',TO_CHAR(T7.REPAIR_END_DATE,'dd-mon-yyyy'),TO_CHAR(sysdate + 1,'dd-mon-yyyy')) rprEndDate,
        --TO_CHAR(T7.REPAIR_END_DATE,'dd-mon-yyyy') rprEndDate,
        TO_CHAR(T7.EFFECTIVE_DATE,'dd-mon-yyyy') prcEffDate,
   --SUBSTR(T5.REPAIR_REFERENCE,0,20) rprIndvRefNbr,
        SUBSTR(T5.REPAIR_REFERENCE,0,20) chldRefNbr,
   --SUBSTR(T5.REPAIR_DESCRIPTION,0,255) rprDesc,
        SUBSTR(T5.REPAIR_DESCRIPTION,0,255) chldRprDesc,
   --SUBSTR(T5.REPAIR_COMMENTS,0,255) rprComment,
        SUBSTR(T5.REPAIR_COMMENTS,0,255) chldComment,
        T5.REPAIR_TYPE rprType,
        TO_CHAR(T4.LAST_UPDATE_DATE,'dd-mon-yyyy') compUpdDate,
        TO_CHAR(T4.CREATION_DATE,'dd-mon-yyyy') compCreDate,
        TO_CHAR(T5.LAST_UPDATE_DATE,'dd-mon-yyyy') rprUpdDate,
        TO_CHAR(T5.CREATION_DATE,'dd-mon-yyyy') rprCreDate,
        TO_CHAR(T7.LAST_UPDATE_DATE,'dd-mon-yyyy') ChldUpdDate,
        TO_CHAR(T7.CREATION_DATE,'dd-mon-yyyy') ChldCreDate,
        --TO_CHAR(T7.PRICE_TYPE) priceTypeSeq,
        T7.PRICE_TYPE priceTypeSeq,
        T5.REPAIR_SEQ_ID rprSeqId
  FROM  crd_e_catalog T0,
        crd_crc_module T1,
        crd_location T2,
        crd_e_component_location T3,
        crd_e_component T4,
        crd_e_repair T5,
        crd_e_repair_catalog_hist T7,
        crd_e_customer_contract T8
  WHERE  T1.ENG_MDL_NUMBER    = T0.ENG_MDL_NUMBER
        AND T0.CATALOG_SEQ_ID    = T8.CATALOG_SEQ_ID(+)
   AND T2.LOCATION_ID   = LOC_ID
   AND T0.catalog_type  IN ('C','D')
   AND T2.LOCATION_ID   = T3.LOCATION_ID
   AND T3.MODULE_SEQ_ID    = T1.MODULE_SEQ_ID
   AND T3.MODULE_SEQ_ID    = T4.MODULE_SEQ_ID
   AND T3.COMPONENT_CODE   = T4.COMPONENT_CODE
   AND T4.COMPONENT_CODE   = T5.COMPONENT_CODE
   AND T4.MODULE_SEQ_ID    = T5.MODULE_SEQ_ID
   AND T5.REPAIR_SEQ_ID    = T7.REPAIR_SEQ_ID
   AND T7.CATALOG_SEQ_ID   = T0.CATALOG_SEQ_ID
   AND T5.REPAIR_TYPE   NOT IN  ('PR','MR','SG')
   AND T7.staging_history_ind = 'A'
   AND TO_DATE(TO_CHAR(T4.CREATION_DATE,'dd-mon-yyyy'),'dd-mon-yyyy') <= TO_DATE(enddate,'dd-mon-yyyy')
   AND TO_DATE(TO_CHAR(T4.LAST_UPDATE_DATE,'dd-mon-yyyy'),'dd-mon-yyyy') <= TO_DATE(enddate,'dd-mon-yyyy')
   AND TO_DATE(TO_CHAR(T5.LAST_UPDATE_DATE,'dd-mon-yyyy'),'dd-mon-yyyy') <= TO_DATE(enddate,'dd-mon-yyyy')
   AND TO_DATE(TO_CHAR(T5.CREATION_DATE,'dd-mon-yyyy'),'dd-mon-yyyy') <= TO_DATE(enddate,'dd-mon-yyyy')
   AND T4.COMPONENT_END_DATE IS NULL
   AND T7.REPAIR_END_DATE    IS NULL
   AND T0.active_ind IN ('Y','A')
   -- Adding where clause not to send future dated catalogs until
   -- the actual price is calculated by the escalation batch job.
   AND TRUNC(T0.CATALOG_EFFECTIVE_DATE) <= TRUNC(SYSDATE)
      ORDER BY engmodnum, catseqid, CompCode, parSeqId, rprseqid;

END IF; -- End of startdate null check


/* Setting the UTL file directory based on the instance it the interface is running on */
   BEGIN
      SELECT GLOBAL_NAME
      INTO   v_global_name
      FROM GLOBAL_NAME;

      IF v_global_name = 'UX4D' THEN -- Local Environment
         v_di_filedir := '/oracle/app/oracle/admin/ux4d/utl_file';
      ELSIF v_global_name = 'EVNLABL2.AE.GE.COM' THEN -- Lab Environment
         v_di_filedir := 'ECRD';
      ELSIF v_global_name = 'EVNODSQ1.WORLD' THEN -- QA Environment
         v_di_filedir := '/evnodsq1/dbdata/utl';
      ELSIF v_global_name = 'EVNODSP1.WORLD' THEN -- Production Environment
         v_di_filedir := '/evnodsp1/dbdata/utl';
      END IF;

   EXCEPTION
      WHEN OTHERS THEN
         dbms_output.put_line('Cannot Select Global Name  : ' || substr(sqlerrm,1,150));
   END;

/*
BEGIN
      -- To delete the contents of the file.Will be removed afterwards
      ECRD_FileHandle := UTL_FILE.FOPEN(v_di_filedir,v_log_filename,'w');
      UTL_FILE.FCLOSE(ECRD_FileHandle);
EXCEPTION
      WHEN OTHERS THEN
         dbms_output.put_line('Warning : Cannot Write to file Reason : ' || substr(sqlerrm,1,150));


END;
*/
--v_return_number := ecrd_file_write_fnc(v_log_filename,'Log file for :'|| to_char(sysdate, 'DD/MM/YYYY hh24:mi:ss'));


/* Open Cursor to get the data to be sent to OSB based on Creation date and end dates */
LOOP
FETCH osb_data_cur into osb_Data_Recs;
EXIT WHEN osb_data_cur%NOTFOUND;
p_chldrepSeqid := osb_data_recs.rprSeqId;

/* Fetch the parent record details for the child record*/
IF (osb_data_recs.parSeqId IS NOT NULL) THEN

   BEGIN
      SELECT REPAIR_DISPLAY_SEQ_ID ,REPAIR_TAT, PRICE_TYPE,  REPAIR_PRICE, SUBSTR(INCREMENTAL_TAT_IND,0,1), SUBSTR(INCREMENTAL_PRICE_IND,0,1)
      INTO p_rprDispSeq, p_rprTAT, p_priceTypeSeq, p_rprPrice, p_incremental_tat_ind, p_incremental_price_ind
      FROM CRD_E_REPAIR_CATALOG
      WHERE REPAIR_SEQ_ID = OSB_DATA_RECS.parSeqId
      AND  CATALOG_SEQ_ID = OSB_DATA_RECS.CatSeqId
      AND  trunc(EFFECTIVE_DATE) = to_date(OSB_DATA_RECS.prcEffDate,'dd-mon-yyyy');
   EXCEPTION
      WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE(SQLCODE || SQLERRM);
      DBMS_OUTPUT.PUT_LINE('Error in fetching Parent Repair Details for child from Repair Catalog table for :'||OSB_DATA_RECS.parSeqId||' '||OSB_DATA_RECS.CatSeqId);
   END;


   BEGIN
      SELECT REPAIR_REFERENCE,  REPAIR_DESCRIPTION, REPAIR_COMMENTS
      INTO  p_rprIndvRefNbr, p_rprDesc, p_rprComment
      FROM CRD_E_REPAIR
      WHERE REPAIR_SEQ_ID = OSB_DATA_RECS.parSeqId;
   EXCEPTION
      WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('Error in fetching Parent Repair Details for child from Repair table for:'||OSB_DATA_RECS.parSeqId);
   END;

   /* Setting the Repair sequence id to parent repair sequence id value */
   p_rprSeqId  := osb_data_recs.parSeqId;
--    p_chldIniDispId := osb_data_recs.chldDispSeq;
-- p_chldDispSeq   := osb_data_recs.chldDispSeq;

ELSE

/* This initilisation is for non Grouped Repairs, like IR */
       p_rprIndvRefNbr := osb_data_recs.chldRefNbr;  -- Because both the column is one. This is for IR type repairs
       p_rprPrice      := osb_data_recs.rprPrice ;
       p_priceTypeSeq  := osb_data_recs.priceTypeSeq;
       p_rprTAT        := osb_data_recs.rprTAT;
       p_rprDesc       := osb_data_recs.chldRprDesc; -- For IR repairs, since only one reocrd is fetched.
       p_rprComment    := osb_data_recs.chldComment; -- For IR type repairs.
       p_rprDispSeq    := osb_data_recs.chldDispSeq;
       p_rprSeqId      := osb_data_recs.rprSeqId;
--     p_chldIniDispId := osb_data_recs.chldDispSeq;
       p_incremental_tat_ind  := osb_data_recs.TATIncreInd;
       p_incremental_price_ind:= osb_data_recs.priceIncreInd;


END IF; -- END of Fetching PArent repair details for child repairs.

t_repair_end_date := to_date(osb_data_recs.rprEndDate,'dd-mon-yyyy');


/* Checking the component end date and catalog end date, If populated, we would populate the repair end date to
   signify to OSB that the record is no longer valid
 */
IF (trunc(osb_data_recs.CompEndDate) IS NOT NULL OR (trunc(osb_data_recs.CatEndDt) = trunc(sysdate)+1)) THEN
   t_repair_end_date := sysdate + 1;
END IF;


 /* Check price type seq*/
 IF (p_priceTypeSeq = 'QUOTE') THEN
   p_rprQuoteInd:='Q';
 ELSE
   p_rprQuoteInd:=' ';
 END IF;


 /*Check the TAT Increment Indicator*/
 IF (p_incremental_tat_ind = 'Y') THEN
   p_TATIncreInd:='+';
 ELSE
   p_TATIncreInd:=' ';
 END IF;


 /*Check the price increment indicator*/
 IF (p_incremental_price_ind = 'Y') THEN
   p_priceIncreInd:='+';
 ELSE
   p_priceIncreInd:=' ';
 END IF;


 /*Check the repair seq id*/
 IF(p_rprSeqIdOld != p_rprSeqId) THEN
   p_rprSeqIdOld  := p_rprSeqId;
   p_chldIniDispId:= osb_data_recs.chldDispSeq - 5;
 END IF;

/* Check the job indicator status in the Interface control table. Fetch the future price from the repair catalog table */
IF(p_jobInd = 'Y') THEN
   BEGIN
     SELECT substr(to_char(FUTURE_PRICE),0,17) INTO crcFutPrice
     FROM crd_e_repair_catalog
     WHERE    to_date(to_char(FUTURE_EFFECTIVE_DATE,'dd-mon-yyyy'),'dd-mon-yyyy') <= to_date(ENDdate,'dd-mon-yyyy')
     AND REPAIR_SEQ_ID=osb_data_recs.rprSeqId;
     IF(crcFutPrice IS NOT NULL) THEN
      p_rprPrice:=crcFutPrice;
     END IF;
   EXCEPTION
     WHEN NO_DATA_FOUND THEN
                NULL;
          WHEN OTHERS THEN
                DBMS_OUTPUT.PUT_LINE('Error Occurred while fetching future price');
   END;
END IF;

/* Setting the repair price */
--p_rprPrice:=p_rprPrice*1000;
p_rprPrice:=p_rprPrice;

   v_cat_hist_flg    := 'N';           -- Initialize the variable

/* Check to see in the catalog table if there is a record for which the PK is modified
   If Yes, then send  the history details for the modified PK. First selecting the min
   last update date, The reason being that there could be multiple records for the same
   last update date. We have to take the record with the minimum time stamp. The assumtion
   is that the front end inserts the timestamp also along with the date. Else error would
   be generated, indicating that the fetch return more than one row
*/

-------------------------------------------------------------------------------------------
-- As discussed with OSB team on 04-Feb, there is no need to send the history record if there
-- is any change in Catalog Effective/End date. Hence setting the flag to N and commenting the
-- queries

/*******************************************

   BEGIN
       SELECT MIN(LAST_UPDATE_DATE)
       INTO v_cat_lastupdt
       FROM CRD_E_CATALOG_HISTORY
       WHERE catalog_seq_id  = osb_data_recs.catseqid
       AND TRUNC(LAST_UPDATE_DATE) BETWEEN TO_DATE(STARTDATE,'dd-mon-yyyy') AND TO_DATE(ENDDATE,'dd-mon-yyyy');
   EXCEPTION
       WHEN NO_DATA_FOUND THEN
         v_cat_stdt       := NULL;
         v_cat_enddt      := NULL;
         v_cat_hist_flg    := 'N';
       WHEN OTHERS THEN
         v_cat_stdt       := NULL;
         v_cat_enddt      := NULL;
         v_cat_hist_flg    := 'N';
        DBMS_OUTPUT.PUT_LINE('Error Occured at IR level while fetching catalog history date for :'||osb_data_recs.rprSeqId||''||osb_data_recs.catseqid);
        DBMS_OUTPUT.PUT_LINE(SQLCODE || SQLERRM);
        --v_return_number := ecrd_file_write_fnc(v_log_filename,'Error Occured at IR level while fetching catalog history date for :'||osb_data_recs.rprSeqId||''||osb_data_recs.catseqid||substr(sqlerrm,1,150));
   END;

-- Based on the Above selected last updated date, the effective date and end date are selected

   BEGIN
       SELECT  effective_date, end_date
       INTO  v_cat_stdt , v_cat_enddt
       FROM CRD_E_CATALOG_HISTORY
       WHERE catalog_seq_id  = osb_data_recs.catseqid
       AND last_update_date = v_cat_lastupdt;

      -- Modified on 03-Feb. Check if there was any change in the primary ket fields
      -- Earlier this code was after END of this block. So even there is no history record
      -- it was comparing the data.
      IF ((trunc(osb_data_recs.catStartDt) <> trunc(v_cat_stdt)) OR (trunc(osb_data_recs.catEndDt) <> trunc(v_cat_enddt))) THEN
               v_cat_hist_flg := 'Y';
      END IF;
      -- End of changes

   EXCEPTION
       WHEN NO_DATA_FOUND THEN
         v_cat_stdt       := NULL;
         v_cat_enddt      := NULL;
         v_cat_hist_flg    := 'N';
       WHEN OTHERS THEN
         v_cat_stdt       := NULL;
         v_cat_enddt      := NULL;
         v_cat_hist_flg    := 'N';
         DBMS_OUTPUT.PUT_LINE('Error occured at IR level while fetching catalog history data for :'||osb_data_recs.rprSeqId||''||osb_data_recs.catseqid);
         DBMS_OUTPUT.PUT_LINE(SQLCODE || SQLERRM);
         --v_return_number := ecrd_file_write_fnc(v_log_filename,'Error occured at IR level while fetching catalog history data for :'||osb_data_recs.rprSeqId||''||osb_data_recs.catseqid||' '||substr(sqlerrm,1,150));
   END;
**************************/


-- As discussed with OSB team on 04-Feb, there is no need to send the history record if there
-- is any change in Catalog Effective/End date. Hence setting the flag to N

v_cat_hist_flg    := 'N';  -- don't send history record for this scenario.


/*If Condition to process the cursor records based on the condition if it is a IR
  Special Individual and Split Repair
*/
IF (osb_data_recs.rprType in ('IR','SI','SP')) then

IF((substr(p_rprIndvRefNbr,1,1) >='0') AND (substr(p_rprIndvRefNbr,1,1)<='9') AND (substr(p_rprIndvRefNbr,2,1) >='0') AND (substr(p_rprIndvRefNbr,2,1)<='9')) THEN
   p_rprDocRef:= p_rprIndvRefNbr;
   p_rprRefNbr:=' ';
ELSIF(substr(p_rprIndvRefNbr,0,5) = 'CINSP') then
   p_rprDocRef:= p_rprIndvRefNbr;
   p_rprRefNbr:=' ';
ELSE
   p_rprDocRef:=' ';
   p_rprRefNbr:= p_rprIndvRefNbr;
END IF;


/* Check Repair History table if for the following record the REPAIR_DISP_SEQ_ID
   is modified or not. If Yes we need to send this record to OSB indicating that the
   corresponding record in OSB needs to be deleted, while the new record needs to
   inserted
*/

   BEGIN
       SELECT MIN(LAST_UPDATE_DATE)
       INTO v_parmin_lastupdt
       FROM CRD_E_REPAIR_CATALOG_HIST
       WHERE repair_seq_id = osb_data_recs.rprSeqId
       AND catalog_seq_id  = osb_data_recs.catseqid
       AND STAGING_HISTORY_IND = 'H'
       AND  trunc(EFFECTIVE_DATE) = to_date(OSB_DATA_RECS.prcEffDate,'dd-mon-yyyy')
       AND TRUNC(LAST_UPDATE_DATE) BETWEEN TO_DATE(STARTDATE,'dd-mon-yyyy') AND TO_DATE(ENDDATE,'dd-mon-yyyy');

   EXCEPTION
       WHEN NO_DATA_FOUND THEN
         v_parhist_seqid   := NULL;
         v_pareffDt        := NULL;
         v_repair_hist_flg := 'N';
       WHEN OTHERS THEN
         v_parhist_seqid   := NULL;
         v_pareffDt        := NULL;
         v_repair_hist_flg := 'N';
         DBMS_OUTPUT.PUT_LINE('Error Occured at IR level while fetching repair catalog hist date for :'||osb_data_recs.rprSeqId||''||osb_data_recs.catseqid);
         DBMS_OUTPUT.PUT_LINE(SQLCODE || SQLERRM);
         --v_return_number := ecrd_file_write_fnc(v_log_filename,'Error Occured at IR level while fetching repair catalog hist date for :'||osb_data_recs.rprSeqId||''||osb_data_recs.catseqid||' '||substr(sqlerrm,1,150));
   END;


/* Fetch the repair display seq id and effective date based on the minimum date selected
   in the above query. There should be one record only in the history table as the assumtion is that
   the front end inserts the date and time portion
*/
   BEGIN
       SELECT REPAIR_DISPLAY_SEQ_ID, EFFECTIVE_DATE
       INTO  v_parhist_seqid , v_pareffDt
       FROM CRD_E_REPAIR_CATALOG_HIST
       WHERE repair_seq_id = osb_data_recs.rprSeqId
       AND catalog_seq_id  = osb_data_recs.catseqid
       AND  trunc(EFFECTIVE_DATE) = to_date(OSB_DATA_RECS.prcEffDate,'dd-mon-yyyy')
       AND last_update_date = v_parmin_lastupdt
       AND STAGING_HISTORY_IND = 'H';

       -- Changes made on 03-Feb. Moved the code in BEGIN block. Earlier it was after END.
       -- Thus even when there are no history records, it was comparing the data and setting
       -- the flag to 'Y'

      /* Check to see if the sequence id is modified in the history table as it is part of
         the PK in OSB. If Yes then we need to send the value to OSB  so that they can soft
         delete the repair in their system
      */

      /*******************************************************************************/
      -- As discussed with OSB team on 04-Feb repair history record needs to be send only whrn the
      -- display seq id of repair has changed. There is no need to send history record if only effective
      -- date has changed and there is no change in disp_seq_id.
      /********************************************************************************/

      -- Commenting the original if condition
      -- IF ((p_rprDispSeq <> v_parhist_seqid) OR (osb_Data_recs.prcEffDate <> to_char(v_parEffDt,'dd-mon-yyyy'))) THEN
      --    v_repair_hist_flg := 'Y';
      --    p_rprHistDispSeq  := v_parhist_seqid;
      -- END IF;

      -- New if condition that checks only for disp_seq_id change
      IF (p_rprDispSeq <> v_parhist_seqid) THEN
          v_repair_hist_flg := 'Y';
          p_rprHistDispSeq  := v_parhist_seqid;
      END IF;

   EXCEPTION
       WHEN NO_DATA_FOUND THEN
         v_parhist_seqid   := NULL;
         v_pareffDt        := NULL;
         v_repair_hist_flg := 'N';
       WHEN OTHERS THEN
         v_parhist_seqid   := NULL;
         v_pareffDt        := NULL;
         v_repair_hist_flg := 'N';
         DBMS_OUTPUT.PUT_LINE('Error Occured at IR level while fetching repair catalog hist data for :'||osb_data_recs.rprSeqId||''||osb_data_recs.catseqid);
         DBMS_OUTPUT.PUT_LINE(SQLCODE || SQLERRM);
         --v_return_number := ecrd_file_write_fnc(v_log_filename,'Error Occured at IR level while fetching repair catalog hist data for :'||osb_data_recs.rprSeqId||''||osb_data_recs.catseqid||' '||substr(sqlerrm,1,150));
   END;


/* Checking if history record exists . If yes then we need to fetch the value of the
   sequence id and check to see if it is modified.If Yes we need to send this record to OSB
*/
IF v_repair_hist_flg = 'Y' THEN
   INSERT INTO CRD_E_OSB_REPAIR_STG(OSB_INFC_RPR_SEQ_ID, CATALOG_SEQ_ID, CATALOG_NUMBER, CATALOG_DESCRIPTION,CATALOG_EFFECTIVE_DATE,CATALOG_END_DATE,
                   ENG_MDL_NUMBER, RPR_UPDATE_STS,
         COMPONENT_CODE, COMPONENT_DOC_REF, LOCATION_ID,
         COMPONENT_UPDATE_STS, COMPONENT_TYPE,RPR_END_DATE,
         BASELINE_TAT,RPR_TAT,RPR_PRICE,
         OSB_UNIQUE_NUMBER, PRICE_QUOTE_IND, COMPONENT_END_DATE,
         PRICE_INCREMENT_IND, TAT_INCREMENT_IND,WRKSCP_DISP_SEQ_ID,
         RPR_DOC_REF,RPR_DISP_SEQ_ID,RPR_DESC,
         RPR_REF_SNUM,NOTE_IND,PRICE_EFFECTIVE_DATE,RPR_ACTN_FLG,REPAIR_SEQ_ID,AR_ORACLE_USER,CONTRACT_NUMBER,CONTRACT_DESCRIPTION,
         CREATED_BY,CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE)
      VALUES (CRD_CRC_OSB_REPAIR_STG_SEQ.nextval, osb_data_recs.CatSeqId, osb_data_recs.CatNbr, osb_data_recs.CatDescr, osb_data_recs.CatStartDt, osb_data_recs.CatEndDt,
         osb_data_recs.engModNum, p_rprUpdStatus,
         osb_data_recs.compCode, osb_data_recs.CompDocRef, osb_data_recs.locId,
         p_compUpdStatus,'C',sysdate + 1,
         osb_data_recs.baselineTAT,p_rprTAT,p_rprPrice,
         osb_data_recs.rprOSBNbr, p_rprQuoteInd, to_date(osb_data_recs.compEndDate,'dd-mon-yyyy'),
         p_priceIncreInd, p_TATIncreInd, p_rprHistDispSeq,
         p_rprDocRef,p_rprHistDispSeq,p_rprDesc,
         substr(p_rprRefNbr,0,15),'',v_parEffDt, p_rpr_actn_flg,p_chldrepSeqid ,osb_data_recs.CustCode, osb_data_recs.ContrNbr, osb_data_recs.ContrDesc,
         'Batch Process', sysdate, 'Batch Process', sysdate);

   v_updcount:=v_updcount+1;

/* If Record has comments, then insert a fresh record with same values, with the description
   field having the comment values
*/
   IF (p_rprComment <> ' ') THEN
      p_rprComment:='*'||p_rprComment;

      INSERT INTO CRD_E_OSB_REPAIR_STG(OSB_INFC_RPR_SEQ_ID, CATALOG_SEQ_ID, CATALOG_NUMBER, CATALOG_DESCRIPTION,CATALOG_EFFECTIVE_DATE,CATALOG_END_DATE,
         ENG_MDL_NUMBER, RPR_UPDATE_STS,
         COMPONENT_CODE, COMPONENT_DOC_REF, LOCATION_ID,
         COMPONENT_UPDATE_STS, COMPONENT_TYPE,RPR_END_DATE,
         BASELINE_TAT,RPR_TAT,RPR_PRICE,
         OSB_UNIQUE_NUMBER, PRICE_QUOTE_IND, COMPONENT_END_DATE,
         PRICE_INCREMENT_IND, TAT_INCREMENT_IND,WRKSCP_DISP_SEQ_ID,
         RPR_DOC_REF,RPR_DISP_SEQ_ID,RPR_DESC,
         RPR_REF_SNUM,NOTE_IND,PRICE_EFFECTIVE_DATE,RPR_ACTN_FLG,REPAIR_SEQ_ID,AR_ORACLE_USER,CONTRACT_NUMBER,CONTRACT_DESCRIPTION,
         CREATED_BY,CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE)
      VALUES (CRD_CRC_OSB_REPAIR_STG_SEQ.nextval, osb_data_recs.CatSeqId, osb_data_recs.CatNbr, osb_data_recs.CatDescr, osb_data_recs.CatStartDt, osb_data_recs.CatEndDt,
         osb_data_recs.engModNum, p_rprUpdStatus,
         osb_data_recs.compCode, osb_data_recs.CompDocRef, osb_data_recs.locId,
         p_compUpdStatus,'C',sysdate + 1,
         osb_data_recs.baselineTAT,p_rprTAT,p_rprPrice,
         osb_data_recs.rprOSBNbr, p_rprQuoteInd, to_date(osb_data_recs.compEndDate,'dd-mon-yyyy'),
         p_priceIncreInd, p_TATIncreInd,p_rprHistDispSeq,
         '',p_rprHistDispSeq+5 ,p_rprComment,
         '','*',v_parEffDt, p_rpr_actn_flg,p_chldrepSeqid,osb_data_recs.CustCode, osb_data_recs.ContrNbr, osb_data_recs.ContrDesc,
         'Batch Process', sysdate, 'Batch Process', sysdate);

         v_updcount:=v_updcount+1;

        END IF; -- End of the repair comments equal to space check
             v_repair_hist_flg := 'N';
END IF;

/* Check to see if there are any history records in the catalog history table which contain
   OSB PK modified flds like catalog effective date and end date. If Yes we need to send them to
   OSB to indicate that the records are modified
*/

IF v_cat_hist_flg = 'Y' THEN
   INSERT INTO CRD_E_OSB_REPAIR_STG(OSB_INFC_RPR_SEQ_ID, CATALOG_SEQ_ID, CATALOG_NUMBER, CATALOG_DESCRIPTION,CATALOG_EFFECTIVE_DATE,CATALOG_END_DATE,
                   ENG_MDL_NUMBER, RPR_UPDATE_STS,
         COMPONENT_CODE, COMPONENT_DOC_REF, LOCATION_ID,
         COMPONENT_UPDATE_STS, COMPONENT_TYPE,RPR_END_DATE,
         BASELINE_TAT,RPR_TAT,RPR_PRICE,
         OSB_UNIQUE_NUMBER, PRICE_QUOTE_IND, COMPONENT_END_DATE,
         PRICE_INCREMENT_IND, TAT_INCREMENT_IND,WRKSCP_DISP_SEQ_ID,
         RPR_DOC_REF,RPR_DISP_SEQ_ID,RPR_DESC,
         RPR_REF_SNUM,NOTE_IND,PRICE_EFFECTIVE_DATE,RPR_ACTN_FLG,REPAIR_SEQ_ID,AR_ORACLE_USER,CONTRACT_NUMBER,CONTRACT_DESCRIPTION,
         CREATED_BY,CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE)
      VALUES (CRD_CRC_OSB_REPAIR_STG_SEQ.nextval, osb_data_recs.CatSeqId, osb_data_recs.CatNbr, osb_data_recs.CatDescr, v_Cat_StDt, v_Cat_EndDt,
         osb_data_recs.engModNum, p_rprUpdStatus,
         osb_data_recs.compCode, osb_data_recs.CompDocRef, osb_data_recs.locId,
         p_compUpdStatus,'C',t_repair_end_date,
         osb_data_recs.baselineTAT,p_rprTAT,p_rprPrice,
         osb_data_recs.rprOSBNbr, p_rprQuoteInd, to_date(osb_data_recs.compEndDate,'dd-mon-yyyy'),
         p_priceIncreInd, p_TATIncreInd, p_rprDispSeq,
         p_rprDocRef,p_rprDispSeq,p_rprDesc,
         substr(p_rprRefNbr,0,15),'',TO_DATE(osb_Data_recs.prcEffDate,'dd-mon-yyyy'), p_rpr_actn_flg,p_chldrepSeqid ,osb_data_recs.CustCode, osb_data_recs.ContrNbr, osb_data_recs.ContrDesc,
         'Batch Process', sysdate, 'Batch Process', sysdate);

   v_updcount:=v_updcount+1;

/* If Record has comments, then insert a fresh record with same values, with the description
   field having the comment values
*/
   IF (p_rprComment <> ' ') THEN
      p_rprComment:='*'||p_rprComment;
   INSERT INTO CRD_E_OSB_REPAIR_STG(OSB_INFC_RPR_SEQ_ID, CATALOG_SEQ_ID, CATALOG_NUMBER, CATALOG_DESCRIPTION,CATALOG_EFFECTIVE_DATE,CATALOG_END_DATE,
         ENG_MDL_NUMBER, RPR_UPDATE_STS,
         COMPONENT_CODE, COMPONENT_DOC_REF, LOCATION_ID,
         COMPONENT_UPDATE_STS, COMPONENT_TYPE,RPR_END_DATE,
         BASELINE_TAT,RPR_TAT,RPR_PRICE,
         OSB_UNIQUE_NUMBER, PRICE_QUOTE_IND, COMPONENT_END_DATE,
         PRICE_INCREMENT_IND, TAT_INCREMENT_IND,WRKSCP_DISP_SEQ_ID,
         RPR_DOC_REF,RPR_DISP_SEQ_ID,RPR_DESC,
         RPR_REF_SNUM,NOTE_IND,PRICE_EFFECTIVE_DATE,RPR_ACTN_FLG,REPAIR_SEQ_ID,AR_ORACLE_USER,CONTRACT_NUMBER,CONTRACT_DESCRIPTION,
         CREATED_BY,CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE)
      VALUES (CRD_CRC_OSB_REPAIR_STG_SEQ.nextval, osb_data_recs.CatSeqId, osb_data_recs.CatNbr, osb_data_recs.CatDescr, v_Cat_StDt, v_Cat_EndDt,
         osb_data_recs.engModNum, p_rprUpdStatus,
         osb_data_recs.compCode, osb_data_recs.CompDocRef, osb_data_recs.locId,
         p_compUpdStatus,'C',t_repair_end_date,
         osb_data_recs.baselineTAT,p_rprTAT,p_rprPrice,
         osb_data_recs.rprOSBNbr, p_rprQuoteInd, to_date(osb_data_recs.compEndDate,'dd-mon-yyyy'),
         p_priceIncreInd, p_TATIncreInd,p_rprDispSeq,
         '',p_rprDispSeq+5 ,p_rprComment,
         '','*',TO_DATE(osb_Data_recs.prcEffDate,'dd-mon-yyyy'), p_rpr_actn_flg,p_chldrepSeqid,osb_data_recs.CustCode, osb_data_recs.ContrNbr, osb_data_recs.ContrDesc,
         'Batch Process', sysdate, 'Batch Process', sysdate);

         v_updcount:=v_updcount+1;

       END IF; -- End of the repair comments equal to space check
              v_cat_hist_flg := 'N';
END IF;

/* If there is a change in Non-Key fields like Repair Description or Repair Reference number
   we would need to send history record with RPR_ACTN_FLAG as 'D' = Delete.
   Check if history record is already sent for repair price change, if not only then send history record
   if non-key field has changed.
*/

IF ((v_cat_hist_flg = 'N') AND (v_repair_hist_flg = 'N')) THEN -- No history record sent

   -- Check if there is any change in Non-key fields (Repair Desc and Repair Format)

   v_repair_desc_flg := 'N';  -- initialize the variable

   -- Get Min last update date for the interface run period

   BEGIN
       SELECT
         MIN(LAST_UPDATE_DATE)
       INTO
         v_parmin_lastupdt
       FROM
         CRD_E_REPAIR_HISTORY
       WHERE
         repair_seq_id = osb_data_recs.rprSeqId
       AND  STAGING_HISTORY_IND = 'H'
       AND  TRUNC(LAST_UPDATE_DATE) BETWEEN TO_DATE(STARTDATE,'dd-mon-yyyy') AND TO_DATE(ENDDATE,'dd-mon-yyyy');

   EXCEPTION
       WHEN NO_DATA_FOUND THEN
            v_old_rep_desc   := NULL;
            v_old_rep_reference := NULL;
            v_repair_desc_flg := 'N';
       WHEN OTHERS THEN
            v_old_rep_desc   := NULL;
            v_old_rep_reference := NULL;
            v_repair_desc_flg := 'N';
         DBMS_OUTPUT.PUT_LINE('Error Occured at IR level while fetching Min Repair Hist date for :' || osb_data_recs.rprSeqId);
         DBMS_OUTPUT.PUT_LINE(SQLCODE || SQLERRM);
         --v_return_number := ecrd_file_write_fnc(v_log_filename,'Error Occured at IR level while fetching Min Repair Hist date for :' || osb_data_recs.rprSeqId);
   END;

   BEGIN

      SELECT
         repair_description, repair_reference_format
      INTO
         v_old_rep_desc, v_old_rep_reference
      FROM
         CRD_E_REPAIR_HISTORY
      WHERE
         repair_seq_id = osb_data_recs.rprSeqId
      AND   last_update_date = v_parmin_lastupdt;

      -- compare the values of non key fields (Repair Desc and Reference Number)
      IF ((v_old_rep_desc <> p_rprDesc) OR (v_old_rep_reference <> p_rprRefNbr)) THEN
         v_repair_desc_flg := 'Y';
      END IF;

   EXCEPTION
       WHEN NO_DATA_FOUND THEN
            v_old_rep_desc   := NULL;
            v_old_rep_reference := NULL;
            v_repair_desc_flg := 'N';
       WHEN OTHERS THEN
            v_old_rep_desc   := NULL;
            v_old_rep_reference := NULL;
            v_repair_desc_flg := 'N';
         DBMS_OUTPUT.PUT_LINE('Error Occured at IR level while fetching Repair Hist data for Min Last Update date for :' || osb_data_recs.rprSeqId);
         DBMS_OUTPUT.PUT_LINE(SQLCODE || SQLERRM);
         --v_return_number := ecrd_file_write_fnc(v_log_filename,'Error Occured at IR level while fetching Repair Hist data for Min Last Update date for :' || osb_data_recs.rprSeqId);
   END;

-- Insert history record with Repair Action Flag as 'D' (Delete) if Non-key fields have changed.
   IF (v_repair_desc_flg = 'Y') THEN

      INSERT INTO CRD_E_OSB_REPAIR_STG(OSB_INFC_RPR_SEQ_ID, CATALOG_SEQ_ID, CATALOG_NUMBER, CATALOG_DESCRIPTION,CATALOG_EFFECTIVE_DATE,CATALOG_END_DATE,
                   ENG_MDL_NUMBER, RPR_UPDATE_STS,
         COMPONENT_CODE, COMPONENT_DOC_REF, LOCATION_ID,
         COMPONENT_UPDATE_STS, COMPONENT_TYPE,RPR_END_DATE,
         BASELINE_TAT,RPR_TAT,RPR_PRICE,
         OSB_UNIQUE_NUMBER, PRICE_QUOTE_IND, COMPONENT_END_DATE,
         PRICE_INCREMENT_IND, TAT_INCREMENT_IND,WRKSCP_DISP_SEQ_ID,
         RPR_DOC_REF,RPR_DISP_SEQ_ID,RPR_DESC,
         RPR_REF_SNUM,NOTE_IND,PRICE_EFFECTIVE_DATE,RPR_ACTN_FLG,REPAIR_SEQ_ID,AR_ORACLE_USER,CONTRACT_NUMBER,CONTRACT_DESCRIPTION,
         CREATED_BY,CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE)
      VALUES (CRD_CRC_OSB_REPAIR_STG_SEQ.nextval, osb_data_recs.CatSeqId, osb_data_recs.CatNbr, osb_data_recs.CatDescr, osb_data_recs.CatStartDt, osb_data_recs.CatEndDt,
         osb_data_recs.engModNum, p_rprUpdStatus,
         osb_data_recs.compCode, osb_data_recs.CompDocRef, osb_data_recs.locId,
         p_compUpdStatus,'C',t_repair_end_date,
         osb_data_recs.baselineTAT,p_rprTAT,p_rprPrice,
         osb_data_recs.rprOSBNbr, p_rprQuoteInd, to_date(osb_data_recs.compEndDate,'dd-mon-yyyy'),
         p_priceIncreInd, p_TATIncreInd, p_rprHistDispSeq,
         p_rprDocRef,p_rprDispSeq,v_old_rep_desc,
         substr(v_old_rep_reference,0,15),'',v_parEffDt, 'D', p_chldrepSeqid ,osb_data_recs.CustCode, osb_data_recs.ContrNbr, osb_data_recs.ContrDesc,
         'Batch Process', sysdate, 'Batch Process', sysdate);

         v_updcount:=v_updcount+1;

   /* If Record has comments, then insert a fresh record with same values, with the description
      field having the comment values
   */
      IF (p_rprComment <> ' ') THEN

         p_rprComment:='*'||p_rprComment;

         INSERT INTO CRD_E_OSB_REPAIR_STG(OSB_INFC_RPR_SEQ_ID, CATALOG_SEQ_ID, CATALOG_NUMBER, CATALOG_DESCRIPTION,CATALOG_EFFECTIVE_DATE,CATALOG_END_DATE,
            ENG_MDL_NUMBER, RPR_UPDATE_STS,
            COMPONENT_CODE, COMPONENT_DOC_REF, LOCATION_ID,
            COMPONENT_UPDATE_STS, COMPONENT_TYPE,RPR_END_DATE,
            BASELINE_TAT,RPR_TAT,RPR_PRICE,
            OSB_UNIQUE_NUMBER, PRICE_QUOTE_IND, COMPONENT_END_DATE,
            PRICE_INCREMENT_IND, TAT_INCREMENT_IND,WRKSCP_DISP_SEQ_ID,
            RPR_DOC_REF,RPR_DISP_SEQ_ID,RPR_DESC,
            RPR_REF_SNUM,NOTE_IND,PRICE_EFFECTIVE_DATE,RPR_ACTN_FLG,REPAIR_SEQ_ID,AR_ORACLE_USER,CONTRACT_NUMBER,CONTRACT_DESCRIPTION,
            CREATED_BY,CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE)
         VALUES (CRD_CRC_OSB_REPAIR_STG_SEQ.nextval, osb_data_recs.CatSeqId, osb_data_recs.CatNbr, osb_data_recs.CatDescr, osb_data_recs.CatStartDt, osb_data_recs.CatEndDt,
            osb_data_recs.engModNum, p_rprUpdStatus,
            osb_data_recs.compCode, osb_data_recs.CompDocRef, osb_data_recs.locId,
            p_compUpdStatus,'C',t_repair_end_date,
            osb_data_recs.baselineTAT,p_rprTAT,p_rprPrice,
            osb_data_recs.rprOSBNbr, p_rprQuoteInd, to_date(osb_data_recs.compEndDate,'dd-mon-yyyy'),
            p_priceIncreInd, p_TATIncreInd,p_rprHistDispSeq,
            '',p_rprDispSeq+5 ,p_rprComment,
            '','*',v_parEffDt, 'D',p_chldrepSeqid,osb_data_recs.CustCode, osb_data_recs.ContrNbr, osb_data_recs.ContrDesc,
            'Batch Process', sysdate, 'Batch Process', sysdate);

            v_updcount:=v_updcount+1;

      END IF; -- End of the repair comments equal to space check

             v_repair_desc_flg := 'N';

   END IF; -- v_repair_desc_flg = 'Y'

   END IF;   -- other history record not sent

/* These two inserts basically insert data into the Staging table with the actual values
   from the regular tables. If the repair has comments then another similar record with
   the comment inserted into the description is inserted.
*/
   INSERT INTO CRD_E_OSB_REPAIR_STG
      (OSB_INFC_RPR_SEQ_ID, CATALOG_SEQ_ID, CATALOG_NUMBER, CATALOG_DESCRIPTION,CATALOG_EFFECTIVE_DATE,CATALOG_END_DATE,
      ENG_MDL_NUMBER, RPR_UPDATE_STS,
      COMPONENT_CODE, COMPONENT_DOC_REF, LOCATION_ID,
      COMPONENT_UPDATE_STS, COMPONENT_TYPE,RPR_END_DATE,
      BASELINE_TAT,RPR_TAT,RPR_PRICE,
      OSB_UNIQUE_NUMBER, PRICE_QUOTE_IND, COMPONENT_END_DATE,
      PRICE_INCREMENT_IND, TAT_INCREMENT_IND,WRKSCP_DISP_SEQ_ID,
      RPR_DOC_REF,RPR_DISP_SEQ_ID,RPR_DESC,
      RPR_REF_SNUM,NOTE_IND,PRICE_EFFECTIVE_DATE,RPR_ACTN_FLG,REPAIR_SEQ_ID,AR_ORACLE_USER,CONTRACT_NUMBER,CONTRACT_DESCRIPTION,
      CREATED_BY,CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE)
   VALUES (CRD_CRC_OSB_REPAIR_STG_SEQ.nextval, osb_data_recs.CatSeqId, osb_data_recs.CatNbr, osb_data_recs.CatDescr, osb_data_recs.CatStartDt, osb_data_recs.CatEndDt,
      osb_data_recs.engModNum, p_rprUpdStatus,
      osb_data_recs.compCode, osb_data_recs.CompDocRef, osb_data_recs.locId,
      p_compUpdStatus,'C',t_repair_end_date,
      osb_data_recs.baselineTAT,p_rprTAT,p_rprPrice,
      osb_data_recs.rprOSBNbr, p_rprQuoteInd, to_date(osb_data_recs.compEndDate,'dd-mon-yyyy'),
      p_priceIncreInd, p_TATIncreInd, p_rprDispSeq,
      p_rprDocRef,p_rprDispSeq,p_rprDesc,
      substr(p_rprRefNbr,0,15),'',TO_DATE(osb_Data_recs.prcEffDate,'dd-mon-yyyy'), p_rpr_actn_flg,p_chldrepSeqid,osb_data_recs.CustCode, osb_data_recs.ContrNbr, osb_data_recs.ContrDesc,
      'Batch Process', sysdate, 'Batch Process', sysdate);

   v_updcount:=v_updcount+1;

   /*Check to see if the record has a comment fld, If yes another insert is done with the comments placed in the description column */
   IF (p_rprComment <> ' ') THEN
      p_rprComment:='*'||p_rprComment;
      INSERT INTO CRD_E_OSB_REPAIR_STG(OSB_INFC_RPR_SEQ_ID, CATALOG_SEQ_ID, CATALOG_NUMBER, CATALOG_DESCRIPTION,CATALOG_EFFECTIVE_DATE,CATALOG_END_DATE,
         ENG_MDL_NUMBER, RPR_UPDATE_STS,
         COMPONENT_CODE, COMPONENT_DOC_REF, LOCATION_ID,
         COMPONENT_UPDATE_STS, COMPONENT_TYPE,RPR_END_DATE,
         BASELINE_TAT,RPR_TAT,RPR_PRICE,
         OSB_UNIQUE_NUMBER, PRICE_QUOTE_IND, COMPONENT_END_DATE,
         PRICE_INCREMENT_IND, TAT_INCREMENT_IND,WRKSCP_DISP_SEQ_ID,
         RPR_DOC_REF,RPR_DISP_SEQ_ID,RPR_DESC,
         RPR_REF_SNUM,NOTE_IND,PRICE_EFFECTIVE_DATE,RPR_ACTN_FLG,REPAIR_SEQ_ID,AR_ORACLE_USER,CONTRACT_NUMBER,CONTRACT_DESCRIPTION,
         CREATED_BY,CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE)
      VALUES (CRD_CRC_OSB_REPAIR_STG_SEQ.nextval, osb_data_recs.CatSeqId, osb_data_recs.CatNbr, osb_data_recs.CatDescr, osb_data_recs.CatStartDt, osb_data_recs.CatEndDt,
         osb_data_recs.engModNum, p_rprUpdStatus,
         osb_data_recs.compCode, osb_data_recs.CompDocRef, osb_data_recs.locId,
         p_compUpdStatus,'C',t_repair_end_date,
         osb_data_recs.baselineTAT,p_rprTAT,p_rprPrice,
         osb_data_recs.rprOSBNbr, p_rprQuoteInd, to_date(osb_data_recs.compEndDate,'dd-mon-yyyy'),
         p_priceIncreInd, p_TATIncreInd,p_rprDispSeq,
         '',p_rprDispSeq+5,p_rprComment,
         '','*',TO_DATE(osb_Data_recs.prcEffDate,'dd-mon-yyyy'), p_rpr_actn_flg,p_chldrepSeqid ,osb_data_recs.CustCode, osb_data_recs.ContrNbr, osb_data_recs.ContrDesc,
         'Batch Process', sysdate, 'Batch Process', sysdate);

         v_updcount:=v_updcount+1;

      END IF; -- End of the repair comments equal to space check

ELSE -- Else part of Repair type check. This Else type will be applicable for 'PR','MR' and 'SG'
    -- type of repairs

   /* Check the Repair Reference number*/
   IF((substr(osb_data_recs.chldRefNbr,1,1) >='0') AND (substr(osb_data_recs.chldRefNbr,1,1)<='9') AND (substr(osb_data_recs.chldRefNbr,2,1) >='0') AND (substr(p_chldRefNbr,2,1)<='9')) THEN
      p_rprDocRef:=osb_data_recs.chldRefNbr;
      p_rprRefNbr:=' ';
   ELSIF(substr(osb_data_recs.chldRefNbr,0,5) = 'CINSP') THEN
      p_rprDocRef:=osb_data_recs.chldRefNbr;
      p_rprRefNbr:=' ';
   ELSE
      p_rprDocRef:=' ';
      p_rprRefNbr:=osb_data_recs.chldRefNbr;
   END IF;

   /*Check the repair sequence id columns to see if they are same*/
   IF(p_rprSeqIdOld = p_rprSeqId) THEN
      p_chldIniDispId:=p_chldIniDispId + 5;
   ELSE
      p_chldIniDispId:=osb_data_recs.chldDispSeq;
   END IF;

   v_repair_hist_flg := 'N';
   v_child_repair_hist_flg := 'N';

   /* Following If condition checks to see if there is a corresponding record in the
      Repair Catalog history table which has the display sequence id modified. IF Yes
      we need to send to OSB so that they could do a soft delete at their end
   */
   IF (osb_data_recs.parSeqId IS NOT NULL) THEN

   /* Condition checks to see if the PArent records Sequence id is modified */
   BEGIN
       SELECT MIN(LAST_UPDATE_DATE)
       INTO v_parmin_lastupdt
       FROM CRD_E_REPAIR_CATALOG_HIST
       WHERE repair_seq_id = osb_data_recs.parseqid
       AND catalog_seq_id  = osb_data_recs.catseqid
       AND STAGING_HISTORY_IND = 'H'
       AND  trunc(EFFECTIVE_DATE) = to_date(OSB_DATA_RECS.prcEffDate,'dd-mon-yyyy')
       AND TRUNC(LAST_UPDATE_DATE) BETWEEN TO_DATE(STARTDATE,'dd-mon-yyyy') and TO_DATE(ENDDATE,'dd-mon-yyyy');

   EXCEPTION
            WHEN NO_DATA_FOUND THEN
              v_parhist_seqid    := p_rprDispSeq;
              v_parhist_seqid_val   := NULL;
              v_repair_hist_flg  := 'N';
       WHEN OTHERS THEN
              v_parhist_seqid    := p_rprDispSeq;
              v_parhist_seqid_val   := NULL;
              v_repair_hist_flg  := 'N';
         DBMS_OUTPUT.PUT_LINE('Error Occured at parent level while fetching date for Grouped Repair History for '||osb_data_recs.parseqid||','||osb_data_recs.catseqid);
         DBMS_OUTPUT.PUT_LINE(SQLCODE || SQLERRM);
          --v_return_number := ecrd_file_write_fnc(v_log_filename,'Error Occured at parent level while fetching date for Grouped Repair History for '||osb_data_recs.parseqid||','||osb_data_recs.catseqid||' '||substr(sqlerrm,1,150));
   END;

   BEGIN
       SELECT REPAIR_DISPLAY_SEQ_ID, EFFECTIVE_DATE
       INTO v_parhist_seqid, v_par_efftDt
       FROM CRD_E_REPAIR_CATALOG_HIST
       WHERE repair_seq_id = osb_data_recs.parseqid
       AND catalog_seq_id  = osb_data_recs.catseqid
       AND STAGING_HISTORY_IND = 'H'
       AND  trunc(EFFECTIVE_DATE) = to_date(OSB_DATA_RECS.prcEffDate,'dd-mon-yyyy')
       AND last_update_date = v_parmin_lastupdt;

      v_parhist_seqid_val := v_parhist_seqid;

       -- Changes made on 03-Feb. Moved the code in BEGIN block. Earlier it was after END.
       -- Thus even when there are no history records, it was comparing the data and setting
       -- the flag to 'Y'

      /* Set the history flag to Y to indicate that the record needs to be sent to OSB */

      /*******************************************************************************/
      -- As discussed with OSB team on 04-Feb repair history record needs to be send only whrn the
      -- display seq id of repair has changed. There is no need to send history record if only effective
      -- date has changed and there is no change in disp_seq_id.
      /********************************************************************************/

      -- commenting the original if condition
      -- IF ((p_rprDispSeq <> v_parhist_seqid_val) OR (osb_Data_recs.prcEffDate <> to_char(v_par_efftDt,'dd-mon-yyyy'))) THEN
      --    v_repair_hist_flg := 'Y';
      -- END IF;

      -- New if condition
         IF (p_rprDispSeq <> v_parhist_seqid_val) THEN
            v_repair_hist_flg := 'Y';
         END IF;
       -- End of changes

   EXCEPTION
            WHEN NO_DATA_FOUND THEN
              v_parhist_seqid    := p_rprDispSeq;
              v_parhist_seqid_val   := NULL;
              v_repair_hist_flg  := 'N';
       WHEN OTHERS THEN
              v_parhist_seqid    := p_rprDispSeq;
              v_parhist_seqid_val   := NULL;
              v_repair_hist_flg  := 'N';
         DBMS_OUTPUT.PUT_LINE('Error Occured at parent level while fetching date for Grouped Repair History for '||osb_data_recs.parseqid||','||osb_data_recs.catseqid);
         DBMS_OUTPUT.PUT_LINE(SQLCODE || SQLERRM);
          --v_return_number := ecrd_file_write_fnc(v_log_filename,'Error Occured at parent level while fetching date for Grouped Repair History for '||osb_data_recs.parseqid||','||osb_data_recs.catseqid||' '||substr(sqlerrm,1,150));
   END;

   /* Condition checks to see if the Child records Sequence id is modified */
   BEGIN
       SELECT MIN(LAST_UPDATE_DATE)
       INTO v_chldmin_lastupdt
       FROM CRD_E_REPAIR_CATALOG_HIST
       WHERE repair_seq_id = osb_data_recs.rprSeqId
       AND catalog_seq_id  = osb_data_recs.catseqid
       AND STAGING_HISTORY_IND = 'H'
       AND  trunc(EFFECTIVE_DATE) = to_date(OSB_DATA_RECS.prcEffDate,'dd-mon-yyyy')
       AND TRUNC(LAST_UPDATE_DATE) BETWEEN TO_DATE(STARTDATE,'dd-mon-yyyy') and TO_DATE(ENDDATE,'dd-mon-yyyy');

   EXCEPTION
            WHEN NO_DATA_FOUND THEN
              v_chldhist_seqid   := p_chldIniDispId;
              v_chldhist_seqid_val := NULL;
              v_child_repair_hist_flg  := 'N';
       WHEN OTHERS THEN
              v_chldhist_seqid   := p_chldIniDispId;
              v_chldhist_seqid_val := NULL;
              v_child_repair_hist_flg  := 'N';
         DBMS_OUTPUT.PUT_LINE('Error Occured  at child level while fetching date for Grouped Repair'||osb_data_recs.rprSeqId||','||osb_data_recs.catseqid);
         DBMS_OUTPUT.PUT_LINE(SQLCODE || SQLERRM);
         --v_return_number := ecrd_file_write_fnc(v_log_filename,'Error Occured  at child level while fetching date for Grouped Repair'||osb_data_recs.rprSeqId||','||osb_data_recs.catseqid||' '||substr(sqlerrm,1,150));
   END;

   BEGIN
       SELECT  REPAIR_DISPLAY_SEQ_ID, EFFECTIVE_DATE
       INTO v_chldhist_seqid, v_chld_efftDt
       FROM CRD_E_REPAIR_CATALOG_HIST
       WHERE repair_seq_id = osb_data_recs.rprSeqId
       AND catalog_seq_id  = osb_data_recs.catseqid
       AND STAGING_HISTORY_IND = 'H'
       AND  trunc(EFFECTIVE_DATE) = to_date(OSB_DATA_RECS.prcEffDate,'dd-mon-yyyy')
       AND last_update_date = v_chldmin_lastupdt
       AND TRUNC(LAST_UPDATE_DATE) BETWEEN TO_DATE(STARTDATE,'dd-mon-yyyy') and TO_DATE(ENDDATE,'dd-mon-yyyy');

       v_chldhist_seqid_val := v_chldhist_seqid;

       -- Changes made on 03-Feb. Moved the code in BEGIN block. Earlier it was after END.
       -- Thus even when there are no history records, it was comparing the data and setting
       -- the flag to 'Y'

      /*******************************************************************************/
      -- As discussed with OSB team on 04-Feb repair history record needs to be send only whrn the
      -- display seq id of repair has changed. There is no need to send history record if only effective
      -- date has changed and there is no change in disp_seq_id.
      /********************************************************************************/

      -- commenting the original if condition
      -- IF ((osb_data_recs.chldDispSeq <> v_chldhist_seqid_val) OR (osb_Data_recs.prcEffDate <> to_char(v_par_efftDt,'dd-mon-yyyy'))) THEN
      --    v_child_repair_hist_flg := 'Y';
      -- END IF;

      -- New if condition
      IF (osb_data_recs.chldDispSeq <> v_chldhist_seqid_val) THEN
         v_child_repair_hist_flg := 'Y';
      END IF;
      -- End of changes

   EXCEPTION
            WHEN NO_DATA_FOUND THEN
              v_chldhist_seqid   := p_chldIniDispId;
              v_chldhist_seqid_val := NULL;
              v_child_repair_hist_flg  := 'N';
       WHEN OTHERS THEN
              v_chldhist_seqid   := p_chldIniDispId;
              v_chldhist_seqid_val := NULL;
              v_child_repair_hist_flg  := 'N';
         DBMS_OUTPUT.PUT_LINE('Error Occured at child level while fetching data for Grouped Repair for '||osb_data_recs.rprSeqId||','||osb_data_recs.catseqid);
         DBMS_OUTPUT.PUT_LINE(SQLCODE || SQLERRM);
         --v_return_number := ecrd_file_write_fnc(v_log_filename,'Error Occured at child level while fetching data for Grouped Repair for '||osb_data_recs.rprSeqId||','||osb_data_recs.catseqid||' '||substr(sqlerrm,1,150));
   END;

END IF; -- End of the history data record check

/* Check to see if the history record exists for which the OSB PK is modified.
   If yes, insert record into table
*/
   IF (v_repair_hist_flg = 'Y') OR (v_child_repair_hist_flg = 'Y') THEN

      INSERT INTO CRD_E_OSB_REPAIR_STG(OSB_INFC_RPR_SEQ_ID, CATALOG_SEQ_ID, CATALOG_NUMBER, CATALOG_DESCRIPTION,CATALOG_EFFECTIVE_DATE,CATALOG_END_DATE,
         ENG_MDL_NUMBER, RPR_UPDATE_STS,
         COMPONENT_CODE, COMPONENT_DOC_REF, LOCATION_ID,
         COMPONENT_UPDATE_STS, COMPONENT_TYPE,RPR_END_DATE,
         BASELINE_TAT,RPR_TAT,RPR_PRICE,
         OSB_UNIQUE_NUMBER, PRICE_QUOTE_IND, COMPONENT_END_DATE,
         PRICE_INCREMENT_IND, TAT_INCREMENT_IND,WRKSCP_DISP_SEQ_ID,
         RPR_DOC_REF,RPR_DISP_SEQ_ID,RPR_DESC,
         RPR_REF_SNUM,NOTE_IND,PRICE_EFFECTIVE_DATE,RPR_ACTN_FLG,REPAIR_SEQ_ID,AR_ORACLE_USER,CONTRACT_NUMBER,CONTRACT_DESCRIPTION,
         CREATED_BY,CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE)
      VALUES (CRD_CRC_OSB_REPAIR_STG_SEQ.nextval, osb_data_recs.CatSeqId, osb_data_recs.CatNbr, osb_data_recs.CatDescr, osb_data_recs.CatStartDt, osb_data_recs.CatEndDt,
         osb_data_recs.engModNum, p_rprUpdStatus,
         osb_data_recs.compCode, osb_data_recs.CompDocRef, osb_data_recs.locId,
         p_compUpdStatus,'C',sysdate + 1,
         osb_data_recs.baselineTAT,p_rprTAT,p_rprPrice,
         osb_data_recs.rprOSBNbr, p_rprQuoteInd, to_date(osb_data_recs.compEndDate,'dd-mon-yyyy'),
         p_priceIncreInd, p_TATIncreInd,v_parhist_seqid,
         p_rprDocRef,v_chldhist_seqid,osb_data_recs.chldRprDesc,
         substr(p_rprRefNbr,0,15),'',v_chld_efftDt,p_rpr_actn_flg,p_chldrepSeqid,osb_data_recs.CustCode, osb_data_recs.ContrNbr, osb_data_recs.ContrDesc,
         'Batch Process', sysdate, 'Batch Process', sysdate);

         v_updcount:=v_updcount+1;

      IF (osb_data_recs.chldComment <> ' ') THEN
         p_chldComment  :='*'||osb_data_recs.chldComment;
         p_chldIniDispId:=p_chldIniDispId + 5;

      INSERT INTO CRD_E_OSB_REPAIR_STG(OSB_INFC_RPR_SEQ_ID, CATALOG_SEQ_ID, CATALOG_NUMBER, CATALOG_DESCRIPTION,CATALOG_EFFECTIVE_DATE,CATALOG_END_DATE,
         ENG_MDL_NUMBER, RPR_UPDATE_STS,
         COMPONENT_CODE, COMPONENT_DOC_REF, LOCATION_ID,
         COMPONENT_UPDATE_STS, COMPONENT_TYPE,RPR_END_DATE,
         BASELINE_TAT,RPR_TAT,RPR_PRICE,
         OSB_UNIQUE_NUMBER, PRICE_QUOTE_IND, COMPONENT_END_DATE,
         PRICE_INCREMENT_IND, TAT_INCREMENT_IND,WRKSCP_DISP_SEQ_ID,
         RPR_DOC_REF,RPR_DISP_SEQ_ID,RPR_DESC,
         RPR_REF_SNUM,NOTE_IND,PRICE_EFFECTIVE_DATE,RPR_ACTN_FLG,REPAIR_SEQ_ID,AR_ORACLE_USER,CONTRACT_NUMBER,CONTRACT_DESCRIPTION,
         CREATED_BY,CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE)
      VALUES (CRD_CRC_OSB_REPAIR_STG_SEQ.nextval, osb_data_recs.CatSeqId, osb_data_recs.CatNbr, osb_data_recs.CatDescr, osb_data_recs.CatStartDt, osb_data_recs.CatEndDt,
         osb_data_recs.engModNum, p_rprUpdStatus,
         osb_data_recs.compCode, osb_data_recs.CompDocRef, osb_data_recs.locId,
         p_compUpdStatus,'C',sysdate + 1,
         osb_data_recs.baselineTAT,p_rprTAT,p_rprPrice,
         osb_data_recs.rprOSBNbr, p_rprQuoteInd, to_date(osb_data_recs.compEndDate,'dd-mon-yyyy'),
         p_priceIncreInd, p_TATIncreInd,v_parhist_seqid,
         '',v_chldhist_seqid,p_chldComment,
         '','*',v_chld_efftDt, p_rpr_actn_flg,p_chldrepSeqid ,osb_data_recs.CustCode, osb_data_recs.ContrNbr, osb_data_recs.ContrDesc,
         'Batch Process', sysdate, 'Batch Process', sysdate);

         v_updcount:=v_updcount+1;

      END IF;

      v_repair_hist_flg := 'N';
      v_child_repair_hist_flg := 'N';
   END IF; -- check if hist flag is set

   /* Check to see if there are any history records in the catalog history table which contain
      OSB PK modified flds like catalog effective date and end date. If Yes we need to send them to
      OSB to indicate that the records are modified
   */

   IF v_cat_hist_flg = 'Y' THEN

      INSERT INTO CRD_E_OSB_REPAIR_STG(OSB_INFC_RPR_SEQ_ID, CATALOG_SEQ_ID, CATALOG_NUMBER, CATALOG_DESCRIPTION,CATALOG_EFFECTIVE_DATE,CATALOG_END_DATE,
         ENG_MDL_NUMBER, RPR_UPDATE_STS,
         COMPONENT_CODE, COMPONENT_DOC_REF, LOCATION_ID,
         COMPONENT_UPDATE_STS, COMPONENT_TYPE,RPR_END_DATE,
         BASELINE_TAT,RPR_TAT,RPR_PRICE,
         OSB_UNIQUE_NUMBER, PRICE_QUOTE_IND, COMPONENT_END_DATE,
         PRICE_INCREMENT_IND, TAT_INCREMENT_IND,WRKSCP_DISP_SEQ_ID,
         RPR_DOC_REF,RPR_DISP_SEQ_ID,RPR_DESC,
         RPR_REF_SNUM,NOTE_IND,PRICE_EFFECTIVE_DATE,RPR_ACTN_FLG,REPAIR_SEQ_ID,AR_ORACLE_USER,CONTRACT_NUMBER,CONTRACT_DESCRIPTION,
         CREATED_BY,CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE)
      VALUES (CRD_CRC_OSB_REPAIR_STG_SEQ.nextval, osb_data_recs.CatSeqId, osb_data_recs.CatNbr, osb_data_recs.CatDescr, v_Cat_StDt, v_Cat_EndDt,
         osb_data_recs.engModNum, p_rprUpdStatus,
         osb_data_recs.compCode, osb_data_recs.CompDocRef, osb_data_recs.locId,
         p_compUpdStatus,'C',t_repair_end_date,
         osb_data_recs.baselineTAT,p_rprTAT,p_rprPrice,
         osb_data_recs.rprOSBNbr, p_rprQuoteInd, to_date(osb_data_recs.compEndDate,'dd-mon-yyyy'),
         p_priceIncreInd, p_TATIncreInd,p_rprDispSeq,
         p_rprDocRef,p_chldIniDispId,osb_data_recs.chldRprDesc,
         substr(p_rprRefNbr,0,15),'',TO_DATE(osb_Data_recs.prcEffDate,'dd-mon-yyyy'),p_rpr_actn_flg,p_chldrepSeqid,osb_data_recs.CustCode, osb_data_recs.ContrNbr, osb_data_recs.ContrDesc,
         'Batch Process', sysdate, 'Batch Process', sysdate);

         v_updcount:=v_updcount+1;

      IF (osb_data_recs.chldComment <> ' ') THEN
         p_chldComment  :='*'||osb_data_recs.chldComment;
         p_chldIniDispId:=p_chldIniDispId + 5;

      INSERT INTO CRD_E_OSB_REPAIR_STG(OSB_INFC_RPR_SEQ_ID, CATALOG_SEQ_ID, CATALOG_NUMBER, CATALOG_DESCRIPTION,CATALOG_EFFECTIVE_DATE,CATALOG_END_DATE,
         ENG_MDL_NUMBER, RPR_UPDATE_STS,
         COMPONENT_CODE, COMPONENT_DOC_REF, LOCATION_ID,
         COMPONENT_UPDATE_STS, COMPONENT_TYPE,RPR_END_DATE,
         BASELINE_TAT,RPR_TAT,RPR_PRICE,
         OSB_UNIQUE_NUMBER, PRICE_QUOTE_IND, COMPONENT_END_DATE,
         PRICE_INCREMENT_IND, TAT_INCREMENT_IND,WRKSCP_DISP_SEQ_ID,
         RPR_DOC_REF,RPR_DISP_SEQ_ID,RPR_DESC,
         RPR_REF_SNUM,NOTE_IND,PRICE_EFFECTIVE_DATE,RPR_ACTN_FLG,REPAIR_SEQ_ID,AR_ORACLE_USER,CONTRACT_NUMBER,CONTRACT_DESCRIPTION,
         CREATED_BY,CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE)
      VALUES (CRD_CRC_OSB_REPAIR_STG_SEQ.nextval, osb_data_recs.CatSeqId, osb_data_recs.CatNbr, osb_data_recs.CatDescr, v_Cat_StDt, v_Cat_EndDt,
         osb_data_recs.engModNum, p_rprUpdStatus,
         osb_data_recs.compCode, osb_data_recs.CompDocRef, osb_data_recs.locId,
         p_compUpdStatus,'C',t_repair_end_date,
         osb_data_recs.baselineTAT,p_rprTAT,p_rprPrice,
         osb_data_recs.rprOSBNbr, p_rprQuoteInd, to_date(osb_data_recs.compEndDate,'dd-mon-yyyy'),
         p_priceIncreInd, p_TATIncreInd,p_rprDispSeq,
         '',p_chldIniDispId,p_chldComment,
         '','*',TO_DATE(osb_Data_recs.prcEffDate,'dd-mon-yyyy'), p_rpr_actn_flg,p_chldrepSeqid ,osb_data_recs.CustCode, osb_data_recs.ContrNbr, osb_data_recs.ContrDesc,
         'Batch Process', sysdate, 'Batch Process', sysdate);

         v_updcount:=v_updcount+1;

      END IF;

      v_cat_hist_flg := 'N';

    END IF; -- check if hist flag is set

    /* If there is a change in Non-Key fields like Repair Description or Repair Reference number
       we would need to send history record with RPR_ACTN_FLAG as 'D' = Delete.
       Check if history record is already sent for repair price change, if not only then send history record
       if non-key field has changed.
    */

    IF ((v_cat_hist_flg = 'N') AND (v_repair_hist_flg = 'N') AND (v_child_repair_hist_flg = 'N')) THEN -- No history record sent

      -- Check if there is any change in Non-key fields (Repair Desc and Repair Format)

      v_repair_desc_flg := 'N';  -- initialize the variable

      -- Get Min last update date for the interface run period

      BEGIN
          SELECT
            MIN(LAST_UPDATE_DATE)
          INTO
            v_parmin_lastupdt
          FROM
            CRD_E_REPAIR_HISTORY
          WHERE
            repair_seq_id = osb_data_recs.rprSeqId
          AND  STAGING_HISTORY_IND = 'H'
          AND  TRUNC(LAST_UPDATE_DATE) BETWEEN TO_DATE(STARTDATE,'dd-mon-yyyy') AND TO_DATE(ENDDATE,'dd-mon-yyyy');

      EXCEPTION
          WHEN NO_DATA_FOUND THEN
            v_old_rep_desc   := NULL;
            v_old_rep_reference := NULL;
            v_repair_desc_flg := 'N';
          WHEN OTHERS THEN
            v_old_rep_desc   := NULL;
            v_old_rep_reference := NULL;
            v_repair_desc_flg := 'N';
            DBMS_OUTPUT.PUT_LINE('Error Occured at child level while fetching Min Repair Hist date for :' || osb_data_recs.rprSeqId);
            DBMS_OUTPUT.PUT_LINE(SQLCODE || SQLERRM);
            --v_return_number := ecrd_file_write_fnc(v_log_filename,'Error Occured at child level while fetching Min Repair Hist date for :' || osb_data_recs.rprSeqId);
      END;

      BEGIN
         SELECT
            repair_description, repair_reference_format
         INTO
            v_old_rep_desc, v_old_rep_reference
         FROM
            CRD_E_REPAIR_HISTORY
         WHERE
            repair_seq_id = osb_data_recs.rprSeqId
         AND   last_update_date = v_parmin_lastupdt;

         -- compare the values of non key fields (Repair Desc and Reference Number)
         IF ((v_old_rep_desc <> p_rprDesc) OR (v_old_rep_reference <> p_rprRefNbr)) THEN
            v_repair_desc_flg := 'Y';
         END IF;

      EXCEPTION
          WHEN NO_DATA_FOUND THEN
            v_old_rep_desc   := NULL;
            v_old_rep_reference := NULL;
            v_repair_desc_flg := 'N';
          WHEN OTHERS THEN
            v_old_rep_desc   := NULL;
            v_old_rep_reference := NULL;
            v_repair_desc_flg := 'N';
            DBMS_OUTPUT.PUT_LINE('Error Occured at child level while fetching Repair Hist data for Min Last Update date for :' || osb_data_recs.rprSeqId);
            DBMS_OUTPUT.PUT_LINE(SQLCODE || SQLERRM);
            --v_return_number := ecrd_file_write_fnc(v_log_filename,'Error Occured at child level while fetching Repair Hist data for Min Last Update date for :' || osb_data_recs.rprSeqId);
      END;

      -- Insert history record with Repair Action Flag as 'D' (Delete) if Non-key fields have changed.
      IF (v_repair_desc_flg = 'Y') THEN

         INSERT INTO CRD_E_OSB_REPAIR_STG(OSB_INFC_RPR_SEQ_ID, CATALOG_SEQ_ID, CATALOG_NUMBER, CATALOG_DESCRIPTION,CATALOG_EFFECTIVE_DATE,CATALOG_END_DATE,
               ENG_MDL_NUMBER, RPR_UPDATE_STS,
               COMPONENT_CODE, COMPONENT_DOC_REF, LOCATION_ID,
               COMPONENT_UPDATE_STS, COMPONENT_TYPE,RPR_END_DATE,
               BASELINE_TAT,RPR_TAT,RPR_PRICE,
               OSB_UNIQUE_NUMBER, PRICE_QUOTE_IND, COMPONENT_END_DATE,
               PRICE_INCREMENT_IND, TAT_INCREMENT_IND,WRKSCP_DISP_SEQ_ID,
               RPR_DOC_REF,RPR_DISP_SEQ_ID,RPR_DESC,
               RPR_REF_SNUM,NOTE_IND,PRICE_EFFECTIVE_DATE,RPR_ACTN_FLG,REPAIR_SEQ_ID,AR_ORACLE_USER,CONTRACT_NUMBER,CONTRACT_DESCRIPTION,
               CREATED_BY,CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE)
            VALUES (CRD_CRC_OSB_REPAIR_STG_SEQ.nextval, osb_data_recs.CatSeqId, osb_data_recs.CatNbr, osb_data_recs.CatDescr, osb_data_recs.CatStartDt, osb_data_recs.CatEndDt,
               osb_data_recs.engModNum, p_rprUpdStatus,
               osb_data_recs.compCode, osb_data_recs.CompDocRef, osb_data_recs.locId,
               p_compUpdStatus,'C',sysdate + 1,
               osb_data_recs.baselineTAT,p_rprTAT,p_rprPrice,
               osb_data_recs.rprOSBNbr, p_rprQuoteInd, to_date(osb_data_recs.compEndDate,'dd-mon-yyyy'),
               p_priceIncreInd, p_TATIncreInd, p_rprHistDispSeq,
               p_rprDocRef,p_chldIniDispId,v_old_rep_desc,
               substr(v_old_rep_reference,0,15),'',v_parEffDt, 'D',p_chldrepSeqid ,osb_data_recs.CustCode, osb_data_recs.ContrNbr, osb_data_recs.ContrDesc,
               'Batch Process', sysdate, 'Batch Process', sysdate);

               v_updcount:=v_updcount+1;

      /* If Record has comments, then insert a fresh record with same values, with the description
         field having the comment values
      */
         IF (osb_data_recs.chldComment <> ' ') THEN
            p_chldComment  :='*'||osb_data_recs.chldComment;
            p_chldIniDispId:=p_chldIniDispId + 5;

            INSERT INTO CRD_E_OSB_REPAIR_STG(OSB_INFC_RPR_SEQ_ID, CATALOG_SEQ_ID, CATALOG_NUMBER, CATALOG_DESCRIPTION,CATALOG_EFFECTIVE_DATE,CATALOG_END_DATE,
               ENG_MDL_NUMBER, RPR_UPDATE_STS,
               COMPONENT_CODE, COMPONENT_DOC_REF, LOCATION_ID,
               COMPONENT_UPDATE_STS, COMPONENT_TYPE,RPR_END_DATE,
               BASELINE_TAT,RPR_TAT,RPR_PRICE,
               OSB_UNIQUE_NUMBER, PRICE_QUOTE_IND, COMPONENT_END_DATE,
               PRICE_INCREMENT_IND, TAT_INCREMENT_IND,WRKSCP_DISP_SEQ_ID,
               RPR_DOC_REF,RPR_DISP_SEQ_ID,RPR_DESC,
               RPR_REF_SNUM,NOTE_IND,PRICE_EFFECTIVE_DATE,RPR_ACTN_FLG,REPAIR_SEQ_ID,AR_ORACLE_USER,CONTRACT_NUMBER,CONTRACT_DESCRIPTION,
               CREATED_BY,CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE)
            VALUES (CRD_CRC_OSB_REPAIR_STG_SEQ.nextval, osb_data_recs.CatSeqId, osb_data_recs.CatNbr, osb_data_recs.CatDescr, osb_data_recs.CatStartDt, osb_data_recs.CatEndDt,
               osb_data_recs.engModNum, p_rprUpdStatus,
               osb_data_recs.compCode, osb_data_recs.CompDocRef, osb_data_recs.locId,
               p_compUpdStatus,'C',sysdate + 1,
               osb_data_recs.baselineTAT,p_rprTAT,p_rprPrice,
               osb_data_recs.rprOSBNbr, p_rprQuoteInd, to_date(osb_data_recs.compEndDate,'dd-mon-yyyy'),
               p_priceIncreInd, p_TATIncreInd,p_rprHistDispSeq,
               '',p_chldIniDispId ,p_chldComment,
               '','*',v_parEffDt, 'D',p_chldrepSeqid,osb_data_recs.CustCode, osb_data_recs.ContrNbr, osb_data_recs.ContrDesc,
               'Batch Process', sysdate, 'Batch Process', sysdate);

               v_updcount:=v_updcount+1;

         END IF; -- End of the repair comments equal to space check

            v_repair_desc_flg := 'N';

      END IF; -- v_repair_desc_flg = 'Y'

    END IF;   -- other history record not sent

   /*Insert regular record into the staging table */
      INSERT INTO CRD_E_OSB_REPAIR_STG(OSB_INFC_RPR_SEQ_ID, CATALOG_SEQ_ID, CATALOG_NUMBER, CATALOG_DESCRIPTION,CATALOG_EFFECTIVE_DATE,CATALOG_END_DATE,
         ENG_MDL_NUMBER, RPR_UPDATE_STS,
         COMPONENT_CODE, COMPONENT_DOC_REF, LOCATION_ID,
         COMPONENT_UPDATE_STS, COMPONENT_TYPE,RPR_END_DATE,
         BASELINE_TAT,RPR_TAT,RPR_PRICE,
         OSB_UNIQUE_NUMBER, PRICE_QUOTE_IND, COMPONENT_END_DATE,
         PRICE_INCREMENT_IND, TAT_INCREMENT_IND,WRKSCP_DISP_SEQ_ID,
         RPR_DOC_REF,RPR_DISP_SEQ_ID,RPR_DESC,
         RPR_REF_SNUM,NOTE_IND,PRICE_EFFECTIVE_DATE,RPR_ACTN_FLG,REPAIR_SEQ_ID,AR_ORACLE_USER,CONTRACT_NUMBER,CONTRACT_DESCRIPTION,
         CREATED_BY,CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE)
      VALUES (CRD_CRC_OSB_REPAIR_STG_SEQ.nextval, osb_data_recs.CatSeqId, osb_data_recs.CatNbr, osb_data_recs.CatDescr, osb_data_recs.CatStartDt, osb_data_recs.CatEndDt,
         osb_data_recs.engModNum, p_rprUpdStatus,
         osb_data_recs.compCode, osb_data_recs.CompDocRef, osb_data_recs.locId,
         p_compUpdStatus,'C',t_repair_end_date,
         osb_data_recs.baselineTAT,p_rprTAT,p_rprPrice,
         osb_data_recs.rprOSBNbr, p_rprQuoteInd, to_date(osb_data_recs.compEndDate,'dd-mon-yyyy'),
         p_priceIncreInd, p_TATIncreInd,p_rprDispSeq,
         p_rprDocRef,p_chldIniDispId,osb_data_recs.chldRprDesc,
         substr(p_rprRefNbr,0,15),'',TO_DATE(osb_Data_recs.prcEffDate,'dd-mon-yyyy'),p_rpr_actn_flg,p_chldrepSeqid,osb_data_recs.CustCode, osb_data_recs.ContrNbr, osb_data_recs.ContrDesc ,
         'Batch Process', sysdate, 'Batch Process', sysdate);
         v_updcount:=v_updcount+1;

/* If the record has a child comment insert a fresh record with the repair description part consisting the comments*/
      IF (osb_data_recs.chldComment <> ' ') THEN
         p_chldComment  :='*'||osb_data_recs.chldComment;
         p_chldIniDispId:=p_chldIniDispId + 5;

      INSERT INTO CRD_E_OSB_REPAIR_STG(OSB_INFC_RPR_SEQ_ID, CATALOG_SEQ_ID, CATALOG_NUMBER, CATALOG_DESCRIPTION,CATALOG_EFFECTIVE_DATE,CATALOG_END_DATE,
         ENG_MDL_NUMBER, RPR_UPDATE_STS,
         COMPONENT_CODE, COMPONENT_DOC_REF, LOCATION_ID,
         COMPONENT_UPDATE_STS, COMPONENT_TYPE,RPR_END_DATE,
         BASELINE_TAT,RPR_TAT,RPR_PRICE,
         OSB_UNIQUE_NUMBER, PRICE_QUOTE_IND, COMPONENT_END_DATE,
         PRICE_INCREMENT_IND, TAT_INCREMENT_IND,WRKSCP_DISP_SEQ_ID,
         RPR_DOC_REF,RPR_DISP_SEQ_ID,RPR_DESC,
         RPR_REF_SNUM,NOTE_IND,PRICE_EFFECTIVE_DATE,RPR_ACTN_FLG,REPAIR_SEQ_ID,AR_ORACLE_USER,CONTRACT_NUMBER,CONTRACT_DESCRIPTION,
         CREATED_BY,CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE)
      VALUES (CRD_CRC_OSB_REPAIR_STG_SEQ.nextval, osb_data_recs.CatSeqId, osb_data_recs.CatNbr, osb_data_recs.CatDescr, osb_data_recs.CatStartDt, osb_data_recs.CatEndDt,
         osb_data_recs.engModNum, p_rprUpdStatus,
         osb_data_recs.compCode, osb_data_recs.CompDocRef, osb_data_recs.locId,
         p_compUpdStatus,'C',t_repair_end_date,
         osb_data_recs.baselineTAT,p_rprTAT,p_rprPrice,
         osb_data_recs.rprOSBNbr, p_rprQuoteInd, to_date(osb_data_recs.compEndDate,'dd-mon-yyyy'),
         p_priceIncreInd, p_TATIncreInd,p_rprDispSeq,
         '',p_chldIniDispId,p_chldComment,
         '','*',TO_DATE(osb_Data_recs.prcEffDate,'dd-mon-yyyy'), p_rpr_actn_flg,p_chldrepSeqid ,osb_data_recs.CustCode, osb_data_recs.ContrNbr, osb_data_recs.ContrDesc,
         'Batch Process', sysdate, 'Batch Process', sysdate);
         v_updcount:=v_updcount+1;
   END IF;  -- end of check for comment

END IF; -- End of the IR loop check

 v_commit_cnt := v_updcount;

/* Intermediate Commit */
 IF MOD(v_commit_cnt ,1000)   = 0 THEN
   COMMIT;
   v_commit_cnt := 0;
 END IF;

END LOOP; -- End of osb_data_cur

CLOSE osb_data_cur;  -- Close the cursor osb_data_cur

/* Commit the records inserted into the staging table for the site */
COMMIT;

-- Update the Start/End date in Job Control Table for the location.
UPDATE   crd_e_osb_jobs
SET     job_start_date = SYSDATE,
   job_end_date = SYSDATE
WHERE    location_id = loc_id;


/* Message to indicate the job completed successfully */
DBMS_OUTPUT.PUT_LINE('Batch Job run successfully for :');
DBMS_OUTPUT.PUT_LINE('Start Date :'||startdate);
DBMS_OUTPUT.PUT_LINE('End Date   :'||enddate);
DBMS_OUTPUT.PUT_LINE('Location   :'||loc_id);
DBMS_OUTPUT.PUT_LINE('Number of Repair record(s)  :'||v_updcount);

END LOOP;   -- End of Cursor from Job Control table
CLOSE selcur;  -- Close the cursor

--v_return_number := ecrd_file_write_fnc(v_log_filename,'End of Log file for :'|| to_char(sysdate, 'DD/MM/YYYY hh24:mi:ss'));

/* Display error message if generated while batch process runs */
EXCEPTION
  WHEN OTHERS THEN
     DBMS_OUTPUT.PUT_LINE('Following Error Occurred while processing: ');
     DBMS_OUTPUT.PUT_LINE(SQLCODE || SQLERRM);

END;
/