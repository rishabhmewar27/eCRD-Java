CREATE OR REPLACE PACKAGE ecrd_to_ecrd_data_migration
AS

/*****************************************************************************
Project Name :- eCRD e Catalog Repair Directory
Module Name  :- Old eCRD to New eCRD Data Migration
name of code :- ecrd_to_ecrd_data_migration
created by   :- Abhishek
creation Date:- 19-Oct-2004

Revision History

Revision no    Revision Date   Revised by      Reason for change

*****************************************************************************/

/*****************************************************************************
	Tables to be mgrtd.Sequence of Migration is Important
	-----------------------------------------------------
	
	*  CRD_CRC_COMPONENT           --->         CRD_COMPONENT
	*  CRD_CRC_PART                --->         CRD_PART
	*  CRD_CRC_REPAIR              --->         CRD_REPAIR,CRD_REPAIR_CATALOG
	*  CRD_CRC_USER                --->         CRD_USER
	*  CRD_CRC_SITE_REPAIR         --->         CRD_REPAIR_COST
	*  CRD_CRC_LOC_COMPONENT       --->         CRD_COMPONENT_LOCATION
	*  CRD_CRC_OSB_INFC_JOB_CTRL   --->         CRD_OSB_JOBS
	*  CRD_CRC_CHILD_REPAIR        --->         CRD_REPAIR,CRD_REPAIR_CATALOG
	*  CRD_CRC_REPAIR_STG          --->         CRD_REPAIR_HISTORY,CRD_REPAIR_CATALOG__HISTORY
	*  CRD_CRC_CHILD_REPAIR_STG    --->         CRD_REPAIR_HISTORY,CRD_REPAIR_CATALOG__HISTORY
	
	New Tables to be Added
	----------------------
	
	*  CRD_CATALOG
*****************************************************************************/

/*	Main procedure
*/
PROCEDURE	ecrd_to_ecrd_main_prc;

/*	To migrate CRD_CRC_COMPONENT
*/
PROCEDURE	ecrd_mgrt_crd_crc_component;

/*	Function to set COMPONENT_SEQ_ID to COMPONENT_CODE mapping
*/
FUNCTION	ecrd_set_comp_code_map_fnc
(
	p_component_seq_id	CRD_CRC_COMPONENT.COMPONENT_SEQ_ID%TYPE,
	p_module_seq_id		CRD_CRC_COMPONENT.MODULE_SEQ_ID%TYPE,
	p_component_code	CRD_CRC_COMPONENT.COMPONENT_CODE%TYPE
)
RETURN NUMBER;

/*	To migrate CRD_CRC_PART
*/
PROCEDURE	ecrd_mgrt_crd_crc_part;

/*	Procedure to get COMPONET_SEQ_ID to COMPONENT_CODE mapping
*/
PROCEDURE	ecrd_get_comp_code_map_prc
(	p_component_seq_id	IN	CRD_CRC_COMPONENT.COMPONENT_SEQ_ID%TYPE,
	v_module_seq_id		OUT	CRD_CRC_COMPONENT.MODULE_SEQ_ID%TYPE,
	v_component_code	OUT	CRD_CRC_COMPONENT.COMPONENT_CODE%TYPE
);

/*	To populate CRD_CATALOG
*/
PROCEDURE	ecrd_crd_catalog;

/*	To migrate CRD_CRC_REPAIR
*/
PROCEDURE	ecrd_mgrt_crd_crc_repair;

/*	Functin to get Catalog Seq Id of the Component Seq Id
*/
FUNCTION ecrd_get_catalog_seq_id_fnc
(	p_component_seq_id	CRD_CRC_COMPONENT.COMPONENT_SEQ_ID%TYPE
)
RETURN NUMBER;

/*	To migrate CRD_CRC_SITE_REPAIR
*/
PROCEDURE	ecrd_mgrt_crd_crc_site_repair;

/*	To migrate CRD_CRC_LOC_COMPONENT
*/
PROCEDURE	ecrd_mgrt_crd_crc_loc_comp;

/*	To migrate CRD_CRC_OSB_INFC_JOB_CTRL
*/
PROCEDURE	ecrd_mgrt_osb_infc_job_ctrl;

/*	To migrate CRD_CRC_CHILD_REPAIR
*/
PROCEDURE	ecrd_mgrt_crd_crc_child_repair;

/*	To migrate CRD_CRC_REPAIR_STG
*/
PROCEDURE	ecrd_mgrt_crd_crc_repair_stg;

/*	To migrate CRD_CRC_CHILD_REPAIR_STG
*/
PROCEDURE	ecrd_crd_crc_child_repair_stg;

/*	File write function
*/
FUNCTION ecrd_file_write_fnc (L_FILENAME IN VARCHAR2,
		             L_FILEDATA IN VARCHAR2
		   	    )
RETURN NUMBER;

END ecrd_to_ecrd_data_migration;
/

CREATE OR REPLACE PACKAGE BODY ecrd_to_ecrd_data_migration
AS

	/* Global variables
	*/
	gv_eng_mdl_number	CRD_CRC_ENG_MDL_DISPLAY.ENG_MDL_NUMBER%TYPE;
	gv_module_seq_id	CRD_CRC_MODULE.MODULE_SEQ_ID%TYPE;
	gv_curr_comp_code	CRD_CRC_COMPONENT.COMPONENT_CODE%TYPE;
	gv_file_name		VARCHAR2(100);
	gv_di_filedir		VARCHAR2(100); 
	
	
	/* Object to hold COMPONENT_SEQ_ID to COMPONENT_CODE mapping
	*/
	TYPE ecrd_component_map_rec IS RECORD
	(
		module_seq_id		CRD_CRC_COMPONENT.MODULE_SEQ_ID%TYPE,
		component_code		CRD_CRC_COMPONENT.COMPONENT_CODE%TYPE
	);
	
	TYPE ecrd_component_map_tbl IS TABLE OF ecrd_component_map_rec INDEX BY BINARY_INTEGER;
	ecrd_component_map_obj ecrd_component_map_tbl;


PROCEDURE	ecrd_to_ecrd_main_prc
AS
/********************************************************************************************
Procedure Name                  : ecrd_to_ecrd_main_prc
Purpose                         : Main Procedure to mgrt the data from Old eCRD to New eCRD
Output Parameters               : None
Called Procedures/ Functions    :
Calling Procedures/ Functions   :
Author                          : Abhishek
Date                            : 20th October,2004
Ver        Date(dd/mm/yy)   Author           Description
---------  ----------       ---------------  ------------------------------------
1.0	     20/10/04		Abhishek		Created
********************************************************************************************/

	/*CURSOR	fetch_eng_model IS
	SELECT	eng.ENG_MDL_NUMBER,
		module.MODULE_SEQ_ID
	FROM	CRD_CRC_ENG_MDL_DISPLAY eng,
		CRD_CRC_MODULE module
	WHERE	eng.ENG_MDL_NUMBER = module.ENG_MDL_NUMBER;*/
	
	MRM_FileHandle 	UTL_FILE.FILE_TYPE;

BEGIN

	--FOR	rec_fetch_eng_model IN fetch_eng_model
	--LOOP
	
		/* Set global variables
		*/
		--gv_eng_mdl_number := rec_fetch_eng_model.ENG_MDL_NUMBER;
		--gv_module_seq_id := rec_fetch_eng_model.MODULE_SEQ_ID;
		
		/*MRM_FileHandle := UTL_FILE.FOPEN(gv_di_filedir,gv_di_filename,'w');
		UTL_FILE.FCLOSE(MRM_FileHandle);*/
		
		/* Migrate CRD_CRC_COMPONENT
		*/
		ecrd_mgrt_crd_crc_component();

		/* Migrate CRD_CRC_PART
		*/
		ecrd_mgrt_crd_crc_part();

		/* Populate CRD_CATALOG
		*/
		DBMS_OUTPUT.PUT_LINE('Populating CRD_E_CATALOG');
		ecrd_crd_catalog();
		DBMS_OUTPUT.PUT_LINE('Population of CRD_E_CATALOG completed');

		/* Migrate CRD_CRC_REPAIR
		*/
		DBMS_OUTPUT.PUT_LINE('Migrating CRD_CRC_REPAIR');
		ecrd_mgrt_crd_crc_repair();
		DBMS_OUTPUT.PUT_LINE('Migration of CRD_CRC_REPAIR completed');
		
		/* Migrate CRD_CRC_LOC_COMPONENT
		*/
		DBMS_OUTPUT.PUT_LINE('Migrating CRD_CRC_LOC_COMPONENT');
		ecrd_mgrt_crd_crc_loc_comp();
		DBMS_OUTPUT.PUT_LINE('Migration of CRD_CRC_LOC_COMPONENT completed');
		
		/* Migrate CRD_CRC_SITE_REPAIR
		*/
		DBMS_OUTPUT.PUT_LINE('Migrating CRD_CRC_SITE_REPAIR');
		ecrd_mgrt_crd_crc_site_repair();
		DBMS_OUTPUT.PUT_LINE('Migration of CRD_CRC_SITE_REPAIR completed');
		

		/* Migrate CRD_CRC_OSB_INFC_JOB_CTRL
		*/
		DBMS_OUTPUT.PUT_LINE('Migrating CRD_CRC_OSB_INFC_JOB_CTRL');
		ecrd_mgrt_osb_infc_job_ctrl();
		DBMS_OUTPUT.PUT_LINE('Migration of CRD_CRC_OSB_INFC_JOB_CTRL completed');

		/* Migrate CRD_CRC_CHILD_REPAIR
		*/
		DBMS_OUTPUT.PUT_LINE('Migrating CRD_CRC_CHILD_REPAIR');
		ecrd_mgrt_crd_crc_child_repair();
		DBMS_OUTPUT.PUT_LINE('Migration of CRD_CRC_CHILD_REPAIR completed');

		/* Migrate CRD_CRC_REPAIR_STG
		*/
		DBMS_OUTPUT.PUT_LINE('Migrating CRD_CRC_REPAIR_STG');
		ecrd_mgrt_crd_crc_repair_stg();
		DBMS_OUTPUT.PUT_LINE('Migration of CRD_CRC_REPAIR_STG completed');

		/* Migrate CRC_CHILD_REPAIR_STG
		*/
		DBMS_OUTPUT.PUT_LINE('Migrating CRC_CHILD_REPAIR_STG');
		ecrd_crd_crc_child_repair_stg();
		DBMS_OUTPUT.PUT_LINE('Migration CRC_CHILD_REPAIR_STG Completed Successfully');
	
	--END LOOP;

END ecrd_to_ecrd_main_prc;

PROCEDURE	ecrd_mgrt_crd_crc_component
AS
/********************************************************************************************
Procedure Name                  : ecrd_mgrt_crd_crc_component
Purpose                         : Procedure to mgrt the data 
				  from CRC_CRC_COMPONENT to CRD_COMPONENT
Output Parameters               : None
Called Procedures/ Functions    :
Calling Procedures/ Functions   :
Author                          : Abhishek
Date                            : 20th October,2004
Ver        Date(dd/mm/yy)   Author           Description
---------  ----------       ---------------  ------------------------------------
1.0	     20/10/04		Abhishek		Created
********************************************************************************************/

	CURSOR	fetch_crd_crc_component IS
	SELECT	COMPONENT_SEQ_ID,
		MODULE_SEQ_ID,
		COMPONENT_DESCRIPTION,
		COMPONENT_TYPE,
		COMPONENT_CODE,
		COMPONENT_DOCUMENT_REFERENCE,
		COMPONENT_DOC_REF_EFF_DATE,
		BASELINE_TURNAROUND_TIME,
		COMPONENT_BEGIN_DATE,
		COMPONENT_END_DATE,
		DECODE(COMPONENT_DELETE_STATUS,NULL,'Y',COMPONENT_DELETE_STATUS) ACTIVE_IND,
		CREATED_BY,
		CREATION_DATE,
		LAST_UPDATED_BY,
		LAST_UPDATE_DATE
	FROM	CRD_CRC_COMPONENT
	WHERE	COMPONENT_TYPE IN ('C', 'B')
	AND	(COMPONENT_DELETE_STATUS <> 'Y'
	OR	COMPONENT_DELETE_STATUS IS NULL);

	v_retrun_code	NUMBER;

BEGIN

	DBMS_OUTPUT.PUT_LINE('Migrating CRD_CRC_COMPONENT');
	
	FOR rec_fetch_crd_crc_component IN fetch_crd_crc_component
	LOOP
		--DBMS_OUTPUT.PUT_LINE('Component Seq Id : ' || rec_fetch_crd_crc_component.COMPONENT_SEQ_ID);
		--DBMS_OUTPUT.PUT_LINE('Module Seq Id : ' || rec_fetch_crd_crc_component.MODULE_SEQ_ID);
		--DBMS_OUTPUT.PUT_LINE('Component Code : ' || rec_fetch_crd_crc_component.COMPONENT_CODE);
		/* Set COMPONENT_SEQ_ID and COMPONENT_CODE mapping into object
		*/
		v_retrun_code := ecrd_set_comp_code_map_fnc(
						rec_fetch_crd_crc_component.COMPONENT_SEQ_ID,
						rec_fetch_crd_crc_component.MODULE_SEQ_ID,
						rec_fetch_crd_crc_component.COMPONENT_CODE
				);
				
		BEGIN
		/* Insert Record into CRD_COMPONENT
		*/
		INSERT INTO CRD_E_COMPONENT(
		       COMPONENT_CODE,
		       MODULE_SEQ_ID,
		       COMPONENT_DESCRIPTION,
		       ATA_REFERENCE_SNUM,
		       BASELINE_TAT,
		       COMPONENT_EFFECTIVE_DATE,
		       -- Removed on 10-Nov-2004
		       --ACTIVE_IND,
		       CYCLE_COUNT_CLASS,
		       QUANTITY_OF_ENGINE,
		       SHOP_VISIT_EXPOSURE_RATE,
		       SCRAP_RATE_AT_EXPOSURE,
		       SERVICEABLE_AT_EXPOSURE,
		       REPAIR_YIELD,
		       COMPONENT_END_DATE,
		       ALTERNATE_COMPONENT_IND, 
		       CREATED_BY,
		       CREATION_DATE,
		       LAST_UPDATE_DATE,
		       LAST_UPDATED_BY
		)
		VALUES(
			rec_fetch_crd_crc_component.COMPONENT_CODE,
			rec_fetch_crd_crc_component.MODULE_SEQ_ID,
			rec_fetch_crd_crc_component.COMPONENT_DESCRIPTION,
			rec_fetch_crd_crc_component.COMPONENT_DOCUMENT_REFERENCE,
			rec_fetch_crd_crc_component.BASELINE_TURNAROUND_TIME,
			rec_fetch_crd_crc_component.COMPONENT_BEGIN_DATE,
			--'Y',
			'D',
			NULL,
			NULL,
			NULL,
			NULL,
			NULL,
			rec_fetch_crd_crc_component.COMPONENT_END_DATE,
			'N',
			rec_fetch_crd_crc_component.CREATED_BY,
			rec_fetch_crd_crc_component.CREATION_DATE,
			rec_fetch_crd_crc_component.LAST_UPDATE_DATE,
			rec_fetch_crd_crc_component.LAST_UPDATED_BY
		);
		EXCEPTION WHEN DUP_VAL_ON_INDEX THEN
			DBMS_OUTPUT.PUT_LINE('Duplicate record Found for Component Seq Id : ' || rec_fetch_crd_crc_component.COMPONENT_SEQ_ID || ' Moudle Seq Id : ' || rec_fetch_crd_crc_component.MODULE_SEQ_ID || ' Component Code : ' || rec_fetch_crd_crc_component.COMPONENT_CODE);
		END;
		
	END LOOP;
	
	DBMS_OUTPUT.PUT_LINE('Migration done for CRD_CRC_COMPONENT');
	
	COMMIT;

END ecrd_mgrt_crd_crc_component;

FUNCTION	ecrd_set_comp_code_map_fnc
(
	p_component_seq_id	CRD_CRC_COMPONENT.COMPONENT_SEQ_ID%TYPE,
	p_module_seq_id		CRD_CRC_COMPONENT.MODULE_SEQ_ID%TYPE,
	p_component_code	CRD_CRC_COMPONENT.COMPONENT_CODE%TYPE
)
RETURN NUMBER
AS
/********************************************************************************************
Function Name                   : ecrd_set_comp_code_map_fnc
Purpose                         : Procedure to set COMPONENT_SEQ_ID to COMPONENT_CODE mapping
Output Parameters               : None
Called Procedures/ Functions    :
Calling Procedures/ Functions   :
Author                          : Abhishek
Date                            : 20th October,2004
Ver        Date(dd/mm/yy)   Author           Description
---------  ----------       ---------------  ------------------------------------
1.0	     20/10/04		Abhishek		Created
********************************************************************************************/

	v_stat_code	NUMBER := 0;
BEGIN
	BEGIN
		ecrd_component_map_obj(p_component_seq_id).MODULE_SEQ_ID	:= p_module_seq_id;
		ecrd_component_map_obj(p_component_seq_id).COMPONENT_CODE	:= p_component_code;
	EXCEPTION WHEN OTHERS THEN
		v_stat_code := 1;
	END;
RETURN v_stat_code;
END ecrd_set_comp_code_map_fnc;

PROCEDURE	ecrd_mgrt_crd_crc_part
AS
/********************************************************************************************
Procedure Name                  : ecrd_mgrt_crd_crc_part
Purpose                         : Procedure to mgrt the data 
				  from CRC_CRC_PART to CRD_PART
Output Parameters               : None
Called Procedures/ Functions    :
Calling Procedures/ Functions   :
Author                          : Abhishek
Date                            : 20th October,2004
Ver        Date(dd/mm/yy)   Author           Description
---------  ----------       ---------------  ------------------------------------
1.0	     20/10/04		Abhishek		Created
********************************************************************************************/
	CURSOR	fetch_crd_crc_part IS
	SELECT	PART_SEQ_ID,
		COMPONENT_SEQ_ID,
		PART_DESCRIPTION,
		PART_NUMBER,
		ALT_PART_NUMBER,
		DECODE(PART_DELETE_STATUS,NULL,'Y','N') ACTIVE_IND,
		PART_QUANTITY,
		CREATED_BY,
		CREATION_DATE,
		LAST_UPDATED_BY,
		LAST_UPDATE_DATE
	FROM	CRD_CRC_PART;
	
	v_module_seq_id		CRD_CRC_COMPONENT.MODULE_SEQ_ID%TYPE;
	v_component_code	CRD_CRC_COMPONENT.COMPONENT_CODE%TYPE;
BEGIN
	DBMS_OUTPUT.PUT_LINE('Migrating CRD_CRC_PART');
	
	FOR rec_fetch_crd_crc_part IN fetch_crd_crc_part
	LOOP
		
		BEGIN
		
		ecrd_get_comp_code_map_prc(rec_fetch_crd_crc_part.COMPONENT_SEQ_ID,
					   v_module_seq_id,
					   v_component_code);
		
		
		INSERT INTO CRD_E_PART(
			PART_NUMBER,
			PART_SEQUENCE_NUMBER,
			ACTIVE_IND,
			MODULE_SEQ_ID,
			COMPONENT_CODE,
			PART_QUANTIY,
			CREATED_BY,
			CREATION_DATE,
			LAST_UPDATED_BY,
			LAST_UPDATE_DATE
		)
		VALUES(
			rec_fetch_crd_crc_part.PART_NUMBER,
			rec_fetch_crd_crc_part.PART_SEQ_ID,
			rec_fetch_crd_crc_part.ACTIVE_IND,
			v_module_seq_id,
			v_component_code,
			rec_fetch_crd_crc_part.PART_QUANTITY,
			rec_fetch_crd_crc_part.CREATED_BY,
			rec_fetch_crd_crc_part.CREATION_DATE,
			rec_fetch_crd_crc_part.LAST_UPDATED_BY,
			rec_fetch_crd_crc_part.LAST_UPDATE_DATE     
		);
		
		EXCEPTION 
			WHEN	DUP_VAL_ON_INDEX THEN
			-- If same recod exist ignore it
				NULL;
			WHEN OTHERS THEN
			
				IF (SQLCODE = -20999) THEN
				        DBMS_OUTPUT.PUT_LINE(SQLERRM);
					DBMS_OUTPUT.PUT_LINE('Skipping Part : ' || rec_fetch_crd_crc_part.PART_NUMBER);
				END IF;
				IF (SQLCODE <> -20999) THEN
					DBMS_OUTPUT.PUT_LINE(SQLERRM);
					DBMS_OUTPUT.PUT_LINE(rec_fetch_crd_crc_part.PART_NUMBER);
					RAISE_APPLICATION_ERROR(-20999,'Skipping Part : ' || rec_fetch_crd_crc_part.PART_NUMBER);
				END IF;
                        
                                
		END;
	END LOOP;
	
	DBMS_OUTPUT.PUT_LINE('Migration done for CRD_CRC_PART');
	
	COMMIT;
	
END ecrd_mgrt_crd_crc_part;

PROCEDURE	ecrd_get_comp_code_map_prc
(	p_component_seq_id	IN	CRD_CRC_COMPONENT.COMPONENT_SEQ_ID%TYPE,
	v_module_seq_id		OUT	CRD_CRC_COMPONENT.MODULE_SEQ_ID%TYPE,
	v_component_code	OUT	CRD_CRC_COMPONENT.COMPONENT_CODE%TYPE
)
AS
/********************************************************************************************
Procedure Name                  : ecrd_get_comp_code_map_prc
Purpose                         : Procedure to get COMPONENT_SEQ_ID to COMPONENT_CODE mapping 
Output Parameters               : None
Called Procedures/ Functions    :
Calling Procedures/ Functions   :
Author                          : Abhishek
Date                            : 20th October,2004
Ver        Date(dd/mm/yy)   Author           Description
---------  ----------       ---------------  ------------------------------------
1.0	     20/10/04		Abhishek		Created
********************************************************************************************/

BEGIN
	--DBMS_OUTPUT.PUT_LINE('Component Seq Id : ' || p_component_seq_id);
	BEGIN
		v_module_seq_id := ecrd_component_map_obj(p_component_seq_id).MODULE_SEQ_ID;
		v_component_code := ecrd_component_map_obj(p_component_seq_id).COMPONENT_CODE;
	EXCEPTION WHEN NO_DATA_FOUND THEN
		DBMS_OUTPUT.PUT_LINE('Component Seq Id : ' || p_component_seq_id);
		RAISE_APPLICATION_ERROR(-20999,'Component Seq ID  not found for : ' || p_component_seq_id);
	END;

END ecrd_get_comp_code_map_prc;

PROCEDURE	ecrd_crd_catalog
AS
/********************************************************************************************
Procedure Name                  : ecrd_crd_catalog
Purpose                         : Procedure to populate CRD_CATALOG 
Output Parameters               : None
Called Procedures/ Functions    :
Calling Procedures/ Functions   :
Author                          : Abhishek
Date                            : 20th October,2004
Ver        Date(dd/mm/yy)   Author           Description
---------  ----------       ---------------  ------------------------------------
1.0	     20/10/04		Abhishek		Created
********************************************************************************************/
	CURSOR	fetch_eng_mdl_number IS
	SELECT	DISTINCT eng.ENG_MDL_NUMBER
	FROM	CRD_CRC_ENG_MDL_DISPLAY eng, 
	 	CRD_CRC_COMPONENT comp, 
	 	CRD_CRC_MODULE module 
	WHERE 	eng.ENG_MDL_NUMBER = module.ENG_MDL_NUMBER 
	AND 	module.MODULE_SEQ_ID = comp.MODULE_SEQ_ID 
	AND 	EXISTS (SELECT	rpr.RPR_SEQ_ID 
		   	FROM	CRD_CRC_REPAIR rpr 
		   	WHERE	comp.COMPONENT_SEQ_ID = rpr.COMPONENT_SEQ_ID);
	
	-- Variable to generate CATALOG_SEQ_ID
	v_catalog_seq_id	NUMBER := 1;
BEGIN
	FOR rec_fetch_eng_mdl_number IN fetch_eng_mdl_number
	LOOP
		INSERT INTO CRD_E_CATALOG(
			CATALOG_SEQ_ID,
			CATALOG_NUMBER,
			CATALOG_DESCRIPTION,
			CATALOG_EFFECTIVE_DATE,
			CATALOG_END_DATE,
			CATALOG_TYPE,
			PARENT_CATALOG_SEQ_ID,
			ACTIVE_IND,
			ENG_MDL_NUMBER,
			FLOWDOWN_CHANGES_IND,
			CALCULATED_PRICE_DEFAULT_IND,
			CREATED_BY,
			CREATION_DATE,
			LAST_UPDATED_BY,
			LAST_UPDATE_DATE
		)
		VALUES(
			v_catalog_seq_id,
			NULL,
			'2004 Catalog Migrated from Old to New eCRD',
			TO_DATE('16/01/2004','DD/MM/YYYY'),
			TO_DATE('15/01/2005','DD/MM/YYYY'),
			'D',
			NULL,
			'Y',
			rec_fetch_eng_mdl_number.ENG_MDL_NUMBER,
			NULL,
			NULL,
			'ECRD DATA ADMIN',
			SYSDATE,
			'ECRD DATA ADMIN',
			SYSDATE
		);
		v_catalog_seq_id := v_catalog_seq_id + 1;
	END LOOP;
	COMMIT;
END ecrd_crd_catalog;

PROCEDURE	ecrd_mgrt_crd_crc_repair
AS
/********************************************************************************************
Procedure Name                  : ecrd_mgrt_crd_crc_repair
Purpose                         : Procedure to migrate data
				  from CRD_CRC_REPAIR to CRD_REPAIR,CRD_REPAIR_CATALOG
Output Parameters               : None
Called Procedures/ Functions    :
Calling Procedures/ Functions   :
Author                          : Abhishek
Date                            : 20th October,2004
Ver        Date(dd/mm/yy)   Author           Description
---------  ----------       ---------------  ------------------------------------
1.0	     20/10/04		Abhishek		Created
********************************************************************************************/
	CURSOR	fetch_crd_crc_repair IS
	SELECT	RPR_SEQ_ID,
		RPR_EFFECTIVE_DATE,
		RPR_TYPE,
		COMPONENT_SEQ_ID,
		DECODE(PRICE_TYPE_SEQ_ID,1,'FFP',3,'QUOTE','4','FPL+',NULL) PRICE_TYPE,
		RPR_DESCRIPTION,
		RPR_REF_SNUM,
		RPR_DISP_SEQ_ID,
		RPR_END_DATE,
		RPR_TAT,
		RPR_TAT_INCREMENT_IND,
		RPR_PRICE,
		RPR_PRICE_INCREMENT_IND,
		RPR_COMMENT,
		RPR_OSB_UNIQUE_NUMBER,
		FUTURE_PRICE,
		FUTURE_PRICE_EFFECTIVE_DATE,
		PRICE_EFFECTIVE_DATE,
		CREATED_BY,
		CREATION_DATE,
		LAST_UPDATED_BY,
		LAST_UPDATE_DATE
	FROM	CRD_CRC_REPAIR;
	
	v_module_seq_id		CRD_CRC_COMPONENT.MODULE_SEQ_ID%TYPE;
	v_component_code	CRD_CRC_COMPONENT.COMPONENT_CODE%TYPE;
	v_catalog_seq_id	CRD_E_CATALOG.CATALOG_SEQ_ID%TYPE;
BEGIN
	FOR rec_fetch_crd_crc_repair IN fetch_crd_crc_repair
	LOOP
		
		BEGIN
		
		ecrd_get_comp_code_map_prc(rec_fetch_crd_crc_repair.COMPONENT_SEQ_ID,
					   v_module_seq_id,
					   v_component_code);
		
		/* Get Catalog Seq Id for the current Component Seq Id
		*/
		v_catalog_seq_id := ecrd_get_catalog_seq_id_fnc(rec_fetch_crd_crc_repair.COMPONENT_SEQ_ID);
		
		INSERT INTO CRD_E_REPAIR(
			REPAIR_SEQ_ID,
			REPAIR_TYPE,
			REPAIR_DESCRIPTION,
			PARENT_REPAIR_SEQ_ID,
			REPAIR_REFERENCE,
			REPAIR_COMMENTS,
			REPAIR_REFERENCE_FORMAT,
			REPAIR_EFFECTIVE_DATE,
			REPAIR_VOLUME,
			REPAIR_END_DATE,
			MODULE_SEQ_ID,
			COMPONENT_CODE,
			RPR_OSB_UNIQUE_NUMBER,
			CREATED_BY,
			CREATION_DATE,
			LAST_UPDATED_BY,
			LAST_UPDATE_DATE
		)
		VALUES(
			rec_fetch_crd_crc_repair.RPR_SEQ_ID,
			rec_fetch_crd_crc_repair.RPR_TYPE,
			rec_fetch_crd_crc_repair.RPR_DESCRIPTION,
			NULL, --For Parent repair this field will be NULL
			rec_fetch_crd_crc_repair.RPR_REF_SNUM,
			rec_fetch_crd_crc_repair.RPR_COMMENT,
			'OTHERS',
			rec_fetch_crd_crc_repair.RPR_EFFECTIVE_DATE,
			NULL,
			rec_fetch_crd_crc_repair.RPR_END_DATE,
			v_module_seq_id,
			v_component_code,
			rec_fetch_crd_crc_repair.RPR_OSB_UNIQUE_NUMBER,
			rec_fetch_crd_crc_repair.CREATED_BY,
			rec_fetch_crd_crc_repair.CREATION_DATE,
			rec_fetch_crd_crc_repair.LAST_UPDATED_BY,
			rec_fetch_crd_crc_repair.LAST_UPDATE_DATE
		);
		
		INSERT INTO CRD_E_REPAIR_CATALOG(
			REPAIR_SEQ_ID,
			CATALOG_SEQ_ID,
			EFFECTIVE_DATE,
			REPAIR_PRICE,
			INCREMENTAL_PRICE_IND,
			REPAIR_TAT,
			INCREMENTAL_TAT_IND,
			FUTURE_PRICE,
			FUTURE_EFFECTIVE_DATE,
			PRICE_TYPE,
			REPAIR_END_DATE,
			REPAIR_DISPLAY_SEQ_ID,
			FUTURE_TAT,
			PRICE_OVERWRITE_FLAG_IND,
			-- Removed on 10-Nov-2004
			--ACTIVE_IND,
			CREATED_BY,
			CREATION_DATE,
			LAST_UPDATED_BY,
			LAST_UPDATE_DATE
		)
		VALUES(
			rec_fetch_crd_crc_repair.RPR_SEQ_ID,
			v_catalog_seq_id,
			--Changed as per Prashant's mail
			TO_DATE('16/01/2004','DD/MM/YYYY'),
			rec_fetch_crd_crc_repair.RPR_PRICE,
			rec_fetch_crd_crc_repair.RPR_PRICE_INCREMENT_IND,
			rec_fetch_crd_crc_repair.RPR_TAT,
			rec_fetch_crd_crc_repair.RPR_TAT_INCREMENT_IND,
			rec_fetch_crd_crc_repair.FUTURE_PRICE,
			rec_fetch_crd_crc_repair.FUTURE_PRICE_EFFECTIVE_DATE,
			rec_fetch_crd_crc_repair.PRICE_TYPE,
			rec_fetch_crd_crc_repair.RPR_END_DATE,
			rec_fetch_crd_crc_repair.RPR_DISP_SEQ_ID,
			NULL,
			'N',
			--'Y',
			rec_fetch_crd_crc_repair.CREATED_BY,
			rec_fetch_crd_crc_repair.CREATION_DATE,
			rec_fetch_crd_crc_repair.LAST_UPDATED_BY,
			rec_fetch_crd_crc_repair.LAST_UPDATE_DATE
		);
		
		EXCEPTION WHEN OTHERS THEN
			IF (SQLCODE = -20999) THEN
				DBMS_OUTPUT.PUT_LINE('Skipping  Repair : ' || rec_fetch_crd_crc_repair.RPR_SEQ_ID);
			END IF;
			--DBMS_OUTPUT.PUT_LINE(SQLERRM);
			IF (SQLCODE <> -20999) THEN
				DBMS_OUTPUT.PUT_LINE(SQLERRM);
				RAISE_APPLICATION_ERROR(-20999,'Skipping  Repair : ' || rec_fetch_crd_crc_repair.RPR_SEQ_ID);
			END IF;
		END;
	END LOOP;
	COMMIT;
END ecrd_mgrt_crd_crc_repair;

FUNCTION ecrd_get_catalog_seq_id_fnc
(	p_component_seq_id	CRD_CRC_COMPONENT.COMPONENT_SEQ_ID%TYPE
)
RETURN NUMBER
AS
/********************************************************************************************
Function Name                   : ecrd_get_catalog_seq_id_fnc
Purpose                         : Fucntion to return Catalog Seq Id of Component Seq Id
Output Parameters               : None
Called Procedures/ Functions    :
Calling Procedures/ Functions   :
Author                          : Abhishek
Date                            : 20th October,2004
Ver        Date(dd/mm/yy)   Author           Description
---------  ----------       ---------------  ------------------------------------
1.0	     20/10/04		Abhishek		Created
********************************************************************************************/
	v_catalog_seq_id	CRD_E_CATALOG.CATALOG_SEQ_ID%TYPE;
BEGIN
	BEGIN
		SELECT	catlg.CATALOG_SEQ_ID
		INTO	v_catalog_seq_id
		FROM	CRD_E_CATALOG catlg,
			CRD_CRC_COMPONENT comp,
			CRD_CRC_MODULE module,
			CRD_CRC_ENG_MDL_DISPLAY eng
		WHERE	eng.ENG_MDL_NUMBER = catlg.ENG_MDL_NUMBER
		AND	module.ENG_MDL_NUMBER = eng.ENG_MDL_NUMBER
		AND	comp.MODULE_SEQ_ID = module.MODULE_SEQ_ID
		AND	comp.COMPONENT_SEQ_ID = p_component_seq_id;
	EXCEPTION WHEN OTHERS THEN
		dbms_output.put_line('No catalog Id found for Component Id : ' || p_component_seq_id);
		RAISE_APPLICATION_ERROR(-20999,'Catalog Id not found for Component Id : ' || p_component_seq_id);
	END;
RETURN	v_catalog_seq_id;
END ecrd_get_catalog_seq_id_fnc;


PROCEDURE	ecrd_mgrt_crd_crc_site_repair
AS
/********************************************************************************************
Procedure Name                  : ecrd_mgrt_crd_crc_site_repair
Purpose                         : Procedure to migrate data
				  from CRD_CRC_SITE_REPAIR to CRD_REPAIR_COST
Output Parameters               : None
Called Procedures/ Functions    :
Calling Procedures/ Functions   :
Author                          : Abhishek
Date                            : 20th October,2004
Ver        Date(dd/mm/yy)   Author           Description
---------  ----------       ---------------  ------------------------------------
1.0	     20/10/04		Abhishek		Created
********************************************************************************************/
	CURSOR	fetch_crd_crc_site_repair IS
	SELECT	site_repair.RPR_SEQ_ID,
		repair.COMPONENT_SEQ_ID,
		LOCATION_ID,
		LABOR_HOURS,
		MATERIAL_COST,
		site_repair.CREATED_BY,
		site_repair.CREATION_DATE,
		site_repair.LAST_UPDATED_BY,
		site_repair.LAST_UPDATE_DATE
	FROM	CRD_CRC_REPAIR repair,
		CRD_CRC_SITE_REPAIR site_repair
	WHERE	site_repair.RPR_SEQ_ID = repair.RPR_SEQ_ID;		
	
	v_module_seq_id		CRD_CRC_COMPONENT.MODULE_SEQ_ID%TYPE;
	v_component_code	CRD_CRC_COMPONENT.COMPONENT_CODE%TYPE;
		
BEGIN
	FOR rec_fetch_crd_crc_site_repair IN fetch_crd_crc_site_repair
	LOOP
		BEGIN
		
		ecrd_get_comp_code_map_prc(rec_fetch_crd_crc_site_repair.COMPONENT_SEQ_ID,
					   v_module_seq_id,
					   v_component_code);
		INSERT INTO CRD_E_REPAIR_COST(
			REPAIR_SEQ_ID,
			MATERIAL_COST,
			LABOUR_HOURS,
			MODULE_SEQ_ID,
			COMPONENT_CODE,
			LOCATION_ID,
			CREATED_BY,
			CREATION_DATE,
			LAST_UPDATED_BY,
			LAST_UPDATE_DATE
		)
		VALUES
		(
			rec_fetch_crd_crc_site_repair.RPR_SEQ_ID,
			rec_fetch_crd_crc_site_repair.MATERIAL_COST,
			rec_fetch_crd_crc_site_repair.LABOR_HOURS,
			v_module_seq_id,
			v_component_code,
			rec_fetch_crd_crc_site_repair.LOCATION_ID,
			rec_fetch_crd_crc_site_repair.CREATED_BY,
			rec_fetch_crd_crc_site_repair.CREATION_DATE,
			rec_fetch_crd_crc_site_repair.LAST_UPDATED_BY,
			rec_fetch_crd_crc_site_repair.LAST_UPDATE_DATE
		);
		
		EXCEPTION WHEN OTHERS THEN
			IF (SQLCODE = -20999) THEN
				DBMS_OUTPUT.PUT_LINE('Skipping Repair : ' || rec_fetch_crd_crc_site_repair.RPR_SEQ_ID);
			END IF;
			--Uncomment the code afterwards
			--IF (SQLCODE <> -20999) THEN
			--	DBMS_OUTPUT.PUT_LINE(SQLERRM);
			--	RAISE_APPLICATION_ERROR(-20999,'Migrating to Site Repair.Skipping Repair : ' || rec_fetch_crd_crc_site_repair.RPR_SEQ_ID);
			--END IF;
		END;
	END LOOP;
	COMMIT;
END ecrd_mgrt_crd_crc_site_repair;

PROCEDURE	ecrd_mgrt_crd_crc_loc_comp
AS
/********************************************************************************************
Procedure Name                  : ecrd_mgrt_crd_crc_loc_comp
Purpose                         : Procedure to migrate data
				  from CRD_CRC_LOC_COMPONENT to CRD_COMPONENT_LOCATION
Output Parameters               : None
Called Procedures/ Functions    :
Calling Procedures/ Functions   :
Author                          : Abhishek
Date                            : 20th October,2004
Ver        Date(dd/mm/yy)   Author           Description
---------  ----------       ---------------  ------------------------------------
1.0	     20/10/04		Abhishek		Created
********************************************************************************************/
	CURSOR	fetch_crd_crc_loc_comp IS
	SELECT	LOCATION_ID,
		COMPONENT_SEQ_ID,
		NVL(DISPLAY_ORDER,1) DISPLAY_ORDER,
		DECODE(LOC_COMP_DELETE_STATUS,NULL,'Y','N') ACTIVE_IND,
		CREATED_BY,
		CREATION_DATE,
		LAST_UPDATED_BY,
		LAST_UPDATE_DATE
	FROM	CRD_CRC_LOC_COMPONENT;
	
	v_module_seq_id		CRD_CRC_COMPONENT.MODULE_SEQ_ID%TYPE;
	v_component_code	CRD_CRC_COMPONENT.COMPONENT_CODE%TYPE;
BEGIN
	FOR rec_fetch_crd_crc_loc_comp IN fetch_crd_crc_loc_comp
	LOOP
		BEGIN
		
		ecrd_get_comp_code_map_prc(rec_fetch_crd_crc_loc_comp.COMPONENT_SEQ_ID,
					   v_module_seq_id,
					   v_component_code);
		INSERT INTO CRD_E_COMPONENT_LOCATION(
			ACTIVE_IND,
			SITE_SEQUENCE_NUMBER,
			MODULE_SEQ_ID,
			COMPONENT_CODE,
			LOCATION_ID,
			HIDE_COMPONENT_IND,
			CREATED_BY,
			CREATION_DATE,
			LAST_UPDATED_BY,
			LAST_UPDATE_DATE		
		)
		VALUES(
			rec_fetch_crd_crc_loc_comp.ACTIVE_IND,
			rec_fetch_crd_crc_loc_comp.DISPLAY_ORDER,
			v_module_seq_id,
			v_component_code,
			rec_fetch_crd_crc_loc_comp.LOCATION_ID,
			NULL,
			rec_fetch_crd_crc_loc_comp.CREATED_BY,
			rec_fetch_crd_crc_loc_comp.CREATION_DATE,
			rec_fetch_crd_crc_loc_comp.LAST_UPDATED_BY,
			rec_fetch_crd_crc_loc_comp.LAST_UPDATE_DATE
		);
		
		EXCEPTION WHEN DUP_VAL_ON_INDEX THEN
				-- Ignore the record
				NULL;
				
			  WHEN OTHERS THEN
				IF (SQLCODE = -20999) THEN
					DBMS_OUTPUT.PUT_LINE('Skipping Location : ' || rec_fetch_crd_crc_loc_comp.LOCATION_ID || ' and Component : ' || v_component_code);
				END IF;

				IF (SQLCODE <> -20999) THEN
					DBMS_OUTPUT.PUT_LINE(SQLERRM);
					RAISE_APPLICATION_ERROR(-20999,'Migrating to Component Location.Location : ' || rec_fetch_crd_crc_loc_comp.LOCATION_ID || ' and Component Seq Id : ' || rec_fetch_crd_crc_loc_comp.COMPONENT_SEQ_ID);
				END IF;
		END;
	END LOOP;
	COMMIT;

END ecrd_mgrt_crd_crc_loc_comp;

PROCEDURE	ecrd_mgrt_osb_infc_job_ctrl
AS
/********************************************************************************************
Procedure Name                  : ecrd_mgrt_crd_crc_loc_comp
Purpose                         : Procedure to migrate data
				  from CRD_CRC_LOC_COMPONENT to CRD_COMPONENT_LOCATION
Output Parameters               : None
Called Procedures/ Functions    :
Calling Procedures/ Functions   :
Author                          : Abhishek
Date                            : 20th October,2004
Ver        Date(dd/mm/yy)   Author           Description
---------  ----------       ---------------  ------------------------------------
1.0	     20/10/04		Abhishek		Created
********************************************************************************************/
	CURSOR	fetch_crd_crc_osb_infc_job IS
	SELECT	OSB_INFC_JOB_CTRL_SEQ_ID OSB_INFC_JOB_CTRL_SEQ_ID,
		LOCATION_ID,
		JOB_CTRL_IND,
		JOB_START_DATE,
		JOB_END_DATE
	FROM	CRD_CRC_OSB_INFC_JOB_CTRL;
BEGIN
	FOR rec_fetch_crd_crc_osb_infc_job IN fetch_crd_crc_osb_infc_job
	LOOP
		INSERT INTO CRD_E_OSB_JOBS(
			JOB_SEQUENCE_IDENTIFIER,
			JOB_INDICATOR,
			JOB_START_DATE,
			JOB_END_DATE,
			LOCATION_ID,
			CREATED_BY,
			CREATION_DATE,
			LAST_UPDATED_BY,
			LAST_UPDATE_DATE
		)
		VALUES(
			to_number(rec_fetch_crd_crc_osb_infc_job.OSB_INFC_JOB_CTRL_SEQ_ID),
			rec_fetch_crd_crc_osb_infc_job.JOB_CTRL_IND,
			rec_fetch_crd_crc_osb_infc_job.JOB_START_DATE,
			rec_fetch_crd_crc_osb_infc_job.JOB_END_DATE,
			rec_fetch_crd_crc_osb_infc_job.LOCATION_ID,
			'ECRD DATA ADMIN',
			SYSDATE,
			'ECRD DATA ADMIN',
			SYSDATE
		);
	END LOOP;
	COMMIT;
END ecrd_mgrt_osb_infc_job_ctrl;

PROCEDURE	ecrd_mgrt_crd_crc_child_repair
AS
/********************************************************************************************
Procedure Name                  : ecrd_mgrt_crd_crc_child_repair
Purpose                         : Procedure to migrate data
				  from CRD_CRC_CHILD_REPAIR to CRD_REPAIR_CATALOG
Output Parameters               : None
Called Procedures/ Functions    :
Calling Procedures/ Functions   :
Author                          : Abhishek
Date                            : 20th October,2004
Ver        Date(dd/mm/yy)   Author           Description
---------  ----------       ---------------  ------------------------------------
1.0	     20/10/04		Abhishek		Created
********************************************************************************************/
	CURSOR	fetch_crd_crc_child_repair IS
	SELECT	child_repair.CHLD_RPR_SEQ_ID,
		child_repair.RPR_SEQ_ID PARENT_REPAIR_SEQ_ID,
		repair.RPR_EFFECTIVE_DATE,
		repair.RPR_OSB_UNIQUE_NUMBER,
		repair.PRICE_EFFECTIVE_DATE,
		repair.RPR_END_DATE,
		repair.COMPONENT_SEQ_ID,
		child_repair.CHLD_RPR_DESC,
		child_repair.CHLD_REF_SNUM,
		child_repair.CHLD_DISP_SEQ_ID,
		child_repair.CHLD_RPR_COMMENT,
		child_repair.CREATED_BY,
		child_repair.CREATION_DATE,
		child_repair.LAST_UPDATED_BY,
		child_repair.LAST_UPDATE_DATE
	FROM	CRD_CRC_CHILD_REPAIR child_repair,
		CRD_CRC_REPAIR repair
	WHERE	child_repair.RPR_SEQ_ID = repair.RPR_SEQ_ID;
	
	v_module_seq_id		CRD_CRC_COMPONENT.MODULE_SEQ_ID%TYPE;
	v_component_code	CRD_CRC_COMPONENT.COMPONENT_CODE%TYPE;
	v_catalog_seq_id	CRD_E_CATALOG.CATALOG_SEQ_ID%TYPE;
	v_rpr_seq_id		NUMBER;
BEGIN
	SELECT MAX(REPAIR_SEQ_ID) + 1
	INTO   v_rpr_seq_id
	FROM   CRD_E_REPAIR;
	
	FOR rec_fetch_crd_crc_child_repair IN fetch_crd_crc_child_repair
	LOOP
		BEGIN
		
		ecrd_get_comp_code_map_prc(rec_fetch_crd_crc_child_repair.COMPONENT_SEQ_ID,
					   v_module_seq_id,
					   v_component_code);
					   
		/* Get Catalog Seq Id for the current Component Seq Id
		*/
		v_catalog_seq_id := ecrd_get_catalog_seq_id_fnc(rec_fetch_crd_crc_child_repair.COMPONENT_SEQ_ID);
		
		--DBMS_OUTPUT.PUT_LINE('Rpr Seq Id : ' || rec_fetch_crd_crc_child_repair.CHLD_RPR_SEQ_ID);
		
		
		INSERT INTO CRD_E_REPAIR(
			REPAIR_SEQ_ID,
			REPAIR_TYPE,
			REPAIR_DESCRIPTION,
			PARENT_REPAIR_SEQ_ID,
			REPAIR_REFERENCE,
			REPAIR_COMMENTS,
			REPAIR_REFERENCE_FORMAT,
			REPAIR_EFFECTIVE_DATE,
			REPAIR_VOLUME,
			REPAIR_END_DATE,
			MODULE_SEQ_ID,
			COMPONENT_CODE,
			RPR_OSB_UNIQUE_NUMBER,
			CREATED_BY,
			CREATION_DATE,
			LAST_UPDATED_BY,
			LAST_UPDATE_DATE
		)
		VALUES(
			v_rpr_seq_id,
			'CR',
			rec_fetch_crd_crc_child_repair.CHLD_RPR_DESC,
			rec_fetch_crd_crc_child_repair.PARENT_REPAIR_SEQ_ID,
			rec_fetch_crd_crc_child_repair.CHLD_REF_SNUM,
			rec_fetch_crd_crc_child_repair.CHLD_RPR_COMMENT,
			'OTHERS',
			rec_fetch_crd_crc_child_repair.RPR_EFFECTIVE_DATE,
			NULL,
			rec_fetch_crd_crc_child_repair.RPR_END_DATE,
			v_module_seq_id,
			v_component_code,
			rec_fetch_crd_crc_child_repair.RPR_OSB_UNIQUE_NUMBER,
			rec_fetch_crd_crc_child_repair.CREATED_BY,
			rec_fetch_crd_crc_child_repair.CREATION_DATE,
			rec_fetch_crd_crc_child_repair.LAST_UPDATED_BY,
			rec_fetch_crd_crc_child_repair.LAST_UPDATE_DATE
		);
		
		INSERT INTO CRD_E_REPAIR_CATALOG(
			REPAIR_SEQ_ID,
			CATALOG_SEQ_ID,
			EFFECTIVE_DATE,
			REPAIR_PRICE,
			INCREMENTAL_PRICE_IND,
			REPAIR_TAT,
			INCREMENTAL_TAT_IND,
			FUTURE_PRICE,
			FUTURE_EFFECTIVE_DATE,
			PRICE_TYPE,
			REPAIR_END_DATE,
			REPAIR_DISPLAY_SEQ_ID,
			FUTURE_TAT,
			PRICE_OVERWRITE_FLAG_IND,
			-- Removed on 10-Nov-2004
			--ACTIVE_IND,
			CREATED_BY,
			CREATION_DATE,
			LAST_UPDATED_BY,
			LAST_UPDATE_DATE
		)
		VALUES(
			v_rpr_seq_id,
			v_catalog_seq_id,
			--Changed as per Prashant's mail
			TO_DATE('16/01/2004','DD/MM/YYYY'),
			NULL,
			NULL,
			NULL,
			NULL,
			NULL,
			NULL,
			NULL,
			rec_fetch_crd_crc_child_repair.RPR_END_DATE,
			rec_fetch_crd_crc_child_repair.CHLD_DISP_SEQ_ID,
			NULL,
			NULL,
			--'Y',
			rec_fetch_crd_crc_child_repair.CREATED_BY,
			rec_fetch_crd_crc_child_repair.CREATION_DATE,
			rec_fetch_crd_crc_child_repair.LAST_UPDATED_BY,
			rec_fetch_crd_crc_child_repair.LAST_UPDATE_DATE
		);
		
		v_rpr_seq_id := v_rpr_seq_id + 1;
		
		EXCEPTION WHEN OTHERS THEN
			IF (SQLCODE = -20999) THEN
				DBMS_OUTPUT.PUT_LINE('Skipping Child Repair Seq Id : ' || rec_fetch_crd_crc_child_repair.CHLD_RPR_SEQ_ID);
			END IF;
			IF (SQLCODE <> -20999) THEN
				DBMS_OUTPUT.PUT_LINE(SQLERRM);
				RAISE_APPLICATION_ERROR(-20999,'Migrating Child Repairs.Skipping Child Repair Seq Id : ' || rec_fetch_crd_crc_child_repair.CHLD_RPR_SEQ_ID);
			END IF;
		END;
		
	END LOOP;
	COMMIT;
END ecrd_mgrt_crd_crc_child_repair;

PROCEDURE	ecrd_mgrt_crd_crc_repair_stg
AS
/********************************************************************************************
Procedure Name                  : ecrd_mgrt_crd_crc_repair_stg
Purpose                         : Procedure to migrate data
				  from CRD_CRC__REPAIR_STG to CRD_REPAIR_HISTORY,
				                              CRD_REPAIR_CATALOG_HISTORY
Output Parameters               : None
Called Procedures/ Functions    :
Calling Procedures/ Functions   :
Author                          : Abhishek
Date                            : 20th October,2004
Ver        Date(dd/mm/yy)   Author           Description
---------  ----------       ---------------  ------------------------------------
1.0	     20/10/04		Abhishek		Created
********************************************************************************************/
	CURSOR	fetch_crd_crc_repair_stg IS
	SELECT	RPR_STG_SEQ_ID,
		RPR_EFFECTIVE_DATE,
		RPR_TYPE,
		COMPONENT_SEQ_ID,
		PRICE_TYPE_SEQ_ID,
		RPR_DESCRIPTION,
		RPR_REF_SNUM,
		RPR_DISP_SEQ_ID,
		RPR_END_DATE,
		RPR_TAT,
		RPR_TAT_INCREMENT_IND,
		RPR_PRICE,
		RPR_PRICE_INCREMENT_IND,
		RPR_COMMENT,
		RPR_SEQ_ID,
		COMPONENT_STG_SEQ_ID,
		FUTURE_PRICE,
		FUTURE_PRICE_EFFECTIVE_DATE,
		CREATED_BY,
		CREATION_DATE,
		LAST_UPDATED_BY,
		LAST_UPDATE_DATE
	FROM	CRD_CRC_REPAIR_STG;
	
	v_module_seq_id		CRD_CRC_COMPONENT.MODULE_SEQ_ID%TYPE;
	v_component_code	CRD_CRC_COMPONENT.COMPONENT_CODE%TYPE;
BEGIN
	FOR rec_fetch_crd_crc_repair_stg IN fetch_crd_crc_repair_stg
	LOOP
		NULL;
		
		/*ecrd_get_comp_code_map_prc(rec_fetch_crd_crc_child_repair.COMPONENT_SEQ_ID,
					   v_module_seq_id,
					   v_component_code);
				
		INSERT INTO CRD_E_REPAIR_HISTORY(
			STAGING_HISTORY_IND,
			COMPONENT_CODE,
			CHANGE_START_DATE,
			REPAIR_SEQ_ID,
			REPAIR_TYPE,
			REPAIR_DESCRIPTION,
			REPAIR_REFERENCE,
			REPAIR_COMMENTS,
			ACTIVE_IND,
			REPAIR_REFERENCE_FORMAT,
			REPAIR_EFFECTIVE_DATE,
			REPAIR_END_DATE,
			REQUESTED_BY,
			APPROVED_REJECTED_BY,
			REQUESTED_DATE,
			APPROVED_REJECTED_DATE,
			REPAIR_VOLUMN,
			APPROVE_REJECT_STATUS,
			REJECTION_COMMENTS,
			CREATED_BY,
			CREATION_DATE,
			LAST_UPDATED_BY,
			LAST_UPDATE_DATE
		)
		VALUES(
			'Y', --Confirm this
			v_component_code,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
		);
		
		INSERT INTO CRD_E_REPAIR_CATALOG_HIST(
			EFFECTIVE_DATE,
			REPAIR_PRICE,
			CHANGE_START_DATE,
			HISTORY_STAGING_INDICATOR,
			INCREMENTAL_PRICE_IND,
			REPAIR_TAT,
			INCREMENTAL_TAT_IND,
			FUTURE_PRICE,
			FUTURE_EFFECTIVE_DATE,
			PRICE_TYPE,
			REPAIR_END_DATE,
			ACTIVE_IND,
			FUTURE_TAT,
			REPAIR_SEQ_ID,
			CATALOG_SEQ_ID,
			REPAIR_DISPLAY_SEQ_ID,
			REQUESTED_BY,
			REQUESTED_DATE,
			APPROV_REJECT_BY,
			APPROVED_REJECTED_DATE,
			APPROVE_REJECT_STATUS,
			REJECTION_COMMENTS,		
			CREATED_BY,
			CREATION_DATE,
			LAST_UPDATED_BY,
			LAST_UPDATE_DATE
		)
		VALUES(
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
			rec_fetch_crd_crc_repair_stg.,
		);*/
	END LOOP;
	COMMIT;
END ecrd_mgrt_crd_crc_repair_stg;

PROCEDURE	ecrd_crd_crc_child_repair_stg
AS
BEGIN
NULL;
END ecrd_crd_crc_child_repair_stg;

FUNCTION

ecrd_file_write_fnc (L_FILENAME IN VARCHAR2,
		     L_FILEDATA IN VARCHAR2
	   	    )

RETURN NUMBER

/*
********************************************************************
* System     :  MRM
*
* Purpose    :  to write the data to filename specified.
*
* Description:  FILENAME and FILEDATA are parameters passed to this
*		function. FILENAME is opened in APPEND mode and the
*		FILEDATA is written to opened file using PUTLINE.
*		this function will return 1 if sucessfull else -1.
*
*
* Created by :   PCS
********************************************************************
*/

IS

MRM_FileHandle 	UTL_FILE.FILE_TYPE;
L_FILEPATH		VARCHAR2(50);
L_SUCESS		NUMBER;

BEGIN

--	L_FILEPATH := '/export/home/sssuser' ;
	L_FILEPATH :=  gv_di_filedir;

	 begin

		 MRM_FileHandle := UTL_FILE.FOPEN(L_FILEPATH,L_FILENAME,'a');
		 if UTL_FILE.IS_OPEN(MRM_FileHandle) then
			  UTL_FILE.PUT_LINE(MRM_FileHandle, L_FILEDATA);
			  UTL_FILE.FCLOSE(MRM_FileHandle);
			  L_SUCESS := 1;
		 end if;

		EXCEPTION
		WHEN UTL_FILE.INVALID_PATH THEN
			--------dbms_OUTPUT.PUT_LINE('FOPEN FAILED. Invalid FILENAME/LOCATION.');
			--------dbms_OUTPUT.PUT_LINE('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~');
			--------dbms_OUTPUT.PUT_LINE('Directory OR Filename is invalid or inaccessible...');
			L_SUCESS := -1;

		WHEN UTL_FILE.INVALID_MODE THEN
			--------dbms_OUTPUT.PUT_LINE('FOPEN FAILED. File may already be open in WRITE mode.');
			--------dbms_OUTPUT.PUT_LINE('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~');
			--------dbms_OUTPUT.PUT_LINE('Invalid sting specified for file mode...');
			L_SUCESS := -1;

		WHEN UTL_FILE.INVALID_OPERATION THEN
			--------dbms_OUTPUT.PUT_LINE('FOPEN FAILED. Invalid file operation.');
			--------dbms_OUTPUT.PUT_LINE('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~');
			--------dbms_OUTPUT.PUT_LINE('File cound not be opened as requested, possibly insufficient permissions...');
			L_SUCESS := -1;

		WHEN UTL_FILE.INVALID_FILEHANDLE THEN
			--------dbms_OUTPUT.PUT_LINE('FOPEN FAILED. Invalid FILEHANDLE.');
			--------dbms_OUTPUT.PUT_LINE('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~');
			--------dbms_OUTPUT.PUT_LINE('File handle does not specify an open file...');
			L_SUCESS := -1;

		WHEN UTL_FILE.WRITE_ERROR THEN
			--------dbms_OUTPUT.PUT_LINE('FWRITE FAILED. Invalid FILE WRITE.');
			--------dbms_OUTPUT.PUT_LINE('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~');
			--------dbms_OUTPUT.PUT_LINE('Operating system error while writing...');
			L_SUCESS := -1;

		WHEN UTL_FILE.INTERNAL_ERROR THEN
			--------dbms_OUTPUT.PUT_LINE('PL/SQL INTERNAL ERROR.');
			--------dbms_OUTPUT.PUT_LINE('~~~~~~~~~~~~~~~~~~~~~~~');
			--------dbms_OUTPUT.PUT_LINE('Unspecified internal error...');
			L_SUCESS := -1;

		WHEN OTHERS THEN
			--------dbms_OUTPUT.PUT_LINE(L_FILEDATA);
			--------dbms_OUTPUT.PUT_LINE('Could not generate ExceptionLog file.');
			--------dbms_OUTPUT.PUT_LINE('Exception: <'||to_char(sqlcode)||'>,<'||sqlerrm(sqlcode)||'>') ;
			L_SUCESS := -1;

	end;

	RETURN(L_SUCESS);

END ecrd_file_write_fnc;


END ecrd_to_ecrd_data_migration;
/

