CREATE OR REPLACE PACKAGE ecrd_approval_pkg
/***********************************************************************/
--
-- Copyright Message       : Copyright(c) 2004 GE Aircraft Engines
-- Title                   : ecrd_approval_pkg
-- Author                  : Patni Offshore
-- Company                 : GE Aircraft Engines
-- Date                    : October 2004
-- Purpose                 : File contains Package Spec and body for Procs
--                           for Componenet,Sites and Repair Approvals
--
-- Modifications           :
-- Date                    Description
-- [DD-MMM-YYYY]           A brief description of change should go here like
--                         who had made change, why change was implemented
--                         and where change is made.
--
-- 12-oct-2004                New Code First Version
-- 04-Sep-2006                Patni Team - Modified ecrd_appr_new_ind_rep_prc,                                         
--                                         ecrd_appr_new_grp_rep_prc,
--                                         ecrd_approve_ind_repair_prc,
--                                         ecrd_appr_grp_repair_prc
--
/***********************************************************************/

AS

TYPE result_cursor IS REF CURSOR;
/***********************************************************************/
-- Procedure Name                : ecrd_apprv_get_comp_list_prc
-- Purpose                       : This procedure is used to get list of component pending for approval
-- Input Parameters              : None
-- Output Parameters             : p_out_component_list_cur result_cursor
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_apprv_get_comp_list_prc
(
   p_in_user_role IN     VARCHAR2,
   p_in_user_id         IN    crd_e_component.CREATED_BY%TYPE,
   p_out_component_list_cur OUT result_cursor
);


/***********************************************************************/
-- Procedure Name                : ecrd_approve_component
-- Purpose                      : This procedure is used to approve components
-- Input Parameters             : p_in_component_code  IN   crd_e_component.component_code%TYPE,
-- Input Parameters             : p_in_component_desc  IN   crd_e_component.component_description%TYPE,
-- Input Parameters             : p_in_model_code      IN   crd_e_component_history.engine_model_code%TYPE,
-- Input Parameters             : p_in_module_id       IN   crd_e_component.module_seq_id%TYPE,
-- Input Parameters             : p_in_ata_ref_snum    IN   crd_e_component.ata_reference_snum%TYPE,
-- Input Parameters             : p_in_base_tat        IN   crd_e_component.baseline_tat%TYPE,
-- Input Parameters             : p_in_comp_eff_date   IN   VARCHAR2,
-- Input Parameters             : p_in_cycle           IN   crd_e_component.cycle_count_class%TYPE,
-- Input Parameters             : p_in_qty_engine      IN   crd_e_component.quantity_of_engine%TYPE,
-- Input Parameters             : p_in_sv_rate_exp     IN   crd_e_component.shop_visit_exposure_rate%TYPE,
-- Input Parameters             : p_in_scrap_rate_exp  IN   crd_e_component.scrap_rate_at_exposure%TYPE,
-- Input Parameters             : p_in_service_exp     IN   crd_e_component.SERVICEABLE_AT_EXPOSURE%TYPE,
-- Input Parameters             : p_in_repair_yld      IN   crd_e_component.REPAIR_YIELD%TYPE,
-- Input Parameters             : p_in_user_id         IN   crd_e_component.CREATED_BY%TYPE,
-- Input Parameters             : p_in_approv_type     IN   VARCHAR2,
-- Output Parameters            : p_out_message        OUT  VARCHAR2
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_approve_component
(
   p_in_component_code  IN    crd_e_component.component_code%TYPE,
   p_in_component_desc  IN    crd_e_component.component_description%TYPE,
   p_in_model_code        IN  VARCHAR2,
   p_in_module_id       IN    VARCHAR2,
   p_in_ata_ref_snum    IN    crd_e_component.ata_reference_snum%TYPE,
   p_in_base_tat       IN  crd_e_component.baseline_tat%TYPE,
   p_in_comp_eff_date   IN    VARCHAR2,
   p_in_cycle           IN    crd_e_component.cycle_count_class%TYPE,
   p_in_qty_engine      IN    crd_e_component.quantity_of_engine%TYPE,
   p_in_sv_rate_exp     IN    crd_e_component.shop_visit_exposure_rate%TYPE,
   p_in_scrap_rate_exp  IN    crd_e_component.scrap_rate_at_exposure%TYPE,
   p_in_service_exp     IN    crd_e_component.SERVICEABLE_AT_EXPOSURE%TYPE,
   p_in_repair_yld      IN    crd_e_component.REPAIR_YIELD%TYPE,
   p_in_alternate_component IN   crd_e_component.ALTERNATE_COMPONENT_IND%TYPE,
   p_in_user_id         IN    crd_e_component.CREATED_BY%TYPE,
   p_in_approv_type     IN    VARCHAR2,

   p_out_message       OUT    VARCHAR2
);


/***********************************************************************/
-- Procedure Name               : ecrd_approve_new_component_prc
-- Purpose                      : This procedure is used to approve new components
-- Input Parameters             : p_in_component_code  IN   crd_e_component.component_code%TYPE,
-- Input Parameters             : p_in_component_desc  IN   crd_e_component.component_description%TYPE,
-- Input Parameters             : p_in_model_code      IN   crd_e_component_history.engine_model_code%TYPE,
-- Input Parameters             : p_in_module_id       IN   crd_e_component.module_seq_id%TYPE,
-- Input Parameters             : p_in_ata_ref_snum    IN   crd_e_component.ata_reference_snum%TYPE,
-- Input Parameters             : p_in_base_tat        IN   crd_e_component.baseline_tat%TYPE,
-- Input Parameters             : p_in_comp_eff_date   IN   VARCHAR2,
-- Input Parameters             : p_in_cycle           IN   crd_e_component.cycle_count_class%TYPE,
-- Input Parameters             : p_in_qty_engine      IN   crd_e_component.quantity_of_engine%TYPE,
-- Input Parameters             : p_in_sv_rate_exp     IN   crd_e_component.shop_visit_exposure_rate%TYPE,
-- Input Parameters             : p_in_scrap_rate_exp  IN   crd_e_component.scrap_rate_at_exposure%TYPE,
-- Input Parameters             : p_in_service_exp     IN   crd_e_component.SERVICEABLE_AT_EXPOSURE%TYPE,
-- Input Parameters             : p_in_repair_yld      IN   crd_e_component.REPAIR_YIELD%TYPE,
-- Input Parameters             : p_in_user_id         IN   crd_e_component.CREATED_BY%TYPE,
-- Input Parameters             : p_in_repair_buff     IN   LONG,
-- Input Parameters             : p_in_comp_site_buff  IN   LONG,
-- Input Parameters             : p_in_comp_part_buff  IN   LONG,
-- Output Parameters            : p_out_message        OUT  VARCHAR2
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_approve_new_component_prc
(
   p_in_component_code  IN    crd_e_component.component_code%TYPE,
   p_in_component_desc  IN    crd_e_component.component_description%TYPE,
   p_in_model_code        IN  crd_e_component_history.engine_model_code%TYPE,
   p_in_module_id       IN    VARCHAR2,
   p_in_ata_ref_snum    IN    crd_e_component.ata_reference_snum%TYPE,
   p_in_base_tat       IN  crd_e_component.baseline_tat%TYPE,
   p_in_comp_eff_date   IN    VARCHAR2,
   p_in_cycle           IN    crd_e_component.cycle_count_class%TYPE,
   p_in_qty_engine      IN    crd_e_component.quantity_of_engine%TYPE,
   p_in_sv_rate_exp     IN    crd_e_component.shop_visit_exposure_rate%TYPE,
   p_in_scrap_rate_exp  IN    crd_e_component.scrap_rate_at_exposure%TYPE,
   p_in_service_exp     IN    crd_e_component.SERVICEABLE_AT_EXPOSURE%TYPE,
   p_in_repair_yld      IN    crd_e_component.REPAIR_YIELD%TYPE,
   p_in_alternate_component IN   crd_e_component.ALTERNATE_COMPONENT_IND%TYPE,
   p_in_user_id         IN    crd_e_component.CREATED_BY%TYPE,
-- p_in_approv_type     IN    VARCHAR2,
   p_in_repair_buff     IN    LONG,
   p_in_comp_site_buff  IN    LONG,
   p_in_comp_part_buff  IN    LONG,
   p_out_message       OUT    VARCHAR2
);
/***********************************************************************/
-- Procedure Name                : ecrd_reject_component
-- Purpose                       : This procedure is used to reject component pending for approval
-- Input Parameters              : p_in_component_code  IN  crd_e_component.component_code%TYPE,
-- Input Parameters              : p_in_module_id       IN  crd_e_component.module_seq_id%TYPE,
-- Input Parameters              : p_in_user_id         IN  crd_e_component.CREATED_BY%TYPE,
-- Input Parameters              : p_in_reject_comm     IN  crd_e_component_history.rejection_comments%TYPE,

-- Output Parameters             : p_out_message        OUT    VARCHAR2
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_reject_component
(
   p_in_component_code  IN    crd_e_component.component_code%TYPE,
   p_in_module_id       IN    crd_e_component.module_seq_id%TYPE,
   p_in_user_id         IN    crd_e_component.CREATED_BY%TYPE,
   p_in_reject_comm     IN    crd_e_component_history.rejection_comments%TYPE,

/* p_in_approv_type     IN    VARCHAR2,       */
   p_out_message       OUT    VARCHAR2
);

/***********************************************************************/
-- Procedure Name                : ecrd_comp_appr_req_details_prc
-- Purpose                       : This procedure is used to get details of the component for approval.
-- Input Parameters              : p_in_component_code  IN  crd_e_component.component_code%TYPE,
-- Input Parameters              : p_in_module_id       IN  crd_e_component.module_seq_id%TYPE,

-- Output Parameters             : p_out_comp_appr_det_cur OUT result_cursor
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_comp_appr_req_details_prc
(
   p_in_module_seq_id   IN VARCHAR2,
   p_in_component_code  IN crd_e_component_history.component_code%TYPE,
   p_out_comp_appr_det_cur OUT   result_cursor
);

/***********************************************************************/
-- Procedure Name                : ecrd_is_comp_req_pend_prc
-- Purpose                       : This procedure is used to check if the approval for a component is pending or not.
-- Input Parameters              : p_in_component_code  IN  crd_e_component.component_code%TYPE,
-- Input Parameters              : p_in_module_id       IN  crd_e_component.module_seq_id%TYPE,

-- Output Parameters             : p_out_msg         OUT         VARCHAR2
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_is_comp_req_pend_prc
(
 p_in_comp_code    IN          crd_e_component_history.component_code%TYPE,
 p_in_module_code  IN          crd_e_component_history.module_seq_id%TYPE,
 p_out_msg         OUT         VARCHAR2
);


/***********************************************************************/
-- Procedure Name                : ecrd_get_tc_csm_mail
-- Purpose                       : This procedure is used to get the mail addresses of all TCs located at the all component sites..
-- Input Parameters              : p_in_component_code  IN  crd_e_component.component_code%TYPE,
-- Input Parameters              : p_in_module_id       IN  crd_e_component.module_seq_id%TYPE,

-- Output Parameters             : p_out_mail_addr    OUT      result_cursor
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_get_tc_csm_mail(
p_in_component_code  IN    crd_e_comp_location_hist.component_code%TYPE,
p_in_module_code  IN    crd_e_comp_location_hist.module_seq_id%TYPE,
p_out_mail_addr      OUT      result_cursor
);


/***********************************************************************/
-- Procedure Name                : ecrd_get_apprv_repair_list
-- Purpose                       : This procedure is used to get list of repairs waiting for approval.

-- Output Parameters             : p_out_apprv_repair_cur      OUT      result_cursor
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_get_apprv_repair_list(
   p_in_user_role IN     VARCHAR2,
   p_in_user_id         IN    crd_e_component.CREATED_BY%TYPE,
   p_out_apprv_repair_cur     OUT      result_cursor
);


PROCEDURE ecrd_approve_comp_site_prc(
                                       p_in_user_role IN     VARCHAR2,
                                       p_in_user_id         IN    crd_e_component.CREATED_BY%TYPE,
                                    p_result_out    OUT    result_cursor
);

/***********************************************************************/
-- Procedure Name                : ecrd_rep_apprv_details_prc
-- Purpose                       : This procedure is used to get details about the repair waititng for approval.
-- Input Parameters      : p_in_repair_seq_id      IN crd_e_repair_history.repair_seq_id%TYPE
-- Output Parameters             : p_out_repair_apprv_det_cur  OUT   result_cursor
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_rep_apprv_details_prc(
p_in_repair_seq_id   IN crd_e_repair_history.repair_seq_id%TYPE,
p_out_repair_apprv_det_cur OUT   result_cursor
);


/***********************************************************************/
-- Procedure Name                : ecrd_reject_repair_prc
-- Purpose                       : This procedure is used to reject the repair.
-- Input Parameters      : p_in_repair_seq_id   IN    VARCHAR2,--crd_e_repair_history.repair_seq_id%TYPE
-- Input Parameters      : p_in_catalog_seq_id  IN VARCHAR2
-- Input Parameters      : p_in_user_id         IN    crd_e_repair_history.approved_rejected_by%TYPE
-- Input Parameters      : p_in_reject_comment  IN VARCHAR2
-- Input Parameters      : p_in_moule_seq_id    IN VARCHAR2
-- Input Parameters      : p_in_component_code  IN VARCHAR2
-- Output Parameters             : p_out_message   OUT   VARCHAR2
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_reject_repair_prc
(
   p_in_repair_seq_id   IN    VARCHAR2,--crd_e_repair_history.repair_seq_id%TYPE,
   p_in_catalog_seq_id  IN    VARCHAR2,
   p_in_user_id         IN    crd_e_repair_history.approved_rejected_by%TYPE,
   p_in_reject_comment  IN    VARCHAR2,
   p_in_moule_seq_id    IN    VARCHAR2,
   p_in_component_code  IN    VARCHAR2,
   p_out_message       OUT    VARCHAR2
);



PROCEDURE ecrd_approve_ind_repair_prc
(
   p_in_repair_seq_id   IN    crd_e_repair.repair_seq_id%TYPE,
   p_in_repair_desc  IN    crd_e_repair.repair_description%TYPE,
   p_in_module_id    IN    crd_e_repair.module_seq_id%TYPE,
   p_in_component_code  IN crd_e_repair.component_code%TYPE,
   p_in_rep_eff_date IN VARCHAR2,--crd_e_repair.repair_effective_date%TYPE ,
   p_in_rep_volume      IN crd_e_repair.repair_volume%TYPE,
   p_in_rep_ref_no      IN crd_e_repair.repair_reference%TYPE,
   p_in_rep_ref_format  IN crd_e_repair.repair_reference_format%TYPE,
   p_in_repair_comments IN crd_e_repair.repair_comments%TYPE,
   p_in_inc_TAT_ind  IN crd_e_repair_catalog.incremental_tat_ind%TYPE,
   p_in_inc_TAT      IN VARCHAR2,--crd_e_repair_catalog.repair_tat%TYPE,
   p_in_inc_pr_ind      IN crd_e_repair_catalog.incremental_price_ind%TYPE,
   p_in_pr        IN VARCHAR2,--crd_e_repair_catalog.repair_price%TYPE,
   p_in_pr_type      IN crd_e_repair_catalog.price_type%TYPE,
   p_in_fut_tat      IN VARCHAR2,--crd_e_repair_catalog.future_tat%TYPE,
   p_in_fut_pr    IN VARCHAR2,--crd_e_repair_catalog.future_price%TYPE,
   p_in_fut_pr_eff_dt   IN VARCHAR2,--crd_e_repair_catalog.future_effective_date%TYPE,
   p_in_user_id      IN crd_e_repair_history.approved_rejected_by%TYPE,
   p_in_catalog_seq_id  IN VARCHAR2,--crd_e_repair_catalog.catalog_seq_id%TYPE,
   p_in_rep_disp_seq_id IN VARCHAR2,--crd_e_repair_catalog.repair_display_seq_id%TYPE,
   p_in_approv_type  IN VARCHAR2,
   p_out_message     OUT   VARCHAR2
);

PROCEDURE ecrd_appr_grp_repair_prc
(
   p_in_repair_seq_id   IN    VARCHAR2,--crd_e_repair.repair_seq_id%TYPE,
   p_in_repair_desc  IN    crd_e_repair.repair_description%TYPE,
   p_in_module_id    IN    VARCHAR2,
   p_in_component_code  IN crd_e_repair.component_code%TYPE,
   p_in_rep_eff_date IN VARCHAR2,--crd_e_repair.repair_effective_date%TYPE ,
   p_in_rep_volume      IN crd_e_repair.repair_volume%TYPE,
   p_in_repair_comments IN crd_e_repair.repair_comments%TYPE,
   p_in_inc_TAT_ind  IN crd_e_repair_catalog.incremental_tat_ind%TYPE,
   p_in_inc_TAT      IN VARCHAR2,--crd_e_repair_catalog.repair_tat%TYPE,
   p_in_inc_pr_ind      IN crd_e_repair_catalog.incremental_price_ind%TYPE,
   p_in_pr        IN VARCHAR2,--crd_e_repair_catalog.repair_price%TYPE,
   p_in_pr_type      IN crd_e_repair_catalog.price_type%TYPE,
   p_in_fut_tat      IN VARCHAR2,--crd_e_repair_catalog.future_tat%TYPE,
   p_in_fut_pr    IN VARCHAR2,--crd_e_repair_catalog.future_price%TYPE,
   p_in_fut_pr_eff_dt   IN VARCHAR2,--crd_e_repair_catalog.future_effective_date%TYPE,
   p_in_user_id      IN crd_e_repair_history.approved_rejected_by%TYPE,
   p_in_catalog_seq_id  IN VARCHAR2,--crd_e_repair_catalog.catalog_seq_id%TYPE,
   p_in_rep_disp_seq_id IN crd_e_repair_catalog.repair_display_seq_id%TYPE,
   p_in_approv_type  IN VARCHAR2,
   p_in_chld_rep_info_buff IN LONG,
   p_in_row_delimiter      IN VARCHAR2,
   p_in_col_delimiter      IN VARCHAR2,

   p_out_message     OUT   VARCHAR2
);

PROCEDURE ecrd_approve_reject_site_prc(
         p_in_approve_reject IN VARCHAR2,
         p_in_mdl_seq_id IN crd_e_component_location.module_seq_id%TYPE,
         p_in_cmp_code  IN crd_e_component_location.COMPONENT_CODE%TYPE,
         p_in_location_id IN crd_e_component_location.LOCATION_ID%TYPE,
         p_in_change_start_date IN VARCHAR2,
         p_in_approve_rejected_by IN crd_e_comp_location_hist.APPROVED_REJECTED_BY%TYPE,
         p_in_rejection_comments IN crd_e_comp_location_hist.REJECTION_COMMENTS%TYPE
         );
PROCEDURE ecrd_cmp_site_approve_prc(
         p_in_param  IN VARCHAR2,
         p_in_user_role IN     VARCHAR2,
         p_in_approve_rejected_by IN crd_e_comp_location_hist.APPROVED_REJECTED_BY%TYPE,
         p_result_out OUT result_cursor,
         p_out_message OUT VARCHAR2
         );



PROCEDURE ecrd_get_comp_history(
   p_in_component_code  IN crd_e_component_history.component_code%TYPE,
   p_in_module_code  IN crd_e_component_history.module_seq_id%TYPE,

   p_out_comp_hist_cur  OUT   result_cursor
);


PROCEDURE ecrd_get_repair_history(
   p_in_repair_seq_id   IN VARCHAR2,
   p_in_catalog_seq_id  IN VARCHAR2,
   p_out_repair_hist_cur   OUT   result_cursor
);

PROCEDURE ecrd_appr_new_ind_rep_prc(
   p_in_repair_seq_id      IN    VARCHAR2,--crd_e_repair.repair_seq_id%TYPE,
   p_in_repair_desc     IN    crd_e_repair.repair_description%TYPE,
   p_in_module_id       IN    VARCHAR2,
   p_in_component_code     IN crd_e_repair.component_code%TYPE,
   p_in_rep_eff_date    IN VARCHAR2,--crd_e_repair.repair_effective_date%TYPE ,
   p_in_rep_volume         IN crd_e_repair.repair_volume%TYPE,
   p_in_rep_ref_no         IN crd_e_repair.repair_reference%TYPE,
   p_in_rep_ref_format     IN crd_e_repair.repair_reference_format%TYPE,
   p_in_repair_comments    IN crd_e_repair.repair_comments%TYPE,
   p_in_inc_TAT_ind     IN crd_e_repair_catalog.incremental_tat_ind%TYPE,
   p_in_inc_TAT         IN VARCHAR2,--crd_e_repair_catalog.repair_tat%TYPE,
   p_in_inc_pr_ind         IN crd_e_repair_catalog.incremental_price_ind%TYPE,
   p_in_pr           IN VARCHAR2,--crd_e_repair_catalog.repair_price%TYPE,
   p_in_pr_type         IN crd_e_repair_catalog.price_type%TYPE,
   p_in_fut_tat         IN VARCHAR2,--crd_e_repair_catalog.future_tat%TYPE,
   p_in_fut_pr       IN VARCHAR2,--crd_e_repair_catalog.future_price%TYPE,
   p_in_fut_pr_eff_dt      IN VARCHAR2,--crd_e_repair_catalog.future_effective_date%TYPE,
   p_in_user_id         IN crd_e_repair_history.approved_rejected_by%TYPE,
   p_in_catalog_seq_id     IN VARCHAR2,--crd_e_repair_catalog.catalog_seq_id%TYPE,
   p_in_rep_disp_seq_id    IN VARCHAR2,--crd_e_repair_catalog.repair_display_seq_id%TYPE,
   p_in_row_delimiter      IN VARCHAR2,
   p_in_col_delimiter      IN VARCHAR2,
   p_in_new_site_info_buff    IN LONG,
   p_out_message        OUT   VARCHAR2
);

PROCEDURE ecrd_appr_new_grp_rep_prc
(
   p_in_repair_seq_id            IN    VARCHAR2,
   p_in_repair_desc           IN    crd_e_repair.repair_description%TYPE,
   p_in_module_id             IN    VARCHAR2,
   p_in_component_code           IN crd_e_repair.component_code%TYPE,
   p_in_rep_eff_date          IN VARCHAR2,
   p_in_rep_volume               IN crd_e_repair.repair_volume%TYPE,
   p_in_repair_comments       IN crd_e_repair.repair_comments%TYPE,
   p_in_inc_TAT_ind           IN crd_e_repair_catalog.incremental_tat_ind%TYPE,
   p_in_inc_TAT               IN VARCHAR2,
   p_in_inc_pr_ind               IN crd_e_repair_catalog.incremental_price_ind%TYPE,
   p_in_pr                    IN VARCHAR2,
   p_in_pr_type               IN crd_e_repair_catalog.price_type%TYPE,
   p_in_fut_tat               IN VARCHAR2,
   p_in_fut_pr                IN VARCHAR2,
   p_in_fut_pr_eff_dt            IN VARCHAR2,
   p_in_user_id               IN crd_e_repair_history.approved_rejected_by%TYPE,
   p_in_catalog_seq_id           IN VARCHAR2,
   p_in_rep_disp_seq_id       IN VARCHAR2,
   p_in_approv_type           IN VARCHAR2,
   p_in_chld_rep_info_buff       IN LONG,
   p_in_row_delimiter            IN VARCHAR2,
   p_in_col_delimiter            IN VARCHAR2,
   p_in_repair_site_buff         IN LONG,

   p_out_message     OUT   VARCHAR2

);

PROCEDURE ecrd_is_rep_req_pend_prc
(
 p_in_repair_seq_id    IN          VARCHAR2,
p_in_catalog_seq_id  IN VARCHAR2,
 p_out_msg     OUT         VARCHAR2
);

FUNCTION ecrd_get_approval_status_fnc(
         p_in_component_code IN CRD_E_COMPONENT.component_code%TYPE,
         p_in_module_seq_id  IN CRD_E_COMPONENT.module_seq_id%TYPE
         )
RETURN VARCHAR2;

PROCEDURE ecrd_comp_site_appr_pend_prc
(
 p_in_module_seq_id    IN          VARCHAR2,
 p_in_component_code  IN VARCHAR2,
 p_in_location_id		IN VARCHAR2,
 p_in_user_role	IN VARCHAR2,
 p_out_msg     OUT         VARCHAR2
);
END ecrd_approval_pkg;
/
CREATE OR REPLACE PACKAGE BODY ecrd_approval_pkg
AS

PROCEDURE ecrd_apprv_get_comp_list_prc
(
   p_in_user_role IN     VARCHAR2,
   p_in_user_id         IN    crd_e_component.CREATED_BY%TYPE,
   p_out_component_list_cur OUT result_cursor
)
AS
BEGIN

   IF  UPPER(p_in_user_role) = UPPER(ecrd_utils_pkg.G_ADMIN)
   THEN
-- This gets all the component including new and modified from the component history table which are waiting for approval.
              OPEN p_out_component_list_cur
               FOR
               SELECT cch.component_code comp_code,
                      cch.component_description comp_desc,
                      cch.engine_model_code model_code,
                      cem.eng_mdl_desc model_desc,
                      cm.module_seq_id module_code,
                      cm.module_name module_desc,
                      ecrd_get_approval_status_fnc(cch.component_code,cm.module_seq_id) flg,
                      UPPER(cu.first_name||' '||cu.last_name) user_name,
                      TO_CHAR(cch.requested_date,ecrd_utils_pkg.g_display_date_format) req_date,
                      TO_CHAR(cch.requested_date,'YYYY/MM/DD') sortable_req_date

               FROM
                  crd_e_component_history cch,
                  crd_e_component cc,
                  crd_crc_eng_mdl_display cem,
                  crd_crc_module cm,
                  crd_crc_user cu
               WHERE cc.component_code (+)= cch.component_code
               AND cc.module_seq_id (+)= cch.module_seq_id
               AND cem.eng_mdl_number = cch.engine_model_code
               AND cm.eng_mdl_number = cem.eng_mdl_number
               AND cch.module_seq_id = cm.module_seq_id
               AND UPPER(cu.userid) = UPPER(cch.requested_by)
               AND UPPER(cch.staging_history_ind) = ecrd_utils_pkg.G_STAGING
               AND cch.approved_rejected_by IS NULL
               AND cch.approved_rejected_date IS NULL
               AND cch.approve_reject_status IS NULL
               AND (cch.component_end_date IS NULL OR cch.component_end_date > SYSDATE)
               ORDER BY comp_code;

   ELSIF UPPER(p_in_user_role) = ecrd_utils_pkg.G_TC
   THEN
            OPEN p_out_component_list_cur
            FOR
            SELECT cch.component_code comp_code,
                   cch.component_description comp_desc,
                   cch.engine_model_code model_code,
                   cem.eng_mdl_desc model_desc,
                   cm.module_seq_id module_code,
                   cm.module_name module_desc,
                   decode(cc.cycle_count_class,NULL,'N','M') flg,
                   UPPER(cu.first_name||' '||cu.last_name) user_name,
                   to_char(cch.requested_date,ecrd_utils_pkg.g_display_date_format) req_date,
                   TO_CHAR(cch.requested_date,'YYYY/MM/DD') sortable_req_date
            FROM
               crd_e_component_history cch,
               crd_e_component cc,
               crd_crc_eng_mdl_display cem,
               crd_crc_module cm,
               crd_crc_user cu
            WHERE
                  cch.requested_by = p_in_user_id
            AND     cc.component_code (+)= cch.component_code
            AND cc.module_seq_id (+)= cch.module_seq_id
            AND cem.eng_mdl_number = cch.engine_model_code
            AND cm.eng_mdl_number = cem.eng_mdl_number
            AND cch.module_seq_id = cm.module_seq_id
            AND UPPER(cu.userid) = UPPER(cch.requested_by)
            AND UPPER(cch.staging_history_ind) = ecrd_utils_pkg.G_STAGING
            AND cch.approved_rejected_by IS NULL
            AND cch.approved_rejected_date IS NULL
            AND cch.approve_reject_status IS NULL
            AND (cch.component_end_date IS NULL OR cch.component_end_date > SYSDATE)
            ORDER BY comp_code;

   END IF;
--The decode function is used to determine which component is new and which is modified.
EXCEPTION
WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20322,'Error in geae_crd_approval_pkg.ecrd_apprv_get_comp_list_prc '||SQLCODE);
END ecrd_apprv_get_comp_list_prc;

/**This procedure is used to approve only a component and not the repairs or parts associated with it.It approves both new as well as modified component.*/
PROCEDURE ecrd_approve_component
(
   p_in_component_code  IN    crd_e_component.component_code%TYPE,
   p_in_component_desc  IN    crd_e_component.component_description%TYPE,
   p_in_model_code        IN  VARCHAR2,
   p_in_module_id       IN    VARCHAR2,
   p_in_ata_ref_snum    IN    crd_e_component.ata_reference_snum%TYPE,
   p_in_base_tat       IN  crd_e_component.baseline_tat%TYPE,
   p_in_comp_eff_date   IN    VARCHAR2,
   p_in_cycle           IN    crd_e_component.cycle_count_class%TYPE,
   p_in_qty_engine      IN    crd_e_component.quantity_of_engine%TYPE,
   p_in_sv_rate_exp     IN    crd_e_component.shop_visit_exposure_rate%TYPE,
   p_in_scrap_rate_exp  IN    crd_e_component.scrap_rate_at_exposure%TYPE,
   p_in_service_exp     IN    crd_e_component.SERVICEABLE_AT_EXPOSURE%TYPE,
   p_in_repair_yld      IN    crd_e_component.REPAIR_YIELD%TYPE,
   p_in_alternate_component IN   crd_e_component.ALTERNATE_COMPONENT_IND%TYPE,
   p_in_user_id         IN    crd_e_component.CREATED_BY%TYPE,
   p_in_approv_type     IN    VARCHAR2,

   p_out_message       OUT    VARCHAR2
)
IS
v_count NUMBER := 0;
v_number NUMBER:=0;
v_catalog_seq_id NUMBER :=0;
v_comp_eff_date DATE := NULL;
v_creation_date DATE := NULL;
v_created_by VARCHAR2(20) :=NULL;

BEGIN
     v_comp_eff_date := TO_DATE(p_in_comp_eff_date,ecrd_utils_pkg.G_DATE_FORMAT);
     p_out_message := 'COMPONENT_APPROVE_FAILURE';

--The approve type checks if the component is new or modified. and depending on it, it will decide further actions.

        BEGIN
            SELECT created_by,
                   creation_date
            INTO
                  v_created_by,
                  v_creation_date
            FROM crd_e_component_history
            WHERE component_code = p_in_component_code
            AND staging_history_ind = ecrd_utils_pkg.G_STAGING
            AND module_seq_id = TO_NUMBER(p_in_module_id)
            AND approved_rejected_by IS NULL;
           EXCEPTION
-- 03-May-2006 Patni - Added NO_DATA_FOUND Exception - Begin

           WHEN NO_DATA_FOUND THEN
            v_created_by := ' ';
            v_creation_date :=' ';
          END;
-- 03-May-2006 Patni - Added NO_DATA_FOUND Exception - END

     IF UPPER(p_in_approv_type) =ecrd_utils_pkg.G_NO
     THEN
      UPDATE crd_e_component_history
            SET staging_history_ind = ecrd_utils_pkg.G_STAGING,
                component_description = p_in_component_desc,
                ata_reference_snum = p_in_ata_ref_snum,
                baseline_tat = p_in_base_tat,
                component_effective_date = v_comp_eff_date,
                cycle_count_class = p_in_cycle,
                quantity_of_engine = p_in_qty_engine,
                shop_visit_exposure_rate = p_in_sv_rate_exp,
                scrap_rate_at_exposure = p_in_scrap_rate_exp,
                serviceable_at_exposure = p_in_service_exp,
                repair_yield = p_in_repair_yld,
                alternate_component_ind = p_in_alternate_component,
                approved_rejected_by = p_in_user_id,
                approved_rejected_date = sysdate,
                approve_reject_status = ecrd_utils_pkg.G_APPROVE_STATUS,
                last_update_date = sysdate,
                last_updated_by = p_in_user_id
            WHERE component_code = p_in_component_code
            AND staging_history_ind = ecrd_utils_pkg.G_STAGING
            AND module_seq_id = TO_NUMBER(p_in_module_id);


               SELECT COUNT(1)
               INTO v_count
               FROM crd_e_component
               WHERE component_code = p_in_component_code
               AND module_seq_id = TO_NUMBER(p_in_module_id)
          AND component_end_date > SYSDATE;

        IF v_count > 0
        THEN
            p_out_message := 'COMPONENT_ALREADY_EXISTS';
            ROLLBACK;
            RETURN;
        END IF;

--This is to check that there is no such component in the main table which has same component and module code as the approved one and was previously deleted.
   BEGIN
   -- Kalyan comments starts on 7th Nov 2005
   /*             SELECT COUNT(1)
      INTO v_number
      FROM crd_e_component
      WHERE component_code=p_in_component_code
      AND module_seq_id= TO_NUMBER(p_in_module_id)
      AND component_end_date < SYSDATE;
   EXCEPTION
   WHEN NO_DATA_FOUND THEN
      v_number :=0;
   WHEN OTHERS THEN
      v_number:=0; */
      SELECT COUNT(1)
      INTO v_number
      FROM crd_e_component
      WHERE component_code=p_in_component_code
      AND module_seq_id= TO_NUMBER(p_in_module_id);
 --     AND component_end_date < SYSDATE;
   EXCEPTION
   WHEN NO_DATA_FOUND THEN
      v_number :=0;
   WHEN OTHERS THEN
      v_number:=0;
         -- Kalyan comments starts on 7th Nov 2005
   END;

--If there is a component with the same component code and module id but with a component end date less than the sysdate then instead of inserting a new record in the table update the old one with setting the repair end date as null and all other details as per the entered component.

      IF v_number >0
      THEN


         UPDATE   crd_e_component
         SET
            component_end_date ='',
            component_description=p_in_component_desc,
            ata_reference_snum=p_in_ata_ref_snum,
            baseline_tat=p_in_base_tat,
            component_effective_date=v_comp_eff_date,
            cycle_count_class=p_in_cycle,
            quantity_of_engine=p_in_qty_engine,
            shop_visit_exposure_rate=p_in_sv_rate_exp,
            serviceable_at_exposure =p_in_service_exp,
            scrap_rate_at_exposure=p_in_scrap_rate_exp,
            repair_yield=p_in_repair_yld,
            alternate_component_ind = p_in_alternate_component,
            /*created_by=v_created_by,
            creation_date=v_creation_date,*/
            last_update_date=SYSDATE,
            last_updated_by=p_in_user_id
         WHERE component_code=p_in_component_code
         AND module_seq_id=TO_NUMBER(p_in_module_id)
         AND component_end_date < SYSDATE;

--If there is no component in the mail table with the same code then insert the data in the main table.
       ELSE


          INSERT INTO crd_e_component
          (
          component_code,
          module_seq_id,
          component_description,
          ata_reference_snum,
          baseline_tat,
          component_effective_date,
          cycle_count_class,
          quantity_of_engine,
          shop_visit_exposure_rate,
          scrap_rate_at_exposure,
          serviceable_at_exposure,
          repair_yield,
          alternate_component_ind,
          created_by,
          creation_date,
          last_update_date,
          last_updated_by
          )
          VALUES
          (
          p_in_component_code,
          TO_NUMBER(p_in_module_id),
          p_in_component_desc,
          p_in_ata_ref_snum,
          p_in_base_tat,
          v_comp_eff_date,
          p_in_cycle,
          p_in_qty_engine,
          p_in_sv_rate_exp,
          p_in_scrap_rate_exp,
          p_in_service_exp,
          p_in_repair_yld,
          p_in_alternate_component,
          v_created_by,
          v_creation_date,
          SYSDATE,
          p_in_user_id
          );


       END IF;
--If the component is modified then just update the main table and move the old data of component to staging table with history indicator.
    ELSE
--Inserting the history data from main table to the staging table.
      INSERT INTO crd_e_component_history
      (
         module_seq_id,
         component_code,
         staging_history_ind,
         change_start_date,
         engine_model_code,
         component_end_date,
         component_description,
         ata_reference_snum,
         baseline_tat,
         component_effective_date,
         cycle_count_class,
         quantity_of_engine,
         shop_visit_exposure_rate,
         scrap_rate_at_exposure,
         serviceable_at_exposure,
         repair_yield,
         requested_by,
         approved_rejected_by,
         requested_date,
         approved_rejected_date,
         approve_reject_status,
         rejection_comments,
         created_by,
         creation_date,
         last_update_date,
         last_updated_by,
         alternate_component_ind
      )
      (
         SELECT
                module_seq_id,
           component_code,
           ecrd_utils_pkg.G_HISTORY_RECORD,
           SYSDATE,
           p_in_model_code,
           NULL,
           component_description,
           ata_reference_snum,
           baseline_tat,
           component_effective_date,
           cycle_count_class,
           quantity_of_engine,
           shop_visit_exposure_rate,
           scrap_rate_at_exposure,
           serviceable_at_exposure,
           repair_yield,
           null,
           null,
           null,
           null,
           null,
           null,
           p_in_user_id,
           SYSDATE,
           SYSDATE,
           p_in_user_id,
           alternate_component_ind
           FROM
           crd_e_component
           WHERE
           component_code = p_in_component_code
           AND module_seq_id = TO_NUMBER(p_in_module_id)
           AND component_end_date IS NULL
      );

--Updatin the history table for the staging component only as per the entered values for component.

            UPDATE crd_e_component_history
            SET
                 component_description    =  p_in_component_desc,
                 ata_reference_snum    =  p_in_ata_ref_snum,
                      baseline_tat        =  p_in_base_tat,
                      component_effective_date  =  v_comp_eff_date,
                      cycle_count_class      =  p_in_cycle,
                      quantity_of_engine     =  p_in_qty_engine,
                      shop_visit_exposure_rate  =  p_in_sv_rate_exp,
                      scrap_rate_at_exposure =  p_in_scrap_rate_exp,
                serviceable_at_exposure   =  p_in_service_exp,
                      repair_yield        =  p_in_repair_yld,
                     alternate_component_ind =  p_in_alternate_component,
                       approved_rejected_by     =  p_in_user_id,
                 approved_rejected_date   =  SYSDATE,
                 approve_reject_status    =  ecrd_utils_pkg.G_APPROVE_STATUS,
                 last_update_date      =  SYSDATE,
                 last_updated_by    =  p_in_user_id
            WHERE component_code    =  p_in_component_code
            AND UPPER(staging_history_ind)   =  ecrd_utils_pkg.G_STAGING
            AND module_seq_id = TO_NUMBER(p_in_module_id)
            AND approved_rejected_by IS NULL;

--Updating the main table for the values entered at the front end textboxes.

                  UPDATE crd_e_component
                  SET
                  component_description   =  p_in_component_desc,
                  ata_reference_snum   =  p_in_ata_ref_snum,
                  baseline_tat      =  p_in_base_tat,
                  component_effective_date   =  v_comp_eff_date,
                  cycle_count_class    =  p_in_cycle,
                  quantity_of_engine   =  p_in_qty_engine,
                  shop_visit_exposure_rate   =  p_in_sv_rate_exp,
                  scrap_rate_at_exposure  =  p_in_scrap_rate_exp,
                  serviceable_at_exposure =  p_in_service_exp,
                  repair_yield      =  p_in_repair_yld,
                  alternate_component_ind =  p_in_alternate_component,
                  last_update_date     =  SYSDATE,
                  last_updated_by      =  p_in_user_id
             WHERE component_code = p_in_component_code
             AND module_seq_id = TO_NUMBER(p_in_module_id)
       AND (component_end_date IS NULL OR component_end_date >SYSDATE);

COMMIT;
END IF;
 p_out_message := 'COMPONENT_APPROVE_SUCCESS';
 EXCEPTION
 WHEN OTHERS THEN
    ROLLBACK;
    p_out_message := 'COMPONENT_APPROVE_FAILURE';
-- 03-May-2006 Patni - Added PKG Name in Exception - Begin
    RAISE_APPLICATION_ERROR(-20322,'Error in ecrd_approval_pkg.ecrd_approve_component '||SQLCODE||' ' ||SQLERRM);
-- 03-May-2006 Patni - Added PKG Name in Exception - End
 END ecrd_approve_component;

/*
   This procedure is used to approve a new component along with the repairs associated with it and also the parts and sites associated with is.
*/

 PROCEDURE ecrd_approve_new_component_prc
(
   p_in_component_code  IN    crd_e_component.component_code%TYPE,
   p_in_component_desc  IN    crd_e_component.component_description%TYPE,
   p_in_model_code        IN  crd_e_component_history.engine_model_code%TYPE,
   p_in_module_id       IN    VARCHAR2,
   p_in_ata_ref_snum    IN    crd_e_component.ata_reference_snum%TYPE,
   p_in_base_tat       IN  crd_e_component.baseline_tat%TYPE,
   p_in_comp_eff_date   IN    VARCHAR2,
   p_in_cycle           IN    crd_e_component.cycle_count_class%TYPE,
   p_in_qty_engine      IN    crd_e_component.quantity_of_engine%TYPE,
   p_in_sv_rate_exp     IN    crd_e_component.shop_visit_exposure_rate%TYPE,
   p_in_scrap_rate_exp  IN    crd_e_component.scrap_rate_at_exposure%TYPE,
   p_in_service_exp     IN    crd_e_component.SERVICEABLE_AT_EXPOSURE%TYPE,
   p_in_repair_yld      IN    crd_e_component.REPAIR_YIELD%TYPE,
   p_in_alternate_component IN   crd_e_component.ALTERNATE_COMPONENT_IND%TYPE,
   p_in_user_id         IN    crd_e_component.CREATED_BY%TYPE,
-- p_in_approv_type     IN    VARCHAR2,
   p_in_repair_buff     IN    LONG,
   p_in_comp_site_buff  IN    LONG,
   p_in_comp_part_buff  IN    LONG,
   p_out_message       OUT    VARCHAR2
)
IS
v_count        NUMBER      :=0;
v_catalog_seq_id  NUMBER      :=0;
var_comp_loc_number  NUMBER      :=0;
v_index        NUMBER      :=0;
v_row_count    NUMBER      :=0;
v_details      LONG     :=NULL;

v_comp_eff_date DATE := NULL;

v_out_message  VARCHAR2(50) := NULL;
v_out_grp_msg  VARCHAR2(50) :=NULL;
v_out_ind_msg  VARCHAR2(50) :=NULL;
v_location_count NUMBER := 0;
tab_broken_rows  ecrd_utils_pkg.gtyp_buf_arr;
tab_broken_cols  ecrd_utils_pkg.gtyp_buf_arr;

v_creation_date DATE := NULL;
v_created_by VARCHAR2(20) :=NULL;


BEGIN

   p_out_message  := 'COMPONENT_APPROVE_FAILURE';

--This method is called to approved just a new component only and not the associated things.

    BEGIN
         SELECT created_by,
                   creation_date
            INTO
                  v_created_by,
                  v_creation_date
            FROM crd_e_component_history
            WHERE component_code = p_in_component_code
            AND staging_history_ind = ecrd_utils_pkg.G_STAGING
            AND module_seq_id = TO_NUMBER(p_in_module_id)
            AND approved_rejected_by IS NULL;
   -- 03-May-2006 Patni - Added NO_DATA_FOUND Exception - Begin
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
    v_created_by :=' ';
    v_creation_date :=' ';
    END;
 -- 03-May-2006 Patni - Added NO_DATA_FOUND Exception - End
   ecrd_approve_component(
   p_in_component_code,
   p_in_component_desc,
   p_in_model_code,
   p_in_module_id,
   p_in_ata_ref_snum,
   p_in_base_tat,
   p_in_comp_eff_date,
   p_in_cycle,
   p_in_qty_engine,
   p_in_sv_rate_exp,
   p_in_scrap_rate_exp,
   p_in_service_exp,
   p_in_repair_yld,
   p_in_alternate_component,
   p_in_user_id,
   ecrd_utils_pkg.G_NO,
   v_out_message
   );




--If the approval of component is success then the component site buffer is broken in the table formate and then it is approved.
   IF UPPER(v_out_message) = 'COMPONENT_APPROVE_SUCCESS'
   THEN

      ecrd_utils_pkg.break_into_rows_s_prc(
                  p_in_comp_site_buff,
                  ecrd_utils_pkg.G_ROW_DELIM,
                tab_broken_rows
      );

   v_row_count := tab_broken_rows.COUNT;

   FOR v_index IN 1..v_row_count
      LOOP
         v_details := tab_broken_rows(v_index);

         ecrd_utils_pkg.break_into_cols_s_prc(
               v_details,
               ecrd_utils_pkg.G_COL_DELIM,
               tab_broken_cols
         );


--This is done to check if there is any existing deleted record in the main table having its end date less than the current sysdate.

  BEGIN
      SELECT COUNT(ROWID)
      INTO var_comp_loc_number
      FROM crd_e_component
      WHERE component_code=p_in_component_code
      AND module_seq_id=TO_NUMBER(p_in_module_id)
      AND TRUNC(component_end_date) < TRUNC(SYSDATE);
 -- 03-May-2006 ADDED EXCEPTION BEGIN
   EXCEPTION
   WHEN NO_DATA_FOUND THEN
   var_comp_loc_number := 0;
   END;
 -- 03-May-2006 ADDED EXCEPTION END


--If there is any such record then instead of inserting a new record we update the existing record and set the repair end date as null.
      IF var_comp_loc_number >0
      THEN
         SELECT
            COUNT(1)
         INTO
            v_location_count
         FROM
            crd_e_component_location
         WHERE
            component_code    =  p_in_component_code
            AND module_seq_id =  TO_NUMBER(p_in_module_id)
            AND location_id      =  tab_broken_cols(1)
            AND active_ind = ecrd_utils_pkg.G_NO;

         IF(v_location_count > 0)
      THEN
      UPDATE crd_e_component_location
      SET   active_ind     =  ecrd_utils_pkg.G_ACTIVE,
         site_sequence_number =  v_index,
         /*created_by      =  p_in_user_id,
         creation_date     =  v_creation_date,*/
         last_update_date  =  SYSDATE,
         last_updated_by      =  v_created_by,
         -- Added new For Hide Component Indicator
         hide_component_ind  = tab_broken_cols(2)
         -- End of Added New For Hide Component Indicator
      WHERE component_code    =  p_in_component_code
         AND module_seq_id =  TO_NUMBER(p_in_module_id)
         AND location_id      =  tab_broken_cols(1);
      ELSE

            INSERT INTO crd_e_component_location
            (
               module_seq_id,
               component_code,
               location_id,
               active_ind,
               site_sequence_number,
               hide_component_ind,
               created_by,
               creation_date,
               last_update_date,
               last_updated_by
            )
            VALUES
            (
               TO_NUMBER(p_in_module_id),
               p_in_component_code,
               tab_broken_cols(1),
               ecrd_utils_pkg.G_ACTIVE,
               v_index,
               NULL,
               p_in_user_id,
               SYSDATE,
               SYSDATE,
               p_in_user_id
            );
         END IF;
      ELSE

--If there is no such record in the main table then just insert the data in the main component location table.
    BEGIN
         SELECT
            COUNT(1)
         INTO
            v_location_count
         FROM
            crd_e_component_location
         WHERE
            component_code    =  p_in_component_code
            AND module_seq_id =  TO_NUMBER(p_in_module_id)
            AND location_id      =  tab_broken_cols(1)
            AND active_ind = ecrd_utils_pkg.G_NO;
  --03-MAY-2006 PATNI ADDED EXCEPTION BEGIN
     EXCEPTION
     WHEN NO_DATA_FOUND THEN
      v_location_count := 0;
      END;
  --03-MAY-2006 PATNI ADDED EXCEPTION END
         IF(v_location_count > 0)
         THEN
            UPDATE crd_e_component_location
            SET   active_ind     =  ecrd_utils_pkg.G_ACTIVE,
               site_sequence_number =  v_index,
               /*created_by      =  p_in_user_id,
               creation_date     =  SYSDATE,*/
               last_update_date  =  SYSDATE,
               last_updated_by      =  p_in_user_id
            WHERE component_code    =  p_in_component_code
               AND module_seq_id =  TO_NUMBER(p_in_module_id)
               AND location_id      =  tab_broken_cols(1);
         ELSE
         INSERT INTO crd_e_component_location
         (
            module_seq_id,
            component_code,
            location_id,
            active_ind,
            site_sequence_number,
            hide_component_ind,
            created_by,
            creation_date,
            last_update_date,
            last_updated_by
         )
         VALUES
         (
            TO_NUMBER(p_in_module_id),
            p_in_component_code,
            tab_broken_cols(1),
            ecrd_utils_pkg.G_ACTIVE,
            v_index,
            -- Changed Null to tab_broken_cols(2) for setting the hide component indicator
            tab_broken_cols(2),
            v_created_by,
            v_creation_date,
            SYSDATE,
            p_in_user_id
         );
         END IF;
      END IF;


--Update the component location history table to store the parameters like approved rejected by and approved rejected date and status etc.
      UPDATE crd_e_comp_location_hist
      SET
         location_id=tab_broken_cols(1),
         approved_rejected_by=p_in_user_id,
         approved_rejected_date=SYSDATE,
         approve_reject_status=ecrd_utils_pkg.G_APPROVE_STATUS,
         /*created_by=p_in_user_id,
         creation_date=SYSDATE,*/
         last_update_date=SYSDATE,
         last_updated_by=p_in_user_id,
         -- Added new for Hide Component Indicator
         hide_component_ind = tab_broken_cols(2)
         -- End of Added new for Hide Component Indicator
      WHERE
         component_code=p_in_component_code
         AND module_seq_id=TO_NUMBER(p_in_module_id)
         AND staging_history_ind = ecrd_utils_pkg.G_STAGING
         AND approved_rejected_by IS NULL;

      END LOOP;

--The component part buffer is broken in the table structure.

      ecrd_utils_pkg.break_into_rows_s_prc(
                    p_in_comp_part_buff,
                    ecrd_utils_pkg.G_ROW_DELIM,
               tab_broken_rows
         );
         v_row_count := tab_broken_rows.COUNT;
         v_index:=0;
         FOR v_index IN 1..v_row_count
            LOOP

               v_details := tab_broken_rows(v_index);


               ecrd_utils_pkg.break_into_cols_s_prc(
                     v_details,
                     ecrd_utils_pkg.G_COL_DELIM,
                     tab_broken_cols
               );
               BEGIN


--The part information is inserted in the main table and the history table is updated.

               INSERT INTO crd_e_part
               (
                  module_seq_id,
                  component_code,
                  part_number,
                  part_sequence_number,
                  created_by,
                  creation_date,
                  last_update_date,
                  last_updated_by,
                  active_ind
               )
               VALUES
               (
                  TO_NUMBER(p_in_module_id),
                  p_in_component_code,
                  tab_broken_cols(1),
                  v_index,
                  v_created_by,
                  v_creation_date,
                  SYSDATE,
                  p_in_user_id,
                  ecrd_utils_pkg.G_ACTIVE
               );
               UPDATE crd_e_part_history
               SET
                  APPROVED_REJECTED_BY = p_in_user_id,
                  PART_SEQUENCE_NUMBER = v_index,
                  APPROVED_REJECTED_DATE  = SYSDATE,
                  APPROVE_REJECT_STATUS   =ecrd_utils_pkg.G_APPROVE_STATUS,
                  ACTIVE_IND     =ecrd_utils_pkg.G_ACTIVE,
                  LAST_UPDATE_DATE  =SYSDATE,
                  LAST_UPDATED_BY      =p_in_user_id
               WHERE
                  component_code = p_in_component_code
                  AND module_seq_id= p_in_module_id
                  AND part_number= tab_broken_cols(1)
                  AND approved_rejected_by IS NULL;
               EXCEPTION
               WHEN OTHERS
               THEN
                  RAISE_APPLICATION_ERROR(-20322,'Error in the part insert v_index =' || v_index ||'part '||tab_broken_cols(1));
               END;
            END LOOP;

-- Breaking the Complete repair buffer into individual repair objects

      ecrd_utils_pkg.break_into_rows_s_prc(
                  p_in_repair_buff,
                  ecrd_utils_pkg.G_ROW_DELIM,
                tab_broken_rows
      );
   v_row_count := tab_broken_rows.COUNT;

   FOR v_index IN 1..v_row_count
      LOOP

--This loop is executed once for each repair.Thus it is totally executed the number of repairs of the component.
         v_details := tab_broken_rows(v_index);


         ecrd_utils_pkg.break_into_cols_s_prc(
               v_details,
               ecrd_utils_pkg.G_COL_DELIM,
               tab_broken_cols
         );

--Getting the Repair attributes information from the buffer and add them in the proc to approve
--depending on the type of the repair respective procedure is called.

      IF UPPER(tab_broken_cols(1))= ecrd_utils_pkg.G_GROUP_REPAIR
      THEN
            ecrd_appr_new_grp_rep_prc
            (
            tab_broken_cols(2),
            tab_broken_cols(3),
            p_in_module_id,
            p_in_component_code,
            tab_broken_cols(4),
            tab_broken_cols(5),
            tab_broken_cols(6),
            tab_broken_cols(7),
            tab_broken_cols(8),
            tab_broken_cols(9),
            tab_broken_cols(10),
            tab_broken_cols(11),
            tab_broken_cols(12),
            tab_broken_cols(13),
            tab_broken_cols(14),
            p_in_user_id,
            tab_broken_cols(15),
            tab_broken_cols(16),
            ecrd_utils_pkg.G_NO,
            tab_broken_cols(18),
            '*',
            '#',
            tab_broken_cols(17),
            v_out_grp_msg
            );


      ELSE

            ecrd_appr_new_ind_rep_prc
               (
               tab_broken_cols(2),
               tab_broken_cols(3),
               p_in_module_id,
               p_in_component_code,
               tab_broken_cols(4),
               tab_broken_cols(5),
               tab_broken_cols(6),
               tab_broken_cols(7),
               tab_broken_cols(8),
               tab_broken_cols(9),
               tab_broken_cols(10),
               tab_broken_cols(11),
               tab_broken_cols(12),
               tab_broken_cols(13),
               tab_broken_cols(14),
               tab_broken_cols(15),
               tab_broken_cols(16),
               p_in_user_id,
               tab_broken_cols(17),
               tab_broken_cols(18),
               '*',
               '#',
               tab_broken_cols(19),
               v_out_ind_msg
               );

         END IF;
      END LOOP;
   END IF;

COMMIT;
p_out_message  := 'COMPONENT_APPROVE_SUCCESS';
EXCEPTION
WHEN OTHERS THEN
ROLLBACK;
--03-MAY-2006 ADDED PROCEDURE NAME BEGIN
    RAISE_APPLICATION_ERROR(-20322,'Error in Ecrd_approval_pkg.ecrd_approve_new_component_prc '||SQLCODE||'-'||SQLERRM);
--03-MAY-2006 ADDED PROCEDURE NAME END
END ecrd_approve_new_component_prc;

/*
This procedure is  used to reject a component.
*/

PROCEDURE ecrd_reject_component
(
   p_in_component_code  IN    crd_e_component.component_code%TYPE,
   p_in_module_id       IN    crd_e_component.module_seq_id%TYPE,
   p_in_user_id         IN    crd_e_component.CREATED_BY%TYPE,
   p_in_reject_comm     IN    crd_e_component_history.rejection_comments%TYPE,
   p_out_message       OUT    VARCHAR2
)
IS
v_count NUMBER := 0;
v_catalog_seq_id NUMBER :=0;
v_eng_mdl_number crd_crc_eng_mdl_display.eng_mdl_number%TYPE;
v_err_mess VARCHAR2(1000):=NULL;
BEGIN
p_out_message := 'COMPONENT_REJECT_FAILURE';

/* SELECT catalog_seq_id
     INTO v_catalog_seq_id
     FROM crd_e_catalog
     WHERE
   eng_mdl_number IN ( SELECT eng_mdl_number
            FROM crd_crc_module
            WHERE module_seq_id=p_in_module_id)
   AND catalog_type=ecrd_utils_pkg.G_DEFAULT_CATALOG;*/

      BEGIN
            SELECT eng_mdl_number INTO v_eng_mdl_number
                    FROM crd_crc_module
                    WHERE module_seq_id=p_in_module_id;
-- 03-MAY-2006 ADDED EXCEPTION BEGIN
       EXCEPTION
       WHEN NO_DATA_FOUND THEN
       v_eng_mdl_number :=' ';
       END;
-- 03-MAY-2006 ADDED EXCEPTION END

        ecrd_managecatalog_pkg.ecrd_get_default_seqid_prc(v_eng_mdl_number,v_catalog_seq_id,v_err_mess);
--Updating the component history table to store the values of approved rejected by and date and rejection comments etc.

        UPDATE crd_e_component_history
        SET approved_rejected_by = p_in_user_id,
            approve_reject_status = ecrd_utils_pkg.G_REJECT_STATUS,
            approved_rejected_date = sysdate,
            last_update_date = sysdate,
            last_updated_by = p_in_user_id,
       rejection_comments = p_in_reject_comm,
       component_end_date=SYSDATE
        WHERE component_code = p_in_component_code
   AND UPPER(staging_history_ind) = ecrd_utils_pkg.G_STAGING
        AND module_seq_id = p_in_module_id;

--Updating all the repairs information in the part history tabel for the given component.
      UPDATE crd_e_part_history
      SET
         approved_rejected_by =p_in_user_id,
         approved_rejected_date  =SYSDATE,
         approve_reject_status   =ecrd_utils_pkg.G_REJECT_STATUS,
         rejection_comments   =p_in_reject_comm,
         active_ind     =ecrd_utils_pkg.G_NO,
         last_update_date  =SYSDATE,
         last_updated_by      =p_in_user_id
      WHERE
         module_seq_id     =p_in_module_id
         AND component_code   =p_in_component_code
         AND approved_rejected_by IS NULL;

--This is used to check if the same component is existing in the main table or not.
--i.e. If the component is new or modified.

   SELECT COUNT(ROWID)
   INTO v_count
   FROM crd_e_component
   WHERE component_code = p_in_component_code
   AND module_seq_id = p_in_module_id;


--If the component is new then along with the component the repairs and parts associated with it need to be rejected.

   IF v_count = 0 THEN

--Updating all the repairs information in the repair history tabel for the given component.

   UPDATE crd_e_repair_history
      SET
         approved_rejected_by = p_in_user_id,
         approve_reject_status = ecrd_utils_pkg.G_REJECT_STATUS,
         approved_rejected_date = SYSDATE,
         last_update_date = SYSDATE,
         last_updated_by = p_in_user_id,
         REJECTION_COMMENTS=p_in_reject_comm
      WHERE
         component_code = p_in_component_code
         AND module_seq_id= p_in_module_id;

--Updating all the repairs information in the repair catalog history tabel for the given component.

      UPDATE crd_e_repair_catalog_hist
      SET

         approv_reject_by = p_in_user_id,
         approved_rejected_date = SYSDATE,
         approve_reject_status= ecrd_utils_pkg.G_REJECT_STATUS,
         last_update_date=SYSDATE,
         last_updated_by=p_in_user_id,
         REJECTION_COMMENTS=p_in_reject_comm
      WHERE
         catalog_seq_id = v_catalog_seq_id
         AND repair_seq_id IN (SELECT repair_seq_id
                     FROM crd_e_repair_history
                     WHERE component_code=p_in_component_code
                     AND module_seq_id=p_in_module_id);

--Updating all the repairs information in the repair cost history tabel for the given component.

      UPDATE crd_e_repair_cost_history
      SET
         APPROV_REJECT_STATUS=ecrd_utils_pkg.G_REJECT_STATUS,
         LAST_UPDATE_DATE=SYSDATE,
         APPROV_REJECT_DATE=SYSDATE,
         LAST_UPDATED_BY=p_in_user_id,
         REJECT_COMMENTS=p_in_reject_comm
      WHERE
         component_code=p_in_component_code
         AND module_seq_id=p_in_module_id;

      END IF;
COMMIT;
p_out_message := 'COMPONENT_APPROVE_SUCCESS';
EXCEPTION
 WHEN OTHERS THEN
    ROLLBACK;
    p_out_message := 'COMPONENT_REJECT_FAILURE';
    RAISE_APPLICATION_ERROR(-20322,'Error in ecrd_approval_pkg.geae_reject_component '||'--'||SQLCODE||'-'||SUBSTR(SQLERRM,1,100));
 END ecrd_reject_component;

/*
This procedure is used to get the details about the component waiting for approval.
This gets the details like who has requested it and the requested date,requestor site etc.
*/



PROCEDURE ecrd_comp_appr_req_details_prc
(
  p_in_module_seq_id    IN VARCHAR2,
  p_in_component_code      IN crd_e_component_history.component_code%TYPE,
  p_out_comp_appr_det_cur  OUT   result_cursor
)
AS
BEGIN
     OPEN p_out_comp_appr_det_cur FOR
      SELECT
            NVL(crh.approved_rejected_by,' '),
            NVL(to_char(crh.approved_rejected_date,ecrd_utils_pkg.G_DISPLAY_DATE_FORMAT),' '),
            NVL(cl.site_name,' '),
            UPPER(cu.first_name || ' ' || cu.last_name) User_Name,
            crh.approve_reject_status,
            decode(cc.cycle_count_class,NULL,'N','M') flg,
            NVL(to_char(crh.requested_date,ecrd_utils_pkg.G_DISPLAY_DATE_FORMAT),' '),
            cu.email_address,
            cl.location_id
     FROM   crd_e_component_history crh,
            crd_e_component cc,
            crd_crc_user cu,
            crd_location cl
     WHERE
                 crh.component_code = p_in_component_code
            AND  cc.component_code (+)= crh.component_code
            AND  crh.module_seq_id = p_in_module_seq_id
            AND  cc.module_seq_id (+)= crh.module_seq_id
            AND  UPPER(cu.userid) = UPPER(crh.requested_by)
            AND  cl.location_id= cu.location_id
            AND  crh.approved_rejected_by IS NULL
            AND  crh.approved_rejected_date IS NULL;

     EXCEPTION
     WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20322,'Error in ecrd_approval_pkg.ecrd_comp_appr_req_details_prc '||SQLCODE);

END ecrd_comp_appr_req_details_prc;

/*
This is used to check if the approval for a component is pending or not.
*/

PROCEDURE ecrd_is_comp_req_pend_prc
(
 p_in_comp_code    IN          crd_e_component_history.component_code%TYPE,
 p_in_module_code  IN          crd_e_component_history.module_seq_id%TYPE,
 p_out_msg         OUT         VARCHAR2
)
IS
var_count  NUMBER(10);
var_status VARCHAR(1);
var_staging_count NUMBER(10);
BEGIN
p_out_msg :='Y';

--If the component exist in the component history table with staging indicator 'S' and approved rejected by field is empty then that component is waiting for approval.

/*
     SELECT
           staging_history_ind
     INTO
         var_status
     FROM  crd_e_component_history
     WHERE component_code  =  p_in_comp_code
     AND   module_seq_id   =  p_in_module_code
     AND   component_end_date IS NULL
     AND   approved_rejected_by IS NULL;
*/

     SELECT
           COUNT(ROWID)
     INTO
         var_staging_count
     FROM  crd_e_component_history
     WHERE component_code  =  p_in_comp_code
     AND   module_seq_id   =  p_in_module_code
     AND   (component_end_date IS NULL OR TRUNC(component_end_date) > TRUNC(SYSDATE))
     AND   approved_rejected_date IS NULL
     AND staging_history_ind = ecrd_utils_pkg.G_STAGING;


     IF var_staging_count >0     -- there is pending approval for component
     THEN
         p_out_msg := 'Y';
     ELSE
-- --If it exist in the main table or the component is completely new and has not been stored in the any of the two tables (staging and master) then the status will be approved for them.
--
--
--             SELECT COUNT(ROWID)
--             INTO var_count
--             FROM crd_e_component
--             WHERE component_code    =  p_in_comp_code
--             AND   module_seq_id  =  p_in_module_code
--             AND   component_end_date IS NULL;
--                  IF var_count > 0 THEN
            p_out_msg :='N';
--                END IF;
      END IF;

   EXCEPTION
     WHEN OTHERS
     THEN
     RAISE_APPLICATION_ERROR(-20322,'Error in ecrd_approval_pkg.ecrd_is_comp_req_pend_prc '||SQLCODE);
END ecrd_is_comp_req_pend_prc;

/*
This is used to get the mails of all the TC associated with the
component site
*/

PROCEDURE ecrd_get_tc_csm_mail(
p_in_component_code  IN    crd_e_comp_location_hist.component_code%TYPE,
p_in_module_code  IN    crd_e_comp_location_hist.module_seq_id%TYPE,
p_out_mail_addr      OUT      result_cursor
)
IS
BEGIN

--Get all the not null mail addresses for the given component locations.

   OPEN p_out_mail_addr
   FOR
	SELECT   cu.email_address
	FROM  crd_crc_user cu,
	      crd_e_component_location clh
	WHERE  cu.location_id = clh.location_id
	AND  clh.module_seq_id =p_in_module_code
	AND  clh.component_code = p_in_component_code
	AND  UPPER(cu.user_role) IN (UPPER(ecrd_utils_pkg.G_TC) ,UPPER(ecrd_utils_pkg.G_CSM))
	AND cu.email_address IS NOT NULL
	AND cu.active_ind = ecrd_utils_pkg.G_USER_ACTIVE;
     EXCEPTION
     WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20322,'Error in ecrd_approval_pkg.ecrd_get_tc_csm_mail '||SQLCODE);
END  ecrd_get_tc_csm_mail;

/*
This procedure gets the list of repairs that are waiting for approval.
*/


PROCEDURE ecrd_get_apprv_repair_list(
   p_in_user_role IN     VARCHAR2,
   p_in_user_id         IN    crd_e_component.CREATED_BY%TYPE,
   p_out_apprv_repair_cur     OUT      result_cursor
)
IS
BEGIN
   IF  UPPER(p_in_user_role) = UPPER(ecrd_utils_pkg.G_ADMIN)
   THEN
                  OPEN p_out_apprv_repair_cur FOR

                  --This gives all the new repairs that are waiting for approval.

                     SELECT
                         cem.eng_mdl_number           mdl_number,
                         cem.eng_mdl_desc            mdl_description,
                         cm.module_name               module_desc,
                              cc.component_description         comp_desc,
                         crh.repair_description          repair_desc,
                         UPPER(cu.first_name||' '||cu.last_name)     user_name,
                         to_char(crh.requested_date,ecrd_utils_pkg.G_DISPLAY_DATE_FORMAT) req_date ,
                         to_char(crh.requested_date,'YYYY/MM/DD') sortable_req_date ,
                         'N' flg,
                         cc.component_code            comp_code,
                         cm.module_seq_id          module_code,
                         crh.repair_seq_id            repair_code,
                         crh.repair_type          repair_type
                     FROM
                        crd_e_repair_history crh,
                        crd_e_repair      cr,
                        crd_e_component      cc,
                        crd_crc_eng_mdl_display cem,
                        crd_crc_module    cm,
                        crd_crc_user      cu
                     WHERE
                            cr.repair_seq_id      (+)= crh.repair_seq_id
                        AND cc.component_code      = crh.component_code
                        AND cc.module_seq_id    = crh.module_seq_id
                        AND cm.module_seq_id    = crh.module_seq_id
                        AND cem.eng_mdl_number     = cm.eng_mdl_number
                        AND UPPER(cu.userid)    = UPPER(crh.requested_by)
                        AND UPPER(crh.staging_history_ind)  = ecrd_utils_pkg.G_STAGING
                        AND crh.approved_rejected_by  IS NULL
                        AND crh.approved_rejected_date   IS NULL
                        AND crh.approve_reject_status IS NULL
                        AND crh.parent_repair_seq_id    IS NULL
                        AND (crh.repair_end_date IS NULL OR crh.repair_end_date >SYSDATE)



                      UNION ALL

                  --This gives all the modified repair list.

                     SELECT
                         cem.eng_mdl_number           mdl_number,
                         cem.eng_mdl_desc            mdl_description,
                         cm.module_name               module_desc,
                         cc.component_description        comp_desc,
                         cr.repair_description           repair_desc,
                         UPPER(cu.first_name||' '||cu.last_name)     user_name,
                         to_char(crch.requested_date,ecrd_utils_pkg.G_DISPLAY_DATE_FORMAT)   req_date ,
                         to_char(crch.requested_date,'YYYY/MM/DD')   sortable_req_date ,
                         'M' flg,
                         cc.component_code            comp_code,
                                   cm.module_seq_id            module_code,
                                   cr.repair_seq_id            repair_code,
                         cr.repair_type                 repair_type
                     FROM
                        crd_e_repair_catalog_hist crch,
                        crd_e_repair      cr,
                        crd_e_component      cc,
                        crd_crc_eng_mdl_display cem,
                        crd_crc_module    cm,
                        crd_crc_user      cu

                     WHERE
                        crch.repair_seq_id NOT IN (select repair_seq_id from crd_e_repair_history where approved_rejected_by IS NULL and staging_history_ind='S')
                        AND cr.repair_seq_id =crch.repair_seq_id
                        AND cc.component_code =cr.component_code
                        AND cc.module_seq_id    = cr.module_seq_id
                        AND cm.module_seq_id    = cr.module_seq_id
                        AND cem.eng_mdl_number     = cm.eng_mdl_number
                        AND UPPER(cu.userid)    = UPPER(crch.requested_by)
                        AND UPPER(crch.staging_history_ind) = ecrd_utils_pkg.G_STAGING
                        AND crch.approv_reject_by  IS NULL
                        AND crch.approved_rejected_date  IS NULL
                        AND crch.approve_reject_status   IS NULL
                        AND cr.parent_repair_seq_id    IS NULL
                        AND crch.repair_display_seq_id is not null
                        AND (crch.repair_end_date IS NULL OR crch.repair_end_date >SYSDATE)

                     ORDER BY mdl_number;

            ELSIF UPPER(p_in_user_role) = ecrd_utils_pkg.G_TC
            THEN

                           OPEN p_out_apprv_repair_cur FOR

                        --This gives all the new repairs that are waiting for approval.

                     SELECT
                              cem.eng_mdl_number            mdl_number,
                              cem.eng_mdl_desc            mdl_description,
                               cm.module_name               module_desc,
                                    cc.component_description         comp_desc,
                               crh.repair_description          repair_desc,
                               UPPER(cu.first_name||' '||cu.last_name)     user_name,
                               to_char(crh.requested_date,ecrd_utils_pkg.G_DISPLAY_DATE_FORMAT) req_date ,
                               to_char(crh.requested_date,'YYYY/MM/DD') sortable_req_date ,
                               'N' flg,
                               cc.component_code            comp_code,
                               cm.module_seq_id          module_code,
                               crh.repair_seq_id            repair_code,
                               crh.repair_type          repair_type
                           FROM
                              crd_e_repair_history crh,
                              crd_e_repair      cr,
                              crd_e_component      cc,
                              crd_crc_eng_mdl_display cem,
                              crd_crc_module    cm,
                              crd_crc_user      cu
                           WHERE
                                    crh.requested_by = p_in_user_id
                              AND    cr.repair_seq_id      (+)= crh.repair_seq_id
                              AND cc.component_code      = crh.component_code
                              AND cc.module_seq_id    = crh.module_seq_id
                              AND cm.module_seq_id    = crh.module_seq_id
                              AND cem.eng_mdl_number     = cm.eng_mdl_number
                              AND UPPER(cu.userid)    = UPPER(crh.requested_by)
                              AND UPPER(crh.staging_history_ind)  = ecrd_utils_pkg.G_STAGING
                              AND crh.approved_rejected_by  IS NULL
                              AND crh.approved_rejected_date   IS NULL
                              AND crh.approve_reject_status IS NULL
                              AND crh.parent_repair_seq_id    IS NULL
                              AND (crh.repair_end_date IS NULL OR crh.repair_end_date >SYSDATE)



                            UNION ALL

                        --This gives all the modified repair list.

                     SELECT
                               cem.eng_mdl_number           mdl_number,
                               cem.eng_mdl_desc            mdl_description,
                               cm.module_name               module_desc,
                               cc.component_description        comp_desc,
                               cr.repair_description           repair_desc,
                               UPPER(cu.first_name||' '||cu.last_name)     user_name,
                               to_char(crch.requested_date,ecrd_utils_pkg.G_DISPLAY_DATE_FORMAT)   req_date ,
                               to_char(crch.requested_date,'YYYY/MM/DD')   sortable_req_date ,
                               'M' flg,
                               cc.component_code            comp_code,
                                         cm.module_seq_id            module_code,
                                         cr.repair_seq_id            repair_code,
                               cr.repair_type                 repair_type
                           FROM
                              crd_e_repair_catalog_hist crch,
                              crd_e_repair      cr,
                              crd_e_component      cc,
                              crd_crc_eng_mdl_display cem,
                              crd_crc_module    cm,
                              crd_crc_user      cu

                           WHERE
                                    crch.requested_by = p_in_user_id
                              AND crch.repair_seq_id NOT IN (select repair_seq_id from crd_e_repair_history where approved_rejected_by IS NULL and staging_history_ind='S')
                              AND cr.repair_seq_id =crch.repair_seq_id
                              AND cc.component_code =cr.component_code
                              AND cc.module_seq_id    = cr.module_seq_id
                              AND cm.module_seq_id    = cr.module_seq_id
                              AND cem.eng_mdl_number     = cm.eng_mdl_number
                              AND UPPER(cu.userid)    = UPPER(crch.requested_by)
                              AND UPPER(crch.staging_history_ind) = ecrd_utils_pkg.G_STAGING
                              AND crch.approv_reject_by  IS NULL
                              AND crch.approved_rejected_date  IS NULL
                              AND crch.approve_reject_status   IS NULL
                              AND cr.parent_repair_seq_id    IS NULL
                              AND crch.repair_display_seq_id is not null
                              AND (crch.repair_end_date IS NULL OR crch.repair_end_date >SYSDATE)

                           ORDER BY mdl_number;

            END IF;

     EXCEPTION
     WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20322,'Error in ecrd_approval_pkg.ecrd_get_apprv_repair_list '||SQLCODE);
END  ecrd_get_apprv_repair_list;


PROCEDURE ecrd_approve_comp_site_prc(
                                       p_in_user_role IN     VARCHAR2,
                                       p_in_user_id         IN    crd_e_component.CREATED_BY%TYPE,
                                    p_result_out OUT result_cursor)
IS
BEGIN

   IF  UPPER(p_in_user_role) = UPPER(ecrd_utils_pkg.G_ADMIN)
   THEN
              OPEN p_result_out FOR
                  SELECT
                        TO_CHAR(clh.CHANGE_START_DATE,ecrd_utils_pkg.g_date_format) change_start_date,
                        clh.LOCATION_ID  location_id,
                        ccm.ENG_MDL_NUMBER  engine_code,
                        cem.eng_mdl_desc engine_model,
                        clh.module_seq_id engine_module,
                        ccm.module_name eng_module_desc,
                        clh.COMPONENT_CODE component_code,
                        cmp.COMPONENT_DESCRIPTION description,
                        cl.site_name location,
                        clh.REQUESTED_BY requested_by,
                        ccu.email_address email_id,
                        UPPER(ccu.first_name) first_name,
                        UPPER(ccu.last_name)  last_name,
                        TO_CHAR(clh.REQUESTED_DATE,ecrd_utils_pkg.g_display_date_format) requested_date,
                        TO_CHAR(clh.REQUESTED_DATE,'YYYY/MM/DD') sortable_requested_date
                FROM     crd_crc_eng_mdl_display cem,
                         crd_e_component cmp,
                         crd_e_comp_location_hist clh,
                         crd_location cl,
                         crd_crc_module ccm,
                         crd_crc_user ccu
               WHERE      (clh.approved_rejected_by IS NULL OR clh.approved_rejected_by ='')
               AND         trim(upper(clh.staging_history_ind))  = ecrd_utils_pkg.G_STAGING
               AND          (clh.approved_rejected_date IS NULL OR clh.approved_rejected_date ='')
               AND          clh.module_seq_id  = cmp.module_seq_id  --join for comp and comp loc history
               AND          clh.component_code = cmp.component_code
               AND          cmp.module_seq_id = ccm.module_seq_id
               AND          ccm.eng_mdl_number = cem.eng_mdl_number
               AND          clh.location_id  = cl.location_id
               AND          UPPER(clh.requested_by) = UPPER(ccu.userid)
               AND       clh.active_ind = ecrd_utils_pkg.g_active;

            ELSIF UPPER(p_in_user_role) = ecrd_utils_pkg.G_TC
            THEN

                 OPEN p_result_out FOR
                  SELECT
                        TO_CHAR(clh.CHANGE_START_DATE,ecrd_utils_pkg.g_date_format) change_start_date,
                        clh.LOCATION_ID  location_id,
                        ccm.ENG_MDL_NUMBER  engine_code,
                        cem.eng_mdl_desc engine_model,
                        clh.module_seq_id engine_module,
                        ccm.module_name eng_module_desc,
                        clh.COMPONENT_CODE component_code,
                        cmp.COMPONENT_DESCRIPTION description,
                        cl.site_name location,
                        clh.REQUESTED_BY requested_by,
                        ccu.email_address email_id,
                        UPPER(ccu.first_name) first_name,
                        UPPER(ccu.last_name)  last_name,
                        TO_CHAR(clh.REQUESTED_DATE,ecrd_utils_pkg.g_display_date_format) requested_date,
                        TO_CHAR(clh.REQUESTED_DATE,'YYYY/MM/DD') sortable_requested_date
                FROM     crd_crc_eng_mdl_display cem,
                         crd_e_component cmp,
                         crd_e_comp_location_hist clh,
                         crd_location cl,
                         crd_crc_module ccm,
                         crd_crc_user ccu
               WHERE    clh.requested_by = p_in_user_id
               AND       (clh.approved_rejected_by IS NULL OR clh.approved_rejected_by ='')
               AND         trim(upper(clh.staging_history_ind))  = ecrd_utils_pkg.G_STAGING
               AND          (clh.approved_rejected_date IS NULL OR clh.approved_rejected_date ='')
               AND          clh.module_seq_id  = cmp.module_seq_id  --join for comp and comp loc history
               AND          clh.component_code = cmp.component_code
               AND          cmp.module_seq_id = ccm.module_seq_id
               AND          ccm.eng_mdl_number = cem.eng_mdl_number
               AND          clh.location_id  = cl.location_id
               AND          UPPER(clh.requested_by) = UPPER(ccu.userid)
               AND       clh.active_ind = ecrd_utils_pkg.g_active;

         END IF;

EXCEPTION
WHEN OTHERS
THEN
--03-may-2006 added pkg name begin
   RAISE_APPLICATION_ERROR(-20020,'Error in ecrd_approval_pkg.ecrd_approve_comp_site_prc--'||SQLCODE||'-'||substr(sqlerrm,1,100));
--03-may-2006 added pkg name end
END ecrd_approve_comp_site_prc;


/*
This procedure gives information about the repair waiting for approval.
The information given are the requestor name and site,requested date,e mail address of the requestor etc.
*/

PROCEDURE ecrd_rep_apprv_details_prc(
p_in_repair_seq_id   IN crd_e_repair_history.repair_seq_id%TYPE,
p_out_repair_apprv_det_cur OUT   result_cursor
)
IS
BEGIN
OPEN p_out_repair_apprv_det_cur FOR
SELECT
            NVL(crph.approv_reject_by,' '),
            NVL(to_char(crph.approved_rejected_date,ecrd_utils_pkg.G_DISPLAY_DATE_FORMAT),' '),
            NVL(cl.site_name,' '),
       UPPER(cu.first_name || ' ' || cu.last_name) User_Name,
            crph.approve_reject_status,
            decode(cr.repair_description,NULL,'N','M')   flg,
            NVL(to_char(crph.requested_date,ecrd_utils_pkg.G_DISPLAY_DATE_FORMAT),' '),
       cu.email_address,
       cu.userid UserId
     FROM   crd_e_repair_catalog_hist crph,
            crd_e_repair cr,
            crd_crc_user cu,
            crd_location cl
     WHERE
                 crph.repair_seq_id = p_in_repair_seq_id
            AND  cr.repair_seq_id (+)=crph.repair_seq_id
            AND  UPPER(cu.userid) = UPPER(crph.requested_by)
            AND  UPPER(cl.location_id) = UPPER(cu.location_id)
            AND  crph.approv_reject_by IS NULL
            AND  crph.approve_reject_status IS NULL
            AND  crph.approved_rejected_date IS NULL
            AND  crph.staging_history_ind = ecrd_utils_pkg.G_STAGING ;
--
 EXCEPTION
     WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20322,'Error in ecrd_approval_pkg.ecrd_rep_apprv_details_prc '||SQLCODE);

END ecrd_rep_apprv_details_prc;


/*
This method is used to reject the repair
*/




PROCEDURE ecrd_reject_repair_prc
(
   p_in_repair_seq_id   IN    VARCHAR2,--crd_e_repair_history.repair_seq_id%TYPE,
   p_in_catalog_seq_id  IN    VARCHAR2,
   p_in_user_id         IN    crd_e_repair_history.approved_rejected_by%TYPE,
   p_in_reject_comment  IN    VARCHAR2,
   p_in_moule_seq_id    IN    VARCHAR2,
   p_in_component_code  IN    VARCHAR2,

   p_out_message       OUT    VARCHAR2
)
IS
var_rep_type VARCHAR2(5);
var_repair_new_modified VARCHAR2(10);
BEGIN
p_out_message := 'REPAIR_REJECT_FAILURE';
-- BEGIN

/*
This determines if the repair to be rejected is new one or the modified one
by checkin in the repair history table.
*/

      SELECT COUNT(ROWID)
      INTO var_repair_new_modified
      FROM crd_e_repair_history
      WHERE repair_seq_id=p_in_repair_seq_id
      AND approved_rejected_by IS NULL
      AND staging_history_ind= ecrd_utils_pkg.G_STAGING
      AND (repair_end_date >SYSDATE OR repair_end_date IS NULL);

      IF var_repair_new_modified >0
      THEN

--This means that there is data in the repair history table for the given input data so the given repair is a new repair and not a modified one.
--The follwoing gets the repair type of the repair to be rejected.

 BEGIN
      SELECT
         repair_type INTO var_rep_type
      FROM  crd_e_repair_history
      WHERE repair_seq_id=p_in_repair_seq_id
         AND staging_history_ind=ecrd_utils_pkg.G_STAGING
         AND approved_rejected_date IS NULL
         AND approved_rejected_by IS NULL;
--03-MAY-2006 ADDED EXCEPTION BEGIN
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  var_rep_type :=' ';
  END;
--03-MAY-2006 ADDED EXCEPTION END

--Updating the repair history table

      UPDATE crd_e_repair_history
      SET
               approved_rejected_by = p_in_user_id,
          approve_reject_status = ecrd_utils_pkg.G_REJECT_STATUS,
               approved_rejected_date = sysdate,
          last_update_date = sysdate,
               last_updated_by = p_in_user_id,
          rejection_comments = p_in_reject_comment
           WHERE repair_seq_id = to_number(p_in_repair_seq_id)
      AND staging_history_ind = ecrd_utils_pkg.G_STAGING
      AND approved_rejected_by IS NULL
      AND repair_end_date IS NULL;

--Updating the repair catalog history table.

      UPDATE crd_e_repair_catalog_hist
      SET
          approv_reject_by = p_in_user_id,
          approved_rejected_date = SYSDATE,
          approve_reject_status= ecrd_utils_pkg.G_REJECT_STATUS,
          last_update_date=SYSDATE,
          last_updated_by=p_in_user_id,
          rejection_comments=p_in_reject_comment
      WHERE
          repair_seq_id = p_in_repair_seq_id
          AND catalog_seq_id = to_number(p_in_catalog_seq_id)
          AND staging_history_ind =ecrd_utils_pkg.G_STAGING
          AND repair_end_date IS NULL
          AND approv_reject_by IS NULL;

--Updating the repair cost history table

      UPDATE crd_e_repair_cost_history
      SET
          approv_reject_date = SYSDATE,
          approv_reject_status= ecrd_utils_pkg.G_REJECT_STATUS,
          last_update_date=SYSDATE,
          last_updated_by=p_in_user_id,
          reject_comments=p_in_reject_comment
      WHERE
         repair_seq_id= p_in_repair_seq_id
         AND module_seq_id =TO_NUMBER(p_in_moule_seq_id)
         AND component_code = p_in_component_code
         AND approv_reject_date IS NULL;

--If the repair is a group repair then the child repair of it need to be rejected also.

   IF var_rep_type = ecrd_utils_pkg.G_GROUP_REPAIR
   THEN

--Updating the history tables for the child repair of the given group repair.

      UPDATE crd_e_repair_history
       SET
         approved_rejected_by = p_in_user_id,
         approve_reject_status = ecrd_utils_pkg.G_REJECT_STATUS,
              approved_rejected_date = sysdate,
              last_update_date = sysdate,
         last_updated_by = p_in_user_id
      WHERE
         parent_repair_seq_id = p_in_repair_seq_id
         AND UPPER(staging_history_ind)= ecrd_utils_pkg.G_STAGING;

      UPDATE crd_e_repair_catalog_hist
       SET
         approv_reject_by = p_in_user_id,
         approve_reject_status = ecrd_utils_pkg.G_REJECT_STATUS,
              approved_rejected_date = sysdate,
              last_update_date = sysdate,
         last_updated_by = p_in_user_id
      WHERE
         repair_seq_id IN
         (
            SELECT   repair_seq_id
            FROM  crd_e_repair_history
            WHERE parent_repair_seq_id = p_in_repair_seq_id
         )
         AND catalog_seq_id = p_in_catalog_seq_id
         AND UPPER(staging_history_ind) = ecrd_utils_pkg.G_STAGING;
         END IF;
-- END IF;
-- EXCEPTION
--    WHEN NO_DATA_FOUND THEN
   ELSE
--If the given repair is a modified one then only the repair catalog history table needs to be modifed and not all the tables.

      UPDATE crd_e_repair_catalog_hist
      SET
          approv_reject_by = p_in_user_id,
          approved_rejected_date = SYSDATE,
          approve_reject_status= ecrd_utils_pkg.G_REJECT_STATUS,
          last_update_date=SYSDATE,
          last_updated_by=p_in_user_id,
          rejection_comments=p_in_reject_comment
      WHERE
          repair_seq_id = p_in_repair_seq_id
          AND catalog_seq_id = to_number(p_in_catalog_seq_id)
          AND staging_history_ind =ecrd_utils_pkg.G_STAGING
          AND repair_end_date IS NULL
          AND approv_reject_by IS NULL;
   END IF;
-- END;
COMMIT;
p_out_message := 'REPAIR_REJECT_SUCCESS';
EXCEPTION
 WHEN OTHERS THEN
    ROLLBACK;
    p_out_message := 'REPAIR_REJECT_FAILURE';
    RAISE_APPLICATION_ERROR(-20322,'Error in ecrd_approval_pkg.ecrd_reject_repair_prc '||'--'||SQLCODE||'-'||SUBSTR(SQLERRM,1,100));
END ecrd_reject_repair_prc;

/*

This procedure is used to approve an individual repair

*/


PROCEDURE ecrd_approve_ind_repair_prc
(
   p_in_repair_seq_id   IN    crd_e_repair.repair_seq_id%TYPE,
   p_in_repair_desc  IN    crd_e_repair.repair_description%TYPE,
   p_in_module_id    IN    crd_e_repair.module_seq_id%TYPE,
   p_in_component_code  IN crd_e_repair.component_code%TYPE,
   p_in_rep_eff_date IN VARCHAR2,--crd_e_repair.repair_effective_date%TYPE ,
   p_in_rep_volume      IN crd_e_repair.repair_volume%TYPE,
   p_in_rep_ref_no      IN crd_e_repair.repair_reference%TYPE,
   p_in_rep_ref_format  IN crd_e_repair.repair_reference_format%TYPE,
   p_in_repair_comments IN crd_e_repair.repair_comments%TYPE,
   p_in_inc_TAT_ind  IN crd_e_repair_catalog.incremental_tat_ind%TYPE,
   p_in_inc_TAT      IN VARCHAR2,--crd_e_repair_catalog.repair_tat%TYPE,
   p_in_inc_pr_ind      IN crd_e_repair_catalog.incremental_price_ind%TYPE,
   p_in_pr        IN VARCHAR2,--crd_e_repair_catalog.repair_price%TYPE,
   p_in_pr_type      IN crd_e_repair_catalog.price_type%TYPE,
   p_in_fut_tat      IN VARCHAR2,--crd_e_repair_catalog.future_tat%TYPE,
   p_in_fut_pr    IN VARCHAR2,--crd_e_repair_catalog.future_price%TYPE,
   p_in_fut_pr_eff_dt   IN VARCHAR2,--crd_e_repair_catalog.future_effective_date%TYPE,
   p_in_user_id      IN crd_e_repair_history.approved_rejected_by%TYPE,
   p_in_catalog_seq_id  IN VARCHAR2,--crd_e_repair_catalog.catalog_seq_id%TYPE,
   p_in_rep_disp_seq_id IN VARCHAR2,--crd_e_repair_catalog.repair_display_seq_id%TYPE,
   p_in_approv_type  IN VARCHAR2,
   p_out_message     OUT   VARCHAR2
)
IS

/* Patni 04-Sep-2006 - To get the repair attributes from the Settings table - Begin */
CURSOR cur_repair_attributes
IS
SELECT CRD_E_SETTINGS_SEQ_ID,
       COLUMN_NAME
FROM   CRD_E_SETTINGS
WHERE  SETTING_ID = 1
AND    UPPER(ACTIVE_IND) = 'Y';
/* Patni 04-Sep-2006 - To get the repair attributes from the Settings table - End */

v_count NUMBER := 0;

v_rep_eff_date DATE := NULL;
v_rep_fut_eff_dt DATE :=NULL;
v_repair_tat crd_e_repair_catalog.repair_tat%TYPE;
v_repair_tat_ind crd_e_repair_catalog.incremental_tat_ind%TYPE;
v_price_inc_ind crd_e_repair_catalog.incremental_price_ind%TYPE;
v_price crd_e_repair_catalog.repair_price%TYPE;
v_price_type crd_e_repair_catalog.price_type%TYPE;
v_creation_date DATE := NULL;
v_created_by VARCHAR2(20) :=NULL;
v_repair_display_seq_id crd_e_repair_catalog.repair_display_seq_id%TYPE;

/* Patni 04-Sep-2006 - Declaring variables - Begin */
v_crd_e_repair_catalog_seq_id    CRD_E_REPAIR_CATALOG.CRD_E_REPAIR_CATALOG_SEQ_ID%TYPE;   
v_old_repair_price               CRD_E_REPAIR_CATALOG_HIST.REPAIR_PRICE%TYPE;   
v_old_repair_tat                 CRD_E_REPAIR_CATALOG_HIST.REPAIR_TAT%TYPE;   
v_settings_seq_id                CRD_E_SETTINGS.CRD_E_SETTINGS_SEQ_ID%TYPE;
v_column_name                    CRD_E_SETTINGS.COLUMN_NAME%TYPE;
v_settings_seq_arr               ECRD_UTILS_PKG.VARRAY_PART;
v_settings_seq_id_data           VARCHAR2(10) := NULL;
v_repair_modified                NUMBER       := 1;
v_data_exist                     NUMBER       := 0;
v_data_modified                  BOOLEAN      := FALSE;
/* Patni 04-Sep-2006 - Declaring variables - End */      

BEGIN
     v_rep_eff_date :=  TO_DATE(p_in_rep_eff_date,ecrd_utils_pkg.G_DATE_FORMAT);
     v_rep_fut_eff_dt := TO_DATE(p_in_fut_pr_eff_dt,ecrd_utils_pkg.G_DATE_FORMAT);
     p_out_message := 'REPAIR_APPROVE_FAILURE';

     /* Patni 04-Sep-2006 - To get the current value of the repair attributes - Begin */
     v_old_repair_price := NULL;
     v_old_repair_tat   := NULL; 
      
     BEGIN
          SELECT REPAIR_PRICE,
                 REPAIR_TAT
          INTO   v_old_repair_price,
                 v_old_repair_tat
          FROM   CRD_E_REPAIR_CATALOG_HIST
          WHERE  CATALOG_SEQ_ID = p_in_catalog_seq_id
          AND    REPAIR_SEQ_ID  = p_in_repair_seq_id
          AND    APPROV_REJECT_BY IS NULL
          AND    UPPER(STAGING_HISTORY_IND) = ECRD_UTILS_PKG.G_STAGING;

     EXCEPTION
     WHEN NO_DATA_FOUND THEN
          v_old_repair_price := NULL;
          v_old_repair_tat   := NULL;
     END;
     /* Patni 04-Sep-2006 - To get the current value of the repair attributes - End */              
     
--First check from the approve type if the individual repair is a new one or the modified one.
-- Kalyan added starts on 7th Nov 2005
BEGIN
-- Kalyan added ends on 7th Nov 2005
            SELECT
                   created_by,
                   creation_date
            INTO
                  v_created_by,
                  v_creation_date
            FROM crd_e_repair_catalog_hist
            WHERE repair_seq_id = TO_NUMBER(p_in_repair_seq_id)
            AND catalog_seq_id = TO_NUMBER(p_in_catalog_seq_id)
            AND UPPER(staging_history_ind) =ecrd_utils_pkg.G_STAGING
            AND approv_reject_by IS NULL;
-- Kalyan added starts on 7th Nov 2005
EXCEPTION
WHEN NO_DATA_FOUND THEN
p_out_message := 'REPAIR_APPROVE_FAILURE';
END;


     IF NVL(LENGTH(TRIM(v_created_by)),'0') <> '0' THEN
-- Kalyan added ends  on 7th Nov 2005
     IF UPPER(p_in_approv_type) = ecrd_utils_pkg.G_NO THEN

--Update the repair history tables for the changed data by the approver at the front end.

      UPDATE crd_e_repair_history
         SET   repair_description = p_in_repair_desc,
               repair_reference = p_in_rep_ref_no,
               repair_effective_date = v_rep_eff_date,
               repair_volume = p_in_rep_volume,
               repair_reference_format = p_in_rep_ref_format,
               repair_comments = p_in_repair_comments,
               last_updated_by = p_in_user_id,
               last_update_date=SYSDATE,
               approved_rejected_by = p_in_user_id,
               approve_reject_status = ecrd_utils_pkg.G_APPROVE_STATUS,
               approved_rejected_date = SYSDATE
            WHERE repair_seq_id = TO_NUMBER(p_in_repair_seq_id)
            AND UPPER(staging_history_ind) = ecrd_utils_pkg.G_STAGING;

      UPDATE crd_e_repair_catalog_hist
      SET
          incremental_tat_ind = p_in_inc_TAT_ind,
          repair_tat = TO_NUMBER(p_in_inc_TAT),
          incremental_price_ind = p_in_inc_pr_ind,
          --repair_price = DECODE(p_in_pr,0,NULL,TO_NUMBER(p_in_pr)),
          repair_price = TO_NUMBER(p_in_pr),
          price_type=p_in_pr_type,
          --future_tat=DECODE(p_in_fut_tat,0,NULL,TO_NUMBER(p_in_fut_tat)),
          future_tat    =  TO_NUMBER(p_in_fut_tat),
          --future_price=DECODE(p_in_fut_pr,0,NULL,TO_NUMBER(p_in_fut_pr)),
          future_price  =  TO_NUMBER(p_in_fut_pr),
          future_effective_date=v_rep_fut_eff_dt,
          approv_reject_by=p_in_user_id,
          approved_rejected_date = SYSDATE,
          approve_reject_status = ecrd_utils_pkg.G_APPROVE_STATUS,
          last_update_date = SYSDATE,
          last_updated_by = p_in_user_id
      WHERE
         repair_seq_id = TO_NUMBER(p_in_repair_seq_id)
         AND catalog_seq_id = TO_NUMBER(p_in_catalog_seq_id)
         AND UPPER(staging_history_ind) =ecrd_utils_pkg.G_STAGING;



               SELECT count(1)
               INTO v_count
               FROM crd_e_repair
               WHERE repair_seq_id = TO_NUMBER(p_in_repair_seq_id);


        IF v_count > 0
        THEN
            p_out_message := 'REPAIR_ALREADY_EXISTS';
            ROLLBACK;
            RETURN;
        END IF;


--This is used to check if there is any repair in the main table with same repair seq id whose end date is less than the sysdate.

     SELECT COUNT(ROWID)
       INTO v_count
       FROM crd_e_repair
       WHERE   repair_seq_id=p_in_repair_seq_id
       AND  component_code =p_in_component_code
       AND  module_seq_id=p_in_module_id
       AND  repair_end_date < SYSDATE;

--If there is any such record then instead of inserting a new record in the main tabel update the table with the modified details.
--And the old data at the main table will be transfered to the history table wiht history indicator.

    IF v_count > 0
    THEN
      INSERT INTO crd_e_repair_history
      (
         repair_seq_id,
         staging_history_ind,
         change_start_date,
         component_code,
         repair_type,
         module_seq_id,
         repair_description,
         repair_reference,
         repair_comments,
         repair_reference_format,
         repair_effective_date,
         repair_end_date,
         requested_by,
         approved_rejected_by,
         requested_date,
         approved_rejected_date,
         repair_volume,
         approve_reject_status,
         rejection_comments,
         creation_date,
         created_by,
         last_update_date,
         last_updated_by,
         parent_repair_seq_id
      )
      (
      SELECT
         repair_seq_id,
         ecrd_utils_pkg.G_HISTORY_RECORD,
         SYSDATE,
         component_code,
         repair_type,
         module_seq_id,
         repair_description,
         repair_reference,
         repair_comments,
         repair_reference_format,
         repair_effective_date,
         NULL,
         NULL,
         NULL,
         NULL,
         NULL,
         repair_volume,
         NULL,
         NULL,
         creation_date,
         created_by,
         SYSDATE,
         p_in_user_id,
         parent_repair_seq_id

         FROM crd_e_repair
         WHERE repair_seq_id=p_in_repair_seq_id
         AND   component_code =p_in_component_code
         AND   module_seq_id=p_in_module_id
         AND   (repair_end_date < SYSDATE OR repair_end_date IS NULL)
      );

/*
   4-Feb-2005
   Changed the change start date from SYSDATE+1 to SYSDATE for History record.
*/
      INSERT INTO crd_e_repair_catalog_hist
      (
         catalog_seq_id,
         repair_seq_id,
         effective_date,
         staging_history_ind,
         change_start_date,
         repair_price,
         incremental_price_ind,
         repair_tat,
         incremental_tat_ind,
         future_price,
         future_effective_date,
         price_type,
         repair_end_date,
         future_tat,
         created_by,
         creation_date,
         last_update_date,
         last_updated_by,
         repair_display_seq_id,
         requested_by,
         requested_date,
         approv_reject_by,
         approved_rejected_date,
         approve_reject_status,
         rejection_comments,
         price_overwrite_flag_ind
      )
      (
         SELECT
            catalog_seq_id,
            repair_seq_id,
            effective_date,
            ecrd_utils_pkg.G_HISTORY_RECORD,
            SYSDATE,
            repair_price,
            incremental_price_ind,
            repair_tat,
            incremental_tat_ind,
            future_price,
            future_effective_date,
            price_type,
            NULL,
            future_tat,
            created_by,
            creation_date,
            SYSDATE,
            p_in_user_id,
            repair_display_seq_id,
            NULL,
            NULL,
            NULL,
            NULL,
            NULL,
            NULL,
            price_overwrite_flag_ind
         FROM crd_e_repair_catalog
         WHERE repair_seq_id=p_in_repair_seq_id
         AND   catalog_seq_id=p_in_catalog_seq_id
         AND   (repair_end_date < SYSDATE OR repair_end_date IS NULL)
      );

--The main tables are updated here.

       UPDATE crd_e_repair
       SET
         repair_end_date='',
         repair_type    = ecrd_utils_pkg.G_INDIVIDUAL_REPAIR,
         repair_description   = p_in_repair_desc,
         parent_repair_seq_id = NULL,
         repair_reference  = NULL,
         repair_comments      = p_in_repair_comments,
         repair_reference_format = NULL,
         repair_effective_date   = v_rep_eff_date,
         repair_volume     = p_in_rep_volume,
         /*
         created_by     = v_created_by,
         creation_date     = v_creation_date,
         */
         last_update_date  = SYSDATE,
         last_updated_by      = p_in_user_id
      WHERE repair_seq_id     = p_in_repair_seq_id
       AND  component_code    = p_in_component_code
       AND  module_seq_id     = p_in_module_id
       AND  (repair_end_date < SYSDATE OR repair_end_date IS NULL);

/*
   4-Feb-05
   Changed the Effective Date to SYSDATE instead of repair effective date
   Getting the Original Repair TAT,TAT ind,Repair Price,Price Ind,Price Type.
   If Any one of these has been changed then update effective date as SYSDATE.
*/
    BEGIN
      SELECT
         --NVL(repair_tat,0),
         repair_tat,
         incremental_tat_ind,
         incremental_price_ind,
         --NVL(repair_price,0),
         repair_price,
         price_type
      INTO
         v_repair_tat,
         v_repair_tat_ind,
         v_price_inc_ind,
         v_price,
         v_price_type
      FROM
         crd_e_repair_catalog
      WHERE
         repair_seq_id = p_in_repair_seq_id AND
         catalog_seq_id = p_in_catalog_seq_id AND
         (repair_end_date IS NULL OR repair_end_date > SYSDATE);
--03-MAY-2006 ADDED EXCEPTION BEGIN
       EXCEPTION
       WHEN NO_DATA_FOUND THEN
         v_repair_tat :=' ' ;
         v_repair_tat_ind := ' ';
         v_price_inc_ind := ' ';
         v_price := ' ';
         v_price_type := ' ';
END;
--03-MAY-2006 ADDED EXCEPTION END

      UPDATE crd_e_repair_catalog
      SET
         repair_end_date      = '',
         repair_seq_id     = TO_NUMBER(p_in_repair_seq_id),
         catalog_seq_id    = TO_NUMBER(p_in_catalog_seq_id),
         --repair_price    = DECODE(p_in_pr,0,NULL,TO_NUMBER(p_in_pr)),
         repair_price      = TO_NUMBER(p_in_pr),
         incremental_price_ind   = p_in_inc_pr_ind,
         repair_tat     = TO_NUMBER(p_in_inc_TAT),
         incremental_tat_ind  = p_in_inc_TAT_ind,
         --future_price    = DECODE(p_in_fut_pr,0,NULL,TO_NUMBER(p_in_fut_pr)),
         future_price      = TO_NUMBER(p_in_fut_pr),
         future_effective_date   = v_rep_fut_eff_dt,
         price_type     = p_in_pr_type,
         repair_display_seq_id   = p_in_rep_disp_seq_id,
         --future_tat      = DECODE(p_in_fut_tat,0,NULL,TO_NUMBER(p_in_fut_tat)),
         future_tat     = TO_NUMBER(p_in_fut_tat),
         price_overwrite_flag_ind= NULL,
         /*
         created_by     = v_created_by,
         creation_date     = v_creation_date,
         */
         last_update_date  = SYSDATE,
         last_updated_by      = p_in_user_id
      WHERE repair_seq_id=p_in_repair_seq_id
      AND   catalog_seq_id=p_in_catalog_seq_id
      AND   (repair_end_date < SYSDATE OR repair_end_date IS NULL);

      IF((NVL(v_repair_tat,-1) <> TO_NUMBER(NVL(p_in_inc_TAT,-1)))OR
      (v_repair_tat_ind <> p_in_inc_TAT_ind)OR
      (v_price_inc_ind <> p_in_inc_pr_ind)OR
      (NVL(v_price,-1) <> TO_NUMBER(NVL(p_in_pr,-1)))OR
      (v_price_type <> p_in_pr_type))
      THEN
         UPDATE crd_e_repair_catalog
         SET
            effective_date = SYSDATE
         WHERE
            catalog_seq_id = p_in_catalog_seq_id
            AND  repair_seq_id = p_in_repair_seq_id
            AND (repair_end_date IS NULL OR repair_end_date > SYSDATE);
      END IF;

   ELSE
--If there is no record in the main table with same repair seq id and repair end date less than the sysdate,
--then insert in the main table the values entered by the approver.
--New Record is created with Repair Effective Date in crd_e_repair table and
--effective date in crd_e_repair_catalog as SYSDATE
/*
   4-Feb-2005
   Removing the hard coding of repair type.
*/
       /* Kalyan adds starts on 7th Nov 2005*/
         UPDATE crd_e_repair_history
         SET   repair_description = p_in_repair_desc,
               repair_reference = p_in_rep_ref_no,
               repair_effective_date = v_rep_eff_date,
               repair_volume = p_in_rep_volume,
               repair_reference_format = p_in_rep_ref_format,
               repair_comments = p_in_repair_comments,
               last_updated_by = p_in_user_id,
               last_update_date=SYSDATE,
               approved_rejected_by = p_in_user_id,
               approve_reject_status = ecrd_utils_pkg.G_APPROVE_STATUS,
               approved_rejected_date = SYSDATE
            WHERE repair_seq_id = TO_NUMBER(p_in_repair_seq_id)
            AND UPPER(staging_history_ind) = ecrd_utils_pkg.G_STAGING;
       /*Kalyan adds ends on 7th Nov 2005*/
       INSERT INTO crd_e_repair
       (
         repair_seq_id,
         module_seq_id,
         component_code,
         repair_type,
         repair_description,
         parent_repair_seq_id,
         repair_reference,
         repair_comments,
         repair_reference_format,
         repair_effective_date,
         repair_volume,
         repair_end_date,
         created_by,
         creation_date,
         last_update_date,
         last_updated_by
       )
       VALUES
       (
       TO_NUMBER(p_in_repair_seq_id),
       p_in_module_id,
       p_in_component_code,
       ecrd_utils_pkg.G_INDIVIDUAL_REPAIR,
       p_in_repair_desc,
       NULL,
       p_in_rep_ref_no,
       p_in_repair_comments,
       p_in_rep_ref_format,
       SYSDATE,
       p_in_rep_volume,
       NULL,
       v_created_by,
       v_creation_date,
       SYSDATE,
       p_in_user_id
       );
       
       INSERT INTO crd_e_repair_catalog
       (
         /* Patni 04-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - Begin */
         crd_e_repair_catalog_seq_id,
         /* Patni 04-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - End */
         repair_seq_id,
         catalog_seq_id,
         effective_date,
         repair_price,
         incremental_price_ind,
         repair_tat,
         incremental_tat_ind,
         future_price,
         future_effective_date,
         price_type,
         repair_end_date,
         repair_display_seq_id,
         future_tat,
         created_by,
         creation_date,
         last_update_date,
         last_updated_by
       )
       VALUES
       (
         /* Patni 04-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - Begin */
         crd_e_repair_catalog_seq.nextval,
         /* Patni 04-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - End */
         TO_NUMBER(p_in_repair_seq_id),
         TO_NUMBER(p_in_catalog_seq_id),
         SYSDATE,
         --DECODE(p_in_pr,0,NULL,TO_NUMBER(p_in_pr)),
         TO_NUMBER(p_in_pr),
         p_in_inc_pr_ind,
         TO_NUMBER(p_in_inc_TAT),
         p_in_inc_TAT_ind,
         --DECODE(p_in_fut_pr,0,NULL,TO_NUMBER(p_in_fut_pr)),
         TO_NUMBER(p_in_fut_pr),
         v_rep_fut_eff_dt,
         p_in_pr_type,
         NULL,
         TO_NUMBER(p_in_rep_disp_seq_id),
         --DECODE(p_in_fut_tat,0,NULL,TO_NUMBER(p_in_fut_tat)),
         TO_NUMBER(p_in_fut_tat),
         v_created_by,
         v_creation_date,
         SYSDATE,
         p_in_user_id
       );
        END IF;
    ELSE

--If the repair is modified then only the repair catalog table data needs to be handled.

--Inserting the existing data of the main table in the history table with history indicator.
BEGIN
      SELECT
      repair_display_seq_id
      INTO
       v_repair_display_seq_id
       FROM CRD_E_REPAIR_CATALOG_HIST
       WHERE
         repair_seq_id     = p_in_repair_seq_id
         AND catalog_seq_id   = p_in_catalog_seq_id
         AND staging_history_ind = ecrd_utils_pkg.G_STAGING
         AND approv_reject_by IS NULL;
--03-MAY-2006 ADDED EXCEPTION BEGIN
EXCEPTION
WHEN NO_DATA_FOUND THEN
       v_repair_display_seq_id := ' ';
END;
--03-MAY-2006 ADDED EXCEPTION END

   INSERT INTO crd_e_repair_catalog_hist
      (
         catalog_seq_id,
         repair_seq_id,
         effective_date,
         staging_history_ind,
         change_start_date,
         repair_price,
         incremental_price_ind,
         repair_tat,
         incremental_tat_ind,
         future_price,
         future_effective_date,
         price_type,
         repair_end_date,
         future_tat,
         created_by,
         creation_date,
         last_update_date,
         last_updated_by,
         repair_display_seq_id,
         requested_by,
         requested_date,
         approv_reject_by,
         approved_rejected_date,
         approve_reject_status,
         rejection_comments
      )
      (
      SELECT
         catalog_seq_id,
         repair_seq_id,
         effective_date,
         ecrd_utils_pkg.G_HISTORY_RECORD,
         SYSDATE,
         repair_price,
         incremental_price_ind,
         repair_tat,
         incremental_tat_ind,
         future_price,
         future_effective_date,
         price_type,
         NULL,
         future_tat,
         created_by,
         creation_date,
         SYSDATE,
         p_in_user_id,
         repair_display_seq_id,
         NULL,
         NULL,
         p_in_user_id,
         SYSDATE,
         ecrd_utils_pkg.G_APPROVE_STATUS,
         NULL
      FROM
      crd_e_repair_catalog

      WHERE
         repair_seq_id = TO_NUMBER(p_in_repair_seq_id)
         AND catalog_seq_id = TO_NUMBER(p_in_catalog_seq_id)
       );

--Updating the staging data in the repair catalog history table.

         UPDATE crd_e_repair_catalog_hist
            SET
            incremental_tat_ind = p_in_inc_TAT_ind,
            repair_tat = TO_NUMBER(p_in_inc_TAT),
            incremental_price_ind = p_in_inc_pr_ind,
            --repair_price = DECODE(p_in_pr,0,NULL,TO_NUMBER(p_in_pr)),
            repair_price = TO_NUMBER(p_in_pr),
            price_type=p_in_pr_type,
            --future_tat=DECODE(p_in_fut_tat,0,NULL,TO_NUMBER(p_in_fut_tat)),
            future_tat=TO_NUMBER(p_in_fut_tat),
            --future_price=DECODE(p_in_fut_pr,0,NULL,TO_NUMBER(p_in_fut_pr)),
            future_price=TO_NUMBER(p_in_fut_pr),
            future_effective_date=v_rep_fut_eff_dt,approv_reject_by=p_in_user_id,
            approved_rejected_date = SYSDATE,
            approve_reject_status = ecrd_utils_pkg.G_APPROVE_STATUS,
            last_update_date = SYSDATE,
            last_updated_by = p_in_user_id
          WHERE
            repair_seq_id = TO_NUMBER(p_in_repair_seq_id)
            AND catalog_seq_id = TO_NUMBER(p_in_catalog_seq_id)
            AND staging_history_ind = ecrd_utils_pkg.G_STAGING
            AND (repair_end_date IS NULL OR repair_end_date <SYSDATE );

--Updating the main repair catalog table.
/*
   4-Feb-2005
   Updating Effective Date as SYSDATE.
   Changed the Effective Date to SYSDATE instead of repair effective date
   Getting the Original Repair TAT,TAT ind,Repair Price,Price Ind,Price Type.
   If Any one of these has been changed then update effective date as SYSDATE.
*/
     BEGIN
       SELECT
         --NVL(repair_tat,0),
         repair_tat,
         incremental_tat_ind,
         incremental_price_ind,
         --NVL(repair_price,0),
         repair_price,
         price_type
      INTO
         v_repair_tat,
         v_repair_tat_ind,
         v_price_inc_ind,
         v_price,
         v_price_type
      FROM
         crd_e_repair_catalog
      WHERE
         repair_seq_id = p_in_repair_seq_id AND
         catalog_seq_id = p_in_catalog_seq_id AND
         (repair_end_date IS NULL OR repair_end_date > SYSDATE);
--03-MAY-2006 ADDED EXCEPTION BEGIN
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
         v_repair_tat :=' ';
         v_repair_tat_ind := ' ';
         v_price_inc_ind := ' ';
         v_price := ' ';
         v_price_type := ' ';
      END;
--03-MAY-2006 ADDED EXCEPTION END
       UPDATE crd_e_repair_catalog
       SET
            incremental_tat_ind = p_in_inc_TAT_ind,
            repair_tat = TO_NUMBER(p_in_inc_TAT),
            incremental_price_ind = p_in_inc_pr_ind,
            --repair_price = DECODE(p_in_pr,0,NULL,TO_NUMBER(p_in_pr)),
            repair_price = TO_NUMBER(p_in_pr),
            price_type=p_in_pr_type,
            repair_display_seq_id = v_repair_display_seq_id,
            --future_tat=DECODE(p_in_fut_tat,0,NULL,TO_NUMBER(p_in_fut_tat)),
            future_tat=TO_NUMBER(p_in_fut_tat),
            --future_price=DECODE(p_in_fut_pr,0,NULL,TO_NUMBER(p_in_fut_pr)),
            future_price=TO_NUMBER(p_in_fut_pr),
            future_effective_date=v_rep_fut_eff_dt,
            last_update_date = SYSDATE,
            last_updated_by = p_in_user_id
       WHERE
         repair_seq_id = TO_NUMBER(p_in_repair_seq_id)
         AND catalog_seq_id = TO_NUMBER(p_in_catalog_seq_id);

       IF((NVL(v_repair_tat,-1) <> to_number(NVL(p_in_inc_TAT,-1)))OR
         (v_repair_tat_ind <> p_in_inc_TAT_ind)OR
         (v_price_inc_ind <> p_in_inc_pr_ind)OR
         (NVL(v_price,-1) <> TO_NUMBER(NVL(p_in_pr,-1)))OR
         (v_price_type <> p_in_pr_type))
         THEN
            UPDATE crd_e_repair_catalog
            SET
               effective_date = SYSDATE
            WHERE
               catalog_seq_id = p_in_catalog_seq_id
               AND  repair_seq_id = p_in_repair_seq_id
               AND (repair_end_date IS NULL OR repair_end_date > SYSDATE);
       END IF;
END IF;
-- Kalyan added starts on 7th Nov 2005
END IF;
-- Kalyan added ends on 7th Nov 2005

 /* Patni 04-Sep-2006 - To check if the repair attributes are modified - Begin */
 v_crd_e_repair_catalog_seq_id := NULL;    

 BEGIN
      SELECT CRD_E_REPAIR_CATALOG_SEQ_ID
      INTO   v_crd_e_repair_catalog_seq_id
      FROM   CRD_E_REPAIR_CATALOG
      WHERE  CATALOG_SEQ_ID = p_in_catalog_seq_id
      AND    REPAIR_SEQ_ID  = p_in_repair_seq_id
      AND    (REPAIR_END_DATE IS NULL OR REPAIR_END_DATE > SYSDATE);

 EXCEPTION
 WHEN NO_DATA_FOUND THEN
      v_crd_e_repair_catalog_seq_id := NULL;
 END;
 
 IF v_crd_e_repair_catalog_seq_id IS NOT NULL THEN
    v_settings_seq_id      := NULL;
    v_column_name          := NULL;

    -- Cursor to get the setting columns
    OPEN cur_repair_attributes; 
 
    BEGIN
         LOOP
             FETCH cur_repair_attributes INTO v_settings_seq_id,
                                              v_column_name;
             EXIT WHEN cur_repair_attributes%NOTFOUND;

             IF v_settings_seq_id_data IS NULL THEN
                v_settings_seq_id_data := v_settings_seq_id || '^';
             ELSE
                v_settings_seq_id_data := v_settings_seq_id_data || v_settings_seq_id || '^';
             END IF;
                       
             IF UPPER(v_column_name) = 'REPAIR_PRICE' THEN
                SELECT COUNT(1)
                INTO   v_repair_modified
                FROM   CRD_E_REPAIR_CATALOG
                WHERE  NVL(REPAIR_PRICE, 0)   = NVL(v_old_repair_price, 0)
                AND    CRD_E_REPAIR_CATALOG_SEQ_ID = v_crd_e_repair_catalog_seq_id;
             
                IF v_repair_modified = 0 THEN
                   v_data_modified := TRUE;
                END IF;
             END IF;
             
             IF UPPER(v_column_name) = 'REPAIR_TAT' THEN
                SELECT COUNT(1)
                INTO   v_repair_modified
                FROM   CRD_E_REPAIR_CATALOG
                WHERE  NVL(REPAIR_TAT, 0)   = NVL(v_old_repair_tat, 0)
                AND    CRD_E_REPAIR_CATALOG_SEQ_ID = v_crd_e_repair_catalog_seq_id;
             
                IF v_repair_modified = 0 THEN
                   v_data_modified := TRUE;
                END IF;
             END IF;
         END LOOP;
         
    EXCEPTION
    WHEN OTHERS THEN
         DBMS_OUTPUT.PUT_LINE('Error while fetching the repair attributes from CRD_E_SETTINGS : ' || SQLCODE || ' ' || SQLERRM);
    END;
 
    CLOSE cur_repair_attributes; 
    
    -- If the repair attributes are modified, the details are maintained in the transaction table     
    IF v_data_modified = TRUE THEN
       v_settings_seq_arr := ECRD_UTILS_PKG.string_to_array(v_settings_seq_id_data, '^');       
       
       IF v_settings_seq_arr(1) IS NOT NULL THEN
          v_data_exist := 0;

          SELECT COUNT(1)
          INTO   v_data_exist
          FROM   CRD_E_MODIFIED_DATA
          WHERE  CRD_E_SETTINGS_SEQ_ID       = TO_NUMBER(v_settings_seq_arr(1))
          AND    CRD_E_REPAIR_CATALOG_SEQ_ID = v_crd_e_repair_catalog_seq_id;

          IF v_data_exist = 0 THEN
             BEGIN
                  INSERT INTO CRD_E_MODIFIED_DATA
                             (
                              CRD_E_MOD_DATA_SEQ_ID,
                              CRD_E_SETTINGS_SEQ_ID,
                              CRD_E_REPAIR_CATALOG_SEQ_ID,
                              OLD_VALUE,
                              CREATED_BY,
                              CREATION_DATE,
                              LAST_UPDATE_DATE,
                              LAST_UPDATED_BY
                             )
                       VALUES(
                              CRD_E_MODIFIED_DATA_SEQ.NEXTVAL,
                              TO_NUMBER(v_settings_seq_arr(1)),
                              v_crd_e_repair_catalog_seq_id,
                              v_old_repair_price,
                              p_in_user_id,
                              SYSDATE,
                              SYSDATE,
                              p_in_user_id
                             );                              
             EXCEPTION
             WHEN OTHERS THEN
                  DBMS_OUTPUT.PUT_LINE('Error while inserting the details in CRD_E_MODIFIED_DATA : ' || SQLCODE || ' ' || SQLERRM);
             END;                
          
          ELSE
              BEGIN
                   UPDATE CRD_E_MODIFIED_DATA
                   SET    OLD_VALUE = v_old_repair_price,
                          LAST_UPDATED_BY  = p_in_user_id,
                          LAST_UPDATE_DATE = SYSDATE
                   WHERE  CRD_E_SETTINGS_SEQ_ID = TO_NUMBER(v_settings_seq_arr(1))
                   AND    CRD_E_REPAIR_CATALOG_SEQ_ID = v_crd_e_repair_catalog_seq_id;
             
             EXCEPTION
             WHEN OTHERS THEN
                  DBMS_OUTPUT.PUT_LINE('Error while updating the details in CRD_E_MODIFIED_DATA : ' || SQLCODE || ' ' || SQLERRM);
             END;
          END IF;
       END IF;

       IF v_settings_seq_arr(2) IS NOT NULL THEN
           v_data_exist := 0;

           SELECT COUNT(1)
           INTO   v_data_exist
           FROM   CRD_E_MODIFIED_DATA
           WHERE  CRD_E_SETTINGS_SEQ_ID       = TO_NUMBER(v_settings_seq_arr(2))
           AND    CRD_E_REPAIR_CATALOG_SEQ_ID = v_crd_e_repair_catalog_seq_id;

           IF v_data_exist = 0 THEN
              BEGIN
                   INSERT INTO CRD_E_MODIFIED_DATA
                              (
                               CRD_E_MOD_DATA_SEQ_ID,
                               CRD_E_SETTINGS_SEQ_ID,
                               CRD_E_REPAIR_CATALOG_SEQ_ID,
                               OLD_VALUE,
                               CREATED_BY,
                               CREATION_DATE,
                               LAST_UPDATE_DATE,
                               LAST_UPDATED_BY
                              )
                        VALUES(
                               CRD_E_MODIFIED_DATA_SEQ.NEXTVAL,
                               TO_NUMBER(v_settings_seq_arr(2)),
                               v_crd_e_repair_catalog_seq_id,
                               v_old_repair_tat,
                               p_in_user_id,
                               SYSDATE,
                               SYSDATE,
                               p_in_user_id
                              );
              EXCEPTION
              WHEN OTHERS THEN
                   DBMS_OUTPUT.PUT_LINE('Error while inserting the details in CRD_E_MODIFIED_DATA : ' || SQLCODE || ' ' || SQLERRM);
              END;                
                              
           ELSE
               BEGIN
                    UPDATE CRD_E_MODIFIED_DATA
                    SET    OLD_VALUE = v_old_repair_tat,
                           LAST_UPDATED_BY  = p_in_user_id,
                           LAST_UPDATE_DATE = SYSDATE
                    WHERE  CRD_E_SETTINGS_SEQ_ID = TO_NUMBER(v_settings_seq_arr(2))
                    AND    CRD_E_REPAIR_CATALOG_SEQ_ID = v_crd_e_repair_catalog_seq_id;
               
               EXCEPTION
               WHEN OTHERS THEN
                    DBMS_OUTPUT.PUT_LINE('Error while updating the details in CRD_E_MODIFIED_DATA : ' || SQLCODE || ' ' || SQLERRM);
               END;
           END IF;
       END IF;
    END IF;
 END IF;
 /* Patni 04-Sep-2006 - To check if the repair attributes are modified - End */

COMMIT;
 p_out_message := 'APPROVE_REPAIR_SUCCESS';
 EXCEPTION
 WHEN OTHERS THEN
    ROLLBACK;
    p_out_message := 'REPAIR_APPROVE_FAILURE';
    RAISE_APPLICATION_ERROR(-20322,'Error in ecrd_approval_pkg.ecrd_approve_ind_repair_prc '||SQLCODE||SQLERRM);
 END ecrd_approve_ind_repair_prc;

/*
This procedure is used to approve a group repair
*/


PROCEDURE ecrd_appr_grp_repair_prc
(
   p_in_repair_seq_id   IN    VARCHAR2,--crd_e_repair.repair_seq_id%TYPE,
   p_in_repair_desc  IN    crd_e_repair.repair_description%TYPE,
   p_in_module_id    IN    VARCHAR2,--crd_e_repair.module_seq_id%TYPE,
   p_in_component_code  IN crd_e_repair.component_code%TYPE,
   p_in_rep_eff_date IN VARCHAR2,--crd_e_repair.repair_effective_date%TYPE ,
   p_in_rep_volume      IN crd_e_repair.repair_volume%TYPE,
   p_in_repair_comments IN crd_e_repair.repair_comments%TYPE,
   p_in_inc_TAT_ind  IN crd_e_repair_catalog.incremental_tat_ind%TYPE,
   p_in_inc_TAT      IN VARCHAR2,--crd_e_repair_catalog.repair_tat%TYPE,
   p_in_inc_pr_ind      IN crd_e_repair_catalog.incremental_price_ind%TYPE,
   p_in_pr        IN VARCHAR2,--crd_e_repair_catalog.repair_price%TYPE,
   p_in_pr_type      IN crd_e_repair_catalog.price_type%TYPE,
   p_in_fut_tat      IN VARCHAR2,--crd_e_repair_catalog.future_tat%TYPE,
   p_in_fut_pr    IN VARCHAR2,--crd_e_repair_catalog.future_price%TYPE,
   p_in_fut_pr_eff_dt   IN VARCHAR2,--crd_e_repair_catalog.future_effective_date%TYPE,
   p_in_user_id      IN crd_e_repair_history.approved_rejected_by%TYPE,
   p_in_catalog_seq_id  IN VARCHAR2,--crd_e_repair_catalog.catalog_seq_id%TYPE,
   p_in_rep_disp_seq_id IN crd_e_repair_catalog.repair_display_seq_id%TYPE,
   p_in_approv_type  IN VARCHAR2,
   p_in_chld_rep_info_buff IN LONG,
   p_in_row_delimiter      IN VARCHAR2,
   p_in_col_delimiter      IN VARCHAR2,

   p_out_message     OUT   VARCHAR2
)
IS

--Child repair cursor is taken to check if any of the requested child has been deleted or not.

   CURSOR ecrd_child_repair_cur
   IS
   SELECT
      crh.repair_seq_id    AS repair_id,
      crh.component_code      AS component_code,
      crh.module_seq_id    AS module_seq_id,
      crh.repair_type         AS repair_type,
      crh.repair_description     AS rep_desc,
           crh.repair_reference     AS rep_ref,
      crh.repair_comments     AS rep_comments,
           crh.repair_reference_format AS rep_format,
           crh.repair_effective_date   AS rep_eff_date,
      crh.repair_end_date     AS rep_end_date,
      crh.repair_volume    AS rep_volume
   FROM crd_e_repair_history crh
   WHERE
      crh.parent_repair_seq_id=TO_NUMBER(p_in_repair_seq_id)
      AND crh.staging_history_ind=ecrd_utils_pkg.G_STAGING
      AND crh.approved_rejected_by IS NULL;

   CURSOR ecrd_get_child_repair(p_repair_id crd_e_repair.repair_seq_id%TYPE)
   IS
   SELECT
      repair_seq_id
   FROM
      crd_e_repair
   WHERE
      parent_repair_seq_id = p_repair_id AND
      (repair_end_date IS NULL OR repair_end_date > SYSDATE);

   /* Patni 04-Sep-2006 - To get the repair attributes from the Settings table - Begin */
   CURSOR cur_repair_attributes
   IS
   SELECT CRD_E_SETTINGS_SEQ_ID,
          COLUMN_NAME
   FROM   CRD_E_SETTINGS
   WHERE  SETTING_ID = 1
   AND    UPPER(ACTIVE_IND) = 'Y';
   /* Patni 04-Sep-2006 - To get the repair attributes from the Settings table - End */
      
v_count        NUMBER      := 0;
v_index        NUMBER      := 0;
v_row_count    NUMBER      := 0;
v_rep_eff_date    DATE     := NULL;
v_rep_fut_eff_dt  DATE     :=NULL;
v_details      VARCHAR2(2000)  := NULL;
v_child_in_hist      VARCHAR2(5) :=NULL;
v_repair_seq_id      NUMBER      :=0;
v_osb_nos      NUMBER      :=0;
var_child_count      NUMBER      :=0;
tab_broken_rows  ecrd_utils_pkg.gtyp_buf_arr;
tab_broken_cols  ecrd_utils_pkg.gtyp_buf_arr;
v_new_effective_date DATE := NULL;
v_repair_tat crd_e_repair_catalog.repair_tat%TYPE;
v_repair_tat_ind crd_e_repair_catalog.incremental_tat_ind%TYPE;
v_price_inc_ind crd_e_repair_catalog.incremental_price_ind%TYPE;
v_price crd_e_repair_catalog.repair_price%TYPE;
v_price_type crd_e_repair_catalog.price_type%TYPE;
v_creation_date DATE := NULL;
v_created_by VARCHAR2(20) :=NULL;
v_repair_display_seq_id crd_e_repair_catalog.repair_display_seq_id%TYPE;

/* Patni 04-Sep-2006 - Declaring variables - Begin */
v_crd_e_repair_catalog_seq_id    CRD_E_REPAIR_CATALOG.CRD_E_REPAIR_CATALOG_SEQ_ID%TYPE;   
v_old_repair_price               CRD_E_REPAIR_CATALOG_HIST.REPAIR_PRICE%TYPE;   
v_old_repair_tat                 CRD_E_REPAIR_CATALOG_HIST.REPAIR_TAT%TYPE;   
v_settings_seq_id                CRD_E_SETTINGS.CRD_E_SETTINGS_SEQ_ID%TYPE;
v_column_name                    CRD_E_SETTINGS.COLUMN_NAME%TYPE;
v_settings_seq_arr               ECRD_UTILS_PKG.VARRAY_PART;
v_settings_seq_id_data           VARCHAR2(10) := NULL;
v_repair_modified                NUMBER       := 1;
v_data_exist                     NUMBER       := 0;
v_data_modified                  BOOLEAN      := FALSE;
/* Patni 04-Sep-2006 - Declaring variables - End */      

BEGIN
     v_rep_eff_date :=  TO_DATE(p_in_rep_eff_date,ecrd_utils_pkg.G_DATE_FORMAT);
     v_rep_fut_eff_dt := TO_DATE(p_in_fut_pr_eff_dt,ecrd_utils_pkg.G_DATE_FORMAT);
     p_out_message := 'REPAIR_APPROVE_FAILURE';

     /* Patni 04-Sep-2006 - To get the current value of the repair attributes - Begin */
     v_old_repair_price := NULL;
     v_old_repair_tat   := NULL; 
      
     BEGIN
          SELECT REPAIR_PRICE,
                 REPAIR_TAT
          INTO   v_old_repair_price,
                 v_old_repair_tat
          FROM   CRD_E_REPAIR_CATALOG_HIST
          WHERE  CATALOG_SEQ_ID = p_in_catalog_seq_id
          AND    REPAIR_SEQ_ID  = p_in_repair_seq_id
          AND    APPROV_REJECT_BY IS NULL
          AND    UPPER(STAGING_HISTORY_IND) = ECRD_UTILS_PKG.G_STAGING;

     EXCEPTION
     WHEN NO_DATA_FOUND THEN
          v_old_repair_price := NULL;
          v_old_repair_tat   := NULL;
     END;
     /* Patni 04-Sep-2006 - To get the current value of the repair attributes - End */              

            SELECT created_by,
                   creation_date
            INTO
                  v_created_by,
                  v_creation_date
            FROM crd_e_repair_catalog_hist
            WHERE
            repair_seq_id     = TO_NUMBER(p_in_repair_seq_id)
            AND catalog_seq_id   = TO_NUMBER(p_in_catalog_seq_id)
            AND staging_history_ind = ecrd_utils_pkg.G_STAGING
            AND approv_reject_by IS NULL;

--The approve type is compared to see if the repair is new one or the modified one.


     IF UPPER(p_in_approv_type) = ecrd_utils_pkg.G_NO THEN


--Update the repair history tables.

      UPDATE crd_e_repair_history
            SET staging_history_ind    = ecrd_utils_pkg.G_STAGING,
                repair_description     = p_in_repair_desc,
          repair_effective_date  = v_rep_eff_date,
                repair_volume    = p_in_rep_volume,
                repair_comments     = p_in_repair_comments,
                last_updated_by     = p_in_user_id,
          last_update_date    = SYSDATE,
          approved_rejected_by   = p_in_user_id,
          approved_rejected_date = SYSDATE,
          approve_reject_status  =ecrd_utils_pkg.G_APPROVE_STATUS
            WHERE repair_seq_id     = TO_NUMBER(p_in_repair_seq_id)
            AND staging_history_ind    = ecrd_utils_pkg.G_STAGING;

      UPDATE crd_e_repair_catalog_hist
      SET
         incremental_tat_ind     = p_in_inc_TAT_ind,
         repair_tat        = TO_NUMBER(p_in_inc_TAT),
         incremental_price_ind   = p_in_inc_pr_ind,
         --repair_price    = DECODE(p_in_pr,0,NULL,TO_NUMBER(p_in_pr)),
         repair_price      = TO_NUMBER(p_in_pr),
         price_type        = p_in_pr_type,
         --future_tat         = DECODE(p_in_fut_tat,0,NULL,TO_NUMBER(p_in_fut_tat)),
         future_tat        = TO_NUMBER(p_in_fut_tat),
         --future_price    = DECODE(p_in_fut_pr,0,NULL,TO_NUMBER(p_in_fut_pr)),
         future_price      = TO_NUMBER(p_in_fut_pr),
         future_effective_date   =v_rep_fut_eff_dt,
         approv_reject_by     =p_in_user_id,
         approved_rejected_date  = SYSDATE,
         approve_reject_status   = ecrd_utils_pkg.G_APPROVE_STATUS,
         last_update_date     = SYSDATE,
         last_updated_by      = p_in_user_id
      WHERE
         repair_seq_id     = TO_NUMBER(p_in_repair_seq_id)
         AND catalog_seq_id   = TO_NUMBER(p_in_catalog_seq_id)
         AND staging_history_ind = ecrd_utils_pkg.G_STAGING;



               SELECT count(1)
               INTO v_count
               FROM crd_e_repair
               WHERE repair_seq_id = TO_NUMBER(p_in_repair_seq_id);



        IF v_count > 0
        THEN
            p_out_message := 'REPAIR_ALREADY_EXISTS';
            ROLLBACK;
            RETURN;
        END IF;


--This is to check if there is any repair existing which has repair end date less than sysdate.

       SELECT COUNT(ROWID)
       INTO v_count
       FROM crd_e_repair
       WHERE   repair_seq_id  = p_in_repair_seq_id
       AND  component_code = p_in_component_code
       AND  module_seq_id  = TO_NUMBER(p_in_module_id)
       AND  repair_end_date < SYSDATE;

       IF v_count > 0
       THEN

--If there is any such record then instead of inserting a new data in the main table update the data with end date less than sysdate.
--Also transfer the existing data of the main tables to the history tables with history indicator.

      INSERT INTO crd_e_repair_history
      (
         repair_seq_id,
         staging_history_ind,
         change_start_date,
         component_code,
         repair_type,
         module_seq_id,
         repair_description,
         repair_reference,
         repair_comments,
         repair_reference_format,
         repair_effective_date,
         repair_end_date,
         requested_by,
         approved_rejected_by,
         requested_date,
         approved_rejected_date,
         repair_volume,
         approve_reject_status,
         rejection_comments,
         creation_date,
         created_by,
         last_update_date,
         last_updated_by,
         parent_repair_seq_id
      )
      (
      SELECT
         repair_seq_id,
         ecrd_utils_pkg.G_HISTORY_RECORD,
         SYSDATE,
         component_code,
         repair_type,
         module_seq_id,
         repair_description,
         repair_reference,
         repair_comments,
         repair_reference_format,
         repair_effective_date,
         NULL,
         NULL,
         NULL,
         NULL,
         NULL,
         repair_volume,
         NULL,
         NULL,
         creation_date,
         created_by,
         SYSDATE,
         p_in_user_id,
         parent_repair_seq_id
         FROM crd_e_repair
         WHERE repair_seq_id  = p_in_repair_seq_id
         AND   component_code = p_in_component_code
         AND   module_seq_id  = TO_NUMBER(p_in_module_id)
         AND   repair_end_date < SYSDATE
      );
/*
   4-Feb-2005
   Update the change start date from SYSDATE + 1 to SYSDATE
*/
      INSERT INTO crd_e_repair_catalog_hist
      (
         catalog_seq_id,
         repair_seq_id,
         effective_date,
         staging_history_ind,
         change_start_date,
         repair_price,
         incremental_price_ind,
         repair_tat,
         incremental_tat_ind,
         future_price,
         future_effective_date,
         price_type,
         repair_end_date,
         future_tat,
         created_by,
         creation_date,
         last_update_date,
         last_updated_by,
         repair_display_seq_id,
         requested_by,
         requested_date,
         approv_reject_by,
         approved_rejected_date,
         approve_reject_status,
         rejection_comments,
         price_overwrite_flag_ind
      )
      (
         SELECT
            catalog_seq_id,
            repair_seq_id,
            effective_date,
            ecrd_utils_pkg.G_HISTORY_RECORD,
            SYSDATE,
            repair_price,
            incremental_price_ind,
            repair_tat,
            incremental_tat_ind,
            future_price,
            future_effective_date,
            price_type,
            NULL,
            future_tat,
            created_by,
            creation_date,
            SYSDATE,
            p_in_user_id,
            repair_display_seq_id,
            NULL,
            NULL,
            NULL,
            NULL,
            NULL,
            NULL,
            price_overwrite_flag_ind
         FROM crd_e_repair_catalog
         WHERE repair_seq_id  = p_in_repair_seq_id
         AND   catalog_seq_id = p_in_catalog_seq_id
         AND   repair_end_date < SYSDATE
      );

--Now update the main tables for the repair by setting the values of the parameter as per the given inputs.

       UPDATE crd_e_repair
       SET
         repair_end_date='',
         repair_type    = ecrd_utils_pkg.G_GROUP_REPAIR,
         repair_description   = p_in_repair_desc,
         parent_repair_seq_id = NULL,
         repair_reference  = NULL,
         repair_comments      = p_in_repair_comments,
         repair_reference_format = NULL,
         repair_effective_date   = v_rep_eff_date,
         repair_volume     = p_in_rep_volume,
         /*
         created_by     = v_created_by,
         creation_date     = v_creation_date,
         */
         last_update_date  = SYSDATE,
         last_updated_by      = p_in_user_id
      WHERE repair_seq_id     = p_in_repair_seq_id
       AND  component_code    = p_in_component_code
       AND  module_seq_id     = TO_NUMBER(p_in_module_id)
       AND  repair_end_date < SYSDATE;

/*
   04-Feb-2005
   Update the effective date to SYSDATE instead of repair_effective_date for Parent repair
*/
     BEGIN
      SELECT
         --NVL(repair_tat,0),
         repair_tat,
         incremental_tat_ind,
         incremental_price_ind,
         --NVL(repair_price,0),
         repair_price,
         price_type
      INTO
         v_repair_tat,
         v_repair_tat_ind,
         v_price_inc_ind,
         v_price,
         v_price_type
      FROM
         crd_e_repair_catalog
      WHERE
         repair_seq_id = p_in_repair_seq_id AND
         catalog_seq_id = p_in_catalog_seq_id AND
         (repair_end_date IS NULL OR repair_end_date > SYSDATE);
--03-MAY-2006 ADDED EXCEPTION  BEGIN
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
         v_repair_tat :=' ';
         v_repair_tat_ind :=' ' ;
         v_price_inc_ind := ' ';
         v_price := ' ';
         v_price_type := ' ';
  END;
  --03-MAY-2006 ADDED EXCEPTION  END
      UPDATE crd_e_repair_catalog
      SET
         repair_end_date      = '',
         repair_seq_id     = TO_NUMBER(p_in_repair_seq_id),
         catalog_seq_id    = TO_NUMBER(p_in_catalog_seq_id),
         --repair_price    = DECODE(p_in_pr,0,NULL,TO_NUMBER(p_in_pr)),
         repair_price      = TO_NUMBER(p_in_pr),
         incremental_price_ind   = p_in_inc_pr_ind,
         repair_tat     = TO_NUMBER(p_in_inc_TAT),
         incremental_tat_ind  = p_in_inc_TAT_ind,
         --future_price    = DECODE(p_in_fut_pr,0,NULL,TO_NUMBER(p_in_fut_pr)),
         future_price      = TO_NUMBER(p_in_fut_pr),
         future_effective_date   = v_rep_fut_eff_dt,
         price_type     = p_in_pr_type,
         repair_display_seq_id   = p_in_rep_disp_seq_id,
         --future_tat      = DECODE(p_in_fut_tat,0,NULL,TO_NUMBER(p_in_fut_tat)),
         future_tat     = TO_NUMBER(p_in_fut_tat),
         price_overwrite_flag_ind= NULL,
         /*
         created_by     = v_created_by,
         creation_date     = v_creation_date,
         */
         last_update_date  = SYSDATE,
         last_updated_by      = p_in_user_id
      WHERE repair_seq_id     = p_in_repair_seq_id
      AND   catalog_seq_id    = p_in_catalog_seq_id;

      IF((NVL(v_repair_tat,-1)<> to_number(NVL(p_in_inc_TAT,-1)))OR
      (v_repair_tat_ind <> p_in_inc_TAT_ind)OR
      (v_price_inc_ind <> p_in_inc_pr_ind)OR
      (NVL(v_price,-1) <> TO_NUMBER(NVL(p_in_pr,-1)))OR
      (v_price_type <> p_in_pr_type))
      THEN
         UPDATE crd_e_repair_catalog
         SET
            effective_date = SYSDATE
         WHERE
            catalog_seq_id = p_in_catalog_seq_id
            AND  repair_seq_id = p_in_repair_seq_id
            AND (repair_end_date IS NULL OR repair_end_date > SYSDATE);
      END IF;

   ELSE

--If there is no repair in the main table with same repair seq id and repair end date less than the sysdate then insert new data in the main tables.
--Creating record in crd_e_repair with repair_effective date and as SYSDATE and in crd_e_repair_catalog with effective date as SYSDATE.
       INSERT INTO crd_e_repair
       (
         repair_seq_id,
         module_seq_id,
         component_code,
         repair_type,
         repair_description,
         parent_repair_seq_id,
         repair_reference,
         repair_comments,
         repair_reference_format,
         repair_effective_date,
         repair_volume,
         repair_end_date,
         created_by,
         creation_date,
         last_update_date,
         last_updated_by
       )
       VALUES
       (
       TO_NUMBER(p_in_repair_seq_id),
       TO_NUMBER(p_in_module_id),
       p_in_component_code,
       ecrd_utils_pkg.G_GROUP_REPAIR,
       p_in_repair_desc,
       NULL,
       NULL,
       p_in_repair_comments,
       NULL,
       SYSDATE,
       p_in_rep_volume,
       NULL,
       v_created_by,
       v_creation_date,
       SYSDATE,
       p_in_user_id
       );


       INSERT INTO crd_e_repair_catalog
       (
         /* Patni 04-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - Begin */
         crd_e_repair_catalog_seq_id,
         /* Patni 04-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - End */
         repair_seq_id,
         catalog_seq_id,
         effective_date,
         repair_price,
         incremental_price_ind,
         repair_tat,
         incremental_tat_ind,
         future_price,
         future_effective_date,
         price_type,
         repair_end_date,
         repair_display_seq_id,
         future_tat,
         created_by,
         creation_date,
         last_update_date,
         last_updated_by
       )
       VALUES
       (
         /* Patni 04-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - Begin */
         crd_e_repair_catalog_seq.nextval,
         /* Patni 04-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - End */
         TO_NUMBER(p_in_repair_seq_id),
         TO_NUMBER(p_in_catalog_seq_id),
         SYSDATE,
         --DECODE(p_in_pr,0,NULL,TO_NUMBER(p_in_pr)),
         TO_NUMBER(p_in_pr),
         p_in_inc_pr_ind,
         TO_NUMBER(p_in_inc_TAT),
         p_in_inc_TAT_ind,
         --DECODE(p_in_fut_pr,0,NULL,TO_NUMBER(p_in_fut_pr)),
         TO_NUMBER(p_in_fut_pr),
         v_rep_fut_eff_dt,
         p_in_pr_type,
         NULL,
         p_in_rep_disp_seq_id,
         --DECODE(p_in_fut_tat,0,NULL,TO_NUMBER(p_in_fut_tat)),
         TO_NUMBER(p_in_fut_tat),
         v_created_by,
         v_creation_date,
         SYSDATE,
         p_in_user_id
       );


   END IF;

--breake the child repair inforamation buffer into a table format.


   FOR child_repair IN ecrd_child_repair_cur --check if the child previously exists in the table
   LOOP



            ecrd_utils_pkg.break_into_rows_s_prc(
             p_in_chld_rep_info_buff
            ,p_in_row_delimiter
            ,tab_broken_rows
      );


      v_row_count := tab_broken_rows.COUNT;


                v_child_in_hist:='N';
      FOR v_index IN 1..v_row_count
      LOOP
         v_details := tab_broken_rows(v_index);

         ecrd_utils_pkg.break_into_cols_s_prc(
                  v_details,
             p_in_col_delimiter,
             tab_broken_cols
         );

                  IF (tab_broken_cols(1) <>' ')
                  THEN


               IF (child_repair.repair_id=to_number(tab_broken_cols(1)))
                                THEN
                                    v_child_in_hist:='Y';/* Record  for update*/
                                    exit;
                                    ELSE
                                    v_child_in_hist:='N';
            END IF;
               END IF;
                END LOOP;

--If there is any child repair which does not exist in the input buffer then delete it from the history table.

      IF UPPER(v_child_in_hist) = 'N' /* Condition to disable the recoprd */
                THEN
         DELETE FROM crd_e_repair_catalog_hist
         WHERE
            repair_seq_id=to_number(child_repair.repair_id)
            AND staging_history_ind=ecrd_utils_pkg.G_STAGING
            AND approv_reject_by IS NULL;



         DELETE FROM crd_e_repair_history
         WHERE
            parent_repair_seq_id=p_in_repair_seq_id
            AND repair_seq_id=to_number(child_repair.repair_id)
            AND staging_history_ind=ecrd_utils_pkg.G_STAGING
            AND approved_rejected_by IS NULL;

      END IF;
   END LOOP;

--Breaking the child repair information again to insert the data in the main tables.


   ecrd_utils_pkg.break_into_rows_s_prc(
                  p_in_chld_rep_info_buff,
                  p_in_row_delimiter,
                tab_broken_rows
      );

       v_row_count := tab_broken_rows.COUNT;



      FOR v_index IN 1..v_row_count
      LOOP

         v_details := tab_broken_rows(v_index);



         ecrd_utils_pkg.break_into_cols_s_prc(
               v_details,
               p_in_col_delimiter,
               tab_broken_cols
         );

--This is to check in the child repair is an existing one in the repair history table or a new one entered by the approver.

      SELECT COUNT(ROWID)
      INTO var_child_count
      FROM crd_e_repair_history
      WHERE repair_seq_id = TO_NUMBER(tab_broken_cols(1))
      AND staging_history_ind=ecrd_utils_pkg.G_STAGING
      AND approved_rejected_by IS NULL;

--If the child repair is an existing repair in the history tabel then insert in the main table normally.
-- Inserting Child repairs with effective date as SYSDATE in both crd_e_repair and crd_e_repair_catalog
      IF var_child_count =1
      THEN
         INSERT INTO crd_e_repair
         (
            repair_seq_id,
            module_seq_id,
            component_code,
            repair_type,
            repair_description,
            parent_repair_seq_id,
            repair_reference,
            repair_comments,
            repair_reference_format,
            repair_effective_date,
            repair_volume,
            repair_end_date,
            created_by,
            rpr_osb_unique_number,
            creation_date,
            last_update_date,
            last_updated_by
         )
         VALUES
         (
            TO_NUMBER(tab_broken_cols(1)),
            TO_NUMBER(p_in_module_id),
            p_in_component_code,
            ecrd_utils_pkg.G_CHILD_REPAIR,
            tab_broken_cols(2),
            TO_NUMBER(tab_broken_cols(3)),
            tab_broken_cols(4),
            tab_broken_cols(5),
            tab_broken_cols(6),
            SYSDATE,
            tab_broken_cols(8),
            NULL,
            v_created_by,
            NULL,
            v_creation_date,
            SYSDATE,
            p_in_user_id
         );

/*
   4-Feb-2005
   Update effective date to SYSDATE for New Repair tht is getting inserted.
*/
         INSERT INTO crd_e_repair_catalog
         (
            /* Patni 04-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - Begin */
            crd_e_repair_catalog_seq_id,
            /* Patni 04-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - End */
            repair_seq_id,
            catalog_seq_id,
            effective_date,
            repair_price,
            incremental_price_ind,
            repair_tat,
            incremental_tat_ind,
            future_price,
            future_effective_date,
            price_type,
            repair_end_date,
            repair_display_seq_id,
            future_tat,
            price_overwrite_flag_ind,
            created_by,
            creation_date,
            last_update_date,
            last_updated_by
         )
         VALUES
         (
            /* Patni 04-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - Begin */
            crd_e_repair_catalog_seq.nextval,
            /* Patni 04-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - End */
            TO_NUMBER(tab_broken_cols(1)),
            TO_NUMBER(p_in_catalog_seq_id),
            SYSDATE,
            NULL,
            NULL,
            NULL,
            NULL,
            NULL,
            NULL,
            NULL,
            NULL,
            TO_NUMBER(tab_broken_cols(9)),
            NULL,
            NULL,
            v_created_by,
            v_creation_date,
            SYSDATE,
            p_in_user_id
         );

--Updating the history tables for the child repairs.

         UPDATE crd_e_repair_history
         SET
            approved_rejected_by = p_in_user_id,
            approved_rejected_date  = SYSDATE,
            approve_reject_status   = ecrd_utils_pkg.G_APPROVE_STATUS,
            repair_description   = tab_broken_cols(2),
            repair_reference  = tab_broken_cols(4),
            repair_comments      = tab_broken_cols(5),
            repair_reference_format = tab_broken_cols(6)
         WHERE
            repair_seq_id     = TO_NUMBER(tab_broken_cols(1))
            AND staging_history_ind = ecrd_utils_pkg.G_STAGING
            AND (repair_end_date IS NULL OR repair_end_date > SYSDATE );


         UPDATE crd_e_repair_catalog_hist
         SET
            effective_date    = TO_DATE(tab_broken_cols(7),ecrd_utils_pkg.G_DATE_FORMAT),
            repair_display_seq_id   = TO_NUMBER(tab_broken_cols(9)),
            last_update_date  = SYSDATE,
            last_updated_by      = p_in_user_id,
            approv_reject_by  = p_in_user_id,
            approve_reject_status   = ecrd_utils_pkg.G_APPROVE_STATUS,
            approved_rejected_date  = SYSDATE
         WHERE
            repair_seq_id     = TO_NUMBER(tab_broken_cols(1))
            AND staging_history_ind = ecrd_utils_pkg.G_STAGING
            AND (repair_end_date IS NULL OR repair_end_date >SYSDATE);


         ELSE

--If the child repairs are the new one enterd by the approver then it wont have the repair seq id associated with it.
--So the repair seq id needs to be generated for these child repairs.


            BEGIN
                SELECT MAX(repr.rpr_osb_unique_number)
                INTO   v_osb_nos
                FROM crd_e_repair repr
                WHERE repr.COMPONENT_CODE = p_in_component_code;
                EXCEPTION WHEN NO_DATA_FOUND THEN
                  v_osb_nos := 0;
            END;
            v_osb_nos := v_osb_nos + 1;

              SELECT crd_e_repair_seq.nextval
              INTO v_repair_seq_id
              FROM dual;

--After generating insertin the data in the main table.
-- Inserting Child repairs with effective date as SYSDATE in both crd_e_repair and crd_e_repair_catalog
            INSERT INTO crd_e_repair
            (
            repair_seq_id,
            module_seq_id,
            component_code,
            repair_type,
            repair_description,
            parent_repair_seq_id,
            repair_reference,
            repair_comments,
            repair_reference_format,
            repair_effective_date,
            repair_volume,
            repair_end_date,
            created_by,
            rpr_osb_unique_number,
            creation_date,
            last_update_date,
            last_updated_by
            )
            VALUES
            (
            v_repair_seq_id,
            TO_NUMBER(p_in_module_id),
            p_in_component_code,
            ecrd_utils_pkg.G_CHILD_REPAIR,
            tab_broken_cols(2),
            TO_NUMBER(tab_broken_cols(3)),
            tab_broken_cols(4),
            tab_broken_cols(5),
            tab_broken_cols(6),
            SYSDATE,
            tab_broken_cols(8),
            NULL,
            v_created_by,
            v_osb_nos,
            v_creation_date,
            SYSDATE,
            p_in_user_id
            );

--Inserting the data in the history table as these tables will not have any record for this new child repairs.
/*
   Need to Comment it after discussion
*/
            INSERT INTO crd_e_repair_history
            (
               repair_seq_id,
               staging_history_ind,
               change_start_date,
               component_code,
               repair_type,
               module_seq_id,
               repair_description,
               repair_reference,
               repair_comments,
               repair_reference_format,
               repair_effective_date,
               repair_end_date,
               requested_by,
               approved_rejected_by,
               requested_date,
               approved_rejected_date,
               repair_volume,
               approve_reject_status,
               rejection_comments,
               creation_date,
               created_by,
               last_update_date,
               last_updated_by,
               parent_repair_seq_id
            )
            VALUES
            (
               v_repair_seq_id,
               ecrd_utils_pkg.G_STAGING,
               SYSDATE,
               p_in_component_code,
               ecrd_utils_pkg.G_CHILD_REPAIR,
               TO_NUMBER(p_in_module_id),
               tab_broken_cols(2),
               tab_broken_cols(4),
               tab_broken_cols(5),
               tab_broken_cols(6),
               TO_DATE(tab_broken_cols(7),ecrd_utils_pkg.G_DATE_FORMAT),
               NULL,
               p_in_user_id,
               p_in_user_id,
               SYSDATE,
               SYSDATE,
               tab_broken_cols(8),
               ecrd_utils_pkg.G_APPROVE_STATUS,
               NULL,
               SYSDATE,
               p_in_user_id,
               SYSDATE,
               p_in_user_id,
               TO_NUMBER(tab_broken_cols(3))
            );


         INSERT INTO crd_e_repair_catalog
         (
            /* Patni 04-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - Begin */
            crd_e_repair_catalog_seq_id,
            /* Patni 04-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - End */
            repair_seq_id,
            catalog_seq_id,
            effective_date,
            repair_price,
            incremental_price_ind,
            repair_tat,
            incremental_tat_ind,
            future_price,
            future_effective_date,
            price_type,
            repair_end_date,
            repair_display_seq_id,
            future_tat,
            price_overwrite_flag_ind,
            created_by,
            creation_date,
            last_update_date,
            last_updated_by
         )
         VALUES
         (
            /* Patni 04-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - Begin */
            crd_e_repair_catalog_seq.nextval,
            /* Patni 04-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - End */
            v_repair_seq_id,
            TO_NUMBER(p_in_catalog_seq_id),
            SYSDATE,
            NULL,
            NULL,
            NULL,
            NULL,
            NULL,
            NULL,
            NULL,
            NULL,
            TO_NUMBER(tab_broken_cols(9)),
            NULL,
            NULL,
            v_created_by,
            v_creation_date,
            SYSDATE,
            p_in_user_id
         );
/*
   Need to Comment it after discussion
*/
         INSERT INTO crd_e_repair_catalog_hist
         (
            catalog_seq_id,
            repair_seq_id,
            effective_date,
            staging_history_ind,
            change_start_date,
            created_by,
            creation_date,
            last_update_date,
            last_updated_by,
            repair_display_seq_id,
            requested_by,
            requested_date,
            approv_reject_by,
            approved_rejected_date,
            approve_reject_status,
            rejection_comments

         )
         VALUES
         (
            TO_NUMBER(p_in_catalog_seq_id),
            v_repair_seq_id,
            SYSDATE,
            ecrd_utils_pkg.G_STAGING,
            SYSDATE,
            p_in_user_id,
            SYSDATE,
            SYSDATE,
            p_in_user_id,
            TO_NUMBER(tab_broken_cols(9)),
            p_in_user_id,
            SYSDATE,
            p_in_user_id,
            SYSDATE,
            ecrd_utils_pkg.G_APPROVE_STATUS,
            NULL
         );

         END IF;
      END LOOP;

   ELSE


--If the repair is a modified repair then only the pricing information needs to be handled.

---Shifting the data from main catalog table to the staging catalog repair table for main repair
    BEGIN
      SELECT
      repair_display_seq_id
      INTO
       v_repair_display_seq_id
       FROM CRD_E_REPAIR_CATALOG_HIST
       WHERE
         repair_seq_id     = p_in_repair_seq_id
         AND catalog_seq_id   = p_in_catalog_seq_id
         AND staging_history_ind = ecrd_utils_pkg.G_STAGING
         AND approv_reject_by IS NULL;
--03-MAY-2006 ADDED EXCEPTION BEGIN
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
       v_repair_display_seq_id := ' ';
       END;
--03-MAY-2006 ADDED EXCEPTION END

      INSERT INTO crd_e_repair_catalog_hist
      (
         catalog_seq_id,
         repair_seq_id,
         effective_date,
         staging_history_ind,
         change_start_date,
         repair_price,
         incremental_price_ind,
         repair_tat,
         incremental_tat_ind,
         future_price,
         future_effective_date,
         price_type,
         repair_end_date,
         future_tat,
         created_by,
         creation_date,
         last_update_date,
         last_updated_by,
         repair_display_seq_id,
         requested_by,
         requested_date,
         approv_reject_by,
         approved_rejected_date,
         approve_reject_status,
         rejection_comments
      )
      (
      SELECT
         catalog_seq_id,
         repair_seq_id,
         effective_date,
         ecrd_utils_pkg.G_HISTORY_RECORD,
         SYSDATE,
         repair_price,
         incremental_price_ind,
         repair_tat,
         incremental_tat_ind,
         future_price,
         future_effective_date,
         price_type,
         NULL,
         future_tat,
         created_by,
         creation_date,
         SYSDATE,
         p_in_user_id,
         repair_display_seq_id,
         NULL,
         NULL,
         p_in_user_id,
         SYSDATE,
         ecrd_utils_pkg.G_APPROVE_STATUS,
         NULL
      FROM
      crd_e_repair_catalog

      WHERE
         repair_seq_id = p_in_repair_seq_id
         AND catalog_seq_id = p_in_catalog_seq_id
       );

--Updating the repair and repair catalog staging tabel for main repair

                  UPDATE crd_e_repair_catalog_hist
            SET
               incremental_tat_ind  = p_in_inc_TAT_ind,
               repair_tat     = TO_NUMBER(p_in_inc_TAT),
               incremental_price_ind   = p_in_inc_pr_ind,
               -- repair_price      = DECODE(p_in_pr,0,NULL,TO_NUMBER(p_in_pr)),
               repair_price      = TO_NUMBER(p_in_pr),
               price_type     = p_in_pr_type,
               --future_tat      = DECODE(p_in_fut_tat,0,NULL,TO_NUMBER(p_in_fut_tat)),
               future_tat     = TO_NUMBER(p_in_fut_tat),
               --future_price    = DECODE(p_in_fut_pr,0,NULL,TO_NUMBER(p_in_fut_pr)),
               future_price      = TO_NUMBER(p_in_fut_pr),
               future_effective_date   = v_rep_fut_eff_dt,
               approv_reject_by  = p_in_user_id,
               approved_rejected_date  = sysdate,
               approve_reject_status   = ecrd_utils_pkg.G_APPROVE_STATUS,
               last_update_date  = SYSDATE,
               last_updated_by      = p_in_user_id
            WHERE
            repair_seq_id     = p_in_repair_seq_id
            AND catalog_seq_id   = p_in_catalog_seq_id
            AND staging_history_ind = ecrd_utils_pkg.G_STAGING
            AND approv_reject_by IS NULL;

--Updating the mater tables for the parent repair
/*
   04-Feb-2005
   Updating the Effective Date as SYSDATE for the approved repair.
*/
  BEGIN
      SELECT
         --NVL(repair_tat,0),
         repair_tat,
         incremental_tat_ind,
         incremental_price_ind,
         --NVL(repair_price,0),
         repair_price,
         price_type
      INTO
         v_repair_tat,
         v_repair_tat_ind,
         v_price_inc_ind,
         v_price,
         v_price_type
      FROM
         crd_e_repair_catalog
      WHERE
         repair_seq_id = p_in_repair_seq_id AND
         catalog_seq_id = p_in_catalog_seq_id AND
         (repair_end_date IS NULL OR repair_end_date > SYSDATE);
--03-MAY-2006 ADDED EXCEPTION BEGIN
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
         v_repair_tat :=' ';
         v_repair_tat_ind :=' ';
         v_price_inc_ind := ' ';
         v_price := ' ';
         v_price_type :=' ' ;
       END;
--03-MAY-2006 ADDED EXCEPTION END

       UPDATE crd_e_repair_catalog
       SET
            incremental_tat_ind     = p_in_inc_TAT_ind,
            repair_tat        = TO_NUMBER(p_in_inc_TAT),
            incremental_price_ind   = p_in_inc_pr_ind,
            --repair_price    = DECODE(p_in_pr,0,NULL,TO_NUMBER(p_in_pr)),
            repair_price      = TO_NUMBER(p_in_pr),
            price_type        = p_in_pr_type,
            repair_display_seq_id  = v_repair_display_seq_id,
            --future_tat         = DECODE(p_in_fut_tat,0,NULL,TO_NUMBER(p_in_fut_tat)),
            future_tat        = TO_NUMBER(p_in_fut_tat),
            --future_price    = DECODE(p_in_fut_pr,0,NULL,TO_NUMBER(p_in_fut_pr)),
            future_price      = TO_NUMBER(p_in_fut_pr),
            future_effective_date   = v_rep_fut_eff_dt,
            last_update_date     = SYSDATE,
            last_updated_by      = p_in_user_id
       WHERE
         repair_seq_id     = p_in_repair_seq_id
         AND catalog_seq_id   = p_in_catalog_seq_id
         AND (repair_end_date IS NULL OR repair_end_date > SYSDATE);

      IF((NVL(v_repair_tat,-1) <> to_number(NVL(p_in_inc_TAT,-1)))OR
         (v_repair_tat_ind <> p_in_inc_TAT_ind)OR
         (v_price_inc_ind <> p_in_inc_pr_ind)OR
         (NVL(v_price,-1) <> TO_NUMBER(NVL(p_in_pr,-1)))OR
         (v_price_type <> p_in_pr_type))
         THEN
            UPDATE crd_e_repair_catalog
            SET
               effective_date = SYSDATE
            WHERE
               catalog_seq_id = p_in_catalog_seq_id
               AND  repair_seq_id = p_in_repair_seq_id
               AND (repair_end_date IS NULL OR repair_end_date > SYSDATE);
      END IF;
--Inserting the data in the history table from master table for the child repairs

         ecrd_utils_pkg.break_into_rows_s_prc(
            p_in_chld_rep_info_buff,
            p_in_row_delimiter,
            tab_broken_rows
         );

         v_row_count := tab_broken_rows.COUNT;

         FOR v_index IN 1..v_row_count
         LOOP

            v_details := tab_broken_rows(v_index);

            ecrd_utils_pkg.break_into_cols_s_prc(
               v_details,
               p_in_col_delimiter,
               tab_broken_cols
            );
--Updating the main table for the child repairs

         UPDATE crd_e_repair
         SET
            repair_description   = tab_broken_cols(2),
            repair_reference  = tab_broken_cols(4),
            repair_reference_format = tab_broken_cols(6),
            repair_comments      = tab_broken_cols(5)
         WHERE
            repair_seq_id     =TO_NUMBER(tab_broken_cols(1));


--Updating the repair history table for the child repairs.

          UPDATE crd_e_repair_history
          SET
            repair_description   = tab_broken_cols(2),
            repair_reference  = tab_broken_cols(4),
            repair_reference_format = tab_broken_cols(6),
            repair_comments      = tab_broken_cols(5),
            staging_history_ind  = ecrd_utils_pkg.G_STAGING,
                  approve_reject_status   = ecrd_utils_pkg.G_APPROVE_STATUS,
            last_updated_by      = p_in_user_id,
            last_update_date  = SYSDATE,
            approved_rejected_by = p_in_user_id,
            approved_rejected_date  = SYSDATE
                WHERE
            parent_repair_seq_id = p_in_repair_seq_id
            AND staging_history_ind = ecrd_utils_pkg.G_STAGING
            AND approved_rejected_by IS NULL;
/*
   4-Feb-2005
   Update repair catalog and repair catalog history for child repairs.
*/
         UPDATE crd_e_repair_catalog
         SET
            repair_display_seq_id = TO_NUMBER(tab_broken_cols(9)),
            last_update_date = SYSDATE,
            last_updated_by = p_in_user_id
         WHERE
            repair_seq_id = TO_NUMBER(tab_broken_cols(1))
            AND catalog_seq_id = p_in_catalog_seq_id;
      END LOOP;
END IF;
/*
   4-Feb-2005
   Updating effective date, last updated date, last updated by for Child Repairs.
*/
   FOR ecrd_child_repair IN ecrd_get_child_repair(p_in_repair_seq_id)
   LOOP
      UPDATE crd_e_repair_catalog
      SET
         last_update_date = SYSDATE,
         last_updated_by = p_in_user_id
      WHERE
         repair_seq_id = ecrd_child_repair.repair_seq_id AND
         catalog_seq_id = p_in_catalog_seq_id;

      SELECT
         effective_date
      INTO
         v_new_effective_date
      FROM
         crd_e_repair_catalog
      WHERE
         repair_seq_id = p_in_repair_seq_id AND
         catalog_seq_id = p_in_catalog_seq_id AND
         (repair_end_date IS NULL OR repair_end_date > SYSDATE);

      IF((NVL(v_repair_tat,-1) <> to_number(NVL(p_in_inc_TAT,-1)))OR
      (v_repair_tat_ind <> p_in_inc_TAT_ind)OR
      (v_price_inc_ind <> p_in_inc_pr_ind)OR
      (NVL(v_price,-1) <> TO_NUMBER(NVL(p_in_pr,-1)))OR
      (v_price_type <> p_in_pr_type))
      THEN
         UPDATE crd_e_repair_catalog
         SET
           effective_date = v_new_effective_date
         WHERE
           repair_seq_id = ecrd_child_repair.repair_seq_id AND
           catalog_seq_id = p_in_catalog_seq_id AND
           (repair_end_date IS NULL OR repair_end_date > SYSDATE);
END IF;
END LOOP;

 /* Patni 04-Sep-2006 - To check if the repair attributes are modified - Begin */
 v_crd_e_repair_catalog_seq_id := NULL;    

 BEGIN
      SELECT CRD_E_REPAIR_CATALOG_SEQ_ID
      INTO   v_crd_e_repair_catalog_seq_id
      FROM   CRD_E_REPAIR_CATALOG
      WHERE  CATALOG_SEQ_ID = p_in_catalog_seq_id
      AND    REPAIR_SEQ_ID  = p_in_repair_seq_id
      AND    (REPAIR_END_DATE IS NULL OR REPAIR_END_DATE > SYSDATE);

 EXCEPTION
 WHEN NO_DATA_FOUND THEN
      v_crd_e_repair_catalog_seq_id := NULL;
 END;
 
 IF v_crd_e_repair_catalog_seq_id IS NOT NULL THEN
    v_settings_seq_id      := NULL;
    v_column_name          := NULL;

    -- Cursor to get the setting columns
    OPEN cur_repair_attributes; 
 
    BEGIN
         LOOP
             FETCH cur_repair_attributes INTO v_settings_seq_id,
                                              v_column_name;
             EXIT WHEN cur_repair_attributes%NOTFOUND;

             IF v_settings_seq_id_data IS NULL THEN
                v_settings_seq_id_data := v_settings_seq_id || '^';
             ELSE
                v_settings_seq_id_data := v_settings_seq_id_data || v_settings_seq_id || '^';
             END IF;
                       
             IF UPPER(v_column_name) = 'REPAIR_PRICE' THEN
                SELECT COUNT(1)
                INTO   v_repair_modified
                FROM   CRD_E_REPAIR_CATALOG
                WHERE  NVL(REPAIR_PRICE, 0)   = NVL(v_old_repair_price, 0)
                AND    CRD_E_REPAIR_CATALOG_SEQ_ID = v_crd_e_repair_catalog_seq_id;
             
                IF v_repair_modified = 0 THEN
                   v_data_modified := TRUE;
                END IF;
             END IF;
             
             IF UPPER(v_column_name) = 'REPAIR_TAT' THEN
                SELECT COUNT(1)
                INTO   v_repair_modified
                FROM   CRD_E_REPAIR_CATALOG
                WHERE  NVL(REPAIR_TAT, 0)   = NVL(v_old_repair_tat, 0)
                AND    CRD_E_REPAIR_CATALOG_SEQ_ID = v_crd_e_repair_catalog_seq_id;
             
                IF v_repair_modified = 0 THEN
                   v_data_modified := TRUE;
                END IF;
             END IF;
         END LOOP;
         
    EXCEPTION
    WHEN OTHERS THEN
         DBMS_OUTPUT.PUT_LINE('Error while fetching the repair attributes from CRD_E_SETTINGS : ' || SQLCODE || ' ' || SQLERRM);
    END;
 
    CLOSE cur_repair_attributes; 
    
    -- If the repair attributes are modified, the details are maintained in the transaction table     
    IF v_data_modified = TRUE THEN
       v_settings_seq_arr := ECRD_UTILS_PKG.string_to_array(v_settings_seq_id_data, '^');       
       
       IF v_settings_seq_arr(1) IS NOT NULL THEN
          v_data_exist := 0;

          SELECT COUNT(1)
          INTO   v_data_exist
          FROM   CRD_E_MODIFIED_DATA
          WHERE  CRD_E_SETTINGS_SEQ_ID       = TO_NUMBER(v_settings_seq_arr(1))
          AND    CRD_E_REPAIR_CATALOG_SEQ_ID = v_crd_e_repair_catalog_seq_id;

          IF v_data_exist = 0 THEN
             BEGIN
                  INSERT INTO CRD_E_MODIFIED_DATA
                             (
                              CRD_E_MOD_DATA_SEQ_ID,
                              CRD_E_SETTINGS_SEQ_ID,
                              CRD_E_REPAIR_CATALOG_SEQ_ID,
                              OLD_VALUE,
                              CREATED_BY,
                              CREATION_DATE,
                              LAST_UPDATE_DATE,
                              LAST_UPDATED_BY
                             )
                       VALUES(
                              CRD_E_MODIFIED_DATA_SEQ.NEXTVAL,
                              TO_NUMBER(v_settings_seq_arr(1)),
                              v_crd_e_repair_catalog_seq_id,
                              v_old_repair_price,
                              p_in_user_id,
                              SYSDATE,
                              SYSDATE,
                              p_in_user_id
                             );                              
             EXCEPTION
             WHEN OTHERS THEN
                  DBMS_OUTPUT.PUT_LINE('Error while inserting the details in CRD_E_MODIFIED_DATA : ' || SQLCODE || ' ' || SQLERRM);
             END;                
          
          ELSE
              BEGIN
                   UPDATE CRD_E_MODIFIED_DATA
                   SET    OLD_VALUE = v_old_repair_price,
                          LAST_UPDATED_BY  = p_in_user_id,
                          LAST_UPDATE_DATE = SYSDATE
                   WHERE  CRD_E_SETTINGS_SEQ_ID = TO_NUMBER(v_settings_seq_arr(1))
                   AND    CRD_E_REPAIR_CATALOG_SEQ_ID = v_crd_e_repair_catalog_seq_id;
             
             EXCEPTION
             WHEN OTHERS THEN
                  DBMS_OUTPUT.PUT_LINE('Error while updating the details in CRD_E_MODIFIED_DATA : ' || SQLCODE || ' ' || SQLERRM);
             END;
          END IF;
       END IF;

       IF v_settings_seq_arr(2) IS NOT NULL THEN
           v_data_exist := 0;

           SELECT COUNT(1)
           INTO   v_data_exist
           FROM   CRD_E_MODIFIED_DATA
           WHERE  CRD_E_SETTINGS_SEQ_ID       = TO_NUMBER(v_settings_seq_arr(2))
           AND    CRD_E_REPAIR_CATALOG_SEQ_ID = v_crd_e_repair_catalog_seq_id;

           IF v_data_exist = 0 THEN
              BEGIN
                   INSERT INTO CRD_E_MODIFIED_DATA
                              (
                               CRD_E_MOD_DATA_SEQ_ID,
                               CRD_E_SETTINGS_SEQ_ID,
                               CRD_E_REPAIR_CATALOG_SEQ_ID,
                               OLD_VALUE,
                               CREATED_BY,
                               CREATION_DATE,
                               LAST_UPDATE_DATE,
                               LAST_UPDATED_BY
                              )
                        VALUES(
                               CRD_E_MODIFIED_DATA_SEQ.NEXTVAL,
                               TO_NUMBER(v_settings_seq_arr(2)),
                               v_crd_e_repair_catalog_seq_id,
                               v_old_repair_tat,
                               p_in_user_id,
                               SYSDATE,
                               SYSDATE,
                               p_in_user_id
                              );
              EXCEPTION
              WHEN OTHERS THEN
                   DBMS_OUTPUT.PUT_LINE('Error while inserting the details in CRD_E_MODIFIED_DATA : ' || SQLCODE || ' ' || SQLERRM);
              END;                
                              
           ELSE
               BEGIN
                    UPDATE CRD_E_MODIFIED_DATA
                    SET    OLD_VALUE = v_old_repair_tat,
                           LAST_UPDATED_BY  = p_in_user_id,
                           LAST_UPDATE_DATE = SYSDATE
                    WHERE  CRD_E_SETTINGS_SEQ_ID = TO_NUMBER(v_settings_seq_arr(2))
                    AND    CRD_E_REPAIR_CATALOG_SEQ_ID = v_crd_e_repair_catalog_seq_id;
               
               EXCEPTION
               WHEN OTHERS THEN
                    DBMS_OUTPUT.PUT_LINE('Error while updating the details in CRD_E_MODIFIED_DATA : ' || SQLCODE || ' ' || SQLERRM);
               END;
           END IF;
       END IF;
    END IF;
 END IF;
 /* Patni 04-Sep-2006 - To check if the repair attributes are modified - End */

COMMIT;
p_out_message := 'APPROVE_REPAIR_SUCCESS';
 EXCEPTION
 WHEN OTHERS THEN
    ROLLBACK;
    p_out_message := 'REPAIR_APPROVE_FAILURE';
    RAISE_APPLICATION_ERROR(-20322,'Error in ecrd_approval_pkg.ecrd_approve_grp_repair_prc '||SQLCODE||'-'||sqlerrm);
END  ecrd_appr_grp_repair_prc;

PROCEDURE ecrd_approve_reject_site_prc(
         p_in_approve_reject IN VARCHAR2,
         p_in_mdl_seq_id IN crd_e_component_location.module_seq_id%TYPE,
         p_in_cmp_code  IN crd_e_component_location.COMPONENT_CODE%TYPE,
         p_in_location_id IN crd_e_component_location.LOCATION_ID%TYPE,
         p_in_change_start_date IN VARCHAR2,
         p_in_approve_rejected_by IN crd_e_comp_location_hist.APPROVED_REJECTED_BY%TYPE,
         p_in_rejection_comments IN crd_e_comp_location_hist.REJECTION_COMMENTS%TYPE
         )
IS

v_count number;
v_created_by crd_e_comp_location_hist.CREATED_BY%TYPE ;
v_creation_date crd_e_comp_location_hist.CREATION_DATE%TYPE;
v_last_update_date crd_e_comp_location_hist.LAST_UPDATE_DATE%TYPE;
v_site_seq_num crd_e_comp_location_hist.SITE_SEQUENCE_NUMBER%TYPE;
v_active_ind crd_e_comp_location_hist.ACTIVE_IND%TYPE;
v_last_update_by crd_e_comp_location_hist.LAST_UPDATED_BY%TYPE;
v_requested_by crd_e_comp_location_hist.REQUESTED_BY%TYPE;
v_requested_date crd_e_comp_location_hist.REQUESTED_DATE%TYPE;
v_hide_component_indicator crd_e_comp_location_hist.HIDE_COMPONENT_IND%TYPE;
v_site_seq_count NUMBER;
BEGIN
--This is for coping from location and updating to hist


IF p_in_approve_reject = 'A'

THEN
--
SELECT COUNT(1)
INTO v_count
FROM crd_e_component_location cl
WHERE cl.MODULE_SEQ_ID = p_in_mdl_seq_id
AND     cl.COMPONENT_CODE =p_in_cmp_code
AND   cl.LOCATION_ID = p_in_location_id;
--
BEGIN
--
    SELECT ch.site_sequence_number
    INTO v_site_seq_num
    FROM CRD_E_COMP_LOCATION_HIST CH
    WHERE ch.module_seq_id = p_in_mdl_seq_id
    AND   ch.component_code = p_in_cmp_code
    AND   ch.location_id  = p_in_location_id
    AND   ch.STAGING_HISTORY_IND = ecrd_utils_pkg.g_staging
    AND approved_rejected_date IS NULL
    AND   to_date(ch.change_start_date)= to_date(p_in_change_start_date,ecrd_utils_pkg.g_date_format);
    --
    SELECT COUNT(1)
    INTO v_site_seq_count
    FROM crd_e_component_location cecl
    WHERE cecl.module_seq_id = p_in_mdl_seq_id
    AND   cecl.component_code = p_in_cmp_code
    AND cecl.active_ind = ecrd_utils_pkg.G_ACTIVE
    AND  cecl.site_sequence_number = v_site_seq_num;
    --
   IF v_site_seq_count != 0
   THEN
		SELECT NVL(MAX(site_sequence_number),0)+1
		INTO v_site_seq_num
		FROM crd_e_component_location cl
		WHERE cl.MODULE_SEQ_ID = p_in_mdl_seq_id
		AND     cl.COMPONENT_CODE =p_in_cmp_code
		AND   cl.active_ind = ecrd_utils_pkg.G_ACTIVE;
	END IF;
   --
   EXCEPTION
   	WHEN NO_DATA_FOUND
      THEN v_site_seq_num := 0;
     WHEN OTHERS THEN
      v_site_seq_num := 0;
END;
/* UPDATE crd_e_comp_location_hist
   SET approved_rejected_by = p_in_approve_rejected_by,
       approved_rejected_date = sysdate,
      approve_reject_status = ecrd_utils_pkg.G_APPROVE_STATUS,
      rejection_comments    = p_in_rejection_comments
  WHERE module_seq_id = p_in_mdl_seq_id
            AND   component_code = p_in_cmp_code
            AND   location_id  = p_in_location_id
            AND   staging_history_ind = ecrd_utils_pkg.g_staging
            AND approved_rejected_date IS NULL
            AND   to_date(change_start_date)= to_date(p_in_change_start_date,ecrd_utils_pkg.g_date_format);*/

--Coping from location and updating to hist

      IF(v_count > 0)
      THEN
         INSERT INTO crd_e_comp_location_hist(
                  module_seq_id,--1
                  component_code,--2
                  location_id,--3
                  staging_history_ind,--4
                  change_start_date, --5
                  active_ind,  --6
                  site_sequence_number,--7
                  requested_by, --8
                  approved_rejected_by,--9
                  requested_date,--10
                  approved_rejected_date,--11
                  approve_reject_status,--12
                  rejection_comments,--13
                  created_by,--14
                  creation_date, --15
                  last_update_date,--16
                  last_updated_by,--17
                  -- Added New For Hide Component Indicator
                  hide_component_ind --18
                  -- End of Added New For Hide Component Indicator
                                    )
                           (
                           SELECT
                              cl.module_seq_id,       --1
                              cl.component_code,         --2
                              cl.location_id,            --3
                              ecrd_utils_pkg.G_HISTORY_RECORD,--4
                              sysdate,             --5
                              cl.active_ind,          --6
                              cl.site_sequence_number,   --7
                              null,          --8
                              p_in_approve_rejected_by,   --9
                              null,       --10
                              sysdate,    --11
                              ecrd_utils_pkg.G_APPROVE_STATUS,--12
                              null,                --13
                              cl.created_by,          --14
                              to_date(cl.creation_date), --15
                              to_date(cl.last_update_date),--16
                              cl.last_updated_by,        --17
                              -- Added New For Hide Component Indicator
                              cl.hide_component_ind      --18
                              -- End of Added New For Hide Component Indicator
                              FROM crd_e_component_location cl
                              WHERE cl.MODULE_SEQ_ID = p_in_mdl_seq_id
                              AND     cl.COMPONENT_CODE =p_in_cmp_code
                              AND   cl.LOCATION_ID = p_in_location_id
                           );

                     --This is to copy from hist and move to master with staging ind h
                  BEGIN
                     SELECT ch.active_ind,
                     /* So that max site seq number goes when approving
                           ch.site_sequence_number,
                           */
                           ch.created_by,
                           ch.creation_date,
                           -- Added new For Hide Component Indicator
                           ch.hide_component_ind
                           -- Added new For Hide Component Indicator
                     INTO v_active_ind,
                        /* So that max site seq number goes when approving
                         v_site_seq_num,
                         */
                         v_created_by,
                         v_creation_date,
                         v_hide_component_indicator
                     FROM CRD_E_COMP_LOCATION_HIST CH
                     WHERE ch.module_seq_id = p_in_mdl_seq_id
                     AND   ch.component_code = p_in_cmp_code
                     AND   ch.location_id  = p_in_location_id
                     AND   ch.STAGING_HISTORY_IND = ecrd_utils_pkg.g_staging
                     AND approved_rejected_date IS NULL
                     AND   to_date(ch.change_start_date)= to_date(p_in_change_start_date,ecrd_utils_pkg.g_date_format);
               --03-MAY-2006 ADDED EXCEPTION BEGIN
                   EXCEPTION
                   WHEN NO_DATA_FOUND THEN
                         v_created_by := ' ';
                         v_creation_date := ' ';
                         v_hide_component_indicator := ' ';
                    END;
               -- 03-MAY-2006 ADDED EXCEPTION END
                        UPDATE crd_e_comp_location_hist
                        SET approved_rejected_by = p_in_approve_rejected_by,
                            approved_rejected_date = sysdate,
                           approve_reject_status = ecrd_utils_pkg.G_APPROVE_STATUS,
                           rejection_comments    = p_in_rejection_comments
                          WHERE module_seq_id = p_in_mdl_seq_id
                                 AND   component_code = p_in_cmp_code
                                 AND   location_id  = p_in_location_id
                                 AND   staging_history_ind = ecrd_utils_pkg.g_staging
                                 AND approved_rejected_date IS NULL
                                 AND   to_date(change_start_date)= to_date(p_in_change_start_date,ecrd_utils_pkg.g_date_format);


                     UPDATE crd_e_component_location
                     SET   module_seq_id           = p_in_mdl_seq_id,
                          component_code           = p_in_cmp_code,
                          location_id              = p_in_location_id,
                          active_ind            = v_active_ind,
                          site_sequence_number     = v_site_seq_num,
                          /*
                          created_by               = v_created_by,
                          creation_date            = v_creation_date,
                          */
                          last_update_date         = sysdate,
                          last_updated_by       = p_in_approve_rejected_by,
                          hide_component_ind    =  v_hide_component_indicator
                     WHERE    module_seq_id = p_in_mdl_seq_id
                           AND     component_code =p_in_cmp_code
                           AND   location_id = p_in_location_id;

      ELSE


                     INSERT INTO crd_e_component_location(
                                                   module_seq_id,
                                                   component_code,
                                                   location_id,
                                                   active_ind,
                                                   site_sequence_number,
                                                   created_by,
                                                   creation_date,
                                                   last_update_date,
                                                   last_updated_by,
                                                   -- Added new For Hide Component Indicator
                                                   hide_component_ind
                                                   -- End of Added new For Hide Component Indicator
                                                )
                           (
                           SELECT
                              ch.module_seq_id,       --Module_seq_id
                              ch.component_code,         --component_seq_id
                              ch.location_id,            --location_code
                              ch.active_ind,                --history_staging_ind
                                                      /* So that max site seq number goes when approving
                         ch.site_sequence_number,               --change_start_date
                         */
										v_site_seq_num,
                              ch.CREATED_BY,          --active_indicator
                              ch.CREATION_DATE, --site_sequence_number
                              ch.last_update_date,          --requested_by
                              ch.LAST_UPDATED_BY,   --approve_rejected_by
                              ch.hide_component_ind
                              FROM crd_e_comp_location_hist ch
                              WHERE ch.MODULE_SEQ_ID = p_in_mdl_seq_id
                              AND     ch.COMPONENT_CODE =p_in_cmp_code
                              AND   ch.LOCATION_ID = p_in_location_id
                              AND   ch.staging_history_ind = ecrd_utils_pkg.g_staging
                              AND approved_rejected_date IS NULL
                              AND   to_date(ch.change_start_date)= to_date(p_in_change_start_date,ecrd_utils_pkg.g_date_format)
                           );

                        UPDATE crd_e_comp_location_hist
                        SET approved_rejected_by = p_in_approve_rejected_by,
                            approved_rejected_date = sysdate,
                           approve_reject_status = ecrd_utils_pkg.G_APPROVE_STATUS,
                           rejection_comments    = p_in_rejection_comments
                          WHERE module_seq_id = p_in_mdl_seq_id
                                 AND   component_code = p_in_cmp_code
                                 AND   location_id  = p_in_location_id
                                 AND   staging_history_ind = ecrd_utils_pkg.g_staging
                                 AND approved_rejected_date IS NULL
                                 AND   to_date(change_start_date)= to_date(p_in_change_start_date,ecrd_utils_pkg.g_date_format);

      END IF;

ELSE
   IF p_in_approve_reject = 'R'
      THEN
         UPDATE crd_e_comp_location_hist
         SET crd_e_comp_location_hist.approved_rejected_by = p_in_approve_rejected_by,
             crd_e_comp_location_hist.approved_rejected_date = sysdate,
            crd_e_comp_location_hist.rejection_comments    = p_in_rejection_comments,
            crd_e_comp_location_hist.approve_reject_status = ecrd_utils_pkg.G_REJECT_STATUS
--          crd_e_comp_location_hist.staging_history_ind   = ecrd_utils_pkg.g_history_record
         WHERE  module_seq_id = p_in_mdl_seq_id
         AND   component_code = p_in_cmp_code
         AND   location_id  = p_in_location_id
         AND   staging_history_ind = ecrd_utils_pkg.g_staging
         AND approved_rejected_date IS NULL
         AND   to_date(change_start_date)= to_date(p_in_change_start_date,ecrd_utils_pkg.g_date_format);
   END IF;
END IF;
COMMIT;

EXCEPTION
WHEN OTHERS
THEN
--03-may-2006 added pkg name begin
   RAISE_APPLICATION_ERROR(-20020,'Error in ecrd_approval_pkg.ecrd_approve_reject_site_prc--'||SQLCODE||'-'||substr(sqlerrm,1,100));
--03-may-2006 added pkg name end
END ecrd_approve_reject_site_prc;

PROCEDURE ecrd_cmp_site_approve_prc(
         p_in_param  IN VARCHAR2,
         p_in_user_role IN     VARCHAR2,
         p_in_approve_rejected_by IN crd_e_comp_location_hist.APPROVED_REJECTED_BY%TYPE,
         p_result_out OUT result_cursor,
         p_out_message OUT VARCHAR2
         )
IS
tab_broken_row ecrd_utils_pkg.gtyp_buf_arr;
tab_broken_column ecrd_utils_pkg.gtyp_buf_arr;
v_row_count NUMBER :=0;
v_index NUMBER :=0;
v_row_details VARCHAR2(2000) :='';
BEGIN

         p_out_message := 'SITE_APPROVE_FAILED';
      -- Breaking the String into Rows...
         ecrd_utils_pkg.break_into_rows_s_prc(p_in_param,ecrd_utils_pkg.G_ROW_DELIM,tab_broken_row);

               v_row_count := tab_broken_row.COUNT;

               FOR v_index IN 1..v_row_count
               LOOP
                  v_row_details := tab_broken_row(v_index);

                  -- Breaking the Rows into Columns...
                  ecrd_utils_pkg.break_into_cols_s_prc(v_row_details,ecrd_utils_pkg.G_COL_DELIM,tab_broken_column);
                  ecrd_approve_reject_site_prc(tab_broken_column(1),
                                        TO_NUMBER(tab_broken_column(2)),
                                        tab_broken_column(3),
                                        tab_broken_column(4),
                                        tab_broken_column(5),
                                  UPPER(p_in_approve_rejected_by),
                                        tab_broken_column(6));
                END LOOP;
      -- ecrd_approve_comp_site_prc(p_result_out);
      ecrd_approve_comp_site_prc(p_in_user_role,
                                 p_in_approve_rejected_by,
                                 p_result_out);

      p_out_message := 'SITE_APPROVE_SUCCESS';
EXCEPTION
WHEN OTHERS
THEN
   RAISE_APPLICATION_ERROR(-20020,'Error in ecrd_approval_pkg.ecrd_cmp_site_approve_prc--'||SQLCODE||'-'||substr(sqlerrm,1,100));
ROLLBACK;
END ecrd_cmp_site_approve_prc;

/*
This method is used to get the history of the previous approvals of the same component.
*/
PROCEDURE ecrd_get_comp_history(
   p_in_component_code  IN crd_e_component_history.component_code%TYPE,
   p_in_module_code  IN crd_e_component_history.module_seq_id%TYPE,

   p_out_comp_hist_cur  OUT   result_cursor
)
IS
BEGIN

   OPEN p_out_comp_hist_cur FOR
   SELECT
      UPPER(cu.first_name ||' ' ||cu.last_name  )  AS Requested_by,
      UPPER(cuApp.First_Name || ' ' || cuApp.Last_Name) AS Approve_Reject_By,
           TO_CHAR(cch.approved_rejected_date,ecrd_utils_pkg.G_DISPLAY_DATE_FORMAT) AS Approve_Reject_Date,
           DECODE(NVL(cch.approve_reject_status,' '),'A','Approve','Reject')           AS Approve_Reject_Status,
           cch.rejection_comments            AS Rejection_Comments
   FROM  crd_e_component_history cch,
      crd_crc_user cu,
      crd_crc_user cuApp
   WHERE cch.component_code      = p_in_component_code
      AND cch.module_seq_id      = p_in_module_code
      AND cch.staging_history_ind   = ecrd_utils_pkg.G_STAGING
      AND UPPER(cu.userid)    = UPPER(cch.requested_by)
      AND UPPER(cuApp.Userid)    = UPPER(cch.approved_rejected_by)
      AND cch.approved_rejected_by IS NOT NULL;

EXCEPTION
WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20322,'Error in crd_approval_pkg.ecrd_get_comp_history '||SQLCODE);
END ecrd_get_comp_history;

/*
This method is used to get the details about the previous approvals of the same repairs
*/

PROCEDURE ecrd_get_repair_history(
   p_in_repair_seq_id   IN VARCHAR2,
   p_in_catalog_seq_id  IN VARCHAR2,
   p_out_repair_hist_cur   OUT   result_cursor
)
IS
BEGIN

   OPEN p_out_repair_hist_cur FOR
   SELECT
      UPPER(cu.first_name || ' ' || cu.last_name)     AS Requested_By,
      UPPER(cuApp.First_Name || ' ' || cuApp.Last_Name) AS Approve_Reject_By,
      TO_CHAR(crch.approved_rejected_date,ecrd_utils_pkg.G_DISPLAY_DATE_FORMAT)     AS Apprv_Reject_Date,
      DECODE(NVL(crch.approve_reject_status,' '),'A','Approve','Reject') AS   Apprv_Reject_Status,
      crch.rejection_comments    AS Rejection_Comments
   FROM
      crd_e_repair_catalog_hist crch,
      crd_crc_user cu,
      crd_crc_user cuApp
   WHERE crch.repair_seq_id      = p_in_repair_seq_id
      AND crch.catalog_seq_id    = p_in_catalog_seq_id
      AND crch.staging_history_ind  = ecrd_utils_pkg.G_STAGING
      AND UPPER(cu.userid)    = UPPER(crch.requested_by)
      AND UPPER(cuApp.Userid)    = UPPER(crch.approv_reject_by)
      AND crch.approv_reject_by IS NOT NULL;

EXCEPTION
WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20322,'Error in crd_approval_pkg.ecrd_get_repair_history '||SQLCODE);
END ecrd_get_repair_history;

/*
This method is used to approve a new individual repair along with the site information approval
*/

PROCEDURE ecrd_appr_new_ind_rep_prc(
   p_in_repair_seq_id      IN    VARCHAR2,
   p_in_repair_desc     IN    crd_e_repair.repair_description%TYPE,
   p_in_module_id       IN    VARCHAR2,
   p_in_component_code     IN crd_e_repair.component_code%TYPE,
   p_in_rep_eff_date    IN VARCHAR2,--crd_e_repair.repair_effective_date%TYPE ,
   p_in_rep_volume         IN crd_e_repair.repair_volume%TYPE,
   p_in_rep_ref_no         IN crd_e_repair.repair_reference%TYPE,
   p_in_rep_ref_format     IN crd_e_repair.repair_reference_format%TYPE,
   p_in_repair_comments    IN crd_e_repair.repair_comments%TYPE,
   p_in_inc_TAT_ind     IN crd_e_repair_catalog.incremental_tat_ind%TYPE,
   p_in_inc_TAT         IN VARCHAR2,--crd_e_repair_catalog.repair_tat%TYPE,
   p_in_inc_pr_ind         IN crd_e_repair_catalog.incremental_price_ind%TYPE,
   p_in_pr           IN VARCHAR2,--crd_e_repair_catalog.repair_price%TYPE,
   p_in_pr_type         IN crd_e_repair_catalog.price_type%TYPE,
   p_in_fut_tat         IN VARCHAR2,--crd_e_repair_catalog.future_tat%TYPE,
   p_in_fut_pr       IN VARCHAR2,--crd_e_repair_catalog.future_price%TYPE,
   p_in_fut_pr_eff_dt      IN VARCHAR2,--crd_e_repair_catalog.future_effective_date%TYPE,
   p_in_user_id         IN crd_e_repair_history.approved_rejected_by%TYPE,
   p_in_catalog_seq_id     IN VARCHAR2,--crd_e_repair_catalog.catalog_seq_id%TYPE,
   p_in_rep_disp_seq_id    IN VARCHAR2,--crd_e_repair_catalog.repair_display_seq_id%TYPE,
   p_in_row_delimiter      IN VARCHAR2,
   p_in_col_delimiter      IN VARCHAR2,
   p_in_new_site_info_buff    IN LONG,
   p_out_message        OUT   VARCHAR2
)
IS
  

   CURSOR ecrd_repair_sit_cur
   IS
   SELECT
      location_id AS location
   FROM
      crd_e_repair_cost_history
   WHERE
      repair_seq_id     = TO_NUMBER(p_in_repair_seq_id)
      AND module_seq_id = TO_NUMBER(p_in_module_id)
      AND component_code   = p_in_component_code
      AND staging_history_ind = ecrd_utils_pkg.G_STAGING;

   /* Patni 04-Sep-2006 - To get the repair attributes from the Settings table - Begin */
   CURSOR cur_repair_attributes
   IS
   SELECT CRD_E_SETTINGS_SEQ_ID,
          COLUMN_NAME
   FROM   CRD_E_SETTINGS
   WHERE  SETTING_ID = 1
   AND    UPPER(ACTIVE_IND) = 'Y';
   /* Patni 04-Sep-2006 - To get the repair attributes from the Settings table - End */
      
v_msg       VARCHAR2(50)   := NULL;
v_count        NUMBER      := 0;
v_index        NUMBER      := 0;
v_row_count    NUMBER      := 0;
v_loc_in_hist     VARCHAR2(5) := NULL;
v_details      LONG     := NULL;
tab_broken_rows  ecrd_utils_pkg.gtyp_buf_arr;
tab_broken_cols  ecrd_utils_pkg.gtyp_buf_arr;

v_creation_date DATE := NULL;
v_created_by VARCHAR2(20) :=NULL;

/* Patni 04-Sep-2006 - Declaring variables - Begin */
v_crd_e_repair_catalog_seq_id    CRD_E_REPAIR_CATALOG.CRD_E_REPAIR_CATALOG_SEQ_ID%TYPE;   
v_old_repair_price               CRD_E_REPAIR_CATALOG_HIST.REPAIR_PRICE%TYPE;   
v_old_repair_tat                 CRD_E_REPAIR_CATALOG_HIST.REPAIR_TAT%TYPE;   
v_settings_seq_id                CRD_E_SETTINGS.CRD_E_SETTINGS_SEQ_ID%TYPE;
v_column_name                    CRD_E_SETTINGS.COLUMN_NAME%TYPE;
v_settings_seq_arr               ECRD_UTILS_PKG.VARRAY_PART;
v_settings_seq_id_data           VARCHAR2(10) := NULL;
v_repair_modified                NUMBER       := 1;
v_data_exist                     NUMBER       := 0;
v_data_modified                  BOOLEAN      := FALSE;
/* Patni 04-Sep-2006 - Declaring variables - End */      

BEGIN

p_out_message := 'APPROVE_REPAIR_FAILURE';
--This method is called to approve only a new individual repair and not the sites associated with it.

commit;
      
     /* Patni 04-Sep-2006 - To get the current value of the repair attributes - Begin */
     v_old_repair_price := NULL;
     v_old_repair_tat   := NULL; 
      
     BEGIN
          SELECT REPAIR_PRICE,
                 REPAIR_TAT
          INTO   v_old_repair_price,
                 v_old_repair_tat
          FROM   CRD_E_REPAIR_CATALOG_HIST
          WHERE  CATALOG_SEQ_ID = p_in_catalog_seq_id
          AND    REPAIR_SEQ_ID  = p_in_repair_seq_id
          AND    APPROV_REJECT_BY IS NULL
          AND    UPPER(STAGING_HISTORY_IND) = ECRD_UTILS_PKG.G_STAGING;

     EXCEPTION
     WHEN NO_DATA_FOUND THEN
          v_old_repair_price := NULL;
          v_old_repair_tat   := NULL;
     END;
     /* Patni 04-Sep-2006 - To get the current value of the repair attributes - End */              

        BEGIN
            SELECT created_by,
                   creation_date
            INTO
                  v_created_by,
                  v_creation_date
            FROM crd_e_repair_catalog_hist
            WHERE
            repair_seq_id     = TO_NUMBER(p_in_repair_seq_id)
            AND catalog_seq_id   = TO_NUMBER(p_in_catalog_seq_id)
            AND staging_history_ind = ecrd_utils_pkg.G_STAGING
            AND APPROV_REJECT_BY IS NULL;
--03-MAY--2006 ADDED EXCEPTION BEGIN
          EXCEPTION
          WHEN NO_DATA_FOUND THEN
          BEGIN
                SELECT created_by,
                   creation_date
            INTO
                  v_created_by,
                  v_creation_date
            FROM crd_e_repair_history
            WHERE
            repair_seq_id     = TO_NUMBER(p_in_repair_seq_id)
                     AND   repair_end_date IS NULL
                     AND   approved_rejected_by IS NULL
                     AND staging_history_ind = ecrd_utils_pkg.G_STAGING;

               EXCEPTION      
          WHEN NO_DATA_FOUND THEN
       
            SELECT created_by,
                   creation_date
            INTO
                  v_created_by,
                  v_creation_date
            FROM crd_e_repair
            WHERE
            repair_seq_id     = TO_NUMBER(p_in_repair_seq_id)
            AND repair_end_date IS NULL;
              END;
            END;

         
         
--03-MAY--2006 ADDED EXCEPTION END

  
   ecrd_approve_ind_repair_prc(
            p_in_repair_seq_id,
            p_in_repair_desc,
            p_in_module_id,
            p_in_component_code,
            p_in_rep_eff_date,
            p_in_rep_volume,
            p_in_rep_ref_no,
            p_in_rep_ref_format,
            p_in_repair_comments,
            p_in_inc_TAT_ind,
            p_in_inc_TAT,
            p_in_inc_pr_ind,
            p_in_pr,
            p_in_pr_type,
            p_in_fut_tat,
            p_in_fut_pr,
            p_in_fut_pr_eff_dt,
            p_in_user_id,
            p_in_catalog_seq_id,
            p_in_rep_disp_seq_id,
            UPPER(ecrd_utils_pkg.G_NO),
            v_msg
            );


--Breakin the repair site information buffer in to table format to check that the repair site in the input buffer exist in the staging table.

   FOR repair_loc IN ecrd_repair_sit_cur
   LOOP
      ecrd_utils_pkg.break_into_rows_s_prc(
                  p_in_new_site_info_buff,
                  p_in_row_delimiter,
                tab_broken_rows
      );

      v_row_count := tab_broken_rows.COUNT;
      v_loc_in_hist :='N';
      FOR v_index IN 1..v_row_count
      LOOP

         v_details := tab_broken_rows(v_index);

         ecrd_utils_pkg.break_into_cols_s_prc(
               v_details,
               p_in_col_delimiter,
               tab_broken_cols
         );

--This compares the existing record in the staging table with the input buffer and if is matched the loop is broken.

         IF (repair_loc.location=tab_broken_cols(1))
                        THEN
                               v_loc_in_hist:='Y';/* Record  for update*/
                               exit;
                        ELSE
                               v_loc_in_hist:='N';
         END IF;
      END LOOP;


--Even after the complete loop the repair site is not found in the input buffer but exist in the staging table that means that the approver has deleted the site while approving the repair.
--So this site information needs to be deleted from the staging table also.

      IF UPPER(v_loc_in_hist) = 'N'
      THEN
         DELETE FROM crd_e_repair_cost_history
         WHERE
            repair_seq_id =p_in_repair_seq_id
            AND location_id = repair_loc.location
            AND staging_history_ind=ecrd_utils_pkg.G_STAGING
            AND approv_reject_date IS NULL;
--Added the following else part by Rushit to ensure that the repair cost history table is updated after the approval of new individual repair on 12/2/2004

--If the repair site information exist in the staging table as well as in the input buffer then update those data in the staging table.

      ELSIF (UPPER(v_loc_in_hist) = 'Y')
      THEN
         UPDATE crd_e_repair_cost_history
         SET
               approv_reject_status = ecrd_utils_pkg.G_APPROVE_STATUS,
              approv_reject_date = SYSDATE,
         last_updated_by = p_in_user_id,
         last_update_date = SYSDATE
         WHERE
               repair_seq_id =p_in_repair_seq_id
         AND location_id=repair_loc.location
         AND staging_history_ind=ecrd_utils_pkg.G_STAGING
         AND approv_reject_status IS NULL;
      END IF;

   END LOOP;

--This loop is used to insert the data of the repair site information in the main table.

   ecrd_utils_pkg.break_into_rows_s_prc(
                  p_in_new_site_info_buff,
                  p_in_row_delimiter,
                tab_broken_rows
      );

   v_row_count := tab_broken_rows.COUNT;

   FOR v_index IN 1..v_row_count
      LOOP

         v_details := tab_broken_rows(v_index);


         ecrd_utils_pkg.break_into_cols_s_prc(
               v_details,
               p_in_col_delimiter,
               tab_broken_cols
         );

p_out_message := p_in_module_id||' '||p_in_component_code || ' '||TO_NUMBER(p_in_repair_seq_id) ||' ' || tab_broken_cols(1);

--Inserting the data of new repair site into the main table.

  

  
   p_out_message := 'Error while inserting into  crd_e_repair_cost ';
    
    
     
     BEGIN
      INSERT INTO crd_e_repair_cost(
         module_seq_id,
         component_code,
         repair_seq_id,
         location_id,
         material_cost,
         labour_hours,
         created_by,
         creation_date,
         last_update_date,
         last_updated_by
      )
      VALUES
      (
         p_in_module_id,
         p_in_component_code,
         TO_NUMBER(p_in_repair_seq_id),
         tab_broken_cols(1),
         TO_NUMBER(tab_broken_cols(2)),
         TO_NUMBER(tab_broken_cols(3)),
         v_created_by,
         v_creation_date,
         SYSDATE,
         p_in_user_id
      );
      EXCEPTION 
      WHEN OTHERS THEN
       DBMS_OUTPUT.PUT_LINE('***************Insert into  crd_e_repair_cost *************'||SQLCODE||'-'||substr(sqlerrm,1,100));        
      END;


   END LOOP;

   
 /* Patni 04-Sep-2006 - To check if the repair attributes are modified - Begin */
 v_crd_e_repair_catalog_seq_id := NULL;    

 BEGIN
      SELECT CRD_E_REPAIR_CATALOG_SEQ_ID
      INTO   v_crd_e_repair_catalog_seq_id
      FROM   CRD_E_REPAIR_CATALOG
      WHERE  CATALOG_SEQ_ID = p_in_catalog_seq_id
      AND    REPAIR_SEQ_ID  = p_in_repair_seq_id
      AND    (REPAIR_END_DATE IS NULL OR REPAIR_END_DATE > SYSDATE);

 EXCEPTION
 WHEN NO_DATA_FOUND THEN
      v_crd_e_repair_catalog_seq_id := NULL;
 END;
 
 IF v_crd_e_repair_catalog_seq_id IS NOT NULL THEN
    v_settings_seq_id      := NULL;
    v_column_name          := NULL;

    -- Cursor to get the setting columns
    OPEN cur_repair_attributes; 
 
    BEGIN
         LOOP
             FETCH cur_repair_attributes INTO v_settings_seq_id,
                                              v_column_name;
             EXIT WHEN cur_repair_attributes%NOTFOUND;

             IF v_settings_seq_id_data IS NULL THEN
                v_settings_seq_id_data := v_settings_seq_id || '^';
             ELSE
                v_settings_seq_id_data := v_settings_seq_id_data || v_settings_seq_id || '^';
             END IF;
                       
             IF UPPER(v_column_name) = 'REPAIR_PRICE' THEN
                SELECT COUNT(1)
                INTO   v_repair_modified
                FROM   CRD_E_REPAIR_CATALOG
                WHERE  NVL(REPAIR_PRICE, 0)   = NVL(v_old_repair_price, 0)
                AND    CRD_E_REPAIR_CATALOG_SEQ_ID = v_crd_e_repair_catalog_seq_id;
             
                IF v_repair_modified = 0 THEN
                   v_data_modified := TRUE;
                END IF;
             END IF;
             
             IF UPPER(v_column_name) = 'REPAIR_TAT' THEN
                SELECT COUNT(1)
                INTO   v_repair_modified
                FROM   CRD_E_REPAIR_CATALOG
                WHERE  NVL(REPAIR_TAT, 0)   = NVL(v_old_repair_tat, 0)
                AND    CRD_E_REPAIR_CATALOG_SEQ_ID = v_crd_e_repair_catalog_seq_id;
             
                IF v_repair_modified = 0 THEN
                   v_data_modified := TRUE;
                END IF;
             END IF;
         END LOOP;
         
    EXCEPTION
    WHEN OTHERS THEN
         DBMS_OUTPUT.PUT_LINE('Error while fetching the repair attributes from CRD_E_SETTINGS : ' || SQLCODE || ' ' || SQLERRM);
    END;
 
    CLOSE cur_repair_attributes; 
    
    -- If the repair attributes are modified, the details are maintained in the transaction table     
    IF v_data_modified = TRUE THEN
       v_settings_seq_arr := ECRD_UTILS_PKG.string_to_array(v_settings_seq_id_data, '^');       
       
       IF v_settings_seq_arr(1) IS NOT NULL THEN
          v_data_exist := 0;

          SELECT COUNT(1)
          INTO   v_data_exist
          FROM   CRD_E_MODIFIED_DATA
          WHERE  CRD_E_SETTINGS_SEQ_ID       = TO_NUMBER(v_settings_seq_arr(1))
          AND    CRD_E_REPAIR_CATALOG_SEQ_ID = v_crd_e_repair_catalog_seq_id;

          IF v_data_exist = 0 THEN
             BEGIN
                  INSERT INTO CRD_E_MODIFIED_DATA
                             (
                              CRD_E_MOD_DATA_SEQ_ID,
                              CRD_E_SETTINGS_SEQ_ID,
                              CRD_E_REPAIR_CATALOG_SEQ_ID,
                              OLD_VALUE,
                              CREATED_BY,
                              CREATION_DATE,
                              LAST_UPDATE_DATE,
                              LAST_UPDATED_BY
                             )
                       VALUES(
                              CRD_E_MODIFIED_DATA_SEQ.NEXTVAL,
                              TO_NUMBER(v_settings_seq_arr(1)),
                              v_crd_e_repair_catalog_seq_id,
                              v_old_repair_price,
                              p_in_user_id,
                              SYSDATE,
                              SYSDATE,
                              p_in_user_id
                             );                              
             EXCEPTION
             WHEN OTHERS THEN
                  DBMS_OUTPUT.PUT_LINE('Error while inserting the details in CRD_E_MODIFIED_DATA : ' || SQLCODE || ' ' || SQLERRM);
             END;                
          
          ELSE
              BEGIN
                   UPDATE CRD_E_MODIFIED_DATA
                   SET    OLD_VALUE = v_old_repair_price,
                          LAST_UPDATED_BY  = p_in_user_id,
                          LAST_UPDATE_DATE = SYSDATE
                   WHERE  CRD_E_SETTINGS_SEQ_ID = TO_NUMBER(v_settings_seq_arr(1))
                   AND    CRD_E_REPAIR_CATALOG_SEQ_ID = v_crd_e_repair_catalog_seq_id;
             
             EXCEPTION
             WHEN OTHERS THEN
                  DBMS_OUTPUT.PUT_LINE('Error while updating the details in CRD_E_MODIFIED_DATA : ' || SQLCODE || ' ' || SQLERRM);
             END;
          END IF;
       END IF;

       IF v_settings_seq_arr(2) IS NOT NULL THEN
           v_data_exist := 0;

           SELECT COUNT(1)
           INTO   v_data_exist
           FROM   CRD_E_MODIFIED_DATA
           WHERE  CRD_E_SETTINGS_SEQ_ID       = TO_NUMBER(v_settings_seq_arr(2))
           AND    CRD_E_REPAIR_CATALOG_SEQ_ID = v_crd_e_repair_catalog_seq_id;

           IF v_data_exist = 0 THEN
              BEGIN
                   INSERT INTO CRD_E_MODIFIED_DATA
                              (
                               CRD_E_MOD_DATA_SEQ_ID,
                               CRD_E_SETTINGS_SEQ_ID,
                               CRD_E_REPAIR_CATALOG_SEQ_ID,
                               OLD_VALUE,
                               CREATED_BY,
                               CREATION_DATE,
                               LAST_UPDATE_DATE,
                               LAST_UPDATED_BY
                              )
                        VALUES(
                               CRD_E_MODIFIED_DATA_SEQ.NEXTVAL,
                               TO_NUMBER(v_settings_seq_arr(2)),
                               v_crd_e_repair_catalog_seq_id,
                               v_old_repair_tat,
                               p_in_user_id,
                               SYSDATE,
                               SYSDATE,
                               p_in_user_id
                              );
              EXCEPTION
              WHEN OTHERS THEN
                   DBMS_OUTPUT.PUT_LINE('Error while inserting the details in CRD_E_MODIFIED_DATA : ' || SQLCODE || ' ' || SQLERRM);
              END;                
                              
           ELSE
               BEGIN
                    UPDATE CRD_E_MODIFIED_DATA
                    SET    OLD_VALUE = v_old_repair_tat,
                           LAST_UPDATED_BY  = p_in_user_id,
                           LAST_UPDATE_DATE = SYSDATE
                    WHERE  CRD_E_SETTINGS_SEQ_ID = TO_NUMBER(v_settings_seq_arr(2))
                    AND    CRD_E_REPAIR_CATALOG_SEQ_ID = v_crd_e_repair_catalog_seq_id;
               
               EXCEPTION
               WHEN OTHERS THEN
                    DBMS_OUTPUT.PUT_LINE('Error while updating the details in CRD_E_MODIFIED_DATA : ' || SQLCODE || ' ' || SQLERRM);
               END;
           END IF;
       END IF;
    END IF;
 END IF;
 /* Patni 04-Sep-2006 - To check if the repair attributes are modified - End */
   
COMMIT;
p_out_message := 'APPROVE_REPAIR_SUCCESS';
 EXCEPTION
 WHEN OTHERS THEN
    ROLLBACK;
 --   p_out_message := 'REPAIR_APPROVE_FAILURE';


    RAISE_APPLICATION_ERROR(-20322,'Error in ecrd_approval_pkg.ecrd_approve_new_ind_repair_prc'||SQLCODE||'-'||sqlerrm || '--'||p_out_message);

END  ecrd_appr_new_ind_rep_prc;


PROCEDURE ecrd_appr_new_grp_rep_prc(
   p_in_repair_seq_id   IN    VARCHAR2,--crd_e_repair.repair_seq_id%TYPE,
   p_in_repair_desc  IN    crd_e_repair.repair_description%TYPE,
   p_in_module_id    IN    VARCHAR2,
   p_in_component_code  IN crd_e_repair.component_code%TYPE,
   p_in_rep_eff_date IN VARCHAR2,--crd_e_repair.repair_effective_date%TYPE ,
   p_in_rep_volume      IN crd_e_repair.repair_volume%TYPE,
   p_in_repair_comments IN crd_e_repair.repair_comments%TYPE,
   p_in_inc_TAT_ind  IN crd_e_repair_catalog.incremental_tat_ind%TYPE,
   p_in_inc_TAT      IN VARCHAR2,--crd_e_repair_catalog.repair_tat%TYPE,
   p_in_inc_pr_ind      IN crd_e_repair_catalog.incremental_price_ind%TYPE,
   p_in_pr        IN VARCHAR2,--crd_e_repair_catalog.repair_price%TYPE,
   p_in_pr_type      IN crd_e_repair_catalog.price_type%TYPE,
   p_in_fut_tat      IN VARCHAR2,--crd_e_repair_catalog.future_tat%TYPE,
   p_in_fut_pr    IN VARCHAR2,--crd_e_repair_catalog.future_price%TYPE,
   p_in_fut_pr_eff_dt   IN VARCHAR2,--crd_e_repair_catalog.future_effective_date%TYPE,
   p_in_user_id      IN crd_e_repair_history.approved_rejected_by%TYPE,
   p_in_catalog_seq_id  IN VARCHAR2,--crd_e_repair_catalog.catalog_seq_id%TYPE,
   p_in_rep_disp_seq_id IN VARCHAR2,
   p_in_approv_type  IN VARCHAR2,
   p_in_chld_rep_info_buff IN LONG,
   p_in_row_delimiter      IN VARCHAR2,
   p_in_col_delimiter      IN VARCHAR2,
   p_in_repair_site_buff   IN LONG,

   p_out_message     OUT   VARCHAR2
   )
IS

CURSOR ecrd_repair_sit_cur
   IS
   SELECT
      location_id AS location
   FROM
      crd_e_repair_cost_history
   WHERE
      repair_seq_id     = TO_NUMBER(p_in_repair_seq_id)
      AND module_seq_id = TO_NUMBER(p_in_module_id)
      AND component_code   = p_in_component_code
      AND staging_history_ind = ecrd_utils_pkg.G_STAGING
      AND approv_reject_date IS NULL;

   /* Patni 04-Sep-2006 - To get the repair attributes from the Settings table - Begin */
   CURSOR cur_repair_attributes
   IS
   SELECT CRD_E_SETTINGS_SEQ_ID,
          COLUMN_NAME
   FROM   CRD_E_SETTINGS
   WHERE  SETTING_ID = 1
   AND    UPPER(ACTIVE_IND) = 'Y';
   /* Patni 04-Sep-2006 - To get the repair attributes from the Settings table - End */
      
v_count        NUMBER      := 0;
v_index        NUMBER      := 0;
v_row_count    NUMBER      := 0;
v_details      LONG     := NULL;
v_out_message     VARCHAR2(50)   := NULL;
v_loc_in_hist     VARCHAR2(5) := NULL;
tab_broken_rows  ecrd_utils_pkg.gtyp_buf_arr;
tab_broken_cols  ecrd_utils_pkg.gtyp_buf_arr;

v_creation_date DATE := NULL;
v_created_by VARCHAR2(20) :=NULL;

/* Patni 04-Sep-2006 - Declaring variables - Begin */
v_crd_e_repair_catalog_seq_id    CRD_E_REPAIR_CATALOG.CRD_E_REPAIR_CATALOG_SEQ_ID%TYPE;   
v_old_repair_price               CRD_E_REPAIR_CATALOG_HIST.REPAIR_PRICE%TYPE;   
v_old_repair_tat                 CRD_E_REPAIR_CATALOG_HIST.REPAIR_TAT%TYPE;   
v_settings_seq_id                CRD_E_SETTINGS.CRD_E_SETTINGS_SEQ_ID%TYPE;
v_column_name                    CRD_E_SETTINGS.COLUMN_NAME%TYPE;
v_settings_seq_arr               ECRD_UTILS_PKG.VARRAY_PART;
v_settings_seq_id_data           VARCHAR2(10) := NULL;
v_repair_modified                NUMBER       := 1;
v_data_exist                     NUMBER       := 0;
v_data_modified                  BOOLEAN      := FALSE;
/* Patni 04-Sep-2006 - Declaring variables - End */      

BEGIN
p_out_message := 'APPROVE_REPAIR_FAILURE';

     /* Patni 04-Sep-2006 - To get the current value of the repair attributes - Begin */
     v_old_repair_price := NULL;
     v_old_repair_tat   := NULL; 
      
     BEGIN
          SELECT REPAIR_PRICE,
                 REPAIR_TAT
          INTO   v_old_repair_price,
                 v_old_repair_tat
          FROM   CRD_E_REPAIR_CATALOG_HIST
          WHERE  CATALOG_SEQ_ID = p_in_catalog_seq_id
          AND    REPAIR_SEQ_ID  = p_in_repair_seq_id
          AND    APPROV_REJECT_BY IS NULL
          AND    UPPER(STAGING_HISTORY_IND) = ECRD_UTILS_PKG.G_STAGING;

     EXCEPTION
     WHEN NO_DATA_FOUND THEN
          v_old_repair_price := NULL;
          v_old_repair_tat   := NULL;
     END;
     /* Patni 04-Sep-2006 - To get the current value of the repair attributes - End */              

--This procedure is called to approve only a new group repair.

        BEGIN
            SELECT created_by,
                   creation_date
            INTO
                  v_created_by,
                  v_creation_date
            FROM crd_e_repair_catalog_hist
            WHERE
            repair_seq_id     = TO_NUMBER(p_in_repair_seq_id)
            AND catalog_seq_id   = TO_NUMBER(p_in_catalog_seq_id)
            AND staging_history_ind = ecrd_utils_pkg.G_STAGING
            AND APPROV_REJECT_BY IS NULL;
--03-MAY--2006 ADDED EXCEPTION BEGIN
          EXCEPTION
          WHEN NO_DATA_FOUND THEN
           v_created_by := ' ';
           v_creation_date := ' ';
           END;
--03-MAY--2006 ADDED EXCEPTION END

   ecrd_appr_grp_repair_prc(
      p_in_repair_seq_id,
      p_in_repair_desc,
      p_in_module_id,
      p_in_component_code,
      p_in_rep_eff_date,
      p_in_rep_volume,
      p_in_repair_comments,
      p_in_inc_TAT_ind,
      p_in_inc_TAT,
      p_in_inc_pr_ind,
      p_in_pr,
      p_in_pr_type,
      p_in_fut_tat,
      p_in_fut_pr,
      p_in_fut_pr_eff_dt,
      p_in_user_id,
      p_in_catalog_seq_id,
      p_in_rep_disp_seq_id,
      UPPER(ecrd_utils_pkg.G_NO),
      p_in_chld_rep_info_buff,
      p_in_row_delimiter,
      p_in_col_delimiter,
      v_out_message
      );



--The staging table repair site information is compared with the input buffer of repair site to see if any of the requested site is deleted by the approver or not.

   FOR repair_loc IN ecrd_repair_sit_cur
   LOOP
      ecrd_utils_pkg.break_into_rows_s_prc(
                  p_in_repair_site_buff,
                  p_in_row_delimiter,
                tab_broken_rows
      );

      v_row_count := tab_broken_rows.COUNT;
      v_loc_in_hist :='N';
      FOR v_index IN 1..v_row_count
      LOOP

         v_details := tab_broken_rows(v_index);

         ecrd_utils_pkg.break_into_cols_s_prc(
               v_details,
               p_in_col_delimiter,
               tab_broken_cols
         );

         IF (repair_loc.location=tab_broken_cols(1))
                        THEN
                               v_loc_in_hist:='Y';/* Record  for update*/
                               exit;
                        ELSE
                               v_loc_in_hist:='N';
         END IF;
      END LOOP;

--If the repair site is there in the staging table for the given repair,but it is not there in the input buffer then that entry is deleted from the history table also.

      IF UPPER(v_loc_in_hist) = 'N'
      THEN
         DELETE FROM crd_e_repair_cost_history
         WHERE
            repair_seq_id =p_in_repair_seq_id
            AND location_id=repair_loc.location
            AND staging_history_ind=ecrd_utils_pkg.G_STAGING
            AND approv_reject_date IS NULL;
      ELSIF (UPPER(v_loc_in_hist) = 'Y')
      THEN
-- Removed the if else condition by Rushit which was deciding whether the repair is for approval of rejection as the proc for rejecting the repair is completely different and this i only used to approved the repair.

--If the repair site is existing in the history table then it is updated.

    UPDATE crd_e_repair_cost_history
         SET
            approv_reject_status = ecrd_utils_pkg.G_APPROVE_STATUS,
            approv_reject_date = SYSDATE,
            last_updated_by = p_in_user_id,
            last_update_date = SYSDATE
         WHERE
            repair_seq_id =p_in_repair_seq_id
            AND location_id=repair_loc.location
            AND staging_history_ind=ecrd_utils_pkg.G_STAGING
            AND approv_reject_status IS NULL;
      END IF;

   END LOOP;

--The repair site buffer is again broken in the table format to enter the data in the main table.

   ecrd_utils_pkg.break_into_rows_s_prc(
                  p_in_repair_site_buff,
                  p_in_row_delimiter,
                tab_broken_rows
      );


       v_row_count := tab_broken_rows.COUNT;


      FOR v_index IN 1..v_row_count
      LOOP

         v_details := tab_broken_rows(v_index);

         ecrd_utils_pkg.break_into_cols_s_prc(
               v_details,
               p_in_col_delimiter,
               tab_broken_cols
         );

p_out_message := p_in_module_id||' '||p_in_component_code || ' '||TO_NUMBER(p_in_repair_seq_id) ||' ' || tab_broken_cols(1);

--Inserting the data in the main table.

      INSERT INTO crd_e_repair_cost(
         module_seq_id,
         component_code,
         repair_seq_id,
         location_id,
         material_cost,
         labour_hours,
         created_by,
         creation_date,
         last_update_date,
         last_updated_by
      )
      VALUES
      (
         p_in_module_id,
         p_in_component_code,
         p_in_repair_seq_id,
         tab_broken_cols(1),
         TO_NUMBER(tab_broken_cols(2)),
         TO_NUMBER(tab_broken_cols(3)),
         v_created_by,
         v_creation_date,
         SYSDATE,
         p_in_user_id
      );




   END LOOP;

 /* Patni 04-Sep-2006 - To check if the repair attributes are modified - Begin */
 v_crd_e_repair_catalog_seq_id := NULL;    

 BEGIN
      SELECT CRD_E_REPAIR_CATALOG_SEQ_ID
      INTO   v_crd_e_repair_catalog_seq_id
      FROM   CRD_E_REPAIR_CATALOG
      WHERE  CATALOG_SEQ_ID = p_in_catalog_seq_id
      AND    REPAIR_SEQ_ID  = p_in_repair_seq_id
      AND    (REPAIR_END_DATE IS NULL OR REPAIR_END_DATE > SYSDATE);

 EXCEPTION
 WHEN NO_DATA_FOUND THEN
      v_crd_e_repair_catalog_seq_id := NULL;
 END;
 
 IF v_crd_e_repair_catalog_seq_id IS NOT NULL THEN
    v_settings_seq_id      := NULL;
    v_column_name          := NULL;

    -- Cursor to get the setting columns
    OPEN cur_repair_attributes; 
 
    BEGIN
         LOOP
             FETCH cur_repair_attributes INTO v_settings_seq_id,
                                              v_column_name;
             EXIT WHEN cur_repair_attributes%NOTFOUND;

             IF v_settings_seq_id_data IS NULL THEN
                v_settings_seq_id_data := v_settings_seq_id || '^';
             ELSE
                v_settings_seq_id_data := v_settings_seq_id_data || v_settings_seq_id || '^';
             END IF;
                       
             IF UPPER(v_column_name) = 'REPAIR_PRICE' THEN
                SELECT COUNT(1)
                INTO   v_repair_modified
                FROM   CRD_E_REPAIR_CATALOG
                WHERE  NVL(REPAIR_PRICE, 0)   = NVL(v_old_repair_price, 0)
                AND    CRD_E_REPAIR_CATALOG_SEQ_ID = v_crd_e_repair_catalog_seq_id;
             
                IF v_repair_modified = 0 THEN
                   v_data_modified := TRUE;
                END IF;
             END IF;
             
             IF UPPER(v_column_name) = 'REPAIR_TAT' THEN
                SELECT COUNT(1)
                INTO   v_repair_modified
                FROM   CRD_E_REPAIR_CATALOG
                WHERE  NVL(REPAIR_TAT, 0)   = NVL(v_old_repair_tat, 0)
                AND    CRD_E_REPAIR_CATALOG_SEQ_ID = v_crd_e_repair_catalog_seq_id;
             
                IF v_repair_modified = 0 THEN
                   v_data_modified := TRUE;
                END IF;
             END IF;
         END LOOP;
         
    EXCEPTION
    WHEN OTHERS THEN
         DBMS_OUTPUT.PUT_LINE('Error while fetching the repair attributes from CRD_E_SETTINGS : ' || SQLCODE || ' ' || SQLERRM);
    END;
 
    CLOSE cur_repair_attributes; 
    
    -- If the repair attributes are modified, the details are maintained in the transaction table     
    IF v_data_modified = TRUE THEN
       v_settings_seq_arr := ECRD_UTILS_PKG.string_to_array(v_settings_seq_id_data, '^');       
       
       IF v_settings_seq_arr(1) IS NOT NULL THEN
          v_data_exist := 0;

          SELECT COUNT(1)
          INTO   v_data_exist
          FROM   CRD_E_MODIFIED_DATA
          WHERE  CRD_E_SETTINGS_SEQ_ID       = TO_NUMBER(v_settings_seq_arr(1))
          AND    CRD_E_REPAIR_CATALOG_SEQ_ID = v_crd_e_repair_catalog_seq_id;

          IF v_data_exist = 0 THEN
             BEGIN
                  INSERT INTO CRD_E_MODIFIED_DATA
                             (
                              CRD_E_MOD_DATA_SEQ_ID,
                              CRD_E_SETTINGS_SEQ_ID,
                              CRD_E_REPAIR_CATALOG_SEQ_ID,
                              OLD_VALUE,
                              CREATED_BY,
                              CREATION_DATE,
                              LAST_UPDATE_DATE,
                              LAST_UPDATED_BY
                             )
                       VALUES(
                              CRD_E_MODIFIED_DATA_SEQ.NEXTVAL,
                              TO_NUMBER(v_settings_seq_arr(1)),
                              v_crd_e_repair_catalog_seq_id,
                              v_old_repair_price,
                              p_in_user_id,
                              SYSDATE,
                              SYSDATE,
                              p_in_user_id
                             );                              
             EXCEPTION
             WHEN OTHERS THEN
                  DBMS_OUTPUT.PUT_LINE('Error while inserting the details in CRD_E_MODIFIED_DATA : ' || SQLCODE || ' ' || SQLERRM);
             END;                
          
          ELSE
              BEGIN
                   UPDATE CRD_E_MODIFIED_DATA
                   SET    OLD_VALUE = v_old_repair_price,
                          LAST_UPDATED_BY  = p_in_user_id,
                          LAST_UPDATE_DATE = SYSDATE
                   WHERE  CRD_E_SETTINGS_SEQ_ID = TO_NUMBER(v_settings_seq_arr(1))
                   AND    CRD_E_REPAIR_CATALOG_SEQ_ID = v_crd_e_repair_catalog_seq_id;
             
             EXCEPTION
             WHEN OTHERS THEN
                  DBMS_OUTPUT.PUT_LINE('Error while updating the details in CRD_E_MODIFIED_DATA : ' || SQLCODE || ' ' || SQLERRM);
             END;
          END IF;
       END IF;

       IF v_settings_seq_arr(2) IS NOT NULL THEN
           v_data_exist := 0;

           SELECT COUNT(1)
           INTO   v_data_exist
           FROM   CRD_E_MODIFIED_DATA
           WHERE  CRD_E_SETTINGS_SEQ_ID       = TO_NUMBER(v_settings_seq_arr(2))
           AND    CRD_E_REPAIR_CATALOG_SEQ_ID = v_crd_e_repair_catalog_seq_id;

           IF v_data_exist = 0 THEN
              BEGIN
                   INSERT INTO CRD_E_MODIFIED_DATA
                              (
                               CRD_E_MOD_DATA_SEQ_ID,
                               CRD_E_SETTINGS_SEQ_ID,
                               CRD_E_REPAIR_CATALOG_SEQ_ID,
                               OLD_VALUE,
                               CREATED_BY,
                               CREATION_DATE,
                               LAST_UPDATE_DATE,
                               LAST_UPDATED_BY
                              )
                        VALUES(
                               CRD_E_MODIFIED_DATA_SEQ.NEXTVAL,
                               TO_NUMBER(v_settings_seq_arr(2)),
                               v_crd_e_repair_catalog_seq_id,
                               v_old_repair_tat,
                               p_in_user_id,
                               SYSDATE,
                               SYSDATE,
                               p_in_user_id
                              );
              EXCEPTION
              WHEN OTHERS THEN
                   DBMS_OUTPUT.PUT_LINE('Error while inserting the details in CRD_E_MODIFIED_DATA : ' || SQLCODE || ' ' || SQLERRM);
              END;                
                              
           ELSE
               BEGIN
                    UPDATE CRD_E_MODIFIED_DATA
                    SET    OLD_VALUE = v_old_repair_tat,
                           LAST_UPDATED_BY  = p_in_user_id,
                           LAST_UPDATE_DATE = SYSDATE
                    WHERE  CRD_E_SETTINGS_SEQ_ID = TO_NUMBER(v_settings_seq_arr(2))
                    AND    CRD_E_REPAIR_CATALOG_SEQ_ID = v_crd_e_repair_catalog_seq_id;
               
               EXCEPTION
               WHEN OTHERS THEN
                    DBMS_OUTPUT.PUT_LINE('Error while updating the details in CRD_E_MODIFIED_DATA : ' || SQLCODE || ' ' || SQLERRM);
               END;
           END IF;
       END IF;
    END IF;
 END IF;
 /* Patni 04-Sep-2006 - To check if the repair attributes are modified - End */
   
COMMIT;
p_out_message := 'APPROVE_REPAIR_SUCCESS';
 EXCEPTION
 WHEN OTHERS THEN
    ROLLBACK;
    p_out_message := 'REPAIR_APPROVE_FAILURE';
    RAISE_APPLICATION_ERROR(-20322,'Error in ecrd_approval_pkg.ecrd_appr_new_grp_repair_prc'||SQLCODE||'-'||sqlerrm||'  '||p_out_message );
END ecrd_appr_new_grp_rep_prc;

/*
This procedure is used  to check if the request for the approval of a repair is pending or not.
*/
PROCEDURE ecrd_is_rep_req_pend_prc
(
 p_in_repair_seq_id    IN          VARCHAR2,
 p_in_catalog_seq_id IN VARCHAR2,
 p_out_msg         OUT         VARCHAR2
)
IS
var_count  NUMBER(10):=0;
var_status NUMBER(5):=0;
BEGIN

--First check in the repair history table.If there is any request pending then that is a new repair which has not been approved yet.

     SELECT
           COUNT(ROWID)
     INTO var_status
     FROM  crd_e_repair_history
     WHERE repair_seq_id   =  TO_NUMBER(p_in_repair_seq_id)
     AND   repair_end_date IS NULL
     AND   approved_rejected_by IS NULL
     AND   staging_history_ind=ecrd_utils_pkg.G_STAGING;

     IF var_status >0
     THEN
         p_out_msg := 'Y';

--If the data is not there in the repair history table then that repair may be modified and then its record will only be in the repair catalog history table.

     ELSE
         SELECT COUNT(ROWID)
      INTO var_count
      FROM crd_e_repair_catalog_hist
      WHERE repair_seq_id  = TO_NUMBER(p_in_repair_seq_id)
      AND catalog_seq_id   = TO_NUMBER(p_in_catalog_seq_id)
      AND staging_history_ind = ecrd_utils_pkg.G_STAGING
      AND approv_reject_by IS NULL
      AND repair_end_date IS NULL;

      IF var_count >0
      THEN
         p_out_msg :='Y';
      ELSE

--If there is no data for the given repair seq id then it means that either the repair is in the main repair and already approved or the reapir has been modifed or newly created but not sent to the any of the staging table yet.

--so in this cases the request for the approval need to be set as not pending.

         SELECT COUNT(ROWID)
         INTO  var_count
         FROM  crd_e_repair
         WHERE repair_seq_id     =  TO_NUMBER(p_in_repair_seq_id)
            AND repair_end_date IS NULL;

         IF var_count > 0 THEN
            p_out_msg :='N';
         ELSE
            p_out_msg :='N';
         END IF;

      END IF;
     END IF;
EXCEPTION

WHEN OTHERS
THEN
    RAISE_APPLICATION_ERROR(-20322,'Error in ecrd_approval_pkg.is_rep_appr_req_pending.prc '||SQLCODE);
END ecrd_is_rep_req_pend_prc;

FUNCTION ecrd_get_approval_status_fnc(
         p_in_component_code IN CRD_E_COMPONENT.component_code%TYPE,
         p_in_module_seq_id  IN CRD_E_COMPONENT.module_seq_id%TYPE
         )
RETURN VARCHAR2
IS
   v_status VARCHAR2(1) := '';
   v_count NUMBER := 0;
BEGIN
   SELECT
      COUNT(1)
   INTO
      v_count
   FROM
      crd_e_component cec
   WHERE
      (cec.component_end_date  IS NULL OR  TRUNC(cec.component_end_date) > TRUNC(SYSDATE)) AND
      cec.module_seq_id = p_in_module_seq_id AND
      UPPER(cec.component_code) = UPPER(p_in_component_code);

   IF(v_count > 0)
   THEN
      v_status := 'M';
   ELSE
      v_status := 'N';
   END IF;

   RETURN v_status;

EXCEPTION
WHEN OTHERS
THEN
    RAISE_APPLICATION_ERROR(-20322,'Error in ecrd_approval_pkg.ecrd_get_approval_status_fnc '||SQLCODE);
END ecrd_get_approval_status_fnc;

PROCEDURE ecrd_comp_site_appr_pend_prc
(
 p_in_module_seq_id    IN          VARCHAR2,
 p_in_component_code  IN VARCHAR2,
 p_in_location_id		IN VARCHAR2,
 p_in_user_role	IN VARCHAR2,
 p_out_msg     OUT         VARCHAR2
)
IS
	v_count NUMBER := 0;
   v_master_count NUMBER :=0;
   v_err_msg VARCHAR2(10) := '';
BEGIN
	IF(p_in_user_role = ecrd_utils_pkg.G_TC)
   THEN
   	SELECT
      	count(1)
      INTO
      	v_master_count
      FROM
      	crd_e_component_location
      WHERE
      	UPPER(component_code) = UPPER(p_in_component_code) AND --22-06-2006 patni offshore changed for showing add repair button to the TC.  
         module_seq_id = p_in_module_seq_id AND
	      UPPER(location_id) = UPPER(p_in_location_id) AND --22-06-2006 patni offshore changed for showing add repair button to the TC.
         active_ind = ecrd_utils_pkg.G_YES;

      IF (v_master_count = 0)
      THEN

--      	ecrd_is_comp_req_pend_prc(p_in_component_code,p_in_module_seq_id,v_err_msg);

         SELECT COUNT(1)
         INTO v_master_count
         FROM crd_e_component_history cech
         	  ,crd_e_comp_location_hist ceclh
         WHERE cech.approve_reject_status IS NULL
         AND UPPER(cech.component_code) = UPPER(p_in_component_code)--22-06-2006 patni offshore changed for showing add repair button to the TC.
         AND cech.module_seq_id = p_in_module_seq_id
         AND UPPER(cech.component_code) = UPPER(ceclh.component_code)--22-06-2006 patni offshore changed for showing add repair button to the TC.
         AND cech.module_seq_id = ceclh.module_seq_id
			   AND UPPER(ceclh.location_id )=  UPPER(p_in_location_id)--22-06-2006 patni offshore changed for showing add repair button to the TC.
         AND ceclh.active_ind = ecrd_utils_pkg.G_YES
         AND ceclh.staging_history_ind = ecrd_utils_pkg.G_STAGING
         AND ceclh.approved_rejected_date IS NULL
         AND cech.staging_history_ind = ecrd_utils_pkg.G_STAGING
         AND cech.approved_rejected_date IS NULL
         AND NOT EXISTS (SELECT cec.component_code
         					 FROM crd_e_component cec
                         WHERE   UPPER(cec.component_code) = UPPER(cech.component_code)--22-06-2006 patni offshore changed for showing add repair button to the TC.
                         AND   (component_end_date IS NULL
                         OR TRUNC(component_end_date) > TRUNC(SYSDATE))
                         );

         IF(v_master_count > 0)
         THEN
         	v_count := 0;
         ELSE
         	v_count := 1;
         END IF;

      ELSE
      	v_count := 0;
      END IF;
	END IF;

   IF (v_count > 0)
   THEN
   	p_out_msg := 'COMP_SITE_APPR_PEND';
   ELSE
   	p_out_msg := '';
   END IF;

EXCEPTION
WHEN OTHERS
THEN
	RAISE_APPLICATION_ERROR(-20020,'ecrd_approvals_pkg.ecrd_comp_site_appr_pend_prc**'||SQLCODE||SQLERRM);
END ecrd_comp_site_appr_pend_prc;

END ecrd_approval_pkg;
/
