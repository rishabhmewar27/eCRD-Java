CREATE OR REPLACE PACKAGE ecrd_batch_cust_cat_pkg 
AS 
  
  TYPE calc_cur   IS  REF CURSOR; 
  v_sysdate         DATE := SYSDATE; 
  v_sysdate_char    VARCHAR(10) := TO_CHAR(v_sysdate,'MM/DD/YYYY');  
  const_advanced_escalation NUMBER := 5; -- This is the constant which decides 
  					 -- that escalation should be done by how many 
  					 -- days in advance 
  
PROCEDURE ecrd_get_base_price_prc(
		  			  all_repair_cur 		IN calc_cur, 
		  			  v_ecrd_cust_cal_tab 	IN  OUT NOCOPY ECRD_CUST_CAT_PRICE_CAL_tab 
				 );
						
PROCEDURE ecrd_get_updated_price_prc(
		  			 p_in_catalog_seq_id IN NUMBER
					,p_in_repair_seq_id  IN NUMBER
					,p_in_module_seq_id  IN NUMBER
					,p_in_cat_eff_date   IN DATE
					,p_in_flow_price_ind IN VARCHAR2
					,p_in_new_rep_ind    IN VARCHAR2
					,p_in_price_def_ind  IN VARCHAR2
					,p_in_repair_price     IN VARCHAR2
					,p_in_prc_ovwrt_ind  IN VARCHAR2
					,p_in_rep_eff_date   IN DATE
					,p_in_out_ann	     IN OUT VARCHAR2
					,p_in_out_esc	     IN OUT VARCHAR2 	
					,p_in_default_catalog_seq_id IN NUMBER
					,p_in_catalog_end_date IN DATE
					,p_in_inc_tat_ind IN VARCHAR2
					,p_in_out_rpr_tat IN OUT NUMBER
					,p_in_update_flag IN VARCHAR2
					,p_out_updated_price OUT NUMBER
					,p_out_new_repair_price OUT NUMBER
					,p_out_rule_check_for_new OUT VARCHAR2);						


PROCEDURE ecrd_batch_cust_cat_prc;

FUNCTION ecrd_fnc_def_cat_seq_id(p_eng_mdl_number_id IN CRD_E_CATALOG.ENG_MDL_NUMBER%TYPE) 
RETURN NUMBER; 

END ecrd_batch_cust_cat_pkg; 
/


CREATE OR REPLACE PACKAGE BODY ecrd_batch_cust_cat_pkg
AS
  
------------------------ Header -------------------------------------
-- Program       crd_batch_cust_cat_pkg.get_base_price_prc 
-- Author        Patni OffShore Team
-- Date          October 2004 
-- Description   The puprpose of this procedure is to  get the base prices.
-- Calls         none
-- 
-- Date          Author             Description Of Change
----------------------------------------------------------------------

PROCEDURE ecrd_get_base_price_prc(all_repair_cur IN calc_cur,
  				  v_ecrd_cust_cal_tab IN  OUT NOCOPY ECRD_CUST_CAT_PRICE_CAL_tab 
						)
     IS 
     
     v_cnt 			              NUMBER(9) := 1;
     v_catalog_seq_id                         NUMBER(9);
     v_default_catalog_seq_id                 NUMBER(9);
     v_module_seq_id                          NUMBER(9);
     v_repair_seq_id                          NUMBER(9);
     v_repair_type                            VARCHAR2(2);
     v_repair_price                           CRD_E_REPAIR_CATALOG.repair_price%TYPE;
     v_temp_repair_price 		      CRD_E_REPAIR_CATALOG.repair_price%TYPE;
     v_catalog_effective_date                 DATE;
     v_update_date			      DATE;
     v_effective_date			      DATE;
     v_calculated_price_default_ind           VARCHAR2(1);
     v_flow_hist							  VARCHAR2(1);
     v_update								  VARCHAR2(5);
     v_new_repair							  VARCHAR2(5);
     v_prc_ovrwrite							  VARCHAR2(1);
     v_rep_eff_date							  DATE;
     v_inc_price_ind		 				  CHAR(1);
     v_repair_tat			 				  NUMBER(11);
     v_inc_tat				 				  CHAR(1);
     v_future_price			 				  NUMBER(15,2);
     v_fut_eff_date			 				  DATE;
     v_price_type			 				  VARCHAR2(10);
     v_rep_dis_seq_id 		 				  NUMBER(7);
     v_future_tat			 				  NUMBER(7);
     v_active_ind			 				  VARCHAR2(1);
     --v_baseline_tat			 			  NUMBER(7,2);		
     v_def_rep_eff_date			       DATE;
     v_counter 				       NUMBER(9) default 1;	
     v_catalog_end_date			       DATE;	
     
     	CURSOR catalog_repair_history IS 
	SELECT   repair_price 
	FROM	 CRD_E_REPAIR_CATALOG_HIST
	WHERE    catalog_seq_id = v_default_catalog_seq_id	   
	AND      repair_seq_id  = v_repair_seq_id
	AND      change_start_date > v_catalog_effective_date
	ORDER BY change_start_date;

	 
BEGIN

	 dbms_output.enable(1000000); 
	 -- dbms_output.put_line('a');
	 -- Looping through the cursor.
        
         LOOP    
             
             FETCH all_repair_cur  
		INTO  v_catalog_seq_id    
               ,v_default_catalog_seq_id 
               ,v_module_seq_id               
               ,v_repair_seq_id 
               ,v_repair_type 
               ,v_repair_price 
               ,v_catalog_effective_date 
               ,v_calculated_price_default_ind 
               ,v_flow_hist 
	       ,v_prc_ovrwrite 
	       ,v_rep_eff_date	 
	       ,v_inc_price_ind	 	
	       ,v_repair_tat 			
	       ,v_inc_tat 			
	       ,v_future_price 		
	       ,v_fut_eff_date 		
	       ,v_price_type 		
	       ,v_rep_dis_seq_id  	
	       ,v_future_tat 		
	       ,v_new_repair 
	       ,v_catalog_end_date;
               
             EXIT WHEN all_repair_cur%NOTFOUND;
	 
			-- This variable will later indicate whether to update this record (i.e. price or not). 
			 
			v_update	    := ecrd_utils_pkg.g_no; 
		
			dbms_output.put_line(v_counter||'**'||v_catalog_seq_id||'**'||v_repair_seq_id||'**'||v_module_seq_id||'**'||v_flow_hist);  
	
			v_counter := v_counter + 1; 
			 
            -- This is new repair no need to take price from other sources. We already have price from default catalog for it.		 
			
			IF v_new_repair <> ecrd_utils_pkg.g_yes THEN 
			
			-- getting flow prices
			-- dbms_output.put_line('b1');
			-- Step #8 in Excel
			
			IF v_repair_type NOT IN (ecrd_utils_pkg.g_merge_repair 
			   		 	,ecrd_utils_pkg.g_special_ind_repair 
						,ecrd_utils_pkg.g_special_group_repair 
						,ecrd_utils_pkg.g_child_repair) THEN  --  Step #8 in Excel .  
																				--Prices for all these repair are already present in the cursor.
						
	          	    
		  -- Step #9 in Excel 				
				
				IF TO_CHAR(v_sysdate-1,'YYYY/MM/DD')  = TO_CHAR(v_catalog_effective_date,'YYYY/MM/DD') 
				THEN 
		    	         	v_update := ecrd_utils_pkg.g_yes;			
				END IF;
				
				IF v_flow_hist = ecrd_utils_pkg.g_yes 
				AND TO_CHAR(v_sysdate-1,'YYYY/MM/DD')  = TO_CHAR(v_catalog_effective_date,'YYYY/MM/DD') 
				THEN 
					
					v_temp_repair_price := v_repair_price; 
		
		                        BEGIN
					
					SELECT	   repair_price
					INTO       v_repair_price
					FROM 	   CRD_E_REPAIR_CATALOG
					WHERE 	   repair_seq_id  = v_repair_seq_id
					AND 	   catalog_seq_id = v_default_catalog_seq_id
					AND 	   repair_end_date IS NULL; 
					
  		    	         	v_update := ecrd_utils_pkg.g_yes;

	  		    	        EXCEPTION 
					
					WHEN NO_DATA_FOUND THEN
					v_repair_price    := v_temp_repair_price;
					END;
								
				
				ELSIF v_flow_hist = ecrd_utils_pkg.g_yes 
				AND nvl(v_prc_ovrwrite,'N') =  ecrd_utils_pkg.g_no 
				THEN 
				    
				   BEGIN 
					
				       v_temp_repair_price := v_repair_price; 
				
					
				   -- Picking up price from default catalog.		
					
					SELECT	   repair_price,last_update_date,effective_date 
					INTO       v_repair_price,v_update_date,v_effective_date 
					FROM 	   CRD_E_REPAIR_CATALOG
					WHERE 	   repair_seq_id  = v_repair_seq_id
					AND 	   catalog_seq_id = v_default_catalog_seq_id
					AND        trunc(last_update_date) = trunc(sysdate) - 1 
					AND 	   repair_end_date IS NULL; 
					
				    	v_update := ecrd_utils_pkg.g_yes;
				    
				    EXCEPTION 
					
					WHEN NO_DATA_FOUND THEN
					v_update := ecrd_utils_pkg.g_no;
					v_repair_price    := v_temp_repair_price;
					v_update_date	  := v_sysdate - 10;				-- This is done just that this date does not match the 
					v_effective_date  := v_sysdate - 10;				-- sysdate in the next IF condition as no data was found.
				
				    END; 

		 			-- Step #10 in Excel 
					
					/*IF TO_CHAR(v_update_date,'MM/DD/YYYY') =  TO_CHAR(v_sysdate-1,'MM/DD/YYYY') THEN
					   v_update := ecrd_utils_pkg.g_yes; 
					END IF;*/
					
			-- end getting flow prices	
				
			-- Step #11 in Excel. 
			-- getting history prices 
				
				END IF;-- End of history / flow .
			    
				
			END IF; -- End of NOT MR,SR,SP. 
		
	END IF;  -- End checking new repair.
	
		
	-- end getting history prices	     

----Step #14 -------------- Populating the table with all repair data.------------------------------
         
               v_ecrd_cust_cal_tab.EXTEND;

	       
	       v_ecrd_cust_cal_tab(v_cnt) := ECRD_CUST_CAT_PRICE_CAL_obj
		       (
			v_catalog_seq_id    
                       ,v_default_catalog_seq_id
                       ,v_module_seq_id               
                       ,v_repair_seq_id
                       ,v_repair_type
                       ,v_repair_price
                       ,v_calculated_price_default_ind
                       ,v_flow_hist
                       ,v_catalog_effective_date
		       ,v_update		
		       ,v_new_repair
		       ,ecrd_utils_pkg.g_no
		       ,ecrd_utils_pkg.g_no        --- This is because it is still not decide whether it is anniversary of the catalog or not.
		       ,v_prc_ovrwrite		
		       ,v_rep_eff_date		
		       ,v_inc_price_ind		
		       ,v_repair_tat		
		       ,v_inc_tat			
		       ,v_future_price		
		       ,v_fut_eff_date		
		       ,v_price_type		
		       ,v_rep_dis_seq_id 	
		       ,v_future_tat
		       ,v_catalog_end_date
                       );
                       
              v_cnt := v_cnt + 1;
         
          END LOOP;
------------------- END populating table with all repair data -----------------------------------

END ecrd_get_base_price_prc;							

------------------------ Header -------------------------------------
-- Program       crd_batch_cust_cat_pkg.get_updated_price_prc 
-- Author        Patni OffShore Team
-- Date          October 2004 
-- Description   The puprpose of this procedure is to  calculate discount and
--               escalation for the base price and give the updated price.
-- Calls         none
-- 
-- Date          Author             Description Of Change
----------------------------------------------------------------------

PROCEDURE ecrd_get_updated_price_prc(
		  					 p_in_catalog_seq_id IN NUMBER
							,p_in_repair_seq_id  IN NUMBER
							,p_in_module_seq_id  IN NUMBER
							,p_in_cat_eff_date   IN DATE
							,p_in_flow_price_ind IN VARCHAR2
							,p_in_new_rep_ind    IN VARCHAR2
							,p_in_price_def_ind  IN VARCHAR2
							,p_in_repair_price   IN VARCHAR2
							,p_in_prc_ovwrt_ind  IN VARCHAR2
							,p_in_rep_eff_date   IN DATE
							,p_in_out_ann	     IN OUT VARCHAR2
							,p_in_out_esc	     IN OUT VARCHAR2 	
							,p_in_default_catalog_seq_id IN NUMBER
							,p_in_catalog_end_date IN DATE
							,p_in_inc_tat_ind IN VARCHAR2
							,p_in_out_rpr_tat IN OUT NUMBER
							,p_in_update_flag IN VARCHAR2
							,p_out_updated_price OUT NUMBER
							,p_out_new_repair_price OUT NUMBER
							,p_out_rule_check_for_new OUT VARCHAR2)
	IS
	 
	 v_discount 			NUMBER(5,2);
	 v_escalation			NUMBER(5,2);
	 v_num_of_yrs			NUMBER(2);
	 v_default_price   		NUMBER(9) DEFAULT 0;
	 v_temp_out_price 		NUMBER(15,2) DEFAULT NULL;
	 v_tat 				NUMBER(11) DEFAULT NULL;				
	 v_tat_rule_flag 		VARCHAR2(1) := ecrd_utils_pkg.g_no;
	 	 
	 	 
	 
BEGIN 

-----------------  Getting Discount for this repair---------------------------- ------------------------------

  BEGIN 
  
  dbms_output.put_line('###'||p_in_catalog_seq_id||'###'||p_in_repair_seq_id); 
  
  SELECT  discount,tat 
  INTO    v_discount,v_tat 
  FROM    CRD_E_CONTRACTED_REPAIR 
  WHERE   catalog_seq_id = p_in_catalog_seq_id 
  AND     repair_seq_id  = p_in_repair_seq_id 
  AND     year = TO_CHAR(v_sysdate-1,'YYYY'); 
  
  IF (v_tat IS NOT NULL) 
  THEN 
  	v_tat_rule_flag := ecrd_utils_pkg.g_yes;
  END IF;
  
  
  IF  NVL(p_in_inc_tat_ind,'N') = 'Y' AND v_tat is not null
  THEN 
  	v_tat := 0;
  END IF;	
  
  
  EXCEPTION WHEN NO_DATA_FOUND THEN 
  	   		
    BEGIN 
	
    SELECT  discount,tat 
    INTO v_discount,v_tat 
    FROM    CRD_E_CONTRACTED_COMP
    WHERE   catalog_seq_id = p_in_catalog_seq_id
    AND     module_seq_id  = p_in_module_seq_id
    AND     year = TO_CHAR(v_sysdate-1,'YYYY');
    --dbms_output.put_line('#2');
    
    	  IF (v_tat IS NOT NULL) 
	  THEN 
  	    	  v_tat_rule_flag := ecrd_utils_pkg.g_yes;
    	  END IF;
    	  
    	  IF  NVL(p_in_inc_tat_ind,'N') = 'Y' AND v_tat is not null
	  THEN 
	  	v_tat := 0;
	  END IF;	

    	p_out_rule_check_for_new := ecrd_utils_pkg.g_yes;
  	
	EXCEPTION WHEN NO_DATA_FOUND THEN
	
	    BEGIN
			 
	     SELECT  discount,tat 
	     INTO v_discount,v_tat 
             FROM    CRD_E_CONTRACTED_MODULE
             WHERE   catalog_seq_id = p_in_catalog_seq_id
             AND     module_seq_id  = p_in_module_seq_id
   	     AND     year = TO_CHAR(v_sysdate-1,'YYYY');
   		     
   		--dbms_output.put_line('#3');     
   		
   		IF (v_tat IS NOT NULL) 
   		THEN 
   			v_tat_rule_flag := ecrd_utils_pkg.g_yes;
   		END IF;	
   	
   		IF  NVL(p_in_inc_tat_ind,'N') = 'Y' AND v_tat is not null
		THEN 
			v_tat := 0;
		END IF;	

   		
		p_out_rule_check_for_new := ecrd_utils_pkg.g_yes;
		
		EXCEPTION WHEN NO_DATA_FOUND THEN 
		    
		BEGIN 
			
	    
	    SELECT discount,tat 
	    INTO v_discount,v_tat  
            FROM   CRD_E_CTLG_CONTRACTED 
            WHERE  catalog_seq_id = p_in_catalog_seq_id 
	    AND     year = TO_CHAR(v_sysdate-1,'YYYY'); 
			
					
	  	IF (v_tat IS NOT NULL) 
	  	THEN 
	  		v_tat_rule_flag := ecrd_utils_pkg.g_yes;
	  	END IF;	
	  	
	  		  	
	    	  IF  NVL(p_in_inc_tat_ind,'N') = 'Y' AND v_tat is not null
		  THEN 
		  	v_tat := 0;
		  END IF;	

	  	
		p_out_rule_check_for_new := ecrd_utils_pkg.g_yes;
			
		EXCEPTION WHEN NO_DATA_FOUND THEN
		
		v_discount := 0;
		
		END;
		
		END;
	
	END;

  END; 


------------ End of getting discount ------------------------------------------------------------------------------
 
 	   			
------------ Getting Escalation for this repair ---------------------------------------------------------------------
			 
			 BEGIN 
				   
				   SELECT escalation 
				   INTO   v_escalation 
				   FROM   CRD_E_CTLG_CONTRACTED 
				   WHERE  catalog_seq_id = p_in_catalog_seq_id 
				   AND year = TO_CHAR(v_sysdate-1+const_advanced_escalation,'YYYY'); 
	             
			 	  EXCEPTION WHEN NO_DATA_FOUND THEN 
				  
				  BEGIN 
				  
				  SELECT SUM(index_value*index_dependancy) 
				  INTO   v_escalation 
		                  FROM   CRD_E_INFLATION_INDEX
	                      	  WHERE  catalog_seq_id = p_in_catalog_seq_id 
	                          AND year = TO_CHAR(v_sysdate-1+const_advanced_escalation,'YYYY');

				  
				  EXCEPTION WHEN NO_DATA_FOUND THEN
				  	v_escalation := 0;
				  
				  END;
				  END;

---------- End of getting escalation for the repair  ----------------------------------------------------- 
 
  
------------ New records will be inserted on the anivarsary of a catalog.-------- 


IF TO_CHAR(v_sysdate-1+const_advanced_escalation,'MM/DD')  = TO_CHAR(p_in_cat_eff_date,'MM/DD') 
   AND TRUNC(p_in_catalog_end_date) > TRUNC(v_sysdate-1+const_advanced_escalation) 
   AND TO_CHAR(v_sysdate-1+const_advanced_escalation,'YYYY')  > TO_CHAR(p_in_cat_eff_date,'YYYY') 
THEN  
		p_in_out_esc := ecrd_utils_pkg.g_yes;
END IF;

IF TO_CHAR(v_sysdate-1,'MM/DD')  = TO_CHAR(p_in_cat_eff_date,'MM/DD') 
   AND TO_CHAR(v_sysdate-1,'YYYY')  > TO_CHAR(p_in_cat_eff_date,'YYYY')       
THEN  
		p_in_out_ann := ecrd_utils_pkg.g_yes;
END IF;

-----------------------------------------------------------------------------------------


--   Apply escalation if 
--  1) Over write indicator is checked but repair anniversary.
--  2) Over write indicator is not checked and also Flow price indicator not checked and catalog anniversary.

------------- Calculating new price ----- 

dbms_output.put_line('New Repair  Ind '||p_in_new_rep_ind);
dbms_output.put_line('Flow price Ind '||p_in_flow_price_ind);
dbms_output.put_line('Price Overwrite Ind '||p_in_prc_ovwrt_ind);
dbms_output.put_line('Anniversary'||p_in_out_ann);

-- If a new repair is there 
-- or the flow down ind is yes or overwrite ind is no or the update flag is yes.
-- or today is catalog effectice date.

IF (p_in_new_rep_ind = ecrd_utils_pkg.g_yes 
OR (p_in_flow_price_ind = ecrd_utils_pkg.g_yes AND nvl(p_in_prc_ovwrt_ind,'N') <> ecrd_utils_pkg.g_yes 
AND p_in_update_flag = ecrd_utils_pkg.g_yes) 
OR TO_CHAR(v_sysdate-1,'YYYY/MM/DD')  = TO_CHAR(p_in_cat_eff_date,'YYYY/MM/DD')) 
THEN 
	
	IF (v_tat_rule_flag = ecrd_utils_pkg.g_yes AND v_tat is not null) 
	THEN 
	     p_in_out_rpr_tat := v_tat;
	END IF;
	
	p_out_updated_price :=  (p_in_repair_price - v_discount/100 * p_in_repair_price); 
	v_temp_out_price := p_out_updated_price; 
	-- If new repair is there then repair price would be discounted 
	p_out_new_repair_price := v_temp_out_price;  

END IF;

-- If it is a advanced escalation 
-- or it is an anniversary.

IF (p_in_out_esc = ecrd_utils_pkg.g_yes 
   OR p_in_out_ann = ecrd_utils_pkg.g_yes) then 

	--dbms_output.put_line('Here 2');	

	IF (v_escalation = 0 AND p_in_flow_price_ind = ecrd_utils_pkg.g_no 
	AND p_in_new_rep_ind = ecrd_utils_pkg.g_no AND v_discount <> 0) THEN 
 	   
		SELECT	   repair_price 
		INTO       v_default_price 
		FROM 	   CRD_E_REPAIR_CATALOG 
		WHERE 	   repair_seq_id  = p_in_repair_seq_id 
		AND 	   catalog_seq_id = p_in_default_catalog_seq_id
		AND 	   repair_end_date IS NULL; 

 	   p_out_updated_price :=  (v_default_price - v_discount/100 * v_default_price); 
 	   
 	   IF (v_tat_rule_flag = ecrd_utils_pkg.g_yes) 
 	   THEN 
		 p_in_out_rpr_tat := v_tat;	   
 	   END IF;
		
	ELSIF (v_temp_out_price IS NULL) THEN 
		p_out_updated_price := (p_in_repair_price + v_escalation/100 * p_in_repair_price); 
	ELSE
		p_out_updated_price := (v_temp_out_price + v_escalation/100 * v_temp_out_price); 
	END IF;
	
	-- If anniversary is there and new repair then repair price would discount+escalation) 
	
	IF (p_in_out_ann = ecrd_utils_pkg.g_yes AND p_in_new_rep_ind = ecrd_utils_pkg.g_yes) 
	THEN 
		p_out_new_repair_price := p_out_updated_price;   	
	END IF;
	
	

END IF;	

IF (p_out_updated_price is null) THEN 
	p_out_updated_price := p_in_repair_price; 
END IF;

v_temp_out_price := null; 

dbms_output.put_line('Escalation '||p_in_out_esc);
dbms_output.put_line('No of escalation '||v_escalation);
dbms_output.put_line('No of years '||v_num_of_yrs);
dbms_output.put_line('Discount '||v_discount);
dbms_output.put_line('Base Price'||p_in_repair_price);
dbms_output.put_line('Updated Price'||p_out_updated_price);
dbms_output.put_line('Escalation Ind :'||p_in_out_esc);
dbms_output.put_line('TAT :'||p_in_out_rpr_tat);

-- If default price ind is yes then it is checked whether 
-- the updated price is more than the default catalog.
-- if it is then the default's catalogs price is retained
-- else the new price is updated

IF (p_in_price_def_ind = ecrd_utils_pkg.g_yes) 
THEN    
					
	BEGIN 
	
	SELECT	   repair_price
	INTO       v_default_price
	FROM 	   CRD_E_REPAIR_CATALOG
	WHERE 	   repair_seq_id  = p_in_repair_seq_id
	AND 	   catalog_seq_id = p_in_default_catalog_seq_id
	AND 	   repair_end_date IS NULL; 
	
	EXCEPTION 
	WHEN NO_DATA_FOUND THEN 
		v_default_price := 0;
	END;
	
	IF (v_default_price <> 0 AND p_out_updated_price > v_default_price) 
	THEN 
		  --dbms_output.put_line('Here 3 '||v_default_price);	
		  p_out_updated_price := v_default_price;
	END IF;	  
END IF;

------------- End calculating new price .

END ecrd_get_updated_price_prc;

------------------------ Header -------------------------------------
-- Program       crd_batch_cust_cat_pkg.crd_batch_cust_cat_prc 
-- Author        Patni OffShore Team
-- Date          October 2004 
-- Description   This is the procedure which will be called to run the batch job
--               for updating customer catalog. 
-- Calls         none.
-- 
-- Date          Author             Description Of Change
----------------------------------------------------------------------
PROCEDURE ecrd_batch_cust_cat_prc 
	
	IS 
	 all_repair_cur calc_cur; 
	 v_ecrd_cust_cal_tab ECRD_CUST_CAT_PRICE_CAL_tab := ECRD_CUST_CAT_PRICE_CAL_tab(); 
	 v_arr_cnt					NUMBER; 
	 v_cnt						NUMBER := 1;  
	 v_cnt_in					NUMBER := 0;  
	 v_insert					VARCHAR2(5);  
	 v_update 					VARCHAR2(5); 
	 v_updated_price				NUMBER(15,2); 
	 v_new_repair_price 				NUMBER(15,2);
	 v_new_repair					VARCHAR2(5) := ecrd_utils_pkg.g_yes;
	 v_old_repair					VARCHAR2(5)   := ecrd_utils_pkg.g_no;
	 v_count_repair                     NUMBER;
	 v_rule_check_for_new					VARCHAR2(1) := ecrd_utils_pkg.g_no;
BEGIN 

-- Step #2 in Excel

-- Getting all the data into the cursor.
	 --dbms_output.put_line('1');
	 
     OPEN all_repair_cur FOR 
-- Existing repairs. 
        SELECT   cat.catalog_seq_id 
        	,ecrd_batch_cust_cat_pkg.ecrd_fnc_def_cat_seq_id(cat.eng_mdl_number) 
                ,rep.module_seq_id 
                ,repc.repair_seq_id 
                ,rep.repair_type 
                ,repc.repair_price 
                ,cat.catalog_effective_date 
                ,cat.calculated_price_default_ind 
                ,cat.flowdown_changes_ind 
		,repc.price_overwrite_flag_ind 
		,repc.effective_date			 
		,repc.incremental_price_ind		 
		,repc.repair_tat			 
		,repc.incremental_tat_ind		 
		,repc.future_price			 
		,repc.future_effective_date			 
		,repc.price_type		 
		,repc.repair_display_seq_id		 
		,repc.future_tat			 
		,v_old_repair
		,cat.catalog_end_date -- This is to indicate these are exiting repairs and insert wont be performed on these.			 
        FROM     CRD_E_REPAIR_CATALOG repc 
        	,CRD_E_REPAIR rep 
        	,CRD_E_CATALOG cat 
        WHERE   cat.catalog_type = ecrd_utils_pkg.g_customer_catalog 
        AND     TRUNC(cat.catalog_end_date) >= TRUNC(sysdate)  
        AND     repc.catalog_seq_id = cat.catalog_seq_id 
        AND     repc.repair_end_date IS NULL 
        AND     repc.repair_seq_id  = rep.repair_seq_id 
        AND     rep.parent_repair_seq_id IS NULL 
	AND     (cat.flowdown_changes_ind = 'Y' 
	OR TO_CHAR(sysdate-1,'MM/DD')  = TO_CHAR(cat.catalog_effective_date,'MM/DD') 
	OR (TO_CHAR(sysdate-1+const_advanced_escalation,'MM/DD')  = TO_CHAR(cat.catalog_effective_date,'MM/DD') 
	AND TRUNC(cat.catalog_end_date) > TRUNC(sysdate-1+const_advanced_escalation)) )  
	UNION
--New   Repairs		
	SELECT  DISTINCT cat.catalog_seq_id 
			,new_prices.catalog_seq_id 
			,new_prices.module_seq_id 
			,new_prices.repair_seq_id 
			,new_prices.repair_type 
			,new_prices.repair_price 
			,cat.catalog_effective_date 
			,ecrd_utils_pkg.g_no 
			,ecrd_utils_pkg.g_no 
			,ecrd_utils_pkg.g_no 
			,v_sysdate 
			,new_prices.incremental_price_ind		  
			,new_prices.repair_tat			 
			,new_prices.incremental_tat_ind
			,new_prices.future_price			 
			,new_prices.future_effective_date			 
			,new_prices.price_type		 
			,new_prices.repair_display_seq_id		 
			,new_prices.future_tat
			,v_new_repair   -- This is to indicate these are new repairs and insert would be performed on these.
			,cat.catalog_end_date 
	FROM             CRD_E_REPAIR_CATALOG repc
			,CRD_E_REPAIR rep
			,CRD_E_CATALOG cat
			,(
						-- Selecting prices from the default catalog for new repairs.
				 SELECT 
				 def_cat_rep.repair_seq_id
				,def_cat_rep.catalog_seq_id
				,def_cat_rep.effective_date
				,def_cat_rep.repair_price
				,def_cat_rep.incremental_tat_ind
				,def_cat_rep.future_price
				,def_cat_rep.future_effective_date
				,def_cat_rep.price_type
				,def_cat_rep.repair_end_date
				,def_cat_rep.repair_display_seq_id
				,def_cat_rep.future_tat
				,def_cat_rep.price_overwrite_flag_ind
				,def_cat.eng_mdl_number
				,def_rep.module_seq_id
				,def_cat_rep.repair_tat
				,def_cat_rep.incremental_price_ind
				,def_rep.repair_type
				FROM    CRD_E_REPAIR_CATALOG def_cat_rep
				       ,CRD_E_CATALOG def_cat
				       ,CRD_E_REPAIR def_rep
				WHERE     def_cat.catalog_type = ecrd_utils_pkg.g_default_catalog 
				AND       TRUNC(def_cat.catalog_end_date) >= TRUNC(sysdate-1)  
				AND       TRUNC(def_cat_rep.effective_date) = TRUNC(sysdate-1) 
				AND       def_cat.catalog_seq_id = def_cat_rep.catalog_seq_id  
				AND       def_cat_rep.repair_end_date IS NULL 
				AND       def_rep.repair_seq_id = def_cat_rep.repair_seq_id  
			        ) new_prices 
	WHERE   cat.catalog_type = ecrd_utils_pkg.g_customer_catalog 
	AND     cat.eng_mdl_number = new_prices.eng_mdl_number 
	AND     TRUNC(cat.catalog_end_date) >= TRUNC(sysdate-1) 
	AND     repc.catalog_seq_id = cat.catalog_seq_id 
	AND     repc.repair_end_date IS NULL 
	AND     repc.repair_seq_id  = rep.repair_seq_id 
	AND     rep.parent_repair_seq_id IS NULL;

	  
  
--- 1) Now the cursor has all the repairs for all customer catalogs. 
--  The prices it is holding currently are from current catalog. 
--  Hence calling get_base_price to get all base prices for all repairs .
--  2)  Also there are records for new repairs.
	
	ecrd_get_base_price_prc(all_repair_cur,v_ecrd_cust_cal_tab); 
  	
  	   
    
-- Step #16 in Excel.	
	
	v_arr_cnt := v_ecrd_cust_cal_tab.COUNT;
 		
	
	FOR  v_cnt IN 1 .. v_arr_cnt
   	LOOP

			-- Apply discount / Escalation to these base prices.
			-- and getting the updated price.
			
			ecrd_get_updated_price_prc(
	  					 v_ecrd_cust_cal_tab(v_cnt).catalog_seq_id
						,v_ecrd_cust_cal_tab(v_cnt).repair_seq_id
						,v_ecrd_cust_cal_tab(v_cnt).module_seq_id
						,v_ecrd_cust_cal_tab(v_cnt).cat_eff_date
						,v_ecrd_cust_cal_tab(v_cnt).flow_price_ind
						,v_ecrd_cust_cal_tab(v_cnt).new_repair_ind
						,v_ecrd_cust_cal_tab(v_cnt).cal_price_def_ind
						,v_ecrd_cust_cal_tab(v_cnt).repair_price
						,v_ecrd_cust_cal_tab(v_cnt).prc_ovrwrite_ind
						,v_ecrd_cust_cal_tab(v_cnt).rep_eff_date
						,v_ecrd_cust_cal_tab(v_cnt).anniversary_ind
						,v_ecrd_cust_cal_tab(v_cnt).escalation_ind
						,v_ecrd_cust_cal_tab(v_cnt).default_catalog_seq_id
						,v_ecrd_cust_cal_tab(v_cnt).catalog_end_date
						,v_ecrd_cust_cal_tab(v_cnt).inc_tat
						,v_ecrd_cust_cal_tab(v_cnt).repair_tat
						,v_ecrd_cust_cal_tab(v_cnt).update_ind
						,v_updated_price
						,v_new_repair_price 
						,v_rule_check_for_new);
	
	
	-- dbms_output.put_line('4');	
			
			
-- There are 4 Scenarios.
-- 1) The escalation ind is Yes. A record with staging ind as 'A' goes into the history table.
-- 2) The update_ind = ecrd_utils_pkg.g_yes . This is because the customer catalog price is outdated as
--     flow down changes was checked and some price changed today.
-- 3) The anniversary indicator is Y signifing that new records to be inserted.     
-- 4) The new repair indicator is Y and hence insert the record.	

				-----UPDATE------- 
				
				
				-- If advanced escalation is there 
				-- then a record is inserted into the 
				-- history table.
				
				IF (v_ecrd_cust_cal_tab(v_cnt).escalation_ind = ecrd_utils_pkg.g_yes) 
				THEN 
				   
				   dbms_output.put_line('In escalation insert');
				   
				   IF v_ecrd_cust_cal_tab(v_cnt).new_repair_ind = ecrd_utils_pkg.g_yes 
				   THEN 

				   INSERT INTO CRD_E_REPAIR_CATALOG_HIST(CATALOG_SEQ_ID, 
				   REPAIR_SEQ_ID, 
				   EFFECTIVE_DATE, 
				   STAGING_HISTORY_IND,
				   CHANGE_START_DATE,
				   REPAIR_PRICE,
				   INCREMENTAL_PRICE_IND,
				   REPAIR_TAT,
				   INCREMENTAL_TAT_IND,
				   FUTURE_PRICE,
				   FUTURE_EFFECTIVE_DATE,
				   PRICE_TYPE,
				   REPAIR_END_DATE,
				   REPAIR_DISPLAY_SEQ_ID,
				   FUTURE_TAT,
				   PRICE_OVERWRITE_FLAG_IND,
				   CREATED_BY,                      
				   CREATION_DATE,                   
				   LAST_UPDATE_DATE,                
				   LAST_UPDATED_BY)                 
				   VALUES 	
				   (v_ecrd_cust_cal_tab(v_cnt).catalog_seq_id,
				   v_ecrd_cust_cal_tab(v_cnt).repair_seq_id,
				   v_sysdate-1 + const_advanced_escalation,
				   'A',
				   v_sysdate-1 + const_advanced_escalation,
				   v_updated_price,  
				   v_ecrd_cust_cal_tab(v_cnt).inc_price_ind,
				   v_ecrd_cust_cal_tab(v_cnt).repair_tat,
				   v_ecrd_cust_cal_tab(v_cnt).inc_tat,
				   v_ecrd_cust_cal_tab(v_cnt).future_price,
				   v_ecrd_cust_cal_tab(v_cnt).fut_eff_date,
				   v_ecrd_cust_cal_tab(v_cnt).price_type,
				   null,
				   v_ecrd_cust_cal_tab(v_cnt).rep_dis_seq_id,
				   v_ecrd_cust_cal_tab(v_cnt).future_tat,
				   v_ecrd_cust_cal_tab(v_cnt).prc_ovrwrite_ind,
				   'system',                      
				   sysdate,
				   sysdate,
				   'System'); 
				  
				  ELSE

				   
				   INSERT INTO CRD_E_REPAIR_CATALOG_HIST(CATALOG_SEQ_ID, 
				   REPAIR_SEQ_ID, 
				   EFFECTIVE_DATE, 
				   STAGING_HISTORY_IND,
				   CHANGE_START_DATE,
				   REPAIR_PRICE,
				   INCREMENTAL_PRICE_IND,
				   REPAIR_TAT,
				   INCREMENTAL_TAT_IND,
				   FUTURE_PRICE,
				   FUTURE_EFFECTIVE_DATE,
				   PRICE_TYPE,
				   REPAIR_END_DATE,
				   REPAIR_DISPLAY_SEQ_ID,
				   FUTURE_TAT,
				   PRICE_OVERWRITE_FLAG_IND,
				   CREATED_BY,                      
				   CREATION_DATE,                   
				   LAST_UPDATE_DATE,                
				   LAST_UPDATED_BY)                 

				   (SELECT CATALOG_SEQ_ID,
				   REPAIR_SEQ_ID,
				   v_sysdate-1 + const_advanced_escalation,
				   'A',
				   v_sysdate-1 + const_advanced_escalation,
				   v_updated_price,  
				   INCREMENTAL_PRICE_IND,
				   v_ecrd_cust_cal_tab(v_cnt).repair_tat,
				   INCREMENTAL_TAT_IND,
				   FUTURE_PRICE,
				   FUTURE_EFFECTIVE_DATE,
				   PRICE_TYPE,
				   REPAIR_END_DATE,
				   REPAIR_DISPLAY_SEQ_ID,
				   FUTURE_TAT,
				   PRICE_OVERWRITE_FLAG_IND,
				   'System',                      
				   SYSDATE,
				   SYSDATE,
				   'System' FROM 
				   CRD_E_REPAIR_CATALOG  
				   WHERE repair_seq_id  = v_ecrd_cust_cal_tab(v_cnt).repair_seq_id 
				   AND 	 catalog_seq_id = v_ecrd_cust_cal_tab(v_cnt).catalog_seq_id 
				   AND	 effective_date	= v_ecrd_cust_cal_tab(v_cnt).rep_eff_date); 

				   END IF;					
				
				END IF;
				
				
				-- Updation if there is a flow down and 
				-- it is not an anniversary 
				
				IF (v_ecrd_cust_cal_tab(v_cnt).update_ind = ecrd_utils_pkg.g_yes 
				   AND v_ecrd_cust_cal_tab(v_cnt).anniversary_ind = ecrd_utils_pkg.g_no)		
				THEN 
								   
				   UPDATE	CRD_E_REPAIR_CATALOG 
				   SET 		repair_price	     = v_updated_price,
				   		repair_tat           = v_ecrd_cust_cal_tab(v_cnt).repair_tat,
				   		effective_date       = sysdate - 1,
				       	        LAST_UPDATE_DATE     = sysdate,  
				                LAST_UPDATED_BY      = 'System'  
				   WHERE	repair_seq_id		 = v_ecrd_cust_cal_tab(v_cnt).repair_seq_id 
				   AND 		catalog_seq_id		 = v_ecrd_cust_cal_tab(v_cnt).catalog_seq_id 
				   AND		effective_date		 = v_ecrd_cust_cal_tab(v_cnt).rep_eff_date  
				   AND          repair_end_date IS NULL; 
				   
				END IF;
			
			---- END UPDATE ----
						
			--dbms_output.put_line('Repair_ind'||v_ecrd_cust_cal_tab(v_cnt).new_repair_ind);			
			
			----- INSERT IF ANNIVERSERY-----
		
		IF (v_ecrd_cust_cal_tab(v_cnt).anniversary_ind = ecrd_utils_pkg.g_yes)	
		THEN

		   dbms_output.put_line('5'||v_ecrd_cust_cal_tab(v_cnt).anniversary_ind);	
		   dbms_output.put_line('6'||v_ecrd_cust_cal_tab(v_cnt).new_repair_ind); 
		   dbms_output.put_line('Catalog :- '||v_ecrd_cust_cal_tab(v_cnt).catalog_seq_id); 

		   -- Since it is anniversary of catalog need to put end date for previous years records.	

		   INSERT INTO CRD_E_REPAIR_CATALOG_HIST(CATALOG_SEQ_ID, 
		   REPAIR_SEQ_ID, 
		   EFFECTIVE_DATE, 
		   STAGING_HISTORY_IND,
		   CHANGE_START_DATE,
		   REPAIR_PRICE,
		   INCREMENTAL_PRICE_IND,
		   REPAIR_TAT,
		   INCREMENTAL_TAT_IND,
		   FUTURE_PRICE,
		   FUTURE_EFFECTIVE_DATE,
		   PRICE_TYPE,
		   REPAIR_END_DATE,
		   REPAIR_DISPLAY_SEQ_ID,
		   FUTURE_TAT,
		   PRICE_OVERWRITE_FLAG_IND,
		   CREATED_BY,                      
		   CREATION_DATE,                   
		   LAST_UPDATE_DATE,                
		   LAST_UPDATED_BY)                 

		   (SELECT CATALOG_SEQ_ID,
		   REPAIR_SEQ_ID,
		   EFFECTIVE_DATE,
		   'H',
		   SYSDATE,
		   REPAIR_PRICE,
		   INCREMENTAL_PRICE_IND,
		   REPAIR_TAT,
		   INCREMENTAL_TAT_IND,
		   FUTURE_PRICE,
		   FUTURE_EFFECTIVE_DATE,
		   PRICE_TYPE,
		   REPAIR_END_DATE,
		   REPAIR_DISPLAY_SEQ_ID,
		   FUTURE_TAT,
		   PRICE_OVERWRITE_FLAG_IND,
		   'System',                      
		   SYSDATE,
		   SYSDATE,
		   'System' FROM 
		   CRD_E_REPAIR_CATALOG  
		   WHERE repair_seq_id  = v_ecrd_cust_cal_tab(v_cnt).repair_seq_id 
		   AND 	 catalog_seq_id = v_ecrd_cust_cal_tab(v_cnt).catalog_seq_id 
		   AND	 effective_date	= v_ecrd_cust_cal_tab(v_cnt).rep_eff_date); 


		   dbms_output.put_line('Updated Price '||v_updated_price);
		   
		   UPDATE CRD_E_REPAIR_CATALOG 
		   SET 	 repair_price         = v_updated_price,
		   	 repair_tat 	      = v_ecrd_cust_cal_tab(v_cnt).repair_tat, 	
		   	 effective_date       = sysdate - 1, 
			 LAST_UPDATE_DATE     = sysdate, 
			 LAST_UPDATED_BY      = 'System'  
		   WHERE   repair_seq_id      = v_ecrd_cust_cal_tab(v_cnt).repair_seq_id 
		   AND 	   catalog_seq_id     = v_ecrd_cust_cal_tab(v_cnt).catalog_seq_id 
		   AND	   effective_date     = v_ecrd_cust_cal_tab(v_cnt).rep_eff_date  
		   AND     repair_end_date IS NULL; 

		   DELETE FROM CRD_E_REPAIR_CATALOG_HIST 
		   WHERE REPAIR_SEQ_ID = v_ecrd_cust_cal_tab(v_cnt).repair_seq_id  
		   AND   CATALOG_SEQ_ID = v_ecrd_cust_cal_tab(v_cnt).catalog_seq_id  
		   AND   STAGING_HISTORY_IND = 'A' 
		   AND   TRUNC(CHANGE_START_DATE) = TRUNC(sysdate) - 1 
		   AND   TRUNC(EFFECTIVE_DATE) = TRUNC(sysdate) - 1;
		
		
		END IF;   

 
		 -- For new repairs if there is a rule at component level 
		 -- or module level or catalog level then it is inserted as
		 -- a new repair
		 
		 IF (v_ecrd_cust_cal_tab(v_cnt).new_repair_ind = ecrd_utils_pkg.g_yes 
		     AND v_rule_check_for_new = ecrd_utils_pkg.g_yes)
		 THEN   

			INSERT INTO CRD_E_REPAIR_CATALOG VALUES(
							    v_ecrd_cust_cal_tab(v_cnt).repair_seq_id
							   ,v_ecrd_cust_cal_tab(v_cnt).catalog_seq_id
							   ,v_sysdate-1
							   ,v_new_repair_price 
							   ,v_ecrd_cust_cal_tab(v_cnt).inc_price_ind
							   ,v_ecrd_cust_cal_tab(v_cnt).repair_tat
							   ,v_ecrd_cust_cal_tab(v_cnt).inc_tat
							   ,v_ecrd_cust_cal_tab(v_cnt).future_price
							   ,v_ecrd_cust_cal_tab(v_cnt).fut_eff_date
							   ,v_ecrd_cust_cal_tab(v_cnt).price_type
							   ,NULL
							   ,v_ecrd_cust_cal_tab(v_cnt).rep_dis_seq_id
							   ,v_ecrd_cust_cal_tab(v_cnt).future_tat
							   ,v_ecrd_cust_cal_tab(v_cnt).prc_ovrwrite_ind
							   ,'System'
							   ,v_sysdate
							   ,v_sysdate
							   ,'System');												   			   				   						   

		END IF;	
		


	 	        -----END INSERT --
			

	
	        	
    END LOOP; 
    
    COMMIT; 

--- End populating the object ---

    dbms_output.put_line('Success'); 

END ecrd_batch_cust_cat_prc;

FUNCTION ecrd_fnc_def_cat_seq_id(p_eng_mdl_number_id IN CRD_E_CATALOG.ENG_MDL_NUMBER%TYPE) 
RETURN NUMBER 
IS 
n_catalog_seq_id CRD_E_REPAIR_CATALOG.CATALOG_SEQ_ID%TYPE; 
BEGIN
		  SELECT cec.CATALOG_SEQ_ID 
		  INTO n_catalog_seq_id 
		  FROM CRD_E_CATALOG cec
		  WHERE cec.eng_mdl_number = p_eng_mdl_number_id
		  AND   cec.catalog_type   = ecrd_utils_pkg.g_default_catalog
		  AND   TRUNC(cec.catalog_end_date) >= TRUNC(sysdate);
		  
		  RETURN n_catalog_seq_id;
		  
END ecrd_fnc_def_cat_seq_id;

END ecrd_batch_cust_cat_pkg;

/