CREATE OR REPLACE PACKAGE ecrd_maintenace_pkg AS
--
/***********************************************************************/
--
-- Copyright Message : Copyright(c) 2004 GE Aircraft Engines
-- Title             : ecrd_maintenace_pkg
-- Author            : Patni Offshore
-- Company           : GE Aircraft Engines
-- Date              : October 2004
-- Purpose           : File contains Package Spec and body for Procs
--                     for Maintenance Data Management
--
-- Modifications     :
--    Date             Description
-- [DD-MMM-YYYY]       A brief description of change should go here like
--                              who had made change, why change was implemented
--                              and where change is made.
--
-- 28-may-2004         New Code First Version
--
/***********************************************************************/
--
/***********************************************************************/
--
-- Package Name    		: ecrd_maintenace_pkg
-- Purpose              : Site and Labour Rates management package.
-- Procedures/Functions :
--                        PROCEDURE ecrd_load_site_prc
--                        PROCEDURE ecrd_update_site_prc
/***********************************************************************/
--
TYPE retcur IS REF CURSOR;
--
/***********************************************************************/
-- Procedure Name                : ecrd_load_site_prc
-- Purpose                       : This procedure is used to get User Details
-- Input Parameters              : p_in_SiteCode	crd_site.Location_code%TYPE
-- Output Parameters             : p_out_SiteName crd_site.Location_Name%TYPE
-- Output Parameters             : p_out_LabourRate crd_site.Labour_Rate%TYPE
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_load_site_prc(p_in_SiteCode IN crd_location.location_id%TYPE,
							p_out_SiteName OUT crd_location.site_name%TYPE,
							p_out_LabourRate OUT crd_location.location_labor_rate%TYPE
					);


/***********************************************************************/
-- Procedure Name                : ecrd_update_site_prc
-- Purpose                       : This procedure is used to update Site Details
-- Input Parameters              : p_in_UserId 	crd_user.user_id%TYPE
-- Input Parameters             	: p_out_FirstName crd_user.user_first_name%TYPE
-- Input Parameters             	: p_out_LastName crd_user.user_last_name%TYPE
-- Input Parameters             	: p_out_SiteCode location_code%TYPE
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_update_site_prc(p_in_SiteCode IN crd_location.Location_id%TYPE,
		  					p_in_SiteName IN crd_location.site_Name%TYPE,				 	
							p_in_LabourRate IN crd_location.location_Labor_Rate%TYPE,
							p_in_updated_by IN crd_Location.last_updated_by%TYPE,
							p_out_success OUT VARCHAR2
					);
--
-- 
--
/***********************************************************************/
-- Procedure Name                : ecrd_save_price_adjust_prc
-- Purpose                       : This procedure is used to save the price adjustment
-- Input Parameters     			: p_in_eng_mdl_code crd_e_catalog.eng_mdl_number%TYPE
-- Input Parameters     			: p_in_module_id crd_e_component.module_seq_id%TYPE
-- Input Parameters     			: p_in_module_id crd_e_component.module_seq_id%TYPE
-- Input Parameters     			: p_in_component_type VARCHAR2
-- Input Parameters     			: p_in_component_code crd_e_component.component_code%TYPE
-- Input Parameters     			: p_in_price_type VARCHAR2
-- Input Parameters     			: p_in_price_value NUMBER
-- Input Parameters     			: p_in_eff_date VARCHAR2
-- Input Parameters     			: p_in_user_id crd_e_repair_catalog.CREATED_BY%TYPE
-- Output Parameters     			: p_out_message VARCHAR2
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_save_price_adjust_prc(
												p_in_eng_mdl_code     IN 	crd_e_catalog.eng_mdl_number%TYPE,
												p_in_module_id     IN 	crd_e_component.module_seq_id%TYPE,
                                    p_in_component_type IN VARCHAR2,
												p_in_component_code IN 	crd_e_component.component_code%TYPE,
                                    p_in_price_type IN VARCHAR2,
 												p_in_price_value IN NUMBER,
                                    p_in_eff_date IN VARCHAR2,
                                  	p_in_user_id         IN 	crd_e_repair_catalog.CREATED_BY%TYPE,
                                    p_out_message  OUT VARCHAR2                                   
												);


--
/***********************************************************************/
-- Procedure Name                : ecrd_view_labor_rates_prc
-- Purpose                       : This procedure is used to retrieve labor rates of sites
-- Output Parameters             : p_out_labor_rates
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_view_labor_rates_prc(p_out_labor_rates OUT retcur);

--
/***********************************************************************/
-- Procedure Name                : ecrd_get_cycle_class_prc
-- Purpose                       : This procedure is used to retrieve cycle class and 
--											  notification period
-- Output Parameters             : p_out_cycle_class_notification_period
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_get_cycle_class_prc(p_out_cycle_class OUT retcur);

/***********************************************************************/
-- Procedure Name                : ecrd_save_notify_period_prc
-- Purpose                       : This procedure is save the changes made in notification period 
-- Input Parameters     			: p_in_user_id crd_e_repair_catalog.CREATED_BY%TYPE
-- Input Parameters     			: p_in_class_period_buff LONG
-- Output Parameters             : p_out_message VARCHAR2
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

------------------------------------------
PROCEDURE ecrd_save_notify_period_prc
(
   p_in_user_id IN crd_crc_user.userid%TYPE,
	p_in_class_period_buff IN LONG,
   p_out_cycle_class OUT retcur,
	p_out_message OUT VARCHAR2
);
---------------------------------------
/***********************************************************************/
-- Procedure Name                : ecrd_save_labor_rates_prc
-- Purpose                       : This procedure is save the changes made in labor rate
-- Input Parameters     			: p_in_user_id crd_e_repair_catalog.CREATED_BY%TYPE
-- Input Parameters     			: p_in_site_labor_rate_buff LONG
-- Output Parameters             : p_out_message VARCHAR2
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_save_labor_rates_prc
(
   p_in_user_id IN crd_crc_user.userid%TYPE,
	p_in_site_labor_rate_buff IN LONG,
   p_out_labor_rate OUT retcur,
  	p_out_message OUT VARCHAR2
);

---------------------------------------
END ecrd_maintenace_pkg;
/

CREATE OR REPLACE PACKAGE BODY ecrd_maintenace_pkg AS
--
--**********************************************************************--
PROCEDURE ecrd_load_site_prc(p_in_SiteCode IN crd_location.location_id%TYPE,
							p_out_SiteName OUT crd_location.site_name%TYPE,
							p_out_LabourRate OUT crd_location.location_labor_rate%TYPE
					)
--
IS
		 v_UserId crd_crc_user.userid%TYPE;
		 v_FirstName crd_crc_user.first_name%TYPE;
		 v_LastName crd_crc_user.last_name%TYPE;

BEGIN
	  -- Retrive user details from the database

	SELECT 			 cs.site_name,
					 cs.location_LABOR_RATE
	INTO
					 p_out_SiteName,
					 p_out_LabourRate
 	FROM 	crd_location cs
	WHERE
		 cs.location_id = p_in_SiteCode;


EXCEPTION
   WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(-20052,
     'NO_SITES_FOUND ERROR IN ecrd_maintenace_pkg.ecrd_load_site_prc' ||
       SQLCODE ||  ' - ' || SQLERRM);
   WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20001,
     'ERROR IN ecrd_maintenace_pkg.ecrd_load_site_prc' ||
       SQLCODE ||  ' - ' || SQLERRM);
END ecrd_load_site_prc;

--------------------------------------------------------------------

PROCEDURE ecrd_update_site_prc(p_in_SiteCode IN crd_location.Location_id%TYPE,
		  					p_in_SiteName IN crd_location.site_Name%TYPE,				 	
							p_in_LabourRate IN crd_location.location_Labor_Rate%TYPE,
							p_in_updated_by IN crd_Location.last_updated_by%TYPE,
							p_out_success OUT VARCHAR2
					)
IS
BEGIN
	-- Update site details in the database

	update crd_location
	set
		site_name = p_in_SiteName,
		location_Labor_Rate = p_in_LabourRate,
		last_updated_by = p_in_updated_by,
		last_update_date = sysdate
	where	 location_id = p_in_SiteCode;

	p_out_success := 'SITE_SUCESSFULLY_UPDATED';

EXCEPTION
   WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20001,
     'ERROR IN ecrd_maintenace_pkg.ecrd_update_site_prc' ||
       SQLCODE ||  ' - ' || SQLERRM);
END ecrd_update_site_prc;

--------------------------------------------------------------------

PROCEDURE ecrd_save_price_adjust_prc(
												p_in_eng_mdl_code     IN 	crd_e_catalog.eng_mdl_number%TYPE,
												p_in_module_id     IN 	crd_e_component.module_seq_id%TYPE,
                                    p_in_component_type IN VARCHAR2,
												p_in_component_code IN 	crd_e_component.component_code%TYPE,
                                    p_in_price_type IN VARCHAR2,
 												p_in_price_value IN NUMBER,
                                    p_in_eff_date IN VARCHAR2,
                                  	p_in_user_id         IN 	crd_e_repair_catalog.CREATED_BY%TYPE,
                                    p_out_message  OUT VARCHAR2                                   
												)
IS
   v_eff_date DATE :=    NULL;
	v_cat_seq_id crd_e_catalog.catalog_seq_id%TYPE;
	v_component_code 	crd_e_component.component_code%TYPE;
   v_out_error_msg VARCHAR2(100):=NULL;
   v_main_query LONG;	    -- Query from Main Table
	v_staging_query LONG;  -- Query from Stahing Table
	v_where_query LONG;	-- Dynamic WHERE clause
	v_query LONG; 			-- Total Query
	NUMERIC_OVERFLOW EXCEPTION; 
	PRAGMA EXCEPTION_INIT(NUMERIC_OVERFLOW, -01438);
   VALUE_OVERFLOW EXCEPTION; 
	PRAGMA EXCEPTION_INIT(VALUE_OVERFLOW, -01426);
    	
BEGIN
		   --	Check if component code or description is passed and add clause accordingly. (Do exact match)
	    	IF  p_in_component_type = 'Code'
   		 THEN
				    v_where_query:=v_where_query||' AND UPPER(cec.component_code) = UPPER('''||p_in_component_code||''||''')';
		    ELSIF  p_in_component_type = 'Description'
		    THEN
			    v_where_query:=v_where_query||' AND UPPER(cec.component_description) = UPPER('''||p_in_component_code||''||''')';
		    END IF;--p_in_component_type = 'Description'

			--	Generate query to search in main table
	   	 v_main_query:='SELECT	 cec.component_code 
				FROM 	 crd_e_component cec
				WHERE
					 (cec.component_end_date IS NULL or cec. component_end_date > SYSDATE)
				AND 	 cec.module_seq_id =' || p_in_module_id|| ' ';
    
				--	Generate query to check in staging table
				 v_staging_query:='	SELECT	 cec.component_code 
				FROM 	 crd_e_component_history cec
				WHERE
						(cec.component_end_date IS NULL or cec. component_end_date > SYSDATE)
					AND	 cec.staging_history_ind = ''' || ecrd_utils_pkg.G_STAGING || ''' ' || '
					AND	 cec.approved_rejected_date IS NULL
					AND 	 cec.module_seq_id =' || p_in_module_id|| ' ';

    v_query := v_main_query || v_where_query || ' UNION ' || v_staging_query || v_where_query;
     
   	BEGIN
	   EXECUTE IMMEDIATE
   	v_query
      INTO v_component_code;                    

   	EXCEPTION WHEN NO_DATA_FOUND   
      THEN 
      		v_component_code:='';

      END;      
         
         v_eff_date := to_date(p_in_eff_date,ecrd_utils_pkg.G_DATE_FORMAT);
         
         	ecrd_managecatalog_pkg.ecrd_get_default_seqid_prc(
										       p_in_eng_mdl_code 
											 ,v_cat_seq_id 
											 ,v_out_error_msg );
  
                                                
 	IF (v_component_code IS NULL)
   THEN

   		p_out_message := 'COMPONENT_NOT_FOUND';
   ELSE--(v_component_code IS NULL)

   				ecrd_managecatalog_pkg.ecrd_get_default_seqid_prc(
										       p_in_eng_mdl_code 
											 ,v_cat_seq_id 
											 ,v_out_error_msg );
  

				 IF(v_eff_date=TO_DATE(SYSDATE))
				 THEN				
							      /*Move the current pricing information into history*/
							      INSERT INTO crd_e_repair_catalog_hist    
							      ( 
							      catalog_seq_id,
							      repair_seq_id,
							      effective_date,
							      staging_history_ind,
							      repair_end_date,
							      change_start_date,
							      repair_price,
							      incremental_price_ind,
							      repair_tat,
							      incremental_tat_ind,
							      future_price,
							      created_by,
							      creation_date,
							      last_update_date,
							      last_updated_by,
							      repair_display_seq_id,
							      requested_by,
							      requested_date,
							      approv_reject_by,
							      approved_rejected_date,
								   approve_reject_status,
								   rejection_comments ,
								   price_type
							      )
							      (
								   SELECT 
								   catalog_seq_id,
							      repair_seq_id,
							      effective_date,
							      ecrd_utils_pkg.g_history_record,
							      repair_end_date,
							      SYSDATE,
							      repair_price,
							      incremental_price_ind,
							      repair_tat,
							      incremental_tat_ind,
							      future_price,
							      p_in_user_id,
							      SYSDATE,
							      SYSDATE,
							      p_in_user_id,
							      repair_display_seq_id,
							      NULL,
							      NULL,
							      NULL,
							      NULL,
							      NULL,
							      NULL,
							      price_type
							      FROM  crd_e_repair_catalog rep_cat 
									WHERE repair_seq_id IN (
							       						 SELECT repair_seq_id 
							                         FROM crd_e_repair 
							                         WHERE module_seq_id = p_in_module_id 
							             				 AND component_code  = UPPER(p_in_component_code)
							                         )
							       AND catalog_seq_id=v_cat_seq_id                                 
							       AND (rep_cat.repair_end_date IS NULL OR rep_cat.repair_end_date > SYSDATE)
							      );
				--
						      /*Update the  pricing information */
						      IF (p_in_price_type ='Increase')
						      THEN
					         		 UPDATE crd_e_Repair_catalog 
					      			 SET repair_price = repair_price + (repair_price * p_in_price_value)/100
                                 /*
                                 17 feb 2005
                                 */
                                 ,effective_date   = SYSDATE
                                 ,last_update_date = SYSDATE
                                 ,last_updated_by  = p_in_user_id 
                                 /*
                                 17 feb 2005
                                 */
					             	 WHERE REPAIR_SEQ_ID IN (
					                									SELECT repair_seq_id 
					                                          FROM crd_e_repair 
					                                          WHERE module_seq_id=p_in_module_id 
					             										AND component_code=UPPER(p_in_component_code)
					                                       )
					          		AND catalog_seq_id=v_cat_seq_id
					          		AND (repair_end_date IS NULL OR repair_end_date > SYSDATE);
								ELSE --(p_in_price_type ='Increase')
				            
						            UPDATE crd_e_Repair_catalog 
						      		SET repair_price = repair_price - (repair_price * p_in_price_value)/100 
                              /*
                              17 feb 2005
                              */
                              ,effective_date   = SYSDATE
                              ,last_update_date = SYSDATE
                              ,last_updated_by  = p_in_user_id 
                              /*
                              17 feb 2005
                              */
						             WHERE REPAIR_SEQ_ID IN (
				                   									SELECT repair_seq_id 
				                                             FROM crd_e_repair 
				                                             WHERE module_seq_id=p_in_module_id 
						             									AND component_code=UPPER(p_in_component_code)
				                                           )
						             AND catalog_seq_id=v_cat_seq_id
						             AND (repair_end_date IS NULL OR repair_end_date > SYSDATE);                                 
						      
						      END IF;--(p_in_price_type ='Increase')
				      
				 ELSE--(v_eff_date=TO_DATE(SYSDATE))
				 
				        		      /*Update the  pricing information */
								      IF (p_in_price_type ='Increase')
								      THEN
                              
										      UPDATE crd_e_Repair_catalog 
								      		SET future_price          = repair_price + (repair_price * p_in_price_value)/100,
								            	 future_effective_date = v_eff_date
                                        /*
		                                  17 feb 2005
		                                  */
		                                  ,last_update_date  = SYSDATE
		                                  ,last_updated_by   = p_in_user_id 
		                                  /*
		                                  17 feb 2005
		                                  */
								            WHERE repair_seq_id IN (
				                        								SELECT repair_seq_id 
				                                                FROM crd_e_repair 
				                                                WHERE module_seq_id=p_in_module_id 
								             							   AND component_code=UPPER(p_in_component_code)
				                                                )
								            AND catalog_seq_id    =    v_cat_seq_id
								            AND (repair_end_date IS NULL OR repair_end_date > SYSDATE);                                              
								
								      ELSE--(p_in_price_type ='Increase')

										      UPDATE crd_e_Repair_catalog 
								      		SET future_price = repair_price - (repair_price * p_in_price_value)/100,
								            	 future_effective_date=v_eff_date
                                        /*
		                                  17 feb 2005
		                                  */
		                                  ,last_update_date = SYSDATE
		                                  ,last_updated_by   = p_in_user_id 
		                                  /*
		                                  17 feb 2005
		                                  */
								            WHERE 
								                 REPAIR_SEQ_ID IN (
				                             							SELECT repair_seq_id 
				                                                FROM crd_e_repair 
				                                                WHERE module_seq_id=p_in_module_id 
								             								AND component_code=UPPER(p_in_component_code)
				                                                )
								             AND catalog_seq_id=v_cat_seq_id
								          	 AND (repair_end_date IS NULL OR repair_end_date > SYSDATE);                                              
								      END IF;-- (p_in_price_type ='Increase')
				                  
					 END IF;--(v_eff_date=TO_DATE(SYSDATE))
				 	p_out_message := 'PRICE_ADJUSTMENT_UPDATED';
               
   END IF;--(v_component_code IS NULL)
 	   
EXCEPTION
	WHEN 	
	   NUMERIC_OVERFLOW
   THEN
       p_out_message := 'NUMERIC_OVERFLOW';
	WHEN 	
	   VALUE_OVERFLOW
   THEN
       p_out_message := 'NUMERIC_OVERFLOW';              
   WHEN OTHERS
   THEN
      RAISE_APPLICATION_ERROR(-20001,'ERROR IN ecrd_maintenace_pkg.ecrd_save_price_adjust_prc' ||SQLCODE ||  ' - ' || SQLERRM);
	
END ecrd_save_price_adjust_prc;
--------------------------------------------------------------------

PROCEDURE ecrd_view_labor_rates_prc(p_out_labor_rates OUT retcur)
IS
BEGIN

	OPEN p_out_labor_rates 
   FOR
	SELECT	
   		cl.location_id,
			cl.location_desc,
			cl.location_labor_rate
 	FROM 	crd_location cl
   WHERE
   		cl.location_id <> 'ALL'
	    ORDER BY cl.location_desc;

EXCEPTION
   WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20001,
     'ERROR IN ecrd_maintenace_pkg.ecrd_view_labor_rates_prc' ||
       SQLCODE ||  ' - ' || SQLERRM);
END ecrd_view_labor_rates_prc;

--------------------------------------------------------------------
 
PROCEDURE ecrd_get_cycle_class_prc(p_out_cycle_class OUT retcur)
IS
BEGIN

-- To get all Cycle Classes and their corresponding Notification period
	OPEN p_out_cycle_class
   FOR
   	SELECT cycle_count_class,
				 notification_period_in_days
		FROM
				 crd_e_cycle_counting_type
		ORDER BY cycle_count_class;      
EXCEPTION
   WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20001,
     'ERROR IN ecrd_maintenace_pkg.ecrd_get_cycle_class_prc' ||
       SQLCODE ||  ' - ' || SQLERRM);
END ecrd_get_cycle_class_prc;

--------------------------------------------------------------------


PROCEDURE ecrd_save_notify_period_prc
(
   p_in_user_id IN crd_crc_user.userid%TYPE,
	p_in_class_period_buff IN LONG,
   p_out_cycle_class OUT retcur,
	p_out_message OUT VARCHAR2
)
IS
   tab_broken_cols ecrd_utils_pkg.gtyp_buf_arr;
   tab_broken_rows ecrd_utils_pkg.gtyp_buf_arr;
   v_count NUMBER :=0;
   v_row_count NUMBER :=0;
   v_details    VARCHAR2(2000)  := NULL;
BEGIN

-- Get the rows of Class and Notification Period 
	 ecrd_utils_pkg.break_into_rows_s_prc(
                                 p_in_class_period_buff,
                                 ecrd_utils_pkg.G_ROW_DELIM,
                                 tab_broken_rows);

	 v_row_count := tab_broken_rows.COUNT;

	 FOR v_index IN 1..v_row_count
    LOOP
			v_details := tab_broken_rows(v_index);

	-- Get Class and Notification Period Separately		

      	ecrd_utils_pkg.break_into_cols_s_prc(
                                 v_details,
                                 ecrd_utils_pkg.G_COL_DELIM,
                                 tab_broken_cols);


	-- Update That Class -  Set Notification Period to changed value 

		UPDATE crd_e_cycle_counting_type
		SET
			notification_period_in_days = to_number(tab_broken_cols(2)),
		   last_updated_by=p_in_user_id,
		   last_update_date = SYSDATE
		WHERE
			cycle_count_class = tab_broken_cols(1);
		COMMIT;				  			
  	 END LOOP;
    p_out_message := 'CLASS_NOTIFICATION_PERIOD_UPDATED';
    
    ecrd_get_cycle_class_prc(p_out_cycle_class);

EXCEPTION
WHEN OTHERS THEN
   p_out_message := '';
   ROLLBACK;
   RAISE_APPLICATION_ERROR(-20020,'Error in  ecrd_maintenace_pkg.ecrd_save_notify_period_prc**'||SQLCODE||SQLERRM);
   
END ecrd_save_notify_period_prc;
----------------------------------------------------------------------
PROCEDURE ecrd_save_labor_rates_prc
(
   p_in_user_id IN crd_crc_user.userid%TYPE,
	p_in_site_labor_rate_buff IN LONG,
	p_out_labor_rate OUT retcur,
   p_out_message OUT VARCHAR2
)

IS
   tab_broken_cols ecrd_utils_pkg.gtyp_buf_arr;
   tab_broken_rows ecrd_utils_pkg.gtyp_buf_arr;
   v_count NUMBER :=0;
   v_row_count NUMBER :=0;
   v_details    VARCHAR2(2000)  := NULL;
BEGIN

-- Get the rows of Site and Labor Rate
	 ecrd_utils_pkg.break_into_rows_s_prc(
                                 p_in_site_labor_rate_buff,
                                 ecrd_utils_pkg.G_ROW_DELIM,
                                 tab_broken_rows);

	 v_row_count := tab_broken_rows.COUNT;

	 FOR v_index IN 1..v_row_count
    LOOP
			v_details := tab_broken_rows(v_index);

	-- Get SiteId and Labor Rate Separately		

      	ecrd_utils_pkg.break_into_cols_s_prc(
                                 v_details,
                                 ecrd_utils_pkg.G_COL_DELIM,
                                 tab_broken_cols);


	-- Update That Site -  Set Labor Rate to changed value 

		UPDATE crd_location
      SET
			location_labor_rate = to_number(tab_broken_cols(2)),
		   last_updated_by=p_in_user_id,
		   last_update_date = SYSDATE
		WHERE
			location_id = tab_broken_cols(1);
		COMMIT;				  			
  	 END LOOP;
    p_out_message := 'LABOR_RATE_UPDATED';

    ecrd_view_labor_rates_prc(p_out_labor_rate);
	
EXCEPTION
WHEN OTHERS THEN
   p_out_message := '';
   ROLLBACK;
   RAISE_APPLICATION_ERROR(-20020,'Error in  ecrd_maintenace_pkg.ecrd_save_notify_period_prc**'||SQLCODE||SQLERRM);
   
END ecrd_save_labor_rates_prc;

----------------------------------------------------------------------
END ecrd_maintenace_pkg;
/




