CREATE OR REPLACE PACKAGE ecrd_manageUser_pkg AS
--
/***********************************************************************/
--
-- Copyright Message : Copyright(c) 2004 GE Aircraft Engines
-- Title                   : ecrd_manageUser_pkg
-- Author               : Patni Offshore
-- Company           : GE Aircraft Engines
-- Date                  : October 2004
-- Purpose             : File contains Package Spec and body for Procs
--                            for User Data Management
--
-- Modifications      :
--    Date                   Description
-- [DD-MMM-YYYY]       A brief description of change should go here like
--                              who had made change, why change was implemented
--                              and where change is made.
--
-- 28-may-2004         New Code First Version
--
/***********************************************************************/
--
/***********************************************************************/
--
-- Package Name    : ecrd_manageUser_pkg
-- Purpose              : To get dropdown data for common utilities.
-- Procedures/Functions :
--                        PROCEDURE ecrd_load_user_prc
--                        PROCEDURE ecrd_create_user_prc
--                        PROCEDURE ecrd_remove_user_prc
--			  PROCEDURE ecrd_update_user_prc
--			  PROCEDURE ecrd_update_user_prc
/***********************************************************************/
--
TYPE result_cursor IS REF CURSOR;
--
--
--
/***********************************************************************/
-- Procedure Name                : ecrd_load_user_prc
-- Purpose                       : This procedure is used to get User Details 
-- Input Parameters              : p_in_UserId 	crd_user.user_id%TYPE
-- Output Parameters             : p_out_FirstName crd_user.user_first_name%TYPE
-- Output Parameters             : p_out_LastName crd_user.user_last_name%TYPE
-- Output Parameters             : p_out_EMailId crd_user.user_EmailId%TYPE
-- Output Parameters             : p_out_Status crd_user.user_status%TYPE
-- Output Parameters             : p_out_Role crd_user.role_code%TYPE
-- Output Parameters             : p_out_SiteCode location_code%TYPE
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_load_user_prc(p_in_UserId IN crd_crc_user.userid%TYPE,
    				p_out_FirstName OUT crd_crc_user.first_name%TYPE,
    				p_out_LastName OUT crd_crc_user.last_name%TYPE,
    				p_out_EMailId OUT crd_crc_user.Email_Address%TYPE,
    				p_out_Status OUT crd_crc_user.ACTIVE_IND%TYPE,
    				p_out_Role OUT crd_crc_user.USER_ROLE%TYPE,
    				p_out_SiteCode OUT crd_crc_user.location_id%TYPE,
					p_out_SiteDescription OUT crd_location.SITE_NAME%TYPE);


/***********************************************************************/
-- Procedure Name                : ecrd_create_user_prc
-- Purpose                       : This procedure is used to get User Details 
-- Input Parameters              : p_in_UserId 	crd_user.user_id%TYPE
-- Input Parameters             : p_out_FirstName crd_user.user_first_name%TYPE
-- Input Parameters             : p_out_LastName crd_user.user_last_name%TYPE
-- Input Parameters             : p_out_EMailId crd_user.user_EmailId%TYPE
-- Input Parameters             : p_out_Status crd_user.user_status%TYPE
-- Input Parameters             : p_out_Role crd_user.role_code%TYPE
-- Input Parameters             : p_out_SiteCode location_code%TYPE
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_create_user_prc(p_in_UserId IN crd_crc_user.USERID%TYPE,
    				p_in_FirstName IN crd_crc_user.FIRST_NAME%TYPE,
    				p_in_LastName IN crd_crc_user.LAST_NAME%TYPE,
    				p_in_EMailId IN crd_crc_user.Email_Address%TYPE,
    				p_in_Status IN crd_crc_user.ACTIVE_IND%TYPE,
    				p_in_Role IN crd_crc_user.USER_ROLE%TYPE,
    				p_in_SiteCode IN crd_crc_user.LOCATION_ID%TYPE,
					p_in_created_by IN crd_crc_user.USERID%TYPE,
					p_in_created_by_role IN crd_crc_user.USER_ROLE%TYPE,
					p_out_success OUT varchar
					); 		
--
--
--

/***********************************************************************/
-- Procedure Name                : ecrd_update_user_prc
-- Purpose                       : This procedure is used to update User Details 
-- Input Parameters              : p_in_UserId 	crd_user.user_id%TYPE
-- Input Parameters             : p_out_FirstName crd_user.user_first_name%TYPE
-- Input Parameters             : p_out_LastName crd_user.user_last_name%TYPE
-- Input Parameters             : p_out_EMailId crd_user.user_EmailId%TYPE
-- Input Parameters             : p_out_Status crd_user.user_status%TYPE
-- Input Parameters             : p_out_Role crd_user.role_code%TYPE
-- Input Parameters             : p_out_SiteCode location_code%TYPE
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_update_user_prc(p_in_UserId IN crd_crc_user.USERID%TYPE,
    				p_in_FirstName IN crd_crc_user.first_name%TYPE,
    				p_in_LastName IN crd_crc_user.last_name%TYPE,
    				p_in_EMailId IN crd_crc_user.Email_Address%TYPE,
    				p_in_Status IN crd_crc_user.ACTIVE_IND%TYPE,
    				p_in_Role IN crd_crc_user.USER_ROLE%TYPE,
    				p_in_SiteCode IN crd_crc_user.LOCATION_ID%TYPE,
					p_in_updated_by IN crd_crc_user.userid%TYPE,
					p_in_updated_by_role IN crd_crc_user.USER_ROLE%TYPE,
					p_out_success OUT varchar
					);
/***********************************************************************/
-- Procedure Name                : ecrd_list_user_prc
-- Purpose                       : This procedure is used to list User Details 
-- Input Parameters              : p_in_fname	crd_user.user_first_name%TYPE
-- Input Parameters             : p_in_lname crd_user.user_first_name%TYPE
-- Input Parameters             : p_in_role  crd_user_role.role_name%TYPE
-- Input Parameters             : p_in_site IN crd_site.location_name%TYPE
-- Output Parameters             : p_out_list_ver_cur OUT result_cursor

-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/
PROCEDURE ecrd_list_user_prc(p_in_fname IN crd_crc_user.first_name%TYPE,
   			     			 p_in_lname IN crd_crc_user.last_name%TYPE,
			     			 p_in_role IN crd_crc_user.user_role%TYPE,
			     			 p_in_site IN crd_location.site_name%TYPE,
				 			 p_in_userid IN crd_crc_user.USERID%TYPE,
							 p_in_loginrole IN crd_crc_user.USER_ROLE%TYPE,
							 p_in_sitecode IN crd_location.LOCATION_ID%TYPE,
			     			 p_out_list_ver_cur OUT result_cursor);
/***********************************************************************/

PROCEDURE ecrd_search_user_details_prc(p_in_userid IN crd_crc_user.USERID%TYPE,
		  								p_out_search_user_cur OUT result_cursor);
--
--
--
/***********************************************************************/
-- Procedure Name                : ecrd_email_groups_prc
-- Purpose                       : This procedure is used to list all Email Groups   
-- Output Parameters             : p_out_groups_cur OUT result_cursor

-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_email_groups_prc(p_out_groups_cur OUT result_cursor);


/***********************************************************************/
-- Procedure Name                : ecrd_insert_group_prc
-- Purpose                       : This procedure is used to insert New Email Group in the database 
-- Input Parameters              : p_in_groupname IN crd_e_email_group.EMAIL_GROUP_DESCRIPTION%TYPE,
-- Input Parameters             : p_in_lname crd_user.user_first_name%TYPE
-- Input Parameters             : p_in_loginuser IN crd_e_email_group.CREATED_BY%TYPE,
-- Output Parameters             : p_out_groupcode OUT varchar2
-- Output Parameters             : p_out_msg OUT VARCHAR2
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_insert_group_prc(p_in_groupname IN crd_e_email_group.EMAIL_GROUP_DESCRIPTION%TYPE,
		  								p_in_loginuser IN crd_e_email_group.CREATED_BY%TYPE,
										p_out_groupcode OUT varchar2,
                              p_out_msg OUT VARCHAR2);

                              
/***********************************************************************/
-- Procedure Name                : ecrd_group_search_email_prc
-- Purpose                       : This procedure is used to get all Email Addresses from the database 
-- Input Parameters              : p_in_firstname IN crd_crc_user.FIRST_NAME%TYPE
-- Input Parameters             : p_in_lastname IN crd_crc_user.LAST_NAME%TYPE
-- Output Parameters             : p_out_search_email_cur OUT result_cursor

-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/
                              
PROCEDURE ecrd_group_search_email_prc(p_in_firstname IN crd_crc_user.FIRST_NAME%TYPE,
									           p_in_lastname IN crd_crc_user.LAST_NAME%TYPE,
									           p_out_search_email_cur OUT result_cursor);




/***********************************************************************/
-- Procedure Name                : ecrd_add_email_in_group_prc
-- Purpose                       : This procedure add a particular Email Addresses into a Group 
-- Input Parameters              : p_in_groupcode IN crd_e_email_group_users.EMAIL_GROUP_CODE%TYPE,
-- Input Parameters             : p_in_emailaddress IN crd_e_email_group_users.EMAIL_ADDRESS%TYPE,
-- Input Parameters             : p_in_userid IN crd_e_email_group_users.CREATED_BY%TYPE,
-- Output Parameters             : p_out_groups_address_cur OUT result_cursor
-- Output Parameters             : p_out_msg OUT VARCHAR2
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_add_email_in_group_prc(p_in_groupcode IN crd_e_email_group_users.EMAIL_GROUP_CODE%TYPE,
			  									p_in_emailaddress IN crd_e_email_group_users.EMAIL_ADDRESS%TYPE,			
												p_in_userid IN crd_e_email_group_users.CREATED_BY%TYPE,
      	                           p_out_groups_address_cur OUT result_cursor,
                                    p_out_msg OUT VARCHAR2);


/***********************************************************************/
-- Procedure Name                : ecrd_delete_group_email_prc
-- Purpose                       : This procedure delete a particular Email Addresses into a Group 
-- Input Parameters              : p_in_groupcode IN crd_e_email_group_users.EMAIL_GROUP_CODE%TYPE,
-- Input Parameters             : p_in_emailaddress IN crd_e_email_group_users.EMAIL_ADDRESS%TYPE,
-- Output Parameters             : p_out_groups_address_cur OUT result_cursor
-- Output Parameters             : p_out_msg OUT VARCHAR2
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_delete_group_email_prc(p_in_groupcode IN crd_e_email_group_users.EMAIL_GROUP_CODE%TYPE,
					  								p_in_emailaddress IN crd_e_email_group_users.EMAIL_ADDRESS%TYPE,
                                       p_out_groups_address_cur OUT result_cursor,
                                       p_out_msg OUT VARCHAR2);


/***********************************************************************/
-- Procedure Name                : ecrd_list_email_prc
-- Purpose                       : This procedure is called to lists all Email Addresses in a Group 
-- Input Parameters              : p_in_groupcode IN crd_e_email_group_users.EMAIL_GROUP_CODE%TYPE,
-- Output Parameters             : p_out_groups_address_cur OUT result_cursor

-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_list_email_prc(p_in_groupcode IN crd_e_email_group_users.EMAIL_GROUP_CODE%TYPE,
		  							  p_out_groups_address_cur OUT result_cursor);


/***********************************************************************/
-- Procedure Name                : ecrd_event_list_prc
-- Purpose                       : This procedure is called to lists all Events in the data base 
-- Output Parameters             : p_out_groups_address_cur OUT result_cursor

-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/
                             
PROCEDURE ecrd_event_list_prc(p_out_event_list OUT result_cursor);


/***********************************************************************/
-- Procedure Name                : ecrd_related_events_prc
-- Purpose                       : This procedure is called get all the Events associated  to a particular group
-- Input Parameters              : p_in_group_code IN crd_e_email_group.EMAIL_GROUP_CODE%TYPE,
-- Output Parameters             : p_out_groups_address_cur OUT result_cursor

-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_related_events_prc(p_in_group_code IN crd_e_email_group.EMAIL_GROUP_CODE%TYPE,
														  p_out_events_cur OUT result_cursor);



/***********************************************************************/
-- Procedure Name                : ecrd_attach_event_group_prc
-- Purpose                       : This procedure is called update the Events associated  to a particular group
-- Input Parameters              : p_in_group_code IN crd_e_email_group.EMAIL_GROUP_CODE%TYPE
-- Input Parameters              : p_in_event_code IN VARCHAR2
-- Input Parameters              : p_in_userid IN crd_e_email_group_users.CREATED_BY%TYPE,
-- Output Parameters             : p_out_msg OUT VARCHAR2

-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_attach_event_group_prc(p_in_group_code IN crd_e_email_group.EMAIL_GROUP_CODE%TYPE,
													p_in_event_code IN VARCHAR2,
                                       p_in_userid IN crd_e_email_group_users.CREATED_BY%TYPE,
                                       p_out_msg OUT VARCHAR2);


/***********************************************************************/
-- Procedure Name                : ecrd_delete_grp_prc
-- Purpose                       : This procedure is called delete a particular group
-- Input Parameters              : p_in_group_code IN crd_e_email_group.EMAIL_GROUP_CODE%TYPE
-- Output Parameters             : p_out_groups_cur OUT result_cursor
-- Output Parameters             : p_out_msg OUT VARCHAR2

-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_delete_grp_prc(p_in_groupcode IN crd_e_email_group_users.EMAIL_GROUP_CODE%TYPE,			
      	                           p_out_groups_cur OUT result_cursor,
                                    p_out_msg OUT VARCHAR2);

                              
END ecrd_manageUser_pkg;
/

CREATE OR REPLACE PACKAGE BODY ecrd_manageUser_pkg AS
--
--**********************************************************************
/***********************************************************************/
PROCEDURE ecrd_load_user_prc(p_in_UserId IN crd_crc_user.userid%TYPE,
    				p_out_FirstName OUT crd_crc_user.first_name%TYPE,
    				p_out_LastName OUT crd_crc_user.last_name%TYPE,
    				p_out_EMailId OUT crd_crc_user.Email_Address%TYPE,
    				p_out_Status OUT crd_crc_user.ACTIVE_IND%TYPE,
    				p_out_Role OUT crd_crc_user.USER_ROLE%TYPE,
    				p_out_SiteCode OUT crd_crc_user.location_id%TYPE,
					p_out_SiteDescription OUT crd_location.SITE_NAME%TYPE)
--
IS
		
BEGIN
	  -- Retrive user details from the database 	  

	SELECT 			 usr.first_name
	   	    		 ,usr.last_name
	   	    		 ,usr.email_address
	   	    		 ,usr.ACTIVE_IND
	   	    		 ,usr.user_role
	   	    		 ,usr.location_id
					 ,cs.site_name					 
	INTO		
				 p_out_FirstName 
				,p_out_LastName 
				,p_out_EMailId 
				,p_out_Status 
				,p_out_Role 
				,p_out_SiteCode 
				,p_out_SiteDescription 
		 	
 	FROM 	 crd_crc_user usr, 
			 crd_location cs	
	WHERE
		 UPPER(usr.userid) = UPPER(p_in_UserId)
		 and usr.location_id = cs.location_id;	 
	 

EXCEPTION
   WHEN NO_DATA_FOUND
   THEN
   	     p_out_FirstName := '';
		 p_out_LastName := '';
		 p_out_EMailId := '';
		 p_out_Status := '';
		 p_out_Role := '';
		 p_out_SiteCode := '';
		 p_out_SiteDescription := '';
		 
   WHEN OTHERS 
   THEN
      RAISE_APPLICATION_ERROR(-20001,
     'ERROR IN ecrd_manageUser_pkg.ecrd_load_user_prc' ||
       SQLCODE ||  ' - ' || SQLERRM);
END ecrd_load_user_prc;
--

--
--**********************************************************************--

PROCEDURE ecrd_create_user_prc(p_in_UserId IN crd_crc_user.USERID%TYPE,
    				p_in_FirstName IN crd_crc_user.FIRST_NAME%TYPE,
    				p_in_LastName IN crd_crc_user.LAST_NAME%TYPE,
    				p_in_EMailId IN crd_crc_user.Email_Address%TYPE,
    				p_in_Status IN crd_crc_user.ACTIVE_IND%TYPE,
    				p_in_Role IN crd_crc_user.USER_ROLE%TYPE,
    				p_in_SiteCode IN crd_crc_user.LOCATION_ID%TYPE,
					p_in_created_by IN crd_crc_user.USERID%TYPE,
					p_in_created_by_role IN crd_crc_user.USER_ROLE%TYPE,
					p_out_success OUT VARCHAR
					)  		
--
IS
BEGIN
	-- Create user details into the database 
	Insert into crd_crc_user 
	(
		userid,
		first_name,
		last_name,
		Email_Address,
		ACTIVE_IND,
		USER_ROLE,
		LOCATION_ID,
		created_by,
		creation_date,
		last_updated_by,
		last_update_date,
		catalog_ind
	)
	VALUES 
	(
    UPPER(p_in_UserId)
   ,p_in_FirstName
   ,p_in_LastName
   ,p_in_EMailId
   ,p_in_Status
   ,p_in_Role
   ,p_in_SiteCode
   ,p_in_created_by
   ,SYSDATE
   ,p_in_created_by
   ,SYSDATE
   ,'C');
	--
	p_out_success := 'USER_SUCESSFULLY_CREATED';
	COMMIT;

EXCEPTION
	WHEN DUP_VAL_ON_INDEX THEN
        ROLLBACK;
		p_out_success := 'USER_ALREADY_EXISTS';
   WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20001,
     'ERROR IN ecrd_manageUser_pkg.ecrd_create_user_prc' ||
       SQLCODE ||  ' - ' || SQLERRM);
END ecrd_create_user_prc;


PROCEDURE ecrd_update_user_prc(p_in_UserId IN crd_crc_user.USERID%TYPE,
    				p_in_FirstName IN crd_crc_user.first_name%TYPE,
    				p_in_LastName IN crd_crc_user.last_name%TYPE,
    				p_in_EMailId IN crd_crc_user.Email_Address%TYPE,
    				p_in_Status IN crd_crc_user.ACTIVE_IND%TYPE,
    				p_in_Role IN crd_crc_user.USER_ROLE%TYPE,
    				p_in_SiteCode IN crd_crc_user.LOCATION_ID%TYPE,
					p_in_updated_by IN crd_crc_user.userid%TYPE,
					p_in_updated_by_role IN crd_crc_user.USER_ROLE%TYPE,
					p_out_success OUT VARCHAR
					)
IS
BEGIN

 	-- Update user details into the database
	 IF p_in_UserId IS NOT NULL  
	 THEN
			UPDATE crd_crc_user
			SET 		
				first_name = p_in_FirstName,
				last_name = p_in_LastName,
				Email_Address = p_in_EMailId,
				ACTIVE_IND = p_in_Status,
				USER_ROLE = p_in_Role,
				LOCATION_ID = p_in_SiteCode ,
				last_updated_by = p_in_updated_by,
				created_by=p_in_updated_by_role,
				last_update_date = sysdate 
			WHERE
				  UPPER(userid) = UPPER(p_in_UserId);
			COMMIT;	 
			p_out_success := 'USER_SUCESSFULLY_UPDATED';
		 END IF;	  


EXCEPTION
WHEN DUP_VAL_ON_INDEX THEN
        ROLLBACK;
		p_out_success := 'USER_ALREADY_EXISTS';
   WHEN OTHERS THEN
   	  ROLLBACK;	
      RAISE_APPLICATION_ERROR(-20001,
     'ERROR IN ecrd_manageUser_pkg.ecrd_update_user_prc' ||
       SQLCODE ||  ' - ' || SQLERRM);
END ecrd_update_user_prc;

--**********************************************************************--
--
--**********************************************************************--
PROCEDURE ecrd_list_user_prc(p_in_fname IN crd_crc_user.first_name%TYPE,
   			     			 p_in_lname IN crd_crc_user.last_name%TYPE,
			     			 p_in_role IN crd_crc_user.user_role%TYPE,
			     			 p_in_site IN crd_location.SITE_NAME%TYPE,
				 			 p_in_userid IN crd_crc_user.USERID%TYPE,
							 p_in_loginrole IN crd_crc_user.USER_ROLE%TYPE,
							 p_in_sitecode IN crd_location.LOCATION_ID%TYPE,
			     			 p_out_list_ver_cur OUT result_cursor)
IS
v_main_query varchar(500):='';
v_where_query varchar(500):='';
BEGIN
v_main_query :='SELECT  cru.userid,
			 	 			   cru.first_name,
				 			   cru.last_name,
				 			   cru.user_role,
				 			   cl.site_name,
				 			   DECODE(cru.ACTIVE_IND,'''||ecrd_utils_pkg.G_USER_ACTIVE ||''',''Active'','''||ecrd_utils_pkg.G_USER_INACTIVE ||''',''InActive''),
				 			   cru.email_address,
				 			   cl.location_id
				 			   
				 FROM  	 	   crd_crc_user cru,
	        	 			   crd_location cl
		         WHERE         cl.location_id= cru.location_id';
		                   
				 
  IF p_in_loginrole=ecrd_utils_pkg.G_TC
  THEN
  v_where_query:=v_where_query||' AND cru.LOCATION_ID='''||p_in_sitecode|| '''AND cru.user_role<>'||''''||ecrd_utils_pkg.G_ADMIN||'''';
  END IF;
  IF p_in_fname IS NOT NULL
  THEN
      v_where_query:=v_where_query||' AND UPPER(cru.first_name) LIKE UPPER('''||'%'||p_in_fname||'%'||'''  )';
  END IF;
  
  IF p_in_lname IS NOT NULL
  THEN
      v_where_query:=v_where_query||' AND UPPER(cru.last_name) LIKE UPPER('''||'%'||p_in_lname||'%'||'''  )';
  END IF;
    
  IF p_in_role IS NOT NULL
  THEN
      v_where_query:=v_where_query||' AND (cru.user_role)='''||p_in_role||'''  ';
  END IF; 
  IF p_in_site IS NOT NULL
  THEN
      v_where_query:=v_where_query||' AND UPPER(cl.location_id)='''||p_in_site||'''  ';
  END IF;
  
   --
   OPEN p_out_list_ver_cur
   FOR v_main_query||v_where_query;
  --INSERT into deepa_test values('error msg',v_main_query||v_where_query);
   --   
   EXCEPTION
   WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20001,
   'ERROR IN ecrd_manageUser_pkg.ecrd_list_user_prc. :' ||v_main_query||v_where_query||':'
   ||SQLCODE ||  ' - ' || SQLERRM);
END ecrd_list_user_prc;
--**********************************************************************--
--
--**********************************************************************--
PROCEDURE ecrd_search_user_details_prc(p_in_userid IN crd_crc_user.USERID%TYPE,
	  								p_out_search_user_cur OUT result_cursor)
IS
BEGIN
 OPEN p_out_search_user_cur
   FOR
   -- Retrive list of sites from the database
	 Select cu.location_id,
	 		cu.user_role,
			cu.ACTIVE_IND
	 from 	crd_crc_user cu
	 WHERE  UPPER(cu.USERID)=UPPER(p_in_userid);
	EXCEPTION
   WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(-20051,
     'NO_USER_FOUND ERROR IN ecrd_manageUser_pkg.ecrd_search_user_details_prc' ||
       SQLCODE ||  ' - ' || SQLERRM);
   WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20001,
     'ERROR IN ecrd_manageUser_pkg.ecrd_search_user_details_prc' ||
       SQLCODE ||  ' - ' || SQLERRM);
										
END ecrd_search_user_details_prc;


PROCEDURE ecrd_email_groups_prc(p_out_groups_cur OUT result_cursor)
IS
BEGIN
		OPEN p_out_groups_cur
		FOR
		SELECT email_group_code,email_group_description
		FROM crd_e_email_group;
		EXCEPTION WHEN OTHERS THEN
		RAISE_APPLICATION_ERROR(-20002,'ERROR IN ecrd_manageUser_pkg.ecrd_email_groups_prc' ||SQLCODE ||  ' - ' || SQLERRM);
END ecrd_email_groups_prc;


PROCEDURE ecrd_insert_group_prc(p_in_groupname IN crd_e_email_group.EMAIL_GROUP_DESCRIPTION%TYPE,
			  								p_in_loginuser IN crd_e_email_group.CREATED_BY%TYPE,
											p_out_groupcode OUT VARCHAR2,
                                 p_out_msg OUT VARCHAR2)
IS
v_out_groupcode VARCHAR2(50):=NULL;
    v_count      NUMBER :=0; 
BEGIN

		SELECT count(rowid) 
      INTO v_count
      FROM crd_e_email_group 
      WHERE UPPER(email_group_description) = UPPER(p_in_groupname);
      

	      IF v_count = 0
         THEN
					SELECT crd_e_email_group_seq.NEXTVAL 
               INTO v_out_groupcode 
               FROM dual;
					INSERT INTO crd_e_email_group
					
						   						 (
												 email_group_code,
												 email_group_description,
												 created_by,
												 creation_date,
												 last_update_date,
												 last_updated_by
												 )
												 VALUES
												 (
												  v_out_groupcode,
												 p_in_groupname,
												 p_in_loginuser,
												 SYSDATE,
												 SYSDATE,
												 p_in_loginuser
												 );
					                      
									p_out_groupcode := v_out_groupcode;
                           p_out_msg := 'GROUP_CREATED_SUCCESSFULLY';
			ELSE
			             p_out_msg := 'GROUP_ALREADY_EXISTS';
         END IF;                                                
EXCEPTION 
   WHEN OTHERS THEN
   	  ROLLBACK;	
      RAISE_APPLICATION_ERROR(-20001,'ERROR IN ecrd_manageUser_pkg.ecrd_insert_group_prc' ||SQLCODE ||  ' - ' || SQLERRM);
END ecrd_insert_group_prc;


PROCEDURE ecrd_group_search_email_prc(p_in_firstname IN crd_crc_user.FIRST_NAME%TYPE,
           p_in_lastname IN crd_crc_user.LAST_NAME%TYPE,
           p_out_search_email_cur OUT result_cursor)
IS
BEGIN

			OPEN p_out_search_email_cur
			FOR
			SELECT      cru.first_name,
			            cru.last_name,
          			   cru.email_address
	      FROM        crd_crc_user cru
         WHERE
    	   UPPER(cru.first_name)=UPPER(p_in_firstname)
	   	OR
		   UPPER(cru.last_name)=UPPER(p_in_lastname);
   	  EXCEPTION
		  WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(-20001,'ERROR IN ecrd_manageUser_pkg.ecrd_group_search_email_prc' ||SQLCODE ||  ' - ' || SQLERRM);
END ecrd_group_search_email_prc;



PROCEDURE ecrd_add_email_in_group_prc(p_in_groupcode IN crd_e_email_group_users.EMAIL_GROUP_CODE%TYPE,
		  									p_in_emailaddress IN crd_e_email_group_users.EMAIL_ADDRESS%TYPE,			
											p_in_userid IN crd_e_email_group_users.CREATED_BY%TYPE,
                                 p_out_groups_address_cur OUT result_cursor,
                                 p_out_msg OUT VARCHAR2
                                 )
                                 
IS
    v_count      NUMBER :=0;
BEGIN
--IF p_in_groupcode==null
--THEN 
--p_in_groupcode=(select max(email_group_code) from crd_e_email_group)

		SELECT count(rowid) 
      INTO v_count
      FROM crd_e_email_group_users 
      WHERE email_group_code = p_in_groupcode
      AND email_address = p_in_emailaddress;
      
      IF v_count = 0
      THEN
					INSERT INTO crd_e_email_group_users
			   							   	(
														 email_group_code,
														 email_address,
														 created_by,
														 creation_date,
														 last_update_date,
														 last_updated_by
														 )
														VALUES
														(
														p_in_groupcode,
														p_in_emailaddress,
														p_in_userid,
														SYSDATE,
														SYSDATE,
														p_in_userid
														);
					                           
						OPEN p_out_groups_address_cur 
						FOR
						SELECT email_address from crd_e_email_group_users
						WHERE email_group_code=p_in_groupcode;
		            
		            p_out_msg := 'EMAIL_SAVED_SUCCESSFULLY';
		ELSE
      				OPEN p_out_groups_address_cur 
						FOR
						SELECT email_address from crd_e_email_group_users
						WHERE email_group_code=p_in_groupcode;
		      
                  p_out_msg := 'EMAIL_ALREADY_EXISTS';      
      END IF;      
				            
EXCEPTION 
  WHEN OTHERS THEN
  ROLLBACK;	
  RAISE_APPLICATION_ERROR(-20001,'ERROR IN ecrd_manageUser_pkg.ecrd_add_email_in_group_prc' ||SQLCODE ||  ' - ' || SQLERRM);
                   
END ecrd_add_email_in_group_prc;


PROCEDURE ecrd_delete_group_email_prc(p_in_groupcode IN crd_e_email_group_users.EMAIL_GROUP_CODE%TYPE,
					  								p_in_emailaddress IN crd_e_email_group_users.EMAIL_ADDRESS%TYPE,
                                       p_out_groups_address_cur OUT result_cursor,
                                       p_out_msg OUT VARCHAR2
                                       )
IS
BEGIN
				DELETE FROM crd_e_email_group_users
				WHERE UPPER(email_group_code)=UPPER(p_in_groupcode)
				AND UPPER(email_address)=UPPER(p_in_emailaddress);
            
				OPEN p_out_groups_address_cur 
				FOR
				SELECT email_address from crd_e_email_group_users
				WHERE email_group_code=p_in_groupcode;
            
             p_out_msg := 'EMAIL_DELETED_SUCCESSFULLY';

  EXCEPTION 
  WHEN OTHERS THEN
  ROLLBACK;	
  RAISE_APPLICATION_ERROR(-20001,'ERROR IN ecrd_manageUser_pkg.ecrd_delete_group_email_prc' ||SQLCODE ||  ' - ' || SQLERRM);

END ecrd_delete_group_email_prc;

PROCEDURE ecrd_list_email_prc(p_in_groupcode IN crd_e_email_group_users.EMAIL_GROUP_CODE%TYPE,
		  							  p_out_groups_address_cur OUT result_cursor)
IS
BEGIN
				OPEN p_out_groups_address_cur 
				FOR
				SELECT email_address
            FROM crd_e_email_group_users
				WHERE email_group_code=p_in_groupcode;
  EXCEPTION 
  WHEN NO_DATA_FOUND THEN	
  RAISE_APPLICATION_ERROR(-20001,'ERROR IN ecrd_manageUser_pkg.ecrd_list_email_prc' ||SQLCODE ||  ' - ' || SQLERRM);
END ecrd_list_email_prc;


PROCEDURE ecrd_event_list_prc(p_out_event_list OUT result_cursor)
IS 
BEGIN
		OPEN p_out_event_list
		FOR
		SELECT event_code,event_description 
		FROM crd_e_event;
  EXCEPTION 
  WHEN NO_DATA_FOUND THEN	
  RAISE_APPLICATION_ERROR(-20001,'ERROR IN ecrd_manageUser_pkg.ecrd_event_list_prc' ||SQLCODE ||  ' - ' || SQLERRM);
      
END ecrd_event_list_prc;

PROCEDURE ecrd_related_events_prc(p_in_group_code IN crd_e_email_group.EMAIL_GROUP_CODE%TYPE,
														  p_out_events_cur OUT result_cursor)
IS 
BEGIN
		OPEN p_out_events_cur
      FOR
		SELECT event_code 
      FROM crd_e_event_email_rel
      WHERE email_group_code = p_in_group_code;
      
  EXCEPTION 
  WHEN NO_DATA_FOUND THEN	
  RAISE_APPLICATION_ERROR(-20001,'ERROR IN ecrd_manageUser_pkg.ecrd_related_events_prc' ||SQLCODE ||  ' - ' || SQLERRM);
      
END ecrd_related_events_prc;                                                                                         

PROCEDURE ecrd_attach_event_group_prc(p_in_group_code IN crd_e_email_group.EMAIL_GROUP_CODE%TYPE,
													p_in_event_code IN VARCHAR2,
                                       p_in_userid IN crd_e_email_group_users.CREATED_BY%TYPE,
                                       p_out_msg OUT VARCHAR2)
IS 
tab_broken_column ecrd_utils_pkg.gtyp_buf_arr;
v_column_count NUMBER :=0;
v_index NUMBER :=0;
v_check NUMBER := 0;
v_test  varchar2(500) := '';
BEGIN
   		-- Breaking the Rows into Columns...
         
			DELETE FROM crd_e_event_email_rel 
			WHERE email_group_code=p_in_group_code;
         
		   ecrd_utils_pkg.break_into_cols_s_prc(p_in_event_code,ecrd_utils_pkg.G_COL_DELIM,tab_broken_column);
         v_column_count := tab_broken_column.COUNT;
         FOR v_index IN 1..v_column_count
         LOOP
/*           	SELECT COUNT(1) INTO v_check 
            FROM crd_e_event_email_rel
            WHERE event_code = tab_broken_column(v_index)
            AND   email_group_code = p_in_group_code ;
     
       
         	p_out_msg := v_test||ecrd_utils_pkg.G_COL_DELIM||p_out_msg ;

            IF v_check > 0
            THEN          
           
              		UPDATE crd_e_event_email_rel
                  SET   last_updated_by = p_in_userid,
                  		last_update_date = sysdate;
                                    
            ELSE*/
            		INSERT INTO crd_e_event_email_rel
         				(
                     	event_code,
                        email_group_code,
                        created_by,
                        creation_date,
                        last_updated_by,
                        last_update_date
                     )
         			VALUES 	      
         				(
                     	tab_broken_column(v_index),
                        p_in_group_code,
                        p_in_userid,
                        SYSDATE,
                        p_in_userid,
                        SYSDATE
                     );
--				END IF;
        END LOOP;
COMMIT;
p_out_msg := 'EVENT_ATTATCHED_TO_GROUP';

  EXCEPTION 
  WHEN OTHERS THEN
  ROLLBACK;	
  RAISE_APPLICATION_ERROR(-20001,'ERROR IN ecrd_manageUser_pkg.ecrd_attach_event_group_prc' ||SQLCODE ||  ' - ' || SQLERRM);

END ecrd_attach_event_group_prc;    


PROCEDURE ecrd_delete_grp_prc(p_in_groupcode IN crd_e_email_group_users.EMAIL_GROUP_CODE%TYPE,			
      	                           p_out_groups_cur OUT result_cursor,
                                    p_out_msg OUT VARCHAR2)
IS
BEGIN
		--
		DELETE FROM crd_e_event_email_rel 
		WHERE email_group_code=p_in_groupcode;
		COMMIT;
      --
		DELETE FROM crd_e_email_group_users 
		WHERE email_group_code=p_in_groupcode;
		COMMIT;
      --               
		DELETE FROM crd_e_email_group 
		WHERE email_group_code=p_in_groupcode;
		COMMIT;
		--      
		OPEN p_out_groups_cur
		FOR
		SELECT email_group_code,email_group_description
		FROM crd_e_email_group;            
      p_out_msg := 'GROUP_DELETED_SUCCESSFULLY';
  EXCEPTION 
  WHEN OTHERS THEN
  ROLLBACK;	
  RAISE_APPLICATION_ERROR(-20001,'ERROR IN ecrd_manageUser_pkg.ecrd_delete_grp_prc' ||SQLCODE ||  ' - ' || SQLERRM);

END ecrd_delete_grp_prc;                                    

END ecrd_manageUser_pkg;
/

