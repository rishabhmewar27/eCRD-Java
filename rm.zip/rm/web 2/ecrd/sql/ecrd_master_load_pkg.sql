CREATE OR REPLACE PACKAGE ecrd_master_load_pkg AS
--
/***********************************************************************/
--
-- Copyright Message : Copyright(c) 2004 GE Aircraft Engines
-- Title                   : ecrd_master_load_pkg
-- Author               : Patni Offshore
-- Company           : GE Aircraft Engines
-- Date                  : October 2004
-- Purpose             : File contains Package Spec and body for Procs
--                            for Master Data Load
--
-- Modifications      :
--    Date                   Description
-- [DD-MMM-YYYY]       A brief description of change should go here like
--                              who had made change, why change was implemented
--                              and where change is made.
--
-- 28-may-2004         New Code First Version
--
/***********************************************************************/
--
/***********************************************************************/
--
-- Package Name    : mrm_master_data_pkg
-- Purpose              : To get dropdown data for common utilities.
-- Procedures/Functions :
-- 						  PROCEDURE ecrd_list_engine_family_prc
--                        PROCEDURE ecrd_list_engine_model_prc
--                        PROCEDURE ecrd_master_module_list_prc
--                        PROCEDURE ecrd_list_component_prc
--			  PROCEDURE ecrd_list_repairs_prc
--			  PROCEDURE ecrd_list_customer_prc
/***********************************************************************/
--
TYPE retcur IS REF CURSOR;
--
--
--
/***********************************************************************/
-- Procedure Name                    :mecrd_list_engine_family_prc
-- Purpose                           : This procedure is used to get Engine Family Cursor
-- Input Parameters                  :None
-- Output Parameters                :Engine Family cursor .
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

/*PROCEDURE ecrd_list_engine_family_prc(
   p_out_engine_family_cur OUT retcur);

 */

--
--
--
/***********************************************************************/
-- Procedure Name                : ecrd_list_engine_model_prc
-- Purpose                       : This procedure is used to get Engine Model Cursor
-- Input Parameters              : None
-- Output Parameters             : Engine Model cursor .
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_list_engine_model_prc(
   p_out_engine_model_cur OUT retcur);
--
--
/***********************************************************************/
-- Procedure Name                : ecrd_list_module_prc
-- Purpose                       : This procedure is used to get Module Cursor for an Engine Model for default catalog
-- Input Parameters              : None
-- Output Parameters             : Module cursor .
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_master_module_list_prc(
		  						p_in_engine_model IN crd_crc_eng_mdl_display.eng_mdl_number%type,
   		  						p_out_module_cur OUT retcur);
--
--
/***********************************************************************/
-- Procedure Name                : ecrd_list_module_prc
-- Purpose                       : This procedure is used to get Module Cursor for an Engine Model for a specific catalog
-- Input Parameters              : None
-- Output Parameters             : Module cursor .
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_module_list_prc(
		  						p_in_catalog_seq_id IN CRD_E_CATALOG.CATALOG_SEQ_ID%TYPE,
  		  						p_out_module_cur OUT retcur);
--
--
/***********************************************************************/
-- Procedure Name                : ecrd_list_component_prc
-- Purpose                       : This procedure is used to get Coponent Cursor for a catalog, Engine Model and Module
-- Input Parameters              : None
-- Output Parameters             : Module cursor .
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_component_list_prc(p_in_catalog_seq_id VARCHAR2,
				p_in_module IN crd_crc_module.MODULE_SEQ_ID%TYPE,
   		  		p_out_component_cur OUT retcur);
--
--
/***********************************************************************/
-- Procedure Name                : ecrd_list_repair_prc
-- Purpose                       : This procedure is used to get Reapir Cursor for a catalog, Engine Model,Module  and component
-- Input Parameters              : None
-- Output Parameters             : Module cursor .
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_repair_list_prc(p_in_catalog_seq_id IN CRD_E_CATALOG.CATALOG_SEQ_ID%TYPE,
				p_in_module IN crd_crc_module.MODULE_SEQ_ID%TYPE,
   		  		p_in_component IN crd_e_component.COMPONENT_CODE%TYPE,
				p_out_repair_cur OUT retcur);
--
--
/***********************************************************************/
-- Procedure Name                : ecrd_list_role_prc
-- Purpose                       : This procedure is used to get User Role Cursor
-- Input Parameters              : None
-- Output Parameters             : Role Cursor.
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_list_role_prc(p_out_role_cur OUT retcur);
--
--
/***********************************************************************/
-- Procedure Name                : ecrd_list_site_prc
-- Purpose                       : This procedure is used to get Site Cursor
-- Input Parameters              : None
-- Output Parameters             : Site Cursor.
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_list_site_prc
(
   p_in_user_role IN crd_crc_user.USER_ROLE%type,
   p_in_userid IN crd_crc_user.USERID%type,
   p_out_site_cur OUT retcur
);

/***********************************************************************/
-- Procedure Name                : ecrd_list_site_without_all_prc
-- Purpose                       : This procedure is used to get Site Cursor
-- Input Parameters              : None
-- Output Parameters             : Site Cursor.
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/
PROCEDURE ecrd_list_site_without_all_prc
(
   p_in_user_role IN crd_crc_user.USER_ROLE%type,
   p_in_userid IN crd_crc_user.USERID%type,
   p_out_site_cur OUT retcur
);


--
--
--
/***********************************************************************/
-- Procedure Name                : ecrd_list_customer_prc
-- Purpose                       : This procedure is used to get Customer Cursor
-- Input Parameters              : None
-- Output Parameters             : Customer Cursor.
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_list_customer_prc(p_in_cust          IN  VARCHAR2
										  ,p_in_active        IN  VARCHAR2
										  ,p_out_customer_cur OUT retcur);
--
--
--
/*PROCEDURE ecrd_list_specify_role(p_in_loginrole IN crd_user_role.ROLE_CODE%TYPE,
p_out_rolelist_cur OUT retcur);
*/
PROCEDURE ecrd_list_cyc_class_prc(p_cyc_out OUT retcur);

PROCEDURE ecrd_customer_details_prc(p_in_customer_code IN crd_e_customer.customer_code%TYPE,
		  							 result_out OUT retcur);

PROCEDURE ecrd_list_site_for_cmp_prc(p_in_user_role   			IN  crd_crc_user.USER_ROLE%TYPE
												  ,p_in_userid     			IN  crd_crc_user.USERID%TYPE
                                      ,p_in_user_site   			IN  crd_crc_user.LOCATION_ID%TYPE
												  ,p_in_comp_code  			IN  crd_e_component.component_code%TYPE
												  ,p_in_mod_seq_id 			IN  crd_e_component.module_seq_id%TYPE
												  ,p_out_site_cur  			OUT retcur
                                      ,p_out_is_user_site_pend OUT VARCHAR2);
END ecrd_master_load_pkg;
/
CREATE OR REPLACE PACKAGE BODY ecrd_master_load_pkg AS

--

--**********************************************************************--
PROCEDURE ecrd_list_engine_model_prc(
   p_out_engine_model_cur OUT retcur
)
--
IS
BEGIN
   OPEN p_out_engine_model_cur
   FOR
	  -- Retrive list of engine models from the database
	  SELECT    cem.eng_mdl_number engine_model,
			  cem.ENG_MDL_DESC engine_model_description
	  FROM 	CRD_CRC_ENG_MDL_DISPLAY cem	   ORDER BY	    cem.ENG_MDL_DESC;
--
EXCEPTION
   WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(-20050,
     'NO_ENGINE_MODELS_FOUND ERROR IN ecrd_master_load_pkg.ecrd_list_engine_model_prc' ||
       SQLCODE ||  ' - ' || SQLERRM);
   WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20001,
     'ERROR IN ecrd_master_load_pkg.ecrd_list_engine_model_prc' ||
       SQLCODE ||  ' - ' || SQLERRM);
END ecrd_list_engine_model_prc;

--


PROCEDURE ecrd_master_module_list_prc(p_in_engine_model IN CRD_CRC_ENG_MDL_DISPLAY.ENG_MDL_NUMBER%type,
   		  							  p_out_module_cur OUT retcur)
--
IS
BEGIN
   OPEN p_out_module_cur
   FOR
	  -- Retrive list of Modules from the database
	  	 Select cm.module_seq_id module_seq_id, cm.module_name module_name
		 from CRD_CRC_MODULE cm
		 where
		 cm.eng_mdl_number = p_in_engine_model
		 ORDER BY	    cm.module_name;
--
EXCEPTION
   WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(-20051,
     'NO_MODULES_FOUND ERROR IN ecrd_master_load_pkg.ecrd_master_module_list_prc' ||
       SQLCODE ||  ' - ' || SQLERRM);
   WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20001,
     'ERROR IN ecrd_master_load_pkg.ecrd_master_module_list_prc' ||
       SQLCODE ||  ' - ' || SQLERRM);
END ecrd_master_module_list_prc;
--**********************************************************************--
--
--**********************************************************************--
--
PROCEDURE ecrd_module_list_prc(
		  						p_in_catalog_seq_id IN CRD_E_CATALOG.CATALOG_SEQ_ID%TYPE,
   		  						p_out_module_cur OUT retcur)
--
IS
BEGIN
   OPEN p_out_module_cur
   FOR
	  -- Retrive list of Modules from the database
		select distinct CM.MODULE_SEQ_ID,
					CM.MODULE_NAME
		from
			CRD_E_REPAIR_CATALOG CRC,
			CRD_E_REPAIR CR,
			CRD_CRC_MODULE CM
		where
			CRC.CATALOG_SEQ_ID = p_in_catalog_seq_id
			--and	 CR.ACTIVE_IND = ecrd_utils_pkg.G_ACTIVE
         and (cr.repair_end_date IS NULL OR cr.repair_end_date > SYSDATE)
			and	 CRC.REPAIR_SEQ_ID = CR.REPAIR_SEQ_ID
			and	 CR.MODULE_SEQ_ID = CM.MODULE_SEQ_ID;

--
EXCEPTION
   WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(-20051,
     'NO_MODULES_FOUND ERROR IN ecrd_master_load_pkg.ecrd_module_list_prc' ||
       SQLCODE ||  ' - ' || SQLERRM);
   WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20001,
     'ERROR IN ecrd_master_load_pkg.ecrd_module_list_prc' ||
       SQLCODE ||  ' - ' || SQLERRM);
END ecrd_module_list_prc;
--

--**********************************************************************--
--
--**********************************************************************--
--
/*
PROCEDURE ecrd_crc_module_list_prc(
		  						p_in_catalog_seq_id IN CRD_E_CATALOG.CATALOG_SEQ_ID%TYPE,
   		  						p_out_module_cur OUT retcur)
--
IS
BEGIN
   OPEN p_out_module_cur
   FOR
	  -- Retrive list of Modules from the database
		select distinct CM.MODULE_SEQ_ID,
					CM.MODULE_NAME
		from
			crd_e_repair_CATALOG CRC,
			crd_e_repair CR,
			crd_crc_module CM
		where
			CRC.CATALOG_SEQ_ID = p_in_catalog_seq_id
			and	 CR.ACTIVE_IND = 'Y'
			and	 CRC.REPAIR_SEQ_ID = CR.REPAIR_SEQ_ID
			and	 CR.MODULE_SEQ_ID = CM.MODULE_SEQ_ID;

--
EXCEPTION
   WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(-20051,
     'NO_MODULES_FOUND ERROR IN ecrd_master_load_pkg.ecrd_crc_module_list_prc' ||
       SQLCODE ||  ' - ' || SQLERRM);
   WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20001,
     'ERROR IN ecrd_master_load_pkg.ecrd_crc_module_list_prc' ||
       SQLCODE ||  ' - ' || SQLERRM);
END ecrd_crc_module_list_prc;
--
*/
--**********************************************************************--
--
--**********************************************************************--
--
PROCEDURE ecrd_component_list_prc(p_in_catalog_seq_id VARCHAR2,
				p_in_module IN crd_crc_module.MODULE_SEQ_ID%TYPE,
   		  		p_out_component_cur OUT retcur)
--
IS
BEGIN
   OPEN p_out_component_cur
   FOR
	  -- Retrive list of components from the database
		select distinct
			CCOM.COMPONENT_CODE,
			CCOM.COMPONENT_CODE||' : '||CCOM.COMPONENT_DESCRIPTION
		from
			 crd_e_repair_CATALOG CRC,
			 crd_e_repair CR,
			 crd_e_component CCOM
		where
			 CRC.CATALOG_SEQ_ID = TO_NUMBER(p_in_catalog_seq_id)
		and	 CRC.REPAIR_SEQ_ID = CR.REPAIR_SEQ_ID
--		and	 CR.ACTIVE_IND = ecrd_utils_pkg.G_ACTIVE
		and (cr.repair_end_date IS NULL OR cr.repair_end_date > SYSDATE)
		and	 CR.MODULE_SEQ_ID = CCOM.MODULE_SEQ_ID
		and	 CR.COMPONENT_CODE = CCOM.COMPONENT_CODE
		and  CR.MODULE_SEQ_ID = p_in_module
		and  (CCOM.COMPONENT_END_DATE IS NULL OR ccom.component_end_date > SYSDATE)
      and (crc.repair_end_date IS NULL OR crc.repair_end_date > SYSDATE)
      ORDER BY 1;
--
EXCEPTION
   WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(-20051,
     'NO_COMPONENT_FOUND ERROR IN ecrd_master_load_pkg.ecrd_component_list_prc' ||
       SQLCODE ||  ' - ' || SQLERRM);
   WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20001,
     'ERROR IN ecrd_master_load_pkg.ecrd_component_list_prc' ||
       SQLCODE ||  ' - ' || SQLERRM);
END ecrd_component_list_prc;
--
--**********************************************************************--
--
--**********************************************************************--
PROCEDURE ecrd_repair_list_prc(p_in_catalog_seq_id IN CRD_E_CATALOG.CATALOG_SEQ_ID%TYPE,
				p_in_module IN crd_crc_module.MODULE_SEQ_ID%TYPE,
   		  		p_in_component IN crd_e_component.COMPONENT_CODE%TYPE,
				p_out_repair_cur OUT retcur)
--
IS
	v_default_catalogSeq_id crd_e_catalog.catalog_seq_id%TYPE;
   v_eng_model	crd_e_catalog.eng_mdl_number%TYPE;
   v_error_message VARCHAR2(100) := '';
   v_engine_model crd_e_catalog.eng_mdl_number%TYPE;
BEGIN
	SELECT
   	eng_mdl_number
   INTO
   	v_eng_model
   FROM
   	crd_e_catalog
   WHERE
   	catalog_seq_id = p_in_catalog_seq_id;

   ecrd_managecatalog_pkg.ecrd_get_default_seqid_prc(v_eng_model,v_default_catalogSeq_id,v_error_message);

-- 	SELECT
--       cec1.catalog_seq_id
--    INTO
--    	v_default_catalogSeq_id
--    FROM
--       crd_e_catalog cec,
--       crd_e_catalog cec1
--    WHERE
--       cec1.catalog_type = ecrd_utils_pkg.G_DEFAULT_CATALOG AND
--    	cec1.eng_mdl_number = cec.eng_mdl_number AND
--       cec.catalog_seq_id = p_in_catalog_seq_id AND
--       cec.catalog_end_date >= SYSDATE;

   OPEN p_out_repair_cur
   FOR
	  -- Retrive list of repairs from the database
	/*	select
			  CR.REPAIR_SEQ_ID,
			  CR.REPAIR_DESCRIPTION
		from
			 crd_e_repair_CATALOG CRC,
			 crd_e_repair CR
		where
			 CRC.CATALOG_SEQ_ID = p_in_catalog_seq_id
		and CR.COMPONENT_CODE = p_in_component
		and CR.MODULE_SEQ_ID = p_in_module
--		and  CR.ACTIVE_IND = ecrd_utils_pkg.G_ACTIVE
		and (cr.repair_end_date IS NULL OR cr.repair_end_date > SYSDATE)
		and	 CRC.REPAIR_SEQ_ID = CR.REPAIR_SEQ_ID;*/
      SELECT
      	repair.repair_seq_id,
         repair.repair_description
      FROM
         crd_e_repair repair,
         crd_e_repair_catalog catalog
      WHERE
      	catalog.repair_seq_id = repair.repair_Seq_id AND
         catalog.catalog_seq_id = v_default_catalogSeq_id AND
         repair.module_seq_id = p_in_module AND
         repair.component_code = p_in_component AND
         repair.repair_type = ecrd_utils_pkg.G_INDIVIDUAL_REPAIR AND
         (repair.repair_end_date IS NULL OR repair.repair_end_date > SYSDATE) AND
         NOT EXISTS (  SELECT
         				     cer.split_merge_seq_id
   		   	   	  FROM
                          crd_e_repair cer,
                          crd_e_repair_catalog cerc
							  WHERE
                       	  cer.repair_seq_id   = cerc.repair_seq_id AND
                          repair.repair_Seq_id  = cer.split_merge_seq_id AND
                          cerc.catalog_seq_id  = p_in_catalog_seq_id AND
                          cer.split_merge_seq_id IS NOT NULL AND
                          cer.REPAIR_TYPE = ecrd_utils_pkg.G_CHILD_REPAIR)
	  UNION
 	  SELECT
        	repair.repair_seq_id,
         repair.repair_description
     FROM
     		crd_e_repair repair,
         crd_e_repair_catalog catalog
     WHERE
     		catalog.repair_seq_id = repair.repair_Seq_id AND
         catalog.catalog_seq_id = v_default_catalogSeq_id AND
         repair.module_seq_id = p_in_module AND
         repair.component_code = p_in_component AND
         repair.repair_type = ecrd_utils_pkg.G_PARENT_REPAIR AND
         (repair.repair_end_date IS NULL OR repair.repair_end_date > SYSDATE) AND
         NOT EXISTS ( SELECT
         					 cer2.parent_repair_seq_id
			   	   	 FROM
                         crd_e_repair cer,
                         crd_e_repair_catalog cerc,
                         crd_e_repair cer2
							 WHERE
                      	 cer.repair_seq_id = cerc.repair_seq_id AND
                      	 cerc.catalog_seq_id   = p_in_catalog_seq_id AND
                         repair.repair_seq_id   = cer2.parent_repair_seq_id AND
                         cer.split_merge_seq_id IS NOT NULL AND
                         cer.split_merge_seq_id = cer2.repair_seq_id AND
                         cer.repair_type        = ecrd_utils_pkg.G_SPLIT_REPAIR);
--
EXCEPTION
   WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(-20051,
     'NO_REPAIR_FOUND ERROR IN ecrd_master_load_pkg.ecrd_repair_list_prc' ||
       SQLCODE ||  ' - ' || SQLERRM);
   WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20001,
     'ERROR IN ecrd_master_load_pkg.ecrd_repair_list_prc' ||
       SQLCODE ||  ' - ' || SQLERRM);
END ecrd_repair_list_prc;
--
--**********************************************************************--
--
--**********************************************************************--

PROCEDURE ecrd_list_role_prc(p_out_role_cur OUT retcur)
--
IS
BEGIN
   OPEN p_out_role_cur
   FOR
   -- Retrive list of role from the database
	 Select cur.user_role
	 from crd_crc_user cur
	 ORDER BY
	 cur.user_role;
	--
EXCEPTION
   WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(-20051,
     'NO_ROLES_FOUND ERROR IN ecrd_master_load_pkg.ecrd_list_role_prc' ||
       SQLCODE ||  ' - ' || SQLERRM);
   WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20001,
     'ERROR IN ecrd_master_load_pkg.ecrd_list_role_prc' ||
       SQLCODE ||  ' - ' || SQLERRM);
END ecrd_list_role_prc;
--
--**********************************************************************--
--
--**********************************************************************--
--
--
--**********************************************************************--
--
--**********************************************************************--
--
PROCEDURE ecrd_list_customer_prc(p_in_cust          IN  VARCHAR2
										  ,p_in_active        IN  VARCHAR2
										  ,p_out_customer_cur OUT retcur)
--
IS
 	 v_main_query LONG;
BEGIN
 v_main_query :='Select cs.customer_code customer_code,
	 	cs.customer_name customer_name
	 FROM 	crd_e_customer cs
                       WHERE UPPER(cs.customer_name) like '''||p_in_cust||'%'||''' ';
   IF (p_in_active= ecrd_utils_pkg.G_YES)
   THEN
   	  v_main_query :=  v_main_query ||' AND NVL(cs.active_ind,'''||ecrd_utils_pkg.G_YES||''')= '''||ecrd_utils_pkg.G_YES||''' ';
   END IF;
			v_main_query :=  v_main_query ||' ORDER BY customer_name ';
   OPEN p_out_customer_cur
   FOR v_main_query;
	--
EXCEPTION
   WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(-20051,
     'NO_SITES_FOUND ERROR IN ecrd_master_load_pkg.ecrd_list_customer_prc' ||
       SQLCODE ||  ' - ' || SQLERRM);
   WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20001,
     'ERROR IN ecrd_master_load_pkg.ecrd_list_customer_prc' ||
       SQLCODE ||  ' - ' || SQLERRM);
END ecrd_list_customer_prc;
--
--**********************************************************************--
--
 PROCEDURE ecrd_list_cyc_class_prc
 (
    p_cyc_out OUT retcur
 )
 IS
 BEGIN
   OPEN p_cyc_out
   FOR
 	  SELECT cycle_count_class,cycle_count_class temp_class
	  FROM crd_e_cycle_counting_type
	  order by cycle_count_class;

 END ecrd_list_cyc_class_prc;




--**********************************************************************--
/*PROCEDURE ecrd_list_specify_role(p_in_loginrole IN crd_user_role.ROLE_CODE%TYPE,
p_out_rolelist_cur OUT retcur)
IS
v_main_query varchar(500):='';
v_where_query varchar(500):='';
BEGIN
v_main_query :='Select cur.role_code,cur.role_name
		from crd_user_role cur';
IF p_in_loginrole='ADMINISTRATOR'
THEN
v_where_query :=v_where_query||	'ORDER BY cur.role_name'||'''  ';
END IF;
IF p_in_loginrole='TECH_COORD'
THEN
v_where_query:=v_where_query||' AND cur.role_code='''||p_in_loginrole||'''  ';
END IF;
OPEN p_out_rolelist_cur
FOR v_main_query||v_where_query;
 EXCEPTION
   WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20001,
   'ERROR IN ecrd_master_load_pkg.ecrd_list_specify_role. :' ||v_main_query||v_where_query||':'
   ||SQLCODE ||  ' - ' || SQLERRM);
END ecrd_list_specify_role;
*/

PROCEDURE ecrd_list_site_prc
(
   p_in_user_role IN crd_crc_user.USER_ROLE%type,
   p_in_userid IN crd_crc_user.USERID%type,
   p_out_site_cur OUT retcur
)
IS
v_location_id  crd_crc_user.location_id%type;
v_query        VARCHAR2(1000):='';
BEGIN
--
  BEGIN
	SELECT NVL(location_id,'-')
	INTO   v_location_id
	FROM   crd_crc_user usr
	WHERE  UPPER(usr.userid) =UPPER( p_in_userid);
  EXCEPTION
  WHEN OTHERS
  THEN RAISE_APPLICATION_ERROR(-20051,
     'NO_SITES_FOUND ERROR IN ecrd_master_load_pkg.ecrd_list_site_prc' ||
       SQLCODE ||  ' - ' || SQLERRM);
  END;

--

  	v_query := 'SELECT location_id
		  		,site_name,NVL(location_labor_rate,0)
          FROM crd_location  cl
          WHERE cl.location_desc IS NOT NULL
		  ';
IF v_location_id <> ecrd_utils_pkg.G_ALL
THEN
	v_query := v_query || ' AND  cl.location_id = '''||v_location_id ||'''
			   		   	  ';
END IF;
	v_query := v_query || ' ORDER BY cl.location_desc ';
	OPEN  p_out_site_cur
        FOR
		   v_query;

--
END ecrd_list_site_prc;


PROCEDURE ecrd_list_site_without_all_prc
(
   p_in_user_role IN crd_crc_user.USER_ROLE%type,
   p_in_userid IN crd_crc_user.USERID%type,
   p_out_site_cur OUT retcur
)
IS
v_location_id  crd_crc_user.location_id%type;
v_query        VARCHAR2(1000):='';
BEGIN
--
  BEGIN
	SELECT NVL(location_id,'-')
	INTO   v_location_id
	FROM   crd_crc_user usr
	WHERE  UPPER(usr.userid )=UPPER( p_in_userid);
  EXCEPTION
  WHEN OTHERS
  THEN RAISE_APPLICATION_ERROR(-20051,
     'NO_SITES_FOUND ERROR IN ecrd_master_load_pkg.ecrd_list_site_prc' ||
       SQLCODE ||  ' - ' || SQLERRM);
  END;

--

  	v_query := ' SELECT location_id '||
		  		' ,site_name,NVL(location_labor_rate,0) '||
          ' FROM crd_location  cl ' ||
          ' WHERE cl.location_desc IS NOT NULL ' ||
		  ' AND cl.location_id <> ''ALL'' ';
IF v_location_id <> ecrd_utils_pkg.G_ALL
THEN
	v_query := v_query || ' AND  cl.location_id = '''||v_location_id ||'''
			   		   	  ';
END IF;
	v_query := v_query || ' ORDER BY cl.location_desc ';
	OPEN  p_out_site_cur
        FOR
		   v_query;


--
END ecrd_list_site_without_all_prc;



PROCEDURE ecrd_customer_details_prc(p_in_customer_code IN crd_e_customer.customer_code%TYPE,
		  							 result_out OUT  retcur)
AS
BEGIN
	 OPEN result_out
	 FOR
	 	SELECT  cec.customer_name	 customer_name,
			   cc.contract_number	 contract_code,
			   cc.customer_contract_description contract_description,
			   TO_CHAR(cc.contract_start_date,ecrd_utils_pkg.G_DATE_FORMAT) start_date,
			   TO_CHAR(cc.contract_end_date,ecrd_utils_pkg.G_DATE_FORMAT) end_date
	FROM  crd_e_customer cec
			 ,crd_e_customer_contract cc
	WHERE cec.CUSTOMER_CODE   = p_in_customer_code
  /* Patni 19-May-2006 Begin Add Contract Start and End Date */ 
  and rownum < 2;
  /* Patni 19-May-2006 Begin Add Contract Start and End Date */ 

EXCEPTION
	 WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20001,
   'ERROR IN ecrd_master_load_pkg.ecrd_customer_details_prc. :'
   ||SQLCODE ||  ' - ' || SQLERRM);
END ecrd_customer_details_prc;
-----------
PROCEDURE ecrd_list_site_for_cmp_prc(p_in_user_role   			IN  crd_crc_user.USER_ROLE%TYPE
												  ,p_in_userid     			IN  crd_crc_user.USERID%TYPE
                                      ,p_in_user_site   			IN  crd_crc_user.LOCATION_ID%TYPE
												  ,p_in_comp_code  			IN  crd_e_component.component_code%TYPE
												  ,p_in_mod_seq_id 			IN  crd_e_component.module_seq_id%TYPE
												  ,p_out_site_cur  			OUT retcur
                                      ,p_out_is_user_site_pend OUT VARCHAR2)
AS
v_location_id  crd_crc_user.location_id%TYPE;
v_query        VARCHAR2(5000):='';
BEGIN
--
  BEGIN
	SELECT NVL(location_id,'-')
	INTO   v_location_id
	FROM   crd_crc_user usr
	WHERE  UPPER(usr.userid )=UPPER( p_in_userid);
  EXCEPTION
  WHEN OTHERS
  THEN RAISE_APPLICATION_ERROR(-20051,
     'NO_SITES_FOUND ERROR IN ecrd_master_load_pkg.ecrd_list_site_for_comp_prc' ||
       SQLCODE ||  ' - ' || SQLERRM);
  END;
--
  	v_query := ' SELECT location_id '||
		  		' ,site_name,NVL(location_labor_rate,0) '||
          ' FROM crd_location  cl ' ||
          ' WHERE cl.location_desc IS NOT NULL ' ||
		  ' AND cl.location_id <> ''ALL'' ';
IF v_location_id <> ecrd_utils_pkg.G_ALL
THEN
	v_query := v_query || ' AND  cl.location_id = '''||v_location_id ||'''
			   		   	  ';
END IF;
v_query := v_query || ' AND NOT EXISTS(
												SELECT loc.location_id
												FROM  crd_location loc,
														crd_e_component_location comp_loc
												WHERE comp_loc.location_id  = loc.location_id
												AND   comp_loc.module_seq_id  ='|| p_in_mod_seq_id||'
												AND   comp_loc.component_code =  '''||p_in_comp_code ||'''
												AND   comp_loc.active_ind     = '''||ecrd_utils_pkg.G_ACTIVE||'''
                                    AND comp_loc.location_id = cl.location_id
												UNION
												SELECT loc.location_id
												FROM  crd_location loc,
														crd_e_comp_location_hist comp_loc_hist
												WHERE comp_loc_hist.location_id  = loc.location_id
												AND	comp_loc_hist.staging_history_ind = '''|| ecrd_utils_pkg.G_STAGING||'''
												AND   comp_loc_hist.approved_rejected_date IS NULL
												AND   comp_loc_hist.module_seq_id  ='|| p_in_mod_seq_id||'
												AND   comp_loc_hist.component_code =  '''||p_in_comp_code ||'''
                                    AND comp_loc_hist.location_id = cl.location_id
											)';
	v_query := v_query || ' ORDER BY cl.location_desc ';
	OPEN  p_out_site_cur
   FOR
			v_query;
--
	SELECT DECODE(COUNT(1),0,'N',1,'Y')
   INTO p_out_is_user_site_pend
   FROM crd_e_comp_location_hist ceclh
   WHERE ceclh.active_ind            = ecrd_utils_pkg.G_ACTIVE
   AND   ceclh.approve_reject_status IS NULL
   AND   ceclh.component_code        = p_in_comp_code
   AND   ceclh.location_id           = p_in_user_site
   AND   ceclh.module_seq_id         = p_in_mod_seq_id
   AND   ceclh.staging_history_ind   = ecrd_utils_pkg.G_STAGING
   AND NOT EXISTS (SELECT cecl.location_id
   					 FROM  crd_e_component_location cecl
                   WHERE cecl.active_ind            = ecrd_utils_pkg.G_ACTIVE
                   AND   cecl.location_id           = p_in_user_site
						 AND   cecl.module_seq_id         = p_in_mod_seq_id
						 AND   cecl.component_code        = p_in_comp_code);
EXCEPTION
	WHEN OTHERS
   THEN RAISE_APPLICATION_ERROR(-20051,
     ' ERROR IN ecrd_master_load_pkg.ecrd_list_site_for_comp_prc : ' ||  v_query ||
       SQLCODE ||  ' - ' || SQLERRM);
END ecrd_list_site_for_cmp_prc;
-----------
END ecrd_master_load_pkg;
/
