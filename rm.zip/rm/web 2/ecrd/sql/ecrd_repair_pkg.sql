create or replace package ecrd_repair_pkg as
/***********************************************************************/
--
-- Copyright Message       : Copyright(c) 2004 GE Aircraft Engines
-- Title                   : ecrd_repair_pkg
-- Author                  : Patni Offshore
-- Company                 : GE Aircraft Engines
-- Date                    : October 2004
-- Purpose                 : File contains Package Spec and body for Procs
--                           for Repair Creation/Modification
--
-- Modifications           :
-- Date                    Description
-- [DD-MMM-YYYY]           A brief description of change should go here like
--                         who had made change, why change was implemented
--                         and where change is made.
--
-- 06-oct-2004                New Code First Version
-- 04-Sep-2006                Patni Team - Modified ecrd_admin_update_rep_prc, 
--                                         ecrd_save_pricing_info_prc,
--                                         ecrd_tc_update_rep_prc,
--                                         ecrd_add_repair_to_csc
--
/***********************************************************************/
  TYPE result_cursor is REF CURSOR;

  /***********************************************************************/
-- Procedure Name                :ecrd_list_comp_prc
-- Purpose                       : This procedure is used to get Engine Family Cursor
-- Input Parameters              :None
-- Output Parameters             :Engine Family cursor .
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_list_comp_prc(P_EngineModel_in IN crd_crc_module.eng_mdl_number%type,
                  P_EngineModule_in IN crd_crc_module.module_seq_id%type,
                  P_CompCode_in IN crd_e_component.component_description%type,
              P_description_in IN varchar2,
              P_ATANo_in IN crd_e_component.ata_reference_snum%type,
                 P_CompList_out OUT result_cursor
              );

PROCEDURE ecrd_compcode_chk_prc(P_CompCode_in    IN  crd_e_component.component_code%type,
                   P_EngineModel_in IN crd_crc_module.eng_mdl_number%type,
                   P_EngineModule_in IN crd_crc_module.module_seq_id%type,
                  P_result   OUT VARCHAR2);


  procedure ecrd_list_repairs_prc(
       p_in_catalog_id IN NUMBER,
            p_in_eng_model IN VARCHAR2,
            p_in_module IN VARCHAR2,
            p_in_component_type IN VARCHAR2,
            p_in_component IN VARCHAR2,
            p_in_user_role IN VARCHAR2,
            p_out_repair_list OUT result_cursor
  );

    /***********************************************************************/
-- Procedure Name                :ecrd_get_loc_rate_prc
-- Purpose                       : This procedure is used to get Location Rate for the given site
-- Input Parameters              :Site Name
-- Output Parameters             :Location Rate
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/
   procedure ecrd_get_loc_rate_prc(
            p_in_site IN crd_location.location_id%type,
            p_out_locrate OUT VARCHAR2
  );
   /***********************************************************************/
-- Procedure Name                :ecrd_ind_or_grp_repairs_prc
-- Purpose                       : This procedure is used to get all individual  repairs or grouped repairs
-- Input Parameters              :Engine Model Code,Engine Module,Repair Type,Component Code
-- Output Parameters             :Repair List
-- Called Procedures/Functions   : ecrd_get_sites_fnc

/***********************************************************************/
 PROCEDURE ecrd_ind_or_grp_repairs_prc(
            p_in_cat_seq_id IN Crd_e_Repair_Catalog.CATALOG_SEQ_ID%TYPE,
            p_in_eng_model IN CRD_CRC_ENG_MDL_DISPLAY.ENG_MDL_NUMBER%TYPE,
            p_in_module IN Crd_crc_Module.MODULE_SEQ_ID%TYPE,
            p_in_ind_or_grp_type IN VARCHAR2,
            p_in_component IN crd_e_repair.COMPONENT_CODE%TYPE,
         p_in_cust_cat_seq_id IN crd_e_repair_catalog.catalog_seq_id%TYPE,
            p_out_repair_list OUT result_cursor
  );

    FUNCTION ecrd_get_repair_sites_fnc(
           p_in_repair_seq_id IN crd_e_repair_cost.repair_seq_id%TYPE
           )
   RETURN VARCHAR2;

  function ecrd_get_sites_fnc(
           p_in_module_seq_id IN VARCHAR2,
           p_in_component_code IN VARCHAR2)
   RETURN VARCHAR2;

  PROCEDURE ecrd_list_repair_find_prc(P_EngineModel_in IN crd_crc_module.eng_mdl_number%type,
                  P_EngineModule_in IN crd_crc_module.module_seq_id%type,
                  P_CompCode_in IN crd_e_component.component_code%type,
              p_CompType_in IN VARCHAR2,
              p_repairCode_in IN VARCHAR2,
              P_description_in IN varchar2,
              P_RepairList_out OUT result_cursor
  );

  procedure ecrd_search_repair_prc(
            p_in_eng_model IN VARCHAR2,
            p_in_module IN VARCHAR2,
            p_in_component_type IN VARCHAR2,
            p_in_component IN VARCHAR2,
            p_in_repair_type IN VARCHAR2,
            p_in_repair IN VARCHAR2,
            p_out_repair_details OUT result_cursor
  );
  /*
  */
  PROCEDURE ecrd_ins_repcat_hist_prc(p_in_repair_seq_id  IN crd_e_repair_catalog.repair_seq_id%TYPE
                          ,p_in_cat_seq_id      IN    crd_e_repair_catalog.catalog_seq_id%TYPE
                           ,p_in_user_id       IN crd_e_repair_catalog.created_by%TYPE
                           );
/*
*/
PROCEDURE ecrd_ins_repcatcost_hist_prc(p_in_repair_seq_id  IN  crd_e_repair_cost.repair_seq_id%TYPE
                              ,p_in_module_id      IN  crd_e_repair_cost.module_seq_id%TYPE
                             , p_in_location_id   IN  crd_e_repair_cost.location_id%TYPE
                             ,p_in_component_code IN  crd_e_repair_cost.component_code%TYPE
                              ,p_in_user_id        IN  crd_e_repair_cost.created_by%TYPE
                           );
 PROCEDURE  ecrd_admin_update_rep_prc(
   p_in_cat_seq_id IN crd_e_repair_catalog.catalog_seq_id%TYPE,
   p_in_component_code  IN    crd_e_component.component_code%TYPE,
   p_in_module_id       IN    crd_e_component.module_seq_id%TYPE,
   p_in_repair_seq_id IN     crd_e_repair.repair_seq_id%TYPE,
   p_in_repair_desc IN crd_e_repair.repair_description%TYPE,
   p_in_repair_volume IN crd_e_repair.repair_volume%TYPE,
   p_in_repair_eff_date VARCHAR2,
   p_in_repair_comment IN crd_e_repair.repair_comments%TYPE,
   p_in_repair_type IN crd_e_repair.repair_type%TYPE,
   p_in_repair_ref IN crd_e_repair.repair_reference%TYPE,
   p_in_repair_ref_format IN crd_e_repair.repair_reference_format%TYPE,

   p_in_rep_site_buff      IN LONG,
   p_in_child_rep_buff     IN LONG,
   p_in_tc_modify     IN VARCHAR2,

   p_in_incr_tat IN crd_e_repair_catalog.incremental_tat_ind%TYPE,
   p_in_tat IN crd_e_repair_catalog.repair_tat%TYPE,
   p_in_incremental_price IN crd_e_repair_catalog.incremental_price_ind%TYPE,
   p_in_price IN crd_e_repair_catalog.repair_price%TYPE,
   p_in_price_type IN crd_e_repair_catalog.price_type%TYPE,
   p_in_display_seq IN crd_e_repair_catalog.repair_display_seq_id%TYPE,
   p_in_future_price IN crd_e_repair_catalog.future_price%TYPE,
   p_in_future_tat IN crd_e_repair_catalog.future_tat%TYPE,
   p_in_future_price_tat_date VARCHAR2,
   p_in_user_id         IN    crd_e_repair.CREATED_BY%TYPE,
   p_in_user_role       IN     VARCHAR2,
    p_in_row_delimiter   IN   VARCHAR2,
    p_in_cols_delimiter   IN  VARCHAR2
   );



PROCEDURE ecrd_tc_update_rep_prc(
   p_in_cat_seq_id IN crd_e_repair_catalog.catalog_seq_id%TYPE,
   p_in_component_code  IN    crd_e_component.component_code%TYPE,
   p_in_module_id       IN    crd_e_component.module_seq_id%TYPE,
   p_in_repair_seq_id IN     crd_e_repair.repair_seq_id%TYPE,
   p_in_repair_desc IN crd_e_repair.repair_description%TYPE,
   p_in_repair_volume IN crd_e_repair.repair_volume%TYPE,
   p_in_repair_eff_date IN crd_e_repair.repair_effective_date%TYPE,
   p_in_repair_comment IN crd_e_repair.repair_comments%TYPE,
   p_in_repair_type IN crd_e_repair.repair_type%TYPE,
   p_in_repair_ref IN crd_e_repair.repair_reference%TYPE,
   p_in_repair_ref_format IN crd_e_repair.repair_reference_format%TYPE,

   p_in_rep_site_buff      IN LONG,
   p_in_child_rep_buff     IN LONG,
   p_in_tc_modify     IN VARCHAR2,

   p_in_incr_tat IN crd_e_repair_catalog.incremental_tat_ind%TYPE,
   p_in_tat IN crd_e_repair_catalog.repair_tat%TYPE,
   p_in_incremental_price IN crd_e_repair_catalog.incremental_price_ind%TYPE,
   p_in_price IN crd_e_repair_catalog.repair_price%TYPE,
   p_in_price_type IN crd_e_repair_catalog.price_type%TYPE,
   p_in_display_seq IN crd_e_repair_catalog.repair_display_seq_id%TYPE,
   p_in_future_price IN crd_e_repair_catalog.future_price%TYPE,
   p_in_future_tat IN crd_e_repair_catalog.future_tat%TYPE,
   p_in_future_price_tat_date IN crd_e_repair_catalog.future_effective_date%TYPE,
   p_in_user_id         IN    crd_e_repair.CREATED_BY%TYPE,
   p_in_user_role       IN     VARCHAR2,
    p_in_row_delimiter   IN   VARCHAR2,
    p_in_cols_delimiter   IN  VARCHAR2
   );

-- Added new For updating pricing information

PROCEDURE ecrd_save_pricing_info_prc
(
   p_in_cat_seq_id IN VARCHAR2,
   p_in_repair_seq_id IN VARCHAR2,
   p_in_user_id IN crd_e_repair.CREATED_BY%TYPE,
   p_in_incr_tat IN crd_e_repair_catalog.incremental_tat_ind%TYPE,
   p_in_tat IN VARCHAR2,
   p_in_incremental_price IN crd_e_repair_catalog.incremental_price_ind%TYPE,
   p_in_price IN VARCHAR2,
   p_in_price_type IN crd_e_repair_catalog.price_type%TYPE,
   p_in_future_price VARCHAR2,
   p_in_future_tat IN VARCHAR2,
   p_in_future_price_eff_date IN VARCHAR2,
   p_out_msg OUT VARCHAR2
);

--END OF ADD NEW PROC


PROCEDURE ecrd_update_repair_details_prc(
   p_in_cat_seq_id IN VARCHAR2,
   p_in_component_code  IN    crd_e_component.component_code%TYPE,
   p_in_module_id    IN   VARCHAR2,
   p_in_repair_seq_id IN     VARCHAR2,
   p_in_repair_desc IN crd_e_repair.repair_description%TYPE,
   p_in_repair_volume IN crd_e_repair.repair_volume%TYPE,
   p_in_repair_eff_date IN VARCHAR2,
   p_in_repair_comment IN crd_e_repair.repair_comments%TYPE,
   p_in_repair_type IN crd_e_repair.repair_type%TYPE,
   p_in_repair_ref IN crd_e_repair.repair_reference%TYPE,
   p_in_repair_ref_format IN crd_e_repair.repair_reference_format%TYPE,

   p_in_rep_site_buff      IN LONG,
   p_in_child_rep_buff     IN LONG,
   p_in_tc_modify     IN VARCHAR2,

   p_in_incr_tat IN crd_e_repair_catalog.incremental_tat_ind%TYPE,
   p_in_tat IN VARCHAR2,
   p_in_incremental_price IN crd_e_repair_catalog.incremental_price_ind%TYPE,
   p_in_price IN VARCHAR2,
   p_in_price_type IN crd_e_repair_catalog.price_type%TYPE,
   p_in_display_seq IN      VARCHAR2,
   p_in_future_price VARCHAR2,
   p_in_future_tat IN VARCHAR2,
   p_in_future_price_tat_date IN VARCHAR2,
   p_in_user_id         IN    crd_e_repair.CREATED_BY%TYPE,
   p_in_user_role       IN     VARCHAR2,
    p_in_row_delimiter   IN   VARCHAR2,
    p_in_cols_delimiter   IN  VARCHAR2,
   p_out_message       OUT    VARCHAR2
   );
   --
PROCEDURE ecrd_list_spl_rprs_prc(
       p_in_catalog_id IN NUMBER,
            p_in_eng_model IN VARCHAR2,
            p_in_module IN VARCHAR2,
            p_in_component_type IN VARCHAR2,
            p_in_component IN VARCHAR2,
            p_out_repair_list OUT result_cursor
  );

PROCEDURE ecrd_update_price_write_prc(
      		p_in_repair_seq_id IN NUMBER,
           p_in_catalog_id IN VARCHAR2);

PROCEDURE ecrd_add_repair_to_csc(
	p_in_repair_id IN VARCHAR2,
   p_in_customer_catalog_id IN crd_e_catalog.catalog_seq_id%TYPE,
   p_in_default_catalog_id IN crd_e_catalog.catalog_seq_id%TYPE,
   p_in_user_id IN crd_crc_user.userid%TYPE,
   p_out_message OUT VARCHAR2);

FUNCTION ecrd_get_rule_discount_prc
(
	p_in_catalog_seq_id crd_e_catalog.catalog_seq_id%TYPE,
   p_in_component_code crd_e_component.component_code%TYPE,
   p_in_module_seq_id crd_crc_module.module_seq_id%TYPE,
   p_in_repair_seq_id crd_e_repair.repair_seq_id%TYPE
)
RETURN VARCHAR2;

FUNCTION ecrd_rule_exists_fnc
(
	p_in_catalog_seq_id crd_e_catalog.catalog_seq_id%TYPE,
   p_in_component_code crd_e_component.component_code%TYPE,
   p_in_module_seq_id crd_crc_module.module_seq_id%TYPE,
   p_in_repair_seq_id crd_e_repair.repair_seq_id%TYPE
)
RETURN VARCHAR2;

PROCEDURE ecrd_list_default_repairs_prc(
		    p_in_catalog_id IN NUMBER,
          p_in_eng_model IN VARCHAR2,
          p_in_module IN VARCHAR2,
          p_in_component_type IN VARCHAR2,
          p_in_component IN VARCHAR2,
          p_out_repair_list OUT result_cursor
);

END ecrd_repair_pkg;
/
create or replace package body ecrd_repair_pkg as

  PROCEDURE ecrd_list_comp_prc(P_EngineModel_in IN crd_crc_module.eng_mdl_number%type,
                  P_EngineModule_in IN crd_crc_module.module_seq_id%type,
                  P_CompCode_in IN crd_e_component.component_description%type,
              P_description_in IN varchar2,
              P_ATANo_in IN crd_e_component.ata_reference_snum%type,
                 P_CompList_out OUT result_cursor
  )
  IS
  v_main_query       LONG;       -- Query from Main table
  v_staging_query    LONG;       -- Query from Stahing Table
  v_where_query   LONG;       -- Dynamic WHERE clause
  v_query      LONG;       -- Total dynamic query

  BEGIN

    v_where_query :=' ';

    IF  UPPER(P_description_in) = 'CODE'
    THEN
         IF P_CompCode_in IS NOT NULL
         THEN
                v_where_query:=v_where_query||' AND UPPER(cc.component_code) LIKE '''||UPPER(P_CompCode_in)||'%'||'''  ';
         END IF;
    ELSIF  UPPER(P_description_in) = 'DESCRIPTION'
    THEN
         IF P_description_in IS NOT NULL
          THEN
              v_where_query:=v_where_query||' AND UPPER(cc.component_description) LIKE '''||'%'||UPPER(P_CompCode_in)||'%'||'''  ';
        END IF;
    END IF;

    IF P_ATANo_in IS NOT NULL
    THEN
        v_where_query:=v_where_query||' AND cc.ata_reference_snum LIKE UPPER('''|| P_ATANo_in ||'%'||''')  ';
    END IF;

--  Generate Query for Main table.
    v_main_query:='SELECT  component_code,
            component_description
          FROM   crd_e_component cc
          WHERE
                        (cc.component_end_date IS NULL or cc. component_end_date > SYSDATE)
          AND     cc.module_seq_id =' || P_EngineModule_in;

--  Generate Query for Staging table
    v_staging_query:='SELECT component_code,
                         component_description
               FROM      crd_e_component_history cc
                 WHERE
                        (cc.component_end_date IS NULL or cc. component_end_date > SYSDATE)
               AND      cc.module_seq_id =' || P_EngineModule_in;

    v_query := v_main_query || v_where_query || ' UNION ' || v_staging_query || v_where_query;


    OPEN P_CompList_out
     FOR v_query;

    EXCEPTION
           WHEN OTHERS then
              RAISE_APPLICATION_ERROR(-20001,'ERROR IN ecrd_e_repair_pkg.ecrd_list_comp_prc ' ||SQLCODE ||  ' - ' || SQLERRM);
END ecrd_list_comp_prc;


 PROCEDURE ecrd_compcode_chk_prc(P_CompCode_in    IN  crd_e_component.component_code%type,
           P_EngineModel_in IN crd_crc_module.eng_mdl_number%type,
           P_EngineModule_in IN crd_crc_module.module_seq_id%type,
           P_result   OUT VARCHAR2)
   IS
   v_component_code crd_e_component.component_code%TYPE;
   CURSOR compcode_cursor
   IS

SELECT component_code
         FROM crd_e_component co
         WHERE  exists
         (
            SELECT module_seq_id
            FROM CRD_crc_module cm
            where eng_mdl_number=P_EngineModel_in
            AND co.MODULE_SEQ_ID=cm.MODULE_SEQ_ID
            AND cm.module_seq_id = P_EngineModule_in
          ) AND UPPER(co.component_code) = UPPER(P_CompCode_in);

  BEGIN
      IF NOT compcode_cursor%ISOPEN THEN
      OPEN compcode_cursor;
      FETCH compcode_cursor INTO v_component_code;
      IF compcode_cursor%FOUND THEN
         P_result := 'Comp Code already exists';
      ELSE
         P_result := 'New Component Code';
      END IF;
      CLOSE compcode_cursor;
      END IF;

   EXCEPTION when others then
       RAISE_APPLICATION_ERROR(-20001,'ERROR IN ecrd_e_repair_pkg.ecrd_compcode_chk_prc' ||SQLCODE ||  ' - ' || SQLERRM);
 end ecrd_compcode_chk_prc;



  procedure ecrd_list_repairs_prc(
       p_in_catalog_id IN NUMBER,
            p_in_eng_model IN VARCHAR2,
            p_in_module IN VARCHAR2,
            p_in_component_type IN VARCHAR2,
            p_in_component IN VARCHAR2,
            p_in_user_role IN VARCHAR2,
            p_out_repair_list OUT result_cursor
  )
  IS

  v_catalog_seq_id NUMBER(9):=0;
  v_err_mess VARCHAR2(1000):='';
  BEGIN

  --  Get the default Catalog Sequence Id for the Model if parameter is NULL

   IF (p_in_catalog_id IS NULL) THEN

      /*SELECT    catalog_seq_id
      INTO  v_catalog_seq_id
      FROM  crd_e_catalog
      WHERE    eng_mdl_number = p_in_eng_model
      AND   catalog_end_date >= TRUNC(SYSDATE)
      AND   catalog_type = 'D';*/
      ecrd_managecatalog_pkg.ecrd_get_default_seqid_prc(p_in_eng_model
                                                      ,v_catalog_seq_id
                                                      ,v_err_mess    );
   ELSE
      v_catalog_seq_id := p_in_catalog_id;
   END IF;
  IF p_in_user_role = ecrd_utils_pkg.G_GUEST
  THEN
  IF p_in_component_type = '1'
       THEN
         --
         OPEN p_out_repair_list
                FOR
      SELECT   catalog.repair_display_seq_id Display_Sequence,
                        repair.repair_description Repair_Description,
                        repair.repair_reference Repair_Reference,
                        ecrd_get_sites_fnc(p_in_module,UPPER(p_in_component)) Sites,
                        catalog.repair_price Price,
                        catalog.price_type Price_Type,
                        catalog.repair_TAT TAT,
                        repair.repair_seq_id repair_seq_id,
                        catalog.incremental_price_ind incremental_price_ind,
                        catalog.incremental_tat_ind incremental_tat_ind,
         repair.repair_type repair_type
               FROM  crd_e_repair repair,
                     crd_e_repair_catalog catalog
               WHERE    catalog.repair_seq_id = repair.repair_seq_id
         --18-05-2006 Patni Chnaged Sysdate to Sysdate+1 to restrict deleted  reapirs Begin
               AND   (catalog.repair_end_date IS NULL or catalog.repair_end_date > SYSDATE+1)
         --18-05-2006 Patni Chnaged Sysdate to Sysdate+1 to restrict deleted  reapirs End
               AND   repair.repair_type <> 'CR' -- Don't Show Child Repairs
               AND   repair.module_seq_id = p_in_module
               AND   repair.component_code = UPPER(p_in_component)
               AND   catalog.catalog_seq_id = v_catalog_seq_id

--        don't show repairs from Main table that exist in Stagging table as well

               AND   catalog.repair_seq_id NOT IN
               (
      SELECT   repair.repair_seq_id
      FROM  crd_e_repair repair,
         crd_e_repair_catalog_hist catalog
      WHERE    catalog.repair_seq_id = repair.repair_Seq_id
  --18-05-2006 Patni Chnaged Sysdate to Sysdate+1 to restrict deleted  reapirs Begin
      AND   (catalog.repair_end_date IS NULL or catalog.repair_end_date > SYSDATE+1)
        --18-05-2006 Patni Chnaged Sysdate to Sysdate+1 to restrict deleted  reapirs End
      AND   catalog.staging_history_ind = ecrd_utils_pkg.G_STAGING
      AND   catalog.approved_rejected_date IS NULL
      AND   repair.repair_type <> 'CR' -- Don't Show Child Repairs
      AND   repair.module_seq_id = p_in_module
                AND  repair.component_code = UPPER(p_in_component)
      AND   catalog.catalog_seq_id = v_catalog_seq_id
               )
         order by 1;

        ELSIF p_in_component_type = '2'
        THEN
                OPEN p_out_repair_list
                FOR
                 SELECT catalog.repair_display_seq_id Display_Sequence,
                        repair.repair_description Repair_Description,
                        repair.repair_reference Repair_Reference,
                        ecrd_get_sites_fnc(p_in_module,p_in_component) Sites,
                        catalog.repair_price Price,
                        catalog.price_type Price_Type,
                        catalog.repair_TAT TAT,
                        repair.repair_seq_id repair_seq_id,
                        catalog.incremental_price_ind incremental_price_ind,
                        catalog.incremental_tat_ind incremental_tat_ind,
         					repair.repair_type repair_type
                 FROM   crd_e_repair repair,
					         crd_e_repair_catalog catalog,
					         crd_crc_module module,
					         crd_crc_eng_mdl_display model,
					         crd_e_component component
                 WHERE  catalog.repair_seq_id = repair.repair_Seq_id
                 AND    module.module_seq_id = repair.module_seq_id
                 AND    model.eng_mdl_number = module.eng_mdl_number
                 AND    component.Component_Code = repair.component_code
                 AND    component.module_seq_id = module.module_seq_id
  --18-05-2006 Patni Chnaged Sysdate to Sysdate+1 to restrict deleted  reapirs Begin
                 AND (catalog.repair_end_date IS NULL or catalog.repair_end_date > SYSDATE+1)
  --18-05-2006 Patni Chnaged Sysdate to Sysdate+1 to restrict deleted  reapirs End
                 AND  repair.repair_type <> 'CR' -- Don't Show Child Repairs
                 AND    repair.component_code = component.component_code
                 AND    UPPER(component.component_description) = UPPER(p_in_component)
                 AND    model.eng_mdl_number  = p_in_eng_model
       AND  repair.module_seq_id = p_in_module
       AND  catalog.catalog_seq_id = v_catalog_seq_id

-- exclude those repairs that are present in history table as well
       AND  catalog.repair_seq_id NOT IN
       (
       SELECT  repair.repair_seq_id
                 FROM   crd_e_repair repair,
         crd_e_repair_catalog_hist catalog,
         crd_crc_module module,
         crd_crc_eng_mdl_display model,
         crd_e_component component
                 WHERE  catalog.repair_seq_id = repair.repair_Seq_id
                 AND    module.module_seq_id = repair.module_seq_id
                 AND    model.eng_mdl_number = module.eng_mdl_number
                 AND    component.Component_Code = repair.component_code
                 AND    component.module_seq_id = module.module_seq_id
  --18-05-2006 Patni Chnaged Sysdate to Sysdate+1 to restrict deleted  reapirs Begin
                 AND (catalog.repair_end_date IS NULL or catalog.repair_end_date > SYSDATE+1)
  --18-05-2006 Patni Chnaged Sysdate to Sysdate+1 to restrict deleted  reapirs End
       AND  catalog.staging_history_ind = ecrd_utils_pkg.G_STAGING
       AND  catalog.approved_rejected_date IS NULL
                   AND  repair.repair_type <> 'CR' -- Don't Show Child Repairs
                 AND    repair.component_code = component.component_code
                 AND    UPPER(component.component_description) = UPPER(p_in_component)
                 AND    model.eng_mdl_number  = p_in_eng_model
       AND  repair.module_seq_id = p_in_module
       AND  catalog.catalog_seq_id = v_catalog_seq_id
       )          order by 1;

        END IF;--componet code or desc
  --
  ELSE--For user role guest...
    IF p_in_component_type = '1'
       THEN
            OPEN p_out_repair_list
            FOR
                  SELECT * FROM
                  (
                  SELECT   catalog.repair_display_seq_id Display_Sequence,
         repair.repair_description Repair_Description,
         repair.repair_reference Repair_Reference,
         ecrd_get_sites_fnc(p_in_module,UPPER(p_in_component)) Sites,
         catalog.repair_price Price,
         catalog.price_type Price_Type,
         catalog.repair_TAT TAT,
         repair.repair_seq_id repair_seq_id,
         catalog.incremental_price_ind incremental_price_ind,
         catalog.incremental_tat_ind incremental_tat_ind,
         repair.repair_type repair_type
      FROM  crd_e_repair repair,
         crd_e_repair_catalog_hist catalog
      WHERE    catalog.repair_seq_id = repair.repair_Seq_id
  --18-05-2006 Patni Chnaged Sysdate to Sysdate+1 to restrict deleted  reapirs Begin
      AND   (catalog.repair_end_date IS NULL or catalog.repair_end_date > SYSDATE+1)
  --18-05-2006 Patni Chnaged Sysdate to Sysdate+1 to restrict deleted  reapirs End
      AND   catalog.staging_history_ind = ecrd_utils_pkg.G_STAGING
      AND   catalog.approved_rejected_date IS NULL
      AND   repair.repair_type <> 'CR' -- Don't Show Child Repairs
      AND   repair.module_seq_id = p_in_module
                AND  repair.component_code = UPPER(p_in_component)
      AND   catalog.catalog_seq_id = v_catalog_seq_id
              )
         UNION
         SELECT * FROM
         (
      SELECT   catalog.repair_display_seq_id Display_Sequence,
                        repair.repair_description Repair_Description,
                        repair.repair_reference Repair_Reference,
                        ecrd_get_sites_fnc(p_in_module,UPPER(p_in_component)) Sites,
                        catalog.repair_price Price,
                        catalog.price_type Price_Type,
                        catalog.repair_TAT TAT,
                        repair.repair_seq_id repair_seq_id,
                        catalog.incremental_price_ind incremental_price_ind,
                        catalog.incremental_tat_ind incremental_tat_ind,
         repair.repair_type repair_type
               FROM  crd_e_repair repair,
                     crd_e_repair_catalog catalog
               WHERE    catalog.repair_seq_id = repair.repair_seq_id
  --18-05-2006 Patni Chnaged Sysdate to Sysdate+1 to restrict deleted  reapirs Begin
               AND   (catalog.repair_end_date IS NULL or catalog.repair_end_date > SYSDATE+1)
  --18-05-2006 Patni Chnaged Sysdate to Sysdate+1 to restrict deleted  reapirs End
               AND   repair.repair_type <> 'CR' -- Don't Show Child Repairs
               AND   repair.module_seq_id = p_in_module
               AND   repair.component_code = UPPER(p_in_component)
               AND   catalog.catalog_seq_id = v_catalog_seq_id

--        don't show repairs from Main table that exist in Stagging table as well

               AND   catalog.repair_seq_id NOT IN
               (
      SELECT   repair.repair_seq_id
      FROM  crd_e_repair repair,
         crd_e_repair_catalog_hist catalog
      WHERE    catalog.repair_seq_id = repair.repair_Seq_id
        --18-05-2006 Patni Chnaged Sysdate to Sysdate+1 to restrict deleted  reapirs Begin
      AND   (catalog.repair_end_date IS NULL or catalog.repair_end_date > SYSDATE+1)
        --18-05-2006 Patni Chnaged Sysdate to Sysdate+1 to restrict deleted  reapirs End
      AND   catalog.staging_history_ind = ecrd_utils_pkg.G_STAGING
      AND   catalog.approved_rejected_date IS NULL
      AND   repair.repair_type <> 'CR' -- Don't Show Child Repairs
      AND   repair.module_seq_id = p_in_module
                AND  repair.component_code = UPPER(p_in_component)
      AND   catalog.catalog_seq_id = v_catalog_seq_id
               )
              )
         UNION

         SELECT * FROM
         (
         SELECT   catalog.repair_display_seq_id Display_Sequence,
         repair.repair_description Repair_Description,
         repair.repair_reference Repair_Reference,
         ecrd_get_sites_fnc(p_in_module,UPPER(p_in_component)) Sites,
         catalog.repair_price Price,
         catalog.price_type Price_Type,
         catalog.repair_TAT TAT,
         repair.repair_seq_id repair_seq_id,
         catalog.incremental_price_ind incremental_price_ind,
         catalog.incremental_tat_ind incremental_tat_ind,
         repair.repair_type repair_type
      FROM  crd_e_repair_history repair,
         crd_e_repair_catalog_hist catalog
      WHERE    catalog.repair_seq_id = repair.repair_Seq_id
        --18-05-2006 Patni Chnaged Sysdate to Sysdate+1 to restrict deleted  reapirs Begin
      AND   (catalog.repair_end_date IS NULL or catalog.repair_end_date > SYSDATE+1)
        --18-05-2006 Patni Chnaged Sysdate to Sysdate+1 to restrict deleted  reapirs End
      AND   repair.staging_history_ind = ecrd_utils_pkg.G_STAGING
      AND   repair.approved_rejected_date IS NULL
      AND   repair.repair_type <> 'CR' -- Don't Show Child Repairs
      AND   repair.module_seq_id = p_in_module
      AND   repair.component_code = UPPER(p_in_component)
      AND   catalog.catalog_seq_id =v_catalog_seq_id
      )

         order by 1;

        ELSIF p_in_component_type = '2'
        THEN
                OPEN p_out_repair_list
                FOR
      SELECT * FROM(
                 SELECT catalog.repair_display_seq_id Display_Sequence,
                        repair.repair_description Repair_Description,
                        repair.repair_reference Repair_Reference,
                        ecrd_get_sites_fnc(p_in_module,p_in_component) Sites,
                        catalog.repair_price Price,
                        catalog.price_type Price_Type,
                        catalog.repair_TAT TAT,
                        repair.repair_seq_id repair_seq_id,
                        catalog.incremental_price_ind incremental_price_ind,
                        catalog.incremental_tat_ind incremental_tat_ind,
         repair.repair_type repair_type
                 FROM   crd_e_repair repair,
         crd_e_repair_catalog_hist catalog,
         crd_crc_module module,
         crd_crc_eng_mdl_display model,
         crd_e_component component
                 WHERE  catalog.repair_seq_id = repair.repair_Seq_id
                 AND    module.module_seq_id = repair.module_seq_id
                 AND    model.eng_mdl_number = module.eng_mdl_number
                 AND    component.Component_Code = repair.component_code
                 AND    component.module_seq_id = module.module_seq_id
  --18-05-2006 Patni Chnaged Sysdate to Sysdate+1 to restrict deleted  reapirs Begin
                 AND (catalog.repair_end_date IS NULL or catalog.repair_end_date > SYSDATE+1)
  --18-05-2006 Patni Chnaged Sysdate to Sysdate+1 to restrict deleted  reapirs End
       AND  catalog.staging_history_ind = ecrd_utils_pkg.G_STAGING
       AND  catalog.approved_rejected_date IS NULL
                   AND  repair.repair_type <> 'CR' -- Don't Show Child Repairs
                 AND    repair.component_code = component.component_code
                 AND    UPPER(component.component_description) = UPPER(p_in_component)
                 AND    model.eng_mdl_number  = p_in_eng_model
       AND  repair.module_seq_id = p_in_module
       AND  catalog.catalog_seq_id = v_catalog_seq_id
       )
       UNION
                 SELECT * FROM(
                 SELECT catalog.repair_display_seq_id Display_Sequence,
                        repair.repair_description Repair_Description,
                        repair.repair_reference Repair_Reference,
                        ecrd_get_sites_fnc(p_in_module,p_in_component) Sites,
                        catalog.repair_price Price,
                        catalog.price_type Price_Type,
                        catalog.repair_TAT TAT,
                        repair.repair_seq_id repair_seq_id,
                        catalog.incremental_price_ind incremental_price_ind,
                        catalog.incremental_tat_ind incremental_tat_ind,
         repair.repair_type repair_type
                 FROM   crd_e_repair repair,
         crd_e_repair_catalog catalog,
         crd_crc_module module,
         crd_crc_eng_mdl_display model,
         crd_e_component component
                 WHERE  catalog.repair_seq_id = repair.repair_Seq_id
                 AND    module.module_seq_id = repair.module_seq_id
                 AND    model.eng_mdl_number = module.eng_mdl_number
                 AND    component.Component_Code = repair.component_code
                 AND    component.module_seq_id = module.module_seq_id
  --18-05-2006 Patni Chnaged Sysdate to Sysdate+1 to restrict deleted  reapirs Begin
                 AND (catalog.repair_end_date IS NULL or catalog.repair_end_date > SYSDATE +1 )
  --18-05-2006 Patni Chnaged Sysdate to Sysdate+1 to restrict deleted  reapirs End
                   AND  repair.repair_type <> 'CR' -- Don't Show Child Repairs
                 AND    repair.component_code = component.component_code
                 AND    UPPER(component.component_description) = UPPER(p_in_component)
                 AND    model.eng_mdl_number  = p_in_eng_model
       AND  repair.module_seq_id = p_in_module
       AND  catalog.catalog_seq_id = v_catalog_seq_id

-- exclude those repairs that are present in history table as well
       AND  catalog.repair_seq_id NOT IN
       (
       SELECT  repair.repair_seq_id
                 FROM   crd_e_repair repair,
         crd_e_repair_catalog_hist catalog,
         crd_crc_module module,
         crd_crc_eng_mdl_display model,
         crd_e_component component
                 WHERE  catalog.repair_seq_id = repair.repair_Seq_id
                 AND    module.module_seq_id = repair.module_seq_id
                 AND    model.eng_mdl_number = module.eng_mdl_number
                 AND    component.Component_Code = repair.component_code
                 AND    component.module_seq_id = module.module_seq_id
  --18-05-2006 Patni Chnaged Sysdate to Sysdate+1 to restrict deleted  reapirs Begin
                 AND (catalog.repair_end_date IS NULL or catalog.repair_end_date > SYSDATE +1)
  --18-05-2006 Patni Chnaged Sysdate to Sysdate+1 to restrict deleted  reapirs End
       AND  catalog.staging_history_ind = ecrd_utils_pkg.G_STAGING
       AND  catalog.approved_rejected_date IS NULL
                   AND  repair.repair_type <> 'CR' -- Don't Show Child Repairs
                 AND    repair.component_code = component.component_code
                 AND    UPPER(component.component_description) = UPPER(p_in_component)
                 AND    model.eng_mdl_number  = p_in_eng_model
       AND  repair.module_seq_id = p_in_module
       AND  catalog.catalog_seq_id = v_catalog_seq_id
       ))
       UNION
       SELECT * FROM(
                 SELECT catalog.repair_display_seq_id Display_Sequence,
                        repair.repair_description Repair_Description,
                        repair.repair_reference Repair_Reference,
                        ecrd_get_sites_fnc(p_in_module,p_in_component) Sites,
                        catalog.repair_price Price,
                        catalog.price_type Price_Type,
                        catalog.repair_TAT TAT,
                        repair.repair_seq_id repair_seq_id,
                        catalog.incremental_price_ind incremental_price_ind,
                        catalog.incremental_tat_ind incremental_tat_ind,
         repair.repair_type repair_type
                 FROM   crd_e_repair_history repair,
         crd_e_repair_catalog_hist catalog,
         crd_crc_module module,
         crd_crc_eng_mdl_display model,
         crd_e_component component
                 WHERE  catalog.repair_seq_id = repair.repair_Seq_id
                 AND    module.module_seq_id = repair.module_seq_id
                 AND    model.eng_mdl_number = module.eng_mdl_number
                 AND    component.Component_Code = repair.component_code
                 AND    component.module_seq_id = module.module_seq_id
  --18-05-2006 Patni Chnaged Sysdate to Sysdate+1 to restrict deleted  reapirs Begin
                 AND (catalog.repair_end_date IS NULL or catalog.repair_end_date > SYSDATE +1)
  --18-05-2006 Patni Chnaged Sysdate to Sysdate+1 to restrict deleted  reapirs End
       AND  repair.staging_history_ind = ecrd_utils_pkg.G_STAGING
       AND  repair.approved_rejected_date IS NULL
                   AND  repair.repair_type <> 'CR' -- Don't Show Child Repairs
                 AND    repair.component_code = component.component_code
                 AND    UPPER(component.component_description) = UPPER(p_in_component)
                 AND    model.eng_mdl_number  = p_in_eng_model
       AND  repair.module_seq_id = p_in_module
       AND  catalog.catalog_seq_id = v_catalog_seq_id
            )
                 order by 1;

        END IF;--componet code or desc
  END IF;--User role

  EXCEPTION
   WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20001,'ERROR IN ecrd_e_repair_pkg.ecrd_list_repairs_prc' ||SQLCODE ||  ' - ' || SQLERRM);

  END ecrd_list_repairs_prc;


  procedure ecrd_get_loc_rate_prc(
            p_in_site IN crd_location.location_id%type,
            p_out_locrate OUT VARCHAR2
  )
  IS
  v_loc_rate VARCHAR2(4);
  BEGIN
      v_loc_rate :=0;
      SELECT location_labor_rate
      into v_loc_rate
      FROM crd_location cl
      WHERE location_id = p_in_site;
            p_out_locrate := v_loc_rate;
  EXCEPTION
   WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20001,'ERROR IN ecrd_e_repair_pkg.ecrd_get_loc_rate_prc' ||SQLCODE ||  ' - ' || SQLERRM);

  END ecrd_get_loc_rate_prc;




  function ecrd_get_sites_fnc(
           p_in_module_seq_id IN VARCHAR2,
           p_in_component_code IN VARCHAR2)
   RETURN VARCHAR2 IS
  sites_cur result_cursor;
  v_site_name VARCHAR2(1000):='';
  v_temp VARCHAR2(1000):='';
  v_counter NUMBER:=0;
  BEGIN
      open sites_cur
             FOR
                SELECT site.site_name
                FROM crd_location site
                  ,crd_e_component_location complocation
                WHERE site.location_id = complocation.location_id
                 AND complocation.module_seq_id  = p_in_module_seq_id
                 AND complocation.component_code = p_in_component_code
                 AND complocation.active_ind = ecrd_utils_pkg.G_ACTIVE
                UNION
                SELECT site.site_name
                FROM crd_location site
                  ,crd_e_comp_location_hist comp_locat_hist
                WHERE site.location_id = comp_locat_hist.location_id
                 AND comp_locat_hist.approved_rejected_date IS NULL
                 AND comp_locat_hist.staging_history_ind = ecrd_utils_pkg.G_STAGING
                 AND comp_locat_hist.module_seq_id  = p_in_module_seq_id
           AND comp_locat_hist.component_code = p_in_component_code;

      loop
          fetch sites_cur into v_temp;
          exit when sites_cur%NOTFOUND;
          v_counter:=v_counter+1;
          if(v_counter=1)
          then
              v_site_name:=v_temp;
          else
              v_site_name:=v_site_name || ', ' || v_temp;
          end if;

      end loop;
      return v_site_name;
  EXCEPTION
   WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20002,'ERROR IN ecrd_e_repair_pkg.ecrd_get_sites_fnc' ||SQLCODE ||  ' - ' || SQLERRM);
  END ecrd_get_sites_fnc;



  PROCEDURE ecrd_list_repair_find_prc(P_EngineModel_in IN crd_crc_module.eng_mdl_number%type,
                  P_EngineModule_in IN crd_crc_module.module_seq_id%type,
                  P_CompCode_in IN crd_e_component.component_code%type,
              p_CompType_in IN VARCHAR2,
              p_repairCode_in IN VARCHAR2,
              P_description_in IN VARCHAR2,
              P_RepairList_out OUT result_cursor
  )
  IS
     v_main_query       LONG;
     v_repair_staging_query   LONG;
     v_catalog_staging_query  LONG;
     v_where_query         LONG;
     v_query         LONG;
     v_err_mess      VARCHAR2(1000):='';
     v_catalog_seq_id   NUMBER(9):=0;
     v_component_code   crd_e_component.component_code%TYPE;

  BEGIN
   /*  SELECT  catalog_seq_id
       INTO v_catalog_seq_id
       FROM crd_e_catalog
       WHERE   eng_mdl_number = P_EngineModel_in
       AND  catalog_end_date >= TRUNC(SYSDATE)
       AND  catalog_type = 'D';*/
   ecrd_managecatalog_pkg.ecrd_get_default_seqid_prc(P_EngineModel_in
                                                 ,v_catalog_seq_id
                                                 ,v_err_mess   );
   v_component_code := NULL;

   IF P_CompType_in = 'Code' THEN
      v_component_code := UPPER(P_CompCode_in);   -- Component code is passed

   ELSE
      -- Get the component code for the component description
          BEGIN
             SELECT  component_code
             INTO v_component_code
             FROM crd_e_component
             WHERE   module_seq_id = P_EngineModule_in
             AND  UPPER(trim(component_description)) = UPPER(P_CompCode_in);
      EXCEPTION
         WHEN NO_DATA_FOUND THEN

   -- Check if component code exists in history table (waiting for approval)
         BEGIN
                SELECT  component_code
                INTO v_component_code
                FROM crd_e_component_history
                WHERE   module_seq_id = P_EngineModule_in
                AND  UPPER(trim(component_description)) = UPPER(P_CompCode_in);
         EXCEPTION
            WHEN NO_DATA_FOUND THEN
               v_component_code := NULL;
         END;
      END;
   END IF;

    IF P_description_in = 'Code'
    THEN
         IF P_RepairCode_in IS NOT NULL
         THEN
                v_where_query:=v_where_query||' AND repcatalog.repair_display_seq_id LIKE '''||P_RepairCode_in||'%''  ';
         END IF;
    ELSIF  P_description_in = 'Description'
    THEN
         IF P_repairCode_in IS NOT NULL
          THEN
              v_where_query:=v_where_query||' AND UPPER(repair.repair_description) LIKE '''|| UPPER(P_RepairCode_in)||'%'||'''  ';
    END IF;
    END IF;

   v_main_query:='SELECT   repcatalog.repair_display_seq_id  rep_display_seq_id
            ,repair.repair_description   rep_description
            ,repair.repair_type rep_type
          FROM
            crd_e_repair repair,
            crd_e_repair_catalog repcatalog
                   WHERE
            repcatalog.repair_seq_id = repair.repair_seq_id
                    AND    repair.parent_repair_seq_id IS NULL
                    AND    (repair.repair_end_date IS NULL OR
            repair.repair_end_date > SYSDATE)
                    AND    repcatalog.catalog_seq_id = ' || v_catalog_seq_id || '
               AND      repair.module_seq_id =' || P_EngineModule_in|| '
          AND     repair.component_code = ''' || v_component_code || ''' ';


  v_repair_staging_query:='SELECT   repcatalog.repair_display_seq_id  rep_display_seq_id
            ,repair.repair_description   rep_description
            ,repair.repair_type rep_type
          FROM
            crd_e_repair repair,
            crd_e_repair_catalog_hist repcatalog
                   WHERE
            repcatalog.repair_seq_id = repair.repair_seq_id
          AND     repcatalog.staging_history_ind = ''' || ecrd_utils_pkg.G_STAGING || ''' ' || '
          AND     repcatalog.approved_rejected_date IS NULL
                    AND    repair.parent_repair_seq_id IS NULL
                    AND    (repair.repair_end_date IS NULL OR
            repair.repair_end_date > SYSDATE)
                    AND    repcatalog.catalog_seq_id = ' || v_catalog_seq_id || '
               AND      repair.module_seq_id =' || P_EngineModule_in|| '
          AND     repair.component_code = ''' || v_component_code || ''' ';

 v_catalog_staging_query:='SELECT   repcatalog.repair_display_seq_id  rep_display_seq_id
            ,repair.repair_description   rep_description
            ,repair.repair_type rep_type
          FROM
            crd_e_repair_history repair,
            crd_e_repair_catalog_hist repcatalog
                   WHERE
            repcatalog.repair_seq_id = repair.repair_seq_id
          AND     repair.staging_history_ind = ''' || ecrd_utils_pkg.G_STAGING || ''' ' || '
          AND     repair.approved_rejected_date IS NULL
                    AND    repair.parent_repair_seq_id IS NULL
                    AND    (repair.repair_end_date IS NULL OR
            repair.repair_end_date > SYSDATE)
                    AND    repcatalog.catalog_seq_id = ' || v_catalog_seq_id || '
               AND      repair.module_seq_id =' || P_EngineModule_in|| '
          AND     repair.component_code = ''' || v_component_code || ''' ';

    v_query := v_main_query || v_where_query || ' UNION ' || v_repair_staging_query || v_where_query || ' UNION ' || v_catalog_staging_query || v_where_query;

    OPEN P_RepairList_out
     FOR v_query;

    EXCEPTION when others then
       RAISE_APPLICATION_ERROR(-20001,'ERROR IN ecrd_e_repair_pkg.ecrd_list_repair_find_prc' ||SQLCODE ||  ' - ' || SQLERRM);
END ecrd_list_repair_find_prc;

procedure ecrd_search_repair_prc(
            p_in_eng_model IN VARCHAR2,
            p_in_module IN VARCHAR2,
            p_in_component_type IN VARCHAR2,
            p_in_component IN VARCHAR2,
            p_in_repair_type IN VARCHAR2,
            p_in_repair IN VARCHAR2,
            p_out_repair_details OUT result_cursor
  )
  IS
  v_catalog_seq_id NUMBER(9):=0;
  v_sql VARCHAR2(5000):='';
  v_err_mess VARCHAR2(1000) :='';
  v_component_code   crd_e_component.component_code%TYPE;

  BEGIN

       BEGIN
       /*   SELECT   catalog_seq_id
          INTO v_catalog_seq_id
          FROM crd_e_catalog
          WHERE   eng_mdl_number = p_in_eng_model
          AND  catalog_end_date >= TRUNC(SYSDATE)
          AND  catalog_type = 'D';
          */
       ecrd_managecatalog_pkg.ecrd_get_default_seqid_prc(p_in_eng_model
                                                 ,v_catalog_seq_id
                                                 ,v_err_mess   );

   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         v_catalog_seq_id := NULL;
   END;

   v_component_code := NULL;

   IF p_in_component_type = '1' THEN
      v_component_code := UPPER(p_in_component);   -- Component code is passed

   ELSIF p_in_component_type = '2' THEN
      -- Get the component code for the component description
          BEGIN
             SELECT  component_code
             INTO v_component_code
             FROM crd_e_component
             WHERE   module_seq_id = p_in_module
             AND  UPPER(trim(component_description)) = UPPER(p_in_component);
      EXCEPTION
         WHEN NO_DATA_FOUND THEN

   -- Check if component code exists in history table (waiting for approval)
         BEGIN
                SELECT  component_code
                INTO v_component_code
                FROM crd_e_component_history
                WHERE   module_seq_id = p_in_module
                AND  UPPER(trim(component_description)) = UPPER(p_in_component);
         EXCEPTION
            WHEN NO_DATA_FOUND THEN
               v_component_code := NULL;
         END;
      END;
   END IF;

        IF p_in_repair_type = '1'
           THEN
               OPEN p_out_repair_details
               FOR
                   SELECT * FROM(
                   SELECT catalog.repair_display_seq_id Display_Sequence,
                          repair.repair_description Repair_Description,
                          repair.repair_reference Repair_Reference,
                          ecrd_get_sites_fnc(p_in_module, v_component_code) Sites,
                          catalog.repair_price Price,
                          catalog.price_type Price_Type,
                          catalog.repair_TAT TAT,
                          repair.repair_seq_id repair_seq_id,
                          catalog.incremental_price_ind incremental_price_ind,
                          catalog.incremental_tat_ind incremental_tat_ind,
           repair.repair_type repair_type
                   FROM
           crd_e_repair repair,
           crd_e_repair_catalog_hist catalog
                   WHERE
           catalog.repair_seq_id = repair.repair_Seq_id
         AND     repair.repair_type <> 'CR'
         AND     catalog.staging_history_ind = ecrd_utils_pkg.G_STAGING
         AND     catalog.approved_rejected_date IS NULL
         AND     (catalog.repair_end_date IS NULL or catalog.repair_end_date > SYSDATE)
                   AND    repair.module_seq_id = p_in_module
                   AND    repair.component_code = v_component_code
         AND     catalog.repair_display_seq_id = p_in_repair
                   AND    catalog.catalog_seq_id =  v_catalog_seq_id
              )
         UNION
                   SELECT * FROM(
                   SELECT catalog.repair_display_seq_id Display_Sequence,
                          repair.repair_description Repair_Description,
                          repair.repair_reference Repair_Reference,
                          ecrd_get_sites_fnc(p_in_module, v_component_code) Sites,
                          catalog.repair_price Price,
                          catalog.price_type Price_Type,
                          catalog.repair_TAT TAT,
                          repair.repair_seq_id repair_seq_id,
                          catalog.incremental_price_ind incremental_price_ind,
                          catalog.incremental_tat_ind incremental_tat_ind,
           repair.repair_type repair_type
                   FROM
           crd_e_repair repair,
           crd_e_repair_catalog catalog
                   WHERE
           catalog.repair_seq_id = repair.repair_Seq_id
         AND     repair.repair_type <> 'CR'
         AND     (catalog.repair_end_date IS NULL or catalog.repair_end_date > SYSDATE)
                   AND    repair.module_seq_id = p_in_module
                   AND    repair.component_code = v_component_code
         AND     catalog.repair_display_seq_id = p_in_repair
                   AND    catalog.catalog_seq_id =  v_catalog_seq_id
         AND     catalog.repair_seq_id NOT IN
         (
            SELECT repair.repair_seq_id
            FROM
              crd_e_repair repair,
              crd_e_repair_catalog_hist catalog
            WHERE
              catalog.repair_seq_id = repair.repair_Seq_id
            AND     repair.repair_type <> 'CR'
            AND     catalog.staging_history_ind = ecrd_utils_pkg.G_STAGING
            AND     catalog.approved_rejected_date IS NULL
            AND     (catalog.repair_end_date IS NULL or catalog.repair_end_date > SYSDATE)
            AND     repair.module_seq_id = p_in_module
            AND     repair.component_code = v_component_code
            AND     catalog.repair_display_seq_id = p_in_repair
            AND     catalog.catalog_seq_id =  v_catalog_seq_id
           )
              )
         UNION
          SELECT * FROM(
                   SELECT catalog.repair_display_seq_id Display_Sequence,
                          repair.repair_description Repair_Description,
                          repair.repair_reference Repair_Reference,
                          ecrd_get_sites_fnc(p_in_module,v_component_code) Sites,
                          catalog.repair_price Price,
                          catalog.price_type Price_Type,
                          catalog.repair_TAT TAT,
           repair.repair_seq_id  repair_seq_id ,
                          catalog.incremental_price_ind incremental_price_ind,
                          catalog.incremental_tat_ind incremental_tat_ind,
           repair.repair_type repair_type
       FROM
           crd_e_repair_history repair,
           crd_e_repair_catalog_hist catalog
                 WHERE
         catalog.repair_seq_id = repair.repair_Seq_id
       AND  repair.repair_type <> 'CR'
            AND   (catalog.repair_end_date IS NULL or catalog.repair_end_date > SYSDATE)
       AND  repair.staging_history_ind = ecrd_utils_pkg.G_STAGING
       AND  repair.approved_rejected_date IS NULL
                 AND repair.module_seq_id = p_in_module
                 AND repair.component_code = v_component_code
       AND  catalog.repair_display_seq_id = p_in_repair
       AND  catalog.catalog_seq_id = v_catalog_seq_id
              )

         order by 1;

           ELSIF p_in_repair_type = 2
           THEN
               OPEN p_out_repair_details
               FOR
                   SELECT * FROM(
                   SELECT catalog.repair_display_seq_id Display_Sequence,
                          repair.repair_description Repair_Description,
                          repair.repair_reference Repair_Reference,
                          ecrd_get_sites_fnc(p_in_module, v_component_code) Sites,
                          catalog.repair_price Price,
                          catalog.price_type Price_Type,
                          catalog.repair_TAT TAT,
                          repair.repair_seq_id repair_seq_id,
                          catalog.incremental_price_ind incremental_price_ind,
                          catalog.incremental_tat_ind incremental_tat_ind,
           repair.repair_type repair_type
                   FROM
           crd_e_repair repair,
           crd_e_repair_catalog_hist catalog
                   WHERE
           catalog.repair_seq_id = repair.repair_Seq_id
         AND     repair.repair_type <> 'CR'
         AND     catalog.staging_history_ind = ecrd_utils_pkg.G_STAGING
         AND     catalog.approved_rejected_date IS NULL
         AND     (catalog.repair_end_date IS NULL or catalog.repair_end_date > SYSDATE)
         AND    UPPER(repair.REPAIR_DESCRIPTION) = UPPER(p_in_repair)
                   AND    repair.module_seq_id = p_in_module
                   AND    repair.component_code = v_component_code
                   AND    catalog.catalog_seq_id =  v_catalog_seq_id
              )
         UNION
                   SELECT * FROM(
                   SELECT catalog.repair_display_seq_id Display_Sequence,
                          repair.repair_description Repair_Description,
                          repair.repair_reference Repair_Reference,
                          ecrd_get_sites_fnc(p_in_module, v_component_code) Sites,
                          catalog.repair_price Price,
                          catalog.price_type Price_Type,
                          catalog.repair_TAT TAT,
                          repair.repair_seq_id repair_seq_id,
                          catalog.incremental_price_ind incremental_price_ind,
                          catalog.incremental_tat_ind incremental_tat_ind,
           repair.repair_type repair_type
                   FROM
           crd_e_repair repair,
           crd_e_repair_catalog catalog
                   WHERE
           catalog.repair_seq_id = repair.repair_Seq_id
         AND     repair.repair_type <> 'CR'
         AND     (catalog.repair_end_date IS NULL or catalog.repair_end_date > SYSDATE)
         AND     UPPER(repair.REPAIR_DESCRIPTION) = UPPER(p_in_repair)
                   AND    repair.module_seq_id = p_in_module
                   AND    repair.component_code = v_component_code
                   AND    catalog.catalog_seq_id =  v_catalog_seq_id
         AND     catalog.repair_seq_id NOT IN
         (
            SELECT repair.repair_seq_id
            FROM
              crd_e_repair repair,
              crd_e_repair_catalog_hist catalog
            WHERE
              catalog.repair_seq_id = repair.repair_Seq_id
            AND     repair.repair_type <> 'CR'
            AND     catalog.staging_history_ind = ecrd_utils_pkg.G_STAGING
            AND     catalog.approved_rejected_date IS NULL
            AND     (catalog.repair_end_date IS NULL or catalog.repair_end_date > SYSDATE)
            AND     UPPER(repair.REPAIR_DESCRIPTION) = UPPER(p_in_repair)
            AND     repair.module_seq_id = p_in_module
            AND     repair.component_code = v_component_code
            AND     catalog.catalog_seq_id =  v_catalog_seq_id
           )
              )
         UNION
          SELECT * FROM(
                   SELECT catalog.repair_display_seq_id Display_Sequence,
                          repair.repair_description Repair_Description,
                          repair.repair_reference Repair_Reference,
                          ecrd_get_sites_fnc(p_in_module,v_component_code) Sites,
                          catalog.repair_price Price,
                          catalog.price_type Price_Type,
                          catalog.repair_TAT TAT,
           repair.repair_seq_id  repair_seq_id ,
                          catalog.incremental_price_ind incremental_price_ind,
                          catalog.incremental_tat_ind incremental_tat_ind,
           repair.repair_type repair_type
       FROM
           crd_e_repair_history repair,
           crd_e_repair_catalog_hist catalog
                 WHERE
         catalog.repair_seq_id = repair.repair_Seq_id
       AND  repair.repair_type <> 'CR'
            AND   (catalog.repair_end_date IS NULL or catalog.repair_end_date > SYSDATE)
       AND  catalog.staging_history_ind = ecrd_utils_pkg.G_STAGING
       AND  catalog.approved_rejected_date IS NULL
       AND  UPPER(repair.REPAIR_DESCRIPTION) = UPPER(p_in_repair)
       AND  repair.module_seq_id = p_in_module
                 AND repair.component_code = v_component_code
       AND  catalog.catalog_seq_id = v_catalog_seq_id
              )

         order by 1;

          END IF;

  EXCEPTION
   WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20001,'ERROR IN ecrd_e_repair_pkg.ecrd_list_repairs_prc' ||SQLCODE ||  ' - ' || SQLERRM);

  END ecrd_search_repair_prc;

PROCEDURE ecrd_ind_or_grp_repairs_prc(
            p_in_cat_seq_id IN Crd_e_Repair_Catalog.CATALOG_SEQ_ID%TYPE,
            p_in_eng_model IN CRD_CRC_ENG_MDL_DISPLAY.ENG_MDL_NUMBER%TYPE,
            p_in_module IN Crd_crc_Module.MODULE_SEQ_ID%TYPE,
            p_in_ind_or_grp_type IN VARCHAR2,
            p_in_component IN crd_e_repair.COMPONENT_CODE%TYPE,
         p_in_cust_cat_seq_id IN crd_e_repair_catalog.catalog_seq_id%TYPE,
            p_out_repair_list OUT result_cursor
  )
  IS
--
  BEGIN
--
       IF p_in_ind_or_grp_type  = '1'
       THEN
               OPEN p_out_repair_list
               FOR
--
                   SELECT catalog.repair_display_seq_id "Display Sequence",
                          repair.repair_description "Repair Description",
                          repair.repair_reference "Repair Reference",
                          ecrd_get_repair_sites_fnc(repair.repair_seq_id) "Sites",
                          catalog.repair_price "Price",
                          catalog.price_type "Price Type",
                          catalog.repair_TAT "TAT",
                        repair.repair_seq_id repair_seq_id,
                        catalog.incremental_price_ind,
                  repair.repair_comments  rep_comment,
                  repair.repair_reference_format ref_format
               FROM Crd_e_Repair repair
                 ,Crd_e_Repair_Catalog catalog
               WHERE catalog.repair_seq_id = repair.repair_Seq_id
               AND catalog.catalog_seq_id = p_in_cat_seq_id
               AND repair.module_seq_id = p_in_module
               AND repair.component_code = p_in_component
               AND repair.repair_type = ecrd_utils_pkg.G_INDIVIDUAL_REPAIR
               AND (repair.repair_end_date IS NULL OR repair.repair_end_date > SYSDATE)
               AND NOT EXISTS (  SELECT cer.split_merge_seq_id
                                 FROM  crd_e_repair cer
                                      ,crd_e_repair_catalog cerc
                                 WHERE cer.repair_seq_id   = cerc.repair_seq_id
                                 AND repair.repair_Seq_id  = cer.split_merge_seq_id
                                 AND  cerc.catalog_seq_id  = p_in_cust_cat_seq_id
                                 AND cer.split_merge_seq_id IS NOT NULL
                                 AND cer.REPAIR_TYPE       = ecrd_utils_pkg.G_CHILD_REPAIR);
--
        ELSIF p_in_ind_or_grp_type = '2'
        THEN
           OPEN p_out_repair_list
              FOR
                SELECT catalog.repair_display_seq_id "Display Sequence",
                          repair.repair_description "Repair Description",
                          repair.repair_reference "Repair Reference",
                          ecrd_get_repair_sites_fnc(repair.repair_seq_id) "Sites",
                          catalog.repair_price "Price",
                          catalog.price_type "Price Type",
                          catalog.repair_TAT "TAT",
                        repair.repair_seq_id repair_seq_id,
                        catalog.incremental_price_ind,
                  repair.repair_comments  rep_comment,
                  repair.repair_reference_format ref_format
               FROM Crd_e_Repair repair
                 ,Crd_e_Repair_Catalog catalog
               WHERE catalog.repair_seq_id = repair.repair_Seq_id
               AND catalog.catalog_seq_id = p_in_cat_seq_id
               AND repair.module_seq_id = p_in_module
               AND repair.component_code = p_in_component
               AND repair.repair_type = ecrd_utils_pkg.G_PARENT_REPAIR
               AND (repair.repair_end_date IS NULL OR repair.repair_end_date > SYSDATE)
               AND NOT EXISTS ( SELECT cer2.parent_repair_seq_id
                                FROM    crd_e_repair cer
                                       ,crd_e_repair_catalog cerc
                                       ,crd_e_repair cer2
                                WHERE cer.repair_seq_id    = cerc.repair_seq_id
                                AND  cerc.catalog_seq_id   = p_in_cust_cat_seq_id
                                AND repair.repair_seq_id   = cer2.parent_repair_seq_id
                                AND cer.split_merge_seq_id IS NOT NULL
                                AND cer.split_merge_seq_id = cer2.repair_seq_id
                                AND cer.repair_type        = ecrd_utils_pkg.G_SPLIT_REPAIR);

--
        END IF;
  EXCEPTION
   WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20001,'ERROR IN ecrd_e_repair_pkg.ecrd_ind_or_grp_repairs_prc' ||SQLCODE ||  ' - ' || SQLERRM);

  END ecrd_ind_or_grp_repairs_prc;



   FUNCTION ecrd_get_repair_sites_fnc(
           p_in_repair_seq_id   IN crd_e_repair_cost.repair_seq_id%TYPE
         )
   RETURN VARCHAR2 IS
  sites_cur result_cursor;
  v_site_name VARCHAR2(1000):='';
  v_temp VARCHAR2(1000):='';
  v_counter NUMBER:=0;
  BEGIN
      open sites_cur
       FOR
         SELECT site_name

       from crd_location cl,
        crd_e_repair_cost cr

        where cr.repair_seq_id = p_in_repair_seq_id
AND cl.location_id = cr.location_id;

      loop
          fetch sites_cur into v_temp;
          exit when sites_cur%NOTFOUND;
          v_counter:=v_counter+1;
          if(v_counter=1)
          then
              v_site_name:=v_temp;
          else
              v_site_name:=v_site_name || ',' || v_temp;
          end if;

      end loop;
      return v_site_name;
  EXCEPTION
   WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20002,'ERROR IN ecrd_e_repair_pkg.ecrd_get_sites_fnc' ||SQLCODE ||  ' - ' || SQLERRM);
  END ecrd_get_repair_sites_fnc;
  /*
  */
PROCEDURE ecrd_ins_repcat_hist_prc(p_in_repair_seq_id  IN crd_e_repair_catalog.repair_seq_id%TYPE
                          ,p_in_cat_seq_id      IN    crd_e_repair_catalog.catalog_seq_id%TYPE
                           ,p_in_user_id       IN crd_e_repair_catalog.created_by%TYPE
                           )
AS
v_cnt number := 0;
BEGIN
-- 06-07-2006 patni checking the history data begin
select count(1)
into  v_cnt
from crd_e_repair_catalog_hist
where catalog_seq_id = p_in_cat_seq_id
and repair_seq_id = p_in_repair_seq_id
and STAGING_HISTORY_IND = ecrd_utils_pkg.g_history_record
and CHANGE_START_DATE = sysdate
and effective_date = 
(
select effective_date
from crd_e_repair_catalog
where repair_seq_id=p_in_repair_seq_id
        AND   catalog_seq_id = p_in_cat_seq_id
       AND (repair_end_date IS NULL OR repair_end_date > SYSDATE)
);

if v_cnt = 0 then
-- 06-07-2006 patni checking the history data End
INSERT INTO crd_e_repair_catalog_hist   --admin
      (
      catalog_seq_id,
      repair_seq_id,
      effective_date,
      staging_history_ind,
      repair_end_date,
      change_start_date,
      repair_price,
      incremental_price_ind,
      repair_tat,
      incremental_tat_ind,
      future_price,
      created_by,
      creation_date,
      last_update_date,
      last_updated_by,
      repair_display_seq_id,
      requested_by,
      requested_date,
      approv_reject_by,
      approved_rejected_date,
     approve_reject_status,
     rejection_comments ,
     price_type
      )
       (
      SELECT
     catalog_seq_id,
      repair_seq_id,
      effective_date,
      ecrd_utils_pkg.g_history_record,
      repair_end_date,
      SYSDATE,
      repair_price,
      incremental_price_ind,
      repair_tat,
      incremental_tat_ind,
      future_price,
      p_in_user_id,
      SYSDATE,
      SYSDATE,
      p_in_user_id,
      repair_display_seq_id,
      NULL,
      NULL,
      NULL,
      NULL,
     NULL,
     NULL,
     price_type
       FROM  crd_e_repair_catalog rep_cat
        WHERE
            rep_cat.repair_seq_id=p_in_repair_seq_id
        AND   rep_cat.catalog_seq_id = p_in_cat_seq_id
       AND (rep_cat.repair_end_date IS NULL OR rep_cat.repair_end_date > SYSDATE)
          );
          end if;
   EXCEPTION
          WHEN OTHERS
          THEN RAISE_APPLICATION_ERROR(-20002,'Error in ecrd_ins_repcat_hist_prc '||SQLERRM||' '||SQLCODE);
END  ecrd_ins_repcat_hist_prc;
/*
*/
PROCEDURE ecrd_ins_repcatcost_hist_prc(p_in_repair_seq_id  IN  crd_e_repair_cost.repair_seq_id%TYPE
                              ,p_in_module_id      IN  crd_e_repair_cost.module_seq_id%TYPE
                             , p_in_location_id   IN  crd_e_repair_cost.location_id%TYPE
                             ,p_in_component_code IN  crd_e_repair_cost.component_code%TYPE
                              ,p_in_user_id        IN  crd_e_repair_cost.created_by%TYPE
                           )
AS
BEGIN
    INSERT INTO crd_e_repair_cost_history
                        (
                         module_seq_id,
                         component_code,
                         repair_seq_id,
                          location_id,
                            staging_history_ind,
                             cost_change_start_date,
                             material_cost,
                             labor_hours,
                             requested_by,
                             created_by,
                             requested_date,
                             creation_date,
                             approv_reject_status,
                             last_update_date,
                             approv_reject_date,
                             last_updated_by,
                             reject_comments
                           )
                         (
                         SELECT
                           module_seq_id,
                           component_code,
                           repair_seq_id,
                           location_id,
                              ecrd_utils_pkg.g_history_record,
                             SYSDATE,
                             material_cost,
                             labour_hours,
                             NULL,
                             p_in_user_id,
                             NULL,
                             SYSDATE,
                             NULL,
                             SYSDATE,
                             NULL,
                             p_in_user_id,
                             NULL
                            FROM    crd_e_repair_cost
                          WHERE   module_seq_id = p_in_module_id
                            AND     repair_seq_id = p_in_repair_seq_id
                          AND     component_code = p_in_component_code
                          AND location_id = p_in_location_id
                          );

EXCEPTION
          WHEN OTHERS
          THEN RAISE_APPLICATION_ERROR(-20002,'Error in ecrd_ins_repcatcost_hist_prc '||SQLERRM||' '||SQLCODE);
END  ecrd_ins_repcatcost_hist_prc;
---------

PROCEDURE ecrd_save_pricing_info_prc
(
   p_in_cat_seq_id IN VARCHAR2,
   p_in_repair_seq_id IN VARCHAR2,
   p_in_user_id IN crd_e_repair.CREATED_BY%TYPE,
   p_in_incr_tat IN crd_e_repair_catalog.incremental_tat_ind%TYPE,
   p_in_tat IN VARCHAR2,
   p_in_incremental_price IN crd_e_repair_catalog.incremental_price_ind%TYPE,
   p_in_price IN VARCHAR2,
   p_in_price_type IN crd_e_repair_catalog.price_type%TYPE,
   p_in_future_price VARCHAR2,
   p_in_future_tat IN VARCHAR2,
   p_in_future_price_eff_date IN VARCHAR2,
   p_out_msg OUT VARCHAR2
)
IS
   CURSOR ecrd_get_child_repairs_cur(p_repair_seq_id CRD_E_REPAIR.REPAIR_SEQ_ID%TYPE)
   IS
   SELECT
      repair_seq_id
   FROM
      crd_e_repair
   WHERE
      parent_repair_seq_id = p_repair_seq_id AND
      (repair_end_date IS NULL OR TRUNC(repair_end_date) > TRUNC(SYSDATE));

   /* Patni 04-Sep-2006 - To get the repair attributes from the Settings table - Begin */
   CURSOR cur_repair_attributes
   IS
   SELECT CRD_E_SETTINGS_SEQ_ID,
          COLUMN_NAME
   FROM   CRD_E_SETTINGS
   WHERE  SETTING_ID = 1
   AND    UPPER(ACTIVE_IND) = 'Y';
   /* Patni 04-Sep-2006 - To get the repair attributes from the Settings table - End */   
      
   v_price crd_e_repair_catalog.repair_price%TYPE;
   v_future_price crd_e_repair_catalog.future_price%TYPE;
   v_repair_tat crd_e_repair_catalog.repair_tat%TYPE;
   v_repair_tat_ind crd_e_repair_catalog.incremental_tat_ind%TYPE;
   v_price_inc_ind crd_e_repair_catalog.incremental_price_ind%TYPE;
   v_org_price crd_e_repair_catalog.repair_price%TYPE;
   v_price_type crd_e_repair_catalog.price_type%TYPE;
   v_effective_date DATE := null;
   
   /* Patni 04-Sep-2006 - Declaring variables - Begin */
   v_crd_e_repair_catalog_seq_id    CRD_E_REPAIR_CATALOG.CRD_E_REPAIR_CATALOG_SEQ_ID%TYPE;   
   v_old_repair_price               CRD_E_REPAIR_CATALOG.REPAIR_PRICE%TYPE;   
   v_old_repair_tat                 CRD_E_REPAIR_CATALOG.REPAIR_TAT%TYPE;   
   v_settings_seq_id                CRD_E_SETTINGS.CRD_E_SETTINGS_SEQ_ID%TYPE;
   v_column_name                    CRD_E_SETTINGS.COLUMN_NAME%TYPE;
   v_settings_seq_arr               ECRD_UTILS_PKG.VARRAY_PART;
   v_settings_seq_id_data           VARCHAR2(10) := NULL;
   v_repair_modified                NUMBER       := 1;
   v_data_exist                     NUMBER       := 0;
   v_data_modified                  BOOLEAN      := FALSE;
   /* Patni 04-Sep-2006 - Declaring variables - End */      

BEGIN
     /* Patni 04-Sep-2006 - To get the current value of the repair attributes - Begin */
     v_crd_e_repair_catalog_seq_id := NULL;
     v_old_repair_price            := NULL;
     v_old_repair_tat              := NULL; 
          
     BEGIN
          SELECT CRD_E_REPAIR_CATALOG_SEQ_ID,
                 REPAIR_PRICE,
                 REPAIR_TAT
          INTO   v_crd_e_repair_catalog_seq_id,
                 v_old_repair_price,
                 v_old_repair_tat
          FROM   CRD_E_REPAIR_CATALOG
          WHERE  CATALOG_SEQ_ID = p_in_cat_seq_id
          AND    REPAIR_SEQ_ID  = p_in_repair_seq_id
          AND    (REPAIR_END_DATE IS NULL OR REPAIR_END_DATE > SYSDATE);
 
     EXCEPTION
     WHEN NO_DATA_FOUND THEN
          v_crd_e_repair_catalog_seq_id := NULL;
          v_old_repair_price            := NULL;
          v_old_repair_tat              := NULL;
     END;
     /* Patni 04-Sep-2006 - To get the current value of the repair attributes - End */              

   ecrd_ins_repcat_hist_prc
   (
      p_in_repair_seq_id,
      p_in_cat_seq_id,
      p_in_user_id
   );
/*
   IF TO_NUMBER(p_in_price) = 0
   THEN
      v_price := null;
   ELSE*/
      v_price := TO_NUMBER(p_in_price);
/* END IF;



   IF TO_NUMBER(p_in_future_price) = 0
   THEN
      v_future_price := null;
   ELSE*/
      v_future_price := TO_NUMBER(p_in_future_price);
-- END IF;

   SELECT
      --NVL(repair_tat,-1),
      repair_tat,
      incremental_tat_ind,
      incremental_price_ind,
      --NVL(repair_price,-1),
      repair_price,
      price_type
   INTO
      v_repair_tat,
      v_repair_tat_ind,
      v_price_inc_ind,
      v_org_price,
      v_price_type
   FROM
      crd_e_repair_catalog
   WHERE
      repair_seq_id = p_in_repair_seq_id AND
      catalog_seq_id = p_in_cat_seq_id AND
      (repair_end_date IS NULL OR repair_end_date > SYSDATE);

   UPDATE   crd_e_repair_catalog
   SET
      incremental_tat_ind = p_in_incr_tat,
      repair_tat = to_number(p_in_tat),
      incremental_price_ind=p_in_incremental_price,
      repair_price = v_price,
      price_type=p_in_price_type,
      future_price=v_future_price,
      future_tat=p_in_future_tat,
      future_effective_date= TO_DATE(p_in_future_price_eff_date,ecrd_utils_pkg.G_DATE_FORMAT),
      price_overwrite_flag_ind = ecrd_utils_pkg.G_YES,
      last_update_date=SYSDATE,
      last_updated_by= p_in_user_id
   WHERE
      catalog_seq_id = p_in_cat_seq_id
      AND  repair_seq_id = p_in_repair_seq_id
      AND (repair_end_date IS NULL OR repair_end_date > SYSDATE);

   IF((NVL(v_repair_tat,-1) <> to_number(NVL(p_in_tat,-1)))OR
      (v_repair_tat_ind <> p_in_incr_tat)OR
      (v_price_inc_ind <> p_in_incremental_price)OR
      (NVL(v_price,-1) <> NVL(v_org_price,-1))OR
      (v_price_type <> p_in_price_type))
   THEN
      UPDATE crd_e_repair_catalog
      SET
         effective_date = SYSDATE
      WHERE
         catalog_seq_id = p_in_cat_seq_id
         AND  repair_seq_id = p_in_repair_seq_id
         AND (repair_end_date IS NULL OR repair_end_date > SYSDATE);
   END IF;

   SELECT
      effective_date
   INTO
      v_effective_date
   FROM
      crd_e_repair_catalog
   WHERE
      catalog_seq_id = p_in_cat_seq_id
      AND  repair_seq_id = p_in_repair_seq_id
      AND (repair_end_date IS NULL OR repair_end_date > SYSDATE);

   -- Updating the Child repair with New Effective Date
   FOR crd_child_cur IN ecrd_get_child_repairs_cur(p_in_repair_seq_id)
   LOOP
      ecrd_ins_repcat_hist_prc
      (
         crd_child_cur.repair_seq_id,
         p_in_cat_seq_id,
         p_in_user_id
      );

      UPDATE crd_e_repair_catalog
      SET
         effective_date = v_effective_date,
         last_updated_by = p_in_user_id,
         last_update_date = SYSDATE
      WHERE
         catalog_seq_id = p_in_cat_seq_id
         AND  repair_seq_id = crd_child_cur.repair_seq_id
         AND (repair_end_date IS NULL OR repair_end_date > SYSDATE);
   END LOOP;

   
   /* Patni 04-Sep-2006 - To check if the repair attributes are modified - Begin */
   IF v_crd_e_repair_catalog_seq_id IS NOT NULL THEN
      v_settings_seq_id      := NULL;
      v_column_name          := NULL;

      -- Cursor to get the setting columns
      OPEN cur_repair_attributes; 
 
      BEGIN
           LOOP
               FETCH cur_repair_attributes INTO v_settings_seq_id,
                                                v_column_name;
               EXIT WHEN cur_repair_attributes%NOTFOUND;

               IF v_settings_seq_id_data IS NULL THEN
                  v_settings_seq_id_data := v_settings_seq_id || '^';
               ELSE
                  v_settings_seq_id_data := v_settings_seq_id_data || v_settings_seq_id || '^';
               END IF;
                       
               IF UPPER(v_column_name) = 'REPAIR_PRICE' THEN
                  SELECT COUNT(1)
                  INTO   v_repair_modified
                  FROM   CRD_E_REPAIR_CATALOG
                  WHERE  NVL(REPAIR_PRICE, 0) = NVL(v_old_repair_price, 0)
                  AND    CRD_E_REPAIR_CATALOG_SEQ_ID = v_crd_e_repair_catalog_seq_id;
             
                  IF v_repair_modified = 0 THEN
                     v_data_modified := TRUE;
                  END IF;
               END IF;
             
               IF UPPER(v_column_name) = 'REPAIR_TAT' THEN
                  SELECT COUNT(1)
                  INTO   v_repair_modified
                  FROM   CRD_E_REPAIR_CATALOG
                  WHERE  NVL(REPAIR_TAT, 0) = NVL(v_old_repair_tat, 0)
                  AND    CRD_E_REPAIR_CATALOG_SEQ_ID = v_crd_e_repair_catalog_seq_id;
             
                  IF v_repair_modified = 0 THEN
                     v_data_modified := TRUE;
                  END IF;
               END IF;
           END LOOP;
         
      EXCEPTION
      WHEN OTHERS THEN
           DBMS_OUTPUT.PUT_LINE('Error while fetching the repair attributes from CRD_E_SETTINGS : ' || SQLCODE || ' ' || SQLERRM);
      END;
 
      CLOSE cur_repair_attributes; 
    
      -- If the repair attributes are modified, the details are maintained in the transaction table     
      IF v_data_modified = TRUE THEN
         v_settings_seq_arr := ECRD_UTILS_PKG.string_to_array(v_settings_seq_id_data, '^');       
       
         IF v_settings_seq_arr(1) IS NOT NULL THEN
            v_data_exist := 0;

            SELECT COUNT(1)
            INTO   v_data_exist
            FROM   CRD_E_MODIFIED_DATA
            WHERE  CRD_E_SETTINGS_SEQ_ID       = TO_NUMBER(v_settings_seq_arr(1))
            AND    CRD_E_REPAIR_CATALOG_SEQ_ID = v_crd_e_repair_catalog_seq_id;

            IF v_data_exist = 0 THEN
               BEGIN
                    INSERT INTO CRD_E_MODIFIED_DATA
                               (
                                CRD_E_MOD_DATA_SEQ_ID,
                                CRD_E_SETTINGS_SEQ_ID,
                                CRD_E_REPAIR_CATALOG_SEQ_ID,
                                OLD_VALUE,
                                CREATED_BY,
                                CREATION_DATE,
                                LAST_UPDATE_DATE,
                                LAST_UPDATED_BY
                               )
                         VALUES(
                                CRD_E_MODIFIED_DATA_SEQ.NEXTVAL,
                                TO_NUMBER(v_settings_seq_arr(1)),
                                v_crd_e_repair_catalog_seq_id,
                                v_old_repair_price,
                                p_in_user_id,
                                SYSDATE,
                                SYSDATE,
                                p_in_user_id
                               );                              
               EXCEPTION
               WHEN OTHERS THEN
                    DBMS_OUTPUT.PUT_LINE('Error while inserting the details in CRD_E_MODIFIED_DATA : ' || SQLCODE || ' ' || SQLERRM);
               END;                
          
            ELSE
                BEGIN
                     UPDATE CRD_E_MODIFIED_DATA
                     SET    OLD_VALUE = v_old_repair_price,
                            LAST_UPDATED_BY  = p_in_user_id,
                            LAST_UPDATE_DATE = SYSDATE
                     WHERE  CRD_E_SETTINGS_SEQ_ID = TO_NUMBER(v_settings_seq_arr(1))
                     AND    CRD_E_REPAIR_CATALOG_SEQ_ID = v_crd_e_repair_catalog_seq_id;
             
                EXCEPTION
                WHEN OTHERS THEN
                     DBMS_OUTPUT.PUT_LINE('Error while updating the details in CRD_E_MODIFIED_DATA : ' || SQLCODE || ' ' || SQLERRM);
                END;
            END IF;
         END IF;

         IF v_settings_seq_arr(2) IS NOT NULL THEN
            v_data_exist := 0;

            SELECT COUNT(1)
            INTO   v_data_exist
            FROM   CRD_E_MODIFIED_DATA
            WHERE  CRD_E_SETTINGS_SEQ_ID       = TO_NUMBER(v_settings_seq_arr(2))
            AND    CRD_E_REPAIR_CATALOG_SEQ_ID = v_crd_e_repair_catalog_seq_id;

            IF v_data_exist = 0 THEN
               BEGIN
                    INSERT INTO CRD_E_MODIFIED_DATA
                               (
                                CRD_E_MOD_DATA_SEQ_ID,
                                CRD_E_SETTINGS_SEQ_ID,
                                CRD_E_REPAIR_CATALOG_SEQ_ID,
                                OLD_VALUE,
                                CREATED_BY,
                                CREATION_DATE,
                                LAST_UPDATE_DATE,
                                LAST_UPDATED_BY
                               )
                         VALUES(
                                CRD_E_MODIFIED_DATA_SEQ.NEXTVAL,
                                TO_NUMBER(v_settings_seq_arr(2)),
                                v_crd_e_repair_catalog_seq_id,
                                v_old_repair_tat,
                                p_in_user_id,
                                SYSDATE,
                                SYSDATE,
                                p_in_user_id
                               );
               EXCEPTION
               WHEN OTHERS THEN
                    DBMS_OUTPUT.PUT_LINE('Error while inserting the details in CRD_E_MODIFIED_DATA : ' || SQLCODE || ' ' || SQLERRM);
               END;                
                              
            ELSE
                BEGIN
                     UPDATE CRD_E_MODIFIED_DATA
                     SET    OLD_VALUE = v_old_repair_tat,
                            LAST_UPDATED_BY  = p_in_user_id,
                            LAST_UPDATE_DATE = SYSDATE
                     WHERE  CRD_E_SETTINGS_SEQ_ID = TO_NUMBER(v_settings_seq_arr(2))
                     AND    CRD_E_REPAIR_CATALOG_SEQ_ID = v_crd_e_repair_catalog_seq_id;
               
                EXCEPTION
                WHEN OTHERS THEN
                     DBMS_OUTPUT.PUT_LINE('Error while updating the details in CRD_E_MODIFIED_DATA : ' || SQLCODE || ' ' || SQLERRM);
                END;
            END IF;
         END IF;
      END IF;
    
      COMMIT;
   END IF;
   /* Patni 04-Sep-2006 - To check if the repair attributes are modified - End */
   
   p_out_msg := 'PRICING_UPDATION_SUCCESSFUL';


EXCEPTION WHEN OTHERS THEN
  ROLLBACK;
  p_out_msg := 'PRICING_UPDATION_FAILED';
  RAISE_APPLICATION_ERROR(-20002,'ERROR IN ecrd_repair_pkg.ecrd_save_pricing_info_prc**p_in_future_price_eff_date--'||p_in_future_price_eff_date||SQLCODE ||  ' - ' || SQLERRM);


END ecrd_save_pricing_info_prc;
------------
PROCEDURE ecrd_update_repair_details_prc(
   p_in_cat_seq_id IN VARCHAR2,
   p_in_component_code  IN    crd_e_component.component_code%TYPE,
   p_in_module_id    IN   VARCHAR2,
   p_in_repair_seq_id IN     VARCHAR2,
   p_in_repair_desc IN crd_e_repair.repair_description%TYPE,
   p_in_repair_volume IN crd_e_repair.repair_volume%TYPE,
   p_in_repair_eff_date IN VARCHAR2,
   p_in_repair_comment IN crd_e_repair.repair_comments%TYPE,
   p_in_repair_type IN crd_e_repair.repair_type%TYPE,
   p_in_repair_ref IN crd_e_repair.repair_reference%TYPE,
   p_in_repair_ref_format IN crd_e_repair.repair_reference_format%TYPE,

   p_in_rep_site_buff      IN LONG,
   p_in_child_rep_buff     IN LONG,
   p_in_tc_modify     IN VARCHAR2,

   p_in_incr_tat IN crd_e_repair_catalog.incremental_tat_ind%TYPE,
   p_in_tat IN VARCHAR2,
   p_in_incremental_price IN crd_e_repair_catalog.incremental_price_ind%TYPE,
   p_in_price IN VARCHAR2,
   p_in_price_type IN crd_e_repair_catalog.price_type%TYPE,
   p_in_display_seq IN      VARCHAR2,
   p_in_future_price VARCHAR2,
   p_in_future_tat IN VARCHAR2,
   p_in_future_price_tat_date IN VARCHAR2,
   p_in_user_id         IN    crd_e_repair.CREATED_BY%TYPE,
   p_in_user_role       IN     VARCHAR2,
    p_in_row_delimiter   IN   VARCHAR2,
    p_in_cols_delimiter   IN  VARCHAR2,
   p_out_message       OUT    VARCHAR2
   )
IS
v_count NUMBER :=0 ;
   tab_broken_rows  ecrd_utils_pkg.gtyp_buf_arr;
   tab_broken_cols  ecrd_utils_pkg.gtyp_buf_arr;
   v_row_count  NUMBER       := 0;
   v_index       NUMBER      := 0;
   v_details    VARCHAR2(2000)  := NULL;
   v_osb_nos    NUMBER :=0;
   v_repair_seq_id NUMBER :=0;
      v_repair_eff_date DATE := NULL;
  v_future_price_date DATE :=    NULL;
   v_repair_price crd_e_repair_catalog.repair_price%TYPE;
   v_future_repair_price crd_e_repair_catalog.future_price%TYPE;
   v_future_tat crd_e_repair_catalog.future_tat%TYPE;



   v_repair_tat_chk crd_e_repair_catalog.repair_tat%type;
   v_inc_tat_ind_chk  crd_e_repair_catalog.incremental_tat_ind%type;
   v_repair_price_chk crd_e_repair_catalog.repair_price%type;
   v_inc_price_ind_chk crd_e_repair_catalog.incremental_price_ind%type;
   v_price_type_chk  crd_e_repair_catalog.price_type%type;
   v_future_price_chk crd_e_repair_catalog.future_price%type;
   v_future_tat_chk crd_e_repair_catalog.future_tat%type;
  v_future_eff_date_chk  crd_e_repair_catalog.future_effective_date%type;

BEGIN
   v_repair_eff_date := to_date(p_in_repair_eff_date,ecrd_utils_pkg.G_DATE_FORMAT);
  v_future_price_date :=to_date(p_in_future_price_tat_date,ecrd_utils_pkg.G_DATE_FORMAT);

      /*IF TO_NUMBER(p_in_price) = 0
      THEN
         v_repair_price := null;
      ELSE*/
         v_repair_price := TO_NUMBER(p_in_price);
/*    END IF;

      IF TO_NUMBER(p_in_future_price) = 0
      THEN
         v_future_repair_price := null;
      ELSE*/
         v_future_repair_price := TO_NUMBER(p_in_future_price);
/*    END IF;


      IF TO_NUMBER(p_in_future_tat) = 0
      THEN
         v_future_tat := null;
      ELSE*/
         v_future_tat := TO_NUMBER(p_in_future_tat);
--    END IF;




     dbms_output.put_line('p_in_user_role'||p_in_user_role);
   IF  UPPER(p_in_user_role) = UPPER(ecrd_utils_pkg.G_ADMIN) OR UPPER(p_in_user_role) = UPPER(ecrd_utils_pkg.G_CSM)
   THEN
   BEGIN

      dbms_output.put_line('In Ecrd Admin'||p_in_cat_seq_id);
   ecrd_admin_update_rep_prc(
                     p_in_cat_seq_id ,
                     p_in_component_code ,
                     p_in_module_id,
                     p_in_repair_seq_id ,
                     p_in_repair_desc ,
                     p_in_repair_volume ,
                     p_in_repair_eff_date,
                     p_in_repair_comment ,
                     p_in_repair_type ,
                     p_in_repair_ref,
                     p_in_repair_ref_format ,
                     p_in_rep_site_buff,
                     p_in_child_rep_buff,
                     p_in_tc_modify     ,
                     p_in_incr_tat,
                     to_number(p_in_tat),
                     p_in_incremental_price,
                     v_repair_price,
                     p_in_price_type ,
                     p_in_display_seq ,
                     v_future_repair_price,
                     v_future_tat ,
                     p_in_future_price_tat_date,
                     p_in_user_id        ,
                     p_in_user_role      ,
                     p_in_row_delimiter ,
                     p_in_cols_delimiter
   );


   p_out_message:='REPAIR_MODIFIED_SUCCESSFULLY';
EXCEPTION WHEN OTHERS THEN
 ROLLBACK;

  RAISE_APPLICATION_ERROR(-20002,'-: ERROR IN ecrd_e_repair_pkg.ecrd_update_repair_details_prc' ||SQLCODE ||  ' - ' || SQLERRM);
 END;
ELSIF UPPER(p_in_user_role) = ecrd_utils_pkg.G_TC

THEN
                   dbms_output.put_line('In Ecrd TC');
   BEGIN

         SELECT COUNT(1)
         INTO v_count
         FROM crd_e_repair_history
         WHERE REPAIR_SEQ_ID  =  p_in_repair_seq_id
         AND STAGING_HISTORY_IND=ecrd_utils_pkg.G_STAGING
         AND approve_reject_status is null
         AND  (repair_end_date IS NULL OR repair_end_date > SYSDATE);

       dbms_output.put_line('Inside repair cost----updating repair tables '||v_count);
  IF v_count=1
  THEN
       dbms_output.put_line('Start Insering the data in repair hist ');
               UPDATE CRD_E_REPAIR_HISTORY
                     SET
                        CHANGE_START_DATE=sysdate,
                        REPAIR_TYPE =p_in_repair_type,
                        REPAIR_DESCRIPTION =p_in_repair_desc,
                        REPAIR_REFERENCE =p_in_repair_ref,
                        REPAIR_COMMENTS= p_in_repair_comment,
                        REPAIR_REFERENCE_FORMAT=p_in_repair_ref_format,
                        REPAIR_EFFECTIVE_DATE =v_repair_eff_date,
                        REQUESTED_DATE =sysdate ,
                        REPAIR_VOLUME =p_in_repair_volume,
                        CREATED_BY = p_in_user_id,
                        LAST_UPDATE_DATE = sysdate,
                        LAST_UPDATED_BY=p_in_user_id

                              WHERE
                                    component_code = p_in_component_code
                              AND   module_seq_id = p_in_module_id
                              AND   repair_seq_id=p_in_repair_seq_id
                               AND staging_history_ind=ecrd_utils_pkg.G_STAGING
                               AND approved_rejected_by is null;
       dbms_output.put_line('Start Insering the data in catalog repair hist ');

                     UPDATE CRD_E_REPAIR_CATALOG_HIST
                     SET
                              effective_date = v_repair_eff_date ,
                              change_start_date= sysdate,
                              repair_price = v_repair_price,
                              incremental_price_ind= p_in_incremental_price,
                              repair_tat= p_in_tat,
                              incremental_tat_ind =p_in_incr_tat,
                              price_type = p_in_price_type,
                              future_price=  v_future_repair_price,
                              future_effective_date=v_future_price_date ,
                              future_tat=v_future_tat,
                              created_by=p_in_user_id,
                              creation_date = sysdate,
                              last_update_date=sysdate,
                              last_updated_by=p_in_user_id,
                              repair_display_seq_id=p_in_display_seq,
                              requested_date=sysdate
                              WHERE
                               repair_seq_id=p_in_repair_seq_id
                               AND  catalog_seq_id = p_in_cat_seq_id
                               AND staging_history_ind=ecrd_utils_pkg.G_STAGING
                               AND approv_reject_by is null;

       dbms_output.put_line('deleting  the data in  repair hist ');
                 delete from crd_e_repair_history
                 where parent_repair_seq_id=p_in_repair_seq_id
                 AND staging_history_ind=ecrd_utils_pkg.G_STAGING
                  AND   component_code = p_in_component_code
                     AND   module_seq_id = p_in_module_id
                               AND approved_rejected_by is null;

                 delete from crd_e_repair_catalog_hist
                 where
                 repair_seq_id in (select repair_seq_id from crd_e_repair where parent_repair_seq_id=p_in_repair_seq_id
                                  AND  catalog_seq_id = p_in_cat_seq_id
                 AND staging_history_ind=ecrd_utils_pkg.G_STAGING
                   AND approv_reject_by is null
                  );

       dbms_output.put_line('deleting  the data in  repair hist ');

                   ecrd_utils_pkg.break_into_rows_s_prc(
                                p_in_child_rep_buff
                             ,p_in_row_delimiter
                             ,tab_broken_rows
                             );


                              v_row_count := tab_broken_rows.COUNT;
       dbms_output.put_line('Start of child loop ');
           FOR v_index IN 1..v_row_count
                     LOOP
                         --
                      v_details := tab_broken_rows(v_index);

                     ecrd_utils_pkg.break_into_cols_s_prc(
                                                              v_details,
                                                              p_in_cols_delimiter,
                                                              tab_broken_cols
                                                            );

                                       BEGIN
                                        SELECT MAX(repr.rpr_osb_unique_number)
                                        INTO   v_osb_nos
                                        FROM crd_e_repair repr
                                        WHERE repr.COMPONENT_CODE = p_in_component_code;
                                        EXCEPTION WHEN NO_DATA_FOUND THEN
                                          v_osb_nos := 0;
                                        END;

                                     v_osb_nos := v_osb_nos + 1;

                                      SELECT crd_e_repair_seq.nextval
                                                   INTO v_repair_seq_id
                                                   FROM dual;

                        INSERT INTO crd_e_repair_history
                        (
                                 REPAIR_SEQ_ID,
                                 STAGING_HISTORY_IND,
                                 CHANGE_START_DATE,
                                 COMPONENT_CODE,
                                 REPAIR_TYPE,
                                 MODULE_SEQ_ID,
                                 REPAIR_DESCRIPTION,
                                 REPAIR_REFERENCE,
                                 REPAIR_COMMENTS,
                                 REPAIR_REFERENCE_FORMAT,
                                 REPAIR_EFFECTIVE_DATE,
                                 REPAIR_END_DATE,
                                 REQUESTED_BY,
                                 APPROVED_REJECTED_BY,
                                 REQUESTED_DATE,
                                 APPROVED_REJECTED_DATE,
                                 REPAIR_VOLUME,
                                 APPROVE_REJECT_STATUS,
                                 REJECTION_COMMENTS,
                                 CREATION_DATE,
                                 CREATED_BY,
                                 LAST_UPDATE_DATE,
                                 LAST_UPDATED_BY,
                                 PARENT_REPAIR_SEQ_ID
                        )
                         VALUES
                        (
                           v_repair_seq_id,
                           ecrd_utils_pkg.G_STAGING,
                           sysdate,
                           p_in_component_code,
                           ecrd_utils_pkg.G_CHILD_REPAIR,
                           p_in_module_id,
                           tab_broken_cols(2),--desc
                           tab_broken_cols(3),--reference
                           tab_broken_cols(4),--comments
                           tab_broken_cols(5),--format
                           v_repair_eff_date  ,
                           NULL,
                           p_in_user_id,
                           NULL,
                           SYSDATE,
                           NULL,
                           NULL,
                           NULL,
                           NULL,
                           SYSDATE,
                           p_in_user_id,
                           SYSDATE,
                           p_in_user_id,
                           p_in_repair_seq_id
                         );


                      dbms_output.put_line('Inside loop after crd_e_repair_history  ');

                        INSERT INTO crd_e_repair_catalog_hist
                        (

                              catalog_seq_id,
                              repair_seq_id,
                              effective_date,
                              staging_history_ind,
                              change_start_date,
                              repair_price,
                              incremental_price_ind,
                              repair_tat,
                              incremental_tat_ind,
                              future_price,
                              created_by,
                              creation_date,
                              last_update_date,
                              last_updated_by,
                              repair_display_seq_id,
                              requested_by,
                              requested_date,
                              approv_reject_by,
                              approved_rejected_date,
                             approve_reject_status,
                             rejection_comments

                        )
                        VALUES
                        (
                              p_in_cat_seq_id,
                              v_repair_seq_id,
                              v_repair_eff_date,
                              ecrd_utils_pkg.G_STAGING,
                              sysdate,
                              NULL,
                              NULL,
                              NULL,
                              NULL,
                              NULL,
                              p_in_user_id,
                              SYSDATE,
                              SYSDATE,
                              p_in_user_id,
                              DECODE(tab_broken_cols(6),'','',TO_NUMBER(tab_broken_cols(6))),
                              p_in_user_id,
                              SYSDATE,
                              NULL,
                              NULL,
                             NULL,
                             NULL
                        );
      dbms_output.put_line('Inside loop after crd_e_repair_catalog hist  ');

    END LOOP;


      dbms_output.put_line('Now the Sites  ');
         /*INSERTING THE SITES*/

               DELETE FROM crd_e_repair_cost_history rp_cost
                  WHERE
                  MODULE_SEQ_ID =   p_in_module_id
                  AND COMPONENT_CODE=p_in_component_code
                  AND REPAIR_SEQ_ID=p_in_repair_seq_id
                  AND STAGING_HISTORY_IND =ecrd_utils_pkg.G_STAGING ;
      dbms_output.put_line('deleting ');

               ecrd_utils_pkg.break_into_rows_s_prc(
                                p_in_rep_site_buff
                             ,p_in_row_delimiter
                             ,tab_broken_rows
                             );


                     v_row_count := tab_broken_rows.COUNT;
                           dbms_output.put_line('----updating repair tables 3'||v_row_count);
                    FOR v_index IN 1..v_row_count
                     LOOP
                         --
                      v_details := tab_broken_rows(v_index);

                     ecrd_utils_pkg.break_into_cols_s_prc(
                             v_details,
                             p_in_cols_delimiter,
                             tab_broken_cols
                           );

                           dbms_output.put_line('Inside repair cost----updating repair tables '||tab_broken_cols(1));
                           dbms_output.put_line('Inside repair cost----updating repair tables 2'||tab_broken_cols(2));
                           dbms_output.put_line('Inside repair cost----updating repair tables 3'||tab_broken_cols(3));

                        INSERT INTO crd_e_repair_cost_history
                        (
                           module_seq_id,
                            component_code,
                           repair_seq_id,
                           location_id,
                            staging_history_ind,
                             cost_change_start_date,
                             material_cost,
                             labor_hours,
                             requested_by,
                             created_by,
                             requested_date,
                             creation_date,
                             approv_reject_status,
                             last_update_date,
                             approv_reject_date,
                             last_updated_by,
                             reject_comments
                         )

                         VALUES
                        (
                           p_in_module_id,
                            p_in_component_code,
                           p_in_repair_seq_id,
                           tab_broken_cols(1),
                            ecrd_utils_pkg.G_STAGING,
                             SYSDATE,
                             DECODE(tab_broken_cols(2),'','',TO_NUMBER(tab_broken_cols(2))),
                        DECODE(tab_broken_cols(3),'','',TO_NUMBER(tab_broken_cols(3))),
                             p_in_user_id,
                             p_in_user_id,
                             SYSDATE,
                             SYSDATE,
                             NULL,
                             SYSDATE,
                             NULL,
                             p_in_user_id,
                             NULL
                         );
                END LOOP;

     p_out_message:='REPAIR_MODIFIED_SUCCESSFULLY_TC';
  ELSE

         --Inserted to get all previous pricing values to check wherther the pricing information is changed by TC

                           SELECT
                           --NVL(cerh.repair_tat,-1),
                           cerh.repair_tat,
                           cerh.incremental_tat_ind,
                           --NVL(cerh.repair_price,-1),
                           cerh.repair_price,
                           cerh.incremental_price_ind,
                           cerh.price_type,
                           --NVL(cerh.future_price,-1),
                           cerh.future_price,
                           --NVL(cerh.future_tat,-1),
                           cerh.future_tat,
                           cerh.future_effective_date
                     INTO
                           v_repair_tat_chk,
                           v_inc_tat_ind_chk,
                           v_repair_price_chk,
                           v_inc_price_ind_chk,
                           v_price_type_chk,
                           v_future_price_chk,
                           v_future_tat_chk,
                           v_future_eff_date_chk
                     FROM crd_e_repair_catalog cerh
                     WHERE
                           catalog_seq_id = p_in_cat_seq_id
                     AND  repair_seq_id = p_in_repair_seq_id
                     AND (repair_end_date IS NULL OR repair_end_date > SYSDATE);



     IF NVL(v_repair_tat_chk,-1) <> to_number(NVL(p_in_tat,-1))
     OR v_inc_tat_ind_chk <> p_in_incr_tat
     OR NVL(v_repair_price_chk,-1) <> NVL(p_in_price,-1)
     OR v_inc_price_ind_chk <> p_in_incremental_price
     OR v_price_type_chk  <> p_in_price_type
     OR NVL(v_future_price_chk,-1)  <> NVL(p_in_future_price,-1)
     OR NVL(v_future_tat_chk,-1)  <> NVL(p_in_future_tat,-1)
     OR TRUNC(v_future_eff_date_chk)  <> TRUNC(v_future_price_date)
     OR p_in_tc_modify = 'false'
          THEN

                 dbms_output.put_line('In Ecrd TC '||p_in_tc_modify);
                    ecrd_tc_update_rep_prc(
                     to_number(p_in_cat_seq_id) ,
                     p_in_component_code ,
                     to_number(p_in_module_id),
                     to_number(p_in_repair_seq_id) ,
                     p_in_repair_desc ,
                     p_in_repair_volume ,
                     to_date(p_in_repair_eff_date,ecrd_utils_pkg.G_DATE_FORMAT),
                     p_in_repair_comment ,
                     p_in_repair_type ,
                     p_in_repair_ref ,
                     p_in_repair_ref_format ,

                     p_in_rep_site_buff,
                     p_in_child_rep_buff,
                     p_in_tc_modify     ,

                     p_in_incr_tat,
                     to_number(p_in_tat),
                     p_in_incremental_price,
                     v_repair_price,
                     p_in_price_type ,
                     to_number(p_in_display_seq) ,
                     v_future_repair_price,
                     v_future_tat,
                                                   to_date(p_in_future_price_tat_date,ecrd_utils_pkg.G_DATE_FORMAT),
                     p_in_user_id        ,
                     p_in_user_role      ,
                      p_in_row_delimiter ,
                      p_in_cols_delimiter

   );

			     p_out_message:='REPAIR_MODIFIED_SUCCESSFULLY_TC';
          ELSE
                         ecrd_admin_update_rep_prc(
                        to_number(p_in_cat_seq_id ),
                        p_in_component_code ,
                        to_number(p_in_module_id)    ,
                        to_number(p_in_repair_seq_id) ,
                        p_in_repair_desc ,
                        p_in_repair_volume ,
                                 p_in_repair_eff_date,
                        p_in_repair_comment ,
                        p_in_repair_type ,
                         p_in_repair_ref ,
                        p_in_repair_ref_format ,

                        p_in_rep_site_buff,
                        p_in_child_rep_buff,
                        p_in_tc_modify     ,

                        p_in_incr_tat,
                        to_number(p_in_tat) ,
                        p_in_incremental_price,
                        v_repair_price ,
                        p_in_price_type ,
                        to_number(p_in_display_seq) ,
                        v_future_repair_price,
                        v_future_tat ,
                                 p_in_future_price_tat_date,
                        p_in_user_id        ,
                        p_in_user_role      ,
                         p_in_row_delimiter ,
                         p_in_cols_delimiter
                        );

                    dbms_output.put_line('In Ecrd TC '||p_in_tc_modify);
                       p_out_message:='REPAIR_MODIFIED_SUCCESSFULLY';
           END IF; -- END OF tc data check*/
    END IF;   --- END OF SAME TC WHEN APPROVAL PENDING

EXCEPTION WHEN OTHERS THEN
 ROLLBACK;
 RAISE_APPLICATION_ERROR(-20002,'ERROR IN ecrd_repair_pkg.ecrd_update_repair_details_prc' ||SQLCODE ||  ' - ' || SQLERRM);
END;

END IF; -- END OF ADMIN ROLE CHECK

END ecrd_update_repair_details_prc;


PROCEDURE  ecrd_admin_update_rep_prc(
   p_in_cat_seq_id IN crd_e_repair_catalog.catalog_seq_id%TYPE,
   p_in_component_code  IN    crd_e_component.component_code%TYPE,
   p_in_module_id       IN    crd_e_component.module_seq_id%TYPE,
   p_in_repair_seq_id IN     crd_e_repair.repair_seq_id%TYPE,
   p_in_repair_desc IN crd_e_repair.repair_description%TYPE,
   p_in_repair_volume IN crd_e_repair.repair_volume%TYPE,
   p_in_repair_eff_date VARCHAR2,
   p_in_repair_comment IN crd_e_repair.repair_comments%TYPE,
   p_in_repair_type IN crd_e_repair.repair_type%TYPE,
   p_in_repair_ref IN crd_e_repair.repair_reference%TYPE,
   p_in_repair_ref_format IN crd_e_repair.repair_reference_format%TYPE,
   p_in_rep_site_buff      IN LONG,
   p_in_child_rep_buff     IN LONG,
   p_in_tc_modify     IN VARCHAR2,
   p_in_incr_tat IN crd_e_repair_catalog.incremental_tat_ind%TYPE,
   p_in_tat IN crd_e_repair_catalog.repair_tat%TYPE,
   p_in_incremental_price IN crd_e_repair_catalog.incremental_price_ind%TYPE,
   p_in_price IN crd_e_repair_catalog.repair_price%TYPE,
   p_in_price_type IN crd_e_repair_catalog.price_type%TYPE,
   p_in_display_seq IN crd_e_repair_catalog.repair_display_seq_id%TYPE,
   p_in_future_price IN crd_e_repair_catalog.future_price%TYPE,
   p_in_future_tat IN crd_e_repair_catalog.future_tat%TYPE,
   p_in_future_price_tat_date VARCHAR2,
   p_in_user_id         IN    crd_e_repair.CREATED_BY%TYPE,
   p_in_user_role       IN     VARCHAR2,
    p_in_row_delimiter   IN   VARCHAR2,
    p_in_cols_delimiter   IN  VARCHAR2
   )
AS
      CURSOR eCRD_get_Child_Repair--cursor  to populate all existing child repairs
               IS
               SELECT
                repair.REPAIR_SEQ_ID repair_id,
                 repair.COMPONENT_CODE component_cd,
                 repair.REPAIR_TYPE rep_type,
                 repair.MODULE_SEQ_ID mod_seq_id,
                repair.REPAIR_DESCRIPTION rep_desc,
                repair.REPAIR_REFERENCE rep_ref,
                repair.REPAIR_COMMENTS rep_comments,
                repair.REPAIR_REFERENCE_FORMAT rep_format,
                repair.REPAIR_EFFECTIVE_DATE rep_eff_date,
                repair.REPAIR_END_DATE rep_end_date,
                repair.REPAIR_VOLUME  rep_volume
              FROM  crd_e_repair repair
               WHERE    parent_repair_seq_id = p_in_repair_seq_id
               AND (repair_end_date IS NULL OR repair_end_date > SYSDATE);




    CURSOR eCRD_get_Repair_cost
     IS
          SELECT
         module_seq_id,
         component_code,
         repair_seq_id,
         LOCATION_ID,
         MATERIAL_COST,
         LABOUR_HOURS

        FROM    CRD_E_REPAIR_COST

        WHERE   module_seq_id = p_in_module_id
        AND       repair_seq_id = p_in_repair_seq_id
        AND     component_code = p_in_component_code;

        /* Patni 04-Sep-2006 - To get the repair attributes from the Settings table - Begin */
        CURSOR cur_repair_attributes
        IS
        SELECT CRD_E_SETTINGS_SEQ_ID,
               COLUMN_NAME
        FROM   CRD_E_SETTINGS
        WHERE  SETTING_ID = 1
        AND    UPPER(ACTIVE_IND) = 'Y';
        /* Patni 04-Sep-2006 - To get the repair attributes from the Settings table - End */
        
   tab_broken_rows  ecrd_utils_pkg.gtyp_buf_arr;
   tab_broken_cols  ecrd_utils_pkg.gtyp_buf_arr;
   v_row_count  NUMBER       := 0;
   v_index       NUMBER      := 0;
   v_details    VARCHAR2(2000)  := NULL;
   v_pos        NUMBER :=0;
    v_count      NUMBER :=0;
   v_temp       NUMBER :=0;
   v_location_str VARCHAR2(2000)  := NULL;
   v_osb_nos    NUMBER :=0;
   v_child_count NUMBER :=0;
   v_child_in_hist VARCHAR2(1) := NULL;
   v_repair_seq_id crd_e_repair.repair_seq_id%type;
   v_repair_eff_date DATE:=NULL;
   v_future_price_date DATE:=NULL;


      v_repair_tat crd_e_repair_catalog.repair_tat%type;
   v_inc_tat_ind  crd_e_repair_catalog.incremental_tat_ind%type;
   v_repair_price crd_e_repair_catalog.repair_price%type;
   v_inc_price_ind crd_e_repair_catalog.incremental_price_ind%type;
   v_price_type   crd_e_repair_catalog.price_type%type;
   v_future_price crd_e_repair_catalog.future_price%type;
   v_future_tat crd_e_repair_catalog.future_tat%type;
  v_future_eff_date   crd_e_repair_catalog.future_effective_date%type;
   v_repair_display_seq crd_e_repair_catalog.repair_display_seq_id%type;

   /* Patni 04-Sep-2006 - Declaring variables - Begin */
   v_crd_e_repair_catalog_seq_id    CRD_E_REPAIR_CATALOG.CRD_E_REPAIR_CATALOG_SEQ_ID%TYPE;   
   v_old_repair_price               CRD_E_REPAIR_CATALOG.REPAIR_PRICE%TYPE;   
   v_old_repair_tat                 CRD_E_REPAIR_CATALOG.REPAIR_TAT%TYPE;   
   v_settings_seq_id                CRD_E_SETTINGS.CRD_E_SETTINGS_SEQ_ID%TYPE;
   v_column_name                    CRD_E_SETTINGS.COLUMN_NAME%TYPE;
   v_settings_seq_arr               ECRD_UTILS_PKG.VARRAY_PART;
   v_settings_seq_id_data           VARCHAR2(10) := NULL;
   v_repair_modified                NUMBER       := 1;
   v_data_exist                     NUMBER       := 0;
   v_data_modified                  BOOLEAN      := FALSE;
   /* Patni 04-Sep-2006 - Declaring variables - End */      
   
   BEGIN
                       dbms_output.put_line('In Ecrd Admin Update  ');

         /* Patni 04-Sep-2006 - To get the current value of the repair attributes - Begin */
         v_crd_e_repair_catalog_seq_id := NULL;
         v_old_repair_price            := NULL;
         v_old_repair_tat              := NULL; 
          
         BEGIN
              SELECT CRD_E_REPAIR_CATALOG_SEQ_ID,
                     REPAIR_PRICE,
                     REPAIR_TAT
              INTO   v_crd_e_repair_catalog_seq_id,
                     v_old_repair_price,
                     v_old_repair_tat
              FROM   CRD_E_REPAIR_CATALOG
              WHERE  CATALOG_SEQ_ID = p_in_cat_seq_id
              AND    REPAIR_SEQ_ID  = p_in_repair_seq_id
              AND    (REPAIR_END_DATE IS NULL OR REPAIR_END_DATE > SYSDATE);
 
         EXCEPTION
         WHEN NO_DATA_FOUND THEN
              v_crd_e_repair_catalog_seq_id := NULL;
              v_old_repair_price            := NULL;
              v_old_repair_tat              := NULL;
         END;
         /* Patni 04-Sep-2006 - To get the current value of the repair attributes - End */              
                       
                       
   v_repair_eff_date := to_date(p_in_repair_eff_date,ecrd_utils_pkg.G_DATE_FORMAT);
  v_future_price_date :=     to_date(p_in_future_price_tat_date,ecrd_utils_pkg.G_DATE_FORMAT);




      dbms_output.put_line('Data Going in repair history Admin Update  ');
      INSERT INTO crd_e_repair_history --admin
      (
         REPAIR_SEQ_ID,
         STAGING_HISTORY_IND,
         CHANGE_START_DATE,
         COMPONENT_CODE,
         REPAIR_TYPE,
         MODULE_SEQ_ID,
         REPAIR_DESCRIPTION,
         REPAIR_REFERENCE,
         REPAIR_COMMENTS,
         REPAIR_REFERENCE_FORMAT,
         REPAIR_EFFECTIVE_DATE,
         REPAIR_END_DATE,
         REQUESTED_BY,
         APPROVED_REJECTED_BY,
         REQUESTED_DATE,
         APPROVED_REJECTED_DATE,
         REPAIR_VOLUME,
         APPROVE_REJECT_STATUS,
         REJECTION_COMMENTS,
         CREATION_DATE,
         CREATED_BY,
         LAST_UPDATE_DATE,
         LAST_UPDATED_BY,
         PARENT_REPAIR_SEQ_ID

       )
       (SELECT
       repair.repair_seq_id,
       ecrd_utils_pkg.G_HISTORY_RECORD,
       SYSDATE,
        repair.COMPONENT_CODE,
        repair.REPAIR_TYPE,
        repair.MODULE_SEQ_ID,
       repair.REPAIR_DESCRIPTION,
       repair.REPAIR_REFERENCE,
       repair.REPAIR_COMMENTS,
      repair.REPAIR_REFERENCE_FORMAT,
       repair.REPAIR_EFFECTIVE_DATE,
       NULL,
       NULL,
         NULL,
         NULL,
         NULL,
       repair.REPAIR_VOLUME,
         NULL,
         NULL,
         SYSDATE,
         p_in_user_id,
         SYSDATE,
         p_in_user_id,
       repair.PARENT_REPAIR_SEQ_ID
        FROM  crd_e_repair repair
        WHERE repair.REPAIR_SEQ_ID=p_in_repair_seq_id
        AND repair.component_code = p_in_component_code
        AND repair.module_seq_id = p_in_module_id
        AND (repair.repair_end_date IS NULL OR repair.repair_end_date > SYSDATE)
        );

               dbms_output.put_line('After data  in repair history    ');


        dbms_output.put_line('main data in Repair catalog  added in repair history    ');


--  ecrd_repair_pkg.ecrd_ins_repcat_hist_prc(p_in_repair_seq_id,p_in_cat_seq_id,p_in_user_id);



        dbms_output.put_line('DATA  ADDED IN crd_e_repair_catalog_hist');




        dbms_output.put_line('main data in Repair cost history  added in repair history');

                        INSERT INTO CRD_E_REPAIR_COST_HISTORY
                        (
                         module_seq_id,
                         component_code,
                         repair_seq_id,
                          LOCATION_ID,
                            STAGING_HISTORY_IND,
                             COST_CHANGE_START_DATE,
                             MATERIAL_COST,
                             LABOR_HOURS,
                             REQUESTED_BY,
                             CREATED_BY,
                             REQUESTED_DATE,
                             CREATION_DATE,
                             APPROV_REJECT_STATUS,
                             LAST_UPDATE_DATE,
                             APPROV_REJECT_DATE,
                             LAST_UPDATED_BY,
                             REJECT_COMMENTS

                           )
                         (
                         SELECT
                           module_seq_id,
                           component_code,
                           repair_seq_id,
                           LOCATION_ID,
                              ecrd_utils_pkg.G_HISTORY_RECORD,
                             SYSDATE,
                             MATERIAL_COST,
                             LABOUR_HOURS,
                             NULL,
                             p_in_user_id,
                             NULL,
                             SYSDATE,
                             NULL,
                             SYSDATE,
                             NULL,
                             p_in_user_id,
                             NULL

                            FROM    CRD_E_REPAIR_COST

                          WHERE   module_seq_id = p_in_module_id
                            AND     repair_seq_id = p_in_repair_seq_id
                          AND     component_code = p_in_component_code
                          );

   dbms_output.put_line('nOW DATA GOING For  childs data  in repair ');
   dbms_output.put_line('For  childs data  in repair history');
   IF p_in_repair_type=ecrd_utils_pkg.G_PARENT_REPAIR OR p_in_repair_type=ecrd_utils_pkg.G_SPECIAL_GROUP_REPAIR OR p_in_repair_type=ecrd_utils_pkg.G_MERGE_REPAIR
   THEN

            FOR child_repair IN eCRD_get_Child_Repair --check if the child previously exists in the table
            LOOP

                     ecrd_utils_pkg.break_into_rows_s_prc(
                         p_in_child_rep_buff
                        ,p_in_row_delimiter
                        ,tab_broken_rows
                        );

                              v_row_count := tab_broken_rows.COUNT;
                              v_child_in_hist:='N';
                    FOR v_index IN 1..v_row_count
                     LOOP

                              v_details := tab_broken_rows(v_index);
                              ecrd_utils_pkg.break_into_cols_s_prc(
                              v_details,
                              p_in_cols_delimiter,
                              tab_broken_cols
                                );
                                   dbms_output.put_line('  tab_broken_cols(1)--------------+++++++++>'||tab_broken_cols(1));
                                   dbms_output.put_line('  rep_seq_id.repair_id--------------+++++>'||child_repair.repair_id);
                              IF (tab_broken_cols(1) <>' ')
                              THEN

                                    IF (child_repair.repair_id=to_number(tab_broken_cols(1)))
                                    THEN
                                    v_child_in_hist:='Y';/* Record  for update*/
                                    dbms_output.put_line('  MATCH FOUND');
                                    dbms_output.put_line('  v_child_in_hist-------------->'||v_child_in_hist);
                                    exit;
                                    ELSE
                                    v_child_in_hist:='N';

                                    END IF;

                              END IF;
                     END LOOP;
                        dbms_output.put_line('  end of loop for checking the match-------------->');
                       dbms_output.put_line('  v_child_in_hist-------------->'||v_child_in_hist);
                                         /*Insert Record in history Record */

                                 INSERT INTO crd_e_repair_history            --admin
                                                (
                                                   REPAIR_SEQ_ID,
                                                   STAGING_HISTORY_IND,
                                                   CHANGE_START_DATE,
                                                   COMPONENT_CODE,
                                                   REPAIR_TYPE,
                                                   MODULE_SEQ_ID,
                                                   REPAIR_DESCRIPTION,
                                                   REPAIR_REFERENCE,
                                                   REPAIR_COMMENTS,
                                                   REPAIR_REFERENCE_FORMAT,
                                                   REPAIR_EFFECTIVE_DATE,
                                                   REPAIR_END_DATE,
                                                   REQUESTED_BY,
                                                   APPROVED_REJECTED_BY,
                                                   REQUESTED_DATE,
                                                   APPROVED_REJECTED_DATE,
                                                   REPAIR_VOLUME,
                                                   APPROVE_REJECT_STATUS,
                                                   REJECTION_COMMENTS,
                                                   CREATION_DATE,
                                                   CREATED_BY,
                                                   LAST_UPDATE_DATE,
                                                   LAST_UPDATED_BY,
                                                   PARENT_REPAIR_SEQ_ID

                                                 )
                                                 VALUES
                                                 (
                                                 child_repair.repair_id,
                                                 ecrd_utils_pkg.G_HISTORY_RECORD,
                                                 SYSDATE,
                                                  child_repair.component_cd,
                                                  child_repair.rep_type,
                                                  child_repair.mod_seq_id,
                                                 child_repair.rep_desc,
                                                 child_repair.rep_ref,
                                                 child_repair.rep_comments,
                                                 child_repair.rep_format,
                                                 child_repair.rep_eff_date,
                                                 NULL,
                                                 NULL,
                                                 NULL,
                                                   NULL,
                                                   NULL,
                                                 child_repair.rep_volume,
                                                   NULL,
                                                   NULL,
                                                   SYSDATE,
                                                   p_in_user_id,
                                                   SYSDATE,
                                                   p_in_user_id,
                                                   p_in_repair_seq_id
                                                  );


                ecrd_repair_pkg.ecrd_ins_repcat_hist_prc(child_repair.repair_id,p_in_cat_seq_id,p_in_user_id);


                              IF v_child_in_hist = 'N' /* Condition to disable the recoprd */
                              THEN
                           dbms_output.put_line('  v_child_in_hist condition******-------------->'||v_child_in_hist);
                           dbms_output.put_line('  Disable the existing Record******-------------->'||child_repair.repair_id);
                           dbms_output.put_line('Disable the existing Record');

                                      /*Disable the existing Record */

                                                   UPDATE   crd_e_repair
                                                         SET
                                                            repair_end_date=SYSDATE+1
                                                         WHERE
                                                            repair_seq_id=child_repair.repair_id
                                                            AND (repair_end_date IS NULL OR repair_end_date > SYSDATE);



                                                   UPDATE   crd_e_repair_catalog
                                                         SET
                                                            repair_end_date=SYSDATE+1
                                                         WHERE
                                                           catalog_seq_id = p_in_cat_seq_id
                                                         AND   repair_seq_id=child_repair.repair_id
                                                            AND (repair_end_date IS NULL OR repair_end_date > SYSDATE);

                              END IF;
      END LOOP;--CURSOR LOOP END


   /*All Child repairs deleted are saved in the history*/
     dbms_output.put_line('All Child repairs deleted are saved in the history');
     dbms_output.put_line('Now update the record or add them in th data base ');

         ecrd_utils_pkg.break_into_rows_s_prc(
             p_in_child_rep_buff
            ,p_in_row_delimiter
            ,tab_broken_rows
            );

      v_row_count := tab_broken_rows.COUNT;
      FOR v_index IN 1..v_row_count
      LOOP

                v_details := tab_broken_rows(v_index);
         ecrd_utils_pkg.break_into_cols_s_prc(
                    v_details,
                  p_in_cols_delimiter,
                    tab_broken_cols
                    );

         SELECT count(rowid) INTO v_child_count  FROM crd_e_repair where repair_seq_id =to_number(tab_broken_cols(1));

         IF v_child_count=1
         THEN
           dbms_output.put_line('Updating the childs  --------------------------1------------------------------>>>  '||tab_broken_cols(1));
               UPDATE   crd_e_repair
               SET
                     repair_description = tab_broken_cols(2),
                     repair_comments = tab_broken_cols(4),
                     /*19-Jan-2005
                        Change No 1
                        Patni Offshore Development
                        When updating the repair effective date should not get updated
                     repair_effective_date=v_repair_eff_date,
                        End 10-Jan-2005
                        Change No 1
                     */
                     repair_volume= p_in_repair_volume,
                     last_updated_by=p_in_user_id,
                     last_update_date = SYSDATE,
                     repair_reference=tab_broken_cols(3),
                     repair_reference_format = tab_broken_cols(5)

               WHERE
                     component_code = p_in_component_code
               AND   module_seq_id = p_in_module_id
               AND   repair_seq_id=to_number(tab_broken_cols(1))
                AND (repair_end_date IS NULL OR repair_end_date > SYSDATE);
           dbms_output.put_line('Updating the childs  ------------------------------------2-------------------->>>  '||tab_broken_cols(1));

                  UPDATE   crd_e_repair_catalog
                     SET
                           repair_display_seq_id=TO_NUMBER(tab_broken_cols(6)),
                           /*
                           Start 10-Jan-2005
                           Change No 2
                           Patni Offshore Development
                        When updating the price the repair price effective date should get updated
                        with SYSDATE
                           */
--                           effective_date =SYSDATE, Commented for not updating the effective date as it is handled in the later section of this proc
                           /*
                           End 10-Jan-2005
                           Change No 2
                           */

						   -- 03-May-2006 Patni - Should update Effective Date to SYSDATE - Begin
						   effective_Date = SYSDATE,
				   	       -- 03-May-2006 Patni - Should update Effective Date to SYSDATE - End

                           last_update_date=SYSDATE,
                           last_updated_by= p_in_user_id
                     WHERE
                           catalog_seq_id = p_in_cat_seq_id
                     AND  repair_seq_id = to_number(tab_broken_cols(1))

                      AND (repair_end_date IS NULL OR repair_end_date > SYSDATE);
           dbms_output.put_line('Updating the childs  ---------------------------------------3----------------->>>  '||tab_broken_cols(1));

         ELSE



                  dbms_output.put_line('New  childs  -------------------------------------------------------->>>  ');
                        BEGIN
                         SELECT MAX(repr.rpr_osb_unique_number)
                         INTO   v_osb_nos
                         FROM crd_e_repair repr
                         WHERE repr.COMPONENT_CODE = p_in_component_code;
                         EXCEPTION WHEN NO_DATA_FOUND THEN
                           v_osb_nos := 0;
                         END;
                  dbms_output.put_line('New  childs  -------------------------------------------------------->>>  ');
          v_osb_nos := v_osb_nos + 1;

           SELECT crd_e_repair_seq.nextval
                        INTO v_repair_seq_id
                        FROM dual;
                  dbms_output.put_line('New  childs  -------------------------------------------------------->>>  '||v_repair_seq_id);
                  dbms_output.put_line('New  childs  -------------------------------------------------------->>>  '||tab_broken_cols(3));
                  dbms_output.put_line('New  childs  -------------------------------------------------------->>>  '||tab_broken_cols(4));
                  dbms_output.put_line('New  childs  -------------------------------------------------------->>>  '||tab_broken_cols(5));




   INSERT INTO crd_e_repair
         (
            repair_seq_id,
            module_seq_id,
            component_code,
            repair_type,
            repair_description,
            parent_repair_seq_id,
            repair_reference,
            repair_comments,
            repair_reference_format,
            repair_effective_date,
            repair_volume,
            repair_end_date,
            created_by,
            rpr_osb_unique_number,
            creation_date,
            last_update_date,
            last_updated_by,
            split_merge_seq_id
         )
          VALUES
         (
            v_repair_seq_id,
            p_in_module_id ,
            p_in_component_code  ,
            ecrd_utils_pkg.G_CHILD_REPAIR,
            tab_broken_cols(2),
            p_in_repair_seq_id,
            tab_broken_cols(3),
            tab_broken_cols(4),
            tab_broken_cols(5),
            /*19-jan-2005
            v_repair_eff_date,
            */
            SYSDATE,
            p_in_repair_volume,
            NULL,
            p_in_user_id,
            v_osb_nos,
            SYSDATE,
            SYSDATE,
            p_in_user_id,
            NULL
          );

            dbms_output.put_line('New  childs  -------------------------------------------------------->>>  ');
            dbms_output.put_line('New  childs  -------------------------------done------------------------->>> '||v_repair_seq_id);
            dbms_output.put_line('New  childs  -------------------------------done------------------------->>> '||v_repair_eff_date);
         dbms_output.put_line('New  childs  -------------------------------done------------------------->>>  '||  TO_NUMBER(tab_broken_cols(6)));
      INSERT INTO crd_e_repair_catalog
         (
                /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - Begin */
                crd_e_repair_catalog_seq_id,
                /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - End */
                repair_seq_id,
               catalog_seq_id,
               effective_date,
               repair_price,
               incremental_price_ind,
               repair_tat,
               incremental_tat_ind,
               future_price,
               future_effective_date,
               price_type,
               repair_end_date,
               repair_display_seq_id,
               future_tat,
               price_overwrite_flag_ind,
               created_by,
               creation_date,
               last_update_date,
               last_updated_by
         )
          VALUES
         (
            /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - Begin */
            crd_e_repair_catalog_seq.nextval,
            /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - End */
            v_repair_seq_id,
               p_in_cat_seq_id,
               /*19-Jan-2005
               v_repair_eff_date,
               */
               SYSDATE,
               NULL,
               NULL,
               NULL,
               NULL,
               NULL,
               NULL,
               NULL,
               NULL,
               TO_NUMBER(tab_broken_cols(6)),
               NULL,
               NULL,
               p_in_user_id,
               SYSDATE,
               SYSDATE,
               p_in_user_id
          );
                           dbms_output.put_line('New  childs  -------------------------------done------------------------->>>  ');
         END IF;
                    dbms_output.put_line('End of loop ');
      END LOOP;
   END IF;
                    dbms_output.put_line('Start of Update ');
    dbms_output.put_line('updating repair tables parent data--repair rep seq id'||p_in_repair_seq_id||'module'||p_in_module_id);

      UPDATE   crd_e_repair
      SET
            REPAIR_DESCRIPTION = p_in_repair_desc,
            repair_volume = p_in_repair_volume,
            /*19-Jan-2005
                 Change No 1
               Patni Offshore Development
                 When updating the repair effective date should not get updated
            repair_effective_date=v_repair_eff_date,
               End 10-Jan-2005
               Change No 1
              */
            repair_comments = p_in_repair_comment,
            last_updated_by=p_in_user_id,
            last_update_date = SYSDATE,
            repair_reference=p_in_repair_ref,
            repair_reference_format = p_in_repair_ref_format
      WHERE
            component_code = p_in_component_code
      AND   module_seq_id = p_in_module_id
      AND   repair_seq_id=p_in_repair_seq_id
      AND (repair_end_date IS NULL OR repair_end_date > SYSDATE);

      -- 03-May-2006 Patni - Updating Repair Catalog with Effective Date as SYSDATE for the Parent Repair and Child Repairs - Begin
      UPDATE crd_e_repair_catalog
      SET
			 effective_date = SYSDATE,
             last_updated_by = p_in_user_id,
             last_update_date = SYSDATE
	  WHERE
             catalog_seq_id = p_in_cat_seq_id
      AND    repair_seq_id = p_in_repair_seq_id
      AND    (repair_end_date IS NULL OR repair_end_date > SYSDATE);


      UPDATE crd_e_repair_catalog
      SET
			 effective_date = SYSDATE,
             last_updated_by = p_in_user_id,
             last_update_date = SYSDATE
	  WHERE
             catalog_seq_id = p_in_cat_seq_id
      AND    repair_seq_id IN (
                               SELECT repair_seq_id
                               FROM crd_e_repair
                               WHERE parent_repair_seq_id = p_in_repair_seq_id
                               AND   (repair_end_date IS NULL OR repair_end_date > SYSDATE)
                              )
      AND    (repair_end_date IS NULL OR repair_end_date > SYSDATE);
      -- 03-May-2006 Patni - Updating Repair Catalog with Effective Date as SYSDATE for the Parent Repair and Child Repairs - End

          dbms_output.put_line('updating repair tables catalog ');
                     SELECT
                           --NVL(cerh.repair_tat,-1),
                           cerh.repair_tat,
                           cerh.incremental_tat_ind,
                           --NVL(cerh.repair_price,-1),
                           cerh.repair_price,
                           cerh.incremental_price_ind,
                           cerh.price_type,
                           --NVL(cerh.future_price,-1),
                           cerh.future_price,
                           --NVL(cerh.future_tat,-1),
                           cerh.future_tat,
                           cerh.future_effective_date,
                           cerh.repair_display_seq_id
                     INTO
                           v_repair_tat,
                           v_inc_tat_ind,
                           v_repair_price,
                           v_inc_price_ind,
                           v_price_type,
                           v_future_price,
                           v_future_tat,
                           v_future_eff_date,
                           v_repair_display_seq
                     FROM crd_e_repair_catalog cerh
                     WHERE
                           catalog_seq_id = p_in_cat_seq_id
                     AND  repair_seq_id = p_in_repair_seq_id
                     AND (repair_end_date IS NULL OR repair_end_date > SYSDATE);


     IF NVL(v_repair_tat,-1) <> to_number(NVL(p_in_tat,-1))
     OR v_inc_tat_ind <> p_in_incr_tat
     OR NVL(v_repair_price,-1) <> NVL(p_in_price,-1)
     OR v_inc_price_ind <> p_in_incremental_price
     OR v_price_type  <> p_in_price_type
     OR NVL(v_future_price,-1)  <> NVL(p_in_future_price,-1)
     OR NVL(v_future_tat,-1)  <> NVL(p_in_future_tat,-1)
     OR TRUNC(v_future_eff_date)  <> TRUNC(v_future_price_date)
     OR v_repair_display_seq <> p_in_display_seq
       THEN
               --Get all the pricing information for checking if any thing is modified

             ecrd_repair_pkg.ecrd_ins_repcat_hist_prc(p_in_repair_seq_id,p_in_cat_seq_id,p_in_user_id);

                         dbms_output.put_line('updating repair tables catalog ');


   UPDATE   crd_e_repair_catalog
      SET
            incremental_tat_ind = p_in_incr_tat,
            repair_tat = TO_NUMBER(p_in_tat),
             /*
                Start 10-Jan-2005
              Change No 2
                Patni Offshore Development
             When updating the price the repair price effective date should get updated
             with SYSDATE
             */
--                                     effective_date =SYSDATE, Commeneted bcoz the conditions for changing effective date is handled later in this proc
             /*
             End 10-Jan-2005
             Change No 2
             */
            incremental_price_ind=p_in_incremental_price,
            repair_price = p_in_price ,
            price_type=p_in_price_type,
            repair_display_seq_id=p_in_display_seq,
            future_price=p_in_future_price ,
            future_tat=p_in_future_tat,
            future_effective_date= v_future_price_date,

            last_update_date=SYSDATE,
            last_updated_by= p_in_user_id
      WHERE
            catalog_seq_id = p_in_cat_seq_id
      AND  repair_seq_id = p_in_repair_seq_id
      AND (repair_end_date IS NULL OR repair_end_date > SYSDATE);

                  UPDATE   crd_e_repair_catalog
                  SET
                           last_update_date=SYSDATE,
                           last_updated_by= p_in_user_id
                  WHERE
                           catalog_seq_id = p_in_cat_seq_id
                           AND   repair_seq_id IN (
                                                      SELECT repair_seq_id
                                                      FROM crd_e_repair
                                                      WHERE parent_repair_seq_id = p_in_repair_seq_id
                                                   )
                        AND (repair_end_date IS NULL OR repair_end_date > SYSDATE);


               --This Updates the effective date to sysdate whenever pri4cing information is modified by Admin
                        IF NVL(v_repair_tat,-1) <> TO_NUMBER(NVL(p_in_tat,-1))
                        OR v_inc_tat_ind <> p_in_incr_tat
                        OR NVL(v_repair_price,-1) <> NVL(p_in_price,-1)
                        OR v_inc_price_ind <> p_in_incremental_price
                        OR v_price_type  <> p_in_price_type
                        THEN
                                    UPDATE   crd_e_repair_catalog
                                       SET effective_date=SYSDATE
                                    WHERE
                                             catalog_seq_id = p_in_cat_seq_id
                                       AND  repair_seq_id = p_in_repair_seq_id
                                       AND (repair_end_date IS NULL OR repair_end_date > SYSDATE);

                                    UPDATE   crd_e_repair_catalog
                                       SET effective_date=SYSDATE
                                    WHERE
                                             catalog_seq_id = p_in_cat_seq_id
                                       AND   repair_seq_id IN (
                                                               SELECT repair_seq_id
                                                               FROM crd_e_repair
                                                               WHERE parent_repair_seq_id = p_in_repair_seq_id
                                                               )
                                       AND (repair_end_date IS NULL OR repair_end_date > SYSDATE);


                        END IF;
         END IF;

       dbms_output.put_line('updating repair tables catalog done ');

           dbms_output.put_line('Inside repair cost----updating repair tables '||p_in_rep_site_buff);
            dbms_output.put_line('Inside repair cost----updating repair tables 2'||p_in_rep_site_buff);


      dbms_output.put_line('deleteing data from repair cost history Repair cost history  added in repair history    ');

DELETE FROM crd_e_repair_cost rp_cost
   WHERE
   MODULE_SEQ_ID =   p_in_module_id
   AND COMPONENT_CODE=p_in_component_code
   AND REPAIR_SEQ_ID=p_in_repair_seq_id;



ecrd_utils_pkg.break_into_rows_s_prc(
                 p_in_rep_site_buff
              ,p_in_row_delimiter
              ,tab_broken_rows
              );


      v_row_count := tab_broken_rows.COUNT;
            dbms_output.put_line('Inside repair cost----updating repair tables 3'||v_row_count);
     FOR v_index IN 1..v_row_count
      LOOP
          --
       v_details := tab_broken_rows(v_index);

      ecrd_utils_pkg.break_into_cols_s_prc(
              v_details,
              p_in_cols_delimiter,
              tab_broken_cols
            );



            dbms_output.put_line('Inside repair cost----updating repair tables '||tab_broken_cols(1));
            dbms_output.put_line('Inside repair cost----updating repair tables 2'||tab_broken_cols(2));
            dbms_output.put_line('Inside repair cost----updating repair tables 3'||tab_broken_cols(3));
         INSERT INTO crd_e_repair_cost
         (
            module_seq_id,
            component_code,
            repair_seq_id,
            location_id,
            material_cost,
            labour_hours,
            created_by,
            creation_date,
            last_update_date,
            last_updated_by
         )
          VALUES
         (
            p_in_module_id,
            p_in_component_code,
            p_in_repair_seq_id,
            tab_broken_cols(1),
            TO_NUMBER(tab_broken_cols(2)),
            TO_NUMBER(tab_broken_cols(3)),
            p_in_user_id,
            SYSDATE,
            SYSDATE,
            p_in_user_id

          );



 END LOOP;

 /* Patni 04-Sep-2006 - To check if the repair attributes are modified - Begin */
 IF v_crd_e_repair_catalog_seq_id IS NOT NULL THEN
    v_settings_seq_id      := NULL;
    v_column_name          := NULL;

    -- Cursor to get the setting columns
    OPEN cur_repair_attributes; 
 
    BEGIN
         LOOP
             FETCH cur_repair_attributes INTO v_settings_seq_id,
                                              v_column_name;
             EXIT WHEN cur_repair_attributes%NOTFOUND;

             IF v_settings_seq_id_data IS NULL THEN
                v_settings_seq_id_data := v_settings_seq_id || '^';
             ELSE
                v_settings_seq_id_data := v_settings_seq_id_data || v_settings_seq_id || '^';
             END IF;
                       
             IF UPPER(v_column_name) = 'REPAIR_PRICE' THEN
                SELECT COUNT(1)
                INTO   v_repair_modified
                FROM   CRD_E_REPAIR_CATALOG
                WHERE  NVL(REPAIR_PRICE, 0) = NVL(v_old_repair_price, 0)
                AND    CRD_E_REPAIR_CATALOG_SEQ_ID = v_crd_e_repair_catalog_seq_id;
             
                IF v_repair_modified = 0 THEN
                   v_data_modified := TRUE;
                END IF;
             END IF;
             
             IF UPPER(v_column_name) = 'REPAIR_TAT' THEN
                SELECT COUNT(1)
                INTO   v_repair_modified
                FROM   CRD_E_REPAIR_CATALOG
                WHERE  NVL(REPAIR_TAT, 0) = NVL(v_old_repair_tat, 0)
                AND    CRD_E_REPAIR_CATALOG_SEQ_ID = v_crd_e_repair_catalog_seq_id;
             
                IF v_repair_modified = 0 THEN
                   v_data_modified := TRUE;
                END IF;
             END IF;
         END LOOP;
         
    EXCEPTION
    WHEN OTHERS THEN
         DBMS_OUTPUT.PUT_LINE('Error while fetching the repair attributes from CRD_E_SETTINGS : ' || SQLCODE || ' ' || SQLERRM);
    END;
 
    CLOSE cur_repair_attributes; 
    
    -- If the repair attributes are modified, the details are maintained in the transaction table     
    IF v_data_modified = TRUE THEN
       v_settings_seq_arr := ECRD_UTILS_PKG.string_to_array(v_settings_seq_id_data, '^');       
       
       IF v_settings_seq_arr(1) IS NOT NULL THEN
          v_data_exist := 0;

          SELECT COUNT(1)
          INTO   v_data_exist
          FROM   CRD_E_MODIFIED_DATA
          WHERE  CRD_E_SETTINGS_SEQ_ID       = TO_NUMBER(v_settings_seq_arr(1))
          AND    CRD_E_REPAIR_CATALOG_SEQ_ID = v_crd_e_repair_catalog_seq_id;

          IF v_data_exist = 0 THEN
             BEGIN
                  INSERT INTO CRD_E_MODIFIED_DATA
                             (
                              CRD_E_MOD_DATA_SEQ_ID,
                              CRD_E_SETTINGS_SEQ_ID,
                              CRD_E_REPAIR_CATALOG_SEQ_ID,
                              OLD_VALUE,
                              CREATED_BY,
                              CREATION_DATE,
                              LAST_UPDATE_DATE,
                              LAST_UPDATED_BY
                             )
                       VALUES(
                              CRD_E_MODIFIED_DATA_SEQ.NEXTVAL,
                              TO_NUMBER(v_settings_seq_arr(1)),
                              v_crd_e_repair_catalog_seq_id,
                              v_old_repair_price,
                              p_in_user_id,
                              SYSDATE,
                              SYSDATE,
                              p_in_user_id
                             );                              
             EXCEPTION
             WHEN OTHERS THEN
                  DBMS_OUTPUT.PUT_LINE('Error while inserting the details in CRD_E_MODIFIED_DATA : ' || SQLCODE || ' ' || SQLERRM);
             END;                
          
          ELSE
              BEGIN
                   UPDATE CRD_E_MODIFIED_DATA
                   SET    OLD_VALUE = v_old_repair_price,
                          LAST_UPDATED_BY  = p_in_user_id,
                          LAST_UPDATE_DATE = SYSDATE
                   WHERE  CRD_E_SETTINGS_SEQ_ID = TO_NUMBER(v_settings_seq_arr(1))
                   AND    CRD_E_REPAIR_CATALOG_SEQ_ID = v_crd_e_repair_catalog_seq_id;
             
             EXCEPTION
             WHEN OTHERS THEN
                  DBMS_OUTPUT.PUT_LINE('Error while updating the details in CRD_E_MODIFIED_DATA : ' || SQLCODE || ' ' || SQLERRM);
             END;
          END IF;
       END IF;

       IF v_settings_seq_arr(2) IS NOT NULL THEN
           v_data_exist := 0;

           SELECT COUNT(1)
           INTO   v_data_exist
           FROM   CRD_E_MODIFIED_DATA
           WHERE  CRD_E_SETTINGS_SEQ_ID       = TO_NUMBER(v_settings_seq_arr(2))
           AND    CRD_E_REPAIR_CATALOG_SEQ_ID = v_crd_e_repair_catalog_seq_id;

           IF v_data_exist = 0 THEN
              BEGIN
                   INSERT INTO CRD_E_MODIFIED_DATA
                              (
                               CRD_E_MOD_DATA_SEQ_ID,
                               CRD_E_SETTINGS_SEQ_ID,
                               CRD_E_REPAIR_CATALOG_SEQ_ID,
                               OLD_VALUE,
                               CREATED_BY,
                               CREATION_DATE,
                               LAST_UPDATE_DATE,
                               LAST_UPDATED_BY
                              )
                        VALUES(
                               CRD_E_MODIFIED_DATA_SEQ.NEXTVAL,
                               TO_NUMBER(v_settings_seq_arr(2)),
                               v_crd_e_repair_catalog_seq_id,
                               v_old_repair_tat,
                               p_in_user_id,
                               SYSDATE,
                               SYSDATE,
                               p_in_user_id
                              );
              EXCEPTION
              WHEN OTHERS THEN
                   DBMS_OUTPUT.PUT_LINE('Error while inserting the details in CRD_E_MODIFIED_DATA : ' || SQLCODE || ' ' || SQLERRM);
              END;                
                              
           ELSE
               BEGIN
                    UPDATE CRD_E_MODIFIED_DATA
                    SET    OLD_VALUE = v_old_repair_tat,
                           LAST_UPDATED_BY  = p_in_user_id,
                           LAST_UPDATE_DATE = SYSDATE
                    WHERE  CRD_E_SETTINGS_SEQ_ID = TO_NUMBER(v_settings_seq_arr(2))
                    AND    CRD_E_REPAIR_CATALOG_SEQ_ID = v_crd_e_repair_catalog_seq_id;
               
               EXCEPTION
               WHEN OTHERS THEN
                    DBMS_OUTPUT.PUT_LINE('Error while updating the details in CRD_E_MODIFIED_DATA : ' || SQLCODE || ' ' || SQLERRM);
               END;
           END IF;
       END IF;
    END IF;
    
    COMMIT;
 END IF;
 /* Patni 04-Sep-2006 - To check if the repair attributes are modified - End */
 

EXCEPTION WHEN OTHERS THEN

 RAISE_APPLICATION_ERROR(-20002,'ERROR IN ecrd_repair_pkg.ecrd_admin_update_rep_prc' ||SQLCODE ||  ' - ' || SQLERRM);
 ROLLBACK;
END ecrd_admin_update_rep_prc;


PROCEDURE ecrd_tc_update_rep_prc(
   p_in_cat_seq_id IN crd_e_repair_catalog.catalog_seq_id%TYPE,
   p_in_component_code  IN    crd_e_component.component_code%TYPE,
   p_in_module_id       IN    crd_e_component.module_seq_id%TYPE,
   p_in_repair_seq_id IN     crd_e_repair.repair_seq_id%TYPE,
   p_in_repair_desc IN crd_e_repair.repair_description%TYPE,
   p_in_repair_volume IN crd_e_repair.repair_volume%TYPE,
   p_in_repair_eff_date IN crd_e_repair.repair_effective_date%TYPE,
   p_in_repair_comment IN crd_e_repair.repair_comments%TYPE,
   p_in_repair_type IN crd_e_repair.repair_type%TYPE,
   p_in_repair_ref IN crd_e_repair.repair_reference%TYPE,
   p_in_repair_ref_format IN crd_e_repair.repair_reference_format%TYPE,

   p_in_rep_site_buff      IN LONG,
   p_in_child_rep_buff     IN LONG,
   p_in_tc_modify     IN VARCHAR2,

   p_in_incr_tat IN crd_e_repair_catalog.incremental_tat_ind%TYPE,
   p_in_tat IN crd_e_repair_catalog.repair_tat%TYPE,
   p_in_incremental_price IN crd_e_repair_catalog.incremental_price_ind%TYPE,
   p_in_price IN crd_e_repair_catalog.repair_price%TYPE,
   p_in_price_type IN crd_e_repair_catalog.price_type%TYPE,
   p_in_display_seq IN crd_e_repair_catalog.repair_display_seq_id%TYPE,
   p_in_future_price IN crd_e_repair_catalog.future_price%TYPE,
   p_in_future_tat IN crd_e_repair_catalog.future_tat%TYPE,
   p_in_future_price_tat_date IN crd_e_repair_catalog.future_effective_date%TYPE,
   p_in_user_id         IN    crd_e_repair.CREATED_BY%TYPE,
   p_in_user_role       IN     VARCHAR2,
    p_in_row_delimiter   IN   VARCHAR2,
    p_in_cols_delimiter   IN  VARCHAR2

   )

 AS
-- Cursor to get all the Repair Seq Ids details.


CURSOR eCRD_get_Child_Repair--cursor  to populate all existing child repairs
               IS
               SELECT
                repair.REPAIR_SEQ_ID repair_id,
                 repair.COMPONENT_CODE component_cd,
                 repair.REPAIR_TYPE rep_type,
                 repair.MODULE_SEQ_ID mod_seq_id,
                repair.REPAIR_DESCRIPTION rep_desc,
                repair.REPAIR_REFERENCE rep_ref,
                repair.REPAIR_COMMENTS rep_comments,
                repair.REPAIR_REFERENCE_FORMAT rep_format,
                repair.REPAIR_EFFECTIVE_DATE rep_eff_date,
                repair.REPAIR_END_DATE rep_end_date,
                repair.REPAIR_VOLUME  rep_volume
              FROM  crd_e_repair repair
               WHERE    parent_repair_seq_id = p_in_repair_seq_id
              AND (repair_end_date IS NULL OR repair_end_date > SYSDATE);

tab_broken_rows  ecrd_utils_pkg.gtyp_buf_arr;
   tab_broken_cols  ecrd_utils_pkg.gtyp_buf_arr;
   v_row_count  NUMBER       := 0;
   v_index       NUMBER      := 0;
   v_details    VARCHAR2(2000)  := NULL;
   v_pos        NUMBER :=0;
    v_count      NUMBER :=0;
   v_temp       NUMBER :=0;
   v_location_str VARCHAR2(2000)  := NULL;
   v_osb_nos    NUMBER :=0;
   v_repair_seq_id crd_e_repair.repair_seq_id%type;
   v_createdby_count NUMBER:=0;
   v_child_in_hist VARCHAR2(1)  := NULL;
   v_child_count NUMBER := 0;
   v_created_by crd_e_repair_catalog.created_by%type;
   v_creation_date crd_e_repair_catalog.creation_date%type;

BEGIN

                 dbms_output.put_line('This  is  TC  ');
                 dbms_output.put_line('Data Going in repair history TC  ');

      SELECT count(rowid)
      INTO v_createdby_count
      FROM crd_e_repair_catalog_hist
      WHERE repair_end_date IS NULL
      AND approved_rejected_date IS NULL
      AND staging_history_ind=ecrd_utils_pkg.G_STAGING
      AND repair_seq_id=p_in_repair_seq_id
      AND catalog_seq_id=p_in_cat_seq_id;

        dbms_output.put_line(' After the created by condition  TC  ');


      /*
      19-Jan-2005
      Do not enter in history for H record
      INSERT INTO crd_e_repair_history --TC
      (
         REPAIR_SEQ_ID,
         STAGING_HISTORY_IND,
         CHANGE_START_DATE,
         COMPONENT_CODE,
         REPAIR_TYPE,
         MODULE_SEQ_ID,
         REPAIR_DESCRIPTION,
         REPAIR_REFERENCE,
         REPAIR_COMMENTS,
         REPAIR_REFERENCE_FORMAT,
         REPAIR_EFFECTIVE_DATE,
         REPAIR_END_DATE,
         REQUESTED_BY,
         APPROVED_REJECTED_BY,
         REQUESTED_DATE,
         APPROVED_REJECTED_DATE,
         REPAIR_VOLUME,
         APPROVE_REJECT_STATUS,
         REJECTION_COMMENTS,
         CREATION_DATE,
         CREATED_BY,
         LAST_UPDATE_DATE,
         LAST_UPDATED_BY,
         PARENT_REPAIR_SEQ_ID

       )
       (SELECT
       repair.repair_seq_id,
       ecrd_utils_pkg.G_HISTORY_RECORD,
       SYSDATE,
        repair.COMPONENT_CODE,
        repair.REPAIR_TYPE,
        repair.MODULE_SEQ_ID,
       repair.REPAIR_DESCRIPTION,
       repair.REPAIR_REFERENCE,
       repair.REPAIR_COMMENTS,
      repair.REPAIR_REFERENCE_FORMAT,
       repair.REPAIR_EFFECTIVE_DATE,
       NULL,
       NULL,
         NULL,
         NULL,
         NULL,
       repair.REPAIR_VOLUME,
         NULL,
         NULL,
         SYSDATE,
         p_in_user_id,
         SYSDATE,
         p_in_user_id,
       repair.PARENT_REPAIR_SEQ_ID
        FROM  crd_e_repair repair
        WHERE repair.REPAIR_SEQ_ID=p_in_repair_seq_id
        AND repair.component_code = p_in_component_code
        AND repair.module_seq_id = p_in_module_id
        AND (repair_end_date IS NULL OR repair_end_date > SYSDATE)
        );

               dbms_output.put_line('After data  in repair history    ');



        dbms_output.put_line('main data in Repair catalog  added in repair history    ');



   19-Jan-2005
      Do not enter in history for H record
    ecrd_repair_pkg.ecrd_ins_repcat_hist_prc(p_in_repair_seq_id,p_in_cat_seq_id,p_in_user_id);



        dbms_output.put_line('DATA  ADDED IN crd_e_repair_catalog_hist');


        dbms_output.put_line('main data in Repair cost history  added in repair history');

                        INSERT INTO CRD_E_REPAIR_COST_HISTORY
                        (
                         module_seq_id,
                         component_code,
                         repair_seq_id,
                          LOCATION_ID,
                            STAGING_HISTORY_IND,
                             COST_CHANGE_START_DATE,
                             MATERIAL_COST,
                             LABOR_HOURS,
                             REQUESTED_BY,
                             CREATED_BY,
                             REQUESTED_DATE,
                             CREATION_DATE,
                             APPROV_REJECT_STATUS,
                             LAST_UPDATE_DATE,
                             APPROV_REJECT_DATE,
                             LAST_UPDATED_BY,
                             REJECT_COMMENTS

                           )
                         (
                         SELECT
                           module_seq_id,
                           component_code,
                           repair_seq_id,
                           LOCATION_ID,
                              ecrd_utils_pkg.G_HISTORY_RECORD,
                             SYSDATE,
                             MATERIAL_COST,
                             LABOUR_HOURS,
                             NULL,
                             p_in_user_id,
                             NULL,
                             SYSDATE,
                             NULL,
                             SYSDATE,
                             NULL,
                             p_in_user_id,
                             NULL

                            FROM    CRD_E_REPAIR_COST

                          WHERE   module_seq_id = p_in_module_id
                            AND     repair_seq_id = p_in_repair_seq_id
                          AND     component_code = p_in_component_code
                          );*/
              dbms_output.put_line('main data in Repair cost history  added in repair history---end');


                  UPDATE   crd_e_repair
                  SET
                        REPAIR_DESCRIPTION = p_in_repair_desc,
                        repair_volume = p_in_repair_volume,
                        /*19-Jan-2005
                             Change No 1
                           Patni Offshore Development
                             When updating the repair effective date should not get updated
                          repair_effective_date=v_repair_eff_date,
                           End 10-Jan-2005
                           Change No 1
                         */
                        repair_comments = p_in_repair_comment,
                        last_updated_by=p_in_user_id,
                        last_update_date = SYSDATE,
                        repair_reference=p_in_repair_ref,
                        repair_reference_format = p_in_repair_ref_format
                  WHERE
                        component_code = p_in_component_code
                  AND   module_seq_id = p_in_module_id
                  AND   repair_seq_id=p_in_repair_seq_id
                  AND (repair_end_date IS NULL OR repair_end_date > SYSDATE);

                  -- 03-May-2006 Patni - Updating Repair Catalog with Effective Date as SYSDATE for the Parent Repair and Child Repairs - Begin
      			  UPDATE crd_e_repair_catalog
                  SET
						 effective_date = SYSDATE,
			             last_updated_by = p_in_user_id,
			             last_update_date = SYSDATE
				  WHERE
			             catalog_seq_id = p_in_cat_seq_id
				  AND    repair_seq_id = p_in_repair_seq_id
			      AND    (repair_end_date IS NULL OR repair_end_date > SYSDATE);


      			  UPDATE crd_e_repair_catalog
      			  SET
						 effective_date = SYSDATE,
             			 last_updated_by = p_in_user_id,
             			 last_update_date = SYSDATE
	  			  WHERE
             			 catalog_seq_id = p_in_cat_seq_id
      			  AND    repair_seq_id IN (
                               				SELECT repair_seq_id
                              				FROM crd_e_repair
                               				WHERE parent_repair_seq_id = p_in_repair_seq_id
										    AND (repair_end_date IS NULL OR repair_end_date > SYSDATE)
                              			  )
      			  AND    (repair_end_date IS NULL OR repair_end_date > SYSDATE);
      			  -- 03-May-2006 Patni - Updating Repair Catalog with Effective Date as SYSDATE for the Parent Repair and Child Repairs - End


    dbms_output.put_line('crd data in Repair added in repair history --end');
  dbms_output.put_line('v_createdby_count  ***************************************** '||v_createdby_count);

         SELECT created_by,
                creation_date
         INTO
               v_created_by,
               v_creation_date
         FROM crd_e_repair_catalog
         WHERE
         catalog_seq_id = p_in_cat_seq_id
         AND  repair_seq_id = p_in_repair_seq_id
         AND (repair_end_date IS NULL OR repair_end_date > SYSDATE);


IF v_createdby_count = 0/*Check wherther the TC is same Tc or different one*/
THEN
  dbms_output.put_line('updating repair tables catalog for diff TC***************************************** '||v_createdby_count);
                                 INSERT INTO crd_e_repair_catalog_hist  --tc
                                     (
                                    catalog_seq_id,
                                    repair_seq_id,
                                    effective_date,
                                    staging_history_ind,
                                    change_start_date,
                                    repair_price,
                                    incremental_price_ind,
                                    repair_tat,
                                    incremental_tat_ind,
                                    future_price,
                                   price_type,
                                    future_tat,
                                    future_effective_date,
                                    created_by,
                                    creation_date,
                                    last_update_date,
                                    last_updated_by,
                                    repair_display_seq_id,
                                    requested_by,
                                    requested_date,
                                    approv_reject_by,
                                    approved_rejected_date,
                                   approve_reject_status,
                                   rejection_comments
                                    )
                                    VALUES
                                     (
                                    p_in_cat_seq_id ,
                                    p_in_repair_seq_id,
                                    /*
                                      Start 10-Jan-2005
                                      Change No 2
                                        Patni Offshore Development
                                     When updating the price the repair price effective date should get updated
                                     with SYSDATE
                                    p_in_repair_eff_date,
                                    */
                                    SYSDATE,
                                    ecrd_utils_pkg.G_STAGING,
                                    SYSDATE,
                                    p_in_price,
                                    p_in_incremental_price,
                                    TO_NUMBER(p_in_tat),
                                    p_in_incr_tat ,
                                    p_in_future_price,
                                    p_in_price_type,
                                    p_in_future_tat,
                                    p_in_future_price_tat_date,
                                    v_created_by,
                                    v_creation_date,
                                    SYSDATE,
                                    p_in_user_id,
                                    p_in_display_seq,
                                    p_in_user_id,
                                    SYSDATE,
                                    NULL,
                                    NULL,
                                    NULL,
                                    NULL
                                     );

ELSE
             dbms_output.put_line('updating repair tables catalog for same TC***************************************** '||v_createdby_count);
                        UPDATE   crd_e_repair_catalog_hist
                           SET
                                 incremental_tat_ind = p_in_incr_tat,
                                 repair_tat = TO_NUMBER(p_in_tat),
                                   /*
                                     Start 10-Jan-2005
                                   Change No 2
                                     Patni Offshore Development
                                  When updating the price the repair price effective date should get updated
                                  with SYSDATE
                                  */
                                    effective_date =SYSDATE,
                                  /*
                                  End 10-Jan-2005
                                  Change No 2
                                  */
                                 incremental_price_ind=p_in_incremental_price,
                                 repair_price = p_in_price ,
                                 price_type=p_in_price_type,
                                 repair_display_seq_id=p_in_display_seq,
                                 future_price=p_in_future_price ,
                                 future_tat=p_in_future_tat,
                                 future_effective_date= p_in_future_price_tat_date,
                                 last_update_date=SYSDATE,
                                 last_updated_by= p_in_user_id
                           WHERE
                                 catalog_seq_id = p_in_cat_seq_id
                           AND  repair_seq_id = p_in_repair_seq_id
                          AND (repair_end_date IS NULL OR repair_end_date > SYSDATE)
                           AND staging_history_ind=ecrd_utils_pkg.G_STAGING;

END IF;



                                    DELETE FROM crd_e_repair_cost rp_cost
                                    WHERE module_seq_id  =   p_in_module_id
                                    AND component_code   =   p_in_component_code
                                    AND repair_seq_id    =   p_in_repair_seq_id;


                              ecrd_utils_pkg.break_into_rows_s_prc(
                                                  p_in_rep_site_buff
                                                  ,p_in_row_delimiter
                                                  ,tab_broken_rows
                                                  );


                                          v_row_count := tab_broken_rows.COUNT;
                                               --
                                          FOR v_index IN 1..v_row_count
                                          LOOP
                                              --
                                           v_details := tab_broken_rows(v_index);

                                          ecrd_utils_pkg.break_into_cols_s_prc(
                                                  v_details,
                                                  p_in_cols_delimiter,
                                                  tab_broken_cols
                                                );
                                       INSERT INTO crd_e_repair_cost
                                                (
                                                   module_seq_id,
                                                   component_code,
                                                   repair_seq_id,
                                                   location_id,
                                                   material_cost,
                                                   labour_hours,
                                                   created_by,
                                                   creation_date,
                                                   last_update_date,
                                                   last_updated_by
                                                )
                                                 VALUES
                                                (
                                                   p_in_module_id,
                                                   p_in_component_code,
                                                   p_in_repair_seq_id,
                                                   tab_broken_cols(1),
                                                   TO_NUMBER(tab_broken_cols(2)),
                                                   TO_NUMBER(tab_broken_cols(3)),
                                                   p_in_user_id,
                                                   SYSDATE,
                                                   SYSDATE,
                                                   p_in_user_id

                                                 );



                            END LOOP;



                                    IF p_in_repair_type=ecrd_utils_pkg.G_PARENT_REPAIR
                                    THEN

                                             FOR child_repair IN eCRD_get_Child_Repair --check if the child previously exists in the table
                                             LOOP

                                                      ecrd_utils_pkg.break_into_rows_s_prc(
                                                          p_in_child_rep_buff
                                                         ,p_in_row_delimiter
                                                         ,tab_broken_rows
                                                         );

                                                               v_row_count := tab_broken_rows.COUNT;
                                                               v_child_in_hist:='N';
                                                     FOR v_index IN 1..v_row_count
                                                      LOOP

                                                               v_details := tab_broken_rows(v_index);
                                                               ecrd_utils_pkg.break_into_cols_s_prc(
                                                               v_details,
                                                               p_in_cols_delimiter,
                                                               tab_broken_cols
                                                                 );
                                                                    dbms_output.put_line('  tab_broken_cols(1)-------------->'||tab_broken_cols(1));
                                                                    dbms_output.put_line('  rep_seq_id.repair_id-------------->'||child_repair.repair_id);
                                                               IF (tab_broken_cols(1) <>' ')
                                                               THEN

                                                                     IF (child_repair.repair_id=to_number(tab_broken_cols(1)))
                                                                     THEN
                                                                     v_child_in_hist:='Y';/* Record  for update*/
                                                                     dbms_output.put_line('  MATCH FOUND');
                                                                     dbms_output.put_line('  v_child_in_hist-------------->'||v_child_in_hist);
                                                                     EXIT;
                                                                     ELSE
                                                                     dbms_output.put_line('  v_child_in_hist-------------->'||v_child_in_hist);
                                                                     END IF;

                                                               END IF;
                                                      END LOOP;
                                                                       dbms_output.put_line('  v_child_in_hist-------------->'||v_child_in_hist);
                                                               dbms_output.put_line('  Updating  child_repair.repair_id -------------->'||child_repair.repair_id);
                                                                          /*Insert Record in history Record */
                                                            dbms_output.put_line('Insert child Record in history Record');
                                                INSERT INTO crd_e_repair_history            --tc
                                                      (
                                                         repair_seq_id,
                                                         staging_history_ind,
                                                         change_start_date,
                                                         component_code,
                                                         repair_type,
                                                         module_seq_id,
                                                         repair_description,
                                                         repair_reference,
                                                         repair_comments,
                                                         repair_reference_format,
                                                         repair_effective_date,
                                                         repair_end_date,
                                                         requested_by,
                                                         approved_rejected_by,
                                                         requested_date,
                                                         approved_rejected_date,
                                                         repair_volume,
                                                         approve_reject_status,
                                                         rejection_comments,
                                                         creation_date,
                                                         created_by,
                                                         last_update_date,
                                                         last_updated_by,
                                                         parent_repair_seq_id

                                                       )
                                                       VALUES
                                                       (
                                                       child_repair.repair_id,
                                                       ecrd_utils_pkg.G_HISTORY_RECORD,
                                                       SYSDATE+1,
                                                        child_repair.component_cd,
                                                        child_repair.rep_type,
                                                        child_repair.mod_seq_id,
                                                       child_repair.rep_desc,
                                                       child_repair.rep_ref,
                                                       child_repair.rep_comments,
                                                       child_repair.rep_format,
                                                       /*19-jan-2005
                                                       child_repair.rep_eff_date,
                                                       */
                                                       SYSDATE,
                                                       child_repair.rep_end_date,
                                                       NULL,
                                                       NULL,
                                                         NULL,
                                                         NULL,
                                                       child_repair.rep_volume,
                                                         NULL,
                                                         NULL,
                                                         SYSDATE,
                                                         p_in_user_id,
                                                         SYSDATE,
                                                         p_in_user_id,
                                                         p_in_repair_seq_id
                                                        );

                                                dbms_output.put_line(' repair for crd_e_repair_catalog_hist');

                                                         INSERT INTO crd_e_repair_catalog_hist             --TC
                                                         (
                                                         CATALOG_SEQ_ID,
                                                         REPAIR_SEQ_ID,
                                                         EFFECTIVE_DATE,
                                                         STAGING_HISTORY_IND,
                                                         CHANGE_START_DATE,
                                                         REPAIR_PRICE,
                                                         INCREMENTAL_PRICE_IND,
                                                         REPAIR_TAT,
                                                         INCREMENTAL_TAT_IND,
                                                         FUTURE_PRICE,
                                                         FUTURE_EFFECTIVE_DATE,
                                                         created_by,
                                                         creation_date,
                                                         last_update_date,
                                                         last_updated_by,
                                                         repair_display_seq_id,
                                                         requested_by,
                                                         requested_date,
                                                         approv_reject_by,
                                                         approved_rejected_date,
                                                        approve_reject_status,
                                                        rejection_comments
                                                         )

                                                          (
                                                           SELECT
                                                         CATALOG_SEQ_ID,
                                                         REPAIR_SEQ_ID,
                                                         /*19-jan-2005
                                                         EFFECTIVE_DATE,
                                                         */
                                                         SYSDATE,
                                                         ecrd_utils_pkg.G_HISTORY_RECORD,
                                                         SYSDATE,
                                                         REPAIR_PRICE,
                                                         INCREMENTAL_PRICE_IND,
                                                         REPAIR_TAT,
                                                         INCREMENTAL_TAT_IND,
                                                         FUTURE_PRICE,
                                                         FUTURE_EFFECTIVE_DATE,
                                                         p_in_user_id,
                                                         SYSDATE,
                                                         SYSDATE,
                                                         p_in_user_id,
                                                         repair_display_seq_id,
                                                         NULL,
                                                         NULL,
                                                        NULL,
                                                        NULL,
                                                        NULL,
                                                        NULL
                                                          FROM  crd_e_repair_catalog rep_cat
                                                           WHERE
                                                              rep_cat.repair_seq_id = child_repair.repair_id
                                                              AND   rep_cat.catalog_seq_id = p_in_cat_seq_id
                                                                  AND (rep_cat.repair_end_date IS NULL OR rep_cat.repair_end_date > SYSDATE)
                                                             );



                                                               IF v_child_in_hist = 'N' /* Condition to disable the recoprd */
                                                               THEN

                                                            dbms_output.put_line('Disable the existing Record');

                                                                       /*Disable the existing Record */

                                                                                    UPDATE   crd_e_repair
                                                                                          SET
                                                                                             repair_end_date=SYSDATE+1
                                                                                          WHERE
                                                                                             repair_seq_id=child_repair.repair_id
                                                                                          AND (repair_end_date IS NULL OR repair_end_date > SYSDATE);



                                                                                    UPDATE   crd_e_repair_catalog
                                                                                          SET
                                                                                             repair_end_date=SYSDATE+1
                                                                                          WHERE
                                                                                            catalog_seq_id = p_in_cat_seq_id
                                                                                          AND   repair_seq_id=child_repair.repair_id
                                                                                          AND (repair_end_date IS NULL OR repair_end_date > SYSDATE);

                                                               END IF;



                                       END LOOP;--CURSOR LOOP END


                                    /*All Child repairs deleted are saved in the history*/
                                      dbms_output.put_line('All Child repairs deleted are saved in the history');
                                      dbms_output.put_line('Now update the record or add them in th data base ');

                                          ecrd_utils_pkg.break_into_rows_s_prc(
                                              p_in_child_rep_buff
                                             ,p_in_row_delimiter
                                             ,tab_broken_rows
                                             );

                                       v_row_count := tab_broken_rows.COUNT;
                                       FOR v_index IN 1..v_row_count
                                       LOOP

                                                 v_details := tab_broken_rows(v_index);
                                          ecrd_utils_pkg.break_into_cols_s_prc(
                                                     v_details,
                                                   p_in_cols_delimiter,
                                                     tab_broken_cols
                                                     );

                                          SELECT count(rowid) INTO v_child_count  FROM crd_e_repair where repair_seq_id =to_number(tab_broken_cols(1));

                                          IF v_child_count=1
                                          THEN
                                            dbms_output.put_line('Updating the childs  -------------------------------------------------------->>>  ');
                                                UPDATE   crd_e_repair
                                                SET
                                                      repair_description = tab_broken_cols(2),
                                                      repair_comments = tab_broken_cols(4),
                                                      /*19-Jan-2005
                                                        Change No 1
                                                      Patni Offshore Development
                                                        When updating the repair effective date should not get updated
                                                     repair_effective_date=v_repair_eff_date,
                                                      End 10-Jan-2005
                                                      Change No 1
                                                     */
                                                      repair_volume= p_in_repair_volume,
                                                      last_updated_by=p_in_user_id,
                                                      last_update_date = SYSDATE,
                                                      repair_reference=tab_broken_cols(3),
                                                      repair_reference_format = tab_broken_cols(5)

                                                WHERE
                                                      component_code = p_in_component_code
                                                AND   module_seq_id = p_in_module_id
                                                AND   repair_seq_id=to_number(tab_broken_cols(1))
                                               AND (repair_end_date IS NULL OR repair_end_date > SYSDATE);

                                                   UPDATE   crd_e_repair_catalog
                                                      SET
                                                            repair_display_seq_id=TO_NUMBER(tab_broken_cols(6)),
                                                             /*
                                                                Start 10-Jan-2005
                                                              Change No 2
                                                                Patni Offshore Development
                                                             When updating the price the repair price effective date should get updated
                                                             with SYSDATE
                                                             */
--                                                             effective_date =SYSDATE, Commeneted bcoz the the effective date is changed when it is approved by Admin
                                                             /*
                                                             End 10-Jan-2005
                                                             Change No 2
                                                             */

															-- 03-May-2006 Patni - Updating Repair Catalog with Effective Date to SYSDATE - Begin
															effective_date = SYSDATE,
															-- 03-May-2006 Patni - Updating Repair Catalog with Effective Date to SYSDATE - End

                                                            last_update_date=SYSDATE,
                                                            last_updated_by= p_in_user_id
                                                      WHERE
                                                            catalog_seq_id = p_in_cat_seq_id
                                                      AND  repair_seq_id = to_number(tab_broken_cols(1))
                                                     AND (repair_end_date IS NULL OR repair_end_date > SYSDATE);


                                          ELSE

                                                       BEGIN
                                       dbms_output.put_line('New  childs  -------------------------------------------------------->>>  ');
                                                          SELECT MAX(repr.rpr_osb_unique_number)
                                                          INTO   v_osb_nos
                                                          FROM crd_e_repair repr
                                                          WHERE repr.COMPONENT_CODE = p_in_component_code;
                                                          EXCEPTION WHEN NO_DATA_FOUND THEN
                                                            v_osb_nos := 0;
                                                          END;

                                           v_osb_nos := v_osb_nos + 1;

                                            SELECT crd_e_repair_seq.nextval
                                                         INTO v_repair_seq_id
                                                         FROM dual;
                  dbms_output.put_line('New  childs  -------------------------------------------------------->>>  '||v_repair_seq_id);
                  dbms_output.put_line('New  childs  -------------------------------------------------------->>>  '||tab_broken_cols(3));
                  dbms_output.put_line('New  childs  -------------------------------------------------------->>>  '||tab_broken_cols(4));
                  dbms_output.put_line('New  childs  -------------------------------------------------------->>>  '||tab_broken_cols(5));


                                      INSERT INTO crd_e_repair
                                          (
                                             repair_seq_id,
                                             module_seq_id,
                                             component_code,
                                             repair_type,
                                             repair_description,
                                             parent_repair_seq_id,
                                             repair_reference,
                                             repair_comments,
                                             repair_reference_format,
                                             repair_effective_date,
                                             repair_volume,
                                             repair_end_date,
                                             created_by,
                                             rpr_osb_unique_number,
                                             creation_date,
                                             last_update_date,
                                             last_updated_by,
                                             split_merge_seq_id
                                          )
                                           VALUES
                                          (
                                             v_repair_seq_id,
                                             p_in_module_id ,
                                             p_in_component_code  ,
                                             ecrd_utils_pkg.G_CHILD_REPAIR,

                                             tab_broken_cols(2),
                                             p_in_repair_seq_id,
                                             tab_broken_cols(3),
                                             tab_broken_cols(4),
                                             tab_broken_cols(5),
                                             /*19-Jan-2005
                                             p_in_repair_eff_date,
                                             */
                                             SYSDATE,
                                             p_in_repair_volume,
                                             NULL,
                                             p_in_user_id,
                                             v_osb_nos,
                                             SYSDATE,
                                             SYSDATE,
                                             p_in_user_id,
                                             NULL
                                           );


                                       INSERT INTO crd_e_repair_catalog
                                          (
                                                /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - Begin */
                                                crd_e_repair_catalog_seq_id,
                                                /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - End */
                                                repair_seq_id,
                                                catalog_seq_id,
                                                effective_date,
                                                repair_price,
                                                incremental_price_ind,
                                                repair_tat,
                                                incremental_tat_ind,
                                                future_price,
                                                future_effective_date,
                                                price_type,
                                                repair_end_date,
                                                repair_display_seq_id,
                                                future_tat,
                                                price_overwrite_flag_ind,
                                                created_by,
                                                creation_date,
                                                last_update_date,
                                                last_updated_by
                                          )
                                           VALUES
                                          (
                                                /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - Begin */
                                                crd_e_repair_catalog_seq.nextval,
                                                /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - End */
                                                v_repair_seq_id,
                                                p_in_cat_seq_id,
                                                /*19-Jan-2005
                                                p_in_repair_eff_date,
                                                */
                                                SYSDATE,
                                                NULL,
                                                NULL,
                                                NULL,
                                                NULL,
                                                NULL,
                                                NULL,
                                                NULL,
                                                NULL,
                                                TO_NUMBER(tab_broken_cols(6)),
                                                NULL,
                                                NULL,
                                                p_in_user_id,
                                                SYSDATE,
                                                SYSDATE,
                                                p_in_user_id
                                           );
                                          END IF;

                                       END LOOP;
                                    END IF;
 dbms_output.put_line('End of Querry  ');


EXCEPTION WHEN OTHERS THEN

 ROLLBACK;
RAISE_APPLICATION_ERROR(-20002,'ERROR IN ecrd_repair_pkg.ecrd_tc_update_rep_prc' ||SQLCODE ||  ' - ' || SQLERRM);

END ecrd_tc_update_rep_prc;
/*
*/
PROCEDURE ecrd_list_spl_rprs_prc(
       p_in_catalog_id IN NUMBER,
            p_in_eng_model IN VARCHAR2,
            p_in_module IN VARCHAR2,
            p_in_component_type IN VARCHAR2,
            p_in_component IN VARCHAR2,
            p_out_repair_list OUT result_cursor
  )
  IS

  v_catalog_seq_id NUMBER(9):=0;
  v_err_mess VARCHAR2(1000) :='';
  BEGIN

  --  Get the default Catalog Sequence Id for the Model if parameter is NULL

   IF (p_in_catalog_id IS NULL) THEN
      /*
      SELECT   catalog_seq_id
      INTO  v_catalog_seq_id
      FROM  crd_e_catalog
      WHERE    eng_mdl_number = p_in_eng_model
      AND   catalog_end_date >= TRUNC(SYSDATE)
      AND   catalog_type = 'D';
      */
      ecrd_managecatalog_pkg.ecrd_get_default_seqid_prc( p_in_eng_model
                                                 ,v_catalog_seq_id
                                                 ,v_err_mess);
   ELSE
      v_catalog_seq_id := p_in_catalog_id;
   END IF;

OPEN p_out_repair_list
FOR
      SELECT   catalog.repair_display_seq_id Display_Sequence,
                        repair.repair_description Repair_Description,
                        repair.repair_reference Repair_Reference,
                        ecrd_get_sites_fnc(p_in_module,UPPER(p_in_component)) Sites,
                        catalog.repair_price Price,
                        catalog.price_type Price_Type,
                        catalog.repair_TAT TAT,
                        repair.repair_seq_id repair_seq_id,
                        catalog.incremental_price_ind incremental_price_ind,
                        catalog.incremental_tat_ind incremental_tat_ind,
         repair.repair_type repair_type
               FROM  crd_e_repair repair,
                     crd_e_repair_catalog catalog
               WHERE    catalog.repair_seq_id = repair.repair_seq_id
               AND   (catalog.repair_end_date IS NULL or catalog.repair_end_date > SYSDATE)
               AND   repair.repair_type IN( 'SI','SG')   -- Don't Show Child Repairs
               AND   repair.module_seq_id = p_in_module
               AND   repair.component_code = UPPER(p_in_component)
               AND   catalog.catalog_seq_id = v_catalog_seq_id ;
EXCEPTION
   WHEN OTHERS
   THEN RAISE_APPLICATION_ERROR(-20020,'error in ecrd_repairs_pkg.ecrd_list_spl_rprs_prc**'||SQLCODE||' '||SQLERRM);
END  ecrd_list_spl_rprs_prc;
--
PROCEDURE ecrd_update_price_write_prc(
      	  p_in_repair_seq_id IN NUMBER,
           p_in_catalog_id IN VARCHAR2)
IS
BEGIN
	UPDATE crd_e_repair_catalog
   SET
   	price_overwrite_flag_ind = ecrd_utils_pkg.G_NO
   WHERE
   	repair_seq_id = p_in_repair_seq_id AND
      catalog_seq_id = p_in_catalog_id;

   COMMIT;

EXCEPTION
WHEN OTHERS THEN
	ROLLBACK;
	RAISE_APPLICATION_ERROR(-20020,'Error in ecrd_repair_pkg.ecrd_update_price_overwrite_ind_prc'||SQLCODE||' '||SQLERRM);
END ecrd_update_price_write_prc;

PROCEDURE ecrd_add_repair_to_csc(
	p_in_repair_id IN VARCHAR2,
   p_in_customer_catalog_id IN crd_e_catalog.catalog_seq_id%TYPE,
   p_in_default_catalog_id IN crd_e_catalog.catalog_seq_id%TYPE,
   p_in_user_id IN crd_crc_user.userid%TYPE,
   p_out_message OUT VARCHAR2)
IS
-- Cursor for finding Child Repair for selected Parent Repair
CURSOR eCRD_Child_repair(p_repair_seq_id IN VARCHAR2)
IS
   SELECT
      repair_seq_id
   FROM
      CRD_E_REPAIR
   WHERE
      parent_repair_seq_id = p_repair_seq_id AND
      (trunc(repair_end_date) > trunc(SYSDATE) OR repair_end_date IS NULL);

	v_year crd_e_contracted_repair.year%TYPE;
   v_module_seq_id crd_crc_module.module_seq_id%TYPE;
   v_component_code crd_e_component.component_code%TYPE;
   v_discount crd_e_contracted_repair.discount%TYPE;
   v_count NUMBER := 0;
   v_repair_seq_id crd_e_repair.repair_seq_id%TYPE;
   v_display_seq_id crd_e_repair_catalog.repair_display_seq_id%TYPE;
   tab_broken_cols  ecrd_utils_pkg.gtyp_buf_arr;
   v_row_count  NUMBER       := 0;
   v_index       NUMBER      := 0;
   v_price crd_e_repair_catalog.repair_price%TYPE;
   v_new_price crd_e_repair_catalog.repair_price%TYPE;
   v_exists_count NUMBER :=0;
   v_child_repair_count NUMBER := 0;
   v_default_ind_status VARCHAR2(1) := '';
   v_tat crd_e_contracted_repair.tat%TYPE;
   v_default_tat crd_e_repair_catalog.repair_tat%TYPE;
   v_test VARCHAR2(100) := '';
BEGIN

	SELECT
   	TO_CHAR(SYSDATE,'YYYY')
   INTO
   	v_year
   FROM
   	DUAL;

v_test := '1';
	ecrd_utils_pkg.break_into_rows_s_prc(
                                        p_in_repair_id
                                        ,ecrd_utils_pkg.G_COL_DELIM
                                        ,tab_broken_cols
                                        );

v_test := '2';
   v_row_count := tab_broken_cols.COUNT;
        --
   FOR v_index IN 1..v_row_count
   LOOP

	   v_repair_seq_id := TO_NUMBER(tab_broken_cols(v_index));
v_test := '2.1';
      SELECT
      	component_code,module_seq_id
      INTO
      	v_component_code,v_module_seq_id
      FROM
      	crd_e_repair
      WHERE
      	repair_seq_id = v_repair_seq_id AND
         (repair_end_date IS NULL OR repair_end_date > SYSDATE);

      SELECT
      	repair_display_seq_id
      INTO
      	v_display_seq_id
      FROM
      	crd_e_repair_catalog
      WHERE
      	catalog_seq_id = p_in_default_catalog_id AND
         repair_seq_id = v_repair_seq_id AND
         (repair_end_date IS NULL OR repair_end_date > SYSDATE);

      ecrd_managecomponent_pkg.ecrd_check_repairdispseq_prc(p_in_customer_catalog_id,
      																		v_component_code,
                                                            v_module_seq_id,
                                                            v_display_seq_id,
                                                            v_repair_seq_id,
                                                            p_out_message);
 v_test := '2.2';
 		IF(p_out_message = '' OR p_out_message IS NULL)
      THEN
			SELECT
		   	count(1)
		   INTO
		   	v_count
		   FROM
		   	crd_e_repair_catalog
		   WHERE
		   	repair_seq_id = v_repair_seq_id AND
		      catalog_seq_id = p_in_customer_catalog_id AND
		      (repair_end_date IS NULL OR repair_end_date > SYSDATE);
		v_test := '2.3';
			IF(v_count = 0)
		   THEN
	      	v_discount := ecrd_get_rule_discount_prc(p_in_customer_catalog_id,v_component_code,v_module_seq_id,v_repair_seq_id);

	         v_default_ind_status := ecrd_rule_exists_fnc(p_in_customer_catalog_id,v_component_code,v_module_seq_id,v_repair_seq_id);

	         SELECT
	         	repair_price,repair_tat
	         INTO
	         	v_price,v_default_tat
	         FROM
	         	crd_e_repair_catalog
	         WHERE
	         	repair_seq_id = v_repair_seq_id AND
	            catalog_seq_id = p_in_default_catalog_id AND
	            (repair_end_date IS NULL OR repair_end_date > SYSDATE);
	v_test := '2.4';
	         v_new_price := (v_price - (v_price * (v_discount/100)));
	         BEGIN
		      	SELECT
		        		tat
		        	INTO
		        		v_tat
		        	FROM
		        		crd_e_contracted_repair
		        	WHERE
		        		repair_seq_id = v_repair_seq_id AND
		           	catalog_seq_id = p_in_customer_catalog_id AND
		           	year = v_year;
	            EXCEPTION
	            WHEN NO_DATA_FOUND
	            THEN
	            	v_tat := '';
	         END;
	v_test := '2.5';
	         IF(v_tat = '' OR v_tat IS NULL)
	         THEN
	         	v_tat := ecrd_reports_pkg.ecrd_get_tat_comp_or_rule_prc(p_in_customer_catalog_id,v_component_code,v_module_seq_id);

	            IF(v_tat = '' OR v_tat IS NULL)
		         THEN
	   	      	v_tat := v_default_tat;
	            END IF;
	         END IF;
	 v_test := '2.6';

	         INSERT INTO CRD_E_REPAIR_CATALOG
	         (
              /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - Begin */
              crd_e_repair_catalog_seq_id,
              /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - End */
	            repair_seq_id,            --1
	            catalog_seq_id,           --2
	            effective_date,           --3
	            repair_price,             --4
	            incremental_price_ind,    --5
	            repair_tat,               --6
	            incremental_tat_ind,      --7
	            future_price,             --8
	            future_effective_date,    --9
	            price_type,               --10
	            repair_end_date,          --11
	            repair_display_seq_id,    --12
	            future_tat,               --13
	            price_overwrite_flag_ind, --14
	            created_by,               --15
	            creation_date,            --16
	            last_update_date,         --17
	            last_updated_by,          --18
	            default_repair_ind		  --19
	         )
	         SELECT
              /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - Begin */
              crd_e_repair_catalog_seq.nextval,
              /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - End */
	            v_repair_seq_id, 					--1
	            p_in_customer_catalog_id,     --2
	            SYSDATE,		                  --3
	            v_new_price,                  --4
	            cerc.incremental_price_ind,   --5
	            v_tat,					         --6
	            cerc.incremental_tat_ind,     --7
	            NULL,                         --8
	            NULL,                         --9
	            cerc.price_type,              --10
	            NULL,                         --11
	            cerc.repair_display_seq_id,   --12
	            NULL,                         --13
	            ecrd_utils_pkg.G_NO,				--14
	            p_in_user_id,                 --15
	            SYSDATE,                      --16
	            SYSDATE,                      --17
	            p_in_user_id,                 --18
	            DECODE(v_default_ind_status, 'N', 'Y', 'N') --19
	         FROM
	            crd_e_repair_catalog cerc
	         WHERE
	            cerc.repair_seq_id = v_repair_seq_id AND
	            cerc.catalog_seq_id = p_in_default_catalog_id AND
	            (cerc.repair_end_date IS NULL OR trunc(cerc.repair_end_date) > trunc(sysdate));
	 v_test := '2.7';
	         FOR ecrd_ref_child_repair IN eCRD_Child_repair(v_repair_seq_id)
	         LOOP
	            SELECT
	               COUNT(1)
	            INTO
	               v_child_repair_count
	            FROM
	               CRD_E_REPAIR_CATALOG
	            WHERE
	               repair_seq_id = ecrd_ref_child_repair.repair_seq_id AND
	               catalog_seq_id = p_in_customer_catalog_id;
	v_test := '2.8.1';
	            IF(v_child_repair_count = 0)
	            THEN
	               INSERT INTO CRD_E_REPAIR_CATALOG
	               (
                    /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - Begin */
                    crd_e_repair_catalog_seq_id,
                    /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - End */
	                  repair_seq_id,            --1
	                  catalog_seq_id,           --2
	                  effective_date,           --3
	                  repair_price,             --4
	                  incremental_price_ind,    --5
	                  repair_tat,               --6
	                  incremental_tat_ind,      --7
	                  future_price,             --8
	                  future_effective_date,    --9
	                  price_type,               --10
	                  repair_end_date,          --11
	                  repair_display_seq_id,    --12
	                  future_tat,               --13
	                  price_overwrite_flag_ind, --14
	                  created_by,               --15
	                  creation_date,            --16
	                  last_update_date,         --17
	                  last_updated_by,          --18
	            		default_repair_ind		  --19
	               )
	               SELECT
	                  /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - Begin */
                    crd_e_repair_catalog_seq.nextval,
                    /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - End */
                    ecrd_ref_child_repair.repair_seq_id,   --1
	                  p_in_customer_catalog_id,     --2
	                  SYSDATE,			               --3
	                  NULL,                         --4
	                  NULL,                         --5
	                  NULL,                         --6
	                  NULL,                         --7
	                  NULL,                         --8
	                  NULL,                         --9
	                  NULL,                         --10
	                  NULL,                         --11
	                  cerc.repair_display_seq_id,   --12
	                  NULL,                         --13
	                  NULL,                         --14
	                  p_in_user_id,                 --15
	                  SYSDATE,                      --16
	                  SYSDATE,                      --17
	                  p_in_user_id,                 --18
			            DECODE(v_default_ind_status, 'N', 'Y', 'N') --19
	               FROM
	                  crd_e_repair_catalog cerc
	               WHERE
	                  cerc.repair_seq_id = ecrd_ref_child_repair.repair_seq_id AND
	                  cerc.catalog_seq_id = p_in_default_catalog_id AND
	                  (cerc.repair_end_date IS NULL OR trunc(cerc.repair_end_date) > trunc(sysdate));
	v_test := '2.8.2';
	            END IF;
	         END LOOP;
            p_out_message := 'REPAIR_ADDED_SUCCESSFULLY';
		   END IF;
      ELSE
      	p_out_message := 'REPAIR_WITH_SAME_REPAIR_SEQ_EXISTS';
      END IF;
   END LOOP;
   COMMIT;
EXCEPTION
WHEN OTHERS
THEN
	ROLLBACK;
	RAISE_APPLICATION_ERROR(-20020,'**ecrd_repair_pkg.ecrd_add_repair_to_csc v_test : '||v_test||'=='||SQLCODE||'--'||SQLERRM);
END ecrd_add_repair_to_csc;

FUNCTION ecrd_get_rule_discount_prc
(
	p_in_catalog_seq_id crd_e_catalog.catalog_seq_id%TYPE,
   p_in_component_code crd_e_component.component_code%TYPE,
   p_in_module_seq_id crd_crc_module.module_seq_id%TYPE,
   p_in_repair_seq_id crd_e_repair.repair_seq_id%TYPE
)
RETURN VARCHAR2
IS
   v_discount crd_e_ctlg_contracted.discount%TYPE;
   v_year crd_e_ctlg_contracted.year%TYPE;
BEGIN
   SELECT
      TO_CHAR(SYSDATE,'YYYY')
   INTO
      v_year
   FROM
      dual;

   BEGIN
   	SELECT
      	discount
      INTO
      	v_discount
      FROM
      	crd_e_contracted_repair
      WHERE
      	repair_seq_id = p_in_repair_seq_id AND
         year = v_year;
      EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
      	BEGIN
		      SELECT
		         discount
		      INTO
		         v_discount
		      FROM
		         CRD_E_CONTRACTED_COMP
		      WHERE
		         catalog_seq_id = p_in_catalog_seq_id  AND
		         component_code = p_in_component_code AND
		         module_seq_id = p_in_module_seq_id AND
		         year = v_year;
		   	EXCEPTION
		      WHEN NO_DATA_FOUND
		      THEN
		         BEGIN
		            SELECT
		               discount
		            INTO
		               v_discount
		            FROM
		               crd_e_contracted_module
		            WHERE
		               catalog_seq_id = p_in_catalog_seq_id  AND
		               module_seq_id = p_in_module_seq_id AND
		               year = v_year;
		        	 	EXCEPTION
		            WHEN NO_DATA_FOUND
		            THEN
		               BEGIN
		                  SELECT
		                     discount
		                  INTO
		                     v_discount
		                  FROM
		                     crd_e_ctlg_contracted
		                  WHERE
		                     catalog_seq_id = p_in_catalog_seq_id  AND
		                     year = v_year;
		               	EXCEPTION
		                  WHEN NO_DATA_FOUND
		                  THEN
		                     v_discount := 0;
		               END;
		         END;
         END;
   END;

   dbms_output.put_line('discount that will be displayed :  :  : '||v_discount);
   RETURN v_discount;
EXCEPTION
WHEN OTHERS
THEN
   RAISE_APPLICATION_ERROR(-20020,'Error in ecrd_repair_pkg.ecrd_get_rule_discount_prc **'||SQLCODE||SQLERRM);
END ecrd_get_rule_discount_prc;

FUNCTION ecrd_rule_exists_fnc
(
	p_in_catalog_seq_id crd_e_catalog.catalog_seq_id%TYPE,
   p_in_component_code crd_e_component.component_code%TYPE,
   p_in_module_seq_id crd_crc_module.module_seq_id%TYPE,
   p_in_repair_seq_id crd_e_repair.repair_seq_id%TYPE
)
RETURN VARCHAR2
IS
   v_repair_count NUMBER := 0;
   v_module_count NUMBER := 0;
   v_component_count NUMBER := 0;
   v_catalog_count NUMBER := 0;
   v_status VARCHAR2(1) := 'N';
   v_year crd_e_ctlg_contracted.year%TYPE;
BEGIN
   SELECT
      TO_CHAR(SYSDATE,'YYYY')
   INTO
      v_year
   FROM
      dual;

  	SELECT
     	count(1)
     INTO
     	v_repair_count
     FROM
     	crd_e_contracted_repair
     WHERE
     	repair_seq_id = p_in_repair_seq_id AND
      year = v_year;

   IF(v_repair_count = 0)
   THEN
      SELECT
         count(1)
      INTO
         v_component_count
      FROM
         CRD_E_CONTRACTED_COMP
      WHERE
         catalog_seq_id = p_in_catalog_seq_id  AND
         component_code = p_in_component_code AND
         module_seq_id = p_in_module_seq_id AND
         year = v_year;

      IF(v_component_count = 0)
      THEN
         SELECT
            count(1)
         INTO
            v_module_count
         FROM
            crd_e_contracted_module
         WHERE
            catalog_seq_id = p_in_catalog_seq_id  AND
            module_seq_id = p_in_module_seq_id AND
            year = v_year;

	      IF(v_module_count = 0)
	      THEN
	         SELECT
	            count(1)
	         INTO
	            v_catalog_count
	         FROM
	            crd_e_ctlg_contracted
	         WHERE
	            catalog_seq_id = p_in_catalog_seq_id  AND
	            year = v_year;

            IF(v_catalog_count = 0)
            THEN
            	v_status := 'N';
            ELSE
            	v_status := 'Y';
            END IF;
         ELSE
            v_status := 'Y';
		   END IF;
      ELSE
         v_status := 'Y';
		END IF;
   ELSE
      v_status := 'Y';
   END IF;

--   dbms_output.put_line('count(1) that will be displayed :  :  : '||v_count);
   RETURN v_status;
EXCEPTION
WHEN OTHERS
THEN
   RAISE_APPLICATION_ERROR(-20020,'Error in ecrd_repair_pkg.ecrd_rule_exists_fnc **'||SQLCODE||SQLERRM);
END ecrd_rule_exists_fnc;

PROCEDURE ecrd_list_default_repairs_prc(
		    p_in_catalog_id IN NUMBER,
          p_in_eng_model IN VARCHAR2,
          p_in_module IN VARCHAR2,
          p_in_component_type IN VARCHAR2,
          p_in_component IN VARCHAR2,
          p_out_repair_list OUT result_cursor
)
IS

  v_catalog_seq_id NUMBER(9):=0;
  v_err_mess VARCHAR2(1000):='';
  BEGIN

  --  Get the default Catalog Sequence Id for the Model if parameter is NULL

      ecrd_managecatalog_pkg.ecrd_get_default_seqid_prc(p_in_eng_model
                                                      ,v_catalog_seq_id
                                                      ,v_err_mess);
--    ELSE
--       v_catalog_seq_id := p_in_catalog_id;
--    END IF;

		OPEN p_out_repair_list
      FOR
         SELECT * FROM
         (
            SELECT
            	catalog.repair_display_seq_id Display_Sequence,
         		repair.repair_description Repair_Description,
		         repair.repair_reference Repair_Reference,
      		   ecrd_get_sites_fnc(p_in_module,UPPER(p_in_component)) Sites,
		         catalog.repair_price Price,
      		   catalog.price_type Price_Type,
		         catalog.repair_TAT TAT,
		         repair.repair_seq_id repair_seq_id,
		         catalog.incremental_price_ind incremental_price_ind,
		         catalog.incremental_tat_ind incremental_tat_ind,
		         repair.repair_type repair_type
      		FROM
            	crd_e_repair repair,
		         crd_e_repair_catalog_hist catalog
      		WHERE
               catalog.repair_seq_id = repair.repair_Seq_id AND
               (catalog.repair_end_date IS NULL or catalog.repair_end_date > SYSDATE) AND
               catalog.staging_history_ind = ecrd_utils_pkg.G_STAGING AND
               catalog.approved_rejected_date IS NULL AND
               /* Don't Show Child Repairs*/
               repair.repair_type <> 'CR' AND
               repair.module_seq_id = p_in_module AND
               repair.component_code = UPPER(p_in_component) AND
               catalog.catalog_seq_id = v_catalog_seq_id AND
               catalog.repair_seq_id NOT IN (SELECT
               											repair_seq_id
               										FROM
                                             	crd_e_repair_catalog
                                             WHERE
                                             	catalog_seq_id = p_in_catalog_id AND
                                                (repair_end_date IS NULL OR repair_end_date > SYSDATE))
         )
         UNION
         SELECT * FROM
         (
      		SELECT
               catalog.repair_display_seq_id Display_Sequence,
               repair.repair_description Repair_Description,
               repair.repair_reference Repair_Reference,
               ecrd_get_sites_fnc(p_in_module,UPPER(p_in_component)) Sites,
               catalog.repair_price Price,
               catalog.price_type Price_Type,
               catalog.repair_TAT TAT,
               repair.repair_seq_id repair_seq_id,
               catalog.incremental_price_ind incremental_price_ind,
               catalog.incremental_tat_ind incremental_tat_ind,
		         repair.repair_type repair_type
            FROM
            	crd_e_repair repair,
               crd_e_repair_catalog catalog
            WHERE
            	catalog.repair_seq_id = repair.repair_seq_id AND
               (catalog.repair_end_date IS NULL or catalog.repair_end_date > SYSDATE) AND
               repair.repair_type <> 'CR' /* Don't Show Child Repairs*/ AND
               repair.module_seq_id = p_in_module AND
               repair.component_code = UPPER(p_in_component) AND
               catalog.catalog_seq_id = v_catalog_seq_id
--        don't show repairs from Main table that exist in Stagging table as well

               AND   catalog.repair_seq_id NOT IN
               (
      				SELECT
                      repair.repair_seq_id
				      FROM
                      crd_e_repair repair,
					       crd_e_repair_catalog_hist catalog
				      WHERE
                      catalog.repair_seq_id = repair.repair_Seq_id AND
                      (catalog.repair_end_date IS NULL or catalog.repair_end_date > SYSDATE) AND
                      catalog.staging_history_ind = ecrd_utils_pkg.G_STAGING AND
                      catalog.approved_rejected_date IS NULL AND
                      /* Don't Show Child Repairs*/
                      repair.repair_type <> 'CR' AND
                      repair.module_seq_id = p_in_module AND
                      repair.component_code = UPPER(p_in_component) AND
                      catalog.catalog_seq_id = v_catalog_seq_id
               ) AND
	            catalog.repair_seq_id NOT IN (SELECT
																repair_seq_id
															FROM
	                            						crd_e_repair_catalog
	                            					WHERE
	                            						catalog_seq_id = p_in_catalog_id AND
	                               					(repair_end_date IS NULL OR repair_end_date > SYSDATE))
         )/*
         UNION
         SELECT * FROM
         (
         	SELECT
               catalog.repair_display_seq_id Display_Sequence,
         		repair.repair_description Repair_Description,
		         repair.repair_reference Repair_Reference,
      		   ecrd_get_sites_fnc(p_in_module,UPPER(p_in_component)) Sites,
		         catalog.repair_price Price,
		         catalog.price_type Price_Type,
		         catalog.repair_TAT TAT,
		         repair.repair_seq_id repair_seq_id,
		         catalog.incremental_price_ind incremental_price_ind,
		         catalog.incremental_tat_ind incremental_tat_ind,
		         repair.repair_type repair_type
      		FROM
               crd_e_repair_history repair,
         		crd_e_repair_catalog_hist catalog
		      WHERE
               catalog.repair_seq_id = repair.repair_Seq_id AND
               (catalog.repair_end_date IS NULL or catalog.repair_end_date > SYSDATE) AND
               repair.staging_history_ind = ecrd_utils_pkg.G_STAGING AND
               repair.approved_rejected_date IS NULL AND
               -- Don't Show Child Repairs
               repair.repair_type <> 'CR' AND
               repair.module_seq_id = p_in_module AND
               repair.component_code = UPPER(p_in_component) AND
               catalog.catalog_seq_id =v_catalog_seq_id
      	)*/

         order by 1;
  EXCEPTION
  WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20001,'ERROR IN ecrd_e_repair_pkg.ecrd_list_default_repairs_prc' ||SQLCODE ||  ' - ' || SQLERRM);

  END ecrd_list_default_repairs_prc;
END ecrd_repair_pkg;
/
