CREATE OR REPLACE PACKAGE ecrd_reports_pkg
AS
/***********************************************************************/
--
-- Copyright Message 	   : Copyright(c) 2004 GE Aircraft Engines
-- Title                   : ecrd_reports_pkg
-- Author                  : Patni Offshore
-- Company           	   : GE Aircraft Engines
-- Date                    : October 2004
-- Purpose             	   : File contains Package Spec and body for Procs
--                           for Report Generation
--
-- Modifications      	   :
-- Date                   	Description
-- [DD-MMM-YYYY]          	This package displays the list repair reports for
--                        	the corresponding engine model,feature(added,deleted,modified)
--							and dates between which we require to retreive the reports.
--
-- 21-oct-2004         	      New Code First Version
--
/***********************************************************************/
TYPE result_cursor IS REF CURSOR;


PROCEDURE ecrd_price_list_report_prc(
	      							 p_in_engine_model IN crd_crc_module.ENG_MDL_NUMBER%TYPE
          							  ,p_in_report_desc IN VARCHAR2
									  ,p_in_start_date IN VARCHAR2
									  ,p_in_end_date IN VARCHAR2
									  ,p_out_report_list OUT result_cursor
          							  ,p_out_error_msg OUT VARCHAR2
									 );

PROCEDURE ecrd_search_catalog_prc(
				p_in_eng_model IN crd_crc_eng_mdl_display.eng_mdl_number%TYPE,
            p_in_start_date IN VARCHAR2,
            p_in_end_date IN VARCHAR2,
            p_in_customer_code IN VARCHAR2,
            p_in_only_default IN VARCHAR2,
            p_in_catalog_num	IN crd_e_catalog.catalog_number%TYPE,
            p_out_catalog_list OUT result_cursor
);

PROCEDURE ecrd_load_catalog_details_prc(
				p_in_catalog_seq_id IN crd_e_catalog.catalog_seq_id%TYPE,
            p_out_catalog_details OUT result_cursor,
            p_out_child_repair_details OUT result_cursor,
            p_out_year OUT VARCHAR2
);
--
PROCEDURE ecrd_get_eng_rev_yld_prc(p_in_cat_seq_id  IN crd_e_catalog.catalog_seq_id%TYPE
											 --,p_in_end_model        IN crd_crc_eng_mdl_display.eng_mdl_number%TYPE
                                  ,p_out_data            OUT result_cursor	
);
--
PROCEDURE ecrd_get_adhoc_prc(      p_in_select			            IN VARCHAR2
						                ,p_in_where			            IN VARCHAR2
						                ,p_in_repair_num_not_pres			IN VARCHAR2
						                ,p_in_part_num_not_pres			IN VARCHAR2
						                ,p_in_TAT_where						IN VARCHAR2        
						                ,p_in_price_where					IN VARCHAR2         
                                  ,p_is_cost_reqd						IN VARCHAR2	                                                                                                      										
                                  ,p_out_data         				OUT result_cursor	
                                --,p_out_cost_data         			OUT result_cursor                                  
                                  ,p_out_error							OUT VARCHAR2
);
--
FUNCTION ecrd_get_comp_location_fnc(
			p_in_module_seq_id  IN CRD_E_COMPONENT_LOCATION.module_seq_id%TYPE,
			p_in_component_code IN CRD_E_COMPONENT_LOCATION.component_code%TYPE
		  	)
RETURN VARCHAR2;
--
FUNCTION ecrd_get_part_nums_fnc(
			 p_in_module_seq_id  IN CRD_E_COMPONENT_LOCATION.module_seq_id%TYPE
			,p_in_component_code IN CRD_E_COMPONENT_LOCATION.component_code%TYPE
         ,p_in_sep				IN VARCHAR2
		  	)
RETURN VARCHAR2;
--------------------------------------

PROCEDURE ecrd_get_price_changes_yrl_prc
(
     p_in_module_seq_id IN crd_crc_module.module_seq_id%TYPE,
     p_in_catalog_seq_id IN crd_e_repair_catalog.catalog_seq_id%TYPE,
     p_in_catalog_type   IN crd_e_catalog.catalog_type%TYPE,
     p_out_repair_price_changes OUT result_cursor    
);

--------------------------------------
FUNCTION ecrd_get_catalog_number(
			 p_catalog_number IN VARCHAR2
		  	)
RETURN VARCHAR2; 

FUNCTION ecrd_rep_lvl_rule_exists_prc
(
	p_in_catalog_seq_id crd_e_catalog.catalog_seq_id%TYPE,
   p_in_repair_seq_id crd_e_repair.repair_seq_id%TYPE
)
RETURN VARCHAR2;
          
FUNCTION ecrd_get_tat_comp_or_rule_prc
(
	p_in_catalog_seq_id crd_e_catalog.catalog_seq_id%TYPE,
   p_in_component_code crd_e_component.component_code%TYPE,
   p_in_module_seq_id crd_crc_module.module_seq_id%TYPE
)
RETURN VARCHAR2;

FUNCTION ecrd_rule_exists_fnc
(
	p_in_catalog_seq_id crd_e_catalog.catalog_seq_id%TYPE,
   p_in_component_code crd_e_component.component_code%TYPE,
   p_in_module_seq_id crd_crc_module.module_seq_id%TYPE,
   p_in_repair_seq_id crd_e_repair.repair_seq_id%TYPE
)
RETURN VARCHAR2;
          
END ecrd_reports_pkg;
/

CREATE OR REPLACE PACKAGE BODY ecrd_reports_pkg AS

---
/********************************************************************************/
/* Procedure Name :  ecrd_price_list_report_prc                              	*/
/* 			 	  	 															*/
/* Description    :  This procedure  retreives price list report .				*/
/* 				  	 	  			   		   		  					    	*/
/*   				 				        			 						*/
/* Input Parameters : Engine Model Code 										*/
/* 		 			  Feature	   												*/
/* 		 			  Start date,  												*/
/*					  End date,													*/
/*                                                        						*/
/* Out Parameters :  Cursor of Price list report	  	 						*/
/* 	   			  	 Error mesage		 	  		 							*/
/********************************************************************************/

PROCEDURE ecrd_price_list_report_prc(
	      							  p_in_engine_model IN crd_crc_module.ENG_MDL_NUMBER%TYPE
          							  ,p_in_report_desc IN VARCHAR2
									  ,p_in_start_date IN VARCHAR2
									  ,p_in_end_date IN VARCHAR2
									  ,p_out_report_list OUT result_cursor
          							  ,p_out_error_msg OUT VARCHAR2
									 )

IS
v_sign_TAT VARCHAR2(5);
v_sign_PRICE VARCHAR2(5);
v_in_start_date DATE :=null;
v_in_end_date DATE := null;

BEGIN

v_in_start_date := TO_DATE(p_in_start_date,ecrd_utils_pkg.G_DATE_FORMAT);
v_in_end_date   := TO_DATE(p_in_end_date,ecrd_utils_pkg.G_DATE_FORMAT);

IF (p_in_report_desc = 'added') THEN

   	OPEN 	p_out_report_list
 		FOR

			SELECT ccemd.ENG_MDL_DESC,
				   ccm.MODULE_NAME,
				   cec.COMPONENT_CODE,
				   cec.COMPONENT_DESCRIPTION,
				   cer.REPAIR_DESCRIPTION,
				   cerc.INCREMENTAL_TAT_IND,
				   cerc.INCREMENTAL_PRICE_IND,
				   cerc.REPAIR_TAT,
				   cerc.REPAIR_PRICE,
				   cerc.PRICE_TYPE,
				   UPPER(cru.LAST_NAME || ',' ||cru.FIRST_NAME),
				   --cerc.LAST_UPDATED_BY,
				   TO_CHAR(cerc.LAST_UPDATE_DATE,ecrd_utils_pkg.G_DISPLAY_DATE_FORMAT),
				   --cerc.CREATED_BY,
				   UPPER(cru1.LAST_NAME|| ',' ||cru1.FIRST_NAME),
				   TO_CHAR(cerc.CREATION_DATE,ecrd_utils_pkg.G_DISPLAY_DATE_FORMAT)
			FROM
				crd_e_repair cer,crd_e_repair_catalog cerc ,crd_crc_module ccm,crd_e_component cec,crd_crc_eng_mdl_display ccemd,crd_crc_user cru,crd_crc_user cru1,crd_e_catalog ceca
			WHERE
				  ccm.ENG_MDL_NUMBER = p_in_engine_model
			and	  ccm.ENG_MDL_NUMBER = ccemd.ENG_MDL_NUMBER
			and	  TRUNC(cerc.EFFECTIVE_DATE) BETWEEN v_in_start_date AND v_in_end_date
			and	  cer.REPAIR_SEQ_ID = cerc.REPAIR_SEQ_ID
			and   cer.MODULE_SEQ_ID = ccm.MODULE_SEQ_ID
			and   ccm.MODULE_SEQ_ID = cec.MODULE_SEQ_ID
			and   cec.COMPONENT_CODE = cer.COMPONENT_CODE
			and   UPPER(cru.USERID)=UPPER(cer.CREATED_BY)
			and UPPER(cru1.USERID)=UPPER(cerc.LAST_UPDATED_BY)
         and cer.repair_type IN (ecrd_utils_pkg.G_GROUP_REPAIR, ecrd_utils_pkg.G_INDIVIDUAL_REPAIR)
         and ceca.eng_mdl_number = ccm.eng_mdl_number 
         and ceca.catalog_type = ecrd_utils_pkg.G_DEFAULT_CATALOG
         and ceca.catalog_seq_id = cerc.catalog_seq_id
         and (ceca.catalog_effective_date < SYSDATE and ceca.catalog_end_date > SYSDATE);  

	ELSIF (p_in_report_desc='modified')

   	THEN
   	   	  	   OPEN 	p_out_report_list
 			   FOR

							SELECT ccemd.ENG_MDL_DESC,
								   ccm.MODULE_NAME,
								   cec.COMPONENT_CODE,
								   cec.COMPONENT_DESCRIPTION,
								   cer.REPAIR_DESCRIPTION,
								   cerc.INCREMENTAL_TAT_IND,
								   cerc.INCREMENTAL_PRICE_IND,
								   cerc.REPAIR_TAT,
								   cerc.REPAIR_PRICE,
								   cerc.PRICE_TYPE,
								   UPPER(cru.LAST_NAME || ',' ||cru.FIRST_NAME),
								   --cerc.LAST_UPDATED_BY,
								   TO_CHAR(cerc.LAST_UPDATE_DATE,ecrd_utils_pkg.G_DISPLAY_DATE_FORMAT),
								   --cerc.CREATED_BY,
								   UPPER(cru1.LAST_NAME || ',' ||cru1.FIRST_NAME),
								   TO_CHAR(cerc.CREATION_DATE,ecrd_utils_pkg.G_DISPLAY_DATE_FORMAT)
							FROM
								   crd_e_repair cer ,crd_e_repair_catalog_hist cerh ,crd_e_repair_catalog cerc ,crd_crc_module ccm,crd_e_component cec,crd_crc_eng_mdl_display ccemd,crd_crc_user cru,crd_crc_user cru1,crd_e_catalog ceca
							WHERE
								   ccm.ENG_MDL_NUMBER = p_in_engine_model
							and	  ccm.ENG_MDL_NUMBER = ccemd.ENG_MDL_NUMBER
							and	   TRUNC(cerh.CHANGE_START_DATE) BETWEEN v_in_start_date AND v_in_end_date
							and	   cer.REPAIR_SEQ_ID = cerh.REPAIR_SEQ_ID
							and	   cer.REPAIR_SEQ_ID = cerc.REPAIR_SEQ_ID
							and    cer.MODULE_SEQ_ID = ccm.MODULE_SEQ_ID
							and    ccm.MODULE_SEQ_ID = cec.MODULE_SEQ_ID
							and    cec.COMPONENT_CODE = cer.COMPONENT_CODE
							and   UPPER(cru.USERID)=UPPER(cer.CREATED_BY)
							and UPPER(cru1.USERID)=UPPER(cerc.LAST_UPDATED_BY)
                     and cer.repair_type IN (ecrd_utils_pkg.G_GROUP_REPAIR, ecrd_utils_pkg.G_INDIVIDUAL_REPAIR)
                     and ceca.eng_mdl_number = ccm.eng_mdl_number 
				         and ceca.catalog_type = ecrd_utils_pkg.G_DEFAULT_CATALOG
				         and ceca.catalog_seq_id = cerc.catalog_seq_id
				         and (ceca.catalog_effective_date < SYSDATE and ceca.catalog_end_date > SYSDATE);


	ELSIF (p_in_report_desc='deleted')

   	THEN
   	   	  	   OPEN 	p_out_report_list
 			   FOR
					SELECT ccemd.ENG_MDL_DESC,
						   ccm.MODULE_NAME,
						   cec.COMPONENT_CODE,
						   cec.COMPONENT_DESCRIPTION,
						   cer.REPAIR_DESCRIPTION,
						   cerc.INCREMENTAL_TAT_IND,
						   cerc.INCREMENTAL_PRICE_IND,
						   cerc.REPAIR_TAT,
						   cerc.REPAIR_PRICE,
						   cerc.PRICE_TYPE,
						   UPPER(cru.LAST_NAME || ' ' ||cru.FIRST_NAME),
						   --cerc.LAST_UPDATED_BY,
					  	   TO_CHAR(cerc.LAST_UPDATE_DATE,ecrd_utils_pkg.G_DISPLAY_DATE_FORMAT),
						   --cerc.CREATED_BY,
						   UPPER(cru1.FIRST_NAME || ' ' ||cru1.LAST_NAME),
						   TO_CHAR(cerc.CREATION_DATE,ecrd_utils_pkg.G_DISPLAY_DATE_FORMAT)
					FROM
						crd_e_repair cer ,crd_e_repair_catalog cerc ,crd_crc_module ccm,crd_e_component cec,crd_crc_eng_mdl_display ccemd,crd_crc_user cru,crd_crc_user cru1,crd_e_catalog ceca
					WHERE
						  ccm.ENG_MDL_NUMBER = p_in_engine_model
					and	  ccm.ENG_MDL_NUMBER = ccemd.ENG_MDL_NUMBER
					and	  TRUNC(cerc.REPAIR_END_DATE) BETWEEN v_in_start_date AND v_in_end_date
					and	  cer.REPAIR_SEQ_ID = cerc.REPAIR_SEQ_ID
					and   cer.MODULE_SEQ_ID = ccm.MODULE_SEQ_ID
					and   ccm.MODULE_SEQ_ID = cec.MODULE_SEQ_ID
					and   cec.COMPONENT_CODE = cer.COMPONENT_CODE
					and   UPPER(cru.USERID)=UPPER(cer.CREATED_BY)
					and UPPER(cru1.USERID)=UPPER(cerc.LAST_UPDATED_BY)
               and cer.repair_type IN (ecrd_utils_pkg.G_GROUP_REPAIR, ecrd_utils_pkg.G_INDIVIDUAL_REPAIR)
               and ceca.eng_mdl_number = ccm.eng_mdl_number 
		         and ceca.catalog_type = ecrd_utils_pkg.G_DEFAULT_CATALOG
		         and ceca.catalog_seq_id = cerc.catalog_seq_id
		         and (ceca.catalog_effective_date < SYSDATE and ceca.catalog_end_date > SYSDATE);

	END IF;
EXCEPTION
	WHEN OTHERS
	THEN
	p_out_error_msg	:=substr(SQLERRM,1,50);
	RAISE_APPLICATION_ERROR(-20101,'Error in ecrd_price_list_report_prc'|| SQLCODE ||  ' - ' || SQLERRM);
END ecrd_price_list_report_prc;

PROCEDURE ecrd_search_catalog_prc(
				p_in_eng_model IN crd_crc_eng_mdl_display.eng_mdl_number%TYPE,
            p_in_start_date IN VARCHAR2,
            p_in_end_date IN VARCHAR2,
            p_in_customer_code IN VARCHAR2,
            p_in_only_default IN VARCHAR2,
            p_in_catalog_num	IN crd_e_catalog.catalog_number%TYPE,
            p_out_catalog_list OUT result_cursor
)
IS
	v_main_query LONG;
   v_where_query LONG;
BEGIN
	
   v_main_query :='SELECT 	
   						cc.CATALOG_SEQ_ID cat_seq_id,
	 						NVL(cc.catalog_number,cem.ENG_MDL_DESC) Engine_Model,	-- Show Catalog Number for Customer Catalog
	 						TO_CHAR(cc.catalog_effective_date,'''||ecrd_utils_pkg.G_DISPLAY_DATE_FORMAT||''') Start_Date,
							TO_CHAR(cc.catalog_effective_date,'||'''YYYY/MM/DD'''||') Sortable_Start_Date,
							TO_CHAR(cc.catalog_end_date,'''||ecrd_utils_pkg.G_DISPLAY_DATE_FORMAT||''') End_Date,
							TO_CHAR(cc.catalog_end_date,'||'''YYYY/MM/DD'''||') Sortable_End_Date,				
   						cc.catalog_description Description,
	 						cc.catalog_type	cat_type,
                     ecrd_reports_pkg.ecrd_get_catalog_number(NVL(cc.catalog_number,cem.ENG_MDL_DESC)) Catalog_number
    					FROM 	
 	                 	crd_e_catalog cc,
   	               crd_crc_eng_mdl_display cem
    					WHERE	
                  	cc.eng_mdl_number = '''||p_in_eng_model||'''	AND	
                     cem.ENG_MDL_NUMBER = cc.ENG_MDL_NUMBER';

	IF p_in_start_date IS NOT NULL
	THEN
	   v_where_query := v_where_query ||' AND TO_DATE(cc.catalog_effective_date)>=TO_DATE('''||p_in_start_date||''',''MM/DD/YYYY'')';
	END IF;

	IF p_in_customer_code IS NOT NULL
   THEN
	   v_where_query := v_where_query || ' AND EXISTS (SELECT 
      																	DISTINCT catalog_seq_id
		  	  		  													FROM 
                                                      	crd_e_customer_contract crn,
                                                         crd_e_customer cru
		  			  													WHERE 
                                                      	cru.customer_code ='''||p_in_customer_code||''' AND 
                                                         crn.customer_code = cru.customer_code AND  
                                                         cc.catalog_seq_id = crn.catalog_seq_id)';
   END IF;
   --INSERT INTO ROSHAN_TEST VALUES('p_in_only_default',p_in_only_default);
   IF p_in_only_default IS NOT NULL
   THEN
   	--INSERT INTO ROSHAN_TEST VALUES('p_in_only_default',p_in_only_default);
	   v_where_query := v_where_query || ' AND cc.catalog_type ='''||ecrd_utils_pkg.G_DEFAULT_CATALOG ||''' ';
   END IF;  
   IF  p_in_end_date IS NOT NULL
	THEN
	  	v_where_query := v_where_query ||' AND TO_DATE(cc.catalog_end_date)<=TO_DATE('''||p_in_end_date||''',''MM/DD/YYYY'')';
	END IF;
    --
   IF(p_in_catalog_num IS NOT NULL)
   THEN
   		v_where_query := v_where_query ||' AND TRIM(UPPER(cc.catalog_number)) LIKE ''%'||TRIM(UPPER(p_in_catalog_num))||'%''';
   END IF;
   --
   OPEN p_out_catalog_list
   FOR v_main_query||v_where_query;
   
   
   
EXCEPTION
	WHEN OTHERS
   THEN
   	RAISE_APPLICATION_ERROR(-20101,'**Error in ecrd_reports_pkg.ecrd_search_catalog_prc **'||SQLCODE||'--'||SQLERRM);
END ecrd_search_catalog_prc;

PROCEDURE ecrd_load_catalog_details_prc(
				p_in_catalog_seq_id IN crd_e_catalog.catalog_seq_id%TYPE,
            p_out_catalog_details OUT result_cursor,
            p_out_child_repair_details OUT result_cursor,
            p_out_year OUT VARCHAR2
)
IS
	v_step NUMBER := 0;
   v_eng_model crd_e_catalog.eng_mdl_number%TYPE := '';
BEGIN
	v_step :=1;
   SELECT
   	TO_CHAR(catalog_effective_date,'YYYY'),
      eng_mdl_number
   INTO
   	p_out_year,
      v_eng_model
   FROM
   	crd_e_catalog
   WHERE
   	catalog_seq_id = p_in_catalog_seq_id;
      
   v_step := 2;
   
	OPEN p_out_catalog_details
   FOR
   	SELECT 
      	module.module_name,
         comp.component_code "Component Code",
         comp.component_description "Component/Parts",
			ecrd_reports_pkg.ecrd_get_comp_location_fnc(module.module_seq_id,comp.component_code) "Repair Sites",
         ata_reference_snum "ATA/Repair Number",
         DECODE(prepair.repair_type,ecrd_utils_pkg.G_CHILD_REPAIR,'  '||prepair.repair_description,prepair.repair_description) "Repair Description",
         --DECODE(repcatalog.incremental_tat_ind,'Y','+')||DECODE(repcatalog.repair_tat,0,'',repcatalog.repair_tat) "TAT Days",
         --ecrd_reports_pkg.ecrd_rep_lvl_rule_exists_prc(p_in_catalog_seq_id,prepair.repair_seq_id) "TAT Days",
         DECODE(ecrd_reports_pkg.ecrd_rep_lvl_rule_exists_prc(p_in_catalog_seq_id,prepair.repair_seq_id),NULL,DECODE(ecrd_reports_pkg.ecrd_rule_exists_fnc(p_in_catalog_seq_id,comp.component_code,comp.module_seq_id,prepair.repair_seq_id),'N',repcatalog.repair_tat),ecrd_reports_pkg.ecrd_rep_lvl_rule_exists_prc(p_in_catalog_seq_id,prepair.repair_seq_id)) "TAT Days",
         DECODE(repcatalog.incremental_price_ind,'Y','+')||DECODE(repcatalog.price_type,'QUOTE','QUOTE',repcatalog.repair_price) "Price",
			ecrd_managecomponent_pkg.ecrd_get_comp_parts_fnc(module.module_seq_id,comp.component_code) "Part Number",
         prepair.repair_reference "Repair display Id",
         prepair.repair_type "Repair Type",
         prepair.parent_repair_seq_id "Parent Repair Id",
         prepair.repair_comments "Repair Comments",
         prepair.repair_seq_id "Repair Id",
         DECODE(ecrd_reports_pkg.ecrd_get_tat_comp_or_rule_prc(p_in_catalog_seq_id,comp.component_code,comp.module_seq_id),'','',ecrd_reports_pkg.ecrd_get_tat_comp_or_rule_prc(p_in_catalog_seq_id,comp.component_code,comp.module_seq_id)) "Component Level Baseline TAT"
      FROM
      	crd_crc_module module,
         crd_e_component comp,
         crd_e_repair prepair,
         crd_e_repair_catalog repcatalog
     WHERE 
         comp.module_seq_id = module.module_seq_id AND 
     		prepair.module_seq_id = module.module_seq_id AND 
         prepair.component_code = comp.component_code AND 
         prepair.repair_seq_id = repcatalog.repair_seq_id AND 
        (comp.component_end_date IS NULL OR comp.component_end_date > SYSDATE) AND 
        (repcatalog.repair_end_date IS NULL OR repcatalog.repair_end_date > SYSDATE) AND 
        (prepair.repair_end_date IS NULL OR prepair.repair_end_date > SYSDATE) AND
        prepair.repair_type <> ecrd_utils_pkg.G_CHILD_REPAIR AND
        module.eng_mdl_number = v_eng_model AND 
        repcatalog.catalog_seq_id = p_in_catalog_seq_id 
		  ORDER BY module.module_name
		  		   ,comp.component_code,prepair.repair_seq_id,prepair.parent_repair_seq_id;
   v_step := 3;	
	OPEN p_out_child_repair_details
   FOR
   	SELECT  
      	module.module_name,
         comp.component_code "Component Code",
         comp.component_description "Component/Parts",
			ecrd_reports_pkg.ecrd_get_comp_location_fnc(module.module_seq_id,comp.component_code) "Repair Sites",
         ata_reference_snum "ATA/Repair Number",
         DECODE(prepair.repair_type,ecrd_utils_pkg.G_CHILD_REPAIR,'  '||prepair.repair_description,prepair.repair_description) "Repair Description",
         --DECODE(repcatalog.incremental_tat_ind,'Y','+')||DECODE(repcatalog.repair_tat,0,'',repcatalog.repair_tat) "TAT Days",
         --ecrd_reports_pkg.ecrd_rep_lvl_rule_exists_prc(p_in_catalog_seq_id,prepair.repair_seq_id) "TAT Days",
         DECODE(ecrd_reports_pkg.ecrd_rep_lvl_rule_exists_prc(p_in_catalog_seq_id,prepair.repair_seq_id),NULL,DECODE(ecrd_reports_pkg.ecrd_rule_exists_fnc(p_in_catalog_seq_id,comp.component_code,comp.module_seq_id,prepair.repair_seq_id),'N',repcatalog.repair_tat),ecrd_reports_pkg.ecrd_rep_lvl_rule_exists_prc(p_in_catalog_seq_id,prepair.repair_seq_id)) "TAT Days",
         DECODE(repcatalog.incremental_price_ind,'Y','+')||DECODE(repcatalog.price_type,'QUOTE','QUOTE',repcatalog.repair_price) "Price",
			ecrd_managecomponent_pkg.ecrd_get_comp_parts_fnc(module.module_seq_id,comp.component_code) "Part Number",
         prepair.repair_reference "Repair display Id",
         prepair.repair_type "Repair Type",
         prepair.parent_repair_seq_id "Parent Repair Id",
         prepair.repair_comments "Repair Comments",
         prepair.repair_seq_id "Repair Id",
         DECODE(ecrd_reports_pkg.ecrd_get_tat_comp_or_rule_prc(p_in_catalog_seq_id,comp.component_code,comp.module_seq_id),'','',ecrd_reports_pkg.ecrd_get_tat_comp_or_rule_prc(p_in_catalog_seq_id,comp.component_code,comp.module_seq_id)) "Component Level Baseline TAT"
      FROM
      	crd_crc_module module,
         crd_e_component comp,
         crd_e_repair prepair,
         crd_e_repair_catalog repcatalog
     WHERE 
         comp.module_seq_id = module.module_seq_id AND 
     		prepair.module_seq_id = module.module_seq_id AND 
         prepair.component_code = comp.component_code AND 
         prepair.repair_seq_id = repcatalog.repair_seq_id AND 
        (comp.component_end_date IS NULL OR comp.component_end_date > SYSDATE) AND 
        (repcatalog.repair_end_date IS NULL OR repcatalog.repair_end_date > SYSDATE) AND 
        (prepair.repair_end_date IS NULL OR prepair.repair_end_date > SYSDATE) AND
        module.eng_mdl_number = v_eng_model AND
        prepair.repair_type = ecrd_utils_pkg.G_CHILD_REPAIR AND 
        repcatalog.catalog_seq_id = p_in_catalog_seq_id 
		  ORDER BY module.module_name
		  		   ,comp.component_code,prepair.repair_seq_id,prepair.parent_repair_seq_id;
   v_step := 4;               
EXCEPTION
	WHEN OTHERS
   THEN
   	RAISE_APPLICATION_ERROR(-20101,'**Error in ecrd_reports_pkg.ecrd_load_catalog_details_prc **p_in_catalog_seq_id '||p_in_catalog_seq_id ||' v_step--'||v_step||' '||SQLCODE||'--'||SQLERRM);
END ecrd_load_catalog_details_prc;
/*--------------------------------------------------------------------------------------------------*/
FUNCTION ecrd_get_comp_location_fnc(
			p_in_module_seq_id  IN CRD_E_COMPONENT_LOCATION.module_seq_id%TYPE,
			p_in_component_code IN CRD_E_COMPONENT_LOCATION.component_code%TYPE
		  	)
RETURN VARCHAR2
IS

--	Declare a cursor to get active locations for the component
	CURSOR c_comp_location(v_module_seq_id NUMBER, v_comp_code VARCHAR2)
	IS
	SELECT	cl.site_name
	FROM	crd_e_component_location cecl, crd_location cl
	WHERE	cecl.module_seq_id = v_module_seq_id
	AND	cecl.component_code = v_comp_code
	AND	cecl.active_ind = ecrd_utils_pkg.G_ACTIVE
	AND	cecl.location_id = cl.location_id
	AND   (cecl.hide_component_ind = ecrd_utils_pkg.G_NO);
    
--	Declare variables
	v_location_list	VARCHAR2(4000);		-- 4000 is the limit on the size
 
BEGIN
	v_location_list := '';

--	Retrieve the part numbers for the specified module and component

	FOR cv_comp_location IN c_comp_location(p_in_module_seq_id, p_in_component_code)
	LOOP

--		Check if the size limit has reached (consider comma and space as well)
		IF ((LENGTH(v_location_list) + LENGTH(cv_comp_location.site_name) + 2) > 4000) THEN
			EXIT;	-- Exit from FOR LOOP
		END IF;

--		Add separator if not first entry
		IF (v_location_list IS NOT NULL) THEN
			v_location_list := v_location_list || ', ';
		END IF;

		v_location_list := v_location_list || cv_comp_location.site_name;

	END LOOP;

	RETURN v_location_list;
EXCEPTION
	WHEN OTHERS THEN
		RAISE_APPLICATION_ERROR(-20001,'ERROR IN ecrd_e_managecatalog_pkg.ecrd_get_comp_location_fnc' ||SQLCODE ||  ' - ' || SQLERRM(250));

END;  -- ecrd_get_comp_location_fnc
------------------------------------------------------------------------------------
PROCEDURE ecrd_get_eng_rev_yld_prc(p_in_cat_seq_id  IN crd_e_catalog.catalog_seq_id%TYPE
											 --,p_in_end_model        IN crd_crc_eng_mdl_display.eng_mdl_number%TYPE
                                  ,p_out_data            OUT result_cursor	
                                  )
IS
v_in_def_cat_seq_id crd_e_catalog.catalog_seq_id%TYPE := NULL;
v_end_model crd_e_catalog.ENG_MDL_NUMBER%TYPE := NULL;
v_seqid VARCHAR2(1000) :='';                                  
v_error_msg VARCHAR2(1000) :='';
v_catalog_type VARCHAR2(2) :='';
BEGIN
--
SELECT cc.catalog_type
		,cc.eng_mdl_number
INTO v_catalog_type
	  ,v_end_model	
FROM crd_e_catalog cc
WHERE cc.catalog_seq_id = p_in_cat_seq_id;
--
/*IF (v_catalog_type = ecrd_utils_pkg.G_CUSTOMER_CATALOG)
THEN--catalog type
	ecrd_managecatalog_pkg.ecrd_get_default_seqid_prc(
			 		   							 v_end_model	
												   ,v_seqid 
												   ,v_error_msg 
			 							            );
	v_in_def_cat_seq_id  := TO_NUMBER(v_seqid);*/                           
	OPEN p_out_data
	FOR 
	/*SELECT *
	FROM (*/
		SELECT module.module_name,
		       comp.component_description "Component Description",
		       comp.component_code "Component Code",
		       comp.ata_reference_snum "ATA Chapter",
		       comp.shop_visit_exposure_rate "Shop Visit Exp Rate",
		       comp.scrap_rate_at_exposure "Scrap Rate At Exposure",
		       comp.serviceable_at_exposure "Serviceable at Exposure",
             comp.alternate_component_ind "ALTERNATE PN FLAG",
             comp.quantity_of_engine "QPE",
		       repcatalog.repair_display_seq_id "Display seq",
		       prepair.repair_reference "Repair Reference",
		       prepair.repair_description "Repair Description",
		       comp.repair_yield "Repair Yield",
		       prepair.repair_volume "Repair Volume",
		       cl.site_name "Primary Site",
		       DECODE(repcatalog.incremental_tat_ind,'Y','+')|| DECODE(repcatalog.repair_tat,0,'',repcatalog.repair_tat) "Repair TAT",
		       DECODE(repcatalog.incremental_price_ind,'Y','+')||DECODE(repcatalog.price_type,'QUOTE','QUOTE',repcatalog.repair_price) "Repair Price",
		       NVL(cost.labour_hours,'') "Labor Hours",
		       NVL(cost.material_cost,'') "Material Cost",
             (cost.labour_hours * cl.location_labor_rate +cost.material_cost) "Total Cost",
		       DECODE(repcatalog.repair_price,NULL,'-',0,'-',ROUND((repcatalog.repair_price - (cost.labour_hours * cl.location_labor_rate +cost.material_cost))*100/repcatalog.repair_price,2)) "CM%",
             ROUND(comp.quantity_of_engine*comp.shop_visit_exposure_rate/100*(1-(comp.scrap_rate_at_exposure+comp.serviceable_at_exposure )/100)*comp.repair_yield/100*prepair.repair_volume/100*repcatalog.repair_price,2) "CALC REPAIR REVENUE PER ENGINE",
             ROUND(comp.quantity_of_engine*comp.shop_visit_exposure_rate/100*(1-(comp.scrap_rate_at_exposure+comp.serviceable_at_exposure )/100)*comp.repair_yield/100*prepair.repair_volume/100*(cost.labour_hours * cl.location_labor_rate +cost.material_cost),2) "CALC REPAIR COST PER ENGINE"
		FROM crd_crc_module module,
		     crd_e_component comp,
		     crd_e_repair prepair,
		     crd_e_repair_catalog repcatalog,
		     crd_e_repair_cost cost,
			  crd_e_component_location cecl,
		     crd_location cl
		WHERE comp.module_seq_id = module.module_seq_id
		AND prepair.module_seq_id = module.module_seq_id
		AND prepair.component_code = comp.component_code
		AND prepair.repair_seq_id = repcatalog.repair_seq_id
		AND cost.repair_seq_id= prepair.repair_seq_id 
		AND cost.module_seq_id = prepair.module_seq_id 
		AND cost.component_code= prepair.component_code 
		AND cost.location_id = cecl.location_id
		AND cecl.module_seq_id = prepair.module_seq_id
		AND cecl.component_code =   prepair.component_code
		AND cl.location_id = cecl.location_id
		AND (comp.component_end_date IS NULL OR comp.component_end_date > SYSDATE)
		AND (repcatalog.repair_end_date IS NULL
		OR repcatalog.repair_end_date > SYSDATE)
		AND (prepair.repair_end_date IS NULL OR prepair.repair_end_date > SYSDATE)
      AND repcatalog.catalog_seq_id = p_in_cat_seq_id
      AND module.eng_mdl_number = v_end_model	
      AND prepair.repair_type <> ecrd_utils_pkg.G_CHILD_REPAIR
      AND cecl.site_sequence_number =  (SELECT MIN(site_sequence_number)
      											FROM crd_e_component_location cecl2
                                       WHERE cecl2.module_seq_id= cecl.module_seq_id
                                       AND cecl2.component_code =cecl.component_code
                                       AND cecl2.active_ind= ecrd_utils_pkg.G_ACTIVE )
		AND cecl.active_ind = ecrd_utils_pkg.G_ACTIVE
      ORDER BY module.module_name,
		       comp.component_code ,
		       comp.component_description ;
		/*UNION ALL
		SELECT module.module_name,
		       comp.component_description "Component Description",
		       comp.component_code "Component Code",
		       comp.ata_reference_snum "ATA Chapter",
		       comp.shop_visit_exposure_rate "Shop Visit Exp Rate",
		       comp.scrap_rate_at_exposure "Scrap Rate At Exposure",
		       comp.serviceable_at_exposure "Serviceable at Exposure",
		       repcatalog.repair_display_seq_id "Display seq",
		       prepair.repair_reference "Repair Reference",
		       prepair.repair_description "Repair Description",
		       comp.repair_yield "Repair Yield",
		       prepair.repair_volume "Repair Volume",
		       cl.site_name "Primary Site",
		       DECODE(repcatalog.incremental_tat_ind,'Y','+')||DECODE(repcatalog.repair_tat,0,'',repcatalog.repair_tat) "Repair TAT",
		       DECODE(repcatalog.incremental_price_ind,'Y','+')||DECODE(repcatalog.price_type,'QUOTE','QUOTE',repcatalog.repair_price) "Repair Price",
		       NVL(cost.labour_hours,'') "Labor Hours",
		       NVL(cost.material_cost,'') "Material Cost",
             (cost.labour_hours * cl.location_labor_rate +cost.material_cost) "Total Cost",
		       DECODE(repcatalog.repair_price,NULL,'-',0,'-',ROUND((repcatalog.repair_price - (cost.labour_hours * cl.location_labor_rate +cost.material_cost))*100/repcatalog.repair_price,2)) "CM%"
		FROM crd_crc_module module,
		     crd_e_component comp,
		     crd_e_repair prepair,
		     crd_e_repair_catalog repcatalog,
		     crd_e_repair_cost cost,
			  crd_e_component_location cecl,
		     crd_location cl
		WHERE comp.module_seq_id = module.module_seq_id
		AND prepair.module_seq_id = module.module_seq_id
		AND prepair.component_code = comp.component_code
		AND prepair.repair_seq_id = repcatalog.repair_seq_id
		AND cost.repair_seq_id= prepair.repair_seq_id 
		AND cost.module_seq_id = prepair.module_seq_id 
		AND cost.component_code= prepair.component_code 
		AND cost.location_id = cecl.location_id
		AND cecl.module_seq_id = prepair.module_seq_id
		AND cecl.component_code =   prepair.component_code
		AND cl.location_id = cecl.location_id
		AND (comp.component_end_date IS NULL OR comp.component_end_date > SYSDATE)
		AND (repcatalog.repair_end_date IS NULL
		OR repcatalog.repair_end_date > SYSDATE)
		AND (prepair.repair_end_date IS NULL OR prepair.repair_end_date > SYSDATE)
		AND NOT EXISTS (SELECT cercc.repair_seq_id
							 FROM crd_e_repair_catalog cercc
		                WHERE cercc.catalog_seq_id =  p_in_cat_seq_id
                      AND cercc.repair_seq_id =repcatalog.repair_seq_id)   
      AND module.eng_mdl_number =v_end_model	       
      AND repcatalog.catalog_seq_id =v_in_def_cat_seq_id    
      AND prepair.repair_type <> ecrd_utils_pkg.G_CHILD_REPAIR   
      AND cecl.site_sequence_number = ecrd_utils_pkg.G_PRIMARY_SITE_SEQ
		AND cecl.active_ind = ecrd_utils_pkg.G_ACTIVE   
	)
	ORDER BY 1,3,2;
ELSE
   OPEN p_out_data
	FOR 
	SELECT module.module_name,
		       comp.component_description "Component Description",
		       comp.component_code "Component Code",
		       comp.ata_reference_snum "ATA Chapter",
		       comp.shop_visit_exposure_rate "Shop Visit Exp Rate",
		       comp.scrap_rate_at_exposure "Scrap Rate At Exposure",
		       comp.serviceable_at_exposure "Serviceable at Exposure",
		       repcatalog.repair_display_seq_id "Display seq",
		       prepair.repair_reference "Repair Reference",
		       prepair.repair_description "Repair Description",
		       comp.repair_yield "Repair Yield",
		       prepair.repair_volume "Repair Volume",
		       cl.site_name "Primary Site",
		       DECODE(repcatalog.incremental_tat_ind,'Y','+')||DECODE(repcatalog.repair_tat,0,'',repcatalog.repair_tat) "Repair TAT",
		       DECODE(repcatalog.incremental_price_ind,'Y','+')||DECODE(repcatalog.price_type,'QUOTE','QUOTE',repcatalog.repair_price) "Repair Price",
		       NVL(cost.labour_hours,'') "Labor Hours",
		       NVL(cost.material_cost,'') "Material Cost",
             (cost.labour_hours * cl.location_labor_rate +cost.material_cost) "Total Cost",
		       DECODE(repcatalog.repair_price,NULL,'-',0,'-',ROUND((repcatalog.repair_price - (cost.labour_hours * cl.location_labor_rate +cost.material_cost))*100/repcatalog.repair_price,2)) "CM%"
		FROM crd_crc_module module,
		     crd_e_component comp,
		     crd_e_repair prepair,
		     crd_e_repair_catalog repcatalog,
		     crd_e_repair_cost cost,
			  crd_e_component_location cecl,
		     crd_location cl
		WHERE comp.module_seq_id = module.module_seq_id
		AND prepair.module_seq_id = module.module_seq_id
		AND prepair.component_code = comp.component_code
		AND prepair.repair_seq_id = repcatalog.repair_seq_id
		AND cost.repair_seq_id= prepair.repair_seq_id 
		AND cost.module_seq_id = prepair.module_seq_id 
		AND cost.component_code= prepair.component_code 
		AND cost.location_id = cecl.location_id
		AND cecl.module_seq_id = prepair.module_seq_id
		AND cecl.component_code =   prepair.component_code
		AND cl.location_id = cecl.location_id
		AND (comp.component_end_date IS NULL OR comp.component_end_date > SYSDATE)
		AND (repcatalog.repair_end_date IS NULL
		OR repcatalog.repair_end_date > SYSDATE)
		AND (prepair.repair_end_date IS NULL OR prepair.repair_end_date > SYSDATE)
      AND repcatalog.catalog_seq_id = p_in_cat_seq_id
      AND module.eng_mdl_number = v_end_model	
  	   AND prepair.repair_type <> ecrd_utils_pkg.G_CHILD_REPAIR
      AND cecl.site_sequence_number = ecrd_utils_pkg.G_PRIMARY_SITE_SEQ
		AND cecl.active_ind = ecrd_utils_pkg.G_ACTIVE   
      ORDER BY 1,3,2;
END IF;--catalog type*/   
EXCEPTION
	WHEN OTHERS
   THEN
   	RAISE;
END ecrd_get_eng_rev_yld_prc;
--
PROCEDURE ecrd_get_adhoc_prc(      p_in_select			            IN VARCHAR2
						                ,p_in_where			            IN VARCHAR2
						                ,p_in_repair_num_not_pres			IN VARCHAR2
						                ,p_in_part_num_not_pres			IN VARCHAR2
						                ,p_in_TAT_where						IN VARCHAR2        
						                ,p_in_price_where					IN VARCHAR2
                                  ,p_is_cost_reqd	 					IN VARCHAR2                                                                                                            										
                                  ,p_out_data         				OUT result_cursor
                                --,p_out_cost_data         			OUT result_cursor	
                                  ,p_out_error							OUT VARCHAR2
)
AS
v_querry 			VARCHAR2(5000):=' ' ;
BEGIN
		v_querry := p_in_select	;
      v_querry := v_querry 
      				||' FROM  crd_crc_eng_mdl_display ,'
                  ||'  crd_crc_module ,'
					   ||'  crd_e_component ,'
		   			||'  crd_e_repair ,'
					   ||'  crd_e_repair_catalog ,';
      IF (p_is_cost_reqd =ecrd_utils_pkg.G_YES)
      THEN             
      	v_querry := v_querry
		   			||'  crd_e_repair_cost ,'
						||'  crd_e_component_location ,'
                  ||'  crd_location  ,';
      END IF;            
   	   v_querry := v_querry
                  ||'  crd_e_catalog ';
	      v_querry := v_querry
      			   ||' WHERE crd_e_component.module_seq_id = crd_crc_module.module_seq_id ';
      IF (p_is_cost_reqd =ecrd_utils_pkg.G_YES)
      THEN             
      	v_querry := v_querry            
                  ||' AND crd_e_repair_cost.module_seq_id         = crd_e_repair.module_seq_id '
                  ||' AND crd_e_repair_cost.repair_seq_id         = crd_e_repair.repair_seq_id '
                  ||' AND crd_e_repair_cost.location_id           = crd_e_component_location.location_id  '
                  ||' AND crd_e_repair_cost.component_code        = crd_e_component_location.component_code  '                  
                  ||' AND crd_e_component_location.active_ind     = '''||ecrd_utils_pkg.G_ACTIVE ||''' '
						||' AND crd_e_component_location.component_code = crd_e_component.component_code  '
                  ||' AND crd_e_component_location.module_seq_id  = crd_e_component.module_seq_id  '                   
                  ||' AND crd_location.location_id            = crd_e_component_location.location_id ';
                  
      END IF;
			v_querry := v_querry                                                   
						||' AND crd_e_repair.module_seq_id = crd_crc_module.module_seq_id '
						||' AND crd_e_repair.component_code = crd_e_component.component_code '
						||' AND crd_e_repair.repair_seq_id = crd_e_repair_catalog.repair_seq_id '
						||' AND (crd_e_component.component_end_date IS NULL OR crd_e_component.component_end_date > SYSDATE)'
						||' AND (crd_e_repair_catalog.repair_end_date IS NULL '
						||' OR crd_e_repair_catalog.repair_end_date > SYSDATE) '
						||' AND (crd_e_repair.repair_end_date IS NULL OR crd_e_repair.repair_end_date > SYSDATE) '
				      ||' AND crd_e_repair_catalog.catalog_seq_id = crd_e_catalog.catalog_seq_id   '
				      ||' AND  crd_crc_eng_mdl_display.eng_mdl_number  = crd_e_catalog.eng_mdl_number '
				      ||' AND crd_e_catalog.catalog_effective_date <= SYSDATE '
				      ||' AND crd_e_catalog.catalog_end_date >= SYSDATE '
                  ||' AND crd_crc_module.eng_mdl_number =  crd_crc_eng_mdl_display.eng_mdl_number   '
                  ||' AND crd_e_repair.repair_type  <> '''|| ecrd_utils_pkg.G_CHILD_REPAIR||''' '
				      ||' AND crd_e_catalog.catalog_type = '''||ecrd_utils_pkg.G_DEFAULT_CATALOG||''' ';
      --                  
      IF (p_in_repair_num_not_pres =ecrd_utils_pkg.G_YES)
      THEN            
      	v_querry  := v_querry
      					||' AND crd_e_repair.repair_reference IS NULL ';
      END IF;  
      --   
      IF (p_in_TAT_where = ecrd_utils_pkg.G_YES)
      THEN            
      	v_querry  := v_querry
      					||' AND crd_e_repair_catalog.incremental_tat_ind = '''||ecrd_utils_pkg.G_YES||''' ';
		ELSIF (p_in_TAT_where = ecrd_utils_pkg.G_NO)
      THEN
      	v_querry  := v_querry
      					||' AND crd_e_repair_catalog.incremental_tat_ind = '''||ecrd_utils_pkg.G_NO||''' ';		                     
      END IF;
      --  
      IF (p_in_price_where = ecrd_utils_pkg.G_YES)
      THEN            
      	v_querry  := v_querry
      					||' AND crd_e_repair_catalog.incremental_price_ind = '''||ecrd_utils_pkg.G_YES||''' ';
		ELSIF(p_in_price_where = ecrd_utils_pkg.G_NO)
      THEN
      	v_querry  := v_querry
      					||' AND crd_e_repair_catalog.incremental_price_ind = '''||ecrd_utils_pkg.G_NO||''' ';		                     
      END IF;   
      IF(p_in_part_num_not_pres = ecrd_utils_pkg.G_YES)
      THEN
      	v_querry  := v_querry
      					||'AND NOT EXISTS ( SELECT   component_code '
                     				||'			 ,module_seq_id ' 	
										   ||'  FROM     crd_e_part '
											||'  WHERE    crd_e_part.module_seq_id = crd_e_component.module_seq_id  ' 
											||'  AND      crd_e_part.component_code = crd_e_component.component_code ) ';
      END IF;
      --       
      v_querry  := v_querry                    
                  || p_in_where;
      --            
      v_querry  := v_querry
      				||' ORDER BY 1,2,3,4,5,6';
                  
      --                 
      --INSERT INTO ROSHAN_TEST VALUES('VJ',v_querry);     
      OPEN p_out_data 
      FOR     v_querry;    
      p_out_error := v_querry ;
EXCEPTION
	WHEN OTHERS
   THEN  
   		--INSERT INTO ROSHAN_TEST VALUES('VJ',v_querry);
         COMMIT;
   		RAISE;
END ecrd_get_adhoc_prc;
--
FUNCTION ecrd_get_part_nums_fnc(
			 p_in_module_seq_id  IN CRD_E_COMPONENT_LOCATION.module_seq_id%TYPE
			,p_in_component_code IN CRD_E_COMPONENT_LOCATION.component_code%TYPE
         ,p_in_sep				IN VARCHAR2
		  	)
RETURN VARCHAR2
IS
	CURSOR c_comp_part(v_module_seq_id NUMBER, v_comp_code VARCHAR2)
	IS
   SELECT   part_number 
	FROM     crd_e_part part
	WHERE    part.module_seq_id = v_module_seq_id
	AND      part.component_code =v_comp_code
	ORDER BY part_sequence_number;
      
    
--	Declare variables
	v_part_list	VARCHAR2(4000);		-- 4000 is the limit on the size
 
BEGIN
	v_part_list := '';

--	Retrieve the part numbers for the specified module and component

	FOR cv_comp_part IN c_comp_part(p_in_module_seq_id, p_in_component_code)
	LOOP

--		Check if the size limit has reached (consider comma and space as well)
		IF ((LENGTH(v_part_list) + LENGTH(cv_comp_part.part_number ) + 2) > 4000) THEN
			EXIT;	-- Exit from FOR LOOP
		END IF;

--		Add separator if not first entry
		IF (v_part_list IS NOT NULL) THEN
			v_part_list := v_part_list || p_in_sep;
		END IF;

		v_part_list := v_part_list || cv_comp_part.part_number ;
--
	END LOOP;
--
	RETURN v_part_list;
END ecrd_get_part_nums_fnc;
---------------------------------------------------------------

PROCEDURE ecrd_get_price_changes_yrl_prc
(
     p_in_module_seq_id  IN crd_crc_module.module_seq_id%TYPE,
     p_in_catalog_seq_id IN crd_e_repair_catalog.catalog_seq_id%TYPE,
     p_in_catalog_type   IN crd_e_catalog.catalog_type%TYPE,
     p_out_repair_price_changes OUT result_cursor    
)
IS
	  v_date_for_past_yr VARCHAR2(10);
	  v_date_for_current_yr VARCHAR2(10);
     v_year NUMBER;	   
BEGIN

	-- Select the Current Year
	SELECT 
   	TO_CHAR(SYSDATE,'YYYY') 
   INTO
    	v_year
   FROM DUAL;
   
	-- Form the date required   
   v_date_for_past_yr :='01/16/' || TO_CHAR(v_year-1); 
   v_date_for_current_yr :='01/16/' || TO_CHAR(v_year);
  

	/*
      In this case information is taken from the main table as well as history table
      For those repairs for which cost information is modified before 16th Jan of that 
      year, the information would be retrieved from the main table otherwise the  
      information for the corresponding repair would be retrieved from the history table
      which is last updated record.
      
      For newly added repairs information information would be retrieved from the main 
      table.
 	
   */   
   
	-- If the catalog selected is default catalog
   IF p_in_catalog_type = ecrd_utils_pkg.G_DEFAULT_CATALOG
   THEN
   	  OPEN 
        			p_out_repair_price_changes
		  FOR
        /*
         	This query is used to combine the result for getting the cost information 
            of the repairs for the current year as well as past year together for 
            the default catalog.
         */
				   SELECT
							comp_desc,
							repair_desc,
							location,
							SUM(past_cost),
							SUM(past_tat),
							SUM(past_price),
							SUM(cur_cost),
							SUM(cur_tat),
							SUM(cur_price),
							incremental_tat_ind,
							incremental_price_ind
					FROM 
					(
		           /*
			         	This query is used to retrieve the cost information of the repairs for
			            the current year for default catalog
		               
		               Decode Condition Used : 
		               
		               This query is retrieving the records from main and history table both.
		               So if main table information is not empty then get the information from
		               main table otherwise get it from the history table.
                     
                     If the repair cost information is modified after 16 Th Jan and it is 
                     not updated from Jan 1 to Jan 16 th, in that case the cost information 
                     should be picked up from the history table(last modified) as that 
                     would be the cost for that year on 16 th Jan.  
			         */
						SELECT
								DECODE(cur_cost2,NULL,cur_cost1,cur_cost2) cur_cost,
								DECODE(cur_TAT2,NULL,cur_TAT1,cur_TAT2) cur_TAT,
								DECODE(cur_price2,NULL,cur_price1,cur_price2) cur_price,
								0 past_cost,
								0 past_TAT,
								0 past_price,
								DECODE(repair_seq1,NULL,repair_seq2,repair_seq1) repair_seq,
								DECODE(location1,NULL,location2,location1) location,
								DECODE(comp_desc1,NULL,comp_desc2,comp_desc1) comp_desc,
								DECODE(repair_desc1,NULL,repair_desc2,repair_desc1) repair_desc,
								DECODE(incremental_tat_ind2,NULL,incremental_tat_ind1,incremental_tat_ind2) incremental_tat_ind,
								DECODE(incremental_price_ind2,NULL,incremental_price_ind1,incremental_price_ind2) incremental_price_ind
						FROM
						(
        
	             	/*
	               	This query retrives the combined information of the main table as well as 
	                  history table together in the same row - comparing repair seq id and
	                  location. 
	                */
   
							SELECT
									location1 ,
									comp_desc1,
									repair_desc1,
									repair_seq1,
									cur_cost1,
									cur_TAT1,
									cur_price1,
									incremental_tat_ind1,
									incremental_price_ind1,
									location2,
									comp_desc2,
									repair_desc2,
									repair_seq2,
									cur_cost2,
									cur_TAT2,
									cur_price2,
									incremental_tat_ind2,
									incremental_price_ind2 
							FROM
							(
		             		/*
		               		This query retrives the information of all the repairs together 
		                     without getting the records for the same repair seq id and location
		                     together in one row. 
		                	*/
		                              
					      	SELECT	 
										tab1.location location1 ,
										tab1.comp_desc comp_desc1,
										tab1.repair_desc repair_desc1,
										tab1.repair_seq repair_seq1,
										tab1.cur_cost cur_cost1,
										tab1.cur_TAT cur_TAT1,
										tab1.cur_price cur_price1,
										tab1.incremental_tat_ind incremental_tat_ind1,
										tab1.incremental_price_ind incremental_price_ind1,
										tab2.location location2,
										tab2.comp_desc comp_desc2,
										tab2.repair_desc repair_desc2,
										tab2.repair_seq repair_seq2,
										tab2.cur_cost cur_cost2,
										tab2.cur_TAT cur_TAT2,
										tab2.cur_price cur_price2,
										tab2.incremental_tat_ind incremental_tat_ind2,
										tab2.incremental_price_ind incremental_price_ind2
								FROM 
								( 
	                      	/*
	            	         	Getting the records from the history table which are modified
	                           last and are modified before 16Th Jan Of the current year.
	                        */
										SELECT 
					               		DISTINCT
												loc.location_desc location,
												comp.component_description comp_desc,
												repair.repair_description repair_desc,
												repair_ctlg.repair_seq_id repair_seq,
												((repair_cost.labor_hours * loc.location_labor_rate) + repair_cost.material_cost) cur_cost,
												repair_ctlg.repair_tat cur_TAT,
												repair_ctlg.repair_price cur_price,
												repair_ctlg.incremental_tat_ind incremental_tat_ind,
												repair_ctlg.incremental_price_ind incremental_price_ind
										FROM
												crd_crc_module modules,
												crd_e_component comp,
												crd_e_repair repair,
												crd_e_repair_catalog_hist repair_ctlg,
												crd_e_repair_cost_history repair_cost,
												crd_location loc,
												crd_e_catalog cec
										WHERE 
												modules.module_seq_id = comp.module_seq_id
												AND	repair.component_code = comp.component_code
												AND 	repair.module_seq_id = modules.module_seq_id
												AND 	repair.repair_seq_id = repair_ctlg.repair_seq_id
												AND 	repair_cost.module_seq_id =modules.module_seq_id
												AND 	repair_cost.component_code = comp.component_code
												AND 	repair_cost.repair_seq_id = repair.repair_seq_id
												AND 	loc.location_id = repair_cost.location_id
												AND 	modules.module_seq_id = p_in_module_seq_id 
												AND   cec.eng_mdl_number = modules.eng_mdl_number
												AND   cec.catalog_type = ecrd_utils_pkg.G_DEFAULT_CATALOG
                                    AND   cec.catalog_end_date >= TO_DATE(v_date_for_current_yr,'MM/DD/YYYY')
                                    AND   repair_ctlg.catalog_seq_id = cec.catalog_seq_id
												AND 	repair_ctlg.last_update_date = 
												( 
													SELECT 
															MAX(last_update_date) 
													FROM 
															crd_e_repair_catalog_hist inner_ctlg
													WHERE 
							                      inner_ctlg.STAGING_HISTORY_IND = ecrd_utils_pkg.G_HISTORY_RECORD
													AND inner_ctlg.last_update_date <= TO_DATE(v_date_for_current_yr,'MM/DD/YYYY')
													AND inner_ctlg.repair_seq_id = repair_ctlg.repair_seq_id
												)
												AND 	repair_cost.last_update_date = 
												(
													SELECT 
															MAX(last_update_date) 
													FROM 
															crd_e_repair_cost_history inner_cost
													WHERE
														 inner_cost.last_update_date <= TO_DATE(v_date_for_current_yr,'MM/DD/YYYY')
							                  AND inner_cost.STAGING_HISTORY_IND = ecrd_utils_pkg.G_HISTORY_RECORD
													AND inner_cost.repair_seq_id = repair_ctlg.repair_seq_id
												)
								) tab1,
								(
	                      	/*
	            	           	Getting the records from the main table which are 
	                           modified/created before 16Th Jan Of the current year.
	                        */
									SELECT 
											loc.location_desc location,
											comp.component_description comp_desc,
											repair.repair_description repair_desc,
											repair_ctlg.repair_seq_id repair_seq,
											((repair_cost.labour_hours * loc.location_labor_rate) + repair_cost.material_cost) cur_cost,
											repair_ctlg.repair_tat cur_TAT,
											repair_ctlg.repair_price cur_price,
											repair_ctlg.incremental_tat_ind incremental_tat_ind,
											repair_ctlg.incremental_price_ind incremental_price_ind
									FROM
											crd_crc_module modules,
											crd_e_component comp,
											crd_e_repair repair,
											crd_e_repair_catalog repair_ctlg,
											crd_e_repair_cost repair_cost,
											crd_location loc,
											crd_e_catalog cec
									WHERE 
											modules.module_seq_id = comp.module_seq_id
											AND	repair.component_code = comp.component_code
											AND 	repair.module_seq_id = modules.module_seq_id
											AND 	repair.repair_seq_id = repair_ctlg.repair_seq_id
											AND 	repair_cost.module_seq_id =modules.module_seq_id
											AND 	repair_cost.component_code = comp.component_code
											AND 	repair_cost.repair_seq_id = repair.repair_seq_id
											AND 	loc.location_id = repair_cost.location_id
											AND 	modules.module_seq_id = p_in_module_seq_id
											AND   cec.catalog_type = ecrd_utils_pkg.G_DEFAULT_CATALOG
											AND   cec.catalog_end_date >= TO_DATE(v_date_for_current_yr,'MM/DD/YYYY')
											AND   cec.eng_mdl_number = modules.eng_mdl_number  
											AND   repair_ctlg.last_update_date <= TO_DATE(v_date_for_current_yr,'MM/DD/YYYY')
											AND 	repair_cost.last_update_date <= TO_DATE(v_date_for_current_yr,'MM/DD/YYYY')
                                 AND   repair_ctlg.catalog_seq_id = cec.catalog_seq_id
								) tab2
                        /*
                        	For Left Outer Join
                        */
								WHERE 
                        		  tab1.location(+) = tab2.location 
								AND	  tab1.repair_seq(+) = tab2.repair_seq 
							)
							UNION
							(
		                	/*
		               		This query retrives the information of all the repairs together 
		                     without getting the records for the same repair seq id and location
		                     together in one row. 
		                	*/
		        
								SELECT 
										tab1.location location1 ,
										tab1.comp_desc comp_desc1,
										tab1.repair_desc repair_desc1,
										tab1.repair_seq repair_seq1,
										tab1.past_cost cur_cost1,
										tab1.past_TAT cur_TAT1,
										tab1.past_price cur_price1,
										tab1.incremental_tat_ind incremental_tat_ind1,
										tab1.incremental_price_ind incremental_price_ind1,
										tab2.location location2,
										tab2.comp_desc comp_desc2,
										tab2.repair_desc repair_desc2,
										tab2.repair_seq repair_seq2,
										tab2.past_cost past_cost2,
										tab2.past_TAT past_TAT2,
										tab2.past_price past_price2,
										tab2.incremental_tat_ind incremental_tat_ind2,
										tab2.incremental_price_ind incremental_price_ind2
								FROM
								( 
	                      	/*
	                        	Getting the records from the history table which are modified
	                           last and are modified before 16Th Jan Of the current year.
	                        */
								
									SELECT 
					            		DISTINCT
											loc.location_desc location,
											comp.component_description comp_desc,
											repair.repair_description repair_desc,
											repair_ctlg.repair_seq_id repair_seq,
											((repair_cost.labor_hours * loc.location_labor_rate) + repair_cost.material_cost) past_cost,
											repair_ctlg.repair_tat past_TAT,
											repair_ctlg.repair_price past_price,
											repair_ctlg.incremental_tat_ind incremental_tat_ind,
											repair_ctlg.incremental_price_ind incremental_price_ind
									FROM
											crd_crc_module modules,
											crd_e_component comp,
											crd_e_repair repair,
											crd_e_repair_catalog_hist repair_ctlg,
											crd_e_repair_cost_history repair_cost,
											crd_location loc,
											crd_e_catalog cec
									WHERE 
											modules.module_seq_id = comp.module_seq_id
											AND	repair.component_code = comp.component_code
											AND 	repair.module_seq_id = modules.module_seq_id
											AND 	repair.repair_seq_id = repair_ctlg.repair_seq_id
											AND 	repair_cost.module_seq_id =modules.module_seq_id
											AND 	repair_cost.component_code = comp.component_code
											AND 	repair_cost.repair_seq_id = repair.repair_seq_id
											AND 	loc.location_id = repair_cost.location_id
											AND 	modules.module_seq_id = p_in_module_seq_id
											AND	cec.catalog_type = ecrd_utils_pkg.G_DEFAULT_CATALOG
											AND   cec.catalog_end_date >= TO_DATE(v_date_for_current_yr,'MM/DD/YYYY')
											AND	cec.eng_mdl_number = modules.eng_mdl_number
                                 AND   repair_ctlg.catalog_seq_id = cec.catalog_seq_id
											AND 	repair_ctlg.last_update_date = 
											( 
												SELECT 
														MAX(last_update_date) 
												FROM 
														crd_e_repair_catalog_hist inner_ctlg
												WHERE 
					                  	 	 inner_ctlg.staging_history_ind = ecrd_utils_pkg.G_HISTORY_RECORD 
												AND inner_ctlg.last_update_date <= TO_DATE(v_date_for_current_yr,'MM/DD/YYYY')
												AND inner_ctlg.repair_seq_id = repair_ctlg.repair_seq_id
											)
											AND 	repair_cost.last_update_date = 
											(
												SELECT 
														MAX(last_update_date) 
												FROM 
														crd_e_repair_cost_history inner_cost
												WHERE
													 inner_cost.last_update_date <= TO_DATE(v_date_for_current_yr,'MM/DD/YYYY')
					               		AND inner_cost.staging_history_ind =  ecrd_utils_pkg.G_HISTORY_RECORD
												AND inner_cost.repair_seq_id = repair_ctlg.repair_seq_id
											)
								) tab1,
								(
	                      	/*
	            	           	Getting the records from the main table which are 
	                           modified/created before 16Th Jan Of the current year.
	                        */
									SELECT 
											loc.location_desc location,
											comp.component_description comp_desc,
											repair.repair_description repair_desc,
											repair_ctlg.repair_seq_id repair_seq,
											((repair_cost.labour_hours * loc.location_labor_rate) + repair_cost.material_cost) past_cost,
											repair_ctlg.repair_tat past_TAT,
											repair_ctlg.repair_price past_price,
											repair_ctlg.incremental_tat_ind incremental_tat_ind,
											repair_ctlg.incremental_price_ind incremental_price_ind
									FROM
											crd_crc_module modules,
											crd_e_component comp,
											crd_e_repair repair,
											crd_e_repair_catalog repair_ctlg,
											crd_e_repair_cost repair_cost,
											crd_location loc,
											crd_e_catalog cec
									WHERE 
											modules.module_seq_id = comp.module_seq_id
											AND	repair.component_code = comp.component_code
											AND 	repair.module_seq_id = modules.module_seq_id
											AND 	repair.repair_seq_id = repair_ctlg.repair_seq_id
											AND 	repair_cost.module_seq_id =modules.module_seq_id
											AND 	repair_cost.component_code = comp.component_code
											AND 	repair_cost.repair_seq_id = repair.repair_seq_id
											AND 	loc.location_id = repair_cost.location_id
											AND 	modules.module_seq_id = p_in_module_seq_id 
											AND   cec.catalog_type = ecrd_utils_pkg.G_DEFAULT_CATALOG
											AND	cec.eng_mdl_number = modules.eng_mdl_number
											AND   cec.catalog_end_date >= TO_DATE(v_date_for_current_yr,'MM/DD/YYYY')
											AND   repair_ctlg.last_update_date <= TO_DATE(v_date_for_current_yr,'MM/DD/YYYY')
											AND 	repair_cost.last_update_date <= TO_DATE(v_date_for_current_yr,'MM/DD/YYYY')
                                 AND   repair_ctlg.catalog_seq_id = cec.catalog_seq_id
								) tab2
                        /*
                        	For Right Outer Join
                        */
								WHERE 
                        		 tab1.location = tab2.location(+) 
								AND	 tab1.repair_seq = tab2.repair_seq(+) 
							) 
						)
						UNION
                  /*
                  		This is retrieving the past year cost information for all repairs
                        for the default catalog
                  */
					         SELECT 
										0 cur_cost,
										0 cur_TAT,
										0 cur_Price,
										((repair_cost.labor_hours * loc.location_labor_rate) + repair_cost.material_cost) past_cost, 
										repair_ctlg.repair_tat past_TAT,
										repair_ctlg.repair_price past_price,
										repair_ctlg.repair_seq_id repair_seq,
										loc.location_desc location_d,
										comp.component_description comp_desc,
										repair.repair_description repair_desc, 
										repair_ctlg.incremental_tat_ind incremental_tat_ind,
										repair_ctlg.incremental_price_ind incremental_price_ind
								FROM
										crd_crc_module modules,
										crd_e_component comp,
										crd_e_repair repair,
										crd_e_repair_catalog_hist repair_ctlg,
										crd_e_repair_cost_history repair_cost,
										crd_location loc,
				                  crd_e_catalog cec
								WHERE 
										modules.module_seq_id = comp.module_seq_id
								AND 	repair.component_code = comp.component_code
								AND 	repair.module_seq_id = modules.module_seq_id
								AND 	repair.repair_seq_id = repair_ctlg.repair_seq_id
								AND 	repair_cost.module_seq_id =modules.module_seq_id
								AND 	repair_cost.component_code = comp.component_code
								AND 	repair_cost.repair_seq_id = repair.repair_seq_id
								AND 	modules.module_seq_id =  p_in_module_seq_id
				           	AND   cec.eng_mdl_number = modules.eng_mdl_number
					         AND   cec.catalog_type = ecrd_utils_pkg.G_DEFAULT_CATALOG
					         AND   cec.catalog_end_date >= TO_DATE(v_date_for_past_yr,'MM/DD/YYYY') 
								AND 	loc.location_id = repair_cost.location_id
                        AND   repair_ctlg.catalog_seq_id = cec.catalog_seq_id
								AND 	repair_ctlg.last_update_date = 
								(
									SELECT 
					              	MAX(last_update_date) 
					              FROM 
					              	crd_e_repair_catalog_hist inner_ctlg
									WHERE 
										 inner_ctlg.staging_history_ind = ecrd_utils_pkg.G_HISTORY_RECORD
									AND inner_ctlg.last_update_date <= TO_DATE(v_date_for_past_yr,'MM/DD/YYYY')
									AND inner_ctlg.repair_seq_id = repair_ctlg.repair_seq_id
								)
								AND repair_cost.last_update_date =
				            (
					   	        	SELECT 
					              	MAX(last_update_date) 
					              FROM 
					              	crd_e_repair_cost_history inner_cost
									WHERE 
					              	 inner_cost.staging_history_ind =ecrd_utils_pkg.G_HISTORY_RECORD
									AND inner_cost.last_update_date <= TO_DATE(v_date_for_past_yr,'MM/DD/YYYY')
									AND inner_cost.repair_seq_id = repair_ctlg.repair_seq_id
								)
					)	
					GROUP BY 
					repair_seq,
					location, 
					comp_desc,
					repair_desc, 
					incremental_tat_ind,
					incremental_price_ind;
	ELSE
   	-- If Selected Catalog is the customer Catalog
         
		   OPEN p_out_repair_price_changes
		   FOR
	      /*
         	This query is used to combine the result for getting the cost information 
            of the repairs for the current year as well as past year together for the 
            custoner catalog selected.
         */
			SELECT
					comp_desc,
					repair_desc,
					location,
					SUM(past_cost),
					SUM(past_tat),
					SUM(past_price),
					SUM(cur_cost),
					SUM(cur_tat),
					SUM(cur_price),
					incremental_tat_ind,
					incremental_price_ind
			FROM 
			(
	         /*
	         	This query is used to retrieve the cost information of the repairs for
	            the current year for customer catalog
               
               Decode Condition Used : 
               
               This query is retrieving the records from main and history table both.
               So if main table information is not empty then get the information from
               main table otherwise get it from the history table.
	         */
				SELECT
						DECODE(cur_cost2,NULL,cur_cost1,cur_cost2) cur_cost,
						DECODE(cur_TAT2,NULL,cur_TAT1,cur_TAT2) cur_TAT,
						DECODE(cur_price2,NULL,cur_price1,cur_price2) cur_price,
						0 past_cost,
						0 past_TAT,
						0 past_price,
						DECODE(repair_seq1,NULL,repair_seq2,repair_seq1) repair_seq,
						DECODE(location1,NULL,location2,location1) location,
						DECODE(comp_desc1,NULL,comp_desc2,comp_desc1) comp_desc,
						DECODE(repair_desc1,NULL,repair_desc2,repair_desc1) repair_desc,
						DECODE(incremental_tat_ind2,NULL,incremental_tat_ind1,incremental_tat_ind2) incremental_tat_ind,
						DECODE(incremental_price_ind2,NULL,incremental_price_ind1,incremental_price_ind2) incremental_price_ind
				FROM
				(
              	/*
               	This query retrives the combined information of the main table as well as 
                  history table together in the same row - comparing repair seq id and
                  location. 
                */
	            SELECT
							location1 ,
							comp_desc1,
							repair_desc1,
							repair_seq1,
							cur_cost1,
							cur_TAT1,
							cur_price1,
							incremental_tat_ind1,
							incremental_price_ind1,
							location2,
							comp_desc2,
							repair_desc2,
							repair_seq2,
							cur_cost2,
							cur_TAT2,
							cur_price2,
							incremental_tat_ind2,
							incremental_price_ind2 
					FROM
					(
            		/*
               		This query retrives the information of all the repairs together 
                     without getting the records for the same repair seq id and location
                     together in one row. 
                	*/
                                
			      		SELECT 
									tab1.location location1 ,
									tab1.comp_desc comp_desc1,
									tab1.repair_desc repair_desc1,
									tab1.repair_seq repair_seq1,
									tab1.cur_cost cur_cost1,
									tab1.cur_TAT cur_TAT1,
									tab1.cur_price cur_price1,
									tab1.incremental_tat_ind incremental_tat_ind1,
									tab1.incremental_price_ind incremental_price_ind1,
									tab2.location location2,
									tab2.comp_desc comp_desc2,
									tab2.repair_desc repair_desc2,
									tab2.repair_seq repair_seq2,
									tab2.cur_cost cur_cost2,
									tab2.cur_TAT cur_TAT2,
									tab2.cur_price cur_price2,
									tab2.incremental_tat_ind incremental_tat_ind2,
									tab2.incremental_price_ind incremental_price_ind2
							FROM
                     (	 
                     	/*
                        	Getting the records from the history table which are modified
                           last and are modified before 16Th Jan Of the current year.
                        */
								SELECT 
			               		DISTINCT
										loc.location_desc location,
										comp.component_description comp_desc,
										repair.repair_description repair_desc,
										repair_ctlg.repair_seq_id repair_seq,
										((repair_cost.labor_hours * loc.location_labor_rate) + repair_cost.material_cost) cur_cost,
										repair_ctlg.repair_tat cur_TAT,
										repair_ctlg.repair_price cur_price,
										repair_ctlg.incremental_tat_ind incremental_tat_ind,
										repair_ctlg.incremental_price_ind incremental_price_ind
								FROM
										crd_crc_module modules,
										crd_e_component comp,
										crd_e_repair repair,
										crd_e_repair_catalog_hist repair_ctlg,
										crd_e_repair_cost_history repair_cost,
										crd_location loc
								WHERE 
										modules.module_seq_id = comp.module_seq_id
										AND	repair.component_code = comp.component_code
										AND 	repair.module_seq_id = modules.module_seq_id
										AND 	repair.repair_seq_id = repair_ctlg.repair_seq_id
										AND 	repair_cost.module_seq_id =modules.module_seq_id
										AND 	repair_cost.component_code = comp.component_code
										AND 	repair_cost.repair_seq_id = repair.repair_seq_id
										AND 	loc.location_id = repair_cost.location_id
										AND 	modules.module_seq_id = p_in_module_seq_id
										AND 	repair_ctlg.catalog_seq_id = p_in_catalog_seq_id
										AND 	repair_ctlg.last_update_date = 
										( 
											SELECT 
													MAX(last_update_date) 
											FROM 
													crd_e_repair_catalog_hist inner_ctlg
											WHERE 
												    inner_ctlg.catalog_seq_id = p_in_catalog_seq_id
						         	      AND inner_ctlg.STAGING_HISTORY_IND = ecrd_utils_pkg.G_HISTORY_RECORD
												AND inner_ctlg.last_update_date <= TO_DATE(v_date_for_current_yr,'MM/DD/YYYY')
												AND inner_ctlg.repair_seq_id = repair_ctlg.repair_seq_id
										)
										AND 	repair_cost.last_update_date = 
										(
											SELECT 
													MAX(last_update_date) 
											FROM 
													crd_e_repair_cost_history inner_cost
											WHERE
													 inner_cost.last_update_date <= TO_DATE(v_date_for_current_yr,'MM/DD/YYYY')
						                  AND inner_cost.STAGING_HISTORY_IND = ecrd_utils_pkg.G_HISTORY_RECORD
												AND inner_cost.repair_seq_id = repair_ctlg.repair_seq_id
										)
							)tab1,
							(
	                   	/*
            	           	Getting the records from the main table which are 
                           modified/created before 16Th Jan Of the current year.
                        */
								SELECT 
										loc.location_desc location,
										comp.component_description comp_desc,
										repair.repair_description repair_desc,
										repair_ctlg.repair_seq_id repair_seq,
										((repair_cost.labour_hours * loc.location_labor_rate) + repair_cost.material_cost) cur_cost,
										repair_ctlg.repair_tat cur_TAT,
										repair_ctlg.repair_price cur_price,
										repair_ctlg.incremental_tat_ind incremental_tat_ind,
										repair_ctlg.incremental_price_ind incremental_price_ind
								FROM
										crd_crc_module modules,
										crd_e_component comp,
										crd_e_repair repair,
										crd_e_repair_catalog repair_ctlg,
										crd_e_repair_cost repair_cost,
										crd_location loc
								WHERE 
										modules.module_seq_id = comp.module_seq_id
										AND	repair.component_code = comp.component_code
										AND 	repair.module_seq_id = modules.module_seq_id
										AND 	repair.repair_seq_id = repair_ctlg.repair_seq_id
										AND 	repair_cost.module_seq_id =modules.module_seq_id
										AND 	repair_cost.component_code = comp.component_code
										AND 	repair_cost.repair_seq_id = repair.repair_seq_id
										AND 	loc.location_id = repair_cost.location_id
										AND 	modules.module_seq_id = p_in_module_seq_id
										AND 	repair_ctlg.catalog_seq_id = p_in_catalog_seq_id
										AND   repair_ctlg.last_update_date <= TO_DATE(v_date_for_current_yr,'MM/DD/YYYY')
										AND 	repair_cost.last_update_date <= TO_DATE(v_date_for_current_yr,'MM/DD/YYYY')
							) tab2
                     /*
                     	For left Outer Join
                     */
							WHERE 
                     		tab1.location(+) = tab2.location 
							AND	tab1.repair_seq(+) = tab2.repair_seq 
					)
					UNION
					(
      	        	/*
               		This query retrives the information of all the repairs together 
                     without getting the records for the same repair seq id and location
                     together in one row. 
                	*/
               		SELECT 
									tab1.location location1 ,
									tab1.comp_desc comp_desc1,
									tab1.repair_desc repair_desc1,
									tab1.repair_seq repair_seq1,
									tab1.past_cost cur_cost1,
									tab1.past_TAT cur_TAT1,
									tab1.past_price cur_price1,
									tab1.incremental_tat_ind incremental_tat_ind1,
									tab1.incremental_price_ind incremental_price_ind1,
									tab2.location location2,
									tab2.comp_desc comp_desc2,
									tab2.repair_desc repair_desc2,
									tab2.repair_seq repair_seq2,
									tab2.past_cost past_cost2,
									tab2.past_TAT past_TAT2,
									tab2.past_price past_price2,
									tab2.incremental_tat_ind incremental_tat_ind2,
									tab2.incremental_price_ind incremental_price_ind2
							FROM
							( 
                      	/*
                        	Getting the records from the history table which are modified
                           last before 16Th Jan Of the current year.
                        */
									SELECT DISTINCT
											loc.location_desc location,
											comp.component_description comp_desc,
											repair.repair_description repair_desc,
											repair_ctlg.repair_seq_id repair_seq,
											((repair_cost.labor_hours * loc.location_labor_rate) + repair_cost.material_cost) past_cost,
											repair_ctlg.repair_tat past_TAT,
											repair_ctlg.repair_price past_price,
											repair_ctlg.incremental_tat_ind incremental_tat_ind,
											repair_ctlg.incremental_price_ind incremental_price_ind
									FROM
											crd_crc_module modules,
											crd_e_component comp,
											crd_e_repair repair,
											crd_e_repair_catalog_hist repair_ctlg,
											crd_e_repair_cost_history repair_cost,
											crd_location loc
									WHERE 
											modules.module_seq_id = comp.module_seq_id
											AND	repair.component_code = comp.component_code
											AND 	repair.module_seq_id = modules.module_seq_id
											AND 	repair.repair_seq_id = repair_ctlg.repair_seq_id
											AND 	repair_cost.module_seq_id =modules.module_seq_id
											AND 	repair_cost.component_code = comp.component_code
											AND 	repair_cost.repair_seq_id = repair.repair_seq_id
											AND 	loc.location_id = repair_cost.location_id
											AND 	modules.module_seq_id = p_in_module_seq_id
											AND 	repair_ctlg.catalog_seq_id = p_in_catalog_seq_id
											AND 	repair_ctlg.last_update_date = 
											( 
												SELECT 
														MAX(last_update_date) 
												FROM 
														crd_e_repair_catalog_hist inner_ctlg
												WHERE 
														 inner_ctlg.catalog_seq_id = p_in_catalog_seq_id
			               				   AND inner_ctlg.STAGING_HISTORY_IND =ecrd_utils_pkg.G_HISTORY_RECORD
 													AND inner_ctlg.last_update_date <= TO_DATE(v_date_for_current_yr,'MM/DD/YYYY')
													AND inner_ctlg.repair_seq_id = repair_ctlg.repair_seq_id
											)
											AND 	repair_cost.last_update_date = 
											(
												SELECT 
														MAX(last_update_date) 
												FROM 
														crd_e_repair_cost_history inner_cost
												WHERE
												 inner_cost.last_update_date <= TO_DATE(v_date_for_current_yr,'MM/DD/YYYY')
					                  AND inner_cost.STAGING_HISTORY_IND = ecrd_utils_pkg.G_HISTORY_RECORD
											AND inner_cost.repair_seq_id = repair_ctlg.repair_seq_id
											)
							) tab1,
							(
         	           	/*
            	           	Getting the records from the main table which are 
                           modified/created before 16Th Jan Of the current year.
                        */
			
									SELECT 
											loc.location_desc location,
											comp.component_description comp_desc,
											repair.repair_description repair_desc,
											repair_ctlg.repair_seq_id repair_seq,
											((repair_cost.labour_hours * loc.location_labor_rate) + repair_cost.material_cost) past_cost,
											repair_ctlg.repair_tat past_TAT,
											repair_ctlg.repair_price past_price,
											repair_ctlg.incremental_tat_ind incremental_tat_ind,
											repair_ctlg.incremental_price_ind incremental_price_ind
									FROM
											crd_crc_module modules,
											crd_e_component comp,
											crd_e_repair repair,
											crd_e_repair_catalog repair_ctlg,
											crd_e_repair_cost repair_cost,
											crd_location loc
									WHERE 
											modules.module_seq_id = comp.module_seq_id
											AND	repair.component_code = comp.component_code
											AND 	repair.module_seq_id = modules.module_seq_id
											AND 	repair.repair_seq_id = repair_ctlg.repair_seq_id
											AND 	repair_cost.module_seq_id =modules.module_seq_id
											AND 	repair_cost.component_code = comp.component_code
											AND 	repair_cost.repair_seq_id = repair.repair_seq_id
											AND 	loc.location_id = repair_cost.location_id
											AND 	modules.module_seq_id = p_in_module_seq_id
											AND 	repair_ctlg.catalog_seq_id = p_in_catalog_seq_id
											AND   repair_ctlg.last_update_date <= TO_DATE(v_date_for_current_yr,'MM/DD/YYYY')
											AND 	repair_cost.last_update_date <= TO_DATE(v_date_for_current_yr,'MM/DD/YYYY')
							) tab2
							WHERE 
                     /*
                     	For Right Outer Join
                     */
                      		tab1.location = tab2.location(+) 
							AND	tab1.repair_seq = tab2.repair_seq(+) 
					) 
				)
				UNION
            /*
            	This query is used to retrieve the record information for the past year
               for the customer catalog 
	          */
            	SELECT
			           	 	0 cur_cost,
								0 cur_TAT,
								0 cur_price,
								((repair_cost.labor_hours * loc.location_labor_rate) + repair_cost.material_cost) past_cost,
								repair_ctlg.repair_tat past_TAT,
								repair_ctlg.repair_price past_price,
								repair_ctlg.repair_seq_id repair_seq,
								loc.location_desc location,
								comp.component_description comp_desc,
								repair.repair_description repair_desc,
								repair_ctlg.incremental_tat_ind incremental_tat_ind,
								repair_ctlg.incremental_price_ind incremental_price_ind
						FROM
								crd_crc_module modules,
								crd_e_component comp,
								crd_e_repair repair,
								crd_e_repair_catalog_hist repair_ctlg,
								crd_e_repair_cost_history repair_cost,
								crd_location loc
						WHERE 
								modules.module_seq_id = comp.module_seq_id
						AND	repair.component_code = comp.component_code
						AND 	repair.module_seq_id = modules.module_seq_id
						AND 	repair.repair_seq_id = repair_ctlg.repair_seq_id
						AND 	repair_cost.module_seq_id =modules.module_seq_id
						AND 	repair_cost.component_code = comp.component_code
						AND 	repair_cost.repair_seq_id = repair.repair_seq_id
						AND 	modules.module_seq_id = p_in_module_seq_id
       				AND 	loc.location_id = repair_cost.location_id
        				AND 	loc.location_id = repair_cost.location_id
						AND 	repair_ctlg.last_update_date = 
						( 
							SELECT 
			              	MAX(last_update_date) 
			              FROM 
			              	crd_e_repair_catalog_hist inner_ctlg
							WHERE 
			              	 inner_ctlg.catalog_seq_id = repair_ctlg.catalog_seq_id
							AND inner_ctlg.staging_history_ind =ecrd_utils_pkg.G_HISTORY_RECORD
                     AND inner_ctlg.repair_seq_id = repair_ctlg.repair_seq_id
							AND inner_ctlg.last_update_date <= TO_DATE(v_date_for_past_yr,'MM/DD/YYYY')
						)
						AND 	repair_cost.last_update_date = 
						(
								SELECT 
			              	MAX(last_update_date) 
			              FROM 
			              	crd_e_repair_cost_history inner_cost
							WHERE
								 inner_cost.staging_history_ind = ecrd_utils_pkg.G_HISTORY_RECORD
                     AND inner_cost.repair_seq_id = repair_ctlg.repair_seq_id
							AND inner_cost.last_update_date <= TO_DATE(v_date_for_past_yr,'MM/DD/YYYY')
						)	
			)	
			GROUP BY 
			repair_seq,
			location, 
			comp_desc,
			repair_desc, 
			incremental_tat_ind,
			incremental_price_ind;
	END IF;                       
EXCEPTION
	WHEN OTHERS THEN
		RAISE_APPLICATION_ERROR(-20001,'ERROR IN ecrd_reports_pkg.ecrd_get_price_changes_yrl_prc' ||SQLCODE ||  ' - ' || SQLERRM(250));
END ecrd_get_price_changes_yrl_prc;
---------------------------------------------------------------

FUNCTION ecrd_get_catalog_number(
			 p_catalog_number IN VARCHAR2
		  	)
RETURN VARCHAR2
IS
	v_catalog_number VARCHAR2(100);
   v_file_name_char VARCHAR2(100);
   tab_broken_cols  ecrd_utils_pkg.gtyp_buf_arr;
   v_col_count NUMBER := 0;
   v_index NUMBER :=0;
BEGIN

	SELECT
   	PARAMETER_VALUE
   INTO
   	v_file_name_char
   FROM
   	CRD_CRC_E_PARAMETERS
   WHERE
   	PARAMETER_CODE = 'FILE_NAME';

   v_catalog_number:= p_catalog_number;
      
   ecrd_utils_pkg.break_into_cols_s_prc(
		      v_file_name_char,
		      ecrd_utils_pkg.G_ROW_DELIM,
		      tab_broken_cols
	);
   v_col_count := tab_broken_cols.COUNT;
   
   FOR v_index IN 1..v_col_count
   LOOP
   	SELECT
      	REPLACE(v_catalog_number,tab_broken_cols(v_index),ecrd_utils_pkg.G_DUMMY_SEPERATOR)
      INTO
      	v_catalog_number
      FROM
      	DUAL;
   END LOOP;
      	
   SELECT
   	REPLACE(v_catalog_number,' ',ecrd_utils_pkg.G_DUMMY_SEPERATOR)
   INTO
   	v_catalog_number
   FROM
   	DUAL;      
      
   RETURN v_catalog_number;
   
EXCEPTION
WHEN OTHERS THEN
	RAISE_APPLICATION_ERROR(-20020,'ecrd_reports_pkg.ecrd_get_catalog_number---'||SQLCODE||SQLERRM);      
END ecrd_get_catalog_number;

FUNCTION ecrd_rep_lvl_rule_exists_prc
(
	p_in_catalog_seq_id crd_e_catalog.catalog_seq_id%TYPE,
   p_in_repair_seq_id crd_e_repair.repair_seq_id%TYPE
)
RETURN VARCHAR2
IS
   v_tat VARCHAR2(100) := '';
   v_year crd_e_ctlg_contracted.year%TYPE;
   v_count NUMBER := 0;
BEGIN
   SELECT
      TO_CHAR(SYSDATE,'YYYY')
   INTO
      v_year
   FROM
      dual;
   
   SELECT
   	count(1)
   INTO
   	v_count
   FROM
   	crd_e_catalog
   WHERE
   	catalog_seq_id = p_in_catalog_seq_id AND
      catalog_type = ecrd_utils_pkg.G_DEFAULT_CATALOG AND
      catalog_end_date > SYSDATE;
      
   /*IF(v_count = 1)
   THEN
   	SELECT
      	DECODE(incremental_tat_ind,'Y','+')||DECODE(repair_tat,0,'',repair_tat)
      INTO
      	v_tat
      FROM
      	crd_e_repair_catalog
      WHERE
      	catalog_seq_id = p_in_catalog_seq_id AND
         repair_seq_id = p_in_repair_seq_id;
   ELSE */     
	   BEGIN   
		   SELECT 
		      TAT
		   INTO
		      v_tat
		   FROM
		      CRD_E_CONTRACTED_REPAIR
		   WHERE
		      catalog_seq_id = p_in_catalog_seq_id  AND
		      repair_seq_id = p_in_repair_seq_id AND
		      year = v_year;
		   EXCEPTION
		   WHEN NO_DATA_FOUND
		   THEN
		   	v_tat := NULL;
	   END;
	--END IF;
   RETURN v_tat;
   
EXCEPTION
WHEN OTHERS
THEN
   RAISE_APPLICATION_ERROR(-20020,'Error in ecrd_reports_pkg.ecrd_rep_lvl_rule_exists_prc **'||SQLCODE||SQLERRM);
END ecrd_rep_lvl_rule_exists_prc;

FUNCTION ecrd_get_tat_comp_or_rule_prc
(
	p_in_catalog_seq_id crd_e_catalog.catalog_seq_id%TYPE,
   p_in_component_code crd_e_component.component_code%TYPE,
   p_in_module_seq_id crd_crc_module.module_seq_id%TYPE
)
RETURN VARCHAR2
IS
   v_tat crd_e_ctlg_contracted.TAT%TYPE;
   v_year crd_e_ctlg_contracted.year%TYPE;
   v_count NUMBER :=0;
BEGIN
   SELECT
      TO_CHAR(SYSDATE,'YYYY')
   INTO
      v_year
   FROM
      dual;
      
   BEGIN
      SELECT 
         tat
      INTO
         v_tat
      FROM
         CRD_E_CONTRACTED_COMP
      WHERE
         catalog_seq_id = p_in_catalog_seq_id  AND
         component_code = p_in_component_code AND
         module_seq_id = p_in_module_seq_id AND
         year = v_year;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         BEGIN
            SELECT   
               tat
            INTO
               v_tat
            FROM
               crd_e_contracted_module
            WHERE
               catalog_seq_id = p_in_catalog_seq_id  AND
               module_seq_id = p_in_module_seq_id AND
               year = v_year;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               BEGIN
                  SELECT
                     tat
                  INTO
                     v_tat
                  FROM
                     crd_e_ctlg_contracted
                  WHERE
                     catalog_seq_id = p_in_catalog_seq_id  AND
                     year = v_year;
               EXCEPTION
                  WHEN NO_DATA_FOUND
                  THEN
                  	v_tat := '';
                     /*SELECT
                        baseline_tat
                     INTO
                        v_tat
                     FROM
                        crd_e_component
                     WHERE 
                        component_code = p_in_component_code AND
                        module_seq_id = p_in_module_seq_id AND
                        (component_end_date IS NULL OR component_end_date > SYSDATE);*/
               END;
         END;
   END;
   
   --dbms_output.put_line('Tat that will be displayed :  :  : '||v_tat);
   RETURN v_tat;
EXCEPTION
WHEN OTHERS
THEN
   RAISE_APPLICATION_ERROR(-20020,'Error in ecrd_managecomponent_pkg.ecrd_get_tat_comp_or_rule_prc **'||SQLCODE||SQLERRM);
END ecrd_get_tat_comp_or_rule_prc;

FUNCTION ecrd_rule_exists_fnc
(
	p_in_catalog_seq_id crd_e_catalog.catalog_seq_id%TYPE,
   p_in_component_code crd_e_component.component_code%TYPE,
   p_in_module_seq_id crd_crc_module.module_seq_id%TYPE,
   p_in_repair_seq_id crd_e_repair.repair_seq_id%TYPE
)
RETURN VARCHAR2
IS
   v_repair_count NUMBER := 0;
   v_module_count NUMBER := 0;
   v_component_count NUMBER := 0;
   v_catalog_count NUMBER := 0;
   v_status VARCHAR2(1) := 'N';
   v_year crd_e_ctlg_contracted.year%TYPE;
BEGIN
   SELECT
      TO_CHAR(SYSDATE,'YYYY')
   INTO
      v_year
   FROM
      dual;
      
  	SELECT
     	count(1)
     INTO
     	v_repair_count
     FROM
     	crd_e_contracted_repair
     WHERE
     	repair_seq_id = p_in_repair_seq_id AND
      year = v_year AND
      tat IS NOT NULL;
   
   IF(v_repair_count = 0)
   THEN
      SELECT 
         count(1)
      INTO
         v_component_count
      FROM
         CRD_E_CONTRACTED_COMP
      WHERE
         catalog_seq_id = p_in_catalog_seq_id  AND
         component_code = p_in_component_code AND
         module_seq_id = p_in_module_seq_id AND
         year = v_year AND
	      tat IS NOT NULL;
      
      IF(v_component_count = 0)
      THEN
         SELECT   
            count(1)
         INTO
            v_module_count
         FROM
            crd_e_contracted_module
         WHERE
            catalog_seq_id = p_in_catalog_seq_id  AND
            module_seq_id = p_in_module_seq_id AND
            year = v_year AND
		      tat IS NOT NULL;
            
	      IF(v_module_count = 0)
	      THEN
	         SELECT
	            count(1)
	         INTO
	            v_catalog_count
	         FROM
	            crd_e_ctlg_contracted
	         WHERE
	            catalog_seq_id = p_in_catalog_seq_id  AND
	            year = v_year AND
			      tat IS NOT NULL;
            
            IF(v_catalog_count = 0)
            THEN
            	v_status := 'N';
            ELSE
            	v_status := 'Y';
            END IF;
         ELSE
            v_status := 'Y';
		   END IF;
      ELSE
         v_status := 'Y';
		END IF;
   ELSE
      v_status := 'Y';
   END IF;
   
--   dbms_output.put_line('count(1) that will be displayed :  :  : '||v_count);
   RETURN v_status;
EXCEPTION
WHEN OTHERS
THEN
   RAISE_APPLICATION_ERROR(-20020,'Error in ecrd_reports_pkg.ecrd_rule_exists_fnc **'||SQLCODE||SQLERRM);
END ecrd_rule_exists_fnc;
END ecrd_reports_pkg;
/

