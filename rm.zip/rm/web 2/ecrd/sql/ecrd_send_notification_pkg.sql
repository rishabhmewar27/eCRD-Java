CREATE OR REPLACE PACKAGE ecrd_send_notification_pkg
AS 
/***********************************************************************/
--
-- Copyright Message 	   : Copyright(c) 2004 GE Aircraft Engines
-- Title                   : ecrd_send_notification_pkg
-- Author                  : Patni Offshore
-- Company           	   : GE Aircraft Engines
-- Date                    : October 2004
-- Purpose             	   : File contains Package Spec and body for Procs
--                           for Sending Notification Mails
--
-- Modifications      	   :
-- Date                   	Description
-- [DD-MMM-YYYY]          	A brief description of change should go here like
--                        	who had made change, why change was implemented
--                        	and where change is made.
--
-- 12-oct-2004         	      New Code First Version	
--
/***********************************************************************/

  TYPE ecrd_email_rec   IS RECORD
  (
      email  VARCHAR2(50) 
  );
  
  TYPE ecrd_location   IS RECORD
  (
      location_id crd_e_component_location.location_id%TYPE 
  );
  
  TYPE ecrd_cycle_class IS RECORD
  (
      cycle_class crd_e_cycle_counting_type.cycle_count_class%TYPE,
      notification_period crd_e_cycle_counting_type.notification_period_in_days%TYPE  
  );
  
  TYPE ecrd_tc_names_email IS RECORD
  (
   	  userid crd_crc_user.userid%TYPE,
		  email_address crd_crc_user.email_address%TYPE
  );
  
  TYPE ecrd_comp_list IS RECORD
  (
   	  comp_code crd_e_component.component_code%TYPE,
        comp_desc crd_e_component.component_description%TYPE,
		  module_seq_id crd_crc_module.module_seq_id%TYPE,
		  module_name crd_crc_module.module_name%TYPE
  );

  new_line VARCHAR2(2):= CHR(13) || CHR(10);
  FIELD_DELIMITER       CONSTANT VARCHAR2(2):= '^^'; --Field Seperator String.  

  TYPE result_cursor    IS REF CURSOR;
  TYPE email_buf_arr IS TABLE OF LONG INDEX BY BINARY_INTEGER;
  TYPE rec_holder IS TABLE OF VARCHAR2(10000)INDEX BY BINARY_INTEGER;
  TYPE ecrd_email_table IS TABLE OF ecrd_email_rec INDEX BY BINARY_INTEGER;
  TYPE ecrd_location_table IS TABLE OF ecrd_location INDEX BY BINARY_INTEGER;
  TYPE ecrd_comp_list_table IS TABLE OF ecrd_comp_list INDEX BY BINARY_INTEGER;
  TYPE ecrd_cycle_class_table IS TABLE OF ecrd_cycle_class INDEX BY BINARY_INTEGER;
  TYPE ecrd_tc_names_email_table IS TABLE OF ecrd_tc_names_email INDEX BY BINARY_INTEGER;

/***********************************************************************/
-- Procedure Name                : ecrd_get_comp_list_prc
-- Purpose                       : This procedure is used to get list of components  
--											  for the selected Class for which repairs have not been 
--											  modified for the notification period
-- Input Parameters              : p_in_location_id crd_e_component_location.location_id%TYPE
-- Input Parameters              : p_in_cycle_class crd_e_component.cycle_count_class%TYPE
-- Input Parameters              : p_in_cycle_period crd_e_cycle_counting_type.notification_period_in_days%TYPE
-- Output Parameters             : p_out_comp_list result_cursor
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/


PROCEDURE ecrd_get_comp_list_prc
(
	  p_in_location_id  IN crd_e_component_location.location_id%TYPE,
	  p_in_cycle_class  IN crd_e_component.cycle_count_class%TYPE,
	  p_in_cycle_period IN crd_e_cycle_counting_type.notification_period_in_days%TYPE,
     p_out_comp_list   OUT result_cursor
);

/***********************************************************************/
-- Procedure Name                : ecrd_send_mail_prc
-- Purpose                       : This procedure is used send mail  
-- Input Parameters              : p_in_sender_email VARCHAR2 
-- Input Parameters              : p_in_recipient_email LONG
-- Input Parameters              : p_in_cc Long
-- Input Parameters              : p_in_subject VARCHAR2,
-- Input Parameters              : p_in_message Long
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_send_mail_prc
(
   p_in_sender_email     IN VARCHAR2,
   p_in_recipient_email  IN LONG, -- emails seperated by ","",
   p_in_cc               IN LONG,
   p_in_subject          IN VARCHAR2,
   p_in_message          IN LONG
);


/***********************************************************************/
-- Procedure Name                : ecrd_split_email_prc
-- Purpose                       : This procedure is used split email addesses   
-- Input Parameters              : p_name_str      VARCHAR2,
-- Input Parameters    				: p_row_delimiter VARCHAR2,
-- Input Parameters    				: p_field_delimiter VARCHAR2,
-- Input/Output Parameters   		: p_table ecrd_email_table 
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_split_email_prc	
(
   p_name_str        IN VARCHAR2,
   p_row_delimiter   IN VARCHAR2,
   p_field_delimiter IN VARCHAR2,
   p_table           IN OUT ecrd_email_table
);

/***********************************************************************/
-- Procedure Name                : ecrd_delimiter_prc
-- Purpose                       :    
-- Input Parameters              : p_name_str      VARCHAR2,
-- Input Parameters    				: p_row_delimiter VARCHAR2,
-- Input Parameters    				: p_field_delimiter VARCHAR2,
-- Input/Output Parameters   		: p_table ecrd_email_table 
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_delimiter_prc
(
   p_name_str        IN VARCHAR2,
   p_row_delimit     IN VARCHAR2,
   p_field_delimit   IN VARCHAR2,
   p_rec_holder      OUT rec_holder
);

/***********************************************************************/
-- Procedure Name                : ecrd_get_list_of_tc_prc
-- Purpose                       : This procedure is used to get the list of TC 
--											  for selected site
-- Input Parameters              : p_in_location_id crd_crc_user.location_id%TYPE
--	Output Parameters   				: p_out_tc_list result_cursor
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_get_list_of_tc_prc
(
     p_in_location_id   IN  crd_crc_user.location_id%TYPE,
     p_out_tc_list      OUT result_cursor
);

/***********************************************************************/
-- Procedure Name                : ecrd_get_location_id_prc
-- Purpose                       : This procedure is used to get list of sites for 
--											  selected module seq id and component
-- Input Parameters              : p_in_module_seq_id crd_e_component_location.module_seq_id%TYPE
-- Input Parameters              : p_in_component_code crd_e_component_location.component_code%TYPE
--	Output Parameters   				: p_out_location_id_list result_cursor
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_get_location_id_prc
(
     p_in_module_seq_id  IN  crd_e_component_location.module_seq_id%TYPE,
     p_in_component_code IN  crd_e_component_location.component_code%TYPE,
	  p_out_location_id_list   OUT result_cursor
);

/***********************************************************************/
-- Procedure Name                : ecrd_get_all_sites_prc
-- Purpose                       : This procedure is used to get list of sites 
--	Output Parameters   				: p_out_site_list result_cursor
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_get_all_sites_prc
(
     p_out_site_list   OUT result_cursor
);

/***********************************************************************/
-- Procedure Name                : ecrd_get_all_cycle_class_prc
-- Purpose                       : This procedure is used to get list of classes 
--	Output Parameters   				: p_out_cycle_class_list
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_get_all_cycle_class_prc
(
     p_out_cycle_class_list   OUT result_cursor
);

/***********************************************************************/
-- Procedure Name                : ecrd_notification_mails_prc
-- Purpose                       : This procedure is send notification mails 
--	Output Parameters   				: p_out_msg LONG
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_notification_mails_prc
(
     p_out_msg	OUT LONG
);

/***********************************************************************/
-- Procedure Name                : ecrd_get_engine_model_prc
-- Purpose                       : This procedure is used to get engine model name
-- Input Parameters  				: p_in_module_seq_id crd_crc_module.module_seq_id%TYPE,
--	Output Parameters   				: p_out_model_name crd_crc_eng_mdl_display.eng_mdl_desc%TYPE
-- Called Procedures/Functions   : None
-- Calling Procedures/ Functions : None
/***********************************************************************/

PROCEDURE ecrd_get_engine_model_prc
(
     p_in_module_seq_id IN crd_crc_module.module_seq_id%TYPE,
     p_out_model_name OUT  crd_crc_eng_mdl_display.eng_mdl_desc%TYPE
);
-------------------------------------------------------------------------------------------
END ecrd_send_notification_pkg;
-------------------------------------------------------------------
/

CREATE OR REPLACE PACKAGE BODY ecrd_send_notification_pkg AS

-------------------------------------------------------------------------------------------

PROCEDURE ecrd_get_comp_list_prc
(
	  p_in_location_id  IN crd_e_component_location.location_id%TYPE,
     p_in_cycle_class  IN crd_e_component.cycle_count_class%TYPE,
	  p_in_cycle_period IN crd_e_cycle_counting_type.notification_period_in_days%TYPE,
     p_out_comp_list   OUT result_cursor
)
AS
BEGIN
	OPEN  p_out_comp_list
	FOR	
			SELECT 
   		DISTINCT  cec.component_code,
   					 cec.component_description,
                   ccm.module_seq_id AS MODULEID,
                   ccm.module_name
	  		FROM
	  					crd_e_component cec, 
		            crd_e_component_location cecl, 
		            crd_e_repair_cost cer,
	   		      crd_crc_module ccm
			WHERE
	        	cec.component_code = cecl.component_code
	  			AND cec.module_seq_id = cecl.module_seq_id
	  			AND cec.component_code = cer.component_code
	  			AND cec.module_seq_id = cer.module_seq_id
	         AND ccm.module_seq_id = cer.module_seq_id
				AND (cec.component_end_date IS NULL OR
				TO_DATE(cec.component_end_date,'DD/MM/YYYY') >
				TO_DATE(SYSDATE,'DD/MM/YYYY'))
			   AND TO_DATE(cer.last_update_date,'DD/MM/YYYY') NOT BETWEEN
				TO_DATE(SYSDATE- p_in_cycle_period,'DD/MM/YYYY') AND TO_DATE(SYSDATE,'DD/MM/YYYY')
	         AND cec.cycle_count_class = p_in_cycle_class 
				AND cecl.active_ind = ecrd_utils_pkg.G_YES
	  			AND cecl.location_id = p_in_location_id
			 	ORDER BY MODULEID;
EXCEPTION 
WHEN OTHERS THEN
	 RAISE_APPLICATION_ERROR(-20020,'Error in ecrd_send_notification_pkg.ecrd_get_comp_list_prc**'||SQLCODE||SQLERRM);
END ecrd_get_comp_list_prc;

-------------------------------------------------------------------------------------------

PROCEDURE ecrd_send_mail_prc
(
   p_in_sender_email     IN VARCHAR2,
   p_in_recipient_email  IN LONG, -- emails seperated by ","",
   p_in_cc               IN LONG,
   p_in_subject          IN VARCHAR2,
   p_in_message          IN LONG
)
IS
   v_email_server 	  VARCHAR2(30);
   v_port_number       NUMBER;
   conn       	        UTL_SMTP.CONNECTION;
   v_message           LONG;
   v_to_table   	     ecrd_email_table;
   v_cc_table   	     ecrd_email_table;
   v_mail_flag         VARCHAR2(1) DEFAULT ecrd_utils_pkg.G_NO;
   v_recipient_email   VARCHAR2(4000);
BEGIN
-- Select Server Ip address from crd_crc_e_parameters Table
  BEGIN
  	    SELECT 
       		parameter_value
		 INTO
            v_email_server
       FROM 
       		crd_crc_e_parameters 
       WHERE 
       		parameter_code = 'EMAIL_SERVER';
  EXCEPTION
   	   WHEN NO_DATA_FOUND THEN
	   RAISE_APPLICATION_ERROR(-20020, 'ERROR - EMAIL SERVER NOT SPECIFIED IN crd_crc_e_parameters_TABLE'||'ecrd_send_notification_pkg.ecrd_send_mail_prc');
  END;
   
-- Select Port Number from crd_crc_e_parameters Table
  BEGIN
  	    SELECT 
       		parameter_value
		 INTO
             v_port_number
       FROM 
       		crd_crc_e_parameters 
       WHERE 
       		parameter_code = 'PORT_NUMBER';

  EXCEPTION
   	   WHEN NO_DATA_FOUND THEN
	   RAISE_APPLICATION_ERROR(-20020, 'ERROR - PORT NUMBER NOT SPECIFIED IN crd_crc_e_parameters_TABLE'||'ecrd_send_notification_pkg.ecrd_send_mail_prc');
  END;
--  conn:= UTL_SMTP.open_connection( '129.202.40.118', v_port_number );
 
  conn:= utl_smtp.open_connection( v_email_server, v_port_number );
  utl_smtp.helo( conn, v_email_server );
  utl_smtp.mail( conn, p_in_sender_email);

  v_recipient_email := p_in_recipient_email||p_in_cc ;
    
  IF (v_recipient_email IS NOT NULL) THEN
    
	 ecrd_split_email_prc(v_recipient_email,ecrd_utils_pkg.G_EMAIL_SEPARATOR,FIELD_DELIMITER, v_to_table);
  
	 FOR i in 1..v_to_table.COUNT
	 LOOP
	   utl_smtp.rcpt(conn, v_to_table(i).email);
	 END LOOP;
  	 v_mail_flag := ecrd_utils_pkg.G_YES;
  END IF;

  IF (TRIM(p_in_cc) IS NOT NULL OR TRIM(p_in_cc) <> '') THEN
  	 ecrd_split_email_prc(p_in_cc,ecrd_utils_pkg.G_EMAIL_SEPARATOR,FIELD_DELIMITER, v_cc_table);
	 FOR i in 1..v_cc_table.COUNT
  	 LOOP
   	 	 utl_smtp.rcpt(conn, v_cc_table(i).email);
	 END LOOP;

  	 v_mail_flag := ecrd_utils_pkg.G_YES;
  END IF;
 
  IF (v_mail_flag = ecrd_utils_pkg.G_YES) THEN

  v_message := 'Date: '||TO_CHAR( SYSDATE, 'dd Mon yy hh24:mi:ss' )|| new_line ||
               'From:'|| p_in_sender_email || new_line ||
               'To: '|| p_in_recipient_email || new_line ||
               'Cc: '|| p_in_cc || new_line ||
               'Subject:' || p_in_subject || new_line ||
                p_in_message;

  utl_smtp.data( conn, v_message );
  END IF;
  utl_smtp.quit( conn );
EXCEPTION
  WHEN OTHERS THEN
  utl_smtp.quit(conn);
  NULL;
  	   RAISE_APPLICATION_ERROR(-20020, 'ERROR in ecrd_send_mail_prc.' || SQLCODE ||  ' - ' || SQLERRM);
END ecrd_send_mail_prc;
-----------------------------------------

PROCEDURE ecrd_split_email_prc
(
   p_name_str        IN VARCHAR2,
   p_row_delimiter   IN VARCHAR2,
   p_field_delimiter IN VARCHAR2,
   p_table           IN OUT ecrd_email_table
)
IS
--
  OPTION_RECORD_LENGTH    CONSTANT    NUMBER := 1;
  v_rec_holder    		  rec_holder;
  ln_ptr       			  NUMBER := 0;
  ln_end       			  NUMBER := 0;
  ln_row       			  NUMBER := 0;
--
BEGIN
--
    IF (p_name_str = '' OR p_name_str = p_row_delimiter) THEN
         GOTO endpoint;
    END IF;
	 -- splitting the passed string to acquire a long train of values.
	
    ecrd_delimiter_prc(p_name_str, ',' , p_field_delimiter, v_rec_holder);
	
    ln_end := (v_rec_holder.COUNT - OPTION_RECORD_LENGTH) + 1;
    ln_ptr := 1;
    ln_row := 1;

    -- arrange and populate the respective tables from the train.

    LOOP
    EXIT WHEN ln_ptr > ln_end;

       p_table(ln_row).email  := v_rec_holder(ln_ptr);
       ln_ptr := ln_ptr + OPTION_RECORD_LENGTH;
       ln_row := ln_row + 1;

    END LOOP;
--
<<endpoint>>
NULL;

EXCEPTION
WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20020, 'ERROR in ecrd_split_email_prc.' || SQLCODE ||  ' - ' || SQLERRM);
END ecrd_split_email_prc;

-------------------------------------
PROCEDURE ecrd_delimiter_prc
(
   p_name_str        IN VARCHAR2,
   p_row_delimit     IN VARCHAR2,
   p_field_delimit   IN VARCHAR2,
   p_rec_holder      OUT rec_holder
)
IS
	 v_rec_pos1                NUMBER;
	 v_rec_pos2                NUMBER;
	 v_rec_delimiter_length    NUMBER;
	 v_field_pos1              NUMBER;
	 v_field_pos2              NUMBER;
	 v_field_delimiter_length  NUMBER;
	 loop_counter              NUMBER;
	 num_cols                  NUMBER;
	 table_counter             NUMBER;
	 col_count                 NUMBER;
	 rec_length                NUMBER;
	 v_record                  VARCHAR2(1000);
	 v_field                   VARCHAR2(1000);
BEGIN
  v_rec_pos1    :=0;
  v_rec_pos2     :=0;
  v_field_pos1  :=0;
  v_field_pos2  :=0;
  loop_counter  :=0;
  table_counter    :=0;

-- outer loop separates out the rows and the inner loop separates out the columns

 LOOP --record loop
   v_rec_pos2   := instr(p_name_str,p_row_delimit,v_rec_pos1+1,1) ;
   v_record     := substr(p_name_str,v_rec_pos1+1,v_rec_pos2-v_rec_pos1-1);
   EXIT WHEN v_rec_pos2 = 0; --exit record loop

   --to get the no of columns for that particular record
   col_count:=0;
   FOR rec_length IN 1..length(v_record)
   LOOP
         v_field_pos2 := instr(v_record,p_field_delimit,v_field_pos1+1,1);
      IF v_field_pos2 = 0
      THEN
           EXIT;
      END IF;
      col_count:=col_count+1;
      v_field_pos1   := v_field_pos2 + length(p_field_delimit) - 1;
   END LOOP;
   num_cols := col_count+1;
   v_field_pos2:=0;
   v_field_pos1:=0;

   FOR loop_counter IN 1..num_cols - 1
      LOOP -- field loop
         table_counter := table_counter + 1;
         v_field_pos2 := instr(v_record,p_field_delimit,v_field_pos1+1,1) ;
         v_field     := ltrim(rtrim(substr(v_record,v_field_pos1+1,v_field_pos2-v_field_pos1-1)));
         p_rec_holder(table_counter)   :=  v_field;
         v_field_pos1   := v_field_pos2 + length(p_field_delimit) - 1;
      EXIT WHEN v_field_pos2 =0; -- exit field loop
      END LOOP;
      v_field     := substr(v_record,v_field_pos1+1,length(v_record));
      table_counter := table_counter + 1;
      p_rec_holder(table_counter)   := v_field;

         -- The separated fields for the record are being held by p_rec_holder.
      -- This is sent to the Action procedure ,sp_display where the business logic for
      -- the separated values is written.

      v_field_pos1   :=0;
      v_field_pos2   :=0;

       v_rec_pos1 :=v_rec_pos2 + length(p_row_delimit) - 1 ;
 END LOOP;-- end record loop
EXCEPTION
WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20020, 'ERROR in ecrd_delimiter_prc.' || SQLCODE ||  ' - ' || SQLERRM);
END ecrd_delimiter_prc;
-------------------------------------

PROCEDURE ecrd_get_list_of_tc_prc
(
     p_in_location_id   IN  crd_crc_user.location_id%TYPE,
     p_out_tc_list      OUT result_cursor
)
IS
BEGIN
	 OPEN 
    		p_out_tc_list
    FOR
			SELECT 
         		userid,
               email_address
			FROM 
         		crd_crc_user
			WHERE
			 	  	location_id = p_in_location_id
				   AND active_ind = ecrd_utils_pkg.G_USER_ACTIVE
					AND user_role = ecrd_utils_pkg.G_TC
               AND email_address IS NOT NULL;
EXCEPTION
WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20020, 'ERROR in ecrd_send_notification_pkg.ecrd_get_list_of_tc_prc' || SQLCODE ||  ' - ' || SQLERRM);	 
end ecrd_get_list_of_tc_prc;
--------------------------------------
PROCEDURE ecrd_get_location_id_prc
(
     p_in_module_seq_id  IN  crd_e_component_location.module_seq_id%TYPE,
     p_in_component_code IN  crd_e_component_location.component_code%TYPE,
  	  p_out_location_id_list   OUT result_cursor
)
IS
BEGIN
	 OPEN 
    		p_out_location_id_list
	 FOR
	 		SELECT 
         		location_id
	 		FROM 	
         		crd_e_component_location
			WHERE
				  	component_code=p_in_component_code
			      AND module_seq_id= p_in_module_seq_id
					AND active_ind = ecrd_utils_pkg.G_YES;
EXCEPTION
WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20020, 'ERROR in ecrd_send_notification_pkg.ecrd_get_location_id_prc' || SQLCODE ||  ' - ' || SQLERRM);	 
end ecrd_get_location_id_prc;
--------------------------------------
PROCEDURE ecrd_get_all_sites_prc
(
     p_out_site_list   OUT result_cursor
)
IS
BEGIN
	 OPEN 
    	p_out_site_list
	 FOR
		 SELECT 
		 		DISTINCT location_id 
		 FROM 
		 	    crd_e_component_location
		 WHERE	  	  
		 	    active_ind = ecrd_utils_pkg.G_YES;
EXCEPTION
WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20020, 'ERROR in ecrd_send_notification_pkg.ecrd_get_all_sites_prc' || SQLCODE ||  ' - ' || SQLERRM);	 
end ecrd_get_all_sites_prc;
------------------------------------------------
PROCEDURE ecrd_get_all_cycle_class_prc
(
     p_out_cycle_class_list   OUT result_cursor
)
IS
BEGIN
	 OPEN 
    	p_out_cycle_class_list
	 FOR
		 SELECT 
		 		cycle_count_class,
				notification_period_in_days 
		 FROM 
		 	    crd_e_cycle_counting_type;
EXCEPTION
WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20020, 'ERROR in ecrd_send_notification_pkg.ecrd_get_all_cycle_class_prc' || SQLCODE ||  ' - ' || SQLERRM);	 
end ecrd_get_all_cycle_class_prc;
------------------------------------------------
PROCEDURE ecrd_notification_mails_prc
(
     p_out_msg	OUT LONG
)
IS
	  cnt int;
     p_loc_id result_cursor;
     p_tc_list result_cursor; 
     p_comp_list result_cursor;
	  p_cycle_class_list result_cursor;
	  v_loc_table ecrd_location_table;
     v_cycle_class ecrd_cycle_class_table;
     v_comp_table ecrd_comp_list_table;
     v_tc_mail_list ecrd_tc_names_email_table;
     
     p_in_recipient_email LONG;
     p_in_sender_email LONG;
     p_in_cc LONG;
     p_in_subject VARCHAR2(100);
     p_in_message LONG;
     p_in_disclaimer_msg LONG;
     v_previous_module_seq_id crd_crc_module.module_seq_id%TYPE;
     v_model_desc crd_crc_eng_mdl_display.eng_mdl_desc%TYPE;
BEGIN
	p_in_disclaimer_msg :='--------------------------------------------------------------------------------------' ||  new_line  ||
							 'Disclaimer: This e-mail message contain GE Confidential, proprietary and legally '||
                      'privileged information for the sole use of the person or entity to whom this '||
                      'message was originally addressed. Any review, e-transmission dissemination or'||
                      ' other use of or taking of any action in reliance upon this information by '||
                      'persons or entities other than the intended recipient is prohibited. If you '||
                      'have received this e-mail in error kindly delete this e-mail from your records.'||
                      ' If it appears that this mail has been forwarded to you without proper authority, '||
                      'please notify the sender and delete this mail. This email (in whole or in part) is '||
                      'not to be reproduced or furnished to third parties or made public without the '||
                      'prior express written permission of the sender.'||  new_line ||
                      '--------------------------------------------------------------------------------------';

	-- Get all the sites from crd_e_component_location
	ecrd_get_all_sites_prc
   (
	   p_loc_id	
   );
   
	/* 
		For each of the site retrieved get the corresponding components which are 
      active for all types of cycle classes 
	*/
   LOOP
	   FETCH p_loc_id INTO v_loc_table(1).location_id;
		EXIT WHEN p_loc_id%NOTFOUND;	
      
      -- Call to prc for getting the list of TC's for that site
      ecrd_get_list_of_tc_prc
		(
			v_loc_table(1).location_id,
			p_tc_list
		);
		cnt := 0;
    	p_in_recipient_email := '';
      LOOP
			FETCH p_tc_list INTO v_tc_mail_list(1).userid,
						            v_tc_mail_list(1).email_address;
			EXIT WHEN p_tc_list%NOTFOUND;
         -- Store all email addresses to send mail
       	p_in_recipient_email := p_in_recipient_email || v_tc_mail_list(1).email_address ||',';
         cnt := cnt +1;
	  	END LOOP;
   
      /*
      	If cnt = 0 Then Send Mail To Admin And Mention The same in the mail
      */
      IF cnt =0 THEN
				OPEN p_tc_list
            FOR
            	SELECT 
               		userid,
                     email_address
              	FROM 
               		crd_crc_user
					WHERE
					 	   location_id = ecrd_utils_pkg.G_ALL
							AND active_ind =ecrd_utils_pkg.G_USER_ACTIVE
							AND user_role = ecrd_utils_pkg.G_ADMIN
                     AND email_address IS NOT NULL ;
            
            cnt := 0;
          	p_in_recipient_email := '';
      		LOOP
					FETCH p_tc_list INTO v_tc_mail_list(1).userid,
								            v_tc_mail_list(1).email_address;
					EXIT WHEN p_tc_list%NOTFOUND;
             	p_in_recipient_email := p_in_recipient_email || v_tc_mail_list(1).email_address || ',';
               cnt := cnt + 1;
      		END LOOP;
	   END IF;
      
      p_in_sender_email := ecrd_utils_pkg.G_ADMIN_FUNCTIONAL_ID;
      
      /* 
      	Get all cycle classes 
      */
      
   	ecrd_get_all_cycle_class_prc
	   (
		   p_cycle_class_list
		);
   	/*
      	For each type of class get the components for the site selected which are active
      */
		
      LOOP
      	FETCH p_cycle_class_list INTO v_cycle_class(1).cycle_class,
										         v_cycle_class(1).notification_period;
			EXIT WHEN p_cycle_class_list%NOTFOUND;
 	      ecrd_get_comp_list_prc
			(	
					v_loc_table(1).location_id,
					v_cycle_class(1).cycle_class,
					v_cycle_class(1).notification_period,
			     	p_comp_list 
			);
         p_in_subject := 'Reminder for Updating Repair Cost Information';			
         cnt := 0;
         LOOP
         	FETCH p_comp_list INTO v_comp_table(1).comp_code,
            							  v_comp_table(1).comp_desc,
                                   v_comp_table(1).module_seq_id,
								           v_comp_table(1).module_name;
				EXIT WHEN p_comp_list%NOTFOUND;
            
				cnt := cnt +1;
            IF(v_previous_module_seq_id = v_comp_table(1).module_seq_id) 
            THEN
           		p_in_message := p_in_message || new_line || '   ' ||v_comp_table(1).comp_code || '       '|| v_comp_table(1).comp_desc || new_line;
	         ELSE
            	IF cnt <> 1 THEN
	            -- Call send mail procedure for Module and then go for the next module

					-- Added for check.... hav to remove ths statment
               --	p_in_recipient_email :='deepa.pawar@patni.com,';

                  p_in_message := p_in_message || new_line || new_line ||new_line || '                                                                                               '||ecrd_utils_pkg.G_ADMIN_FUNCTIONAL_ID;
                  p_in_message := p_in_message || new_line ||  new_line || p_in_disclaimer_msg; 
	              	ecrd_send_mail_prc
						(
						  p_in_sender_email,
						  p_in_recipient_email, -- emails seperated by ","",
						  p_in_cc,
						  p_in_subject,
						  p_in_message
						);
               END IF;
		         ecrd_get_engine_model_prc
					(
     					v_comp_table(1).module_seq_id,
     					v_model_desc
					);	
					p_in_message := '';	
               p_in_message := p_in_message ||new_line || ' *** This is an automated mail , Please do not reply back to this email *** ';
	            p_in_message := p_in_message || new_line || new_line;
               p_in_message := p_in_message || 'This is the reminder for updating repair cost information for following components' || new_line || new_line;
               p_in_message := p_in_message || new_line || 'Engine Model  :  ' || v_model_desc || new_line;
             	p_in_message := p_in_message || new_line || 'Engine Module :  ' ||v_comp_table(1).module_name|| new_line;
               p_in_message := p_in_message || new_line || 'Component Information' || new_line;
               p_in_message := p_in_message || new_line || '   Code    ' ||  '   Desc    ' || new_line;
               p_in_message := p_in_message || new_line ||  '   ' || v_comp_table(1).comp_code ||'       '|| v_comp_table(1).comp_desc || new_line;
            END IF;
            v_previous_module_seq_id :=v_comp_table(1).module_seq_id;
         END LOOP; /* End of Comp List Loop */

        --Call send mail prc to send the mails for the last module
        	 IF cnt > 1 THEN
          
			---  Ths stmt has to be removed.....added for checking....
			--   p_in_recipient_email :='deepa.pawar@patni.com,';
            p_in_message := p_in_message || new_line || new_line ||new_line || '                                                                                               '||ecrd_utils_pkg.G_ADMIN_FUNCTIONAL_ID;
            p_in_message := p_in_message || new_line || new_line || p_in_disclaimer_msg;
         	ecrd_send_mail_prc
				(
				  p_in_sender_email,
				  p_in_recipient_email, -- emails seperated by ","",
				  p_in_cc,
				  p_in_subject,
				  p_in_message
				);
          END IF;
		END LOOP; /* End of get all Cycle_classes */              		
	END LOOP; /* End loop of Get Sites */
EXCEPTION
WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20020, 'ERROR in ecrd_send_notification_pkg.ecrd_notification_mails_prc' || SQLCODE ||  ' - ' || SQLERRM);   
END ecrd_notification_mails_prc;
------------------------------------------------

PROCEDURE ecrd_get_engine_model_prc
(
     p_in_module_seq_id IN crd_crc_module.module_seq_id%TYPE,
     p_out_model_name OUT  crd_crc_eng_mdl_display.eng_mdl_desc%TYPE  
)
IS
BEGIN
	   SELECT 
      	ccemd.eng_mdl_desc
      INTO 
      	p_out_model_name
		FROM 
      	crd_crc_eng_mdl_display ccemd,
         crd_crc_module ccm
		WHERE
			ccm.module_seq_id = p_in_module_seq_id  AND
			ccm.eng_mdl_number = ccemd.eng_mdl_number;
EXCEPTION
WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20020, 'ERROR in ecrd_send_notification_pkg.ecrd_get_engine_model_prc' || SQLCODE ||  ' - ' || SQLERRM);         
END ecrd_get_engine_model_prc;
---------------------------------------
end ecrd_send_notification_pkg;
/
--------------------------------------

