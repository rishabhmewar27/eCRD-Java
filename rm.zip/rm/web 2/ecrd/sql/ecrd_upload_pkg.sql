create or replace package ecrd_upload_pkg
IS
PROCEDURE ecrd_upload_data_prc(
as_engine_code	IN 	VARCHAR2,

/* Patni 23-Aug-2006 - Removed Module Name from the input parameter list - Begin */
--as_module_desc	IN 	VARCHAR2,
/* Patni 23-Aug-2006 - Removed Module Name from the input parameter list - End */

as_site_name	IN		VARCHAR2,
as_user_id 		IN 	VARCHAR2,
as_catalog_id	IN VARCHAR2,
as_is_admin		IN	VARCHAR2,
as_data1_in		IN 	LONG,
as_data2_in		IN 	LONG,
as_data3_in		IN 	LONG,
as_data4_in		IN 	LONG,
as_data5_in		IN 	LONG,
as_data6_in		IN 	LONG,
as_data7_in		IN 	LONG,
as_data8_in		IN 	LONG,
as_data9_in		IN 	LONG,
as_data10_in		IN 	LONG,
as_data1_out		OUT 	VARCHAR2,
as_data2_out		OUT 	VARCHAR2,
as_data3_out		OUT 	VARCHAR2,
as_data4_out		OUT 	VARCHAR2,
as_data5_out		OUT 	VARCHAR2,
as_data6_out		OUT 	VARCHAR2,
as_data7_out		OUT 	VARCHAR2,
as_data8_out		OUT 	VARCHAR2,
as_data9_out		OUT 	VARCHAR2,
as_data10_out		OUT 	VARCHAR2,
as_data11_out		OUT 	VARCHAR2,
as_data12_out		OUT 	VARCHAR2,
as_data13_out		OUT 	VARCHAR2,
as_data14_out		OUT 	VARCHAR2,
as_data15_out		OUT 	VARCHAR2
);

TYPE input_array IS VARRAY(4000) OF VARCHAR2(32767) ;

END ecrd_upload_pkg;
/
CREATE OR REPLACE PACKAGE BODY ecrd_upload_pkg
IS
PROCEDURE ecrd_upload_data_prc(
as_engine_code	IN 	VARCHAR2,

/* Patni 23-Aug-2006 - Removed Module Name from the input parameter list - Begin */
--as_module_desc	IN 	VARCHAR2,
/* Patni 23-Aug-2006 - Removed Module Name from the input parameter list - End */

as_site_name	IN		VARCHAR2,
as_user_id 		IN 	VARCHAR2,
as_catalog_id	IN VARCHAR2,
as_is_admin		IN	VARCHAR2,
as_data1_in		IN 	LONG,
as_data2_in		IN 	LONG,
as_data3_in		IN 	LONG,
as_data4_in		IN 	LONG,
as_data5_in		IN 	LONG,
as_data6_in		IN 	LONG,
as_data7_in		IN 	LONG,
as_data8_in		IN 	LONG,
as_data9_in		IN 	LONG,
as_data10_in		IN 	LONG,
as_data1_out		OUT 	VARCHAR2,
as_data2_out		OUT 	VARCHAR2,
as_data3_out		OUT 	VARCHAR2,
as_data4_out		OUT 	VARCHAR2,
as_data5_out		OUT 	VARCHAR2,
as_data6_out		OUT 	VARCHAR2,
as_data7_out		OUT 	VARCHAR2,
as_data8_out		OUT 	VARCHAR2,
as_data9_out		OUT 	VARCHAR2,
as_data10_out		OUT 	VARCHAR2,
as_data11_out		OUT 	VARCHAR2,
as_data12_out		OUT 	VARCHAR2,
as_data13_out		OUT 	VARCHAR2,
as_data14_out		OUT 	VARCHAR2,
as_data15_out		OUT 	VARCHAR2
)
AS
ls_mod_seq_id	CRD_E_COMPONENT.MODULE_SEQ_ID%TYPE;
ls_rem_data		LONG;
ls_row_comp		LONG;
lb_not_eof		BOOLEAN;
ls_row_no		VARCHAR2(50);

/* Patni 25-Aug-2006 - Declared variables - Begin */
ls_module_name     CRD_CRC_MODULE.MODULE_NAME%TYPE;
/* Patni 25-Aug-2006 - Declared variables - End */

ls_comp_code CRD_E_COMPONENT.COMPONENT_CODE%TYPE;
ls_comp_desc CRD_E_COMPONENT.COMPONENT_DESCRIPTION%TYPE;
ls_comp_doc_ref CRD_E_COMPONENT.ATA_REFERENCE_SNUM%TYPE;
ls_rep_desc CRD_E_REPAIR.REPAIR_DESCRIPTION%TYPE;
ls_rep_ref	CRD_E_REPAIR.REPAIR_REFERENCE_FORMAT%TYPE;
ls_rep_TAT VARCHAR2(500);
ls_rep_Future_TAT	VARCHAR2(500);
ls_rep_price VARCHAR2(500);
ls_rep_Future_price VARCHAR2(500);
ls_rep_price_inc_ind CRD_E_REPAIR_CATALOG.INCREMENTAL_PRICE_IND%TYPE;
ls_rep_TAT_inc_ind CRD_E_REPAIR_CATALOG.INCREMENTAL_TAT_IND%TYPE;
ln_rep_seq_id	CRD_E_REPAIR.REPAIR_SEQ_ID%TYPE;
ln_price_type_id CRD_E_REPAIR_CATALOG.PRICE_TYPE%TYPE;
ln_labor_cost	LONG;
ln_material_cost	LONG;
ls_future_date	VARCHAR2(200);
ln_temp NUMBER;
p_location_id  crd_location.location_id%TYPE;
v_v_eng_mod_cd CRD_CRC_ENG_MDL_DISPLAY.ENG_MDL_NUMBER%TYPE;
v_is_present          NUMBER:=0;
v_is_present_for_user NUMBER:=0;
in_data input_array;
v_repair_cost_count NUMBER :=0; -- Added by milind on 26/11/2004
v_comp_hist_count NUMBER :=0; -- added by milind on 26/11/2004
v_n_modified NUMBER :=0;
v_n_cost_modified NUMBER :=0;
v_b_pend_apprv_added BOOLEAN :=FALSE;

--09-05-2006 Patni Added repair seq id parameter Begin
ls_rep_seq_id     VARCHAR2(400);
ls_rep_eff_date   VARCHAR2(400);
ls_incr_tat_ind   CRD_E_REPAIR_CATALOG.INCREMENTAL_PRICE_IND%TYPE;
ls_incr_price_ind CRD_E_REPAIR_CATALOG.INCREMENTAL_TAT_IND%TYPE;
v_catalog_type   varchar2(100):=NULL;
v_n_repr_des_mod NUMBER :=0;
--09-05-2006 Patni Added repair seq id parameter End
ls_retain_val_ind VARCHAR2(2):= NULL;
/*
*/


PROCEDURE ecrd_chk_is_pres_prc(p_in_repair_seq	        IN crd_e_repair_catalog.repair_seq_id%TYPE
		  				      ,p_in_catalog_seq         IN crd_e_repair_catalog.catalog_seq_id%TYPE
							  ,p_in_user                IN crd_e_repair_catalog_hist.requested_by%TYPE
		  					  ,p_in_present_by_user     OUT NUMBER
							  ,p_in_present             OUT NUMBER)
AS
BEGIN
	 /*
	 */


   SELECT COUNT(1)
	 INTO p_in_present_by_user
	 FROM crd_e_repair_catalog_hist cerch
	 WHERE cerch.approve_reject_status IS NULL
	 AND UPPER(cerch.requested_by) = UPPER(p_in_user)
	 AND cerch.staging_history_ind = ecrd_utils_pkg.G_STAGING
	 AND cerch.repair_seq_id = p_in_repair_seq
	 AND cerch.catalog_seq_id = p_in_catalog_seq   ;
	 /*
	 */
	 SELECT COUNT(1)
	 INTO p_in_present
	 FROM crd_e_repair_catalog_hist cerch
	 WHERE cerch.approve_reject_status IS NULL
	 AND cerch.staging_history_ind = ecrd_utils_pkg.G_STAGING
	 AND cerch.repair_seq_id = p_in_repair_seq
	 AND cerch.catalog_seq_id = p_in_catalog_seq   ;
	 /*
	 */
	 EXCEPTION
	 		  WHEN OTHERS
			  THEN
			  	  RAISE;
END ecrd_chk_is_pres_prc;
/*
*/
PROCEDURE ecrd_chk_modification_prc(p_in_repair_seq	        IN crd_e_repair_catalog.repair_seq_id%TYPE
		  				      ,p_in_catalog_seq               IN crd_e_repair_catalog.catalog_seq_id%TYPE
                        ,p_in_rep_pric				IN crd_e_repair_catalog.repair_price%TYPE
                        ,p_in_pric_type         IN crd_e_repair_catalog.price_type%TYPE
                        ,p_in_rep_tat           IN crd_e_repair_catalog.repair_tat%TYPE
                        ,p_in_inc_tat           IN crd_e_repair_catalog.incremental_tat_ind%TYPE
                        ,p_in_inc_pric          IN crd_e_repair_catalog.incremental_price_ind%TYPE
                        ,p_in_fut_tat				IN crd_e_repair_catalog.future_tat%TYPE
                        ,p_in_fut_pric				IN crd_e_repair_catalog.future_price%TYPE
                        ,p_in_fut_date				IN LONG
                        ,p_in_loc_id				IN crd_location.location_id%TYPE
                        ,p_in_lab_hrs      		IN LONG
                        ,p_in_mat_cost				IN LONG
                        ,p_in_mod_id				IN LONG
                        ,p_in_comp_cd				IN LONG
          -- 17-05-2006 Patni added injput parameter for repair description Begin
                        ,p_in_rep_des       IN crd_e_repair.repair_description%TYPE
          -- 17-05-2006 Patni added injput parameter for repair description End
                        ,p_out_modified			OUT NUMBER
                        ,p_out_cost_mod			OUT NUMBER
    -- 17-05-2006 Patni added out put  parameter for repair description updation Begin
                        ,p_out_repr_des_mod OUT NUMBER)
    -- 17-05-2006 Patni added out put  parameter for repair description updation End

 /*
  */
AS
	 BEGIN
    --
		SELECT COUNT(1)
      INTO p_out_modified
		FROM crd_e_repair_catalog cerc
		WHERE cerc.catalog_seq_id = p_in_catalog_seq
		AND cerc.repair_seq_id = p_in_repair_seq
		AND ( cerc.repair_end_date IS NULL OR cerc.repair_end_date  > SYSDATE)
		AND NVL(cerc.repair_price,0)  =NVL(p_in_rep_pric,0)
		AND NVL(cerc.repair_tat,0  )  = NVL(p_in_rep_tat ,0)
		AND UPPER(TRIM(cerc.price_type)) = UPPER(TRIM(p_in_pric_type))
		AND UPPER(TRIM(cerc.incremental_price_ind)) = p_in_inc_pric
		AND UPPER(TRIM(cerc.incremental_tat_ind)) =    p_in_inc_tat
      AND NVL(cerc.future_price ,0  )= NVL(p_in_fut_pric,0  )
      AND NVL(cerc.future_tat,0  ) =NVL(p_in_fut_tat ,0  )
      AND NVL(TO_CHAR(cerc.future_effective_date,'MM/DD/YYYY')	,0)=NVL(p_in_fut_date,0);
      --

      SELECT COUNT(1)
      INTO p_out_cost_mod
      FROM crd_e_repair_cost cerc
      WHERE cerc.component_code = p_in_comp_cd
      AND cerc.module_seq_id    = TO_NUMBER(p_in_mod_id)
      AND cerc.repair_seq_id	  = p_in_repair_seq
      AND cerc.location_id		  = p_in_loc_id
      AND NVL(cerc.labour_hours,0)     = TO_NUMBER(NVL(p_in_lab_hrs,0) )
      AND NVL(cerc.material_cost	,0)   = TO_NUMBER(NVL(p_in_mat_cost,0) );


-- 11-05-2006 Patni  For checking the repair description modification  Begin

SELECT COUNT(1)
		INTO p_out_repr_des_mod
		FROM crd_e_repair cer
		WHERE TRIM(UPPER(cer.Repair_Description)) = TRIM(UPPER(p_in_rep_des))
    AND cer.repair_seq_id =  ls_rep_seq_id
		AND ( cer.repair_end_date IS NULL or  cer.repair_end_date > SYSDATE ) ;



-- 11-05-2006 Patni  For checking the repair description modification  End

	 EXCEPTION
	 		  WHEN OTHERS
			  THEN
			  	  RAISE;
--
END ecrd_chk_modification_prc ;
/*
*/
PROCEDURE populate_in_data
AS
BEGIN


	in_data(1) := as_data1_in;
	in_data.EXTEND(1);
	in_data(2) := as_data2_in;
	in_data.EXTEND(1);
	in_data(3) := as_data3_in;
	in_data.EXTEND(1);
	in_data(4) := as_data4_in;
	in_data.EXTEND(1);
	in_data(5) := as_data5_in;
	in_data.EXTEND(1);
	in_data(6) := as_data6_in;
	in_data.EXTEND(1);
	in_data(7) := as_data7_in;
	in_data.EXTEND(1);
	in_data(8) := as_data8_in;
	in_data.EXTEND(1);
	in_data(9) := as_data9_in;
	in_data.EXTEND(1);
	in_data(10) := as_data10_in;
END populate_in_data;

FUNCTION return_string(aInStr IN LONG,separator IN VARCHAR2,mode_type IN VARCHAR2)
RETURN LONG
IS
	p_outStr LONG;
BEGIN
	IF (mode_type = 'BEF') THEN
		p_outStr := SUBSTR(aInStr, 1, INSTR(aInStr, separator) - 1) ;
	ELSIF (mode_type = 'AFT') THEN
		p_outStr := SUBSTR(aInStr, INSTR(aInStr, separator) + 1) ;
	END IF;

	return p_outStr;
END return_string;

PROCEDURE add_error(aErrMsg IN VARCHAR2)
IS
BEGIN
	IF (LENGTH(NVL(as_data1_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
		as_data1_out := as_data1_out || aErrMsg;
	ELSIF (LENGTH(NVL(as_data2_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
		as_data2_out := as_data2_out || aErrMsg;
	ELSIF (LENGTH(NVL(as_data3_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
		as_data3_out := as_data3_out || aErrMsg;
	ELSIF (LENGTH(NVL(as_data4_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
		as_data4_out := as_data4_out || aErrMsg;
	ELSIF (LENGTH(NVL(as_data5_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
		as_data5_out := as_data5_out || aErrMsg;
	ELSIF (LENGTH(NVL(as_data6_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
		as_data6_out := as_data6_out || aErrMsg;
	ELSIF (LENGTH(NVL(as_data7_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
		as_data7_out := as_data7_out || aErrMsg;
	ELSIF (LENGTH(NVL(as_data8_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
		as_data8_out := as_data8_out || aErrMsg;
	ELSIF (LENGTH(NVL(as_data9_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
		as_data9_out := as_data9_out || aErrMsg;
	ELSIF (LENGTH(NVL(as_data10_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
		as_data10_out := as_data10_out || aErrMsg;
	ELSIF (LENGTH(NVL(as_data11_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
		as_data11_out := as_data11_out || aErrMsg;
	ELSIF (LENGTH(NVL(as_data12_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
		as_data12_out := as_data12_out || aErrMsg;
	ELSIF (LENGTH(NVL(as_data13_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
		as_data13_out := as_data13_out || aErrMsg;
	ELSIF (LENGTH(NVL(as_data14_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
		as_data14_out := as_data14_out || aErrMsg;
	ELSIF (LENGTH(NVL(as_data15_out,' ')) + LENGTH(aErrMsg) < 4000) THEN
		as_data15_out := as_data15_out || aErrMsg;
	END IF;
END add_error;

/* Patni 23-Aug-2006 - Function to validate the Module Name - Begin */
FUNCTION validate_module(aEngModelCode IN LONG, aModuleName IN LONG, aRowNum IN VARCHAR2)
RETURN NUMBER
IS
  p_count      NUMBER;
  p_module_seq_id NUMBER;
BEGIN
     p_module_seq_id := NULL;
     
     BEGIN
          SELECT MODULE_SEQ_ID
	        INTO   p_module_seq_id
	        FROM   CRD_CRC_MODULE
	        WHERE  UPPER(MODULE_NAME) = UPPER(TRIM(aModuleName))
          AND    UPPER(ENG_MDL_NUMBER) = UPPER(TRIM(aEngModelCode));
  	 EXCEPTION
     WHEN NO_DATA_FOUND THEN
          p_module_seq_id := NULL;
     END;
     
     IF (p_module_seq_id IS NOT NULL) THEN
        RETURN p_module_seq_id;
	   ELSE
		    add_error('Error in Row Number '|| aRowNum || ' Module Name ' || aModuleName || ' does not exist^');
		    RETURN 0;
	   END IF;
END validate_module;
/* Patni 23-Aug-2006 - Function to validate the Module Name - Begin */

/* Patni 23-Aug-2006 - Included Module Seq Id as the input parameter - Begin */
--FUNCTION validate_component(aCompCode IN LONG,aRowNum IN VARCHAR2)
FUNCTION validate_component(aCompCode IN LONG,aRowNum IN VARCHAR2,aModuleSeqId IN LONG)
/* Patni 23-Aug-2006 - Included Module Seq Id as the input parameter - End */
RETURN NUMBER
IS
	p_count NUMBER;
BEGIN
	SELECT COUNT(1)
	INTO p_count
	FROM crd_e_component
	WHERE Component_Code = TRIM(aCompCode)
  /* Patni 23-Aug-2006 - Check for the given Module Seq Id - Begin */
	--AND Module_Seq_id = ls_mod_seq_id;
  AND Module_Seq_id = aModuleSeqId;
  /* Patni 23-Aug-2006 - Check for the given Module Seq Id - End */
	
	IF (p_count = 1)
	THEN
		RETURN 1;
	ELSE
		add_error('Error in Row Number '|| aRowNum || ' Component Code ' || aCompCode || ' does not exist^');
		RETURN 0;
	END IF;
END validate_component;


/* Patni 23-Aug-2006 - Included Module Seq Id as the input parameter - Begin */
--FUNCTION validate_repair(aCompCode IN VARCHAR2,aRepDesc IN LONG,aRowNum IN VARCHAR2)
FUNCTION validate_repair(aCompCode IN VARCHAR2,aRepDesc IN LONG,aRowNum IN VARCHAR2,aModuleSeqId IN LONG)
/* Patni 23-Aug-2006 - Included Module Seq Id as the input parameter - End */
RETURN NUMBER
IS
	p_rep_seq_id NUMBER(9);
	p_count NUMBER;
BEGIN
	--Code added by milind on 16Th Nov 2004

	SELECT COUNT(1)
		INTO p_count
		FROM crd_e_repair cer
		,crd_e_component cec
		WHERE-- TRIM(UPPER(cer.Repair_Description)) = TRIM(UPPER(aRepDesc))
-- 11-05-2006 added to validate the repair seq id Begin
    cer.repair_seq_id =  ls_rep_seq_id
-- 11-05-2006 added to validate the repair seq id End
		AND cer.Component_Code = aCompCode
    
    /* Patni 23-Aug-2006 - Check for the given Module Seq Id - Begin */
		--AND cer.Module_Seq_id = ls_mod_seq_id
    AND cer.Module_Seq_id = aModuleSeqId
    /* Patni 23-Aug-2006 - Check for the given Module Seq Id - End */
    
		AND cer.Component_Code = cec.Component_Code
		AND cer.Module_Seq_id  = cec.Module_Seq_id
		AND cer.repair_end_date IS NULL
    AND cer.repair_type IN ( ecrd_utils_pkg.G_GROUP_REPAIR ,ecrd_utils_pkg.G_INDIVIDUAL_REPAIR );
	/*
	*/
	IF (p_count = 1)
	THEN

	--Code added by milind on 16Th Nov 2004
  	SELECT cer.repair_seq_id
		INTO p_rep_seq_id
		FROM crd_e_repair cer
			,crd_e_component cec
		WHERE-- TRIM(UPPER(cer.Repair_Description)) = TRIM(UPPER(aRepDesc))
 -- 11-05-2006 added to validate the repair seq id Begin
     cer.repair_seq_id =  ls_rep_seq_id
-- 11-05-2006 added to validate the repair seq id End

		AND cer.Component_Code = aCompCode

    /* Patni 23-Aug-2006 - Check for the given Module Seq Id - Begin */
		--AND cer.Module_Seq_id = ls_mod_seq_id
    AND cer.Module_Seq_id = aModuleSeqId
    /* Patni 23-Aug-2006 - Check for the given Module Seq Id - End */
    
		AND cer.Component_Code = cec.Component_Code
		AND cer.Module_Seq_id  = cec.Module_Seq_id
		AND cer.repair_end_date IS NULL
      AND cer.repair_type IN ( ecrd_utils_pkg.G_GROUP_REPAIR ,ecrd_utils_pkg.G_INDIVIDUAL_REPAIR );
		--

		RETURN p_rep_seq_id;
	ELSE
		IF (p_count = 0)
		THEN
			add_error('Error in Row Number '|| aRowNum || ' Repair  ' || aRepDesc || ' or repair seq id'|| ls_rep_seq_id ||'does not exist^');
		ELSE
			add_error('Error in Row Number '|| aRowNum || ' Repair ' || aRepDesc || ' has too Many Matches^');
		END IF;
		RETURN 0;
	END IF;
END validate_repair;

/*
Begin of main proc
*/

      

BEGIN

--  11-05-2006 Fetching  catalog type based on catalog seq id Begin
     
        

      

      BEGIN
           SELECT catalog_type
           INTO  v_catalog_type
           FROM crd_e_catalog
           WHERE catalog_seq_id = as_catalog_id ;
           EXCEPTION
           WHEN NO_DATA_FOUND
           THEN
           v_catalog_type :=NULL;
		       add_error('Catalog Seq id '||as_catalog_id||' Not Found^');
       	END;


--  11-05-2006 Fetching  catalog type based on catalog seq id End


  BEGIN

		SELECT eng_mdl_number
		INTO v_v_eng_mod_cd
		FROM crd_crc_eng_mdl_display
		WHERE TRIM(UPPER(eng_mdl_desc)) = TRIM(UPPER(as_engine_code));
	EXCEPTION
		WHEN NO_DATA_FOUND
		THEN
		    v_v_eng_mod_cd :=NULL;
		    add_error('Engine Model '||as_engine_code||' Not Found^');
	END;
-- 07-07-06 Patni implementing the site ALL selection BEGIN 
IF( as_site_name!= 'ALL') 
THEN 
	BEGIN
		SELECT location_id
		INTO p_location_id
		FROM crd_location
		WHERE TRIM(UPPER(location_desc)) =TRIM(UPPER( as_site_name));
	EXCEPTION
		WHEN NO_DATA_FOUND
		THEN
		    p_location_id :=NULL;
	    	    add_error('Site name : ' || as_site_name||' Not Found ^');
	END;
ELSE
 p_location_id :=NULL;
 END IF;
-- 07-07-06 Patni implementing the site ALL selection END

/* Patni 23-Aug-2006 - Commented the below code - Begin */
/*  
IF (v_v_eng_mod_cd IS NOT NULL)
	THEN
		BEGIN
			SELECT module_seq_id
			INTO ls_mod_seq_id
			FROM crd_crc_module
			WHERE TRIM(UPPER(module_name))= TRIM(UPPER(as_module_desc))
			AND eng_mdl_number = v_v_eng_mod_cd;
		EXCEPTION
			WHEN NO_DATA_FOUND
			THEN
				add_error('Module '|| as_module_desc ||' Not found for Engine Model ' || as_engine_code||'^');
				v_v_eng_mod_cd :=NULL;
		END;
END IF;

IF  (ls_mod_seq_id IS NOT NULL)
THEN
*/
/* Patni 23-Aug-2006 - Commented the below code - End */
	in_data := input_array('');
	populate_in_data();

	FOR i IN 1..10 LOOP
	IF in_data(i) IS NOT NULL
	THEN
		ls_rem_data := in_data(i);
		lb_not_eof := TRUE;      
    
		WHILE lb_not_eof
		LOOP
			ls_row_comp := return_string(ls_rem_data,'|','BEF');
    	ls_rem_data := return_string(ls_rem_data,'|','AFT');

			IF ls_rem_data IS NULL
			THEN
				lb_not_eof := FALSE ;
			END IF;   
      
			ls_row_no := return_string(ls_row_comp,'^','BEF');
			ls_row_comp := return_string(ls_row_comp,'^','AFT');

      /* Patni 23-Aug-2006 - Extracting data for Module Name and validating it - Begin */
      ls_module_name := return_string(ls_row_comp,'^','BEF');
			ls_row_comp := return_string(ls_row_comp,'^','AFT');
      
      ls_mod_seq_id := validate_module(v_v_eng_mod_cd,ls_module_name,ls_row_no);
      /* Patni 23-Aug-2006 - Extracting data for Module Name and validating it - End */
            
			ls_comp_desc := return_string(ls_row_comp,'^','BEF');
			ls_row_comp := return_string(ls_row_comp,'^','AFT');

			ls_comp_code := return_string(ls_row_comp,'^','BEF');
			ls_row_comp := return_string(ls_row_comp,'^','AFT');

			ls_comp_doc_ref := return_string(ls_row_comp,'^','BEF');
			ls_row_comp := return_string(ls_row_comp,'^','AFT');

 /*
      */

      /* Patni 25-Aug-2006 - Validating the component based on the given Module Seq Id - Begin */
			--ln_temp := validate_component(ls_comp_code,ls_row_no);
      ln_temp := validate_component(ls_comp_code,ls_row_no,ls_mod_seq_id);
      /* Patni 25-Aug-2006 - Validating the component based on the given Module Seq Id - End */

			IF (ln_temp = 1)
			THEN
-- 09-05-2006 Patni Added ls_rep_seq_id to fetch the reapir seq id Begin
			  ls_rep_seq_id := return_string(ls_row_comp,'^','BEF');
       	ls_row_comp := return_string(ls_row_comp,'^','AFT');
-- 09-05-2006 Patni Added ls_rep_seq_id to fetch the reapir seq id End

      	ls_rep_ref := return_string(ls_row_comp,'^','BEF');
				ls_row_comp := return_string(ls_row_comp,'^','AFT');

				ls_rep_desc := return_string(ls_row_comp,'^','BEF');
				ls_row_comp := return_string(ls_row_comp,'^','AFT');

-- 09-05-2006 Patni Added ls_rep_eff_date to fetch the reapir effective date Begin
		--	  ls_rep_eff_date := return_string(ls_row_comp,'^','BEF');
     --  	ls_row_comp := return_string(ls_row_comp,'^','AFT');
-- 09-05-2006 Patni Added ls_rep_eff_date to fetch the reapir effective date End


        ln_price_type_id := return_string(ls_row_comp,'^','BEF');
				ls_row_comp := return_string(ls_row_comp,'^','AFT');

				ls_rep_TAT := return_string(ls_row_comp,'^','BEF');
				ls_row_comp := return_string(ls_row_comp,'^','AFT');

-- 09-05-2006 Patni Added ls_incr_tat_ind to fetch the incremental TAT Indicator Begin
			  ls_incr_tat_ind := return_string(ls_row_comp,'^','BEF');
       	ls_row_comp := return_string(ls_row_comp,'^','AFT');
-- 09-05-2006 Patni Added ls_incr_tat_ind to fetch the incremental TAT Indicator End


				ls_rep_price := return_string(ls_row_comp,'^','BEF');
				ls_row_comp := return_string(ls_row_comp,'^','AFT');

-- 09-05-2006 Patni Added ls_incr_price_ind to fetch the incremental Price Indicator Begin
			  ls_incr_price_ind := return_string(ls_row_comp,'^','BEF');
       	ls_row_comp := return_string(ls_row_comp,'^','AFT');
-- 09-05-2006 Patni Added ls_incr_price_ind to fetch the incremental Price  Indicator End

				ls_rep_Future_TAT := return_string(ls_row_comp,'^','BEF');
				ls_row_comp := return_string(ls_row_comp,'^','AFT');

				ls_rep_Future_price := return_string(ls_row_comp,'^','BEF');
				ls_row_comp := return_string(ls_row_comp,'^','AFT');

				ls_future_date := return_string(ls_row_comp,'^','BEF');
				ls_row_comp := return_string(ls_row_comp,'^','AFT');

-- 26-06-2006 Patni Added Retain Value Indicator  Begin 
				ls_retain_val_ind := return_string(ls_row_comp,'^','BEF');
        ls_row_comp := return_string(ls_row_comp,'^','AFT');
-- 26-06-2006 Patni Added Retain Value Indicator  End        


        ln_labor_cost := return_string(ls_row_comp,'^','BEF');
				ls_row_comp := return_string(ls_row_comp,'^','AFT');

				ln_material_cost :=return_string(ls_row_comp,'^','BEF');-- ls_row_comp;
				v_b_pend_apprv_added  :=FALSE;

  -- 18-05-2006 patni commented the code to remove the TAT Sign validations Begin

  	/*		IF (INSTR(ls_rep_TAT,'+') > 0)
				THEN
					ls_rep_TAT_inc_ind := 'Y';
					ls_rep_TAT := SUBSTR(ls_rep_TAT,2);
				ELSE
					ls_rep_TAT_inc_ind := 'N';
				END IF;
*/
/*				IF (INSTR(ls_rep_price,'+') > 0)
				THEN
					ls_rep_price_inc_ind := 'Y';
					ls_rep_price := SUBSTR(ls_rep_price,2);
				ELSE
					ls_rep_price_inc_ind := 'N';
				END IF;*/

         -- 18-05-2006 patni commented the code to remove the TAT Sign validations End
				/*Start : updated by milind on 26/11/2004*/

      -- 07-07-06 Patni implementing the retain value indicator BEGIN 
       BEGIN  
          IF (ls_retain_val_ind = 'Y')
        THEN
             UPDATE crd_e_repair_cost 
             SET last_update_date = SYSDATE
							  ,last_updated_by = as_user_id
             WHERE module_seq_id = ls_mod_seq_id             
             AND repair_seq_id = ls_rep_seq_id
             AND component_code = ls_comp_code
             AND location_id = p_location_id ;
                          
        END IF;
        EXCEPTION WHEN OTHERS
        THEN 
             add_error('Error Updating for Repair cost on row number ' || ls_row_no ||'^');
        END;        
      -- 07-07-06 Patni implementing the retain value indicator END        
      -- 07-07-06 Patni implementing site all selection BEGIN        
        IF( as_site_name != 'ALL')
        THEN         
     -- 07-07-06 Patni implementing site all selection END
				  SELECT count(1)
					INTO v_comp_hist_count
					FROM crd_e_component_location cl
					WHERE cl.COMPONENT_CODE = ls_comp_code
					AND cl.LOCATION_ID = p_location_id          
					AND cl.MODULE_SEQ_ID = ls_mod_seq_id
					AND cl.ACTIVE_IND = ecrd_utils_pkg.G_ACTIVE;
        ELSE
        v_comp_hist_count :=1;
        END IF;
        
        
				IF v_comp_hist_count <> 1 THEN
   						add_error('Component '||ls_comp_desc||' not associated  for site '||as_site_name|| ' on row number ' || ls_row_no || '^');
				ELSE


				/*End : updated by milind on 26/11/2004*/

				IF (ls_rep_desc IS NOT NULL)
				THEN
          /* Patni 25-Aug-2006 - Validating the repair based on the given Module Seq Id - Begin */
					--ln_rep_seq_id := validate_repair(ls_comp_code,ls_rep_desc,ls_row_no);
          ln_rep_seq_id := validate_repair(ls_comp_code,ls_rep_desc,ls_row_no,ls_mod_seq_id);
          /* Patni 25-Aug-2006 - Validating the repair based on the given Module Seq Id - End */
          
               /*
               */

          ecrd_chk_is_pres_prc(ls_rep_seq_id
								 ,as_catalog_id
								 ,as_user_id
								 ,v_is_present_for_user
								 , v_is_present  );




                         /*
                         */
					IF ((ls_future_date IS NULL) AND ((ls_rep_Future_TAT IS NOT NULL) OR (ls_rep_Future_price IS NOT NULL)))
					THEN
						add_error('Future date not found for Repair '||ls_rep_desc|| ' on row number ' || ls_row_no || '^');
					ELSE


               ecrd_chk_modification_prc(ls_rep_seq_id
								 ,as_catalog_id
                        ,ls_rep_price
                        ,ln_price_type_id
                        ,ls_rep_TAT
                        ,ls_incr_tat_ind
                        ,ls_incr_price_ind
                        ,ls_rep_Future_TAT
                        ,ls_rep_Future_price
                        ,ls_future_date
                        ,p_location_id
                        ,ln_labor_cost
                        ,trim(ln_material_cost)
                        ,ls_mod_seq_id
								        ,ls_comp_code
     -- 17-05-2006 Patni added input parametere for repair description updation Begin
                        ,ls_rep_desc
     -- 17-05-2006 Patni added input parameter for repair description updation End
                        ,v_n_modified
                        ,v_n_cost_modified
     -- 17-05-2006 Patni added output parameter  repair description updation Begin
                        ,v_n_repr_des_mod);
     -- 17-05-2006 Patni added output parameter  repair description updation end
                       --
                       --
						IF (ls_rep_seq_id <> 0)
						THEN
                IF(v_is_present > 0 AND v_is_present_for_user = 0) AND (v_n_cost_modified = 0)
						 THEN
							 add_error('You Cannot Modify Repair '||ls_rep_desc ||' at Row '||ls_row_no  ||' as it is pending for approval^');
                      v_b_pend_apprv_added  :=TRUE;
						 ELSE

                    IF   (v_n_cost_modified = 0)
                    THEN
						           	BEGIN
                               ecrd_repair_pkg.ecrd_ins_repcatcost_hist_prc(ls_rep_seq_id
					  						      ,ls_mod_seq_id
												      ,p_location_id
												      ,ls_comp_code
					  						      ,as_user_id
					  						      );
			   		                	EXCEPTION
						      	          WHEN OTHERS
						      	        THEN
							             	
                            add_error('Error Updating for Repair History Data '||ls_rep_desc||' on row number ' || ls_row_no ||'^');
							          END;

                      BEGIN
							-- Start : Added by milind on 26/11/2004
      -- 07-07-06 Patni implementing site all selection BEGIN
				IF( as_site_name != 'ALL')
        THEN
      -- 07-07-06 Patni implementing site all selection END
        			SELECT COUNT(1)
							   INTO v_repair_cost_count
								FROM crd_e_repair_cost
								WHERE location_id  = p_location_id
								AND component_code = ls_comp_code
								AND module_seq_id  = TO_NUMBER(ls_mod_seq_id)
								AND repair_seq_id  = TO_NUMBER(ls_rep_seq_id) ;
        END IF;  

      -- 07-07-06 Patni implementing site all selection BEGIN
							IF v_repair_cost_count < 1 AND as_site_name != 'ALL'
              THEN
      -- 07-07-06 Patni implementing site all selection END

              	INSERT INTO crd_e_repair_cost
									   (module_seq_id,
									   repair_seq_id,
									   component_code,
									   location_id,
									   labour_hours,
									   material_cost,
									   created_by,
									   creation_date,
									   last_updated_by,
									   last_update_date
									   )
								VALUES(TO_NUMBER(ls_mod_seq_id),
										TO_NUMBER(ls_rep_seq_id),
										ls_comp_code,
										p_location_id,
										TO_NUMBER(ln_labor_cost),
										TO_NUMBER(trim(ln_material_cost)),
										as_user_id,
										SYSDATE,
										as_user_id,
										SYSDATE
								);
							ELSE
      -- 07-07-06 Patni implementing site all selection BEGIN
               IF( as_site_name!='ALL')
               THEN
      -- 07-07-06 Patni implementing site all selection END
									UPDATE crd_e_repair_cost
									SET	   labour_hours  = TO_NUMBER(ln_labor_cost)
										  ,material_cost = TO_NUMBER(trim(ln_material_cost))
  										  -- Start : added by milind on 21/11/2004
										  ,last_update_date = SYSDATE
										  ,last_updated_by = as_user_id
										  -- End : added by milind on 21/11/2004
									WHERE location_id  = p_location_id
									AND component_code = ls_comp_code
									AND module_seq_id  = TO_NUMBER(ls_mod_seq_id)
									AND repair_seq_id  = TO_NUMBER(ls_rep_seq_id) ;
                END IF;  
							END IF;
						-- End : Added by milind on 26/11/2004
							EXCEPTION
							WHEN OTHERS
							THEN
								add_error('Error Updating Repair Cost for '||ls_rep_desc||' on row number ' || ls_row_no ||'^');
							END;
                    END IF;--if cost modified
                   END IF;--for pending approval

              -- 17-05-2006 Patni Updating the repair description Begin


              IF(v_n_repr_des_mod = 0 AND v_catalog_type = 'D' AND as_is_admin  = 'Y' )
              THEN
                 BEGIN
                   INSERT INTO Crd_e_Repair_History
                           (repair_seq_id,
                           staging_history_ind,
                           component_code,
                           module_seq_id,
                           repair_description,
                           change_start_date,
                           creation_date,
                           created_by,
                           last_update_date,
                           last_updated_by,
                           parent_repair_seq_id
                          )
                          select
                           repair_seq_id,
                           ecrd_utils_pkg.G_HISTORY_RECORD,
                           component_code,
                           module_seq_id,
                           repair_description,
                           sysdate,
                           sysdate,
                           as_user_id,
                           sysdate,
                           as_user_id,
                           repair_seq_id
                           from crd_e_repair
                           where repair_seq_id = ls_rep_seq_id
                           and ( repair_end_date IS NULL  OR repair_end_date > SYSDATE );
                    EXCEPTION
                      WHEN OTHERS
                      THEN
                    	add_error('Error Inserting Crd_e_Repair_History^');
      							END;


                       update crd_e_repair
                       set repair_description = ls_rep_desc,
                           last_update_date = sysdate,
                           last_updated_by =as_user_id
                       where repair_seq_id = ls_rep_seq_id
                       and  module_seq_id = ls_mod_seq_id
                       and  component_code = ls_comp_code;

BEGIN
  insert into crd_e_repair_catalog_hist
                                   (	catalog_seq_id,
			   						               	repair_seq_id,
									                  created_by,
									                  creation_date,
										                last_update_date,
									                  last_updated_by,
									                  staging_history_ind,
									                  change_start_date,
									                  repair_price,
									                  repair_tat,
									                  approve_reject_status,
									                  future_effective_date,
									                  future_price,
									                  future_tat,
									                  incremental_price_ind,
									                  incremental_tat_ind,
                                    effective_date,
                                    repair_display_seq_id,
                                    requested_by,
                                    requested_date,
                                    price_type
                										)
                           SELECT
											catalog_seq_id,
											repair_seq_id,
											created_by,
											creation_date,
											SYSDATE,
											as_user_id,
											 ecrd_utils_pkg.G_HISTORY_RECORD,
											SYSDATE,
											repair_price,
											repair_tat,
											NULL,
											DECODE(ls_future_date,NULL,NULL,TO_DATE(ls_future_date,'MM/DD/YY HH:MI:SS')),
											future_price,
											future_tat,
											incremental_price_ind,
											incremental_tat_ind,
                      SYSDATE,
                      repair_display_seq_id,
											as_user_id,
											SYSDATE,
                      price_type
										FROM crd_e_repair_catalog
										WHERE  	catalog_seq_id = as_catalog_id
										AND repair_seq_id  = ls_rep_seq_id
										AND (repair_end_date IS NULL OR repair_end_date > SYSDATE) ;
                  EXCEPTION
                      WHEN OTHERS
                      THEN
                    	add_error('Error Inserting crd_e_repair_catalog_hist^');

      							END;

BEGIN
                       INSERT INTO crd_e_repair_catalog_hist
                                   (	catalog_seq_id,
			   						               	repair_seq_id,
									                  created_by,
									                  creation_date,
										                last_update_date,
									                  last_updated_by,
									                  staging_history_ind,
									                  change_start_date,
									                  repair_price,
									                  repair_tat,
									                  approve_reject_status,
									                  future_effective_date,
									                  future_price,
									                  future_tat,
									                  incremental_price_ind,
									                  incremental_tat_ind,
                                    effective_date,
                                    repair_display_seq_id,
                                    requested_by,
                                    requested_date,
                                    price_type
                										)
                           SELECT
											catalog_seq_id,
											repair_seq_id,
											created_by,
											creation_date,
											SYSDATE,
											as_user_id,
											ecrd_utils_pkg.G_HISTORY_RECORD,
											SYSDATE,
											repair_price,
											repair_tat,
											NULL,
											DECODE(ls_future_date,NULL,NULL,TO_DATE(ls_future_date,'MM/DD/YY HH:MI:SS')),
											future_price,
											future_tat,
											incremental_price_ind,
											incremental_tat_ind,
                      SYSDATE,
                      repair_display_seq_id,
											as_user_id,
											SYSDATE,
                      price_type
										FROM crd_e_repair_catalog
										WHERE  	catalog_seq_id = as_catalog_id
										AND repair_seq_id IN (SELECT repair_seq_id
													  				   FROM crd_e_repair
                                                      WHERE parent_repair_seq_id=ls_rep_seq_id)
										AND ( repair_end_date IS NULL or repair_end_date > SYSDATE );
            EXCEPTION
                  WHEN OTHERS
                      THEN
                    	add_error('Error Inserting crd_e_repair_catalog_hist^');
                 					END;

										update  crd_e_repair_catalog
                   set  	effective_date = sysdate,
                   LAST_UPDATE_DATE = sysdate,
                   last_updated_by = as_user_id
                   where  repair_seq_id = ls_rep_seq_id
                   AND  catalog_seq_id = as_catalog_id
                  	AND (repair_end_date IS NULL or repair_end_date > sysdate) ;

                   update  crd_e_repair_catalog
                   set  	effective_date = sysdate,
                   LAST_UPDATE_DATE = sysdate,
                   last_updated_by = as_user_id
                   where
                   catalog_seq_id = as_catalog_id
                   AND  repair_seq_id IN (SELECT repair_seq_id
										   FROM crd_e_repair
                       WHERE parent_repair_seq_id=ls_rep_seq_id
                       AND (repair_end_date IS NULL or repair_end_date > sysdate ));


          END IF;
              -- 17-05-2006 Patni Updating the repair description End


						END IF;
                  --
						IF ((ls_rep_seq_id <> 0) AND (as_is_admin <> 'Y')  )
						THEN
							BEGIN
								 IF(v_is_present > 0 AND v_is_present_for_user = 0) AND (v_n_modified	= 0)
								 THEN
                         	 IF v_b_pend_apprv_added = FALSE
                            THEN
								 	 	add_error('You Cannot Modify Repair '||ls_rep_desc ||' at Row '||ls_row_no  ||' as it is pending for approval^');
                            END IF;
								 ELSE
								  	 IF(v_is_present_for_user > 0)
									 THEN
									 	 UPDATE crd_e_repair_catalog_hist
										 SET last_update_date         = SYSDATE
                                  /*
                                  Added effective_date to be updated...10/feb/05
                                  */
                                  ,effective_date           = SYSDATE
                                  /*
                                  End Added effective_date to be updated...10/feb/05
                                  */
                                  ,repair_price             = ls_rep_price
											,repair_tat                = ls_rep_TAT
											,future_effective_date     = DECODE(ls_future_date,NULL,NULL,TO_DATE(ls_future_date,'MM/DD/YY HH:MI:SS'))
										    ,future_price             = ls_rep_Future_price
											,future_tat                = ls_rep_Future_TAT
											,incremental_price_ind     = ls_incr_price_ind
											,incremental_tat_ind       = ls_incr_tat_ind
                                 ,price_type                = ln_price_type_id
										 WHERE crd_e_repair_catalog_hist.approve_reject_status IS NULL
										 AND crd_e_repair_catalog_hist.requested_by =as_user_id
										 AND crd_e_repair_catalog_hist.staging_history_ind = ecrd_utils_pkg.G_STAGING
										 AND crd_e_repair_catalog_hist.repair_seq_id = ls_rep_seq_id
										 AND crd_e_repair_catalog_hist.catalog_seq_id = as_catalog_id   ;
                               /*
                               UPDATING FOR CHILD REPAIR ADDITION 10/feb/05
                               */
                               UPDATE  crd_e_repair_catalog_hist
                               SET last_update_date         = SYSDATE
                                  ,effective_date           = SYSDATE
                               WHERE crd_e_repair_catalog_hist.approve_reject_status IS NULL
										 AND crd_e_repair_catalog_hist.requested_by =as_user_id
										 AND crd_e_repair_catalog_hist.staging_history_ind = ecrd_utils_pkg.G_STAGING
                               AND crd_e_repair_catalog_hist.catalog_seq_id = as_catalog_id
										 AND crd_e_repair_catalog_hist.repair_seq_id IN (SELECT repair_seq_id
                               																 FROM crd_e_repair
                                                                               WHERE parent_repair_seq_id=ls_rep_seq_id);
                               /*
                               UPDATING FOR CHILD REPAIR ADDITION 10/feb/05
                               */
									 ELSE
                            	IF (v_n_modified	= 0)
                            	THEN
										/*
										*/
										INSERT INTO crd_e_repair_catalog_hist (
			   							catalog_seq_id,
			   							repair_seq_id,
										created_by,
										creation_date,
										last_update_date,
										last_updated_by,
										staging_history_ind,
										change_start_date,
										repair_price,
										repair_tat,
										approve_reject_status,
										future_effective_date,
										future_price,
										future_tat,
										incremental_price_ind,
										incremental_tat_ind,
										effective_date,
										repair_display_seq_id,
										requested_by,
										requested_date,
                    price_type
										)
										SELECT
											as_catalog_id,
											ls_rep_seq_id,
											created_by,
											creation_date,
											SYSDATE,
											as_user_id,
											ecrd_utils_pkg.G_STAGING ,
											SYSDATE,
											ls_rep_price,
											ls_rep_TAT,
											NULL,
											DECODE(ls_future_date,NULL,NULL,TO_DATE(ls_future_date,'MM/DD/YY HH:MI:SS')),
											ls_rep_Future_price,
											ls_rep_Future_TAT,
											ls_incr_price_ind,
											ls_incr_tat_ind,
                                 /*10-Feb-05
											effective_date,
                                 10-Feb-05*/
                                 SYSDATE,
                                 /*
                                 10-Feb-05
                                 */
											repair_display_seq_id,
											as_user_id,
											SYSDATE,
                                 ln_price_type_id
										FROM crd_e_repair_catalog
										WHERE  	catalog_seq_id = as_catalog_id
										AND repair_seq_id= ls_rep_seq_id
										AND repair_end_date IS NULL ;
										/*
                              10 feb 05 inserting child repairs for modification
										*/
                              INSERT INTO crd_e_repair_catalog_hist (
			   							catalog_seq_id,
			   							repair_seq_id,
										created_by,
										creation_date,
										last_update_date,
										last_updated_by,
										staging_history_ind,
										change_start_date,
										approve_reject_status,
										effective_date,
										repair_display_seq_id,
										requested_by,
										requested_date
                              )
										SELECT
											as_catalog_id,
											repair_seq_id,
											created_by,
											creation_date,
											SYSDATE,
											as_user_id,
											ecrd_utils_pkg.G_STAGING ,
											SYSDATE,
                                 NULL,
											/*10-Feb-05
											effective_date,
                                 10-Feb-05*/
                                 SYSDATE,
                                 /*
                                 10-Feb-05
                                 */
											repair_display_seq_id,
											as_user_id,
											SYSDATE
										FROM crd_e_repair_catalog
										WHERE  	catalog_seq_id = as_catalog_id
										AND repair_seq_id IN (SELECT repair_seq_id
													  				   FROM crd_e_repair
                                                      WHERE parent_repair_seq_id=ls_rep_seq_id)
										AND repair_end_date IS NULL ;
                              /*
                              10 feb 05
										*/
                             END IF;--for else if
									 END IF;
								 END IF;

								EXCEPTION
								WHEN OTHERS
								THEN
									add_error('Error Updating Repair History for Repair '||ls_rep_desc|| ' on row number ' || ls_row_no || '^');
								END;
								--
						ELSE
                  IF(v_is_present > 0) AND (v_n_modified	= 0)
                  THEN
                  	add_error('You Cannot Modify Repair '||ls_rep_desc ||' at Row '||ls_row_no  ||' as it is pending for approval^');
                  ELSE
							/*
							IF ADMIN USER
							THEN ENTER IN HISTORY
							*/
							IF (ls_rep_seq_id <> 0)AND (v_n_modified	= 0)
							THEN
							BEGIN
								ecrd_repair_pkg.ecrd_ins_repcat_hist_prc(ls_rep_seq_id
							  						  , as_catalog_id
							  						   ,as_user_id
							  						   );
							EXCEPTION
									WHEN OTHERS
									THEN
										    RAISE_APPLICATION_ERROR(-20002,'Error in ECRD UPLAOD  '||SQLERRM||' '||SQLCODE);
                		add_error('Error Updating Repair Price History for Repair '||ls_rep_desc||' on row number ' || ls_row_no ||'^');
									END;
							END IF;
 						   --IF ((ln_rep_seq_id <> 0) AND (ls_rep_TAT IS NOT NULL) OR (ls_rep_price IS NOT NULL) AND (ln_price_type_id IS NOT NULL))
                     IF (ls_rep_seq_id <> 0) AND (v_n_modified	= 0)
							THEN
									BEGIN
										UPDATE crd_e_repair_catalog
										SET repair_TAT = ls_rep_TAT,
											repair_Price = ls_rep_price,
											future_TAT = ls_rep_Future_TAT,
											future_Price = ls_rep_Future_price,
											future_effective_date = TO_DATE(ls_future_date,'MM/DD/YYYY HH:MI:SS'),
											price_type = ln_price_type_id,
											incremental_price_ind = ls_incr_price_ind,
											incremental_tat_ind = ls_incr_tat_ind,
										  -- Start : added by milind on 21/11/2004
										  last_update_date = SYSDATE,
										  last_updated_by = as_user_id
										  -- End : added by milind on 21/11/2004
                                /*
                                10-feb-05
                                */
                                , effective_date = SYSDATE
                                /*
                                10-feb-05
                                */
										WHERE repair_seq_id = ls_rep_seq_id
										AND catalog_seq_id = as_catalog_id
										AND repair_end_date IS NULL ;
                              /*
                              10-feb-05
                              */


                              UPDATE crd_e_repair_catalog
										SET last_update_date = SYSDATE,
										    last_updated_by = as_user_id
                                 ,effective_date = SYSDATE
                              WHERE catalog_seq_id = as_catalog_id
                              AND 	repair_seq_id IN (SELECT repair_seq_id
													  				   FROM crd_e_repair
                                                      WHERE parent_repair_seq_id=ls_rep_seq_id)
										AND repair_end_date IS NULL ;
                              /*
                              10-feb-05
                              */
									EXCEPTION
									WHEN OTHERS
									THEN
										add_error('Error Updating for Repair '||ls_rep_desc|| ' on row number ' || ls_row_no || '^');
									END;
							--
							END IF;
						END IF;
                 END IF;
					END IF;
				ELSE
					add_error('Error in Row Number '|| ls_row_no || ' Repair description is not found^');
				END IF; --- Repair Description Checking if ending here

			 END IF; -- added by milind 26/11/2004 v_comp_hist_count  if ending here
			END IF; -- ln_temp if condition ending here
		END LOOP;-- While loop ending here

	END IF; -- Array data if ending here
	END LOOP; -- For loop ending here

/* Patni 23-Aug-2006 - Commented the below code - Begin */
--END IF; ---Main If loop ls_mod_seq_id condition checking
/* Patni 23-Aug-2006 - Commented the below code - End */

COMMIT;

EXCEPTION
WHEN OTHERS
THEN
add_error('Error in uploading of data^');
END ecrd_upload_data_prc;
--
END ecrd_upload_pkg;
/
