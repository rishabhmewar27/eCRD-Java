create or replace package loaddata as
procedure loadlocdata(loc_id varchar2);
FUNCTION ecrd_file_write_fnc 
	(L_FILENAME IN VARCHAR2,
         L_FILEDATA IN VARCHAR2)
	RETURN NUMBER;	
end loaddata;
/

create or replace package body loaddata as
v_di_filedir		VARCHAR2(100) ;


procedure loadlocdata(loc_id varchar2) is

cursor c1 is
select 
  rpad(nvl(substr(CATALOG_SEQ_ID,0,9),' '),9,' ')||''||
  rpad(nvl(substr(CONTRACT_NUMBER,0,9),' '),9,' ')||''||
  rpad(nvl(substr(CONTRACT_DESCRIPTION,0,100),' '),100,' ')||''||
  rpad(nvl(substr(AR_ORACLE_USER,0,30),' '),30,' ')||''||
  T1.ENG_MDL_NUMBER||''||
  rpad(nvl(substr(T1.CATALOG_NUMBER,0,25),' '),25,' ')||''||
  rpad(nvl(substr(T1.CATALOG_DESCRIPTION,0,50),' '),50,' ')||''||
  rpad(NVL(to_char(T1.CATALOG_EFFECTIVE_DATE,'dd-mon-yyyy'),' '),11,' ')||''||
  rpad(NVL(to_char(T1.CATALOG_END_DATE,'dd-mon-yyyy'),' '),11,' ')||''||
  rpad(NVL(T1.COMPONENT_CODE,' '),4,' ')||''||
  rpad(NVL(T1.COMPONENT_DOC_REF,' '),20,' ')||''||
  rpad(NVL(to_char(T1.BASELINE_TAT),' '),5,' ')||''||
  rpad(NVL(to_char(T1.WRKSCP_DISP_SEQ_ID),' '),3,' ')||''||
  rpad(NVL(to_char(T1.PRICE_EFFECTIVE_DATE,'dd-mon-yyyy'),' '),11,' ')||''||
  rpad(NVL(T1.OSB_UNIQUE_NUMBER,' '),15,' ')||''||
  rpad(NVL(to_char(T1.RPR_END_DATE,'dd-mon-yyyy'),' '),11,' ')||''||
  rpad(NVL(to_char(T1.TAT_INCREMENT_IND),' '),1,' ')||''||
  rpad(NVL(to_char(T1.RPR_TAT),' '),5,' ')||''||
  rpad(NVL(T1.PRICE_INCREMENT_IND,' '),1,' ')||''||
  rpad(NVL(to_char(T1.RPR_PRICE),' '),14,' ')||''||
  rpad(NVL(T1.PRICE_QUOTE_IND,' '),1,' ')||''|| 
  rpad(NVL(to_char(T1.RPR_DISP_SEQ_ID),' '),3,' ')||''|| 
  rpad(NVL(T1.RPR_DOC_REF,' '),15,' ')||''||
  rpad(NVL(T1.RPR_REF_SNUM,' '),8,' ')||''||
  rpad(NVL(substr(T1.RPR_DESC,0,255),' '),255,' ')||''||
  rpad(NVL(substr(T1.REPAIR_SEQ_ID,0,9),' '),9,' ')||''||
  'N' data
  from  CRD_E_OSB_REPAIR_STG T1,
	CRD_E_OSB_JOBS    T2
where T1.LOCATION_ID=loc_id
and T2.LOCATION_ID=T1.LOCATION_ID
  order by OSB_INFC_RPR_SEQ_ID;
  
  
  ECRD_FileHandle 	UTL_FILE.FILE_TYPE;
	v_return_number		NUMBER;
	v_log_filename		VARCHAR2(100) := 'CRCREPAIRS.'||loc_id;
	v_global_name		VARCHAR2(100);
	v_getline varchar2(4000);
  
  begin
  
  
  
  	BEGIN
  		SELECT GLOBAL_NAME 
  		INTO   v_global_name
  		FROM GLOBAL_NAME;
  
  		IF v_global_name = 'UX4D' THEN -- Local Environment
  			v_di_filedir := '/oracle/app/oracle/admin/ux4d/utl_file';
  		ELSIF v_global_name = 'EVNLABL2.AE.GE.COM' THEN -- Lab Environment
  			v_di_filedir := 'ECRD';
  		ELSIF v_global_name = 'EVNODSQ1.WORLD' THEN -- QA Environment
  			v_di_filedir := '/evnodsq1/dbdata/utl';
  		ELSIF v_global_name = 'EVNODSP1.WORLD' THEN -- QA Environment
  			v_di_filedir := '/evnodsp1/dbdata/utl';	
  		END IF;
  			
  	EXCEPTION
  		WHEN OTHERS THEN
  			dbms_output.put_line('Cannot Select Global Name  : ' || substr(sqlerrm,1,150));
  	END;
  	
  	
  	BEGIN
			-- To delete the contents of the file.Will be removed afterwards
			ECRD_FileHandle := UTL_FILE.FOPEN(v_di_filedir,v_log_filename,'w');
			UTL_FILE.FCLOSE(ECRD_FileHandle);
	EXCEPTION
			WHEN OTHERS THEN
				dbms_output.put_line('Warning : Cannot Write to file Reason : ' || substr(sqlerrm,1,150));
			
			
	END;		

--v_return_number := ecrd_file_write_fnc(v_log_filename,'Log file for :'|| to_char(sysdate, 'DD/MM/YYYY hh24:mi:ss'));

for c1recs in c1 loop

 v_return_number := ecrd_file_write_fnc(v_log_filename,c1recs.data);

end loop;
    
  
  end;
  
FUNCTION

ecrd_file_write_fnc (L_FILENAME IN VARCHAR2,
		     L_FILEDATA IN VARCHAR2
	   	    )

RETURN NUMBER

/*
********************************************************************
* System     :  eCRD
*
* Purpose    :  to write the data to filename specified.
*
* Description:  FILENAME and FILEDATA are parameters passed to this
*		function. FILENAME is opened in APPEND mode and the
*		FILEDATA is written to opened file using PUTLINE.
*		this function will return 1 if sucessfull else -1.
*
*
* Created by :   Patni
********************************************************************
*/

IS

ecrd_FileHandle 	UTL_FILE.FILE_TYPE;
L_FILEPATH		VARCHAR2(50);
L_SUCESS		NUMBER;

BEGIN

	L_FILEPATH :=  v_di_filedir;

	 begin

		 ecrd_FileHandle := UTL_FILE.FOPEN(L_FILEPATH,L_FILENAME,'a');
		 if UTL_FILE.IS_OPEN(ecrd_FileHandle) then
			  UTL_FILE.PUT_LINE(ecrd_FileHandle, L_FILEDATA);
			  UTL_FILE.FCLOSE(ecrd_FileHandle);
			  L_SUCESS := 1;
		 end if;

		EXCEPTION
		WHEN UTL_FILE.INVALID_PATH THEN
			L_SUCESS := -1;

		WHEN UTL_FILE.INVALID_MODE THEN
			L_SUCESS := -1;

		WHEN UTL_FILE.INVALID_OPERATION THEN
			L_SUCESS := -1;

		WHEN UTL_FILE.INVALID_FILEHANDLE THEN
			L_SUCESS := -1;

		WHEN UTL_FILE.WRITE_ERROR THEN
			L_SUCESS := -1;

		WHEN UTL_FILE.INTERNAL_ERROR THEN
			L_SUCESS := -1;

		WHEN OTHERS THEN
			L_SUCESS := -1;

	end;
	RETURN(L_SUCESS);
END ecrd_file_write_fnc;

END loaddata;
/
SHOW ERRORS
/


