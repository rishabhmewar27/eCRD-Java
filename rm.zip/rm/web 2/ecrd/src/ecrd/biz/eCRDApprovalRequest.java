/*
* Module    	    : eCRDBusinessBean.java
* Author      	    : PATNI-Offshore
* Project	        : eCRD
* Date Written		: October 2004
* Security	        : Unclassified
* Restrictions		: GE PROPRIETARY INFORMATION, FOR GE USE ONLY
*
*     ****************************************************
*     *  Copyright (2000) with all rights reserved       *
*     *          General Electric Company                *
*     ****************************************************
*
* Description: eCRDBusinessBean is used for getting the GEAE Row Cache Tag
*
* Revision Log  (mm/dd/yy initials description)
* --------------------------------------------------------------
*/

package ecrd.biz;
import ecrd.util.eCRDUtil;
import geae.messaging.GEAEMailMessageException;

/**
 * This abstract class is a superclass for all 3 types of Approval Request namely
 * Component/Repair & Sites.
 * It also has accessor and mutator methods to hold the TC and Approver Details. 
 * It interacts with the Database to approve or reject TC changes. 
 * It also has method to send Notification to TC's on account of Approval or Rejects
 * 
 */
public abstract class eCRDApprovalRequest
{
	private String strRequestedBy = null;
	private String dtRequestDate = null;
	private String strRequestorSite = null;
	private String strApprovedBy = null;
	private String dtApprovedDate = null;
	private String strRejectionComments = null;
	private String strRequestorMailId = null;
	private String strRequestorSiteCd = null; 
	/**
	 * Intent of the approval. Is it for newly added component/ repair or for modified 
	 * component/repair.
	 * New = N
	 * Modified =M
	 */
	private String strChgType = "N";
	/**
	 * Dispalys status of the Approval request. Status could be Pending, 
	 * Approved,Rejected
	 */
	private String strRquestStatus;
	/**
	 * Indicates which type of approval this is, 'Component Approval', 'Repair 
	 * Approval' and 'Site Approval'.Use codes like 'C' for Component, 'R' for repair 
	 * and 'S' or site approval.
	 */
	private String strApprovalType;

	/**
	 * This is an abstract method which will be implemented in the 
	 * subclasses for the diferent types of Approval Requests.
	 */
	public abstract String approve() throws Exception;

	/**
	 * This is an abstract method which will be implemented in the classes 
	 * in the subclasses for the different types of Approval Requests,
	 */
	public abstract String reject() throws Exception;
	/**
		   * This method is called after an Approval Request has been Rejected.
		   * This method will permanently delete the TC Changes from Database.
		   */
	public void removeApprovalRequest(String approvalRequestId)
	
	{

	}
	/**
	 * Gets the Requestor Name
	 * @return String
	 */
	public String getRequestedBy()
	{
		return this.strRequestedBy;
	}

	/**
	 * Gets the Requested Date
	 * @return Calendar
	 */
	public String getRequestDate()
	{
		return this.dtRequestDate;
	}

	/**
	 * Gets the Requestor Site
	 * @return String
	 */
	public String getRequestorSite()
	{
		return this.strRequestorSite;
	}

	/**
	 * Gets the Approver Name
	 * @return String
	 */
	public String getApprovedBy()
	{
		return this.strApprovedBy;
	}

	/**
	 * Gets the Date for which Component/Repair or Site was approved
	 * @return Calendar
	 */
	public String getApprovedDate()
	{
		return this.dtApprovedDate;
	}

	/**
	 * Gets the change type whether it is New or Modified
	 * @return String
	 */
	public String getChgType()
	{
		return this.strChgType;
	}

	/**
	 * Gets the status of the Request
	 * @return String
	 */
	public String getRequestStatus()
	{
		return this.strRquestStatus;
	}

	/**
	 * Sets the Requestor Name
	 * @param strRequestedBy
	 */
	public void setRequestedBy(String strRequestedBy)
	{
		this.strRequestedBy = strRequestedBy;
	}

	/**
	 * Sets the Date for which the request has been made
	 * @param dtRequestDate
	 */
	public void setRequestDate(String dtRequestDate)
	{
		this.dtRequestDate = dtRequestDate;
	}

	/**
	 * Sets the Requestor Site who made the Request
	 * @param strSite
	 */
	public void setRequestorSite(String strRequestorSite)
	{
		this.strRequestorSite = strRequestorSite;
	}

	/**
	 * Sets the Approver Name who approved/Rejected Component/Repair/Site Changes.
	 * @param strApprovedBy
	 */
	public void setApprovedBy(String strApprovedBy)
	{
		this.strApprovedBy = strApprovedBy;
	}

	/**
	 * Sets the Date for which approver approved/rejected Component/Repair/Site Changes
	 * @param dtApprovedDate
	 */
	public void setApprovedDate(String dtApprovedDate)
	{
		this.dtApprovedDate = dtApprovedDate;
	}

	/**
	 * Sets the change typw whether it is New or Modified.
	 * @param strChgType
	 */
	public void setChgType(String strChgType)
	{
		this.strChgType = strChgType;
	}

	/**
	 * Sets the status of the Request for the approver.
	 * @param strRequestStatus
	 */
	public void setRequestStatus(String strRequestStatus)
	{
		this.strRquestStatus = strRequestStatus;
	}

	/**
	 * Sets the Approval Type wehther it is Component/Repair or Site
	 * @param strApprovalType
	 */
	public void setApprovalType(String strApprovalType)
	{
		this.strApprovalType = strApprovalType;
	}

	public void sendNotification() throws GEAEMailMessageException, Exception
	{
	}

	/**
	 * @return
	 */
	public String getRejectionComments()
	{
		return strRejectionComments;
	}

	/**
	 * @param string
	 */
	public void setRejectionComments(String strComts)
	{
		strRejectionComments = eCRDUtil.replaceString(strComts, "\r\n", " ");
	}
	/**
	 *@param string
	 */
	public void setRequestorMailId(String strMailId)
	{
		strRequestorMailId = strMailId;
	}

	public String getRequestorMailId()
	{
		return strRequestorMailId;
	}

	/**
	 * @return
	 */
	public String getRequestorSiteCd()
	{
		return strRequestorSiteCd;
	}

	/**
	 * @param string
	 */
	public void setRequestorSiteCd(String strRequestorSiteCd)
	{
		this.strRequestorSiteCd = strRequestorSiteCd;
	}

}
