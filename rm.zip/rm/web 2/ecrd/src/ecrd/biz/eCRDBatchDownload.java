



/*
 *  Project     :   eCRD
 *  Program     :   eCRDBatchDownload.java
 *  Author      :   Patni Team
 *  Date        :   October 2004
 *  Security    :   Classified/Unclassified
 *  Restrictions:   GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 *
 *  ****************************************************
 *  *  Copyright(Year) with all rights reserved        *
 *  *          General Electric Company                *
 *  ****************************************************
 *  Description:   This class will download the excel sheet.
 *
 *
 *
 *  Revision Log  (mm/dd/yy initials description)
 *  --------------------------------------------------------
 *  Patni Team    October 07, 2004  sCreated
 *  Patni Team    May 02, 2006      Modified generateEngRevReport
 *  Patni Team    August 21, 2006   Modified generateXLSSheet
 */
package ecrd.biz;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.StringTokenizer;
import java.util.Iterator;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import ecrd.common.eCRDDBMediator;
import ecrd.common.eCRDStyleObjects;
import ecrd.exception.eCRDException;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDUtil;
import geae.dao.GEAECallableStatement;
import geae.dao.GEAEResultSet;
import geae.office.GEAEOfficeException;
import geae.office.spreadsheet.GEAECell;
import geae.office.spreadsheet.GEAERow;
import geae.office.spreadsheet.GEAESheet;
import geae.office.spreadsheet.GEAEWorkbookFactory;
import geae.office.spreadsheet.excel.GEAEExcelCell;
import geae.office.spreadsheet.excel.GEAEExcelCellStyle;
import geae.office.spreadsheet.excel.GEAEExcelConstants;
import geae.office.spreadsheet.excel.GEAEExcelDataFormat;
import geae.office.spreadsheet.excel.GEAEExcelFont;
import geae.office.spreadsheet.excel.GEAEExcelRow;
import geae.office.spreadsheet.excel.GEAEExcelSheet;
import geae.office.spreadsheet.excel.GEAEExcelSheetRegion;
import geae.office.spreadsheet.excel.GEAEExcelWorkbook;

/**
 * The <code>eCRDBatchDownload</code> class represents the business object
 * This class will have the logic of getting the values from the database and
 * put these values to the cells of the excel sheet.
 * The formatting of the excel sheet, alignments, fonts is taken care by this class
 * @author  Patni Team
 * @version 1.0, 10/10/2004
 * @see
 * @see
 * @since   JDK1.0
 */
public class eCRDBatchDownload
{

    //this is database mediation object
    private eCRDDBMediator objECRDDBMediator = null;
    //row index in the excel sheet.
    private int intRowIndex = 0;
    //initialize the GEAE Excel workbook.
    private GEAEExcelWorkbook workBook;
    //initialising the excel sheet for details sheet.
    private GEAEExcelSheet sheetDetails = null;
    //initialising the excel row.
    private GEAEExcelRow excelRow = null;
    //initialising the excel cell
    private GEAEExcelCell excelCell = null;
    //initialising the excel cell style object
    private GEAEExcelCellStyle style = null;
    //initialising the excel font object
    private GEAEExcelFont font = null;
    //action id variable.
    private String strActionId = "";
    //initialising the session variable
    private HttpSession session = null;

    //declaring all style sheet objects.
    private GEAEExcelCellStyle styleObj9NormalLeft = null;
    private GEAEExcelCellStyle styleObj9NormalRight = null;
    private GEAEExcelCellStyle styleObj9BoldRight = null;
    private GEAEExcelCellStyle styleObj9NormalRightNum = null;
    private GEAEExcelCellStyle styleObj9BoldRightNum = null;
    private GEAEExcelCellStyle styleObj10BoldLeft = null;
    private GEAEExcelCellStyle styleObj9BoldLeft = null;
    private GEAEExcelCellStyle styleObj10BoldRight = null;
    private GEAEExcelCellStyle styleObj9NormalRightPer = null;
    private GEAEExcelCellStyle styleObj9NormalRightCur = null;
    private GEAEExcelCellStyle styleObj9BoldRightPer = null;
    private GEAEExcelCellStyle styleObj9BoldRightCur = null;
    private GEAEExcelCellStyle styleObj9NormalRightNumAbs = null;
    private GEAEExcelCellStyle styleObj9BoldRightNumAbs = null;
    private GEAEExcelCellStyle styleObj9NormalLeftNumAbs = null;
    private GEAEExcelCellStyle styleObj9NormalLeftNum = null;
    private GEAEExcelCellStyle styleObj9NormalLeftCur = null;
    private GEAEExcelCellStyle styleObj9NormalLeftPer = null;
    private GEAEExcelCellStyle styleObjBottomBackBlack = null;
    private GEAEExcelCellStyle styleObjBottomBackBlackDesc = null;
    private GEAEExcelCellStyle styleObjBottomBorderBlack = null;

    private GEAEExcelFont fontBoldGESerif9 = null;
    private GEAEExcelFont objNormalFontGESerif8;
    private GEAEExcelFont objBoldFontGESerif10;
    private GEAEExcelFont objBoldFontGESerif8;
    private GEAEExcelFont objNormalFontGESerif11;
    private GEAEExcelFont objBoldFontGESerif11;
    private GEAEExcelFont objNormalFontGESerif16;
    private GEAEExcelFont objNormalFontGESerif12;

    private GEAEExcelCellStyle styleObjNormalGESerif12 = null;
    private GEAEExcelCellStyle styleObjNormalGESerif8 = null;
    private GEAEExcelCellStyle styleObjBoldGESerif10 = null;
    private GEAEExcelCellStyle styleObjBoldGESerif8 = null;
    private GEAEExcelCellStyle styleObjNormalGESerif11 = null;
    private GEAEExcelCellStyle styleObjBoldGESerif11 = null;
    private GEAEExcelCellStyle styleObjNormalGESerif16 = null;
    /**
     *This is a constructor.
     *This will initialise the database bean object.
     */
    public eCRDBatchDownload()
    {
    } //end of the constructor eCRDBatchDownload

    public GEAEExcelWorkbook generateFlatFileXLSSheet(GEAEResultSet rsCatalogueDetails,String futureEffectiveDate,String strEngineModel) throws Exception
    {
        eCRDDefaultCatalog objeCRDDefaultCatalog = null;
        eCRDCustomerCatalog objeCRDCustomerCatalog = null ;
        eCRDEngineModel objeCRDEngineModel = null;
        eCRDException objeCRDException = null;
        eCRDCatalog objCRDCatalog = null;
        int intColumnIndex = 0;
        int intColumnCount = 0;


        String strCatalogId = "";
        String strSite = "";
        String strClass = "";

        String strCatTpye = "";



        String strEngineModelDesc = "";

        intRowIndex = 0;


        try
        {

           workBook = (GEAEExcelWorkbook) GEAEWorkbookFactory.getWorkbook(0);
            if (rsCatalogueDetails == null || rsCatalogueDetails.size() == 0)
            {
                return workBook;
            }

            intRowIndex = 1;
            intColumnIndex = 0;
            GEAERow row;
            GEAECell cell;
            GEAEExcelFont fontObj = null;
            GEAEExcelCellStyle styleObj = null;

            intColumnCount = rsCatalogueDetails.getColumnCount();
//        19-05-2006 patni checking null value Begin
             if (rsCatalogueDetails != null)
             {
//        19-05-2006 patni checking null value End

            /* Patni 21-Aug-2006 - Setting Sheet Name to the selected Engine Model Description - Begin */
            	   sheetDetails = (GEAEExcelSheet) workBook.createSheet(strEngineModel);
            //sheetDetails = (GEAEExcelSheet) workBook.createSheet(strEngineModelDesc);
            intRowIndex = 0;
            row = null;
            row = sheetDetails.createRow((short) intRowIndex);

            fontObj = eCRDStyleObjects.getBoldFontArial10(workBook);
            styleObj = eCRDStyleObjects.getLeftAlignStyleObject(workBook);

            styleObj.setFont(fontObj);
            styleObj.setWrapText(true);

            for (intColumnIndex = 0; intColumnIndex <= intColumnCount - 1; intColumnIndex++)
            {
                cell = row.createCell((short) intColumnIndex);
                excelCell = (GEAEExcelCell) cell;
                excelCell.setCellStyle(styleObj);

                if(intColumnIndex == 18)
                {
                    excelCell.setCellValue("Cost Updation Required");
                }
                else
                {
                    excelCell.setCellValue(rsCatalogueDetails.getColumnHeading(intColumnIndex + 1));
                }
            }
            sheetDetails.setDefaultColumnWidth((short) 15);

            fontObj = eCRDStyleObjects.getNormalFontArial10(workBook);
            styleObj = eCRDStyleObjects.getLeftAlignStyleObject(workBook);

            styleObj.setFont(fontObj);
            styleObj.setWrapText(true);
            /* Patni 21-Aug-2006 - Setting Sheet Name to the selected Engine Model Description - End */

            while (rsCatalogueDetails.next())
            {
                intRowIndex++;
                row = null;
                row = sheetDetails.createRow((short) intRowIndex);


                /* Patni 21-Aug-2006 - Changing the Column Index value as Module will be added as the first column - Begin */
                //for (intColumnIndex = 0; intColumnIndex <= intColumnCount - 2; intColumnIndex++)
                for (intColumnIndex = 0; intColumnIndex <= intColumnCount - 1; intColumnIndex++)
                /* Patni 21-Aug-2006 - Changing the Column Index value as Module will be added as the first column - End */
                {
                    cell = row.createCell((short) intColumnIndex);
                    excelCell = (GEAEExcelCell) cell;
                    excelCell.setCellStyle(styleObj);

                    /* Patni 21-Aug-2006 - Changing the Column Index value as Module will be added as the first column - Begin */
                    //excelCell.setCellValue(rsCatalogueDetails.getString(intColumnIndex + 2));

                    if(rsCatalogueDetails.getColumnHeading(intColumnIndex+1).equalsIgnoreCase("Future Effective date"))
                    {
                    	excelCell.setCellValue(futureEffectiveDate);
                    }
                    else
                    	excelCell.setCellValue(rsCatalogueDetails.getString(intColumnIndex + 1));

                    /* Patni 21-Aug-2006 - Changing the Column Index value as Module will be added as the first column - End */
                }
            }
//          19-05-2006 patni checking null value Begin
             } // end if
//           19-05-2006 patni checking null value End
            instantiateStyleObjects();
            return workBook;
        }
        catch (Exception objExp)
        {
            objExp.printStackTrace();
            throw new Exception("eCRDBatchDownload.generateFlatFileXLSSheet::::::" + objExp.getMessage());
        }
    }


    /**
     * Method name: generateXLSSheet
     * Brief logic:  This is the main method. This is being called from the service method
     * This method will actually get the result set from the database and pass the result set
     * of each forecast number with revision to the getXLSDataSheet method.
     * @author  10/10/2004
     * @version 1.0
     * @param   request (HttpServletRequest)
     * @return
     * @since   JDK1.0
     */
    public GEAEExcelWorkbook generateXLSSheet(HttpServletRequest request) throws Exception
    {
        eCRDDefaultCatalog objeCRDDefaultCatalog = null;
        eCRDCustomerCatalog objeCRDCustomerCatalog = null ;
        eCRDEngineModel objeCRDEngineModel = null;
        eCRDException objeCRDException = null;
        eCRDCatalog objCRDCatalog = null;
        int intColumnIndex = 0;
        int intColumnCount = 0;

        /* Patni 21-Aug-2006 - Commented the below code - Begin */
        //String strPrevModule = "";
        /* Patni 21-Aug-2006 - Commented the below code - End */

        String strEngineModel = "";
        String strCatalogId = "";
        String strSite = "";
        String strClass = "";
    //19-05-2006 Patni added to collect the catalog type Begin
        String strCatTpye = "";
//      19-05-2006 Patni added to collect the catalog type End

        /* Patni 21-Aug-2006 - Declare variable to hold the value of Engine Model Description - Begin */
        String strEngineModelDesc = "";
        /* Patni 21-Aug-2006 - Declare variable to hold the value of Engine Model Description - End */

        ArrayList arrInParam = null;
        ArrayList arrOutParam = null;
        GEAEResultSet rsCatalogueDetails = new GEAEResultSet();
        arrInParam = new ArrayList();
        arrOutParam = new ArrayList();

        intRowIndex = 0;

        session = request.getSession();
        strSite = request.getParameter("hdnSite");
        strClass = request.getParameter("hdnClass");

        strActionId = eCRDConstants.getActionId("eCRD_BATCH_DOWNLOAD");


        try
        {

       // 19-05-2006 Patni Checking the catalog type Begin
            objCRDCatalog = (eCRDCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);

            strCatTpye = objCRDCatalog.getCatalogType();

            if("D".equals(strCatTpye))
            {
                objeCRDDefaultCatalog =(eCRDDefaultCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
            }
            else
            {
                objeCRDCustomerCatalog = (eCRDCustomerCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
            }

      // 19-05-2006 Patni Checking the catalog type End

        /*    if (objeCRDDefaultCatalog == null  && objeCRDCustomerCatalog == null)
            {
                objeCRDException = new eCRDException();
                objeCRDException.setExcpId("CATALOG_NOT_SET");
                throw objeCRDException;
            }*/

            if (objeCRDDefaultCatalog !=null)
            {
             objeCRDEngineModel = objeCRDDefaultCatalog.getEngineModel();
             strCatalogId = objeCRDDefaultCatalog.getCatalogSeqId();
            }
            else
            {
                objeCRDEngineModel = objeCRDCustomerCatalog.getEngineModel();
                 strCatalogId = objeCRDCustomerCatalog.getCatalogSeqId();
            }

            if (objeCRDEngineModel == null)
            {
                objeCRDException = new eCRDException();
                objeCRDException.setExcpId("ENGINE_MODEL_NULL");
                throw objeCRDException;
            }
            strEngineModel = objeCRDEngineModel.getEngineModelCode();

            /* Patni 21-Aug-2006 - To get the Engine Model Description of the selected Engine Model - Begin */
            strEngineModelDesc = objeCRDEngineModel.getEngineModelDesc();
            /* Patni 21-Aug-2006 - To get the Engine Model Description of the selected Engine Model - Begin */

            arrInParam.add(strEngineModel);
            arrInParam.add(strCatalogId);
            arrInParam.add(strClass);
            arrInParam.add(strSite);

            arrOutParam = eCRDDBMediator.doDBOperation(strActionId, arrInParam);

            rsCatalogueDetails = (GEAEResultSet) arrOutParam.get(0);

            workBook = (GEAEExcelWorkbook) GEAEWorkbookFactory.getWorkbook(0);
            if (rsCatalogueDetails == null || rsCatalogueDetails.size() == 0)
            {
                return workBook;
            }

            intRowIndex = 1;
            intColumnIndex = 0;
            GEAERow row;
            GEAECell cell;
            GEAEExcelFont fontObj = null;
            GEAEExcelCellStyle styleObj = null;

            intColumnCount = rsCatalogueDetails.getColumnCount();
//        19-05-2006 patni checking null value Begin
             if (rsCatalogueDetails != null)
             {
//        19-05-2006 patni checking null value End

            /* Patni 21-Aug-2006 - Setting Sheet Name to the selected Engine Model Description - Begin */
            sheetDetails = (GEAEExcelSheet) workBook.createSheet(strEngineModelDesc);
            intRowIndex = 0;
            row = null;
            row = sheetDetails.createRow((short) intRowIndex);

            fontObj = eCRDStyleObjects.getBoldFontArial10(workBook);
            styleObj = eCRDStyleObjects.getLeftAlignStyleObject(workBook);

            styleObj.setFont(fontObj);
            styleObj.setWrapText(true);

            for (intColumnIndex = 0; intColumnIndex <= intColumnCount - 1; intColumnIndex++)
            {
                cell = row.createCell((short) intColumnIndex);
                excelCell = (GEAEExcelCell) cell;
                excelCell.setCellStyle(styleObj);

                if(intColumnIndex == 18)
                {
                    excelCell.setCellValue("Cost Updation Required");
                }
                else
                {
                    excelCell.setCellValue(rsCatalogueDetails.getColumnHeading(intColumnIndex + 1));
                }
            }
            sheetDetails.setDefaultColumnWidth((short) 15);

            fontObj = eCRDStyleObjects.getNormalFontArial10(workBook);
            styleObj = eCRDStyleObjects.getLeftAlignStyleObject(workBook);

            styleObj.setFont(fontObj);
            styleObj.setWrapText(true);
            /* Patni 21-Aug-2006 - Setting Sheet Name to the selected Engine Model Description - End */

            while (rsCatalogueDetails.next())
            {
                /* Patni 21-Aug-2006 - Commented the below code - Begin */
                /*
                String strModule = rsCatalogueDetails.getString(1);
                if (!(strPrevModule.equals(strModule)))
                {
                    sheetDetails = (GEAEExcelSheet) workBook.createSheet(strModule);
                    intRowIndex = 0;
                    row = null;
                    row = sheetDetails.createRow((short) intRowIndex);

                    fontObj = eCRDStyleObjects.getBoldFontArial10(workBook);
                    styleObj = eCRDStyleObjects.getLeftAlignStyleObject(workBook);

                    styleObj.setFont(fontObj);
                    styleObj.setWrapText(true);

                    for (intColumnIndex = 0; intColumnIndex <= intColumnCount - 2; intColumnIndex++)
                    {

                        cell = row.createCell((short) intColumnIndex);
                        excelCell = (GEAEExcelCell) cell;
                        excelCell.setCellStyle(styleObj);

                    // 06-07-2006 Patni Adding modify cost coulmn in excel sheet Begin
                        if(intColumnIndex == 17)
                        {
                            excelCell.setCellValue("Cost Updation Required");
                        }
                        else
                        {
                            excelCell.setCellValue(rsCatalogueDetails.getColumnHeading(intColumnIndex + 2));
                        }
//                      06-07-2006 Patni Adding modify cost coulmn in excel sheet End
                        //getColumnName
                    }
                    sheetDetails.setDefaultColumnWidth((short) 15);

                    fontObj = eCRDStyleObjects.getNormalFontArial10(workBook);
                    styleObj = eCRDStyleObjects.getLeftAlignStyleObject(workBook);

                    styleObj.setFont(fontObj);
                    styleObj.setWrapText(true);
                }
                strPrevModule = strModule;
                */
                /* Patni 21-Aug-2006 - Commented the below code - End */

                intRowIndex++;
                row = null;
                row = sheetDetails.createRow((short) intRowIndex);


                /* Patni 21-Aug-2006 - Changing the Column Index value as Module will be added as the first column - Begin */
                //for (intColumnIndex = 0; intColumnIndex <= intColumnCount - 2; intColumnIndex++)
                for (intColumnIndex = 0; intColumnIndex <= intColumnCount - 1; intColumnIndex++)
                /* Patni 21-Aug-2006 - Changing the Column Index value as Module will be added as the first column - End */
                {
                    cell = row.createCell((short) intColumnIndex);
                    excelCell = (GEAEExcelCell) cell;
                    excelCell.setCellStyle(styleObj);

                    /* Patni 21-Aug-2006 - Changing the Column Index value as Module will be added as the first column - Begin */
                    //excelCell.setCellValue(rsCatalogueDetails.getString(intColumnIndex + 2));
                    excelCell.setCellValue(rsCatalogueDetails.getString(intColumnIndex + 1));
                    /* Patni 21-Aug-2006 - Changing the Column Index value as Module will be added as the first column - End */
                }
            }
//          19-05-2006 patni checking null value Begin
             } // end if
//           19-05-2006 patni checking null value End
            instantiateStyleObjects();
            return workBook;
        }
        catch (Exception objExp)
        {
            objExp.printStackTrace();
            throw new Exception("eCRDBatchDownload.generateXLSSheet::::::" + objExp.getMessage());
        }
    }


    /**
     * Method name: generateCompMappingXLSSheet
     * Brief logic:  This is the main method. This is being called from the service method
     * This method will actually get the result set from the database and pass the result set
     * of each forecast number with revision to the getXLSDataSheet method.
     * @author  13/02/2008
     * @version 1.0
     * @param   request (HttpServletRequest)
     * @return
     * @since   JDK1.4
     */
    public GEAEExcelWorkbook generateCompMappingXLSSheet(HttpServletRequest request) throws Exception
    {
    GEAERow sheet_row;
    GEAEExcelCell cell;

    GEAESheet workbook_sheet=null;
    GEAEResultSet rsetExcelData = null;

    GEAEExcelFont fontObjNormal = null;
    GEAEExcelFont fontObjBold = null;
    GEAEExcelCellStyle styleObj = null;
    GEAEExcelCellStyle styleObjBold = null;
    int intColumnCount = 0;

    int rownum = 0;
    int j = 0;
    int i = 0;
    int intSheetCount = 0;
    ArrayList arrlstInParams = null;
    ArrayList arrlstOutParams = null;
    HashMap hmdataMap = null;
    String strScreenAction = "";
    String strEngineModel  = "";
    String strEngineModelDesc = "";
    String strLocation = "";
	SimpleDateFormat formatter = null;
	Date date = null;
	String upDate = "";

    try
    {
       arrlstInParams  = new ArrayList();
       arrlstOutParams = new ArrayList();
       rsetExcelData   = new GEAEResultSet();

       strScreenAction = eCRDConstants.getActionId("eCRD_BATCH_DOWNLOAD_MAPPING");

       strEngineModel       = eCRDUtil.verifyNull(request.getParameter("hdnEngineModel"));
       strEngineModelDesc   = eCRDUtil.verifyNull(request.getParameter("hdnEngineModelDesc"));
       strLocation          = eCRDUtil.verifyNull(request.getParameter("hdnSite"));


       if(strEngineModelDesc.equalsIgnoreCase("Select.."))
    	   strEngineModelDesc = "ALL";


       arrlstInParams.add(strEngineModel);
       arrlstInParams.add(strLocation);
       arrlstOutParams = eCRDDBMediator.doDBOperation(strScreenAction, arrlstInParams);
       rsetExcelData = (GEAEResultSet) arrlstOutParams.get(0);

    // FOR EXCEL

       rsetExcelData.setColumnHeading(1,eCRDConstants.STRMODEL);
       rsetExcelData.setColumnHeading(2,eCRDConstants.STRMODULE);
       rsetExcelData.setColumnHeading(3,eCRDConstants.STRCOMCODE);
       rsetExcelData.setColumnHeading(4,eCRDConstants.STRCOMDESC);
       rsetExcelData.setColumnHeading(5,eCRDConstants.STRCSITE);
       rsetExcelData.setColumnHeading(6,eCRDConstants.STROSBCODE);
       rsetExcelData.setColumnHeading(7,eCRDConstants.STRLASTUPDATE);
       rsetExcelData.setColumnHeading(8,eCRDConstants.STRACTIVEID);

       intColumnCount = rsetExcelData.getColumnCount();

       workBook = (GEAEExcelWorkbook)GEAEWorkbookFactory.getWorkbook(0);
       fontObjBold = eCRDStyleObjects.getBoldFontArial10(workBook);
       styleObj = eCRDStyleObjects.getLeftAlignStyleObject(workBook);
       styleObjBold= eCRDStyleObjects.getLeftAlignStyleObject(workBook);
       fontObjNormal = eCRDStyleObjects.getNormalFontArial10(workBook);


        hmdataMap = new HashMap();
        formatter = new SimpleDateFormat("MM/dd/yyyy");
        date = new Date();


        if(rsetExcelData!=null && rsetExcelData.size()>0)
	    {
	        while (rsetExcelData.next())
	        {
	           // for printing the headings in the excel.
	           if (rownum%60000 == 0 || rownum == 0)
	           {

	        	   workbook_sheet = workBook.createSheet();
	               workBook.setSheetName(intSheetCount,strEngineModelDesc);
	               intSheetCount++;
	               workbook_sheet.setDefaultColumnWidth((short) 15);
	               for (j=1;j<=intColumnCount;j++)
	               {
	            	    hmdataMap.put((j-1)+"",rsetExcelData.getColumnHeading(j));
	               }
	               rownum = 0;

	               rowgeneratorMapping(rownum,intColumnCount,hmdataMap,workbook_sheet,workBook,fontObjBold,styleObjBold);
	               rownum++;
	               hmdataMap.clear();
	           }
	           // for printing the data
        	   for (j=1; j <= intColumnCount; j++)
        	   {
        		   String strColumnData = rsetExcelData.getString(j);

        		   if(j == 6) { // combination of component code, active indicator, last updated date separated by ^

	            	  //split and put hmdataMap (j-1)+1

        			   if (strColumnData != null && !"".equals(strColumnData))
	            	   {
        				   StringTokenizer strTokVal = new StringTokenizer(strColumnData,"^");

	                   		// 	Looping through tokens of last column ie, 6th column

        				   int intCtr=0;
        				   while (strTokVal.hasMoreTokens())
	                   		{
	                   			String token = strTokVal.nextToken(); // Add value to String Array
	                   			if(token == null )
	                   				token="";

	                   			hmdataMap.put(((j-1)+intCtr)+"",token);
	                   			intCtr++;
	                   		}
	                   }
        			   else
        			   {
        				   hmdataMap.put(((j-1))+"","");
        				   hmdataMap.put(((j))+"","");
        				   hmdataMap.put(((j+1))+"","");
        			   }
        			   break; // Move out of loop once the 6th element in resultset is procesed.
                   }
        		   else{
        			   hmdataMap.put((j-1)+"",rsetExcelData.getString(j));
        		   }
        	   } // End For

        	   rowgeneratorMapping(rownum,intColumnCount,hmdataMap,workbook_sheet,workBook,fontObjNormal,styleObj);
	           rownum++;
	           hmdataMap.clear();

	        }// End while
	   }
       else
       {
           //workBook =null;
           workbook_sheet = workBook.createSheet();
           workBook.setSheetName(intSheetCount,strEngineModelDesc);
           sheet_row = (GEAEExcelRow)workbook_sheet.createRow((short)0);

           //fontObj = eCRDStyleObjects.getBoldFontArial10(workBook);
           fontObjBold = eCRDStyleObjects.getBoldFontArial10(workBook);
           styleObj = eCRDStyleObjects.getLeftAlignStyleObject(workBook);
           styleObj.setFont(fontObjBold);

           styleObj.setWrapText(false);
           cell = (GEAEExcelCell)sheet_row.createCell((short)0);
           cell.setCellStyle(styleObj);
           cell.setCellValue("No Data Found for the Search Criteria");

       }

    }
    catch(IOException ioexp)
    {
        throw new Exception("eCRDExcelTrial::getExcelWorkBook" + ioexp.getMessage());
    }
    catch(GEAEOfficeException geaeoff)
    {
        throw new Exception("eCRDExcelTrial::getExcelWorkBook" + geaeoff.getMessage());
    }
    catch(Exception objExp)
    {
         throw new Exception("eCRDExcelTrial::getExcelWorkBook" + objExp.getMessage());
    }
    finally
    {
       rsetExcelData = null;
       arrlstInParams = null;
       arrlstOutParams = null;
       hmdataMap = null;
       workbook_sheet=null;
       rsetExcelData = null;
       fontObjBold = null;
       fontObjNormal = null;
       styleObj = null;
    }
    instantiateStyleObjects();
    return workBook;
}

/* END generateComponentMappingXLSSheet



    /**
    * Method name:  generateComponentXLSSheet
    * Brief logic:   This method will Genereate Excel sheet with Component details.
    * @author   Patni Team
    * @version 1.0
    * @param
    * @return
    * @since   JDK1.4
    */
    public GEAEExcelWorkbook generateComponentXLSSheet(HttpServletRequest request)
    throws Exception
    {

                 GEAERow sheet_row;
                 GEAEExcelCell cell;
                 GEAECell sheet_cell;
                 GEAESheet workbook_sheet=null;
                 GEAEResultSet rsetExcelData = null;
                 GEAECallableStatement callStatement = null;
                 GEAEExcelFont fontObj = null;
                 GEAEExcelCellStyle styleObj = null;
                 int intColumnCount = 0;
                 int rowindex = 0;
                 int rownum = 0;
                 int j = 0;
                 int intSheetCount = 0;
                 ArrayList arrlstInParams = null;
                 ArrayList arrlstOutParams = null;
                 HashMap hmdataMap = null;
                 String strScreenAction = "";
                 String strEngineModel  = "";
                 String strEngineModelDesc = "";
                 String strEngineModule = "";
                 String strComponentCode = "";
                 String strComponentDesc = "";
                 String strLocation = "";

                 try
                 {
                    arrlstInParams  = new ArrayList();
                    arrlstOutParams = new ArrayList();
                    rsetExcelData   = new GEAEResultSet();
                    strScreenAction = eCRDConstants.getActionId("eCRD_COMPONENT_DOWNLOAD");

                    strEngineModel       = eCRDUtil.verifyNull(request.getParameter("hdnEngineModel"));
                    strEngineModelDesc   = eCRDUtil.verifyNull(request.getParameter("hdnEngineModelDesc"));
                    strEngineModule      = eCRDUtil.verifyNull(request.getParameter("hdnEngineModule"));
                    strComponentCode     = eCRDUtil.verifyNull(request.getParameter("hdnComponentCode"));
                    strLocation          = eCRDUtil.verifyNull(request.getParameter("hdnCompLocation"));


                    arrlstInParams.add(strEngineModel);
                    arrlstInParams.add(strEngineModule);
                    arrlstInParams.add(strComponentDesc);
                    arrlstInParams.add(strComponentCode);
                    arrlstInParams.add(strLocation);
                    arrlstOutParams = eCRDDBMediator.doDBOperation(strScreenAction, arrlstInParams);
                    rsetExcelData = (GEAEResultSet) arrlstOutParams.get(0);


                 // FOR EXCEL

                    rsetExcelData.setColumnHeading(1,eCRDConstants.STRMODULESEQID);
                    rsetExcelData.setColumnHeading(2,eCRDConstants.STRMODULENAME);
                    rsetExcelData.setColumnHeading(3,eCRDConstants.STRCOMPCODE);
                    rsetExcelData.setColumnHeading(4,eCRDConstants.STRCOMPDESC);
                    rsetExcelData.setColumnHeading(5,eCRDConstants.STRLOCATIONID);
                    rsetExcelData.setColumnHeading(6,eCRDConstants.STRLOCATIONNAME);
                    rsetExcelData.setColumnHeading(7,eCRDConstants.STRPRIMARYSITE);
                    rsetExcelData.setColumnHeading(8,eCRDConstants.STRHIDDENSITE);
                    rsetExcelData.setColumnHeading(9,eCRDConstants.STRDELETESITE);

                    intColumnCount = rsetExcelData.getColumnCount();

                    workBook = (GEAEExcelWorkbook)GEAEWorkbookFactory.getWorkbook(0);

                     hmdataMap = new HashMap();
                    if(rsetExcelData!=null && rsetExcelData.size()>0)
                    {
                     while (rsetExcelData.next())
                     {

                        // for printing the headings in the excel.
                        if (rownum%60000 == 0 || rownum == 0)
                        {
                            workbook_sheet = workBook.createSheet();
                            workBook.setSheetName(intSheetCount,strEngineModelDesc);
                            intSheetCount++;
                            workbook_sheet.setDefaultColumnWidth((short) 15);
                            for (j=1;j<=intColumnCount;j++)
                            {
                                hmdataMap.put(new Integer(j-1),rsetExcelData.getColumnHeading(j));
                            }
                            rownum = 0;
                            rowgenerator(rownum,intColumnCount,hmdataMap,workbook_sheet,workBook);
                            rownum++;
                            hmdataMap.clear();
                        }
                        // for printing the data
                        for (j=1;j<=intColumnCount;j++)
                        {
                            hmdataMap.put(new Integer(j-1),rsetExcelData.getString(j));
                        }
                        rowgenerator(rownum,intColumnCount,hmdataMap,workbook_sheet,workBook);
                        rownum++;
                        hmdataMap.clear();
                     }
                    }
                    else
                    {
                        //workBook =null;
                        workbook_sheet = workBook.createSheet();
                        workBook.setSheetName(intSheetCount,strEngineModelDesc);
                        sheet_row = (GEAEExcelRow)workbook_sheet.createRow((short)0);

                        //fontObj = eCRDStyleObjects.getBoldFontArial10(workBook);
                        fontObj = eCRDStyleObjects.getBoldFontArial10(workBook);
                        styleObj = eCRDStyleObjects.getLeftAlignStyleObject(workBook);
                        styleObj.setFont(fontObj);

                        styleObj.setWrapText(false);
                        cell = (GEAEExcelCell)sheet_row.createCell((short)0);
                        cell.setCellStyle(styleObj);
                        cell.setCellValue("No Data Found for the Search Criteria");

                    }
                 }
                 catch(IOException ioexp)
                 {
                     throw new Exception("eCRDExcelTrial::getExcelWorkBook" + ioexp.getMessage());
                 }
                 catch(GEAEOfficeException geaeoff)
                 {
                     throw new Exception("eCRDExcelTrial::getExcelWorkBook" + geaeoff.getMessage());
                 }
                 catch(Exception objExp)
                 {
                      throw new Exception("eCRDExcelTrial::getExcelWorkBook" + objExp.getMessage());
                 }
                 finally
                 {
                    rsetExcelData = null;
                 }
                 instantiateStyleObjects();
                 return workBook;

    }
    /**
     *  <pre>
     * This method Generates the rows in that excel with the columns and the data
     * @param  rownum                         Rownumber to be populated.
     * @param  colCount                       Count of the columns in the excel.
     * @param  hmDataMap                      HashMap containing the data
     * @param  workbook_sheet                 Sheet on which the rows are to be added
     * @exception  GEAEOfficeException
     * @throws  GEAEOfficeException  </pre>
     */


    public void rowgenerator(int rownum,int colCount,HashMap hmdataMap,GEAESheet workbook_sheet,GEAEExcelWorkbook wb)
    throws GEAEOfficeException
    {
        GEAEExcelRow sheet_row;
        GEAEExcelCell sheet_cell;
        GEAECell cell;
        String strData = "";
        int i = 0;
        GEAEExcelFont fontObj = null;
        GEAEExcelCellStyle styleObj = null;


                 try
                 {
                     sheet_row = (GEAEExcelRow)workbook_sheet.createRow((short)rownum);
                     if(rownum == 0)
                     {
                         fontObj = eCRDStyleObjects.getBoldFontArial10(wb);
                         styleObj = eCRDStyleObjects.getLeftAlignStyleObject(wb);
                     }
                     else
                     {
                         fontObj = eCRDStyleObjects.getNormalFontArial10(wb);
                         styleObj = eCRDStyleObjects.getLeftAlignStyleObject(wb);
                     }

                     styleObj.setFont(fontObj);
                     styleObj.setWrapText(true);

                     for (i=0;i<colCount;i++)
                     {
                         sheet_cell = (GEAEExcelCell)sheet_row.createCell((short)i);
                         //strData = (String)hmdataMap.get(i+"");
                         strData = (String)hmdataMap.get(new Integer(i));
                         sheet_cell.setCellStyle(styleObj);
                         sheet_cell.setCellValue(strData);
                         sheet_cell = null;
                     }
                 }
                 catch(GEAEOfficeException geaeoff)
                 {
                    throw new GEAEOfficeException("eCRDExcelTrial::rowgenerator" + geaeoff.getMessage());
                 }
		 finally
		 {
			sheet_row = null;
			fontObj = null;
       		        styleObj = null;

		 }

    }


    /**
    * Method name:  instantiateStyleObjects
    * Brief logic:   This method will instantiate the style objects.
    * @author   Patni Team
    * @version 1.0
    * @param
    * @return
    * @since   JDK1.0
    */
    private void instantiateStyleObjects() throws Exception
    {
        styleObj9NormalLeft = eCRDStyleObjects.getStyleObjLeftNormal9(workBook);
        styleObj9NormalRight = eCRDStyleObjects.getStyleObjRightNormal9(workBook);
        styleObj9BoldRight = eCRDStyleObjects.getStyleObjRightBold9(workBook);
        styleObj9NormalRightNum = eCRDStyleObjects.getStyleObjRightNormal9Num(workBook);
        styleObj9BoldRightNum = eCRDStyleObjects.getStyleObjRightBold9Num(workBook);
        styleObj10BoldLeft = eCRDStyleObjects.getStyleObjLeftBold10(workBook);
        styleObj9BoldLeft = eCRDStyleObjects.getStyleObjLeftBold9(workBook);
        styleObj10BoldRight = eCRDStyleObjects.getStyleObjRightBold10(workBook);
        styleObj9NormalRightPer = eCRDStyleObjects.getStyleObjRightNormal9Per(workBook);
        styleObj9NormalRightCur = eCRDStyleObjects.getStyleObjRightNormal9Cur(workBook);
        styleObj9BoldRightPer = eCRDStyleObjects.getStyleObjRightBold9Per(workBook);
        styleObj9BoldRightCur = eCRDStyleObjects.getStyleObjRightBold9Cur(workBook);
        styleObj9NormalRightNumAbs = eCRDStyleObjects.getStyleObjRightNormal9Abs(workBook);
        styleObj9BoldRightNumAbs = eCRDStyleObjects.getStyleObjRightBold9Abs(workBook);
        styleObj9NormalLeftNumAbs = eCRDStyleObjects.getStyleObjLeftNormal9Abs(workBook);
        styleObj9NormalLeftNum = eCRDStyleObjects.getStyleObjLeftNormal9Num(workBook);
        styleObj9NormalLeftCur = eCRDStyleObjects.getStyleObjLeftNormal9Cur(workBook);
        styleObj9NormalLeftPer = eCRDStyleObjects.getStyleObjLeftNormal9Per(workBook);
    }

    private GEAEExcelWorkbook generateYearlyCatalogXLS(HttpServletRequest request) throws Exception
    {
    	
    	int count = 0 ; //rishabh
    	
        GEAEExcelWorkbook workBook;
        int intColumnIndex = 0;
        int intColumnCount = 0;
        int intColumn = 0;
        String strPrevModule = "";
        String strCatalogId = null;
        String strActionId = null;
        ArrayList arrlstInParam = null;
        GEAEResultSet rsCatalog = null;
        GEAEResultSet rsChildRepairCatalogs = null;
        ArrayList arrlstOutParam = null;
        String strEngine = null;
        String strPrevComponentCode = "";
        String strComponentCode = null;
        String strRepairComments = null;
        int intPart = 0;
        int intModules = 0;
        int intSite = 0;
        String strHeading = null;
        ArrayList arrlstParts = null;
        ArrayList arrlstSites = null;
        GEAEExcelSheetRegion region = null;
        String strYear = null;
        boolean blnFlag = false;
        //GEAEExcelFont objFont;
        GEAEExcelCellStyle styleObj = null;
        String strRepairType = null;
        String strRepairId = null;
        String strModule = null;
        String strRprEffDate= null;
        try
        {
            arrlstInParam = new ArrayList();
            arrlstOutParam = new ArrayList();

            strCatalogId = eCRDUtil.verifyNull(request.getParameter("hdnCatalogValue"));
//Start For Repair Effective Date on 08Nov2005 By Rajiv
            strRprEffDate = eCRDUtil.verifyNull(request.getParameter("hdnRprEffDate"));
//End For Repair Effective Date on 08Nov2005 By Rajiv

            strEngine = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, "Engine"));
            strActionId = eCRDConstants.getActionId("eCRD_DOWNLOAD_EXCEL");

            arrlstInParam.add(strCatalogId);
//Start For Repair Effective Date on 08Nov2005 By Rajiv
            arrlstInParam.add(strRprEffDate);
//End For Repair Effective Date on 08Nov2005 By Rajiv
            // Hitting the Database and getting the details for that Catalog.
            arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInParam);
            System.out.println("After procedure called");
            rsCatalog = (GEAEResultSet) arrlstOutParam.get(0);
            rsChildRepairCatalogs = (GEAEResultSet) arrlstOutParam.get(1);
            strYear = (String)arrlstOutParam.get(2);
            workBook = (GEAEExcelWorkbook) GEAEWorkbookFactory.getWorkbook(0);
            System.out.println("Catalog result set size");
            if (rsCatalog == null || rsCatalog.size() == 0)
            {
                return workBook;
            }
            System.out.println("Catalog result set size...");
            intRowIndex = 1;
            intColumnIndex = 0;
            GEAEExcelRow row;
            GEAECell cell;
            styleObj = workBook.createCellStyle();
            //objFont = workBook.createFont();

            intColumnCount = rsCatalog.getColumnCount();

            if(rsCatalog !=null )
            {
            while (rsCatalog.next())
            {
                strModule = rsCatalog.getString(1);
                if (!(strPrevModule.equals(strModule))) // Check to identify whetherto create a New Sheet or Not.
                {
                    intColumnIndex = 0;
                    intModules++;
            /*
             * Checking if there are any More Parts or Sites that have to be Displayed f
             * for the previous Module before creating a new Module sheet.
             */
                    if(arrlstParts != null)
                    {
                        intPart = arrlstParts.size();
                    }
                    else
                    {
                        intPart = 0;
                    }
                    if(arrlstSites != null)
                    {
                        intSite = arrlstSites.size();
                    }
                    else
                    {
                        intSite = 0;
                    }
                    if(intPart > 0 || intSite > 0)
                    {
                        //Indentifying whether there are more parts or more sites to be displayed.
                        if(intPart > intSite)
                        {
                            intColumn = intPart;
                        }
                        else
                        {
                            intColumn = intSite;
                        }
                        // Loop to display all the remaining Sites and Parts for the Previous Component
                        for(int inti = 0 ; inti < intColumn; inti++)
                        {
                            // creating new row to insert parts and site Data
                            intRowIndex++;
                            row=null;
                            row = (GEAEExcelRow)sheetDetails.createRow((short) intRowIndex);

                            //creating cell for parts data.
                            cell=null;
                            excelCell = null;
                            cell = row.createCell((short) 1);
                            excelCell = (GEAEExcelCell) cell;
                            styleObj = getStyleObjLeftNormal8GESerif(workBook);
                            styleObj.setWrapText(true);
                            excelCell.setCellStyle(styleObj);
                            intPart = arrlstParts.size();
                            if(intPart > 0)
                            {
                                // Displaying the Part Numbers.
                                excelCell.setCellValue(arrlstParts.get(intPart-1));
                                // Removing the Displayed Part Number frm the Arraylist.
                                arrlstParts.remove(intPart-1);
                            }
                            else
                            {
                                // No Value to be displayed in the cell for Part Number.
                                excelCell.setCellValue("");
                            }

                            //creating cell for Sites Data
                            cell=null;
                            excelCell = null;
                            cell = row.createCell((short) 2);
                            excelCell = (GEAEExcelCell) cell;
                            styleObj = getStyleObjLeftBold8GESerif(workBook);
                            styleObj.setWrapText(true);
                            excelCell.setCellStyle(styleObj);
                            intSite = arrlstSites.size();
                            if(intSite > 0)
                            {
                                // Displaying the Sites.
                                excelCell.setCellValue(arrlstSites.get(intSite-1));
                                // Removing the Sites frm the Site ArrayList.
                                arrlstSites.remove(intSite-1);
                            }
                            else
                            {
                                // No Value to be Dispalyed in the Cell for Sites.
                                excelCell.setCellValue("");
                            }
                        }
                    }
                    // To Insert and Empty row at the end of the Sheet.
                    if (sheetDetails != null)
                    {
                        intRowIndex++;
                        row = null;
                        row = (GEAEExcelRow) sheetDetails.createRow((short) intRowIndex);
                        setBottomBorderBack(workBook,sheetDetails, intRowIndex, intColumnCount - 8);
                    }
                    sheetDetails = (GEAEExcelSheet) workBook.createSheet(strModule);
                    intRowIndex = 0;
                    arrlstSites = null;
                    arrlstParts = null;

                    row = null;
                    row = (GEAEExcelRow) sheetDetails.createRow((short) intRowIndex);
                    row.setHeight((short) 50);
                    cell=null;
                    excelCell = null;
                    cell = row.createCell((short) intColumnIndex);
                    /*
                     * Start of Data to Be Displayed in the First Row of Every Sheet.
                     */



                    region = new GEAEExcelSheetRegion((short) intRowIndex, (short) intRowIndex, (short) 0, (short) 1);
                    ((GEAEExcelSheet) sheetDetails).addMergedRegion(region);
                    excelCell = (GEAEExcelCell) cell;
                    styleObj = getStyleObjLeftNormal12GESerif(workBook);
                    styleObj.setWrapText(true);
                    excelCell.setCellStyle(styleObj);
                    excelCell.setCellValue("GE Engine Services Inc");
                    cell=null;
                    excelCell = null;
                    /*cell = row.createCell((short) (intColumnIndex + 2));
                    //styleObj = workBook.createCellStyle();
                    //styleObj = getHiddenStyleObject(styleObj);
                    //styleObj.setWrapText(true);
                    excelCell = (GEAEExcelCell) cell;
                    excelCell.setCellStyle(styleObj);
                    excelCell.setCellValue("");*/

                    cell=null;
                    excelCell = null;
                    cell = row.createCell((short) (intColumnIndex + 2));
                    styleObj = getStyleObjLeftNormal16GESerif(workBook);
                    styleObj.setWrapText(true);
                    region = new GEAEExcelSheetRegion((short) intRowIndex, (short) intRowIndex, (short) 2, (short) 4);
                    ((GEAEExcelSheet) sheetDetails).addMergedRegion(region);
                    excelCell = (GEAEExcelCell) cell;
                    excelCell.setCellStyle(styleObj);
                    
                    
                  //beginning_rishabh_component_early_excel_tm
	  	          	   
                	System.out.println(" Check strEngine - " + strEngine);        
                	System.out.println(" Check strYear - " + strYear);  
                	
                	if ( strEngine.contains("GE Passport") && count == 0)
  	               	{   
  	            	   	count ++ ;
  	            	   	strEngine = strEngine.replace("GE Passport","GE Passport\u2122");		  	                   
  	            	   	excelCell.setCellValue(strEngine + "\n" + strYear + " Component Repair Directory");
  	               	}
  	               	else
  	               	{
  	               		excelCell.setCellValue(strEngine + "\n" + strYear + " Component Repair Directory");
  	               	}
                
                //ending_rishabh_component_early_excel_tm
                    
                    
                    //excelCell.setCellValue(strEngine + "\n" + strYear + " Component Repair Directory");
                    
                	cell=null;
                    excelCell = null;
                    /*cell = row.createCell((short) (intColumnIndex + 5));
                    styleObj = getHiddenStyleObject(styleObj);
                    styleObj.setWrapText(true);
                    excelCell = (GEAEExcelCell) cell;
                    excelCell.setCellStyle(styleObj);
                    excelCell.setCellValue("");*/

                    cell=null;
                    excelCell = null;
                    cell = row.createCell((short) (intColumnIndex + 5));
                    styleObj = getStyleObjLeftBold11GESerif(workBook);
                    styleObj.setWrapText(true);
                    region = new GEAEExcelSheetRegion((short) intRowIndex, (short) intRowIndex, (short) 5, (short) 6);
                    ((GEAEExcelSheet) sheetDetails).addMergedRegion(region);
                    excelCell = (GEAEExcelCell) cell;
                    excelCell.setCellStyle(styleObj);
                    excelCell.setCellValue(strModule + " Module" + "\n" + "Section "+intModules + "\n" + "Issued: January 1, " + strYear);

                    styleObj = getStyleObjLeftBold10GESerif(workBook);
                    styleObj.setWrapText(true);
                    /*
                     * End of the Data to be Displayed in the First Row.
                     */

                    intRowIndex++;
                    row = null;
                    row = (GEAEExcelRow) sheetDetails.createRow((short) intRowIndex);

                    intColumn = 0;
                    /*
                     * Loop to Display the Headings of the Data to be Displayed.
                     */
                    for (intColumnIndex = 0; intColumnIndex <= intColumnCount - 9; intColumnIndex++)
                    {
                        cell=null;
                        excelCell = null;
                        cell = row.createCell((short) intColumnIndex);
                        excelCell = (GEAEExcelCell) cell;
                        styleObj = getStyleObjLeftBold10GESerif(workBook);
                        styleObj.setWrapText(true);
                        excelCell.setCellStyle(styleObj);
                        strHeading = eCRDUtil.verifyNull(rsCatalog.getColumnHeading(intColumnIndex + 2));

                        /*if("'".equals(strHeading))
                        {
                            excelCell.setCellValue(" ");
                        }
                        else
                        {*/
                            excelCell.setCellValue(strHeading);
                        //}

                    }
                    setBackColorBlack(workBook,sheetDetails, intRowIndex, 7);
                    sheetDetails.setDefaultColumnWidth((short) Integer.parseInt(eCRDConstants.EXCEL_COLUMN_WIDTH));
                }
                strPrevModule = strModule;
                strComponentCode = rsCatalog.getString(2);
                
                // Inserting a blank row btwn the Header and the actual Data.
                if (!strPrevComponentCode.equals(strComponentCode))
                {
                	
                	//code changes start for parts missing issue.
                	if(arrlstParts != null)
                    {
                        intPart = arrlstParts.size();
                    }
                    else
                    {
                        intPart = 0;
                    }
                    if(arrlstSites != null)
                    {
                        intSite = arrlstSites.size();
                    }
                    else
                    {
                        intSite = 0;
                    }
                    if(intPart > 0 || intSite > 0)
                    {
                    	intColumn = 0;
                    	if(intPart > intSite)
                        {
                            intColumn = intPart;
                        }
                        else
                        {
                            intColumn = intSite;
                        }
                        for(int inti = 0 ; inti < intColumn; inti++)
                        {
                            cell=null;
                            excelCell = null;
                            intRowIndex++;
                            row = null;
                            row = (GEAEExcelRow)sheetDetails.createRow((short) intRowIndex);
                            cell = row.createCell((short) 1);
                            excelCell = (GEAEExcelCell) cell;
                            styleObj = getStyleObjLeftNormal8GESerif(workBook);
                            styleObj.setWrapText(true);
                            excelCell.setCellStyle(styleObj);

                            intPart = arrlstParts.size();
                            if(intPart > 0)
                            {
                                excelCell.setCellValue(arrlstParts.get(intPart-1));
                                arrlstParts.remove(intPart-1);
                            }
                            else
                            {
                                excelCell.setCellValue("");
                            }

                            cell=null;
                            excelCell = null;
                            cell = row.createCell((short) 2);
                            excelCell = (GEAEExcelCell) cell;
                            styleObj = getStyleObjLeftBold8GESerif(workBook);
                            styleObj.setWrapText(true);
                            excelCell.setCellStyle(styleObj);
                            intSite = arrlstSites.size();
                            if(intSite > 0)
                            {
                                excelCell.setCellValue(arrlstSites.get(intSite-1));
                                arrlstSites.remove(intSite-1);
                            }
                            else
                            {
                                excelCell.setCellValue("");
                            }
                            
                        }
                    }        
                    //Code changes end for parts missing issue
                    
                    intRowIndex++;
                    row = null;
                    row = (GEAEExcelRow) sheetDetails.createRow((short) intRowIndex);
                    setBottomBorderBack(workBook,sheetDetails, intRowIndex, intColumnCount - 8);
                    arrlstSites = null;
                    arrlstParts = null;
                    //blnFlag = false;
                }

                /*
                 * Start of Displaying Actual Data.
                 */
                intRowIndex++;
                row = null;
                row = (GEAEExcelRow) sheetDetails.createRow((short) intRowIndex);
                styleObj = getStyleObjLeftBold8GESerif(workBook);
                styleObj.setWrapText(true);

                strRepairType = rsCatalog.getString(11);

                for (intColumnIndex = 0; intColumnIndex <= intColumnCount - 9; intColumnIndex++)
                {
                    cell=null;
                    excelCell = null;
                    cell = row.createCell((short) intColumnIndex);
                    excelCell = (GEAEExcelCell) cell;
                    if (!(strPrevComponentCode).equals(strComponentCode))
                    {
                        // New Component in Module
                        styleObj = getStyleObjLeftBold8GESerif(workBook);
                        styleObj.setWrapText(true);
                        intColumn = 0;
                        //Inserting the component details
                        /*
                         * Checking if there are any part or Sites left to be displayed for previous component.
                         * when the new component has come for display
                         * Checking only for the 1st column.
                         */
                        
                        /*Commented for parts missing issue
                        if(intColumnIndex == 0)
                        {
                            if(arrlstParts != null)
                            {
                                intPart = arrlstParts.size();
                            }
                            else
                            {
                                intPart = 0;
                            }
                            if(arrlstSites != null)
                            {
                                intSite = arrlstSites.size();
                            }
                            else
                            {
                                intSite = 0;
                            }
                            if(intPart > 0 || intSite > 0)
                            {
                                if(intPart > intSite)
                                {
                                    intColumn = intPart;
                                }
                                else
                                {
                                    intColumn = intSite;
                                }
                                for(int inti = 0 ; inti < intColumn; inti++)
                                {
                                    cell=null;
                                    excelCell = null;
                                    cell = row.createCell((short) 1);
                                    excelCell = (GEAEExcelCell) cell;
                                    styleObj = getStyleObjLeftNormal8GESerif(workBook);
                                    styleObj.setWrapText(true);
                                    excelCell.setCellStyle(styleObj);

                                    intPart = arrlstParts.size();
                                    if(intPart > 0)
                                    {
                                        excelCell.setCellValue(arrlstParts.get(intPart-1));
                                        arrlstParts.remove(intPart-1);
                                    }
                                    else
                                    {
                                        excelCell.setCellValue("");
                                    }

                                    cell=null;
                                    excelCell = null;
                                    cell = row.createCell((short) 2);
                                    excelCell = (GEAEExcelCell) cell;
                                    styleObj = getStyleObjLeftBold8GESerif(workBook);
                                    styleObj.setWrapText(true);
                                    excelCell.setCellStyle(styleObj);
                                    intSite = arrlstSites.size();
                                    if(intSite > 0)
                                    {
                                        excelCell.setCellValue(arrlstSites.get(intSite-1));
                                        arrlstSites.remove(intSite-1);
                                    }
                                    else
                                    {
                                        excelCell.setCellValue("");
                                    }

                                    intRowIndex++;
                                    row = null;
                                    row = (GEAEExcelRow)sheetDetails.createRow((short) intRowIndex);
                                }
                            }
                            
                        }
                        */
                        
                        /*
                         * End of the Extra Site or Parts that where supposed to displayed.
                         */
                        styleObj = getStyleObjLeftBold8GESerif(workBook);
                        styleObj.setWrapText(true);
                        /*
                         * Start of Display of Component releated Details.
                         */
                        if (intColumnIndex < 4)
                        {
                            /*
                             * Checking if it is 1st column to be displayed then creating the ArrayList of Parts for tht component.
                             * If it is 3rd Column to be Displayed then creating the Arraylist of sites.
                             * else Displaying the Component Details.
                             */
                            if(intColumnIndex == 1)
                            {
                                arrlstParts = new ArrayList();
                                arrlstParts = eCRDUtil.convertStringToArrayList((String)rsCatalog.getString(9),",");
                                excelCell.setCellValue(rsCatalog.getString(intColumnIndex + 2));
                            }
                            else if(intColumnIndex == 2)
                            {
                                arrlstSites = new ArrayList();
                                arrlstSites = eCRDUtil.convertStringToArrayList((String)rsCatalog.getString(4),",");
                                intSite = arrlstSites.size();
                                if(intSite > 0)
                                {
                                    excelCell.setCellValue(arrlstSites.get(intSite-1));
                                    arrlstSites.remove(intSite-1);
                                }
                            }
                            else
                            {
                                excelCell.setCellValue(rsCatalog.getString(intColumnIndex + 2));
                                excelCell.setCellStyle(styleObj);
                                if(intColumnIndex == 3)
                                {
                                    cell=null;
                                    excelCell = null;
                                    cell = row.createCell((short) 5);
                                    excelCell = (GEAEExcelCell) cell;
                                    styleObj = getStyleObjLeftBold8GESerif(workBook);
                                    styleObj.setWrapText(true);
                                    excelCell.setCellStyle(styleObj);
                                    if(!"".equals(rsCatalog.getString(15)))
                                    {
                                        excelCell.setCellValue(rsCatalog.getString(15)+" (CONTRACT TAT)");
                                    }
                                    else
                                    {
                                        excelCell.setCellValue("");
                                    }
                                }
                            }
                        }
                        /*
                         * Start of 1st Repair Data for the Current Component
                         */
                        else // inserting Repair Details in next row.
                        {
                            styleObj = getStyleObjLeftNormal8GESerif(workBook);
                            styleObj.setWrapText(true);
                            /*
                             * Identifies if we need to create a new repair row.
                             * If So then check if we need to display and Part/Site Information for the current component.
                             * If So then Display it
                             * Else Display the Repair Data.
                             */
                            if (!blnFlag)
                            {
                                intRowIndex++;
                                row = null;
                                row = (GEAEExcelRow) sheetDetails.createRow((short) intRowIndex);
                                /*
                                 * Start of Displaying the Site/Part Data for Current Component
                                 */

                                cell=null;
                                excelCell = null;
                                cell = row.createCell((short) 1);
                                excelCell = (GEAEExcelCell) cell;
                                excelCell.setCellStyle(styleObj);
                                arrlstParts = eCRDUtil.convertStringToArrayList((String)rsCatalog.getString(9),",");
                                intPart = arrlstParts.size();
                                if(intPart > 0)
                                {
                                    excelCell.setCellValue(arrlstParts.get(intPart-1));
                                    arrlstParts.remove(intPart-1);
                                }
                                else
                                {
                                    excelCell.setCellValue("");
                                }

                                cell=null;
                                excelCell = null;
                                cell = row.createCell((short) 2);
                                excelCell = (GEAEExcelCell) cell;
                                styleObj = getStyleObjLeftBold8GESerif(workBook);
                                excelCell.setCellStyle(styleObj);
                                intSite = arrlstSites.size();
                                if(intSite > 0)
                                {
                                    excelCell.setCellValue(arrlstSites.get(intSite-1));
                                    arrlstSites.remove(intSite-1);
                                }
                                else
                                {
                                    excelCell.setCellValue("");
                                }
                                /*
                                 * End of Code for Displaying Site/Part Information
                                 */
                                // Display the Repair Display Seq Id
                                styleObj = getStyleObjLeftNormal8GESerif(workBook);
                                cell=null;
                                excelCell = null;
                                cell = row.createCell((short) 3);
                                excelCell = (GEAEExcelCell) cell;
                                excelCell.setCellStyle(styleObj);
                                excelCell.setCellValue(rsCatalog.getString(10));

                                cell=null;
                                excelCell = null;
                                cell = row.createCell((short) intColumnIndex);
                                excelCell = (GEAEExcelCell) cell;
                                excelCell.setCellStyle(styleObj);

                                blnFlag = true;

                            }
                            styleObj = getStyleObjLeftNormal8GESerif(workBook);
                            styleObj.setWrapText(true);
                            excelCell.setCellStyle(styleObj);
                            excelCell.setCellValue(rsCatalog.getString(intColumnIndex + 2));
                            /*
                             * Start of Code for Display of Repair Comments if Present
                             */
                            if(intColumnIndex == (intColumnCount-9))
                            {
                                strRepairComments = eCRDUtil.verifyNull(rsCatalog.getString(13));
                                if(!"".equals(strRepairComments))
                                {
                                    intRowIndex ++;
                                    row = null;
                                    row = (GEAEExcelRow)sheetDetails.createRow((short)intRowIndex);

                                    cell=null;
                                    excelCell = null;
                                    cell = row.createCell((short) 1);
                                    excelCell = (GEAEExcelCell) cell;
                                    excelCell.setCellStyle(styleObj);
                                    intPart = arrlstParts.size();
                                    if(intPart > 0)
                                    {
                                        excelCell.setCellValue(arrlstParts.get(intPart-1));
                                        arrlstParts.remove(intPart-1);
                                    }
                                    else
                                    {
                                        excelCell.setCellValue("");
                                    }

                                    cell=null;
                                    excelCell = null;
                                    cell = row.createCell((short) 2);
                                    excelCell = (GEAEExcelCell) cell;
                                    styleObj = getStyleObjLeftBold8GESerif(workBook);
                                    excelCell.setCellStyle(styleObj);
                                    intSite = arrlstSites.size();
                                    if(intSite > 0)
                                    {
                                        excelCell.setCellValue(arrlstSites.get(intSite-1));
                                        arrlstSites.remove(intSite-1);
                                    }
                                    else
                                    {
                                        excelCell.setCellValue("");
                                    }

                                    cell=null;
                                    excelCell = null;
                                    cell = row.createCell((short)4);
                                    excelCell = (GEAEExcelCell) cell;
                                    styleObj = getStyleObjLeftNormal8GESerif(workBook);
                                    styleObj.setWrapText(true);
                                    excelCell.setCellStyle(styleObj);
                                    excelCell.setCellValue(strRepairComments);
                                }
                            }
                            /*
                             * End Of Code for Display of Repair Comments.
                             */
                           if(intColumnIndex == (intColumnCount-9))
                           {
                                if(eCRDConstants.STRGROUPREPAIR.equals(strRepairType))
                                {
                                    strRepairId = rsCatalog.getString(14);
                                    intRowIndex = insertChildRepairsData(workBook,sheetDetails,intRowIndex,rsChildRepairCatalogs,styleObj,arrlstParts,arrlstSites,strRepairId);
                                }
                           }
                        }// End of Code for Display of Repair.
                    }//End of Code for Display of Component Details
                    /*
                     * Start of Code for Display of Data for Repair present in the Component
                     */
                    else // Data for Repair of the same component
                    {
                        styleObj = getStyleObjLeftNormal8GESerif(workBook);
                        styleObj.setWrapText(true);
                        /*
                         * Start of Code for Display of Following Things.
                         * 1) Part if any left for the Component
                         * 2) Sites if any left for the Component
                         * 3) Repair Display Seq Id For the current Repair.
                         */
                        if (intColumnIndex < 4)
                        {
                            if (intColumnIndex == 1)
                            {
                                intPart = arrlstParts.size();
                                if(intPart > 0)
                                {
                                    excelCell.setCellValue(arrlstParts.get(intPart-1));
                                    arrlstParts.remove(intPart-1);
                                }
                                else
                                {
                                    excelCell.setCellValue("");
                                }
                            }
                            else if (intColumnIndex == 2)
                            {
                                styleObj = getStyleObjLeftBold8GESerif(workBook);
                                styleObj.setWrapText(true);
                                intSite = arrlstSites.size();
                                if(intSite > 0)
                                {
                                    excelCell.setCellValue(arrlstSites.get(intSite-1));
                                    arrlstSites.remove(intSite-1);
                                }
                                else
                                {
                                    excelCell.setCellValue("");
                                }
                            }
                            else if (intColumnIndex == 3)
                            {
                                excelCell.setCellValue(rsCatalog.getString(intColumnIndex + 7));
                            }
                            else
                            {
                                excelCell.setCellValue("");
                            }
                        }
                        /*
                         * End of Code for display of Sites/Parts/Display Seq.
                         * Start of Code for Display of Other Repair Details.
                         */
                        else
                        {
                            styleObj = getStyleObjLeftNormal8GESerif(workBook);
                            styleObj.setWrapText(true);
                            excelCell.setCellStyle(styleObj);
                            excelCell.setCellValue(rsCatalog.getString(intColumnIndex + 2));
                            /*
                             * Start of Code for Display of Repair Comments if Available
                             */
                            if(intColumnIndex == (intColumnCount-9))
                            {
                                strRepairComments = eCRDUtil.verifyNull(rsCatalog.getString(13));
                                if(!"".equals(strRepairComments))
                                {
                                    intRowIndex ++;
                                    row = null;
                                    row = (GEAEExcelRow)sheetDetails.createRow((short)intRowIndex);

                                    cell=null;
                                    excelCell = null;
                                    cell = row.createCell((short) 1);
                                    excelCell = (GEAEExcelCell) cell;
                                    excelCell.setCellStyle(styleObj);
                                    intPart = arrlstParts.size();
                                    if(intPart > 0)
                                    {
                                        excelCell.setCellValue(arrlstParts.get(intPart-1));
                                        arrlstParts.remove(intPart-1);
                                    }
                                    else
                                    {
                                        excelCell.setCellValue("");
                                    }

                                    cell=null;
                                    excelCell = null;
                                    cell = row.createCell((short) 2);
                                    excelCell = (GEAEExcelCell) cell;
                                    styleObj = getStyleObjLeftBold8GESerif(workBook);
                                    excelCell.setCellStyle(styleObj);
                                    intSite = arrlstSites.size();
                                    if(intSite > 0)
                                    {
                                        excelCell.setCellValue(arrlstSites.get(intSite-1));
                                        arrlstSites.remove(intSite-1);
                                    }
                                    else
                                    {
                                        excelCell.setCellValue("");
                                    }

                                    cell=null;
                                    excelCell = null;
                                    cell = row.createCell((short)4);
                                    excelCell = (GEAEExcelCell) cell;
                                    styleObj = getStyleObjLeftNormal8GESerif(workBook);
                                    styleObj.setWrapText(true);
                                    excelCell.setCellStyle(styleObj);
                                    excelCell.setCellValue(strRepairComments);
                                }
                            }/*
                              * End of Code for Display of Repair Comments
                              */
                            if(intColumnIndex == (intColumnCount-9))
                            {
                                if(eCRDConstants.STRGROUPREPAIR.equals(strRepairType))
                                {
                                    strRepairId = rsCatalog.getString(14);
                                    intRowIndex = insertChildRepairsData(workBook,sheetDetails,intRowIndex,rsChildRepairCatalogs,styleObj,arrlstParts,arrlstSites,strRepairId);
                                }
                            }
                        }/*
                          * End of Code for Display of Repari Details
                          */
                    }/*
                      * End of Code for Display of Repair for the Same Component
                      */
                    excelCell.setCellStyle(styleObj);
                }/*
                  * End of the For Loop for the Display of Actual Data
                  */
                blnFlag = false;
                strPrevComponentCode = strComponentCode;
            }
//          19-05-2006 patni checking null value Begin
        } // End if
//    19-05-2006 patni checking null value End
            /*
             * Checking if there are any More Parts or Sites that have to be Displayed
             * for the last Component of Last Module.
             */
            if(arrlstParts != null)
            {
                intPart = arrlstParts.size();
            }
            else
            {
                intPart = 0;
            }
            if(arrlstSites != null)
            {
                intSite = arrlstSites.size();
            }
            else
            {
                intSite = 0;
            }
            if(intPart > 0 || intSite > 0)
            {
                //Indentifying whether there are more parts or more sites to be displayed.
                if(intPart > intSite)
                {
                    intColumn = intPart;
                }
                else
                {
                    intColumn = intSite;
                }
                // Loop to display all the remaining Sites and Parts for the Previous Component
                for(int inti = 0 ; inti < intColumn; inti++)
                {
                    // creating new row to insert parts and site Data
                    intRowIndex++;
                    row=null;
                    row = (GEAEExcelRow)sheetDetails.createRow((short) intRowIndex);

                    //creating cell for parts data.
                    cell=null;
                    excelCell = null;
                    cell = row.createCell((short) 1);
                    excelCell = (GEAEExcelCell) cell;
                    styleObj = getStyleObjLeftNormal8GESerif(workBook);
                    styleObj.setWrapText(true);
                    excelCell.setCellStyle(styleObj);
                    intPart = arrlstParts.size();
                    if(intPart > 0)
                    {
                        // Displaying the Part Numbers.
                        excelCell.setCellValue(arrlstParts.get(intPart-1));
                        // Removing the Displayed Part Number frm the Arraylist.
                        arrlstParts.remove(intPart-1);
                    }
                    else
                    {
                        // No Value to be displayed in the cell for Part Number.
                        excelCell.setCellValue("");
                    }

                    //creating cell for Sites Data
                    cell=null;
                    excelCell = null;
                    cell = row.createCell((short) 2);
                    excelCell = (GEAEExcelCell) cell;
                    styleObj = getStyleObjLeftBold8GESerif(workBook);
                    styleObj.setWrapText(true);
                    excelCell.setCellStyle(styleObj);
                    intSite = arrlstSites.size();
                    if(intSite > 0)
                    {
                        // Displaying the Sites.
                        excelCell.setCellValue(arrlstSites.get(intSite-1));
                        // Removing the Sites frm the Site ArrayList.
                        arrlstSites.remove(intSite-1);
                    }
                    else
                    {
                        // No Value to be Dispalyed in the Cell for Sites.
                        excelCell.setCellValue("");
                    }
                }
            }
            setBottomBorderBack(workBook,sheetDetails, intRowIndex, intColumnCount - 8);
            return workBook;
        }
        finally
        {
            intColumnIndex = 0;
            intColumnCount = 0;
            intColumn = 0;
            strPrevModule = null;
            strCatalogId = null;
            strActionId = null;
            arrlstInParam = null;
            rsCatalog = null;
            rsChildRepairCatalogs = null;
            arrlstOutParam = null;
            strEngine = null;
            strPrevComponentCode =null;
            strComponentCode = null;
            strRepairComments = null;
            intPart = 0;
            intModules = 0;
            intSite = 0;
            strHeading = null;
            arrlstParts = null;
            arrlstSites = null;
            region = null;
            strYear = null;
            blnFlag = false;
            styleObj = null;
            strRepairType =null;
            strRepairId = null;
        }
    }

    public GEAEExcelWorkbook getReport(String strAction, HttpServletRequest request) throws Exception
    {

        if (eCRDConstants.getActionId("eCRD_DOWNLOAD_EXCEL").equals(strAction))
        {
            workBook = generateYearlyCatalogXLS(request);
        }
        else if(eCRDConstants.STRENGREVYIELD.equals(strAction))
        {
            workBook = generateEngRevReport(request);
        }
        else if(eCRDConstants.STRADHOCREPAIRREP.equals(strAction))
        {
            workBook = generateAdhocReport(request);
        }
        //Added by Bora
        else if(eCRDConstants.STRENADHOCREPAIRREP.equals(strAction))
        {
            workBook = generateEnhancedAdhocReport(request);
        }
        //End Bora
        // Adding Customer Adhoc Repair Reports started DES1121903 sujitha
        else if(eCRDConstants.STRCUSTADHOCREPAIRREP.equals(strAction))
        {
        	System.out.println("PRATHIMA IN TEST FOR inside the getReport()");
            workBook = generateCustdhocReport(request);
        }
       
        else if(eCRDConstants.STRENCUSTADHOCREPAIRREP.equals(strAction))
        {
        	System.out.println("SANTOSH inside download jsp in Batch download  ===");
            workBook = generateEnhancedCustadhocReport(request);
        }
        // Adding Customer Adhoc Repair Reports ended
   
        return workBook;
    }

    private void setBackColorBlack(GEAEExcelWorkbook workBook, GEAESheet sheet, int rowIndex, int endCell) throws Exception
    {
        GEAEExcelCell cell;
        GEAEExcelRow row1;
        int i = 0;
        try
        {

            if(fontBoldGESerif9 == null)
            {
                fontBoldGESerif9 = workBook.createFont();
            }
            if(styleObjBottomBackBlack == null)
            {
                styleObjBottomBackBlack = workBook.createCellStyle();
            }

            // set font properties
            fontBoldGESerif9.setFontName(GEAEExcelConstants.FONT_GE_SERIF);
            fontBoldGESerif9.setFontHeight((short) 8);
            fontBoldGESerif9.setColor(GEAEExcelConstants.WHITE);
            fontBoldGESerif9.setBoldweight(GEAEExcelConstants.BOLDWEIGHT_BOLD);
            styleObjBottomBackBlack.setFont(fontBoldGESerif9);
            styleObjBottomBackBlack.setWrapText(true);

            styleObjBottomBackBlack.setFillForegroundColor(GEAEExcelConstants.BLACK);
            styleObjBottomBackBlack.setFillPattern(GEAEExcelConstants.SOLID_FOREGROUND);

            styleObjBottomBackBlack.setBorderBottom(GEAEExcelConstants.BORDER_THIN);
            styleObjBottomBackBlack.setBottomBorderColor(GEAEExcelConstants.BLACK);
            styleObjBottomBackBlack.setBorderTop(GEAEExcelConstants.BORDER_THIN);
            styleObjBottomBackBlack.setTopBorderColor(GEAEExcelConstants.BLACK);

            styleObjBottomBackBlack.setDataFormat(GEAEExcelDataFormat.getFormatIndex("0.00"));
            styleObjBottomBackBlack.setAlignment(GEAEExcelConstants.ALIGN_LEFT);

            if(styleObjBottomBackBlackDesc == null)
            {
                styleObjBottomBackBlackDesc = workBook.createCellStyle();
            }
            styleObjBottomBackBlackDesc.setFont(fontBoldGESerif9);
            styleObjBottomBackBlackDesc.setFillForegroundColor(GEAEExcelConstants.BLACK);
            styleObjBottomBackBlackDesc.setFillForegroundColor(GEAEExcelConstants.BLACK);
            styleObjBottomBackBlackDesc.setFillPattern(GEAEExcelConstants.SOLID_FOREGROUND);

            row1 = (GEAEExcelRow) sheet.getRow((short) rowIndex);
            for (i = 0; i < endCell; i++)
            {
                try
                {
                    if (i == 0)
                    {
                        cell = (GEAEExcelCell) row1.getCell((short) i);
                        cell.setCellStyle(styleObjBottomBackBlackDesc);
                    }
                    else
                    {
                        cell = (GEAEExcelCell) row1.getCell((short) i);
                        cell.setCellStyle(styleObjBottomBackBlack);
                    }
                }
                catch (NullPointerException e)
                {

                    row1.createCell((short) i).setCellValue("");
                    cell = (GEAEExcelCell) row1.getCell((short) i);
                    cell.setCellStyle(styleObjBottomBackBlack);
                }
            }
        }
        finally
        {
        }

    }

    /*
    *This method is written to handle null pointer exception
    *The problem is getCell or getRow doesnot return null when there is no data in the cells
    *But when a method is applied to the cell or Row it raises a null pointer exception
    *This is the reason for the try catch block in each of these methods to apply the styles.whenever a getCell method is called
    **/
    private void setBottomBorderBack(GEAEExcelWorkbook workBook, GEAESheet sheet, int rowIndex, int endCell) throws Exception
    {
        GEAEExcelCell cell;
        int i = 0;
        try
        {
            if(styleObjBottomBorderBlack == null)
            {
                styleObjBottomBorderBlack = workBook.createCellStyle();
            }
            if(fontBoldGESerif9 == null)
            {
                fontBoldGESerif9 = workBook.createFont();
            }
            // set font properties
            fontBoldGESerif9.setFontName(GEAEExcelConstants.FONT_GE_SERIF);
            fontBoldGESerif9.setBoldweight(GEAEExcelConstants.BOLDWEIGHT_BOLD);
            fontBoldGESerif9.setFontHeight((short) 9);
            styleObjBottomBorderBlack.setFont(fontBoldGESerif9);
            styleObjBottomBorderBlack.setFillForegroundColor(GEAEExcelConstants.WHITE);
            styleObjBottomBorderBlack.setFillPattern(GEAEExcelConstants.SOLID_FOREGROUND);
            styleObjBottomBorderBlack.setBorderBottom(GEAEExcelConstants.BORDER_THIN);
            styleObjBottomBorderBlack.setBorderTop(GEAEExcelConstants.BORDER_HAIR);
            styleObjBottomBorderBlack.setBottomBorderColor(GEAEExcelConstants.BLACK);
            styleObjBottomBorderBlack.setBorderRight(GEAEExcelConstants.BORDER_HAIR);
            // set the wrap text property
            //style.setWrapText(true);

            GEAEExcelRow row1 = (GEAEExcelRow) sheet.getRow((short) rowIndex);
            //row1.setRowStyle(style);
            for (i = 0; i < endCell; i++)
            {
                try
                {
                    cell = (GEAEExcelCell) row1.getCell((short) i);

                    cell.setCellStyle(styleObjBottomBorderBlack);
                    cell.setCellValue("");
                }
                catch (NullPointerException e)
                {
                    row1.createCell((short) i).setCellValue("");
                    cell = (GEAEExcelCell) row1.getCell((short) i);
                    cell.setCellStyle(styleObjBottomBorderBlack);
                    cell.setCellValue("");
                }
            }
        }
        finally
        {
        }
    }

    private int insertChildRepairsData(GEAEExcelWorkbook workBook,GEAEExcelSheet sheet, int intRowIndex,GEAEResultSet rsChildRepairs,GEAEExcelCellStyle styleObj,ArrayList arrlstParts, ArrayList arrlstSites,String strRepairId) throws Exception
    {
        int intColumnIndex = 0;
        int intPart = 0;
        int intSite = 0;
        String strRepairComments = null;
        GEAEExcelRow row;
        GEAEExcelCell excelCell;
        int intColumnCount =0;
        String strParentRepairId = null;
        try
        {
            intColumnCount = rsChildRepairs.getColumnCount();
            styleObj = getStyleObjLeftNormal8GESerif(workBook);
            styleObj.setWrapText(true);
            /*
             * Start of Code for Display of Following Things.
             * 1) Part if any left for the Component
             * 2) Sites if any left for the Component
             * 3) Repair Display Seq Id For the current Repair.
             */
            rsChildRepairs.setCurrentRow(0);
//        19-05-2006 patni checking null value Begin
            if(rsChildRepairs!=null)
            {
//              19-05-2006 patni checking null value End

            while(rsChildRepairs.next())
            {
                strParentRepairId = rsChildRepairs.getString(12);
                if(strRepairId.equals(strParentRepairId))
                {
                    intRowIndex ++;
                    row = null;
                    row =   (GEAEExcelRow)sheet.createRow((short)intRowIndex);
                    for(intColumnIndex = 0; intColumnIndex <= intColumnCount -9; intColumnIndex ++)
                    {
                        excelCell = null;
                        excelCell = (GEAEExcelCell)row.createCell((short)intColumnIndex);
                        styleObj = getStyleObjLeftNormal8GESerif(workBook);
                        styleObj.setWrapText(true);

                        if (intColumnIndex < 4)
                        {
                            if (intColumnIndex == 1)
                            {
                                intPart = arrlstParts.size();
                                if(intPart > 0)
                                {
                                    excelCell.setCellValue(arrlstParts.get(intPart-1));
                                    arrlstParts.remove(intPart-1);
                                }
                                else
                                {
                                    excelCell.setCellValue("");
                                }
                            }
                            else if (intColumnIndex == 2)
                            {
                                styleObj = getStyleObjLeftBold8GESerif(workBook);
                                styleObj.setWrapText(true);
                                intSite = arrlstSites.size();
                                if(intSite > 0)
                                {
                                    excelCell.setCellValue(arrlstSites.get(intSite-1));
                                    arrlstSites.remove(intSite-1);
                                }
                                else
                                {
                                    excelCell.setCellValue("");
                                }
                            }
                            else if (intColumnIndex == 3)
                            {
                                excelCell.setCellValue(rsChildRepairs.getString(intColumnIndex + 7));
                            }
                            else
                            {
                                excelCell.setCellValue("");
                            }
                            excelCell.setCellStyle(styleObj);
                        }
                        /*
                         * End of Code for display of Sites/Parts/Display Seq.
                         * Start of Code for Display of Other Repair Details.
                         */
                        else
                        {
                            styleObj = getStyleObjLeftNormal8GESerif(workBook);
                            styleObj.setWrapText(true);
                            excelCell.setCellValue(rsChildRepairs.getString(intColumnIndex + 2));
                            /*
                             * Start of Code for Display of Repair Comments if Available
                             */
                            if(intColumnIndex == (intColumnCount-9))
                            {
                                strRepairComments = eCRDUtil.verifyNull(rsChildRepairs.getString(13));
                                if(!"".equals(strRepairComments))
                                {
                                    intRowIndex ++;
                                    row = null;
                                    row = (GEAEExcelRow)sheetDetails.createRow((short)intRowIndex);

                                    excelCell = null;
                                    excelCell = (GEAEExcelCell)row.createCell((short) 1);
                                    excelCell.setCellStyle(styleObj);
                                    intPart = arrlstParts.size();
                                    if(intPart > 0)
                                    {
                                        excelCell.setCellValue(arrlstParts.get(intPart-1));
                                        arrlstParts.remove(intPart-1);
                                    }
                                    else
                                    {
                                        excelCell.setCellValue("");
                                    }

                                    excelCell = null;
                                    excelCell = (GEAEExcelCell)row.createCell((short) 2);
                                    styleObj = getStyleObjLeftBold8GESerif(workBook);
                                    excelCell.setCellStyle(styleObj);
                                    intSite = arrlstSites.size();
                                    if(intSite > 0)
                                    {
                                        excelCell.setCellValue(arrlstSites.get(intSite-1));
                                        arrlstSites.remove(intSite-1);
                                    }
                                    else
                                    {
                                        excelCell.setCellValue("");
                                    }

                                    excelCell = null;
                                    excelCell = (GEAEExcelCell)row.createCell((short)4);
                                    styleObj = getStyleObjLeftNormal8GESerif(workBook);
                                    styleObj.setWrapText(true);
                                    excelCell.setCellStyle(styleObj);
                                    excelCell.setCellValue(strRepairComments);
                                }
                            }
                            excelCell.setCellStyle(styleObj);
                        }
                    }
                }
            }
//          19-05-2006 patni checking null value Begin
            } // end if
//          19-05-2006 patni checking null value End
            return intRowIndex;
        }
        finally
        {
            intColumnIndex = 0;
            intPart = 0;
            intSite = 0;
            strRepairComments = "";
            intColumnCount =0;
            strParentRepairId = "";
        }
    }

    /*
     * Added by Roshan
     */
    /**
     * Method name: getStyleObjLeftNormal12GESerif
     * Brief logic:  This method will return the excel cell style object with normal font
     * size 12 and right align
     * @param   workBook (GEAEExcelWorkbook)
     * @return  GEAEExcelCellStyle
     */
    private GEAEExcelCellStyle getStyleObjLeftNormal12GESerif(GEAEExcelWorkbook workBook)
        throws Exception
    {
        if(styleObjNormalGESerif12 == null)
        {
            styleObjNormalGESerif12 = workBook.createCellStyle();
        }
        objNormalFontGESerif12 = getNormalFontGESerif12(workBook,objNormalFontGESerif12);
        styleObjNormalGESerif12 = getLeftAlignStyleObject(styleObjNormalGESerif12);
        styleObjNormalGESerif12.setFont(objNormalFontGESerif12);
        styleObjNormalGESerif12.setDataFormat((short) 8);

        return styleObjNormalGESerif12;
    }

    /**
     * Method name: getNormalFontGESerif12
     * Brief logic:  This method will set the font style object to normal and GESerif type and
     * size of 12.
     * @param   wb (GEAEExcelWorkbook)
     * @return  GEAEExcelFont
     */
    private GEAEExcelFont getNormalFontGESerif12(GEAEExcelWorkbook workBook, GEAEExcelFont objNormalFontGESerif12)
        throws GEAEOfficeException
    {
        if(objNormalFontGESerif12 == null)
        {
            objNormalFontGESerif12 = workBook.createFont();
        }
        objNormalFontGESerif12.setFontName(GEAEExcelConstants.FONT_GE_SERIF);
        //setting it to normal font.
        //font.setBoldweight(GEAEExcelConstants.COLOR_NORMAL);
        //setting the height of the font to 12.
        objNormalFontGESerif12.setFontHeight((short) 12);
        return objNormalFontGESerif12;
    } //end of getFontGESerif12 method

    /**
     * Method name: getStyleObjLeftNormal16GESerif
     * Brief logic:  This method will return the excel cell style object with normal font
     * size 16 and left align
     * @param   workBook (GEAEExcelWorkbook)
     * @return  GEAEExcelCellStyle
     */
    private GEAEExcelCellStyle getStyleObjLeftNormal16GESerif(GEAEExcelWorkbook workBook)
        throws Exception
    {
        if(styleObjNormalGESerif16 == null)
        {
            styleObjNormalGESerif16 = workBook.createCellStyle();
        }
        objNormalFontGESerif16 = getNormalFontGESerif16(workBook,objNormalFontGESerif16);
        styleObjNormalGESerif16 = getLeftAlignStyleObject(styleObjNormalGESerif16);
        styleObjNormalGESerif16.setFont(objNormalFontGESerif16);

        styleObjNormalGESerif16.setDataFormat((short) 8);

        return styleObjNormalGESerif16;
    }

    /**
     * Method name: getNormalFontGESerif16
     * Brief logic:  This method will set the font style object to normal and GESerif type and
     * size of 16.
     * @param   wb (GEAEExcelWorkbook)
     * @return  GEAEExcelFont
     */
    private GEAEExcelFont getNormalFontGESerif16(GEAEExcelWorkbook workBook,GEAEExcelFont font )
        throws GEAEOfficeException
    {
        if(font == null)
        {
            font = workBook.createFont();
        }
        //setting it to GE Serif font.
        font.setFontName(GEAEExcelConstants.FONT_GE_SERIF);
        //setting the height of the font to 16.
        font.setFontHeight((short) 16);
        return font;
    } //end of getFontGESerif12 method

    /**
     * Method name: getCenterAlignStyleObject
     * Brief logic:  This method will set the style object to center alignment.
     * @param   wb (GEAEExcelWorkbook)
     * @return  GEAEExcelCellStyle
     */
    private GEAEExcelCellStyle getCenterAlignStyleObject(GEAEExcelWorkbook wb)
        throws GEAEOfficeException {
        GEAEExcelCellStyle style = wb.createCellStyle();
        //setting it to Center alignment.
        style.setAlignment(GEAEExcelConstants.ALIGN_CENTER_SELECTION);
        return style;
    } //end of getRightAlignStyleObject method

    /**
     * Method name: getStyleObjLeftBold11GESerif
     * Brief logic:  This method will return the excel cell style object with Bold font
     * size 11 and left align
     * @param   workBook (GEAEExcelWorkbook)
     * @return  GEAEExcelCellStyle
     */
    private GEAEExcelCellStyle getStyleObjLeftBold11GESerif(GEAEExcelWorkbook workBook)
        throws Exception
    {
        if(styleObjBoldGESerif11 == null)
        {
            styleObjBoldGESerif11 = workBook.createCellStyle();
        }
        objBoldFontGESerif11 = getBoldFontGESerif11(workBook,objBoldFontGESerif11);
        styleObjBoldGESerif11 = getLeftAlignStyleObject(styleObjBoldGESerif11);
        styleObjBoldGESerif11.setFont(objBoldFontGESerif11);
        styleObjBoldGESerif11.setDataFormat((short) 8);

        return styleObjBoldGESerif11;
    }

    /**
     * Method name: getBoldFontGESerif11
     * Brief logic:  This method will set the font style object to normal and GESerif type and
     * size of 11.
     * @param   wb (GEAEExcelWorkbook)
     * @return  GEAEExcelFont
     */
    private GEAEExcelFont getBoldFontGESerif11(GEAEExcelWorkbook workBook,GEAEExcelFont objBoldFontGESerif11)
        throws GEAEOfficeException
    {
        if(objBoldFontGESerif11 == null)
        {
            objBoldFontGESerif11 = workBook.createFont();
        }
        //setting it to GE Serif font.
        objBoldFontGESerif11.setFontName(GEAEExcelConstants.FONT_GE_SERIF);
        //setting it to Bold font.
        objBoldFontGESerif11.setBoldweight(GEAEExcelConstants.BOLDWEIGHT_BOLD);
        //setting the height of the font to 11.
        objBoldFontGESerif11.setFontHeight((short) 11);
        return objBoldFontGESerif11;
    } //end of getBoldFontGESerif11 method

    /**
     * Method name: getStyleObjLeftNormal11GESerif
     * Brief logic:  This method will return the excel cell style object with normal font
     * size 11 and left align
     * @param   workBook (GEAEExcelWorkbook)
     * @return  GEAEExcelCellStyle
     */
    private GEAEExcelCellStyle getStyleObjLeftNormal11GESerif(GEAEExcelWorkbook workBook)
        throws Exception
    {
        if(styleObjNormalGESerif11 == null)
        {
            styleObjNormalGESerif11 = workBook.createCellStyle();
        }
        objNormalFontGESerif11 = getNormalFontGESerif11(workBook,objNormalFontGESerif11);
        styleObjNormalGESerif11 = getLeftAlignStyleObject(styleObjNormalGESerif11);
        styleObjNormalGESerif11.setFont(objNormalFontGESerif11);
        styleObjNormalGESerif11.setDataFormat((short) 8);

        return styleObjNormalGESerif11;
    }

    /**
     * Method name: getNormalFontGESerif11
     * Brief logic:  This method will set the font style object to normal and GESerif type and
     * size of 11.
     * @param   wb (GEAEExcelWorkbook)
     * @return  GEAEExcelFont
     */
    private GEAEExcelFont getNormalFontGESerif11(GEAEExcelWorkbook workBook,GEAEExcelFont objNormalFontGESerif11 )
        throws GEAEOfficeException
    {
        if(objNormalFontGESerif11 == null)
        {
            objNormalFontGESerif11 = workBook.createFont();
        }
        //setting it to GE Serif font.
        objNormalFontGESerif11.setFontName(GEAEExcelConstants.FONT_GE_SERIF);
        //setting it to normal font.
        objNormalFontGESerif11.setBoldweight(GEAEExcelConstants.COLOR_NORMAL);
        //setting the height of the font to 11.
        objNormalFontGESerif11.setFontHeight((short) 11);
        return objNormalFontGESerif11;
    }

    /**
     * Method name: getStyleObjLeftBold10GESerif
     * Brief logic:  This method will return the excel cell style object with Bold font
     * size 10 and center right
     * @param   workBook (GEAEExcelWorkbook)
     * @return  GEAEExcelCellStyle
     */
    private GEAEExcelCellStyle getStyleObjLeftBold10GESerif(GEAEExcelWorkbook workBook)
        throws Exception
    {
        if(styleObjBoldGESerif10 == null)
        {
            styleObjBoldGESerif10 = workBook.createCellStyle();
        }
        objBoldFontGESerif10 = getBoldFontGESerif10(workBook,objBoldFontGESerif10);
        styleObjBoldGESerif10 = getLeftAlignStyleObject(styleObjBoldGESerif10);
        styleObjBoldGESerif10.setFont(objBoldFontGESerif10);
        styleObjBoldGESerif10.setDataFormat((short) 10);
        return styleObjBoldGESerif10;
    }

    /**
     * Method name: getBoldFontGESerif8
     * Brief logic:  This method will set the font style object to Bold and GESerif type and
     * size of 8.
     * @param   wb (GEAEExcelWorkbook)
     * @return  GEAEExcelFont
     */
    private GEAEExcelFont getBoldFontGESerif8(GEAEExcelWorkbook workBook,GEAEExcelFont objBoldFontGESerif8 )
        throws GEAEOfficeException
    {
        if(objBoldFontGESerif8 == null)
        {
            objBoldFontGESerif8 = workBook.createFont();
        }
        //setting it to GE Serif font.
        objBoldFontGESerif8.setFontName(GEAEExcelConstants.FONT_GE_SERIF);
        //setting it to normal font.
        objBoldFontGESerif8.setBoldweight(GEAEExcelConstants.BOLDWEIGHT_BOLD);
        //setting the height of the font to 8.
        objBoldFontGESerif8.setFontHeight((short) 8);

        return objBoldFontGESerif8;
    }

    /**
     * Method name: getBoldFontGESerif10
     * Brief logic:  This method will set the font style object to Bold and GESerif type and
     * size of 10.
     * @param   wb (GEAEExcelWorkbook)
     * @return  GEAEExcelFont
     */
    private GEAEExcelFont getBoldFontGESerif10(GEAEExcelWorkbook workBook,GEAEExcelFont objBoldFontGESerif10 )
        throws GEAEOfficeException
    {
        if(objBoldFontGESerif10 == null)
        {
            objBoldFontGESerif10 = workBook.createFont();
        }
        //setting it to GE Serif font.
        objBoldFontGESerif10.setFontName(GEAEExcelConstants.FONT_GE_SERIF);
        //setting it to normal font.
        objBoldFontGESerif10.setBoldweight(GEAEExcelConstants.BOLDWEIGHT_BOLD);
        //setting the height of the font to 10.
        objBoldFontGESerif10.setFontHeight((short) 10);
        return objBoldFontGESerif10;
    }

    /**
     * Method name: getStyleObjLeftBold8GESerif
     * Brief logic:  This method will return the excel cell style object with Bold font
     * size 8 and Left align
     * @param   workBook (GEAEExcelWorkbook)
     * @return  GEAEExcelCellStyle
     */
    private GEAEExcelCellStyle getStyleObjLeftBold8GESerif(GEAEExcelWorkbook workBook)
        throws Exception
    {
        if(styleObjBoldGESerif8 == null)
        {
            styleObjBoldGESerif8 = workBook.createCellStyle();
        }
        objBoldFontGESerif8 = getBoldFontGESerif8(workBook,objBoldFontGESerif8);
        styleObjBoldGESerif8 = getLeftAlignStyleObject(styleObjBoldGESerif8);
        styleObjBoldGESerif8.setFont(objBoldFontGESerif8);
        styleObjBoldGESerif8.setDataFormat((short) 8);
        return styleObjBoldGESerif8;
    }

    /**
     * Method name: getStyleObjRightNormal8GESerif
     * Brief logic:  This method will return the excel cell style object with normal GESerif font
     * size 8 and center align
     * @param   workBook (GEAEExcelWorkbook)
     * @return  GEAEExcelCellStyle
     */
    private GEAEExcelCellStyle getStyleObjLeftNormal8GESerif(GEAEExcelWorkbook workBook)
        throws Exception
    {
        if(styleObjNormalGESerif8 == null)
        {
            styleObjNormalGESerif8 = workBook.createCellStyle();
        }
        objNormalFontGESerif8 = getNormalFontGESerif8(workBook,objNormalFontGESerif8);
        styleObjNormalGESerif8 = getLeftAlignStyleObject(styleObjNormalGESerif8);
        styleObjNormalGESerif8.setFont(objNormalFontGESerif8);
        styleObjNormalGESerif8.setDataFormat((short)GEAEExcelConstants.CELL_TYPE_BLANK);
        return styleObjNormalGESerif8;
    }

    /**
     * Method name: getNormalFontGESerif8
     * Brief logic:  This method will set the font style object to normal and GESerif type and
     * size of 8.
     * @param   wb (GEAEExcelWorkbook)
     * @return  GEAEExcelFont
     */
    private GEAEExcelFont getNormalFontGESerif8(GEAEExcelWorkbook workBook,GEAEExcelFont objNormalFontGESerif8)
        throws GEAEOfficeException
    {
        if(objNormalFontGESerif8 == null)
        {
            objNormalFontGESerif8 = workBook.createFont();
        }
        //setting it to GE Serif font.
        objNormalFontGESerif8.setFontName(GEAEExcelConstants.FONT_GE_SERIF);
        //setting it to normal font.
        objNormalFontGESerif8.setBoldweight(GEAEExcelConstants.BOLDWEIGHT_NORMAL);
        //setting the height of the font to 8.
        objNormalFontGESerif8.setFontHeight((short) 8);

        return objNormalFontGESerif8;
    }

    /**
     * Method name: getStyleObjLeftNormalHidden
     * Brief logic:  This method will return the excel cell style object with normal font
     * size 8 and hidden
     * @param   workBook (GEAEExcelWorkbook)
     * @return  GEAEExcelCellStyle
     */
    private GEAEExcelCellStyle getStyleObjLeftNormalHidden(GEAEExcelWorkbook workBook,GEAEExcelCellStyle styleObj)
        throws Exception
    {
        styleObj = workBook.createCellStyle();
        objNormalFontGESerif8 = getNormalFontGESerif8(workBook,objNormalFontGESerif8);
        styleObj = getHiddenStyleObject(styleObj);
        styleObj.setFont(objNormalFontGESerif8);
        styleObj.setDataFormat((short) 8);
        return styleObj;
    }

    /**
     * Method name: getHiddenStyleObject
     * Brief logic:  This method will set the style object to hidden.
     * @param   wb (GEAEExcelWorkbook)
     * @return  GEAEExcelCellStyle
     */
    private GEAEExcelCellStyle getHiddenStyleObject(GEAEExcelCellStyle style)
        throws GEAEOfficeException {

        //setting it to left alignment.
        style.setHidden(true);
        return style;
    } //end of getHiddenStyleObject method

    /**
     * Method name: getLeftAlignStyleObject
     * Brief logic:  This method will set the style object to left alignment.
     * @param   wb (GEAEExcelWorkbook)
     * @return  GEAEExcelCellStyle
     */
    private GEAEExcelCellStyle getLeftAlignStyleObject(GEAEExcelCellStyle style)
        throws GEAEOfficeException {
        //setting it to left alignment.
        style.setAlignment(GEAEExcelConstants.ALIGN_LEFT);
        style.setVerticalAlignment(GEAEExcelConstants.VERTICAL_TOP);
        return style;
    } //end of getLeftAlignStyleObject method
    /**
     * Method name: generateEngRevReport
     * Brief logic:  This is the main method. This is being called from the service method
     * This method will actually get the result set from the database and pass the result set
     * of each forecast number with revision to the getXLSDataSheet method.
     * @version 1.0
     * @param   request (HttpServletRequest)
     * @return
     * @since   JDK1.0
     */
    private GEAEExcelWorkbook generateEngRevReport(HttpServletRequest request) throws Exception
    {
        int intColumnIndex = 0;
        int intColumnCount = 0;

        String strPrevModule = null;
        String strModule =null;
        String strCatalogId = null;
        String strCM = null;
        String strRole = null;
        ArrayList arrInParam  = null ;
        ArrayList arrOutParam = null ;
        ArrayList arrlstPriceCost   = null ;

        GEAEResultSet rsCatalogueDetails = null;
        GEAERow row = null;
        GEAECell cell= null;
        GEAEExcelFont fontObj = null;
        GEAEExcelCellStyle styleObj = null;
        eCRDUser objeCRDNewUser = null;

        double dblCost = 0.0;
        double dblPrice = 0.0;

        double dblCostTotal = 0.0;
        double dblPriceTotal = 0.0;

        try
        {
            arrInParam = new ArrayList();
            arrOutParam = new ArrayList();
            intRowIndex = 0;
            strCatalogId = eCRDUtil.verifyNull(request.getParameter("hdnCatalogValue"));
            //strEngineModel = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, "Engine"));
            rsCatalogueDetails = new GEAEResultSet();

            arrInParam.add(strCatalogId);
            //arrInParam.add(strEngineModel);

            objeCRDNewUser =  (eCRDUser)eCRDUtil.getFromSessionApp(request, "objeCRDUser");
            strRole = objeCRDNewUser.getRole();
            strActionId =eCRDConstants.getActionId("eCRD_ENG_REV_YIELD");

            arrOutParam = eCRDDBMediator.doDBOperation(strActionId, arrInParam);

            rsCatalogueDetails = (GEAEResultSet) arrOutParam.get(0);

            workBook = (GEAEExcelWorkbook) GEAEWorkbookFactory.getWorkbook(0);



            if (rsCatalogueDetails == null || rsCatalogueDetails.size() == 0)
            {
                return workBook;
            }

            intRowIndex = 1;
            intColumnIndex = 0;
            arrlstPriceCost = new ArrayList();
            row = null;
            cell= null;
            fontObj = null;
            styleObj = null;
            intColumnCount = rsCatalogueDetails.getColumnCount();
//           14-11-2006 patni checking user role for restricting Guest value Begin
            if(strRole.equals(eCRDConstants.ROLE_GUEST)) {
            intColumnCount = intColumnCount - 6;
            }
//          14-11-2006 patni checking user role for restricting Guest value End
            strPrevModule = "";
//        19-05-2006 patni checking null value Begin
            if (rsCatalogueDetails != null )
            {
//              19-05-2006 patni checking null value End

            while (rsCatalogueDetails.next())
            {
                row = null;
                strModule = rsCatalogueDetails.getString(1);
                /*
                 * if the module is different now then make new shet
                 */
                if (!(strPrevModule.equals(strModule)))
                {

                    /*
                     * calculating CM
                     */
                    if(!"".equals(strPrevModule))
                    {
                        strCM = null;
                        // Change as on 7 Nov 2006
                        //Restricting Guest to view CM
                        if(!strRole.equals(eCRDConstants.ROLE_GUEST)) {
                        strCM = printCMPriceCostAtEnd(dblPrice,dblCost,intRowIndex);
                        }
                        dblPriceTotal =  dblPriceTotal + dblPrice  ;
                        dblCostTotal  =  dblCostTotal + dblCost  ;
                        arrlstPriceCost.add(strPrevModule+"^"+dblPrice+"^"+dblCost+"^"+strCM);
                        dblCost = 0.0;
                        dblPrice = 0.0;

                    }
                    sheetDetails = null ;
                    sheetDetails = (GEAEExcelSheet) workBook.createSheet(strModule);
                    intRowIndex = 0;
                    row = sheetDetails.createRow((short) intRowIndex);

                    fontObj = eCRDStyleObjects.getBoldFontArial10(workBook);
                    styleObj = eCRDStyleObjects.getLeftAlignStyleObject(workBook);

                    styleObj.setFont(fontObj);
                    styleObj.setWrapText(true);

                    for (intColumnIndex = 0; intColumnIndex <= intColumnCount - 2; intColumnIndex++)
                    {
                        /*
                         * printing column headings
                         */
                        cell = row.createCell((short) intColumnIndex);
                        excelCell = (GEAEExcelCell) cell;
                        excelCell.setCellStyle(styleObj);
                        excelCell.setCellValue(rsCatalogueDetails.getColumnHeading(intColumnIndex + 2));
                        excelCell= null;
                        cell=null;

                    }
                    sheetDetails.setDefaultColumnWidth((short) 15);

                    fontObj = eCRDStyleObjects.getNormalFontArial10(workBook);
                    styleObj = eCRDStyleObjects.getLeftAlignStyleObject(workBook);

                    styleObj.setFont(fontObj);
                    styleObj.setWrapText(true);

                }
                strPrevModule = strModule;
                intRowIndex++;
                row = sheetDetails.createRow((short) intRowIndex);
                /*
                 * print the data
                 */
                for (intColumnIndex = 0; intColumnIndex <= intColumnCount - 2; intColumnIndex++)
                {
                    cell = row.createCell((short) intColumnIndex);
                    excelCell = (GEAEExcelCell) cell;
                    excelCell.setCellStyle(styleObj);
                    excelCell.setCellValue(rsCatalogueDetails.getString(intColumnIndex + 2));
                    excelCell=null;
                    cell=null;
                }
                /*
                 * calcuation of price and cost at module level
                 */

                 // 02-May-2006 Patni - Since Repair Seq Id is included in the resultset, the column numbers should be modified - Begin
                 dblPrice      =  dblPrice + eCRDUtil.verifyDouble(rsCatalogueDetails.getString(23));
                 dblCost       =  dblCost  + eCRDUtil.verifyDouble(rsCatalogueDetails.getString(24));
                 // 02-May-2006 Patni - Since Repair Seq Id is included in the resultset, the column numbers should be modified - End
            }
//          19-05-2006 patni checking null value Begin
            } // end if
//          19-05-2006 patni checking null value End
            strCM = null;
            //--------------- Change as on 7 Nov 2006
            if(!strRole.equals(eCRDConstants.ROLE_GUEST))
            {
                strCM = printCMPriceCostAtEnd(dblPrice,dblCost,intRowIndex);
            }

            //strCM = printCMPriceCostAtEnd(dblPrice,dblCost,intRowIndex);

            dblPriceTotal =  dblPriceTotal + dblPrice  ;
            dblCostTotal  =  dblCostTotal + dblCost  ;

            arrlstPriceCost.add(strModule+"^"+dblPrice+"^"+dblCost+"^"+strCM);
            dblCost = 0.0;
            dblPrice = 0.0;
            strCM = null;
            if(dblPriceTotal!=0)
            {
                strCM = ((dblPriceTotal - dblCostTotal)/dblPriceTotal)+"";
            }
            else
            {
                strCM ="0.0";
            }
            arrlstPriceCost.add("Total"+"^"+dblPriceTotal+"^"+dblCostTotal+"^"+strCM);

            instantiateStyleObjects();
//          14-11-2006 patni checking user role for restricting Guest for Summary value Begin
            if(!strRole.equals(eCRDConstants.ROLE_GUEST)) {

            sheetDetails = (GEAEExcelSheet) workBook.createSheet("Summary");
            sheetDetails.setDefaultColumnWidth((short) 20);

            fontObj = eCRDStyleObjects.getBoldFontArial10(workBook);
            styleObj = eCRDStyleObjects.getLeftAlignStyleObject(workBook);

            styleObj.setFont(fontObj);
            styleObj.setWrapText(true);

            row  = sheetDetails.createRow((short) 0);
            cell = row.createCell((short) 0);
            excelCell = (GEAEExcelCell) cell;
            excelCell.setCellStyle(styleObj);
            excelCell.setCellValue("Report Summary");
            excelCell  = null;
            cell       = null;
            row        = null;

            printSummarySheet(arrlstPriceCost);
            }
            return workBook;
//          14-11-2006 patni checking user role for restricting Guest for Summary value End
        }

        finally
        {
            strPrevModule = null;
            //strEngineModel = null;
            strCatalogId = null;

            arrInParam = null;
            arrOutParam = null;
            rsCatalogueDetails = null;
            row = null;
            cell= null;
            fontObj = null;
            styleObj = null;
            strModule =null;
        }
    }
    /*
     * Method to print the summary sheet
     */
     private void printSummarySheet(ArrayList arrlstPriceCost )throws Exception
     {
        StringTokenizer strtkn = null;
        String strEachElement  = null;
        String strEachToken    = null;
        GEAERow row = null;
        GEAECell cell= null;
        GEAEExcelFont fontObj = null;
        GEAEExcelCellStyle styleObj = null;

        double dblEachValue = 0.0;
        int intRowIndex = 0;
        int intColCount = 0;
        try
        {
            if(arrlstPriceCost!=null && arrlstPriceCost.size() >0)
            {
                intRowIndex  = 2;
                row = sheetDetails.createRow((short)intRowIndex);

                styleObj = eCRDStyleObjects.getLeftAlignStyleObject(workBook);
                fontObj = eCRDStyleObjects.getBoldFontArial10(workBook);
                styleObj.setFont(fontObj);
                styleObj.setWrapText(true);

                cell = row.createCell((short)0);
                excelCell = (GEAEExcelCell) cell;
                excelCell.setCellStyle(styleObj);
                excelCell.setCellValue("Engine Module");
                excelCell= null;
                cell=null;

                cell = row.createCell((short)1);
                excelCell = (GEAEExcelCell) cell;
                excelCell.setCellStyle(styleObj);
                excelCell.setCellValue("Total Revenue Per SV");
                excelCell= null;
                cell=null;

                cell = row.createCell((short)2);
                excelCell = (GEAEExcelCell) cell;
                excelCell.setCellStyle(styleObj);
                excelCell.setCellValue("Total Cost Per SV");
                excelCell= null;
                cell=null;

                cell = row.createCell((short)3);
                excelCell = (GEAEExcelCell) cell;
                excelCell.setCellStyle(styleObj);
                excelCell.setCellValue("CM %");
                excelCell= null;
                cell=null;

                for(int intCount=0;intCount< arrlstPriceCost.size();intCount++)
                {
                    intRowIndex++;
                    row = sheetDetails.createRow((short)intRowIndex);

                    strEachElement  = (String)arrlstPriceCost.get(intCount);
                    strtkn = new StringTokenizer(strEachElement ,"^");
                    intColCount = 0;
                    while(strtkn.hasMoreTokens())
                    {
                        styleObj = null;
                        fontObj = null;
                        cell = row.createCell((short)intColCount );
                        excelCell = (GEAEExcelCell) cell;
                        if(intColCount==0)
                        {
                            styleObj = eCRDStyleObjects.getLeftAlignStyleObject(workBook);
                            fontObj = eCRDStyleObjects.getBoldFontArial10(workBook);
                            styleObj.setFont(fontObj);
                            styleObj.setWrapText(true);
                        }
                        else if(intColCount==1 || intColCount == 2)
                        {
                            styleObj = eCRDStyleObjects.getStyleObjLeftNormal10Cur(workBook);
                            if((intCount+1)== arrlstPriceCost.size())
                            {
                                fontObj = eCRDStyleObjects.getBoldFontArial10(workBook);
                            }
                            else
                            {
                                fontObj = eCRDStyleObjects.getNormalFontArial10(workBook);
                            }
                            styleObj.setFont(fontObj);
                            styleObj.setWrapText(true);
                        }
                        else if(intColCount==3)
                        {
                            styleObj = eCRDStyleObjects.getStyleObjLeftNormal10Per(workBook);
                            if((intCount+1)== arrlstPriceCost.size())
                            {
                                fontObj = eCRDStyleObjects.getBoldFontArial10(workBook);
                            }
                            else
                            {
                                fontObj = eCRDStyleObjects.getNormalFontArial10(workBook);
                            }
                            styleObj.setFont(fontObj);
                            styleObj.setWrapText(true);

                        }
                        excelCell.setCellStyle(styleObj);
                        strEachToken = strtkn.nextToken();
                        if(intColCount==0)
                        {
                            excelCell.setCellValue(strEachToken);
                        }
                        else
                        {
                            dblEachValue = Double.parseDouble(eCRDUtil.Format(Double.parseDouble(strEachToken)));
                            if(intColCount==3)
                            {
                                if(dblEachValue==0.0)
                                {
                                    excelCell.setCellValue("-");
                                }
                                else
                                {
                                    excelCell.setCellValue(dblEachValue );
                                }
                            }
                            else
                            {
                                excelCell.setCellValue(dblEachValue );
                            }

                        }
                        excelCell= null;
                        cell=null;
                        styleObj = null;
                        fontObj = null;
                        intColCount++;
                    }
                    styleObj = null;
                    fontObj = null;

                }

            }
        }
        finally
        {
            strtkn = null;
            strEachElement  = null;

            row = null;
            cell= null;
            fontObj = null;
            styleObj = null;
        }
     }
    /*
     * method is usde to print the cost and price info at the end of the sheet
     */
    private String printCMPriceCostAtEnd(double dblPrice,double dblCost,int intRowIndex)throws Exception
    {
        double dblCM =0.0;
        GEAERow row = null;
        GEAECell cell= null;
        GEAEExcelFont fontObj = null;
        GEAEExcelCellStyle styleObj = null;


        try
        {
            styleObj = eCRDStyleObjects.getLeftAlignStyleObject(workBook);
            fontObj = eCRDStyleObjects.getBoldFontArial10(workBook);
            styleObj.setFont(fontObj);
            styleObj.setWrapText(true);

            if(dblPrice!=0)
            {
                dblCM = (dblPrice - dblCost)/dblPrice;
            }
            /*
             * printing Cost and price and CM at the end of the sheet
             */
            intRowIndex+=2;
            row = sheetDetails.createRow((short) intRowIndex);

            styleObj = eCRDStyleObjects.getLeftAlignStyleObject(workBook);
            fontObj = eCRDStyleObjects.getBoldFontArial10(workBook);
            styleObj.setFont(fontObj);
            styleObj.setWrapText(true);


            cell = row.createCell((short)1);
            excelCell = (GEAEExcelCell) cell;
            excelCell.setCellStyle(styleObj);
            excelCell.setCellValue("Total Revenue Per SV");
            excelCell= null;
            cell=null;

            styleObj = null;
            fontObj = null;
            styleObj = eCRDStyleObjects.getStyleObjLeftNormal10Cur(workBook);
            fontObj = eCRDStyleObjects.getNormalFontArial10(workBook);
            styleObj.setFont(fontObj);
            styleObj.setWrapText(true);


            cell = row.createCell((short) 2);
            excelCell = (GEAEExcelCell) cell;
            excelCell.setCellStyle(styleObj);
            excelCell.setCellValue(dblPrice);
            excelCell= null;
            cell=null;
            row = null;
            intRowIndex+=1;
            row = sheetDetails.createRow((short) intRowIndex);
            styleObj = null;
            fontObj = null;
            styleObj = eCRDStyleObjects.getLeftAlignStyleObject(workBook);
            fontObj = eCRDStyleObjects.getBoldFontArial10(workBook);
            styleObj.setFont(fontObj);
            styleObj.setWrapText(true);

            cell = row.createCell((short)1);
            excelCell = (GEAEExcelCell) cell;
            excelCell.setCellStyle(styleObj);
            excelCell.setCellValue("Total Cost Per SV");
            excelCell= null;
            cell=null;

            styleObj = null;
            fontObj = null;
            styleObj = eCRDStyleObjects.getStyleObjLeftNormal10Cur(workBook);
            fontObj = eCRDStyleObjects.getNormalFontArial10(workBook);
            styleObj.setFont(fontObj);
            styleObj.setWrapText(true);

            cell = row.createCell((short) 2);
            excelCell = (GEAEExcelCell) cell;
            excelCell.setCellStyle(styleObj);
            excelCell.setCellValue(dblCost);
            excelCell= null;
            cell=null;

            intRowIndex+=1;

            row = null;
            row = sheetDetails.createRow((short) intRowIndex);
            styleObj = null;
            fontObj = null;
            styleObj = eCRDStyleObjects.getLeftAlignStyleObject(workBook);
            fontObj = eCRDStyleObjects.getBoldFontArial10(workBook);
            styleObj.setFont(fontObj);
            styleObj.setWrapText(true);

            cell = row.createCell((short)1);
            excelCell = (GEAEExcelCell) cell;
            excelCell.setCellStyle(styleObj);
            excelCell.setCellValue("CM %");
            excelCell= null;
            cell=null;

            styleObj = null;
            fontObj = null;
            styleObj = eCRDStyleObjects.getStyleObjLeftNormal10Per(workBook);
            fontObj = eCRDStyleObjects.getNormalFontArial10(workBook);
            styleObj.setFont(fontObj);
            styleObj.setWrapText(true);

            cell = row.createCell((short) 2);
            excelCell = (GEAEExcelCell) cell;
            excelCell.setCellStyle(styleObj);
            if(dblCM==0)
            {
                excelCell.setCellValue("-");
            }
            else
            {
                excelCell.setCellValue(dblCM);
            }

            excelCell= null;
            cell=null;
            return dblCM+"";
        }
        finally
        {
            row = null;
            cell= null;
            fontObj = null;
            styleObj = null;
        }
    }
    /**
     * Method name: generateAdhocReport
     * Brief logic:  This is the main method. This is being called from the service method
     * This method will actually get the result set from the database and pass the result set
     * of each forecast number with revision to the getXLSDataSheet method.
     * @version 1.0
     * @param   request (HttpServletRequest)
     * @return
     * @since   JDK1.0
     */
    private GEAEExcelWorkbook generateAdhocReport(HttpServletRequest request) throws Exception
    {
        
      
         String strRole = null;
         GEAEResultSet rsCatalogueDetails = null;
        
         ArrayList arrlstReturn = null ;
         eCRDUser objeCRDNewUser = null;
         try
         {
             arrlstReturn = getAdhocData(request);
             objeCRDNewUser =  (eCRDUser)eCRDUtil.getFromSessionApp(request, "objeCRDUser");
             strRole = objeCRDNewUser.getRole();
            
             
             ArrayList arrlstResultSet = null;
             ArrayList arrlstEng = null;
             ArrayList arrlstCrit = null;
             
             arrlstResultSet=(ArrayList)arrlstReturn.get(0);
             arrlstEng=(ArrayList)arrlstReturn.get(1);
             arrlstCrit=(ArrayList)arrlstReturn.get(2);
             

             workBook = (GEAEExcelWorkbook) GEAEWorkbookFactory.getWorkbook(0);

             generateCriteriaSheet( (StringBuffer)arrlstCrit.get(0));
             
             //Added By Santosh

             String strEngMdl=null;
             
             for(int i=0;i<arrlstResultSet.size();i++)
             {
             	rsCatalogueDetails = (GEAEResultSet)arrlstResultSet.get(i);
             	strEngMdl = (String)arrlstEng.get(i);
             	
             	generateSheetEngMdlAdhoc(rsCatalogueDetails,strEngMdl,strRole);
             	
             }
             
             //Ended By Santosh

         }
         finally
         {
        	 rsCatalogueDetails = null;
         }
         return workBook;
    }
    
  
  //Added By Santosh
    /**
     * Method name: generateSheetEngMdlAdhoc
     * This method will actually get the sheet for differnt Engine Model
     * of each forecast number with revision to the getXLSDataSheet method.
     * @version 1.0
     * @param   rsCatalogueDetails (GEAEResultSet)
     * @param   strEngMdl (String)
     * @param   strRole (String)
     * @return
     * @since   JDK1.0
     */
    private void generateSheetEngMdlAdhoc(GEAEResultSet rsCatalogueDetails,String strEngMdl,String strRole)throws Exception
    {
       
       	 	int intColumnIndex = 0;
            int intColumnCount = 0;
            GEAERow row = null;
            GEAECell cell= null;
            GEAEExcelFont fontObj = null;
            GEAEExcelCellStyle styleObj = null;
            
            
            try
            {
           	 sheetDetails = (GEAEExcelSheet) workBook.createSheet(strEngMdl);
                sheetDetails.setDefaultColumnWidth((short) 15);
                intRowIndex = 0;
                row = sheetDetails.createRow((short) intRowIndex);

                fontObj = eCRDStyleObjects.getBoldFontArial10(workBook);
                styleObj = eCRDStyleObjects.getLeftAlignStyleObject(workBook);

                styleObj.setFont(fontObj);
                styleObj.setWrapText(true);

                if (rsCatalogueDetails == null || rsCatalogueDetails.size() == 0)
                {
                    cell = row.createCell((short) intColumnIndex);
                    excelCell = (GEAEExcelCell) cell;
                    excelCell.setCellStyle(styleObj);
                    excelCell.setCellValue("Search Resulted in No rows.Please select different filter criteria");
                    excelCell= null;
                    cell=null;
                    //return workBook;
                }
                else if(rsCatalogueDetails.size()>65000)
                {
                    cell = row.createCell((short) intColumnIndex);
                    excelCell = (GEAEExcelCell) cell;
                    excelCell.setCellStyle(styleObj);
                    excelCell.setCellValue("Search Resulted in too many rows.Please select more filter criteria");
                    excelCell= null;
                    cell=null;
                    //return workBook;
                }
                else
                {
                    intColumnCount = rsCatalogueDetails.getColumnCount();
                    int count = 0;
                    if(strRole.equals(eCRDConstants.ROLE_GUEST)){

                        for (intColumnIndex = 0; intColumnIndex < 11 ; intColumnIndex++)
                          {
                           cell = row.createCell((short) intColumnIndex);

                           excelCell = (GEAEExcelCell) cell;
                           excelCell.setCellStyle(styleObj);
                           excelCell.setCellValue(rsCatalogueDetails.getColumnHeading(intColumnIndex + 1));
                           excelCell= null;
                           cell=null;
                           count++;
                          }
                        for (intColumnIndex = 13; intColumnIndex <15 ; intColumnIndex++)
                        {

                         cell = row.createCell((short) count);

                         excelCell = (GEAEExcelCell) cell;
                         excelCell.setCellStyle(styleObj);
                         excelCell.setCellValue(rsCatalogueDetails.getColumnHeading(intColumnIndex + 1));
                         excelCell= null;
                         cell=null;
                         count++;
                        }

                    }else {

                        for (intColumnIndex = 0; intColumnIndex < intColumnCount ; intColumnIndex++)
                        {
                            cell = row.createCell((short) intColumnIndex);
                            excelCell = (GEAEExcelCell) cell;
                            excelCell.setCellStyle(styleObj);
                            excelCell.setCellValue(rsCatalogueDetails.getColumnHeading(intColumnIndex + 1));

                            excelCell= null;
                            cell=null;
                       }
                    }

                    count = 0;
                    row = null;
                    fontObj = null;
                    styleObj = null;
                    //strEngModel = "";
                    //strPrevEngModel = "";
                    fontObj = eCRDStyleObjects.getNormalFontArial10(workBook);
                    styleObj = eCRDStyleObjects.getLeftAlignStyleObject(workBook);

                    styleObj.setFont(fontObj);
                    styleObj.setWrapText(true);
//                19-05-2006 patni checking null value Begin
                    if(rsCatalogueDetails != null)
                   {
//                      19-05-2006 patni checking null value End

                    while (rsCatalogueDetails.next())
                    {
                        intRowIndex++;
                        /*strEngModel = rsCatalogueDetails.getString("Engine Model");
                        if(!strEngModel.equals(strPrevEngModel) && !"".equals(strPrevEngModel))
                        {
                            intRowIndex++;
                        }*/
                        row = sheetDetails.createRow((short) intRowIndex);

                        /*
                         * print the data
                         */
                        if(strRole.equals(eCRDConstants.ROLE_GUEST)){

                              for (intColumnIndex = 0; intColumnIndex < 11 ; intColumnIndex++)
                                {
                                 cell = row.createCell((short) intColumnIndex);
                                 excelCell = (GEAEExcelCell) cell;
                                 excelCell.setCellStyle(styleObj);
                                 excelCell.setCellValue(rsCatalogueDetails.getString(intColumnIndex + 1));
                                 excelCell= null;
                                 cell=null;
                                 count++;
                                }
                              for (intColumnIndex = 13; intColumnIndex <15 ; intColumnIndex++)
                              {

                               cell = row.createCell((short) count);

                               excelCell = (GEAEExcelCell) cell;
                               excelCell.setCellStyle(styleObj);
                               excelCell.setCellValue(rsCatalogueDetails.getString(intColumnIndex + 1));
                               excelCell= null;
                               cell=null;
                               count++;
                              }
                              count=0;
                          }else {

                              for (intColumnIndex = 0; intColumnIndex < intColumnCount ; intColumnIndex++)
                              {
                                cell = row.createCell((short) intColumnIndex);
                                excelCell = (GEAEExcelCell) cell;
                                excelCell.setCellStyle(styleObj);
                                
                                
                              //beginning_rishabh_adhoc_tm
	                                
	                                String value = rsCatalogueDetails.getString(intColumnIndex + 1);
	                            	if ( value.contains("GE Passport"))
	                            	{	
	                                    value=value.replace("GE Passport","GE Passport\u2122");
	                            	}
	                            	excelCell.setCellValue(value);
                          		
                              //ending_rishabh_adhoc_tm
                                
                                
                                //excelCell.setCellValue(rsCatalogueDetails.getString(intColumnIndex+1 ));
                                excelCell=null;
                                cell=null;
                              }
                          }
                        row = null;

                        //strPrevEngModel = strEngModel ;
                    }
//                19-05-2006 patni checking null value Begin
                   } // end if
//                  19-05-2006 patni checking null value End
                }
                instantiateStyleObjects(); 
            }
            
            finally{
            	cell=null;
            	row = null;
            }
       }
   //Ended By Santosh
    /**
     * Method name: getAdhocData
     * Brief logic:  This is the main method. This is being called from the service method
     * This method will actually get the result set from the database and pass the result set
     * of each forecast number with revision to the getXLSDataSheet method.
     * @version 1.0
     * @param   request (HttpServletRequest)
     * @return  ArrayList
     * @since   JDK1.0
     */
    
  //Adding Customer Adhoc Repair Reports started DES1121903 sujitha
    private GEAEExcelWorkbook generateCustdhocReport(HttpServletRequest request) throws Exception
    {
    	
         String strRole = null;
         GEAEResultSet rsCatalogueDetails = null;
         ArrayList arrlstReturn = null ;
         eCRDUser objeCRDNewUser = null;
         try
         {
        	 System.out.println("PRATHIMA IN TEST inside the generateCustdhocReport ");
             arrlstReturn = getCustadhocData(request);
             
            
             objeCRDNewUser =  (eCRDUser)eCRDUtil.getFromSessionApp(request, "objeCRDUser");
             strRole = objeCRDNewUser.getRole();
            
             ArrayList arrlstResultSet = null;
             ArrayList arrlstEng = null;
             ArrayList arrlstCrit = null;
             
             arrlstResultSet=(ArrayList)arrlstReturn.get(0);
             arrlstEng=(ArrayList)arrlstReturn.get(1);
             arrlstCrit=(ArrayList)arrlstReturn.get(2);
             

             workBook = (GEAEExcelWorkbook) GEAEWorkbookFactory.getWorkbook(0);

             generateCriteriaSheet( (StringBuffer)arrlstCrit.get(0));
             
             //Added By Santosh
             

             String strEngMdl=null;
             
             for(int i=0;i<arrlstResultSet.size();i++)
             {
             	rsCatalogueDetails = (GEAEResultSet)arrlstResultSet.get(i);
             	strEngMdl = (String)arrlstEng.get(i);
             	
             	generateSheetEngMdlCustadhoc(rsCatalogueDetails,strEngMdl,strRole);
             	
             }
             
             //Ended By Santosh

         }
         finally
         {
        	 rsCatalogueDetails = null;
         }
         return workBook;
    }
    
    //Added By Santosh
    
    
    private GEAEExcelWorkbook generateEnhancedCustadhocReport(HttpServletRequest request) throws Exception
    {
    	
         String strRole = null;
         GEAEResultSet rsCatalogueDetails = null;
         ArrayList arrlstReturn = null ;
         eCRDUser objeCRDNewUser = null;
         try
         {
        	 System.out.println("PRATHIMA IN TEST inside the generateCustdhocReport ");
             arrlstReturn = getEnhanceCustadhocData(request);
             
            
             objeCRDNewUser =  (eCRDUser)eCRDUtil.getFromSessionApp(request, "objeCRDUser");
             strRole = objeCRDNewUser.getRole();
            
             ArrayList arrlstResultSet = null;
             ArrayList arrlstEng = null;
             ArrayList arrlstCrit = null;
             
             arrlstResultSet=(ArrayList)arrlstReturn.get(0);
             arrlstEng=(ArrayList)arrlstReturn.get(1);
             arrlstCrit=(ArrayList)arrlstReturn.get(2);
             

             workBook = (GEAEExcelWorkbook) GEAEWorkbookFactory.getWorkbook(0);

             generateCriteriaSheet( (StringBuffer)arrlstCrit.get(0));
             
             //Added By Santosh
             

             String strEngMdl=null;
             
             for(int i=0;i<arrlstResultSet.size();i++)
             {
             	rsCatalogueDetails = (GEAEResultSet)arrlstResultSet.get(i);
             	strEngMdl = (String)arrlstEng.get(i);
             	
             	generateSheetEngMdlCustadhoc(rsCatalogueDetails,strEngMdl,strRole);
             	
             }
             
             //Ended By Santosh

         }
         finally
         {
        	 rsCatalogueDetails = null;
         }
         return workBook;
    }
    
    
    
  //Adding Customer Adhoc Repair Reports ended
    
    private ArrayList getAdhocData(HttpServletRequest request) throws Exception
    {
        String strActionId = null;
        String isRepairNumNotPresent = null;
        String isPartNumNotPresent = null;
        String strPriceWhere = null;
        String strCostWhere = null;
        String strPriceTypeWhere = null;
        String strInTATWhere = null;
        String strInPriceWhere = null;
        String strSeqCols = null;
        String strSelCols = null;
        String strEachSeqCol = null;
        String strEachSelCol = null;
        String strIsCostReqd = null;
// 11-05-2006 Patni added Engine model Field Begin
        String strEngModel  = null;
        String strEngDesc = null;
// 11-05-2006 Patni added Engine model Field End
     // Added By Santosh added Site Field 
        String strSite = null;
        String strSiteDesc = null;
     // Added By Santosh added Site Field 
        StringBuffer strbuffWhere = null;
        StringBuffer strbuffSel = null;
        StringBuffer strbuffCriteria = null;
        StringBuffer strbufflstSite = null;

        StringTokenizer strTkn = null;

        HashMap hmSelectedCols = null;

        ArrayList arrlstInParam = null;
        ArrayList arrlstOutParam = null;
        ArrayList arrlstReturn = null;
        GEAEResultSet geaeRsetData = null;
        try
        {
            strbuffCriteria =  new StringBuffer();
            strSeqCols = eCRDUtil.verifyNull(request.getParameter("hdnSeqOfColums"));
            strIsCostReqd = eCRDUtil.verifyNull(request.getParameter("hdnIsCostReqd"));

            strSelCols= eCRDUtil.verifyNull(request.getParameter("hdnSelColumns"));
           
            strInTATWhere = eCRDUtil.verifyNull(request.getParameter("cmb_incTAT"));
            strInPriceWhere= eCRDUtil.verifyNull(request.getParameter("cmb_incPrice"));

            strActionId= eCRDConstants.getActionId("eCRD_GET_ADHOC_DATA");
            strTkn = new StringTokenizer(strSelCols,eCRDConstants.STRCOLUMNDELIM);
            hmSelectedCols = new HashMap();
            while(strTkn.hasMoreTokens())
            {
                strEachSelCol = strTkn.nextToken();
                hmSelectedCols.put(strEachSelCol,strEachSelCol);
            }
            strTkn = new StringTokenizer(strSeqCols,eCRDConstants.STRCOLUMNDELIM);
            strbuffSel = new StringBuffer();
            strbuffSel.append("SELECT ");
            while(strTkn.hasMoreTokens())
            {
                strEachSeqCol = strTkn.nextToken();
                if(hmSelectedCols.containsKey(strEachSeqCol))
                {
                    strbuffSel.append(eCRDConstants.getAdhocColumns(strEachSeqCol)+",");
                }
                else if("LOCATION".equals((strEachSeqCol)))
                {
                    if(hmSelectedCols.containsKey("LOCATION_IND"))
                    {
                        strbuffSel.append(eCRDConstants.getAdhocColumns("LOCATION_IND")+",");
                    }
                }

            }
            System.out.println("Santosh Select Statements"+strbuffSel);

            isRepairNumNotPresent = eCRDUtil.verifyNull(request.getParameter("hdnRepairNum"));
            if("Y".equals(isRepairNumNotPresent))
            {
                strbuffCriteria.append("Repair Number Present");
                strbuffCriteria.append("^");
                strbuffCriteria.append("N");
                strbuffCriteria.append("$");
            }
            isPartNumNotPresent = eCRDUtil.verifyNull(request.getParameter("hdnPartNum"));
            if("Y".equals(isRepairNumNotPresent))
            {
                strbuffCriteria.append("Part Number Present");
                strbuffCriteria.append("^");
                strbuffCriteria.append("N");
                strbuffCriteria.append("$");
            }
            strInTATWhere =eCRDUtil.verifyNull(request.getParameter("cmb_incTAT"));
            if("Select..".equalsIgnoreCase(strInTATWhere))
            {
                strInTATWhere = "";
            }
            else
            {
                strbuffCriteria.append("Incremental TAT");
                strbuffCriteria.append("^");
                strbuffCriteria.append(strInTATWhere);
                strbuffCriteria.append("$");
            }
            strInPriceWhere = eCRDUtil.verifyNull(request.getParameter("cmb_incPrice"));
            if("Select..".equalsIgnoreCase(strInPriceWhere))
            {
                strInPriceWhere = "";
            }
            else
            {
                strbuffCriteria.append("Incremental Price");
                strbuffCriteria.append("^");
                strbuffCriteria.append(strInPriceWhere);
                strbuffCriteria.append("$");
            }
            strbuffWhere = new StringBuffer();
            strPriceWhere = eCRDUtil.verifyNull(request.getParameter("cmb_wherePrice"));

            if("Select..".equalsIgnoreCase(strPriceWhere))
            {
                strPriceWhere = "";
            }
            else
            {
                strbuffWhere.append(" AND "+eCRDConstants.getAdhocColumns("PRICE_WHERE"));
                strbuffWhere.append(strPriceWhere);
                strbuffWhere.append(eCRDUtil.verifyNull(request.getParameter("txt_Price"))+" ");

                strbuffCriteria.append("Repair Price");
                strbuffCriteria.append("^");
                strbuffCriteria.append(eCRDUtil.verifyNull(request.getParameter("cmb_wherePrice_text")));
                strbuffCriteria.append("^");
                strbuffCriteria.append(eCRDUtil.verifyNull(request.getParameter("txt_Price")));
                strbuffCriteria.append("$");
            }
            strCostWhere = eCRDUtil.verifyNull(request.getParameter("cmb_whereCost"));
            if("Select..".equalsIgnoreCase(strCostWhere))
            {
                strCostWhere = "";
            }
            else
            {
                strbuffWhere.append(" AND "+eCRDConstants.getAdhocColumns("COST_WHERE"));
                strbuffWhere.append(strCostWhere);
                strbuffWhere.append(eCRDUtil.verifyNull(request.getParameter("txt_Cost"))+" ");

                strbuffCriteria.append("Repair Cost");
                strbuffCriteria.append("^");
                strbuffCriteria.append(eCRDUtil.verifyNull(request.getParameter("cmb_whereCost_text")));
                strbuffCriteria.append("^");
                strbuffCriteria.append(eCRDUtil.verifyNull(request.getParameter("txt_Cost")));
                strbuffCriteria.append("$");

            }
            strPriceTypeWhere =eCRDUtil.verifyNull(request.getParameter("cmb_wherePriceType"));
            if("Select..".equalsIgnoreCase(strPriceTypeWhere))
            {
                strPriceTypeWhere = "";
            }
            else
            {
                strbuffWhere.append(" AND "+eCRDConstants.getAdhocColumns("PRICE_TYPE_WHERE"));
                strbuffWhere.append(strPriceTypeWhere);
                strbuffWhere.append("'"+eCRDUtil.verifyNull(request.getParameter("cmb_priceType"))+"' ");

                strbuffCriteria.append("Price Type");
                strbuffCriteria.append("^");
                strbuffCriteria.append(eCRDUtil.verifyNull(request.getParameter("cmb_wherePriceType_text")));
                strbuffCriteria.append("^");
                strbuffCriteria.append(eCRDUtil.verifyNull(request.getParameter("cmb_priceType")));
                strbuffCriteria.append("$");

            }
         // Added By Santosh For Site
            strSite = eCRDUtil.verifyNull(request.getParameter("cmb_site"));
            strSiteDesc = eCRDUtil.verifyNull(request.getParameter("cmb_site_test"));
           
            strTkn = new StringTokenizer(strSite,eCRDConstants.STRCOLUMNDELIM);
            String strAll = null;
            String strsite = null;
            String strst=null;
            strbufflstSite = new StringBuffer();
            while(strTkn.hasMoreTokens())
            {
            	strsite=(String)strTkn.nextToken();
            	if("ALL".equals(strsite))
            	{
            		strAll=strsite;
            		break;
            	}
            	else
            	{
            		strbufflstSite.append("'");
            		strbufflstSite.append(strsite);
            		strbufflstSite.append("'");
            		strbufflstSite.append(",");
            		strsite=null;
            	}
             }
            strbufflstSite.append("'");
            strbufflstSite.append("'");
            System.out.println("Santosh all the site after tokenizer"+strbufflstSite);
            
            if("ALL".equalsIgnoreCase(strAll))
            {
            	strSite="";
            	strbuffCriteria.append("Site");
                strbuffCriteria.append("^");
                strbuffCriteria.append(" ");
                strbuffCriteria.append("^");
                strbuffCriteria.append("ALL");
                strbuffCriteria.append("$");
            }
            else
            {
            	strbuffWhere.append(" AND "+eCRDConstants.getEnhancedAdhocColumns("LOCATION_WHERE"));
            	strbuffWhere.append(" IN (");
            	strbuffWhere.append(strbufflstSite);
            	strbuffWhere.append(" ) "); 
            	
            	strbuffCriteria.append("Site");
                strbuffCriteria.append("^");
                strbuffCriteria.append(" ");
                strbuffCriteria.append("^");
                strbuffCriteria.append(strSiteDesc);
                strbuffCriteria.append("$");
            	
            	
            }
         // Ended By Santosh For Site
           
             // Added By Santosh
                strEngModel = eCRDUtil.verifyNull(request.getParameter("cmb_engmodel")); 
    
                arrlstInParam = new ArrayList();

                arrlstInParam.add(strbuffSel.toString().substring(0,strbuffSel.toString().length()-1));
                arrlstInParam.add(strbuffWhere.toString());
                arrlstInParam.add(isRepairNumNotPresent);
                arrlstInParam.add(isPartNumNotPresent);
                arrlstInParam.add(strInTATWhere);
                arrlstInParam.add(strInPriceWhere);
                arrlstInParam.add(strIsCostReqd);
                
                
                strTkn = new StringTokenizer(strEngModel,eCRDConstants.STRCOLUMNDELIM);
                arrlstReturn = new ArrayList();
                
                ArrayList arrlstReturn1 = new ArrayList();
                ArrayList arrlstEng = new ArrayList();
                ArrayList arrlstCrit = new ArrayList();
                
                ArrayList tempInparam = new ArrayList();
                
                
                String engModel = null;
                
                while(strTkn.hasMoreTokens())
                {
                	engModel=(String)strTkn.nextToken();            
               	 	arrlstInParam.add(engModel);
               	 	geaeRsetData = getResultSetEngMdlAdhoc(strActionId,arrlstInParam);
               	 	arrlstInParam.remove(arrlstInParam.size()-1);
               	 	arrlstReturn.add(geaeRsetData);
               	 	engModel = null;
                }
                
          
                strEngDesc = eCRDUtil.verifyNull(request.getParameter("cmb_engmodel_text"));
                String strEngTxt = null;
                strTkn = new StringTokenizer(strEngDesc,eCRDConstants.STRCOLUMNDELIM);
                while(strTkn.hasMoreTokens())
                {
                	strEngTxt=(String)strTkn.nextToken();
                	arrlstEng.add(strEngTxt);
                	strEngTxt = null;
                }
                    strbuffCriteria.append("Engine Model");
                    strbuffCriteria.append("^");
                    strbuffCriteria.append(" ");
                    strbuffCriteria.append("^");
                    strbuffCriteria.append(strEngDesc);
                    strbuffCriteria.append("$");
                    arrlstCrit.add(strbuffCriteria);
                    
                    
                    arrlstReturn1.add(arrlstReturn);
                    arrlstReturn1.add(arrlstEng);
                    arrlstReturn1.add(arrlstCrit);
                  //Ended By Santosh

                return arrlstReturn1;
            }
            finally
            {
               
                hmSelectedCols = null;
                strTkn = null;
            }

    }
    //Added by Bora
    
    //Added By Santosh 
    /**
     * Method name: getResultSetEngMdlAdhoc
     * This method will actually get the result set from the database and pass the result set
     * of each forecast number with revision to the getXLSDataSheet method.
     * @version 1.0
     * @param   strActionId (String)
     * @param   arrlstInParam (ArrayList)
     * @return  ResultSet (GEAEResultSet)
     * @since   JDK1.0
     */
    private GEAEResultSet getResultSetEngMdlAdhoc(String strActionId,ArrayList arrlstInParam) throws Exception
    {
    	 ArrayList arrlstOutParam = null;
    	 GEAEResultSet geaeRsetData = null;
    	
    	 
    	 try
    	 {
    		 System.out.println("PRATHIMA IN TEST inside the DB input Param "+arrlstInParam.toString());
    		 arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId,arrlstInParam);
    		 geaeRsetData = (GEAEResultSet)arrlstOutParam.get(0);
    		 System.out.println("INSIDE DB OPERATION resultset size"+geaeRsetData.size());
    		 return geaeRsetData;
    	 }
    	 
    	
    	 finally
    	 {
    		 arrlstOutParam = null;
    		 geaeRsetData = null;
    	 }
    	 
    }
    
    //Ended By Santosh 
    /**
     * Method name: generateEnhancedAdhocReport
     * Brief logic:  This is the main method. This is being called from the service method
     * This method will actually get the result set from the database and pass the result set
     * of each forecast number with revision to the getXLSDataSheet method.
     * @version 1.0
     * @param   request (HttpServletRequest)
     * @return
     * @since   JDK1.0
     */
    private GEAEExcelWorkbook generateEnhancedAdhocReport(HttpServletRequest request) throws Exception
    {
   
        String strRole = null;
        GEAEResultSet rsCatalogueDetails = null;
        ArrayList arrlstReturn = null ;
        eCRDUser objeCRDNewUser = null;
        try
        {
            arrlstReturn = getEnhancedAdhocData(request);

            objeCRDNewUser =  (eCRDUser)eCRDUtil.getFromSessionApp(request, "objeCRDUser");
            strRole = objeCRDNewUser.getRole();
          
            ArrayList arrlstResultSet = null;
            ArrayList arrlstEng = null;
            ArrayList arrlstCrit = null;
            
            arrlstResultSet=(ArrayList)arrlstReturn.get(0);
            arrlstEng=(ArrayList)arrlstReturn.get(1);
            arrlstCrit=(ArrayList)arrlstReturn.get(2);
            

            workBook = (GEAEExcelWorkbook) GEAEWorkbookFactory.getWorkbook(0);

            generateCriteriaSheet( (StringBuffer)arrlstCrit.get(0));
            
            //Added By Santosh
            
            String strEngMdl=null;
            
            for(int i=0;i<arrlstResultSet.size();i++)
            {
            	rsCatalogueDetails = (GEAEResultSet)arrlstResultSet.get(i);
            	strEngMdl = (String)arrlstEng.get(i);
            	
            	generateSheetEngMdl(rsCatalogueDetails,strEngMdl,strRole);
            	
            }
            
            //Ended By Santosh
      }
        finally
        {
        	rsCatalogueDetails = null;
        }
        return workBook;
    }
//End Bora
    
//Added By Santosh
    /**
     * Method name: generateSheetEngMdl
     * This method will actually get the sheet for different Engine Model
     * of each forecast number with revision to the getXLSDataSheet method.
     * @version 1.0
     * @param   rsCatalogueDetails (GEAEResultSet)
     * @param   strEngMdl (String)
     * @param   strRole (String)
     * @return
     * @since   JDK1.0
     */
 private void generateSheetEngMdl(GEAEResultSet rsCatalogueDetails,String strEngMdl,String strRole)throws Exception
 {
    
    	 int intColumnIndex = 0;
         int intColumnCount = 0;
         GEAERow row = null;
         GEAECell cell= null;
         GEAEExcelFont fontObj = null;
         GEAEExcelCellStyle styleObj = null;
         
         
         try
         {
        	 sheetDetails = (GEAEExcelSheet) workBook.createSheet(strEngMdl);
             sheetDetails.setDefaultColumnWidth((short) 15);
             intRowIndex = 0;
             row = sheetDetails.createRow((short) intRowIndex);

             fontObj = eCRDStyleObjects.getBoldFontArial10(workBook);
             styleObj = eCRDStyleObjects.getLeftAlignStyleObject(workBook);

             styleObj.setFont(fontObj);
             styleObj.setWrapText(true);

             if (rsCatalogueDetails == null || rsCatalogueDetails.size() == 0)
             {
                 cell = row.createCell((short) intColumnIndex);
                 excelCell = (GEAEExcelCell) cell;
                 excelCell.setCellStyle(styleObj);
                 excelCell.setCellValue("Search Resulted in No rows.Please select different filter criteria");
                 excelCell= null;
                 cell=null;
                 //return workBook;
             }
             else if(rsCatalogueDetails.size()>65000)
             {
                 cell = row.createCell((short) intColumnIndex);
                 excelCell = (GEAEExcelCell) cell;
                 excelCell.setCellStyle(styleObj);
                 excelCell.setCellValue("Search Resulted in too many rows.Please select more filter criteria");
                 excelCell= null;
                 cell=null;
                 //return workBook;
             }
             else
             {
                 intColumnCount = rsCatalogueDetails.getColumnCount();
                 int count = 0;
                 if(strRole.equals(eCRDConstants.ROLE_GUEST)){

                     for (intColumnIndex = 0; intColumnIndex < 11 ; intColumnIndex++)
                       {
                        cell = row.createCell((short) intColumnIndex);

                        excelCell = (GEAEExcelCell) cell;
                        excelCell.setCellStyle(styleObj);
                        excelCell.setCellValue(rsCatalogueDetails.getColumnHeading(intColumnIndex + 1));
                        excelCell= null;
                        cell=null;
                        count++;
                       }
                     for (intColumnIndex = 13; intColumnIndex <15 ; intColumnIndex++)
                     {

                      cell = row.createCell((short) count);

                      excelCell = (GEAEExcelCell) cell;
                      excelCell.setCellStyle(styleObj);
                      excelCell.setCellValue(rsCatalogueDetails.getColumnHeading(intColumnIndex + 1));
                      excelCell= null;
                      cell=null;
                      count++;
                     }

                 }else {

                     for (intColumnIndex = 0; intColumnIndex < intColumnCount ; intColumnIndex++)
                     {
                         cell = row.createCell((short) intColumnIndex);
                         excelCell = (GEAEExcelCell) cell;
                         excelCell.setCellStyle(styleObj);
                         excelCell.setCellValue(rsCatalogueDetails.getColumnHeading(intColumnIndex + 1));

                         excelCell= null;
                         cell=null;
                    }
                 }

                 count = 0;
                 row = null;
                 fontObj = null;
                 styleObj = null;
                 //strEngModel = "";
                 //strPrevEngModel = "";
                 fontObj = eCRDStyleObjects.getNormalFontArial10(workBook);
                 styleObj = eCRDStyleObjects.getLeftAlignStyleObject(workBook);

                 styleObj.setFont(fontObj);
                 styleObj.setWrapText(true);
//             19-05-2006 patni checking null value Begin
                 if(rsCatalogueDetails != null)
                {
//                   19-05-2006 patni checking null value End

                 while (rsCatalogueDetails.next())
                 {
                     intRowIndex++;
                     /*strEngModel = rsCatalogueDetails.getString("Engine Model");
                     if(!strEngModel.equals(strPrevEngModel) && !"".equals(strPrevEngModel))
                     {
                         intRowIndex++;
                     }*/
                     row = sheetDetails.createRow((short) intRowIndex);

                     /*
                      * print the data
                      */
                     if(strRole.equals(eCRDConstants.ROLE_GUEST)){

                           for (intColumnIndex = 0; intColumnIndex < 11 ; intColumnIndex++)
                             {
                              cell = row.createCell((short) intColumnIndex);
                              excelCell = (GEAEExcelCell) cell;
                              excelCell.setCellStyle(styleObj);
                              excelCell.setCellValue(rsCatalogueDetails.getString(intColumnIndex + 1));
                              excelCell= null;
                              cell=null;
                              count++;
                             }
                           for (intColumnIndex = 13; intColumnIndex <15 ; intColumnIndex++)
                           {

                            cell = row.createCell((short) count);

                            excelCell = (GEAEExcelCell) cell;
                            excelCell.setCellStyle(styleObj);
                            excelCell.setCellValue(rsCatalogueDetails.getString(intColumnIndex + 1));
                            excelCell= null;
                            cell=null;
                            count++;
                           }
                           count=0;
                       }else {

                           for (intColumnIndex = 0; intColumnIndex < intColumnCount ; intColumnIndex++)
                           {
                             cell = row.createCell((short) intColumnIndex);
                             excelCell = (GEAEExcelCell) cell;
                             excelCell.setCellStyle(styleObj);
                             
                             
                           //beginning_rishabh_enhanced_adhoc_tm
                             
	                            String value = rsCatalogueDetails.getString(intColumnIndex + 1);
	                         	if ( value.contains("GE Passport"))
	                         	{
	                                 value=value.replace("GE Passport","GE Passport\u2122");
	                         	}
	                         	excelCell.setCellValue(value);
	                         		
	                         //ending_rishabh_enhanced_adhoc_tm
                             
                             
                             //excelCell.setCellValue(rsCatalogueDetails.getString(intColumnIndex+1 ));
                             excelCell=null;
                             cell=null;
                           }
                       }
                     row = null;

                     //strPrevEngModel = strEngModel ;
                 }
//             19-05-2006 patni checking null value Begin
                } // end if
//               19-05-2006 patni checking null value End
             }
             instantiateStyleObjects(); 
         }
         
         finally{
        	 
        	 row = null;
        	 cell=null;
         }
    }
//Ended By Santosh
  
//Adding Customer Adhoc Repair Reports started DES1121903 sujitha
 
 // Adding Customer Adhoc Repair Reports started DES1121903 sujitha
 
 private ArrayList getCustadhocData(HttpServletRequest request) throws Exception
 {
     String strActionId = null;
     String isRepairNumNotPresent = null;
     String isPartNumNotPresent = null;
     String strPriceWhere = null;
     String strCostWhere = null;
     String strPriceTypeWhere = null;
     String strInTATWhere = null;
     String strInPriceWhere = null;
     String strSeqCols = null;
     String strSelCols = null;
     String strEachSeqCol = null;
     String strEachSelCol = null;
     String strIsCostReqd = null;
//11-05-2006 Patni added Engine model Field Begin
     String strEngModel  = null;
     String strEngDesc = null;
     //Added By Santosh
     String strCatalogCode = null;
     String strCatalogName = null;
     
//11-05-2006 Patni added Engine model Field End
  // Added By Santosh added Site Field 
     String strSite = null;
     String strSiteDesc = null;
  // Added By Santosh added Site Field 
     StringBuffer strbuffWhere = null;
     StringBuffer strbuffSel = null;
     StringBuffer strbuffCriteria = null;
     StringBuffer strbufflstSite = null;

     StringTokenizer strTkn = null;

     HashMap hmSelectedCols = null;

     ArrayList arrlstInParam = null;
     ArrayList arrlstOutParam = null;
     ArrayList arrlstReturn = null;
     GEAEResultSet geaeRsetData = null;
     try
     {
         strbuffCriteria =  new StringBuffer();
         
         strSeqCols = eCRDUtil.verifyNull(request.getParameter("hdnSeqOfColums"));
        
         System.out.println("strseqCols --s-ssssss :======"+strSeqCols);

         strSelCols= eCRDUtil.verifyNull(request.getParameter("hdnSelColumns"));
         
         System.out.println("strselCols --s-lllllll :======"+strSelCols);
         
         strActionId= eCRDConstants.getActionId("eCRD_GET_CUSTADHOC_DATA");
         
         strTkn = new StringTokenizer(strSelCols,eCRDConstants.STRCOLUMNDELIM);
         hmSelectedCols = new HashMap();
         while(strTkn.hasMoreTokens())
         {
             strEachSelCol = strTkn.nextToken();
             hmSelectedCols.put(strEachSelCol,strEachSelCol);
             System.out.println("strselCols hashMap --s-lllllll :======"+hmSelectedCols);
         }
         strTkn = new StringTokenizer(strSeqCols,eCRDConstants.STRCOLUMNDELIM);
         strbuffSel = new StringBuffer();
         strbuffSel.append("SELECT ");
         
         while(strTkn.hasMoreTokens())
         {
             strEachSeqCol = strTkn.nextToken();
             System.out.println("Selected Columns in While :======"+strEachSeqCol);
             if(hmSelectedCols.containsKey(strEachSeqCol))
             {
            	 System.out.println("Selected Columns in if :======"+strEachSeqCol);
                 strbuffSel.append(eCRDConstants.getCustadhocColumns(strEachSeqCol)+",");
             }
             else if("LOCATION".equals((strEachSeqCol)))
             {
                 if(hmSelectedCols.containsKey("LOCATION_IND"))
                 {
                     strbuffSel.append(eCRDConstants.getCustadhocColumns("LOCATION_IND")+",");
                 }
             }

         }
        
             
             
             
             arrlstInParam = new ArrayList();

            
             
             System.out.println("SANTOSH IN TEST FOR REPORT SELECT PARAM"+strbuffSel.toString().substring(0,strbuffSel.toString().length()-1));
             
             
             System.out.println("SANTOSH IN TEST FOR REPORT GENERATE CHECK BOX PARAM"+request.getParameter("oselectedCatalog"));
             
             
             strCatalogCode = eCRDUtil.verifyNull(request.getParameter("oselectedCatalog")); 
             
             
             strTkn = new StringTokenizer(strCatalogCode,"$");
             
             arrlstReturn = new ArrayList();
             
             ArrayList arrlstReturn1 = new ArrayList();
             ArrayList arrlstEng = new ArrayList();
             ArrayList arrlstCrit = new ArrayList();
             
             ArrayList tempInparam = new ArrayList();
             
             ArrayList arrlstToken = null;
             
             
             StringTokenizer strTknCat = null;
             
             String custCatalog = null;
             
             String strCatCode = null;
             
             String strTknParam = null;
             
             ArrayList arrlstAllIn = new ArrayList();
             
             while(strTkn.hasMoreTokens())
             {
             	custCatalog = (String)strTkn.nextToken();   
             	strTknCat = new StringTokenizer(custCatalog,"^");
             	arrlstToken = new ArrayList();
             	while(strTknCat.hasMoreTokens())
             	{
             		strTknParam = (String)strTknCat.nextToken();
             		arrlstToken.add(strTknParam);
             		arrlstAllIn.add(strTknParam);
             		strTknParam = null;
             	}
             	
             		System.out.println("SANTOSH IN TEST FOR REPORT AarrayList Token  ---"+arrlstToken);
             	    

                     arrlstInParam.add(strbuffSel.toString().substring(0,strbuffSel.toString().length()-1));
             	    System.out.println("SANTOSH IN TEST FOR REPORT AarrayList Token"+arrlstInParam);
            	 		arrlstInParam.add(arrlstToken.get(1));
            	 		arrlstInParam.add(arrlstToken.get(0));
            	 		
            	 		
            	 		
            	 		System.out.println("SANTOSH IN TEST FOR REPORT INPUT PARA in DB"+arrlstInParam);
            	 		geaeRsetData = getResultSetEngMdlAdhoc(strActionId,arrlstInParam);
            	 	
            	 		arrlstReturn.add(geaeRsetData);
            	 	
            	 	
            	 		arrlstInParam.removeAll(arrlstInParam);
            	 		custCatalog = null;
             }
             
             
             System.out.println("SANTOSH IN TEST FOR REPORT ALL INPUT FROM FRONT"+arrlstAllIn);
             
             String strEngineModel = null;
             String strCustomerName = null;
             StringBuffer strbufCatDesc = new StringBuffer();
             ArrayList arrlstCatalogDesc = new ArrayList();
             String strTemp = null;
             
             for(int i = 1 ;i <= arrlstAllIn.size();i++ )
             {
             	strEngineModel = (String)arrlstAllIn.get(1);
             	strCustomerName = (String)arrlstAllIn.get(2);
             	
             	if(i%4 == 0)
             	{
             		strTemp = (String)arrlstAllIn.get(i-1);
             		arrlstCatalogDesc.add(strTemp);
             		strbufCatDesc.append(strTemp);
             		strbufCatDesc.append(",");
             		strTemp = null;
             	}
             	
             	
             }
              
             
             System.out.println("SANTOSH IN TEST FOR CRITERIA Engine Model :"+strEngineModel);
            
             System.out.println("SANTOSH IN TEST FOR CRITERIA Engine Customer Name :"+strCustomerName);
             
             System.out.println("SANTOSH IN TEST FOR CRITERIA Engine Catalog Desc :"+strbufCatDesc);
             
           
             
                 strbuffCriteria.append("Engine Model");
                 strbuffCriteria.append("^");
                 strbuffCriteria.append(" ");
                 strbuffCriteria.append("^");
                 strbuffCriteria.append(strEngineModel);
                 strbuffCriteria.append("$");
                 
                 strbuffCriteria.append("Customer Name");
                 strbuffCriteria.append("^");
                 strbuffCriteria.append(" ");
                 strbuffCriteria.append("^");
                 strbuffCriteria.append(strCustomerName);
                 strbuffCriteria.append("$");
                 
                 strbuffCriteria.append("Customer Catalog Desc");
                 strbuffCriteria.append("^");
                 strbuffCriteria.append(" ");
                 strbuffCriteria.append("^");
                 strbuffCriteria.append(strbufCatDesc);
                 strbuffCriteria.append("$");
                 
                 
                 
                 arrlstCrit.add(strbuffCriteria);
                 
                 
                 arrlstReturn1.add(arrlstReturn);
                 arrlstReturn1.add(arrlstCatalogDesc);
                 arrlstReturn1.add(arrlstCrit);
               //Ended By Santosh



 
                
             return arrlstReturn1;
         }
         finally
         {
           
             hmSelectedCols = null;
             strTkn = null;
         }

 }
 
 // Adding Customer Adhoc Repair Reports ended
  
 
 
 private ArrayList getEnhanceCustadhocData(HttpServletRequest request) throws Exception
 {
     String strActionId = null;
     String isRepairNumNotPresent = null;
     String isPartNumNotPresent = null;
     String strPriceWhere = null;
     String strCostWhere = null;
     String strPriceTypeWhere = null;
     String strInTATWhere = null;
     String strInPriceWhere = null;
     String strSeqCols = null;
     String strSelCols = null;
     String strEachSeqCol = null;
     String strEachSelCol = null;
     String strIsCostReqd = null;
//11-05-2006 Patni added Engine model Field Begin
     String strEngModel  = null;
     String strEngDesc = null;
     //Added By Santosh
     String strCatalogCode = null;
     String strCatalogName = null;
     
//11-05-2006 Patni added Engine model Field End
  // Added By Santosh added Site Field 
     String strSite = null;
     String strSiteDesc = null;
  // Added By Santosh added Site Field 
     StringBuffer strbuffWhere = null;
     StringBuffer strbuffSel = null;
     StringBuffer strbuffCriteria = null;
     StringBuffer strbufflstSite = null;

     StringTokenizer strTkn = null;

     HashMap hmSelectedCols = null;

     ArrayList arrlstInParam = null;
     ArrayList arrlstOutParam = null;
     ArrayList arrlstReturn = null;
     GEAEResultSet geaeRsetData = null;
     try
     {
         strbuffCriteria =  new StringBuffer();
         
         strSeqCols = eCRDUtil.verifyNull(request.getParameter("hdnSeqOfColums"));
         System.out.println("TEST in strseqCols&&&&&&&"+strSeqCols);

         strSelCols= eCRDUtil.verifyNull(request.getParameter("hdnSelColumns"));
         System.out.println("TEST in strselCols&&&&&&& LLLLLL"+strSelCols);

         strActionId= eCRDConstants.getActionId("eCRD_GET_ENHANCED_CUSTADHOC_DATA");
         
         strTkn = new StringTokenizer(strSelCols,eCRDConstants.STRCOLUMNDELIM);
         hmSelectedCols = new HashMap();
         while(strTkn.hasMoreTokens())
         {
             strEachSelCol = strTkn.nextToken();
             hmSelectedCols.put(strEachSelCol,strEachSelCol);
         }
         strTkn = new StringTokenizer(strSeqCols,eCRDConstants.STRCOLUMNDELIM);
         strbuffSel = new StringBuffer();
         strbuffSel.append("SELECT ");
         
         while(strTkn.hasMoreTokens())
         {
             strEachSeqCol = strTkn.nextToken();
             if(hmSelectedCols.containsKey(strEachSeqCol))
             {
                 //strbuffSel.append(eCRDConstants.getAdhocColumns(strEachSeqCol)+",");
            	 
            	 System.out.println("Select columns"+strEachSeqCol);
                 strbuffSel.append(eCRDConstants.getEnhancedCustadhocColumns(strEachSeqCol)+",");
             }
             else if("LOCATION".equals((strEachSeqCol)))
             {
                 if(hmSelectedCols.containsKey("LOCATION_IND"))
                 {
                     strbuffSel.append(eCRDConstants.getEnhancedCustadhocColumns("LOCATION_IND")+",");
                 }
             }

         }
        
             
             
             
             arrlstInParam = new ArrayList();

            
             
             System.out.println("SANTOSH IN TEST FOR REPORT SELECT PARAM"+strbuffSel.toString().substring(0,strbuffSel.toString().length()-1));
             
             
             System.out.println("SANTOSH IN TEST FOR REPORT GENERATE CHECK BOX PARAM"+request.getParameter("oselectedCatalog"));
             
             
             strCatalogCode = eCRDUtil.verifyNull(request.getParameter("oselectedCatalog")); 
             
             
             strTkn = new StringTokenizer(strCatalogCode,"$");
             
             arrlstReturn = new ArrayList();
             
             ArrayList arrlstReturn1 = new ArrayList();
             ArrayList arrlstEng = new ArrayList();
             ArrayList arrlstCrit = new ArrayList();
             
             ArrayList tempInparam = new ArrayList();
             
             ArrayList arrlstToken = null;
             
             
             StringTokenizer strTknCat = null;
             
             String custCatalog = null;
             
             String strCatCode = null;
             
             String strTknParam = null;
             
             ArrayList arrlstAllIn = new ArrayList();
             
             while(strTkn.hasMoreTokens())
             {
             	custCatalog = (String)strTkn.nextToken();   
             	strTknCat = new StringTokenizer(custCatalog,"^");
             	arrlstToken = new ArrayList();
             	while(strTknCat.hasMoreTokens())
             	{
             		strTknParam = (String)strTknCat.nextToken();
             		arrlstToken.add(strTknParam);
             		arrlstAllIn.add(strTknParam);
             		strTknParam = null;
             	}
             	
             		System.out.println("SANTOSH IN TEST FOR REPORT AarrayList Token  ---"+arrlstToken);
             	    

                     arrlstInParam.add(strbuffSel.toString().substring(0,strbuffSel.toString().length()-1));
             	    System.out.println("SANTOSH IN TEST FOR REPORT AarrayList Token"+arrlstInParam);
            	 		arrlstInParam.add(arrlstToken.get(1));
            	 		arrlstInParam.add(arrlstToken.get(0));
            	 		
            	 		
            	 		
            	 		System.out.println("SANTOSH IN TEST FOR REPORT INPUT PARA in DB"+arrlstInParam);
            	 		geaeRsetData = getResultSetEngMdlAdhoc(strActionId,arrlstInParam);
            	 	
            	 		arrlstReturn.add(geaeRsetData);
            	 	
            	 	
            	 		arrlstInParam.removeAll(arrlstInParam);
            	 		custCatalog = null;
             }
             
             
             System.out.println("SANTOSH IN TEST FOR REPORT ALL INPUT FROM FRONT"+arrlstAllIn);
             
             String strEngineModel = null;
             String strCustomerName = null;
             StringBuffer strbufCatDesc = new StringBuffer();
             ArrayList arrlstCatalogDesc = new ArrayList();
             String strTemp = null;
             
             for(int i = 1 ;i <= arrlstAllIn.size();i++ )
             {
             	strEngineModel = (String)arrlstAllIn.get(1);
             	strCustomerName = (String)arrlstAllIn.get(2);
             	
             	if(i%4 == 0)
             	{
             		strTemp = (String)arrlstAllIn.get(i-1);
             		arrlstCatalogDesc.add(strTemp);
             		strbufCatDesc.append(strTemp);
             		strbufCatDesc.append(",");
             		strTemp = null;
             	}
             	
             	
             }
              
             
             System.out.println("SANTOSH IN TEST FOR CRITERIA Engine Model :"+strEngineModel);
            
             System.out.println("SANTOSH IN TEST FOR CRITERIA Engine Customer Name :"+strCustomerName);
             
             System.out.println("SANTOSH IN TEST FOR CRITERIA Engine Catalog Desc :"+strbufCatDesc);
             
           
             
                 strbuffCriteria.append("Engine Model");
                 strbuffCriteria.append("^");
                 strbuffCriteria.append(" ");
                 strbuffCriteria.append("^");
                 strbuffCriteria.append(strEngineModel);
                 strbuffCriteria.append("$");
                 
                 strbuffCriteria.append("Customer Name");
                 strbuffCriteria.append("^");
                 strbuffCriteria.append(" ");
                 strbuffCriteria.append("^");
                 strbuffCriteria.append(strCustomerName);
                 strbuffCriteria.append("$");
                 
                 strbuffCriteria.append("Customer Catalog Desc");
                 strbuffCriteria.append("^");
                 strbuffCriteria.append(" ");
                 strbuffCriteria.append("^");
                 strbuffCriteria.append(strbufCatDesc);
                 strbuffCriteria.append("$");
                 
                 
                 
                 arrlstCrit.add(strbuffCriteria);
                 
                 
                 arrlstReturn1.add(arrlstReturn);
                 arrlstReturn1.add(arrlstCatalogDesc);
                 arrlstReturn1.add(arrlstCrit);
               //Ended By Santosh



 
                
             return arrlstReturn1;
         }
         finally
         {
           
             hmSelectedCols = null;
             strTkn = null;
         }

 }
 
 
 
//Added by Bora
    private ArrayList getEnhancedAdhocData(HttpServletRequest request) throws Exception
        {
            String strActionId = null;
            String isRepairNumNotPresent = null;
            String isPartNumNotPresent = null;
            String strPriceWhere = null;
            String strCostWhere = null;
            String strPriceTypeWhere = null;
            String strInTATWhere = null;
            String strInPriceWhere = null;
            String strSeqCols = null;
            String strSelCols = null;
            String strEachSeqCol = null;
            String strEachSelCol = null;
            String strIsCostReqd = null;
    // 11-05-2006 Patni added Engine model Field Begin
            String strEngModel  = null;
            String strEngDesc = null;
    // 11-05-2006 Patni added Engine model Field End
            
    // Added By Santosh added Site Field 
            String strSite = null;
            String strSiteDesc = null;
    // Added By Santosh added Site Field 
            StringBuffer strbuffWhere = null;
            StringBuffer strbuffSel = null;
            StringBuffer strbuffCriteria = null;
            StringBuffer strbufflstSite = null;

            StringTokenizer strTkn = null;

            HashMap hmSelectedCols = null;

            ArrayList arrlstInParam = null;
            ArrayList arrlstReturn = null;
           
            //Added By Santosh
            GEAEResultSet geaeRsetData = null;
            //ArrayList arrlstReturn = null;
            //Ended By Santosh
            
            try
            {
                strbuffCriteria =  new StringBuffer();
                strSeqCols = eCRDUtil.verifyNull(request.getParameter("hdnSeqOfEnColums"));
                strIsCostReqd = eCRDUtil.verifyNull(request.getParameter("hdnIsCostReqd"));

                strSelCols= eCRDUtil.verifyNull(request.getParameter("hdnSelEnColumns"));


                strInTATWhere = eCRDUtil.verifyNull(request.getParameter("cmb_incTAT"));
                strInPriceWhere= eCRDUtil.verifyNull(request.getParameter("cmb_incPrice"));
             
                strActionId= eCRDConstants.getActionId("eCRD_GET_ENHANCED_ADHOC_DATA");
                strTkn = new StringTokenizer(strSelCols,eCRDConstants.STRCOLUMNDELIM);
                hmSelectedCols = new HashMap();
                while(strTkn.hasMoreTokens())
                {
                    strEachSelCol = strTkn.nextToken();
                    hmSelectedCols.put(strEachSelCol,strEachSelCol);
                }
                strTkn = new StringTokenizer(strSeqCols,eCRDConstants.STRCOLUMNDELIM);
                strbuffSel = new StringBuffer();
                strbuffSel.append("SELECT ");
                while(strTkn.hasMoreTokens())
                {
                    strEachSeqCol = strTkn.nextToken();
                    if(hmSelectedCols.containsKey(strEachSeqCol))
                    {
                        strbuffSel.append(eCRDConstants.getEnhancedAdhocColumns(strEachSeqCol)+",");
                    }
                    else if("LOCATION".equals((strEachSeqCol)))
                    {
                        if(hmSelectedCols.containsKey("LOCATION_IND"))
                        {
                            strbuffSel.append(eCRDConstants.getEnhancedAdhocColumns("LOCATION_IND")+",");
                        }
                    }

                }


                isRepairNumNotPresent = eCRDUtil.verifyNull(request.getParameter("hdnRepairNum"));
                if("Y".equals(isRepairNumNotPresent))
                {
                    strbuffCriteria.append("Repair Number Present");
                    strbuffCriteria.append("^");
                    strbuffCriteria.append("N");
                    strbuffCriteria.append("$");
                }
                isPartNumNotPresent = eCRDUtil.verifyNull(request.getParameter("hdnPartNum"));
                if("Y".equals(isRepairNumNotPresent))
                {
                    strbuffCriteria.append("Part Number Present");
                    strbuffCriteria.append("^");
                    strbuffCriteria.append("N");
                    strbuffCriteria.append("$");
                }
                strInTATWhere =eCRDUtil.verifyNull(request.getParameter("cmb_incTAT"));
                if("Select..".equalsIgnoreCase(strInTATWhere))
                {
                    strInTATWhere = "";
                }
                else
                {
                    strbuffCriteria.append("Incremental TAT");
                    strbuffCriteria.append("^");
                    strbuffCriteria.append(strInTATWhere);
                    strbuffCriteria.append("$");
                }
                strInPriceWhere = eCRDUtil.verifyNull(request.getParameter("cmb_incPrice"));
                if("Select..".equalsIgnoreCase(strInPriceWhere))
                {
                    strInPriceWhere = "";
                }
                else
                {
                    strbuffCriteria.append("Incremental Price");
                    strbuffCriteria.append("^");
                    strbuffCriteria.append(strInPriceWhere);
                    strbuffCriteria.append("$");
                }
                strbuffWhere = new StringBuffer();
                strPriceWhere = eCRDUtil.verifyNull(request.getParameter("cmb_wherePrice"));

                if("Select..".equalsIgnoreCase(strPriceWhere))
                {
                    strPriceWhere = "";
                }
                else
                {
                    strbuffWhere.append(" AND "+eCRDConstants.getEnhancedAdhocColumns("PRICE_WHERE"));
                    strbuffWhere.append(strPriceWhere);
                    strbuffWhere.append(eCRDUtil.verifyNull(request.getParameter("txt_Price"))+" ");

                    strbuffCriteria.append("Repair Price");
                    strbuffCriteria.append("^");
                    strbuffCriteria.append(eCRDUtil.verifyNull(request.getParameter("cmb_wherePrice_text")));
                    strbuffCriteria.append("^");
                    strbuffCriteria.append(eCRDUtil.verifyNull(request.getParameter("txt_Price")));
                    strbuffCriteria.append("$");
                }
                strCostWhere = eCRDUtil.verifyNull(request.getParameter("cmb_whereCost"));
                if("Select..".equalsIgnoreCase(strCostWhere))
                {
                    strCostWhere = "";
                }
                else
                {
                    strbuffWhere.append(" AND "+eCRDConstants.getEnhancedAdhocColumns("COST_WHERE"));
                    strbuffWhere.append(strCostWhere);
                    strbuffWhere.append(eCRDUtil.verifyNull(request.getParameter("txt_Cost"))+" ");

                    strbuffCriteria.append("Repair Cost");
                    strbuffCriteria.append("^");
                    strbuffCriteria.append(eCRDUtil.verifyNull(request.getParameter("cmb_whereCost_text")));
                    strbuffCriteria.append("^");
                    strbuffCriteria.append(eCRDUtil.verifyNull(request.getParameter("txt_Cost")));
                    strbuffCriteria.append("$");

                }
                strPriceTypeWhere =eCRDUtil.verifyNull(request.getParameter("cmb_wherePriceType"));
                if("Select..".equalsIgnoreCase(strPriceTypeWhere))
                {
                    strPriceTypeWhere = "";
                }
                else
                {
                    strbuffWhere.append(" AND "+eCRDConstants.getEnhancedAdhocColumns("PRICE_TYPE_WHERE"));
                    strbuffWhere.append(strPriceTypeWhere);
                    strbuffWhere.append("'"+eCRDUtil.verifyNull(request.getParameter("cmb_priceType"))+"' ");

                    strbuffCriteria.append("Price Type");
                    strbuffCriteria.append("^");
                    strbuffCriteria.append(eCRDUtil.verifyNull(request.getParameter("cmb_wherePriceType_text")));
                    strbuffCriteria.append("^");
                    strbuffCriteria.append(eCRDUtil.verifyNull(request.getParameter("cmb_priceType")));
                    strbuffCriteria.append("$");

                }
                
             // Added By Santosh For Site
                strSite = eCRDUtil.verifyNull(request.getParameter("cmb_site"));
                strSiteDesc = eCRDUtil.verifyNull(request.getParameter("cmb_site_test"));
               
                strTkn = new StringTokenizer(strSite,eCRDConstants.STRCOLUMNDELIM);
                String strAll = null;
                String strsite = null;
                String strst=null;
                strbufflstSite = new StringBuffer();
                while(strTkn.hasMoreTokens())
                {
                	strsite=(String)strTkn.nextToken();
                	if("ALL".equals(strsite))
                	{
                		strAll=strsite;
                		break;
                	}
                	else
                	{
                		strbufflstSite.append("'");
                		strbufflstSite.append(strsite);
                		strbufflstSite.append("'");
                		strbufflstSite.append(",");
                		strsite=null;
                	}
                 }
                strbufflstSite.append("'");
                strbufflstSite.append("'");
               
                
                if("ALL".equalsIgnoreCase(strAll))
                {
                	strSite="";
                	strbuffCriteria.append("Site");
                    strbuffCriteria.append("^");
                    strbuffCriteria.append(" ");
                    strbuffCriteria.append("^");
                    strbuffCriteria.append("ALL");
                    strbuffCriteria.append("$");
                }
                else
                {
                	strbuffWhere.append(" AND "+eCRDConstants.getEnhancedAdhocColumns("LOCATION_WHERE"));
                	strbuffWhere.append(" IN (");
                	strbuffWhere.append(strbufflstSite);
                	strbuffWhere.append(" ) "); 
                	
                	strbuffCriteria.append("Site");
                    strbuffCriteria.append("^");
                    strbuffCriteria.append(" ");
                    strbuffCriteria.append("^");
                    strbuffCriteria.append(strSiteDesc);
                    strbuffCriteria.append("$");
                	
                	
                }
               
                // Ended By Santosh For Site
         // 11-05-2006 Patni  Added for criteria Begin
                // Added By Santosh
                strEngModel = eCRDUtil.verifyNull(request.getParameter("cmb_engmodel")); 
             
                
                arrlstInParam = new ArrayList();

                arrlstInParam.add(strbuffSel.toString().substring(0,strbuffSel.toString().length()-1));
                arrlstInParam.add(strbuffWhere.toString());
                arrlstInParam.add(isRepairNumNotPresent);
                arrlstInParam.add(isPartNumNotPresent);
                arrlstInParam.add(strInTATWhere);
                arrlstInParam.add(strInPriceWhere);
                arrlstInParam.add(strIsCostReqd);
                
                
                strTkn = new StringTokenizer(strEngModel,eCRDConstants.STRCOLUMNDELIM);
                arrlstReturn = new ArrayList();
                
                ArrayList arrlstReturn1 = new ArrayList();
                ArrayList arrlstEng = new ArrayList();
                ArrayList arrlstCrit = new ArrayList();
                
                ArrayList tempInparam = new ArrayList();
                
                
                String engModel = null;
                
                while(strTkn.hasMoreTokens())
                {
                	engModel=(String)strTkn.nextToken();            
               	 	arrlstInParam.add(engModel);
               	 	geaeRsetData = getResultSetEngMdl(strActionId,arrlstInParam);
               	 	arrlstInParam.remove(arrlstInParam.size()-1);
               	 	arrlstReturn.add(geaeRsetData);
               	 	engModel = null;
                }
                
          
                strEngDesc = eCRDUtil.verifyNull(request.getParameter("cmb_engmodel_text"));
                String strEngTxt = null;
                strTkn = new StringTokenizer(strEngDesc,eCRDConstants.STRCOLUMNDELIM);
                while(strTkn.hasMoreTokens())
                {
                	strEngTxt=(String)strTkn.nextToken();
                	arrlstEng.add(strEngTxt);
                	strEngTxt = null;
                }
                    strbuffCriteria.append("Engine Model");
                    strbuffCriteria.append("^");
                    strbuffCriteria.append(" ");
                    strbuffCriteria.append("^");
                    strbuffCriteria.append(strEngDesc);
                    strbuffCriteria.append("$");
                    arrlstCrit.add(strbuffCriteria);
                    
                    
                    arrlstReturn1.add(arrlstReturn);
                    arrlstReturn1.add(arrlstEng);
                    arrlstReturn1.add(arrlstCrit);
                  //Ended By Santosh
   
                return arrlstReturn1;
            }
            finally
            {
                hmSelectedCols = null;
                strTkn = null;
            }

        }
    //End Bora
    
    //Added By Santosh 
    /**
     * Method name: getResultSetEngMdl
     * This method will actually get the sheet for different Engine Model
     * of each forecast number with revision to the getXLSDataSheet method.
     * @version 1.0
     * @param   strActionId (String)
     * @param   arrlstInParam (ArrayList)
     * @return  GEAEResultSet
     * @since   JDK1.0
     */
    private GEAEResultSet getResultSetEngMdl(String strActionId,ArrayList arrlstInParam) throws Exception
    {
    	 ArrayList arrlstOutParam = null;
    	 GEAEResultSet geaeRsetData = null;
    	 arrlstInParam.add(engMdl);
    	 
    	 try
    	 {
    		 arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId,arrlstInParam);
    		 geaeRsetData = (GEAEResultSet)arrlstOutParam.get(0);
    		 
    		 return geaeRsetData;
    	 }
    	 
    	
    	 finally
    	 {
    		 arrlstOutParam = null;
    		 geaeRsetData = null;
    	 }
    	 
    }
    
    //Ended By Santosh 
    
    private void generateCriteriaSheet(StringBuffer strBuffCriteria)throws Exception
    {
        GEAERow row = null;
        GEAECell cell= null;
        GEAEExcelFont fontObj = null;
        GEAEExcelCellStyle styleObj = null;
        String strCriteria = null;
        String strCols = null;
        StringTokenizer strTknRows = null;
        StringTokenizer strTknCols = null;
        int intRowIndex = 0;
        int intColIndex = 0;
        try
        {
            sheetDetails = (GEAEExcelSheet)workBook.createSheet("Report_Criteria");
            intRowIndex = 0;
            row = null;
            row = sheetDetails.createRow((short) intRowIndex);
            fontObj = eCRDStyleObjects.getBoldFontArial10(workBook);
            styleObj = eCRDStyleObjects.getLeftAlignStyleObject(workBook);

            sheetDetails.setDefaultColumnWidth((short) 15);

            styleObj.setFont(fontObj);
            styleObj.setWrapText(true);

            cell = row.createCell((short) 0);
            excelCell = (GEAEExcelCell) cell;
            excelCell.setCellStyle(styleObj);
            excelCell.setCellValue("Column");

            cell = row.createCell((short) 1);
            excelCell = (GEAEExcelCell) cell;
            excelCell.setCellStyle(styleObj);
            excelCell.setCellValue("Criteria");

            cell = row.createCell((short) 2);
            excelCell = (GEAEExcelCell) cell;
            excelCell.setCellStyle(styleObj);
            excelCell.setCellValue("Value");

            strCriteria = strBuffCriteria.toString();

            strTknRows = new StringTokenizer(strCriteria , "$");
            fontObj = eCRDStyleObjects.getNormalFontArial10(workBook);
            styleObj = eCRDStyleObjects.getLeftAlignStyleObject(workBook);

            styleObj.setFont(fontObj);
            styleObj.setWrapText(true);

            while(strTknRows.hasMoreTokens())
            {
                strCols = strTknRows.nextToken();
                strTknCols = new StringTokenizer(strCols , "^");
                intColIndex = 0;
                intRowIndex++;
                row = sheetDetails.createRow((short) intRowIndex);
                while(strTknCols.hasMoreTokens())
                {
                    cell = row.createCell((short) intColIndex);
                    excelCell = (GEAEExcelCell) cell;
                    excelCell.setCellStyle(styleObj);
                    
                    
 //beginning_rishabh_criteriaSheet_tm
                    
                	String newValue = strTknCols.nextToken();
                	System.out.println("newValue 2- " + newValue );
                	if ( newValue.contains("GE Passport"))
                	{	
                        newValue = newValue.replace("GE Passport","GE Passport\u2122");   
                	}
                	excelCell.setCellValue(newValue);
            	
            	//ending_rishabh_criteriaSheet_tm  
                    
                    
                    //excelCell.setCellValue(strTknCols.nextToken());
                    intColIndex++;
                }
            }


        }
        finally
        {
            row = null;
            cell= null;
            fontObj = null;
            styleObj = null;
            strCriteria = null;
            strCols = null;
            strTknRows = null;
            strTknCols = null;
        }
    }
    /**
     *  <pre>
     * This method Generates the rows in that excel with the columns and the data
     * @param  rownum                         Rownumber to be populated.
     * @param  colCount                       Count of the columns in the excel.
     * @param  hmDataMap                      HashMap containing the data
     * @param  workbook_sheet                 Sheet on which the rows are to be added
     * @exception  GEAEOfficeException
     * @throws  GEAEOfficeException  </pre>
     */


    public void rowgeneratorMapping(int rownum,int colCount,HashMap hmdataMap,GEAESheet workbook_sheet,
    								GEAEExcelWorkbook wb,GEAEExcelFont fontObj,GEAEExcelCellStyle styleObj)
    throws GEAEOfficeException
    {
        GEAEExcelRow sheet_row;
        GEAEExcelCell sheet_cell;
        GEAECell cell;
        String strData = "";
        int i = 0;

                 try
                 {
                	// if (rownum==0)
                		// System.out.println("fontObj  in row generator - "+fontObj );
                     sheet_row = (GEAEExcelRow)workbook_sheet.createRow((short)rownum);
                     styleObj.setFont(fontObj);
                     styleObj.setWrapText(true);

                     for (i=0;i<colCount;i++)
                     {
                         sheet_cell = (GEAEExcelCell)sheet_row.createCell((short)i);
                         strData = (String)hmdataMap.get(i+"");
                         sheet_cell.setCellStyle(styleObj);
                         sheet_cell.setCellValue(strData);
                         sheet_cell = null;
                     }
                 }
                 catch(GEAEOfficeException geaeoff)
                 {
                    throw new GEAEOfficeException("eCRDExcelTrial::rowgenerator" + geaeoff.getMessage());
                 }
		 finally
		 {
			sheet_row = null;
			fontObj = null;
       		styleObj = null;

		 }

    }
    //end of rowGeneratorMapping method
} //end of the class eCRDBatchDownload