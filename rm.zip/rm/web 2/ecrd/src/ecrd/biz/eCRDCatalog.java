//Source file: D:\\ECRD\\SOURCE CODE\\ecrd\\biz\\eCRDCatalog.java
/*
* Module    	    : eCRDCatalog.java
* Author      	    : PATNI-Offshore
* Project	        : eCRD
* Date Written		: October 2004
* Security	        : Unclassified
* Restrictions		: GE PROPRIETARY INFORMATION, FOR GE USE ONLY
*
*     ****************************************************
*     *  Copyright (2000) with all rights reserved       *
*     *          General Electric Company                *
*     ****************************************************
*
* Description: eCRDCatalog is used for the catalog related data
*
* Revision Log  (mm/dd/yy initials description)
* --------------------------------------------------------------
*/

package ecrd.biz;

import java.util.ArrayList;

import ecrd.common.eCRDDBMediator;
import ecrd.util.eCRDUtil;
import ecrd.util.eCRDConstants;

/**
 * This class is super class for all other catalog types.
 */
public abstract class eCRDCatalog
{
	private String strCatalogSeqId = null;
	private String strCatalogStartDate = null;
	private String strCatalogEndDate = null;
	private String strCatalogDesc = null;
	
	private String strCatInd = null;  //changes by vikrant
	
	private String strCopiedCatalogSeq = null;
	private String strCatalogType = null;
	private eCRDEngineModel objeCRDEngineModel = null;
	private String strVisibleToCWC = null;
	private String strCatalogCreationDate = null;
    private String strCatalogCreationBy = null;
    private String strCatalogEndDateModifiedDate = null;
    private String strCatalogEndDateModifiedBy= null;
    
    //Added By Santosh
    private String strEngineModelDesc = null;
    // Ended By Santosh
    
    
	private boolean isActive;

	/*
	 * Constructor
	 */
	public eCRDCatalog()
	{

	}

	/**
	 * Copies current catalog and returns reference to the new copied catalog. User 
	 * needs to set engine model, start date end date of this new catalog.
	 * @return ecrd.biz.eCRDCatalog
	 */
	public abstract boolean copyCatalog(eCRDCatalog objeCRDCatalog, String strUserId) throws Exception;

	/**
	 * Update the catalog details
	 */
	public abstract boolean save(String strUserId) throws Exception;

	/**
	 * Stores the catalog details to the database
	 */
	public abstract boolean create(String strUserId) throws Exception;

	/**
	 * Download the catalog data from database.
	 * @param strFormat
	 */
	public void downloadCatalog(String strFormat)
	
	{

	}

	/**
	 * @return int
	 */
	public String getCatalogSeqId()
	{
		return this.strCatalogSeqId;
	}

	/**
	* @return strVisibleToCWC
	* method returns the parameter which is set in the setter method for Visible to CWC functionality.
	*/
	public String getVisibleToCWC()
	{
		return this.strVisibleToCWC;
	}
	/**
	 * @return Calendar
	 */
	public String getStartDate()
	{
		return this.strCatalogStartDate;
	}
	//Added By Santosh

	public String getStrEngineModelDesc() {
		return strEngineModelDesc;
	}

	public void setStrEngineModelDesc(String strEngineModelDesc) {
		this.strEngineModelDesc = strEngineModelDesc;
	}

	//Ended By Santosh
	/**
	 * @return Calendar
	 */
	public String getEndDate()
	{
		return this.strCatalogEndDate;
	}

	/**
	 * @return String
	 */
	public String getCatalogDesc()
	{
		return this.strCatalogDesc;
	}

	/**
	 * @return ecrd.biz.eCRDEngineModel
	 */
	public eCRDEngineModel getEngineModel()
	{
		return this.objeCRDEngineModel;
	}

	/**
	 * @param intCatalogSeqId
	 */
	public void setCatalogSeqId(String strCatalogSeqId)
	{
		this.strCatalogSeqId = strCatalogSeqId;
	}

	/**
	* @param strVisibleToCWC
	* method sets the parameter for Visible to CWC functionality.
	*/
	public void setVisibleToCWC(String strVisibleToCWC)
	{
		this.strVisibleToCWC = strVisibleToCWC;
	}

	/**
	 * @param dtCatalogStartDate
	 */
	public void setCatalogStartDate(String strCatalogStartDate)
	{
		this.strCatalogStartDate = strCatalogStartDate;
	}

	/**
	 * @param dtCatalogEndDate
	 */
	public void setCatalogEndDate(String strCatalogEndDate)
	{
		this.strCatalogEndDate = strCatalogEndDate;
	}

	/**
	 * @param strCatalogDesc
	 */
	public void setCatalogDesc(String strCatalogDesc)
	{
		this.strCatalogDesc = eCRDUtil.replaceString(strCatalogDesc, "\r\n", " "); 
	}

	/**
	 * @param objEngineModel
	 */
	public void setEngineModel(eCRDEngineModel objEngineModel)
	{
		this.objeCRDEngineModel = objEngineModel;
	}
	/*This method returns the current default seq id
	 * @param strEngModelCd <code>String </code>
	 * @returns String default Seq ID
	 */
	public static String getCurrentDefaultSeqId(String strEngModelCd) throws Exception
	{
		String strDefaultCatalogSeqId = "";
		ArrayList arrlstInParam = null;
		ArrayList arrlstOutParam = null;
		try
		{
			arrlstInParam = new ArrayList();
			arrlstInParam.add(strEngModelCd);
			arrlstOutParam = eCRDDBMediator.doDBOperation(eCRDConstants.getActionId("eCRD_GET_DEFAULT_SEQ_ID"), arrlstInParam);
			strDefaultCatalogSeqId = eCRDUtil.verifyNull((String) arrlstOutParam.get(0));
			return strDefaultCatalogSeqId;
		}
		finally
		{
			arrlstInParam = null;
			arrlstOutParam = null;
		}
	}
	/**
	 * @return
	 */
	public String getCopiedCatalogSeq()
	{
		return strCopiedCatalogSeq;
	}

	/**
	 * @param string
	 */
	public void setCopiedCatalogSeq(String strCopiedCatalogSeq)
	{
		this.strCopiedCatalogSeq = strCopiedCatalogSeq;
	}

	/**
	 * @return
	 */
	public String getCatalogType()
	{
		return strCatalogType;
	}

	/**
	 * @param string
	 */
	public void setCatalogType(String strCatalogType)
	{
		this.strCatalogType = strCatalogType;
	}

	/**
	 * @return
	 */
	
	
	
	
	
//  changes by vikrant
	
	
	
	public String getCatInd()
	{
		return strCatInd;
	}

	/**
	 * @param string
	 */
	public void setCatInd(String strCatInd)
	{
		this.strCatInd = strCatInd;
	}
	
	
	// changes end by vikrant
	
	
	
	
	public boolean isActive()
	{
		return isActive;
	}

	/**
	 * @param b
	 */
	public void setActive(boolean blnActive)
	{
		isActive = blnActive;
	}

    /**
     * @param string
     */ 
   public void setCatalogCreationDate(String strCatalogCreationDate)
    {
        this.strCatalogCreationDate = strCatalogCreationDate;
    }

   /**
     * @param string
     */
    public void setCatalogEndDateModifiedDate(String strCatalogEndDateModifiedDate)
    {
        this.strCatalogEndDateModifiedDate = strCatalogEndDateModifiedDate;
    }
    /**
     * @return Calendar
     */
    public String getCatalogCreationDate()
    {
        return this.strCatalogStartDate;
    }
    /**
     * @return Calendar
     */
    public String getCatalogEndDateModifiedDate()
    {
        return this.strCatalogEndDateModifiedDate;
    }
    
    /**
     * @param string
     */ 
   public void setCatalogCreationBy(String strCatalogCreationBy)
    {
        this.strCatalogCreationBy = strCatalogCreationBy;
    }

   /**
     * @param string
     */
    public void setCatalogEndDateModifiedBy(String strCatalogEndDateModifiedBy)
    {
        this.strCatalogEndDateModifiedBy = strCatalogEndDateModifiedBy;
    }
    /**
     * @return Calendar
     */
    public String getCatalogCreationBy()
    {
        return this.strCatalogCreationBy;
    }
    /**
     * @return Calendar
     */
    public String getCatalogEndDateModifiedBy()
    {
        return this.strCatalogEndDateModifiedBy;
    }
    

    
}
