//Source file: D:\\ECRD\\SOURCE CODE\\ecrd\\biz\\eCRDCatalogRule.java
/*
* Module    	    : eCRDCatalogRule.java
* Author      	    : PATNI-Offshore
* Project	        : eCRD
* Date Written		: October 2004
* Security	        : Unclassified
* Restrictions		: GE PROPRIETARY INFORMATION, FOR GE USE ONLY
*
*     ****************************************************
*     *  Copyright (2000) with all rights reserved       *
*     *          General Electric Company                *
*     ****************************************************
*
* Description: eCRDCatalogRule is used for the catalog rule
*
* Revision Log  (mm/dd/yy initials description)
* --------------------------------------------------------------
*/

package ecrd.biz;

import java.util.ArrayList;
import java.io.Serializable;
import ecrd.exception.eCRDException;
import ecrd.util.eCRDConstants;
/**
 * This Entity represents Each rule in customer catalog.
 */
public class eCRDCatalogRule implements Serializable
{

	/**
	 * Rule Code
	 */
	//private String strRuleCode = null;
	private String strYear = null;

	/**
	 * Rule level could be on entire catalog level or specified modules, components, 
	 * repairs. Please specify "CA" for catalog level, "M" for Module level , "CO" or 
	 * component and "R" for repair level.
	 */
	private String strRuleLevel = null;

	/**
	 * List of codes for components or modules or repairs for which the rule is to be 
	 * applied
	 */
	private ArrayList arrlstLevelCode = null;
	private Double dblDiscount = null;
	private Integer intTAT = null;

	/**
	 * Calculated price should be less than default value.
	 * For these rule level will be always catalog.
	 */
	private boolean flgDefaultValCompare = false;

	/**
	 * Whether to flow changes from Default Catalog.
	 * For these rule level will be always catalog.
	 */
	private boolean flgFlowChangesFrmDef = false;

	/**
	 * Discount for New Repairs. Apply this discount on New Repairs only.
	 * For these rule level will be always catalog.
	 */
	private double dblDiscountForNewRepair = 0;

	/**
	 * Calculated price should be > than this value (Absolute Value)
	 * For these rule level will be always catalog.
	 */
	private double dblPriceToCompare = 0;

	/**
	 *  Calculated price should be > than:this value  (% of current default Catalog 
	 * Price)
	 * For these rule level will be always catalog.
	 */
	private double dblPriceToPercent = 0;

	/**
	 * Just to identify difference between fixed rules on catalog level (misclleneou 
	 * rules) and other dynamically added rules.
	 */
	private String strRuleType = null;

	/**
	 * Module Cd for which the Rule is going to be applied.
	 */
	private String strModuleCd = null;

	/**
		* Component Cd for which the Rule is going to be applied.
		*/
	private String strComponentCd = null;

	/**
		* Repair Cd for which the Rule is going to be applied.
		*/
	private String strRepairCd = null;

	/**
	 * Flag which indicates whether this object is loaded partially or fully. 
	 * True : Partial Loading
	 * False : Full Loading
	 */
	private boolean flgIsLoadedPartially = true;
	private eCRDEscalation objeCRDEscalation = null;

	private eCRDException objeCRDException = null;

	public eCRDCatalogRule()
	{

	}
	public eCRDCatalogRule(String strYear, String strRuleLevel, String strComponentCode, String strModuleCode, String strRepairCode) throws Exception
	{
		this.strYear = strYear;
		this.strRuleLevel = strRuleLevel;
		this.strComponentCd = strComponentCode;
		this.strModuleCd = strModuleCode;
		this.strRepairCd = strRepairCode;
	}
	/**
	 * Create catalog rule entry into database.
	 */
	public void create()
	{

	}

	/**
	 * Save updated rule details to database
	 */
	public void save()
	{

	}

	/**
	 * Delete rule from the database
	 */
	public void delete()
	{

	}

	/**
	 * @return String
	 */
	/*public String getRuleCode() 
	{
	 return null;
	}
	*/
	/**
	 * @return String
	 */
	public String getYear()
	{
		return this.strYear;
	}

	/**
	 * @return String
	 */
	public String getRuleLevel()
	{
		return this.strRuleLevel;
	}

	/**
	 * @return ArrayList
	 */
	public ArrayList getLevelCode()
	{
		return this.arrlstLevelCode;
	}

	/**
	 * @return double
	 */
	public Double getDiscount()
	{
		return this.dblDiscount;
	}

	/**
	 * Returns reference to the eCRDEscalation object stored in the eCRDCatalogRule.
	 * @return ecrd.biz.eCRDEscalation
	 */
	public eCRDEscalation getEscalation()
	{
		return this.objeCRDEscalation;
	}

	/**
	 * @param strRuleCode
	 */
	/*   public void setRuleCode(String strRuleCode) 
	   {
	    
	   }
	  */
	public void setYear(String strYear)
	{
		this.strYear = strYear;
	}

	/**
	 * @param strRuleDesc
	 */
	public void setRuleLevel(String strRuleDesc)
	{
		this.strRuleLevel = strRuleDesc;
	}

	/**
	 * @param lstLvlCode
	 */
	public void setLevelCode(ArrayList lstLvlCode)
	{
		this.arrlstLevelCode = lstLvlCode;
	}

	/**
	 * @param dblDiscount
	 */
	public void setDiscount(Double dblDiscount)
	{
		this.dblDiscount = dblDiscount;
	}

	/**
	 * Creates object of eCRDEscalation and sets it to memeber variable. Also returns 
	 * reference to this memeber variable so that its parameters could be set.
	 * @return ecrd.biz.eCRDEscalation
	 */
	public void addEscalation(eCRDEscalation objeCRDEscalation)
	{
		this.objeCRDEscalation = objeCRDEscalation;
	}

	/**
	 * @return boolean
	 */
	public boolean getDefaultValCompare()
	{
		return this.flgDefaultValCompare;
	}

	/**
	 * @return boolean
	 */
	public boolean getFlowChangesFrmDef()
	{
		return this.flgFlowChangesFrmDef;
	}

	/**
	 * @return double
	 */
	public double getDiscountForNewRepair()
	{
		return this.dblDiscountForNewRepair;
	}

	/**
	 * @return double
	 */
	public double getPriceToCompare()
	{
		return this.dblPriceToCompare;
	}

	/**
	 * @return double
	 */
	public double getPriceToPercent()
	{
		return this.dblPriceToPercent;
	}

	/**
	 * @return String
	 */
	public String getRuleType()
	{
		return this.strRuleType;
	}

	/**
	 * For setting Catalog Level Rule
	 * @param flgDefaltValCompare
	 */
	public void setDefaltValCompare(boolean flgDefaultValCompare)
	{
		this.flgDefaultValCompare = flgDefaultValCompare;
	}

	/**
	 * For setting Catalog Level Rule
	 * @param flgFolwChangesFrmDef
	 */
	public void setFlowChangesFrmDef(boolean flgFlowChangesFrmDef)
	{
		this.flgFlowChangesFrmDef = flgFlowChangesFrmDef;
	}

	/**
	 * For setting Catalog Level Rule
	 * @param dblDiscountForNewRepair
	 */
	public void setDiscountForNewRepair(double dblDiscountForNewRepair)
	{
		this.dblDiscountForNewRepair = dblDiscountForNewRepair;
	}

	/**
	 * For setting Catalog Level Rule
	 * @param dblPriceToCompare
	 */
	public void setPriceToCompare(double dblPriceToCompare)
	{
		this.dblPriceToCompare = dblPriceToCompare;
	}

	/**
	 * For setting Catalog Level Rule
	 * @param dblPriceToPercent
	 */
	public void setPriceToPercent(double dblPriceToPercent)
	{
		this.dblPriceToPercent = dblPriceToPercent;
	}

	/**
	 * @param strRuleType - Missalaneous catalog level rules would be identified by 
	 * 'M' and rest of the rules would be identifies by 'O'
	 */
	public void setRuleType(String strRuleType)
	{
		this.strRuleType = strRuleType;
	}

	/**
	 * Returns status of the Reapir object. Retruns true if loaded partially, returns 
	 * false if loaded fully.
	 * @return boolean
	 */
	public boolean getIsLoadedPartially()
	{
		return this.flgIsLoadedPartially;
	}
	public Integer getTAT()
	{
		return this.intTAT;
	}
	public void setTAT(Integer intTAT)
	{
		this.intTAT = intTAT;
	}

	/**
	 * @return String
	 */
	public String getComponentCd()
	{
		return this.strComponentCd;
	}

	/**
		* @return String
		*/
	public String getModuleCd()
	{
		return this.strModuleCd;
	}

	/**
		* @return String
		*/
	public String getRepairCd()
	{
		return this.strRepairCd;
	}
	/**
		* @param strComponentCd  
		*/
	public void setComponentCd(String strComponentCd)
	{
		this.strComponentCd = strComponentCd;
	}
	/**
		* @param strModuleCd  
		*/
	public void setModuleCd(String strModuleCd)
	{
		this.strModuleCd = strModuleCd;
	}

	/**
		* @param strRepariCd  
		*/
	public void setRepairCd(String strRepairCd)
	{
		this.strRepairCd = strRepairCd;
	}

	private boolean retBoolean(String strBoolean)
	{
		if (strBoolean.toUpperCase().equals("Y") || strBoolean.toUpperCase().equals("TRUE"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	public String getIndexDep() throws Exception
	{
		String[][] strIndexDep = null;
		StringBuffer strIndexDepBuff = null;
		int intNoOfIndex = 0;
		try
		{
			strIndexDep = objeCRDEscalation.getIndexDependency();
			strIndexDepBuff = new StringBuffer();
			/*if(strIndexDep = null )
			{
				objeCRDException = new eCRDException();
				objeCRDException.setExcpId("eCRD_Escalation_Not_Found");
			}*/
			if (strIndexDep != null)
			{
				intNoOfIndex = strIndexDep.length;

				for (int intCtr = 0; intCtr < intNoOfIndex; intCtr++)
				{
					strIndexDepBuff.append(strIndexDep[intCtr][0]);
					strIndexDepBuff.append(eCRDConstants.STRCOLUMNDELIM);
					strIndexDepBuff.append(strIndexDep[intCtr][1]);
					strIndexDepBuff.append(eCRDConstants.STRCOLUMNDELIM);
					strIndexDepBuff.append(eCRDConstants.STRROWDELIM);
				}
			}
			return strIndexDepBuff.toString();
		}
		finally
		{
			strIndexDep = null;
			strIndexDepBuff = null;
		}
	}

}
