//Source file: D:\\ECRD\\SOURCE CODE\\ecrd\\biz\\eCRDChildRepair.java
/*
* Module    	    : eCRDBusinessBean.java
* Author      	    : PATNI-Offshore
* Project	        : eCRD
* Date Written		: October 2004
* Security	        : Unclassified
* Restrictions		: GE PROPRIETARY INFORMATION, FOR GE USE ONLY
*
*     ****************************************************
*     *  Copyright (2000) with all rights reserved       *
*     *          General Electric Company                *
*     ****************************************************
*
* Description: eCRDBusinessBean is used for getting the GEAE Row Cache Tag
*
* Revision Log  (mm/dd/yy initials description)
* --------------------------------------------------------------
*/

package ecrd.biz;

import ecrd.util.eCRDUtil;


/**
 * This Entity represent the child repair.
 */
public class eCRDChildRepair 
{
   
   /**
	* Code identifying a child repair.
	*/
   private String strChildRepairCode = null;
   
   /**
	* Sequence number of the child repair.
	*/
   private String strRepairSeqNo = null;
   private String strReapirDesc = null;
   private String strReapairRefFormat = null;
   private String strRepairRefNo = null;
   private String strComments = null;
   
   private String strChildRepairInd = null; //changes by rishabh mewar
   
   private String strMergeSplitSeqId = null ;
   private String strRDNumber = null;
   private String strReasonRDOverride = null;
   private String strRDNumberComment = null;
   private String strRDCreationDt = null;
   private String strRDModifiedDt = null;
   private String strRDAssociation = null;
/**
 * @return
 */
public String getRepairSeqNo() {
	return strRepairSeqNo;
}

/**
 * @param intRepairSeqNo
 */
public void setRepairSeqNo(String intRepairSeqNo) {
	this.strRepairSeqNo = intRepairSeqNo;
}

/**
 * @return
 */
public String getStrChildRepairCode() {
	return strChildRepairCode;
}

/**
 * @param strChildRepairCode
 */
public void setStrChildRepairCode(String strChildRepairCode) {
	this.strChildRepairCode = strChildRepairCode;
}

/**
 * @return
 */
public String getStrComments() {
	return strComments;
}

/**
 * @param strComments
 */
public void setStrComments(String strComments) {
	this.strComments = eCRDUtil.replaceString(strComments, "\r\n", " "); 
}


/**beginning changes by rishabh mewar **/

public String getRepairInd()
{
    return strChildRepairInd;
}
public void setRepairInd(String strChildRepairInd)
{
    this.strChildRepairInd = strChildRepairInd;
}

/**end of changes by rishabh mewar **/


/**
 * @return
 */
public String getStrReapairRefFormat() {
	return strReapairRefFormat;
}

/**
 * @param strReapairRefFormat
 */
public void setStrReapairRefFormat(String strReapairRefFormat) {
	this.strReapairRefFormat = strReapairRefFormat;
}

/**
 * @return
 */
public String getStrReapirDesc() {
	return strReapirDesc;
}

/**
 * @param strReapirDesc
 */
public void setStrReapirDesc(String strReapirDesc) {
	this.strReapirDesc = eCRDUtil.replaceString(strReapirDesc, "\r\n", " "); 
}

/**
 * @return
 */
public String getStrRepairRefNo() {
	return strRepairRefNo;
}

/**
 * @param strRepairRefNo
 */
public void setStrRepairRefNo(String strRepairRefNo) {
	this.strRepairRefNo = strRepairRefNo;
}

   /**
	* Load Child repair by using the Child repair code passed
	* @param strChildRepairCode
	* @param strRepairCode
	*/
   public eCRDChildRepair(String strChildRepairCode, String strRepairCode) 
   {
    
   }
   
   /**
	* Deafult Constructor
	*/
   public eCRDChildRepair() 
   {
    
   }
   
   /**
	* Create data into database for the child repair and its dependent
	*/
   public void create() 
   {
    
   }
   
   /**
	* update child repair and its dependencies in the database
	*/
   public void update() 
   {
    
   }
   
   /**
	* Removes child repair from the database.
	* @param strChildRepairSeqId
	*/
   public void remove(String strChildRepairSeqId) 
   {
    
   }
	   
	  
	/**
	 * @return
	 */
	public String getMergeSplitSeqId()
	{
		return strMergeSplitSeqId;
	}
	
	/**
	 * @param string
	 */
	public void setMergeSplitSeqId(String strSeqId)
	{
		strMergeSplitSeqId = strSeqId;
	}

/**
 * @return Returns the strRDCreationDt.
 */
public String getStrRDCreationDt()
{
    return strRDCreationDt;
}
/**
 * @param strRDCreationDt The strRDCreationDt to set.
 */
public void setStrRDCreationDt(String strRDCreationDt)
{
    this.strRDCreationDt = strRDCreationDt;
}
/**
 * @return Returns the strRDModifiedDt.
 */
public String getStrRDModifiedDt()
{
    return strRDModifiedDt;
}
/**
 * @param strRDModifiedDt The strRDModifiedDt to set.
 */
public void setStrRDModifiedDt(String strRDModifiedDt)
{
    this.strRDModifiedDt = strRDModifiedDt;
}
/**
 * @return Returns the strRDNumber.
 */
public String getStrRDNumber()
{
    return strRDNumber;
}
/**
 * @param strRDNumber The strRDNumber to set.
 */
public void setStrRDNumber(String strRDNumber)
{
    this.strRDNumber = strRDNumber;
}
/**
 * @return Returns the strRDNumberComment.
 */
public String getStrRDNumberComment()
{
    return strRDNumberComment;
}
/**
 * @param strRDNumberComment The strRDNumberComment to set.
 */
public void setStrRDNumberComment(String strRDNumberComment)
{
    this.strRDNumberComment = strRDNumberComment;
}
/**
 * @return Returns the strReasonRDOverride.
 */
public String getStrReasonRDOverride()
{
    return strReasonRDOverride;
}
/**
 * @param strReasonRDOverride The strReasonRDOverride to set.
 */
public void setStrReasonRDOverride(String strReasonRDOverride)
{
    this.strReasonRDOverride = strReasonRDOverride;
}
/**
 * @return Returns the strRDAssociation.
 */
public String getStrRDAssociation()
{
    return strRDAssociation;
}
/**
 * @param strRDAssociation The strRDAssociation to set.
 */
public void setStrRDAssociation(String strRDAssociation)
{
    this.strRDAssociation = strRDAssociation;
}
}
