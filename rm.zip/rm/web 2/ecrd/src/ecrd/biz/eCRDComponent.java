/*
* Module    	    : eCRDBusinessBean.java
* Author      	    : PATNI-Offshore
* Project	        : eCRD
* Date Written		: October 2004
* Security	        : Unclassified
* Restrictions		: GE PROPRIETARY INFORMATION, FOR GE USE ONLY
*
*     ****************************************************
*     *  Copyright (2000) with all rights reserved       *
*     *          General Electric Company                *
*     ****************************************************
*
* Description:
*
* Revision Log  (mm/dd/yy initials description)
* --------------------------------------------------------------
*/

package ecrd.biz;

import java.util.ArrayList;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;

import ecrd.common.eCRDDBMediator;
import ecrd.exception.eCRDException;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDUtil;
import geae.dao.GEAEResultSet;
import geae.dao.GEAESQLException;

/**
 * 1) Load component Data from the database based on the Engine Model, Module and
      component code.
 * 2) Used for loading the component data for viewing..
 * 3) load repairs partially for the component.
 */
public class eCRDComponent
{

	private String strComponentCode = null;
	private String strComponentDesc = null;
	private String strATARefNo = null;
	private String strBaseLineTAT = null;
	private String dtComponentEffDt = null;
	private String strCycValClass = null;
	private String strQtyCompPerEngine = null;
	private String strShopVisitExposureRate = null;
	private String strScrapRateAtExposure = null;
	private String strServicableAtExposure = null;
	private String strPercetageYield = null;
	private String strAlternateComponent = null;

	private String strTechLvl = null;
	/**
	 * ArrayList of eCRDRepair for the component.
	 */
	private ArrayList arrlstRepair = null;

	/**
	 * ArrayList of eCRDSite.
	 */
	private ArrayList arrlstSites = null;

	/**
	 * ArrayList of eCRDPart linked to the component.
	 */
	private ArrayList arrlstParts = null;

	/* Module Object reference to have Backward traversal */

	private eCRDModule objECRDModule = null;

	/**
	 * This method is a constructor which will load component details based on passed
	 * parameters table.If the strDataFrom is S then component details will be loaded
	 * from history table else if it 'M' then the component details are loaded from
	 * master table.If strDataFrom is NULL then data is loaded from Master table.
	 * @param strModuleCode
	 * @param strComponentCode
	 * @param strDataFrom
	 */
	public eCRDComponent(String strComponentCode, String strModuleCode, String strDataFrom) throws Exception
	{

		ArrayList arrInParam = null;
		ArrayList arrOutParam = null;
		String strActionId = null;
		GEAEResultSet rsComponentDetails = null;
		GEAEResultSet rsPartDetails = null;
		GEAEResultSet rsSiteDetails = null;
		eCRDSite objECRDSite = null;
		eCRDException objException = null;

		try
		{
			arrInParam = new ArrayList();
			arrOutParam = new ArrayList();

			/*check to see if the primary keys are set
			 * if the component code is not set or the
			 * module code is not set then throw a ecrd exception
			* */

			if (strComponentCode == null || strModuleCode == null || strComponentCode.equals("") || strModuleCode.equals(""))
			{
				objException = new eCRDException();
				objException.setExcpId("INPUT_PARAMETERS_NOT_SET");
				throw objException;

			}

			/*Set the input parameters*/
			arrInParam.add(strComponentCode);
			arrInParam.add(strModuleCode);
			arrInParam.add(strDataFrom);

			/*call procedure returns he components details,part details
			  and site details associated with the component
			  Note: the reapir  information is not loaded.
			*/
			strActionId = eCRDUtil.verifyNull((String) eCRDConstants.getActionId("eCRD_GET_COMPONENT_DETAIL"));
			arrOutParam = eCRDDBMediator.doDBOperation(strActionId, arrInParam);

			/*this resultSet will hold the Component details
			* Note the component details of only Single component
			* are fetched from the database. A resultSet is used only
			* for avoid a long list of variables.
			**/
			rsComponentDetails = (GEAEResultSet) arrOutParam.get(0);

			/*this result set will hold the Part details
			* this result set will hold the part details of all the
			* parts that are associated with the component*/
			rsPartDetails = (GEAEResultSet) arrOutParam.get(1);

			/*this result set will hold the Site  details
			 * this result set will have all the site details
			 * that are associated with the component*/
			rsSiteDetails = (GEAEResultSet) arrOutParam.get(2);

			/*Initialize the result Set so tht they point to first record*/
			rsComponentDetails.setCurrentRow(0);
			rsComponentDetails.next();

			rsPartDetails.setCurrentRow(0);
			rsPartDetails.next();

			rsSiteDetails.setCurrentRow(0);
			rsSiteDetails.next();

			/*set the component attributes that are fetched  from db */
			this.strComponentCode = strComponentCode;
			strComponentDesc = eCRDUtil.verifyNull(rsComponentDetails.getString("compDescription"));
			strATARefNo = eCRDUtil.verifyNull(rsComponentDetails.getString("ataRefNum"));
			strBaseLineTAT = eCRDUtil.verifyNull(rsComponentDetails.getString("baseLineTAT"));
			dtComponentEffDt = eCRDUtil.verifyNull(rsComponentDetails.getString("compEfftDate"));
			strQtyCompPerEngine = eCRDUtil.verifyNull(rsComponentDetails.getString("engQnty"));
			strShopVisitExposureRate = eCRDUtil.verifyNull(rsComponentDetails.getString("shopVistExpRate"));
			strScrapRateAtExposure = eCRDUtil.verifyNull(rsComponentDetails.getString("scrapRateExp"));
			strServicableAtExposure = eCRDUtil.verifyNull(rsComponentDetails.getString("serviceAtExp"));
			strPercetageYield = eCRDUtil.verifyNull(rsComponentDetails.getString("repairYld"));
			strCycValClass = eCRDUtil.verifyNull(rsComponentDetails.getString("class"));
			strTechLvl = eCRDUtil.verifyNull(rsComponentDetails.getString("tech_lvl"));
			strAlternateComponent = eCRDUtil.verifyNull(rsComponentDetails.getString("alternateComp"));

			/*Initialize the Arraylist that will hold all
			 * all the part details
			 * */
			if (arrlstParts == null)
			{
				arrlstParts = new ArrayList();
			}

			/*Iterate through the result set and set the
			 * part number into the arraylist
			 * */
			for (int i = 0; i < rsPartDetails.size(); i++, rsPartDetails.next())
			{
				arrlstParts.add((String) rsPartDetails.getObject("partNumber"));
			}

			/*Initialze the arrayList that holds the reference
			 * to the site related to the component*/
			if (arrlstSites == null)
			{
				arrlstSites = new ArrayList();
			}

			/*
			 the site information associated with the components
			 is stored in an arrayList. to access individual site infromation
			 use the following syntax
			 objECRDSite = (eCRDSite)arrlstSites.get(0);
			 String strSite Code = objECRDSite.getSiteCode();
			*/
			for (int i = 0; i < rsSiteDetails.size(); i++, rsSiteDetails.next())
			{
				objECRDSite = new eCRDSite();
				objECRDSite.setSiteDescription(rsSiteDetails.getString("locName"));
				objECRDSite.setSiteCode(rsSiteDetails.getString("locCode"));
				objECRDSite.setLocationLaborRate(eCRDUtil.verifyDouble(rsSiteDetails.getString("laborRate")));
// Added new For Hide Component Indicator
				objECRDSite.setHideComponentInd(eCRDUtil.verifyNull(rsSiteDetails.getString("hideCompInd")));
// End of Added New
				this.arrlstSites.add(objECRDSite);
			}
		}
		/*Destroy all the objects used. */
		finally
		{
			arrInParam = null;
			arrOutParam = null;
			strActionId = null;
			rsComponentDetails = null;
			rsPartDetails = null;
			rsSiteDetails = null;
			objECRDSite = null;
		}
	}

	/**
	 * Default Constructor
	 */
	public eCRDComponent()
	{

	}

	/**
	 * Returns the component code.
	 * @return String
	 */
	public String getComponentCode()
	{
		return strComponentCode;
	}

	/**
	 * Returns the component description.
	 * @return String
	 */
	public String getComponentDesc()
	{
		return strComponentDesc;
	}

	/**
	 * Returns the ATA Reference Number
	 * @return String
	 */
	public String getATARefNo()
	{
		return strATARefNo;
	}

	/**
	 * Returns Baseline TAT
	 * @return int
	 */
	public String getBaseLineTAT()
	{
		return strBaseLineTAT;
	}

	/**
	 * Returns Component Effective Date
	 * @return String
	 */
	public String getComponentEffDt()
	{
		return dtComponentEffDt;
	}

	/**
	 * Returns Class
	 * @return String
	 */
	public String getCycValClass()
	{
		return strCycValClass;
	}

	/**
	 * Returns strTechLvl
	 * @return String
	 */
	public String getTechLvl()
	{
		return strTechLvl;
	}
	
	/**
	 * Returns Quantity Parts per Set
	 * @return int
	 */
	public String getQtyCompPerEngine()
	{
		return strQtyCompPerEngine;
	}

	/**
	 * Returns Component Shop Visit Exposure Rate
	 * @return String
	 */
	public String getShopVisitExposureRate()
	{
		return strShopVisitExposureRate;
	}

	/**
	 * Returns Component Scrap Exposure Rate
	 * @return String
	 */
	public String getScrapRateAtExposure()
	{
		return strScrapRateAtExposure;
	}

	/**
	 * Returns Serviceable at Exposure Rate
	 * @return String
	 */
	public String getServicableAtExposure()
	{
		return strServicableAtExposure;
	}

	/**
	 * Returns % Age Repair Yield
	 * @return String
	 */
	public String getPercentageYield()
	{
		return strPercetageYield;
	}

	/**
	 * Sets Component Code
	 * @param strComponentCode
	 */
	public void setComponentCode(String strComponentCode)
	{
		this.strComponentCode = strComponentCode;
	}

	/**
	 * Sets  Component Description
	 * @param strComponentDesc
	 */
	public void setComponentDesc(String strComponentDesc)
	{
		this.strComponentDesc = strComponentDesc;
	}

	/**
	 * Sets ATA Reference Number
	 * @param strATARefNo
	 */
	public void setATARefNo(String strATARefNo)
	{
		this.strATARefNo = strATARefNo;
	}

	/**
	 * Sets Baseline TAT
	 * @param intBaseLineTAT
	 */
	public void setBaseLineTAT(String strBaseLineTAT)
	{
		this.strBaseLineTAT = strBaseLineTAT;
	}

	/**
	 * Sets Component Effective Date
	 * @param dtComponentEffDt
	 */
	public void setComponentEffDt(String dtComponentEffDt)
	{
		this.dtComponentEffDt = dtComponentEffDt;
	}

	/**
	 * Sets Class
	 * @param strCycValClass
	 */
	public void setCycValClass(String strCycValClass)
	{
		this.strCycValClass = strCycValClass;
	}

	/**
	 * Sets Tech Level
	 * @param strTechLvl
	 */
	public void setTechLvl(String strTechLvl)
	{
		this.strTechLvl = strTechLvl;
	}
	
	/**
	 * Sets Quantity Parts per Set
	 * @param intQTYCompPerEngine
	 */
	public void setQtyCompPerEngine(String strQTYCompPerEngine)
	{
		this.strQtyCompPerEngine = strQTYCompPerEngine;
	}

	/**
	 * Sets Component Shop Visit Exposure Rate
	 * @param strShopVisitExposureRate
	 */
	public void setShopVisitExposureRate(String strShopVisitExposureRate)
	{
		this.strShopVisitExposureRate = strShopVisitExposureRate;
	}

	/**
	 * Sets Component Scrap Exposure Rate
	 * @param strScrapRateAtExposure
	 */
	public void setScrapRateAtExposure(String strScrapRateAtExposure)
	{
		this.strScrapRateAtExposure = strScrapRateAtExposure;
	}

	/**
	 * Sets 	Serviceable at Exposure Rate
	 * @param strServicableArExposure
	 */
	public void setServicableAtExposure(String strServicableArExposure)
	{
		this.strServicableAtExposure = strServicableArExposure;
	}

	/**
	 * Sets % Age Repair Yield
	 * @param strPercentageYield
	 */
	public void setPercentageYield(String strPercentageYield)
	{
		this.strPercetageYield = strPercentageYield;
	}

	/**
	 * Sets the refernce of the Module associated with the component
	 * @return void
	 */
	public void setModule(eCRDModule objeCRD)
	{
		objECRDModule = objeCRD;

	}

	/**
	 * returns the Module object associated with the component.
	 * @return void
	 */
	public eCRDModule getModule()
	{
		return objECRDModule;
	}

	/**
	 * The method updates the component details. The old values are moved
	 * @return String
	 * @throws Exception
	 */
	public String update(String strUserId, String strUserRole) throws Exception
	{

		ArrayList arrlstInpParam = null;
		ArrayList arrlstOutParam = null;
		String strActionId = null;
		String strModuleCode = null;
		String strEngineModel = null;
		eCRDException objException = null;
		eCRDSite objSite = null;
		eCRDEngineModel objECRDEngModel = null;
		StringBuffer strCompSiteBuff = null;
		StringBuffer strPartDetailsBuff = null;
		String strMessage = null;

		try
		{

			arrlstInpParam = new ArrayList();
			arrlstOutParam = new ArrayList();
			strCompSiteBuff = new StringBuffer();
			strPartDetailsBuff = new StringBuffer();

			/*check if the primarykeys required to update
			 * the details are not null or empty
			 **/

			if (this.strComponentCode == null
				|| objECRDModule == null
				|| strUserId == null
				|| strUserRole == null
				|| this.strComponentCode.equals("")
				|| strUserId.equals("")
				|| strUserRole.equals(""))
			{
				objException = new eCRDException();
				objException.setExcpId("INPUT_PARAMETERS_NOT_SET");
				throw objException;
			}

			/*fetch the module code associated with the component*/

			strModuleCode = objECRDModule.getModuleCode();

			objECRDEngModel = objECRDModule.getEngineModel();

			/*check if the engine model is set or not*/
			if (objECRDEngModel == null)
			{
				objException = new eCRDException();
				objException.setExcpId("ENIGNE_MODEL_NOT_SET");
				throw objException;
			}

			/*fetch the engine model code assocaited witht he component*/
			strEngineModel = objECRDEngModel.getEngineModelCode();

			strActionId = eCRDConstants.getActionId("eCRD_UPDATE_COMPONENT");

			/* set the modified component details as input
			 * parameters to the procedure
			 **/

			arrlstInpParam.add(eCRDUtil.verifyNull(this.strComponentCode));
			arrlstInpParam.add(eCRDUtil.verifyNull(this.strComponentDesc));

			arrlstInpParam.add(eCRDUtil.verifyNull(strEngineModel));

			arrlstInpParam.add(eCRDUtil.verifyNull(strModuleCode));

			arrlstInpParam.add(eCRDUtil.verifyNull(this.strATARefNo));

			arrlstInpParam.add(eCRDUtil.verifyNull(this.strBaseLineTAT));

			arrlstInpParam.add(eCRDUtil.verifyNull(this.dtComponentEffDt));

			arrlstInpParam.add(eCRDUtil.verifyNull(this.strCycValClass));

			arrlstInpParam.add(eCRDUtil.verifyNull(this.strQtyCompPerEngine));

			arrlstInpParam.add(eCRDUtil.verifyNull(this.strShopVisitExposureRate));

			arrlstInpParam.add(eCRDUtil.verifyNull(this.strScrapRateAtExposure));

			arrlstInpParam.add(eCRDUtil.verifyNull(this.strServicableAtExposure));

			arrlstInpParam.add(eCRDUtil.verifyNull(this.strPercetageYield));

			arrlstInpParam.add(eCRDUtil.verifyNull(this.strAlternateComponent));

			/*  create a delimted string of sites associated with component
			 * iterate through the arraylist of sites and convert into a delimted string
			 * each object will be converted into a row.
			 */
			for (int i = 0; i < arrlstSites.size(); i++)
			{
				objSite = (eCRDSite) arrlstSites.get(i);
				strCompSiteBuff.append(objSite.getSiteCode());
				strCompSiteBuff.append(eCRDConstants.STRCOLUMNDELIM);
				strCompSiteBuff.append(eCRDUtil.verifyNull(this.strComponentCode));
				strCompSiteBuff.append(eCRDConstants.STRCOLUMNDELIM);
				strCompSiteBuff.append(eCRDUtil.verifyNull(strModuleCode));
				strCompSiteBuff.append(eCRDConstants.STRCOLUMNDELIM);
/* Added New For Hide Component Indicator */
				strCompSiteBuff.append(objSite.getHideComponentInd());
				strCompSiteBuff.append(eCRDConstants.STRCOLUMNDELIM);
/* End Of Added New Code For Hide Component Indicator */
				strCompSiteBuff.append(eCRDConstants.STRROWDELIM);

			}

			// create a delimted string of parts  associated with component
			for (int i = 0; i < arrlstParts.size(); i++)
			{
				strPartDetailsBuff.append((String) arrlstParts.get(i));
				strPartDetailsBuff.append(eCRDConstants.STRCOLUMNDELIM);
				strPartDetailsBuff.append(eCRDUtil.verifyNull(this.strComponentCode));
				strPartDetailsBuff.append(eCRDConstants.STRCOLUMNDELIM);
				strPartDetailsBuff.append(eCRDUtil.verifyNull(strModuleCode));
				strPartDetailsBuff.append(eCRDConstants.STRCOLUMNDELIM);
				strPartDetailsBuff.append(eCRDConstants.STRROWDELIM);
			}

			/*set the component details,site detail part details strings as input parameter  */
			arrlstInpParam.add(strCompSiteBuff.toString());
			arrlstInpParam.add(strPartDetailsBuff.toString());
			arrlstInpParam.add(strUserId);
			arrlstInpParam.add(strUserRole);
			arrlstInpParam.add(eCRDConstants.STRROWDELIM);
			arrlstInpParam.add(eCRDConstants.STRCOLUMNDELIM);
			arrlstInpParam.add(eCRDUtil.verifyNull(this.strTechLvl));

			arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);
			strMessage = (String) arrlstOutParam.get(0);
			return strMessage;
		}
		finally
		{
			arrlstInpParam = null;
			arrlstOutParam = null;
			strActionId = null;
			strModuleCode = null;
			strEngineModel = null;
			objException = null;
			objSite = null;
			objECRDEngModel = null;
			strCompSiteBuff = null;
			strPartDetailsBuff = null;
			strMessage = null;
		}
	}

	public String updateSites(String strUserId) throws Exception
	{

		ArrayList arrlstInpParam = null;
		ArrayList arrlstOutParam = null;
		String strActionId = null;
		String strModuleCode = null;
		String strEngineModel = null;
		eCRDException objException = null;
		eCRDSite objSite = null;
		eCRDEngineModel objECRDEngModel = null;
		StringBuffer strCompSiteBuff = null;
		String strMessage = null;
		try
		{
			arrlstInpParam = new ArrayList();
			arrlstOutParam = new ArrayList();
			strCompSiteBuff = new StringBuffer();

			/*check if the primarykeys required to update
			 * the details are not null or empty
			 **/

			if (this.strComponentCode == null || objECRDModule == null || strUserId == null || this.strComponentCode.equals("") || strUserId.equals(""))
			{
				objException = new eCRDException();
				objException.setExcpId("INPUT_PARAMETERS_NOT_SET");
				throw objException;
			}

			/*fetch the module code associated with the component*/

			strModuleCode = objECRDModule.getModuleCode();

			objECRDEngModel = objECRDModule.getEngineModel();

			/*check if the engine model is set or not*/
			if (objECRDEngModel == null)
			{
				objException = new eCRDException();
				objException.setExcpId("ENIGNE_MODEL_NOT_SET");
				throw objException;
			}

			/*fetch the engine model code assocaited witht he component*/
			strEngineModel = objECRDEngModel.getEngineModelCode();

			strActionId = eCRDConstants.getActionId("eCRD_UPDATE_COMPONENT_SITE");

			/* set the modified component details as input
			 * parameters to the procedure
			 **/

			/*  create a delimted string of sites associated with component
			 * iterate through the arraylist of sites and convert into a delimted string
			 * each object will be converted into a row.
			 */
			for (int i = 0; i < arrlstSites.size(); i++)
			{
				objSite = (eCRDSite) arrlstSites.get(i);
				strCompSiteBuff.append(objSite.getSiteCode());
				strCompSiteBuff.append(eCRDConstants.STRCOLUMNDELIM);
				strCompSiteBuff.append(eCRDUtil.verifyNull(this.strComponentCode));
				strCompSiteBuff.append(eCRDConstants.STRCOLUMNDELIM);
				strCompSiteBuff.append(eCRDUtil.verifyNull(strModuleCode));
				strCompSiteBuff.append(eCRDConstants.STRCOLUMNDELIM);
/* Added new for Hide Component Indicator*/
				strCompSiteBuff.append(objSite.getHideComponentInd());
				strCompSiteBuff.append(eCRDConstants.STRCOLUMNDELIM);
/* End of Added new for Hide Component Indicator*/
				strCompSiteBuff.append(eCRDConstants.STRROWDELIM);
			}

			/*set the site detail strings as input parameter  */
			arrlstInpParam.add(strCompSiteBuff.toString());
			arrlstInpParam.add(strUserId);
			arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);
			strMessage = (String) arrlstOutParam.get(0);
			return strMessage;
		}
		finally
		{
			arrlstInpParam = null;
			arrlstOutParam = null;
			strActionId = null;
			strModuleCode = null;
			strEngineModel = null;
			objException = null;
			objSite = null;
			objECRDEngModel = null;
			strCompSiteBuff = null;
			strMessage = null;
		}
	}

	/**
	 * Removes component and its related entities from the database
	 * the plsql asscocated with this method will delete all the
	 * reparis, sites & parts assocated with this component. if the
	 * delete is successful at the database end, only then will the
	 * component object be destroyed.
	 *
	 * Remove component object from the list of components
		* @param String strCompSeqId,String strModelCd,String strCatalogSeqId,String strUserId,String strUserRole
		* @throws Exception
		*/
	public String removeComponent(String strCompSeqId, String strUserId, String strUserRole) throws Exception
	{
		ArrayList arrlstInData = null;
		ArrayList arrlstOutData = null;
		String strMessage = null;
		String strActionId = null;
		String strModuleCode = null;
		eCRDException objException = null;
		eCRDEngineModel objECRDEngModel = null;
		eCRDCatalog objECRDCatalog = null;
		String strCatalogSeqId = null;
		try
		{
			strActionId = eCRDConstants.getActionId("eCRD_REMOVE_COMPONENT");

			if (strActionId == null
				|| strCompSeqId == null
				|| objECRDModule == null
				|| strUserId == null
				|| strUserRole == null
				|| strActionId.equals("")
				|| strCompSeqId.equals("")
				|| strUserId.equals("")
				|| strUserRole.equals(""))
			{
				objException = new eCRDException();
				objException.setExcpId("INPUT_PARAMETERS_NOT_SET");
				throw objException;
			}
			strModuleCode = objECRDModule.getModuleCode();

			objECRDEngModel = objECRDModule.getEngineModel();
			if (objECRDEngModel == null)
			{
				objException = new eCRDException();
				objException.setExcpId("ENIGNE_MODEL_NOT_SET");
				throw objException;
			}

			objECRDCatalog = objECRDEngModel.getCatalog();
			if (objECRDCatalog == null)
			{
				objException = new eCRDException();
				objException.setExcpId("ENIGNE_MODEL_NOT_SET");
				throw objException;
			}
			strCatalogSeqId = objECRDCatalog.getCatalogSeqId();

			arrlstInData.add(strCatalogSeqId);
			arrlstInData.add(strModuleCode);
			arrlstInData.add(strCompSeqId);
			arrlstInData.add(strUserId);
			arrlstInData.add(strUserRole);

			// This will delete all the repairs and all the Data releated to this Component
			arrlstOutData = eCRDDBMediator.doDBOperation(strActionId, arrlstInData);
			strMessage = (String) arrlstOutData.get(0);

			this.arrlstParts = null;
			this.arrlstRepair = null;
			this.dtComponentEffDt = null;
			this.strBaseLineTAT = null;
			this.strQtyCompPerEngine = null;
			this.objECRDModule = null;
			this.strATARefNo = null;
			this.strComponentCode = null;
			this.strComponentDesc = null;
			this.strCycValClass = null;
			this.strTechLvl = null;
			this.strPercetageYield = null;
			this.strScrapRateAtExposure = null;
			this.strServicableAtExposure = null;
			this.strShopVisitExposureRate = null;
			return strMessage;
		}

		finally
		{
			arrlstInData = null;
			arrlstOutData = null;
			strMessage = null;
			strActionId = null;
		}

	}

	/**
	 * Creates eCRDRepair object and adds it to ArrayList of repairs in
	 * the component. Returns reference to the either CRDGroupedRepair
	 * object or eCRDIndRepair object depending on the strRepairType
	 * passed to it.
	 * @return ecrd.biz.eCRDRepair
	 */
	public eCRDRepair addRepair(String strRepairType) throws Exception
	{
		eCRDRepair objRepair = null;
		if (arrlstRepair == null)
		{
			arrlstRepair = new ArrayList();
		}
		// Check what type of object instance is requested
		if (strRepairType.equalsIgnoreCase(eCRDConstants.STRGROUPREPAIR)
			|| strRepairType.equalsIgnoreCase(eCRDConstants.STRMERGEREPAIR)
			|| strRepairType.equalsIgnoreCase(eCRDConstants.STRSPECIALGROUPREPAIR))
		{
			//instantiate the eCRDGroupedRepair object.

			objRepair = new eCRDGroupedRepair();
			objRepair.setRepairType(strRepairType.toUpperCase());
			//objRepair.setRepairCode("");
			// add the Repair object to the ArrayList of Repairs associated with Component
			arrlstRepair.add(objRepair);
		} // end of if
		else
		{
			if (strRepairType.equalsIgnoreCase(eCRDConstants.STRINDIVIDUALREPAIR)
				|| strRepairType.equalsIgnoreCase(eCRDConstants.STRSLITREPAIR)
				|| strRepairType.equalsIgnoreCase(eCRDConstants.STRSPECIALINDIVIDUALREPAIR))
			{
				//instantiate the eCRDGroupedRepair object.
				objRepair = new eCRDIndRepair();
				// add the Repair object to the ArrayList of Repairs associated with Component
				objRepair.setRepairType(strRepairType.toUpperCase());
				///objRepair.setRepairCode("");
				arrlstRepair.add(objRepair);
			}
		} //end of else
		return objRepair;
	}

	/**
	 * Removes the repair from Db. If a approval is pending then the repair can't be
	 * deleted. If this is the last repair.  then it removes the component as
	 * well.
	 * @param strReapirCode
	 * @throws Exception
	 */
	public String removeRepair(String strRepairCode, String strUserId, String strUserRole) throws Exception
	{
		ArrayList arrlstInpParam = null;
		ArrayList arrlstOutParam = null;
		String strActionId = null;
//		String strErrorMsg = null;
		String strEngModel = null;
		String strCatalogSeqId = null;
		String strEngineModule = null;
		eCRDEngineModel objECRDEngModel = null;
		eCRDCatalog objECRDCatalog = null;
		eCRDException objException = null;

		try
		{
			//Set the action this to call procedure to delete the repair
			strActionId = eCRDConstants.getActionId("eCRD_DELETE_REPAIR");

			//ArrayList of Input Parameters
			arrlstInpParam = new ArrayList();
			//ArrayList of Output Parameters
			arrlstOutParam = new ArrayList();
			//Pass procedure input parameters to ArrayList

			objECRDEngModel = new eCRDEngineModel();
			objECRDCatalog = new eCRDDefaultCatalog();

			if (strActionId == null
				|| objECRDModule == null
				|| this.strComponentCode == null
				|| strActionId.equals("")
				|| this.strComponentCode == ""
				|| strRepairCode == null
				|| strRepairCode.equals("")
				|| strUserId == null
				|| strUserRole == null
				|| strUserId.equals("")
				|| strUserRole == "")
			{
				objException = new eCRDException();
				objException.setExcpId("INPUT_PARAMETERS_NOT_SET");
				throw objException;
			}

			strEngineModule = objECRDModule.getModuleCode();
			objECRDEngModel = objECRDModule.getEngineModel();
			strEngModel = objECRDEngModel.getEngineModelCode();
			objECRDCatalog = objECRDEngModel.getCatalog();
			strCatalogSeqId = objECRDCatalog.getCatalogSeqId();

			if (strEngineModule == null || strEngineModule.equals(""))
			{
				objException = new eCRDException();
				objException.setExcpId("MODULE_CODE_NOT_SET");
				throw objException;
			}

			arrlstInpParam.add(strRepairCode);
			arrlstInpParam.add(strEngineModule);
			arrlstInpParam.add(this.strComponentCode);
			arrlstInpParam.add(strCatalogSeqId);
			arrlstInpParam.add(strUserId);
			arrlstInpParam.add(strUserRole);

			// Call this function to update site details
			arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);
			//Return the message code retrieved from procedure
			return (String) arrlstOutParam.get(0);
		}
		finally
		{
			arrlstInpParam = null;
			arrlstOutParam = null;
			strActionId = null;
//			strErrorMsg = null;
			objECRDEngModel = null;
			strEngModel = null;
			objECRDCatalog = null;
		}

	}

	/**
	 * Adds eCRDSite object to Arraylist of sites a in the component.
	 * @param objSite
		* @return objSite
	 */
	public eCRDSite addSite()
	{
		eCRDSite objECRDSite = null;
		objECRDSite = new eCRDSite();
		if (arrlstSites == null)
		{
			arrlstSites = new ArrayList();
		}
		arrlstSites.add(objECRDSite);
		return objECRDSite;
	}

	/**
	 * the method creates the site objs out of a delimted string
	 * @param strSites
	 */

	public void addSite(String strSites)
	{
		eCRDSite objECRDSite = null;
		StringTokenizer stk = null;

		strSites = strSites + eCRDConstants.STRCOLUMNDELIM;

		if (arrlstSites == null)
		{
			arrlstSites = new ArrayList();
		}
		stk = new StringTokenizer(strSites, eCRDConstants.STRCOLUMNDELIM);
		while (stk.hasMoreTokens())
		{
			objECRDSite = new eCRDSite();
			objECRDSite.setSiteCode(eCRDUtil.verifyNull(stk.nextToken()));
			objECRDSite.setLocationLaborRate(Double.parseDouble(stk.nextToken()));
			objECRDSite.setSiteDescription(eCRDUtil.verifyNull(stk.nextToken()));
			objECRDSite.setHideComponentInd(stk.nextToken());
			arrlstSites.add(objECRDSite);

		}
	}

	/**
	 * The methods removes the site from the Db. It aslo
	 * deletes the reference of this site in the arraylist of
	 * sites associated with the compnent
	 * @param ,String strUser_role,String strUser_id
	 * @return String
	 * @throws Exception
	 */
	public String removeSite(String[] strSiteCode, String strUserRole, String strUserId) throws Exception
	{
		ArrayList arrlstInpParam = null;
		ArrayList arrlstOutParam = null;
		String strActionId = null;
//		String strErrorMsg = null;
		String strModule = null;
		eCRDSite objSite = null;
		eCRDException objException = null;
		String strMesg = null;
		StringBuffer strSiteCodeBuff = null;
		try
		{
			//Set the action this to call procedure to delete the repair
			strActionId = eCRDConstants.getActionId("eCRD_DELETE_SITE");
			//ArrayList of Input Parameters
			arrlstInpParam = new ArrayList();
			//ArrayList of Output Parameters
			arrlstOutParam = new ArrayList();
			//Pass procedure input parameters to ArrayList

			if (objECRDModule == null || this.strComponentCode == null || this.strComponentCode.equals(""))
			{
				objException = new eCRDException();
				objException.setExcpId("INPUT_PARAMETERS_NOT_SET");
				throw objException;
			}
			strSiteCodeBuff = new StringBuffer();

			for (int i = 0; i < strSiteCode.length; i++)
			{
				strSiteCodeBuff.append(strSiteCode[i]);
				strSiteCodeBuff.append(eCRDConstants.STRCOLUMNDELIM);

			}
			strSiteCodeBuff.append(eCRDConstants.STRROWDELIM);
			strModule = objECRDModule.getModuleCode();

			if (strModule == null || strUserRole == null || strUserId == null || strModule.equals("") || strUserRole.equals("") || strUserId.equals(""))
			{
				objException = new eCRDException();
				objException.setExcpId("INPUT_PARAMETERS_NOT_SET");
				throw objException;
			}

			arrlstInpParam.add(this.strComponentCode);
			arrlstInpParam.add(strModule);
			arrlstInpParam.add(strSiteCodeBuff.toString());
			arrlstInpParam.add(strUserRole);
			arrlstInpParam.add(strUserId);
			// Call this function to update site details
			arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);
			strMesg = (String) arrlstOutParam.get(0);
			if (strMesg.equalsIgnoreCase("SUCCESS"))
			{
				objSite = new eCRDSite();
				// iterate though the arrlist of sites and remove there the
				// site obj from the list
				for (int i = 0; i < arrlstSites.size(); i++)
				{
					objSite = (eCRDSite) arrlstSites.get(0);
					if (objSite.getSiteCode().equalsIgnoreCase(strSiteCode[i]))
					{
						arrlstSites.remove(i);
						break;
					}
				}
			}
			return (String) arrlstOutParam.get(0);
		}

		finally
		{
			arrlstInpParam = null;
			arrlstOutParam = null;
			strActionId = null;
//			strErrorMsg = null;
			strModule = null;
			objSite = null;
		}

	}
	/**
	 * Retruns fully loaded object of the eCRDRepair class which is contained in
	 * current component. The object is returned based on repair code.
	 * If the object is not in hasMap call constructor with parameters for the class
	 * and load the object and add it to the hashmap.
	 * If the repair object is in hashmap and it is not fully loaded then calls
	 * constructor with parameters for the component object and assigns new object to
	 * the exisitng reference.
	 * @param strRepairCode
	 * @return ecrd.biz.eCRDRepair
	 */
	public eCRDRepair getRepair(String strRepairCode, String strRepairType) throws Exception
	{

		boolean blnFound = false;
		eCRDRepair objeCRDRepair = null;
		String strCatalogId = "";
		
		try
		{
			if (this.arrlstRepair != null)
			{
				for (int i = 0; i < this.arrlstRepair.size(); i++)
				{
					objeCRDRepair = (eCRDRepair) arrlstRepair.get(i);
					
					if (strRepairCode.equalsIgnoreCase(objeCRDRepair.getStrRepairCode()) 
                            && strRepairType.equalsIgnoreCase(objeCRDRepair.getRepairType()))
					{
						blnFound = true;
						break;
					}
				}
			}
			else
			{
				this.arrlstRepair = new ArrayList();
			}
			
			strCatalogId = eCRDUtil.verifyNull(this.getModule().getEngineModel().getCatalog().getCatalogSeqId());

			if ("".equals(strCatalogId))
			{
				strCatalogId = eCRDCatalog.getCurrentDefaultSeqId(this.getModule().getEngineModel().getEngineModelCode());
			}
			
			if (!blnFound)
			{
				if (strRepairType.equals(eCRDConstants.STRINDIVIDUALREPAIR)
					|| strRepairType.equalsIgnoreCase(eCRDConstants.STRSLITREPAIR)
					|| strRepairType.equalsIgnoreCase(eCRDConstants.STRSPECIALINDIVIDUALREPAIR))
				{
					objeCRDRepair = (eCRDRepair) new eCRDIndRepair(strRepairCode, this.objECRDModule.getModuleCode(), this.getComponentCode(), strCatalogId);
					objeCRDRepair.setRepairType(strRepairType.toUpperCase());
				}
				
				else if (
							strRepairType.equals(eCRDConstants.STRGROUPREPAIR)
							|| strRepairType.equalsIgnoreCase(eCRDConstants.STRMERGEREPAIR)
							|| strRepairType.equalsIgnoreCase(eCRDConstants.STRSPECIALGROUPREPAIR))
				{
                    objeCRDRepair = (eCRDRepair) new eCRDGroupedRepair(strRepairCode, this.objECRDModule.getModuleCode(), this.getComponentCode(), strCatalogId);
                    objeCRDRepair.setRepairType(strRepairType.toUpperCase());
				}
				
				objeCRDRepair.setECRDComponent(this);
				arrlstRepair.add(objeCRDRepair);
				
			}

			return objeCRDRepair;
			
		}
		
		finally
		{

		}
		
		
	}

	/**
	 * Retrieves arrayList of Sites in order of the Site display sequence id.
	 * @return ArrayList
	 * @throws Exception
	 */
	public ArrayList getSiteList() throws GEAESQLException, Exception
	{

		try
		{
			if (this.arrlstSites != null && this.arrlstSites.size() > 0)
			{
				return this.arrlstSites;
			}
			return getSiteListStageMaster();
		}
		finally
		{

		}
	}
	/**
	 * Retrieves arrayList of Sites in order of the Site display sequence id.
	 * @return ArrayList
	 * @throws Exception
	 */
	public ArrayList getSiteListStageMaster() throws GEAESQLException, Exception
	{

		GEAEResultSet rsSiteDetails = null;
		eCRDSite objECRDSite = null;
		ArrayList arrlstInpParam = null;
		ArrayList arrOutParam = null;
		String strActionId = null;
		String strEngineModule = null;
		eCRDException objException = null;

		try
		{

			arrlstInpParam = new ArrayList();
			arrOutParam = new ArrayList();
			arrlstSites = new ArrayList();

			if (objECRDModule == null || this.strComponentCode == null || this.strComponentCode.equals(""))
			{
				objException = new eCRDException();
				objException.setExcpId("INPUT_PARAMETERS_NOT_SET");
				throw objException;
			}
			strEngineModule = objECRDModule.getModuleCode();
			arrlstInpParam.add(strEngineModule);
			arrlstInpParam.add(this.strComponentCode);
			strActionId = eCRDUtil.verifyNull((String) eCRDConstants.getActionId("eCRD_GET_SITE_DETAL"));

			arrOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);
			rsSiteDetails = (GEAEResultSet) arrOutParam.get(0);

			rsSiteDetails.setCurrentRow(0);
			rsSiteDetails.next();

			/*clear the previous list of sites.
			  and get the latest list from the database*/

			arrlstSites = null;
			arrlstSites = new ArrayList();

			/*iterate through the resultSet & populate
			  the site arrayList*/

			for (int i = 0; i < rsSiteDetails.size(); i++, rsSiteDetails.next())
			{
				objECRDSite = new eCRDSite();
				objECRDSite.setSiteCode(eCRDUtil.verifyNull(rsSiteDetails.getString("locCode")));
				objECRDSite.setLocationLaborRate(eCRDUtil.verifyDouble(rsSiteDetails.getString("laborRate")));
				objECRDSite.setSiteDescription(eCRDUtil.verifyNull(rsSiteDetails.getString("locName")));
//					Added new For Hide Component Indicator
				 objECRDSite.setHideComponentInd(eCRDUtil.verifyNull(rsSiteDetails.getString("hideCompInd")));
//					End of Added New
				arrlstSites.add(objECRDSite);
			}
			return arrlstSites;
		}
		finally
		{
			rsSiteDetails = null;
		}
	}

	/**
	 * Returns the list of sites present in the main table only for a component
	 * @param strSiteNo
	 * @return
	 * @throws Exception
	 */
	public ArrayList getMasterSiteList() throws GEAESQLException, Exception
	{

		GEAEResultSet rsSiteDetails = null;
		eCRDSite objECRDSite = null;
		ArrayList arrlstInpParam = null;
		ArrayList arrOutParam = null;
		String strActionId = null;
		String strEngineModule = null;
		eCRDException objException = null;

		if (this.arrlstSites != null && this.arrlstSites.size() > 0)
		{
			return arrlstSites;
		}
		try
		{
			arrlstInpParam = new ArrayList();
			arrOutParam = new ArrayList();
			arrlstSites = new ArrayList();

			if (objECRDModule == null || this.strComponentCode == null || this.strComponentCode.equals(""))
			{
				objException = new eCRDException();
				objException.setExcpId("INPUT_PARAMETERS_NOT_SET");
				throw objException;
			}
			strEngineModule = objECRDModule.getModuleCode();
			arrlstInpParam.add(strEngineModule);
			arrlstInpParam.add(this.strComponentCode);
			arrlstInpParam.add("Master");
			strActionId = eCRDUtil.verifyNull((String) eCRDConstants.getActionId("eCRD_GET_SITE_DETAL"));

			arrOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);
			rsSiteDetails = (GEAEResultSet) arrOutParam.get(0);

			rsSiteDetails.setCurrentRow(0);
			rsSiteDetails.next();

			/*clear the previous list of sites.
				 and get the latest list from the database*/

			arrlstSites = null;
			arrlstSites = new ArrayList();

			/*iterate through the resultSet & populate
				 the site arrayList*/

			for (int i = 0; i < rsSiteDetails.size(); i++, rsSiteDetails.next())
			{
				objECRDSite = new eCRDSite();
				objECRDSite.setSiteCode(eCRDUtil.verifyNull(rsSiteDetails.getString("locCode")));
				objECRDSite.setLocationLaborRate(eCRDUtil.verifyDouble(rsSiteDetails.getString("laborRate")));
				objECRDSite.setSiteDescription(eCRDUtil.verifyNull(rsSiteDetails.getString("locName")));
//				Added new For Hide Component Indicator
				objECRDSite.setHideComponentInd(eCRDUtil.verifyNull(rsSiteDetails.getString("hideCompInd")));
//				End of Added New
				arrlstSites.add(objECRDSite);
			}
			return arrlstSites;
		}
		finally
		{
			rsSiteDetails = null;
		}
	}

	/**
	 * Retruns object of the eCRDSite class which is contained in current component.
	 * The object is returned based on Site  code.
	 * If the object is not in arrayLsit call constructor with parameters and load the
	 * object and add it to the arraylist.
	 * @param strSiteNo
	 * @return ecrd.biz.eCRDSite
	 * @throws Exception
	 */
	public eCRDSite getSite(String strSiteNo) throws Exception
	{
		eCRDException objException = null;
		eCRDSite objECRDSite = null;

		if (strSiteNo == null || strSiteNo.equals(""))
		{
			objException = new eCRDException();
			objException.setExcpId("INPUT_PARAMETERS_NOT_SET");
			throw objException;
		}
		//call this consttuctor which will give u a fully loaded site
		objECRDSite = new eCRDSite(strSiteNo);

		return objECRDSite;
	}

	/**
	 * Returns history of approvals for the current component. This does not include
	 * the pending approval. The method returns a resultSet containing history details
	 * @return ArrayList
	 * @throws Exception
	 */
	public GEAEResultSet getApprovalHistory() throws Exception
	{

		/*NOT VERY CLEAR AS TO WHT THIS SHOULD DO
		 * SHOULD I BE RETURNING*/

//		GEAEResultSet rsApprHistory = null;
		ArrayList arrInParam = null;
		ArrayList arrOutParam = null;
		String strActionId = null;
		eCRDException objException = null;
		String strModuleCode = null;

		try
		{
			arrInParam = new ArrayList();
			arrOutParam = new ArrayList();
			arrlstSites = new ArrayList();

			if (objECRDModule == null || this.strComponentCode == null || this.strComponentCode.equals(""))
			{
				objException = new eCRDException();
				objException.setExcpId("INPUT_PARAMETERS_NOT_SET");
				throw objException;
			}
			strModuleCode = objECRDModule.getModuleCode();
			arrInParam.add(this.strComponentCode);
			arrInParam.add(strModuleCode);
			strActionId = eCRDUtil.verifyNull((String) eCRDConstants.getActionId("eCRD_GET_APPR_HISTORY"));
			arrOutParam = eCRDDBMediator.doDBOperation(strActionId, arrInParam);
			return ((GEAEResultSet) arrOutParam.get(0));
		}
		finally
		{
//			rsApprHistory = null;
			arrInParam = null;
			arrOutParam = null;
			strActionId = null;
		}

	}

	/**
	 * Checks whether the approval requests are pending.
	 * @return boolean
	 * @throws Exception
	 */
	public boolean isApprovalRequestPending() throws Exception
	{

		ArrayList arrInParam = null;
		ArrayList arrOutParam = null;
		String strActionId = null;
		String strStatus = null;
		boolean isApprReqPending = false;
		eCRDException objException = null;
		String strModuleCode = null;
		try
		{
			arrInParam = new ArrayList();
			arrOutParam = new ArrayList();

			if (objECRDModule == null || this.strComponentCode == null || this.strComponentCode.equals(""))
			{
				objException = new eCRDException();
				objException.setExcpId("INPUT_PARAMETERS_NOT_SET");
				throw objException;
			}
			strModuleCode = objECRDModule.getModuleCode();
			arrInParam.add(this.strComponentCode);
			arrInParam.add(strModuleCode);

			strActionId = eCRDUtil.verifyNull((String) eCRDConstants.getActionId("eCRD_GET_REQUEST_STATUS"));
			arrOutParam = eCRDDBMediator.doDBOperation(strActionId, arrInParam);
			strStatus = (String) arrOutParam.get(0);
			if (strStatus.equalsIgnoreCase(eCRDConstants.STRTRUE))
			{
				isApprReqPending = true;
			}
			else
			{
				isApprReqPending = false;
			}
			return isApprReqPending;
		}
		finally
		{

			arrInParam = null;
			arrOutParam = null;
			strActionId = null;
		}

	}

	/**
	 * Returns pending approval request for the current component. If there is no
	 * pending approval request then returns null.
	 * @return ecrd.biz.eCRDApprovalRequest
	 * @throws Exception
	 */
	public eCRDComponentApproval getApprovalRequestDetails() throws Exception
	{

		GEAEResultSet rsArroveRequestDetails = null;
		ArrayList arrInParam = null;
		ArrayList arrOutParam = null;
		String strActionId = null;
		eCRDComponentApproval objCompAppr = null;
		String strModuleCode = null;
		eCRDException objException = null;
		eCRDEngineModel objECRDEngModel = null;
		String strEngineModel = null;
		try
		{
			arrInParam = new ArrayList();
			arrOutParam = new ArrayList();

			objCompAppr = new eCRDComponentApproval();
			objECRDEngModel = new eCRDEngineModel();

			if (objECRDModule == null || this.strComponentCode == null || this.strComponentCode.equals(""))
			{
				objException = new eCRDException();
				objException.setExcpId("INPUT_PARAMETERS_NOT_SET");
				throw objException;
			}

			strModuleCode = objECRDModule.getModuleCode();

			objECRDEngModel = objECRDModule.getEngineModel();

			if (objECRDEngModel == null)
			{
				objException = new eCRDException();
				objException.setExcpId("MODEL_OBJECT_NOT_SET");
				throw objException;
			}
			strEngineModel = objECRDEngModel.getEngineModelCode();

			arrInParam.add(strModuleCode);
			arrInParam.add(this.strComponentCode);

			strActionId = eCRDUtil.verifyNull((String) eCRDConstants.getActionId("eCRD_GET_APPROVAL_REQUEST_DETAL"));

			arrOutParam = eCRDDBMediator.doDBOperation(strActionId, arrInParam);
			rsArroveRequestDetails = (GEAEResultSet) arrOutParam.get(0);
			rsArroveRequestDetails.next();
			objCompAppr.setApprovalComponent(this);

			objCompAppr.setApprovedBy(rsArroveRequestDetails.getString(1));
			objCompAppr.setApprovedDate(rsArroveRequestDetails.getString(2));
			objCompAppr.setRequestorSite(rsArroveRequestDetails.getString(3));
			objCompAppr.setRequestedBy(rsArroveRequestDetails.getString(4));
			objCompAppr.setRequestStatus(rsArroveRequestDetails.getString(5));
			objCompAppr.setChgType(rsArroveRequestDetails.getString(6));
			objCompAppr.setRequestorMailId(rsArroveRequestDetails.getString(8));
			objCompAppr.setRequestDate(rsArroveRequestDetails.getString(7));
			objCompAppr.setRequestorSiteCd(rsArroveRequestDetails.getString(9));
			return objCompAppr;
		}
		finally
		{
			rsArroveRequestDetails = null;
			arrInParam = null;
			arrOutParam = null;
			strActionId = null;
			objECRDEngModel = null;
		}

	}

	public String createRepair(HttpServletRequest request, String userId, String userRole, String strRepIndType, String strRepGrpType, String strRepListDel) throws Exception
	{
		ArrayList arrlstInpParam = null;
		ArrayList arrlstOutParam = null;
		String strActionId = null;
//		eCRDModule objModule = null;
		eCRDEngineModel objEngineModel = null;
		eCRDException objException = null;
		eCRDCatalog objCataLog = null;
//		String strSites = null;
//		String strRepairs = null;
//		String strParts = null;
		String strReturn = null;
		try
		{

			//Set the action this to call procedure to add the repair
			strActionId = eCRDConstants.getActionId("eCRD_CREATE_REPAIR");
            //ArrayList of Input Parameters
			arrlstInpParam = new ArrayList();
			//ArrayList of Output Parameters
			arrlstOutParam = new ArrayList();

			//Pass procedure input parameters to ArrayList

			if (objECRDModule == null || this.strComponentCode == null || this.strComponentCode.equals(""))
			{
				objException = new eCRDException();
				objException.setExcpId("INPUT_PARAMETERS_NOT_SET");
				throw objException;
			}
			// 1------------
			arrlstInpParam.add(objECRDModule.getModuleCode());

			objEngineModel = objECRDModule.getEngineModel();
			if (objEngineModel == null)
			{
				objException = new eCRDException();
				objException.setExcpId("ENGINE_MODEL_NOT_SET");
				throw objException;
			}

			//2------------
			arrlstInpParam.add(objEngineModel.getEngineModelCode());


			//	3------------
			if (strRepListDel != null && !"".equals(strRepListDel))
			{
				objCataLog = (eCRDCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
				if (objCataLog == null)
				{
					objException = new eCRDException();
					objException.setExcpId("CATALOG_NOT_SET");
					throw objException;
				}
				arrlstInpParam.add(objCataLog.getCatalogSeqId());
			}
			else
			{
				arrlstInpParam.add(eCRDCatalog.getCurrentDefaultSeqId(objEngineModel.getEngineModelCode()));
			}

			arrlstInpParam.add(eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRCOMPONENTCODE)));

			//set the repair details of the repairs associated with the component into a delimted string
            setRepairString(arrlstInpParam);

			arrlstInpParam.add(userId);
			arrlstInpParam.add(userRole);
			arrlstInpParam.add(strRepIndType);
			arrlstInpParam.add(strRepGrpType);
			arrlstInpParam.add(strRepListDel);
			//			arrlstInpParam.add(eCRDConstants.STRROWDELIM);
			//			arrlstInpParam.add(eCRDConstants.STRCOLUMNDELIM);

			// Call this function to update site details
			arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);
			strReturn = eCRDUtil.verifyNull((String) arrlstOutParam.get(1));
			if ("REPAIR_ADDED_SUCCESSFULY".equals(strReturn)||"RD_NUMBER_VALIDATION_FAILED".equals(strReturn))
			{
				this.removeRepairs();
			}
			//Return the message code retrieved from procedure

			return strReturn;
		}
		finally
		{
			arrlstInpParam = null;
			arrlstOutParam = null;
			strActionId = null;
//			objModule = null;

		}
	}

	/**
	 * create()
	 * this method creates a component at the database.
	 * it saves all the data that is assocaited with the component.
	 * @return String
	 * @throws Exception
	 */
	public String create(String userId, String userRole) throws Exception
	{
		ArrayList arrlstInpParam = null;
		ArrayList arrlstOutParam = null;
		String strActionId = null;
//		String strErrorMsg = null;
		String strModule = null;
		eCRDModule objModule = null;
		eCRDEngineModel objEngineModel = null;
		eCRDException objException = null;
//		eCRDCatalog objCataLog = null;
//		String strSites = null;
//		String strRepairs = null;
//		String strParts = null;
		String strReturn = null;

		try
		{

			//Set the action this to call procedure to add the repair
			strActionId = eCRDConstants.getActionId("eCRD_CREATE_COMPONENT");
			//ArrayList of Input Parameters
			arrlstInpParam = new ArrayList();
			//ArrayList of Output Parameters
			arrlstOutParam = new ArrayList();

			//Pass procedure input parameters to ArrayList

			//set the  module code associated with the component as input parameter

			if (objECRDModule == null || this.strComponentCode == null || this.strComponentCode.equals(""))
			{
				objException = new eCRDException();
				objException.setExcpId("INPUT_PARAMETERS_NOT_SET");
				throw objException;
			}
			arrlstInpParam.add(objECRDModule.getModuleCode());

			objEngineModel = objECRDModule.getEngineModel();

			if (objEngineModel == null)
			{
				objException = new eCRDException();
				objException.setExcpId("ENGINE_MODEL_NOT_SET");
				throw objException;
			}

			arrlstInpParam.add(objEngineModel.getEngineModelCode());


			arrlstInpParam.add(eCRDCatalog.getCurrentDefaultSeqId(objEngineModel.getEngineModelCode()));

			// set the component details and the site details into a delimted string.

			setComponentString(arrlstInpParam);

			//set the repair details of the repairs associated with the component into a delimted string

			setRepairString(arrlstInpParam);

			arrlstInpParam.add(userId);
			arrlstInpParam.add(userRole);
			arrlstInpParam.add(eCRDConstants.STRROWDELIM);
			arrlstInpParam.add(eCRDConstants.STRCOLUMNDELIM);

            arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);
			strReturn = eCRDUtil.verifyNull((String) arrlstOutParam.get(1));

            
            if ("COMPONENT_REPAIR_ADDED_SUCCESSFULY".equals(strReturn))
			{
				this.removeRepairs();
			}
            //added by sushant
            else if("RD_NUMBER_VALIDATION_FAILED".equals(strReturn)) {
                this.removeRepairs();
            }
			//Return the message code retrieved from procedure
			return strReturn;

		}
		finally
		{
			arrlstInpParam = null;
			arrlstOutParam = null;
			strActionId = null;
//			strErrorMsg = null;
			objModule = null;
			strModule = null;
		}

	}

	/**
	 * setComponentString
	 * this method converts the data assocated with the component
	 * into a delimted string. It creates a separate string for
	 * the sites associated with the component.
	 * @param arrlstInpParam
	 */

	private void setComponentString(ArrayList arrlstInpParam)
	{

		eCRDSite objSite = null;

		StringBuffer strCompBuff = null;
		StringBuffer strCompSiteBuff = null;
		StringBuffer strPartDetailsBuff = null;

		strCompBuff = new StringBuffer();
		strCompSiteBuff = new StringBuffer();
		strPartDetailsBuff = new StringBuffer();

		strCompBuff.append(this.strComponentCode);
		strCompBuff.append(eCRDUtil.verifyNull(eCRDConstants.STRCOLUMNDELIM));
		strCompBuff.append(eCRDUtil.verifyNull((String) arrlstInpParam.get(0)));
		strCompBuff.append(eCRDConstants.STRCOLUMNDELIM);
		strCompBuff.append(eCRDUtil.verifyNull(this.strBaseLineTAT));
		strCompBuff.append(eCRDConstants.STRCOLUMNDELIM);
		strCompBuff.append(eCRDUtil.verifyNull(this.strQtyCompPerEngine));
		strCompBuff.append(eCRDConstants.STRCOLUMNDELIM);
		strCompBuff.append(eCRDUtil.verifyNull(this.dtComponentEffDt));
		strCompBuff.append(eCRDConstants.STRCOLUMNDELIM);
		strCompBuff.append(eCRDUtil.verifyNull(this.strATARefNo));
		strCompBuff.append(eCRDConstants.STRCOLUMNDELIM);
		strCompBuff.append(eCRDUtil.verifyNull(this.strComponentDesc));
		strCompBuff.append(eCRDConstants.STRCOLUMNDELIM);
		strCompBuff.append(eCRDUtil.verifyNull(this.strCycValClass));
		//strTechLvl to set in p_in_comp_dtls_buff input parameter of ecrd_managecomponent_pkg.ecrd_create_component_prc
		strCompBuff.append(eCRDConstants.STRCOLUMNDELIM);
		strCompBuff.append(eCRDUtil.verifyNull(this.strTechLvl));
		strCompBuff.append(eCRDConstants.STRCOLUMNDELIM);
		strCompBuff.append(eCRDUtil.verifyNull(this.strPercetageYield));
		strCompBuff.append(eCRDConstants.STRCOLUMNDELIM);
		strCompBuff.append(eCRDUtil.verifyNull(this.strScrapRateAtExposure));
		strCompBuff.append(eCRDConstants.STRCOLUMNDELIM);
		strCompBuff.append(eCRDUtil.verifyNull(this.strServicableAtExposure));
		strCompBuff.append(eCRDConstants.STRCOLUMNDELIM);
		strCompBuff.append(eCRDUtil.verifyNull(this.strShopVisitExposureRate));
		strCompBuff.append(eCRDConstants.STRCOLUMNDELIM);
		strCompBuff.append(eCRDUtil.verifyNull(strAlternateComponent));
		strCompBuff.append(eCRDConstants.STRCOLUMNDELIM);
		strCompBuff.append(eCRDConstants.STRROWDELIM);

		/* iterate through the arraylist of sites and convert into a delimted string
		 * each object will be converted into a row.
		 */
		for (int i = 0; i < arrlstSites.size(); i++)
		{
			objSite = (eCRDSite) arrlstSites.get(i);
			strCompSiteBuff.append(objSite.getSiteCode());
			strCompSiteBuff.append(eCRDConstants.STRCOLUMNDELIM);
			strCompSiteBuff.append(eCRDUtil.verifyNull(this.strComponentCode));
			strCompSiteBuff.append(eCRDConstants.STRCOLUMNDELIM);
			strCompSiteBuff.append(eCRDUtil.verifyNull((String) arrlstInpParam.get(0)));
			strCompSiteBuff.append(eCRDConstants.STRCOLUMNDELIM);
/* Added New For Hide Component Indicator*/
			strCompSiteBuff.append(objSite.getHideComponentInd());
			strCompSiteBuff.append(eCRDConstants.STRCOLUMNDELIM);
			strCompSiteBuff.append(eCRDConstants.STRROWDELIM);
/* End Added New*/
		}

		for (int i = 0; i < arrlstParts.size(); i++)
		{
			strPartDetailsBuff.append((String) arrlstParts.get(i));
			strPartDetailsBuff.append(eCRDConstants.STRCOLUMNDELIM);
			strPartDetailsBuff.append(eCRDUtil.verifyNull(this.strComponentCode));
			strPartDetailsBuff.append(eCRDConstants.STRCOLUMNDELIM);
			strPartDetailsBuff.append(eCRDUtil.verifyNull((String) arrlstInpParam.get(0)));
			strPartDetailsBuff.append(eCRDConstants.STRCOLUMNDELIM);
			strPartDetailsBuff.append(eCRDConstants.STRROWDELIM);
		}

		/*set the component details,site detail part details strings as input parameter  */

		arrlstInpParam.add(strCompBuff.toString());
		arrlstInpParam.add(strCompSiteBuff.toString());
		arrlstInpParam.add(strPartDetailsBuff.toString());

	}
	/**
	 * setRepairString
	 * this method segregates the grouped repair and indivdual repairs
	 * into two different arraylist and invokes the method that converts
	 * the data related to the repairs into delimted string
	 * @param arrlstInpParam
	 * @throws Exception
	 */
	private void setRepairString(ArrayList arrlstInpParam) throws Exception
	{

		ArrayList alGrpRepair = null;
		ArrayList alIndRepair = null;
		alGrpRepair = new ArrayList();
		alIndRepair = new ArrayList();

		Class clseCRDGroupedRepair = Class.forName("ecrd.biz.eCRDGroupedRepair");
		Class clseCRDeCRDIndRepair = Class.forName("ecrd.biz.eCRDIndRepair");

		/* Iterate though the arraylist of repair objects
		 * associated with the component and cerate 2 arraylist
		 * one which holds Grouped Repairs and another which holds
		 * individual repairs.*/

		for (int i = 0; i < arrlstRepair.size(); i++)
		{
			/*Check if the current object in the arraylist
			 * is a grouped repair or individual repair */
			if (clseCRDGroupedRepair.isInstance(arrlstRepair.get(i))) {
                alGrpRepair.add(arrlstRepair.get(i));
            }
			else if (clseCRDeCRDIndRepair.isInstance(arrlstRepair.get(i))) {
                alIndRepair.add(arrlstRepair.get(i));
            }
        }		/*create a delimted string only if there is a group
		 * repair is  associated with the component
		 */
		setGroupRepairStrings(arrlstInpParam, alGrpRepair);
		setIndvRepairStrings(arrlstInpParam, alIndRepair);

	} // end of method

	/**
	 * setGroupRepairStrings
	 * this mothod iterates though the group repairs that
	 * are associated with the component & converts the information into a
	 * delimited string. It  creates a saperate string for the child repairs
	 * that are associated with the repair, a saperate string for sites associated
	 * with the repair. It adds these string to arrayList of input parameters.
	 * @param arrlstInpParam
	 * @param alGrpRepair
	 */
	private void setGroupRepairStrings(ArrayList arrlstInpParam, ArrayList alGrpRepair) throws Exception
	{
		ArrayList alGrpRepairSites = null;
		ArrayList alChildRepairs = null;
//		String strGrpRepair = null;
//		String strIndRepair = null;
		eCRDGroupedRepair objGroupRepair = null;
		eCRDIndRepair objIndRepair = null;
		eCRDChildRepair objChildRepair = null;
		eCRDRepairSite objRepairSite = null;
		eCRDRepairPricing objRepairPricing = null;
		StringBuffer strRepairBuff = null;
		StringBuffer strRepairSiteBuff = null;
		StringBuffer strChildRepairBuff = null;

		String strRepairEffDate = "";
		alChildRepairs = new ArrayList();
		alGrpRepairSites = new ArrayList();
		strRepairBuff = new StringBuffer();
		objChildRepair = new eCRDChildRepair();
		objGroupRepair = new eCRDGroupedRepair();
		objRepairPricing = new eCRDRepairPricing();
		objIndRepair = new eCRDIndRepair();
		strRepairBuff = new StringBuffer();
		strRepairSiteBuff = new StringBuffer();
		strChildRepairBuff = new StringBuffer();

		/*iterate through the arraylist of grouped repairs
		 * and convert the data to delimited string*/
        for (int i = 0; i < alGrpRepair.size(); i++)
		{
			objGroupRepair = (eCRDGroupedRepair) alGrpRepair.get(i);
			objRepairPricing = objGroupRepair.getObjRepairPricing();

			strRepairBuff.append(eCRDUtil.verifyNull(this.strComponentCode));
			strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
			strRepairBuff.append(eCRDUtil.verifyNull((String) arrlstInpParam.get(0)));
			strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);

			strRepairBuff.append(eCRDUtil.verifyNull(objGroupRepair.getStrRepairDesc()));
			strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
			strRepairBuff.append(eCRDUtil.verifyNull(objGroupRepair.getStrRepairVolume()));
			strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
			// added new to associate repair effective date with child repair
			strRepairEffDate = eCRDUtil.verifyNull(objGroupRepair.getDtRepairEffDate());
			// end added new
			strRepairBuff.append(eCRDUtil.verifyNull(objGroupRepair.getDtRepairEffDate()));
			strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
			strRepairBuff.append(eCRDUtil.verifyNull(objGroupRepair.getStrComments()));
			strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);

			if (objRepairPricing.isFlgIncrTAT())
			{
				strRepairBuff.append(eCRDConstants.STRTRUE);
				strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
			}
			else
			{
				strRepairBuff.append(eCRDConstants.STRFALSE);
				strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
			}

			strRepairBuff.append(eCRDUtil.verifyNullReturnObject(objRepairPricing.getIntTAT()));
			strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);

			if (objRepairPricing.isFlgIncrPrice())
			{
				strRepairBuff.append(eCRDConstants.STRTRUE);
				strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
			}
			else
			{
				strRepairBuff.append(eCRDConstants.STRFALSE);
				strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
			}

			strRepairBuff.append(eCRDUtil.verifyNullReturnObject(objRepairPricing.getDblPrice()));
			strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
			strRepairBuff.append(eCRDUtil.verifyNull(objRepairPricing.getStrPriceType()));
			strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
			strRepairBuff.append(eCRDUtil.verifyNullReturnObject(objRepairPricing.getDblFuturePrice()));
			strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
			strRepairBuff.append(eCRDUtil.verifyNullReturnObject(objRepairPricing.getIntFutureTAT()));
			strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
			strRepairBuff.append(objRepairPricing.getDtFuturePriceTATEffDt());
			strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
			strRepairBuff.append(eCRDUtil.verifyNull(objRepairPricing.getRepairSeqNo()));
			strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
            strRepairBuff.append(eCRDUtil.verifyNull(objGroupRepair.getStrNPIClassification()));
            strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
            
			strRepairBuff.append(eCRDConstants.STRROWDELIM);

			/* get the sites assocated with the group repair.
			 * convert the data assocaited with the sites into
			 * a delimted string
			*/

			alGrpRepairSites = objGroupRepair.getArrlstECRDRepairSite();
			for (int j = 0; j < alGrpRepairSites.size(); j++)
			{
				objRepairSite = (eCRDRepairSite) alGrpRepairSites.get(j);
				strRepairSiteBuff.append(eCRDUtil.verifyNull(objRepairSite.getSiteCode()));
				strRepairSiteBuff.append(eCRDConstants.STRCOLUMNDELIM);
				strRepairSiteBuff.append(objRepairSite.getMaterialCost());
				strRepairSiteBuff.append(eCRDConstants.STRCOLUMNDELIM);
				strRepairSiteBuff.append(objRepairSite.getLaborHr());
				strRepairSiteBuff.append(eCRDConstants.STRCOLUMNDELIM);
				strRepairSiteBuff.append(eCRDUtil.verifyNull(this.strComponentCode));
				strRepairSiteBuff.append(eCRDConstants.STRCOLUMNDELIM);
				strRepairSiteBuff.append(eCRDUtil.verifyNull((String) arrlstInpParam.get(0)));
				strRepairSiteBuff.append(eCRDConstants.STRCOLUMNDELIM);
				strRepairSiteBuff.append(eCRDConstants.STRROWDELIM);
			}
			/* get the child repairs associated with the repair
			 * convert the data assocaited with the child repair
			 * into a delimted string
			*/

			alChildRepairs = objGroupRepair.getChildRepairsList();
			for (int k = 0; k < alChildRepairs.size(); k++)
			{
				objChildRepair = (eCRDChildRepair) alChildRepairs.get(k);
				strChildRepairBuff.append(eCRDUtil.verifyNull(this.strComponentCode));
				strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
				strChildRepairBuff.append(eCRDUtil.verifyNull((String) arrlstInpParam.get(0)));
				strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
				strChildRepairBuff.append(eCRDUtil.verifyNull(objChildRepair.getRepairSeqNo()));
				strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
				strChildRepairBuff.append(eCRDUtil.verifyNull(objChildRepair.getStrReapirDesc()));
				strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
				strChildRepairBuff.append(eCRDUtil.verifyNull(objChildRepair.getStrRepairRefNo()));
				strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
				strChildRepairBuff.append(eCRDUtil.verifyNull(objChildRepair.getStrComments()));
				strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
				strChildRepairBuff.append(eCRDUtil.verifyNull(objChildRepair.getStrReapairRefFormat()));
				strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);

				//added new to associate repair effective date with each child repair
				//col no = 8

				strChildRepairBuff.append(strRepairEffDate);
				strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);

				//end added new

				strChildRepairBuff.append(eCRDUtil.verifyNull(objChildRepair.getMergeSplitSeqId()));
				strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                
                // Add new RD Number Values Sushant

                strChildRepairBuff.append(objChildRepair.getStrRDNumber());
                strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                strChildRepairBuff.append(objChildRepair.getStrReasonRDOverride());
                strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                strChildRepairBuff.append(objChildRepair.getStrRDNumberComment());
                strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                strChildRepairBuff.append(objChildRepair.getStrRDAssociation());
                strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);

                strChildRepairBuff.append(eCRDConstants.STRROWDELIM);
			}

		} // end of for loop tht iterates over repair objects

		/*Add the individual string to the arraylist of input parameters*/

		arrlstInpParam.add(strRepairBuff.toString());
		arrlstInpParam.add(strRepairSiteBuff.toString());

		arrlstInpParam.add(strChildRepairBuff.toString());

		/*set the component details,site detail part details strings as input parameter  */

	} // end of method

	/**
	 * setIndvRepairStrings
	 * this mothod iterates though the individual repairs that
	* are associated with the component & converts the information into a
	* delimited string. It  creates a separate string for the child repairs
	* that are associated with the repair, a saperate string for sites associated
	* with the repair. It adds these string to arrayList of input parameters.
	 * @param arrlstInpParam
	 * @param alIndRepair
	 */
	private void setIndvRepairStrings(ArrayList arrlstInpParam, ArrayList alIndRepair)
	{
		ArrayList alIndRepairSites = null;
//		String strGrpRepair = null;
//		String strIndRepair = null;
		eCRDIndRepair objIndRepair = null;
		eCRDRepairSite objRepairSite = null;
		eCRDRepairPricing objRepairPricing = null;
		StringBuffer strRepairBuff = null;
		StringBuffer strRepairSiteBuff = null;
//		StringBuffer strChildRepairBuff = null;

		alIndRepairSites = new ArrayList();
		strRepairBuff = new StringBuffer();

		objIndRepair = new eCRDIndRepair();
		objRepairPricing = new eCRDRepairPricing();
		objRepairSite = new eCRDRepairSite();
		strRepairBuff = new StringBuffer();
		strRepairSiteBuff = new StringBuffer();
//		strChildRepairBuff = new StringBuffer();
		for (int i = 0; i < alIndRepair.size(); i++)
		{
			objIndRepair = (eCRDIndRepair) alIndRepair.get(i);
			objRepairPricing = objIndRepair.getObjRepairPricing();

			strRepairBuff.append(this.strComponentCode);
			strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
			strRepairBuff.append((String) arrlstInpParam.get(0));
			strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);

			strRepairBuff.append(objIndRepair.getStrRepairDesc());
			strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
			strRepairBuff.append(objIndRepair.getStrRepairVolume());
			strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
			strRepairBuff.append(objIndRepair.getDtRepairEffDate());
			strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
			strRepairBuff.append(objIndRepair.getStrComments());
			strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
			strRepairBuff.append(objIndRepair.getRepairRefFormat());
			strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
            
			if (objRepairPricing.isFlgIncrTAT())
			{
				strRepairBuff.append(eCRDConstants.STRTRUE);
				strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
			}
			else
			{
				strRepairBuff.append(eCRDConstants.STRFALSE);
				strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
			}

			strRepairBuff.append(eCRDUtil.verifyNullReturnObject(objRepairPricing.getIntTAT()));
			strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);

			if (objRepairPricing.isFlgIncrPrice())
			{
				strRepairBuff.append(eCRDConstants.STRTRUE);
				strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
			}
			else
			{
				strRepairBuff.append(eCRDConstants.STRFALSE);
				strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
			}

			strRepairBuff.append(eCRDUtil.verifyNullReturnObject(objRepairPricing.getDblPrice()));
			strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
			strRepairBuff.append(objRepairPricing.getStrPriceType());
			strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
			strRepairBuff.append(eCRDUtil.verifyNullReturnObject(objRepairPricing.getDblFuturePrice()));
			strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
			strRepairBuff.append(eCRDUtil.verifyNullReturnObject(objRepairPricing.getIntFutureTAT()));
			strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
			strRepairBuff.append(objRepairPricing.getDtFuturePriceTATEffDt());
			strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
			strRepairBuff.append(objRepairPricing.getRepairSeqNo());
			strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);

			strRepairBuff.append(objIndRepair.getRepairRefNo());
			strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
			// added new
			if (objRepairPricing.isFlgPriceOverWriteInd())
			{
				strRepairBuff.append(eCRDConstants.STRTRUE);
				strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
			}
			else
			{
				strRepairBuff.append(eCRDConstants.STRFALSE);
				strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
			}

			strRepairBuff.append(eCRDUtil.verifyNull(objIndRepair.getMergeSplitSeqId()));
			strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);

            // Add new RD Number Values Sushant
            strRepairBuff.append(objIndRepair.getStrRDNumber());
            strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
            strRepairBuff.append(objIndRepair.getStrReasonRDOverride());
            strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
            strRepairBuff.append(objIndRepair.getStrRDNumberComment());
            strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
            strRepairBuff.append(objIndRepair.getStrRDAssociation());
            strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
            strRepairBuff.append(objIndRepair.getStrNPIClassification());
            strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
            //      end added new
            strRepairBuff.append(eCRDConstants.STRROWDELIM);
            
            // get the sites assocated with the individual repair
			alIndRepairSites = objIndRepair.getArrlstECRDRepairSite();

			for (int j = 0; j < alIndRepairSites.size(); j++)
			{
				objRepairSite = (eCRDRepairSite) alIndRepairSites.get(j);
				strRepairSiteBuff.append(objRepairSite.getSiteCode());
				strRepairSiteBuff.append(eCRDConstants.STRCOLUMNDELIM);
				strRepairSiteBuff.append(objRepairSite.getMaterialCost());
				strRepairSiteBuff.append(eCRDConstants.STRCOLUMNDELIM);
				strRepairSiteBuff.append(objRepairSite.getLaborHr());
				strRepairSiteBuff.append(eCRDConstants.STRCOLUMNDELIM);
				strRepairSiteBuff.append(this.strComponentCode);
				strRepairSiteBuff.append(eCRDConstants.STRCOLUMNDELIM);
				strRepairSiteBuff.append((String) arrlstInpParam.get(0));
				strRepairSiteBuff.append(eCRDConstants.STRCOLUMNDELIM);
				strRepairSiteBuff.append(eCRDConstants.STRROWDELIM);

            } // end of for loop tht iterates overs sites in a repair
			strRepairSiteBuff.append("~");
		} // end of outer for loop

		arrlstInpParam.add(strRepairBuff.toString());
		arrlstInpParam.add(strRepairSiteBuff.toString());

	} //end of method

	/**
	 * the method add's part number to the component.
	 * @param strPartNumber
	 */
	public void addPart(String strPartNumbers)
	{

		if (arrlstParts == null)
		{
			arrlstParts = new ArrayList();
		}
		StringTokenizer strTokens = new StringTokenizer(strPartNumbers, eCRDConstants.STRCOLUMNDELIM);

		while (strTokens.hasMoreTokens())
		{
			arrlstParts.add(strTokens.nextToken());
		}
	}

	/**
		  * the method gets  part number belong to the current component.
		  * @param
		  */
	public ArrayList getPart() throws GEAESQLException, Exception
	{
		GEAEResultSet rsPartDetails = null;
		ArrayList arrInParam = null;
		ArrayList arrOutParam = null;
		String strActionId = null;

		if (this.arrlstParts != null)
		{
			return (arrlstParts);
		}
		try
		{
			arrInParam = new ArrayList();
			arrOutParam = new ArrayList();
			arrlstSites = new ArrayList();

			arrInParam.add(this.strComponentCode);
			arrInParam.add(objECRDModule.getModuleCode());
			strActionId = eCRDUtil.verifyNull((String) eCRDConstants.getActionId("eCRD_GET_PARTS_DETAL"));
			arrOutParam = eCRDDBMediator.doDBOperation(strActionId, arrInParam);
			rsPartDetails = (GEAEResultSet) arrOutParam.get(0);

			if (arrlstParts == null)
			{
				arrlstParts = new ArrayList();
			}

			for (int i = 0; i < rsPartDetails.size(); i++, rsPartDetails.next())
			{
				arrlstParts.add(rsPartDetails.getString(i));
			}
			return arrlstParts;
		}
		finally
		{
			rsPartDetails = null;
			arrInParam = null;
			arrOutParam = null;
			strActionId = null;
		}

	}

	/**
		  * The part information is passed as string ARRAY.
		  * @param strSites
		  */
	public void addPart(String[] alParts)
	{
		if (arrlstParts == null)
		{
			arrlstParts = new ArrayList();
		}
		for (int i = 0; i < alParts.length; i++)
		{
			arrlstParts.add(alParts[i]);
		}
	}

	/**
	 * @return
	 */
	public String getAlternateComponent()
	{
		return strAlternateComponent;
	}

	/**
	 * @param string
	 */
	public void setAlternateComponent(String strAltComp)
	{
		strAlternateComponent = strAltComp;
	}

	/**
	 * this methods clears the contents of the arraylist that holds the
	 * sites associated with the component.
	 *
	 */
	public void clearSiteList()
	{
		this.arrlstSites = null;
		arrlstSites = new ArrayList();

	}

	/**
	 * this method clears the arraylist that holds the parts associated with the
	 * component.
	 *
	 */
	public void clearPartList()
	{
		arrlstParts = null;
		arrlstParts = new ArrayList();
	}

	/**
		* This method is a constructor which will load component details based on passed
		* parameters table.The sql associated with the proc will chk if there is any data
		* present in the staging table for the given component code. If yes then the staging
		* data is returned. It may also happen that some data comes from staging and some
		* from master as the site and component approval are not  synchronus.
		* @param strModuleCode
		* @param strComponentCode
		* @param strDataFrom
		*/
	public eCRDComponent(String strComponentCode, String strModuleCd) throws Exception
	{

		ArrayList arrInParam = null;
		ArrayList arrOutParam = null;
		String strActionId = null;
		GEAEResultSet rsComponentDetails = null;
		GEAEResultSet rsPartDetails = null;
		GEAEResultSet rsSiteDetails = null;
		eCRDSite objECRDSite = null;
		eCRDException objException = null;

		try
		{
			arrInParam = new ArrayList();
			arrOutParam = new ArrayList();

			/*check to see if the primary keys are set
			 * if the component code is not set or the
			 * module code is not set then throw a ecrd exception
			* */

			if (strComponentCode == null || "".equals(strComponentCode) || strModuleCd == null || "".equals(strModuleCd))
			{
				objException = new eCRDException();
				objException.setExcpId("INPUT_PARAMETERS_NOT_SET");
				throw objException;

			}

			/*Set the input parameters*/
			arrInParam.add(strComponentCode);
			arrInParam.add(strModuleCd);

			/*call procedure returns he components details,part details
			  and site details associated with the component
			  Note: the reapir  information is not loaded.
			*/
			strActionId = eCRDUtil.verifyNull((String) eCRDConstants.getActionId("eCRD_GET_COMPONENT_MAS_STG_DETAIL"));
			arrOutParam = eCRDDBMediator.doDBOperation(strActionId, arrInParam);

			/*this resultSet will hold the Component details
			* Note the component details of only Single component
			* are fetched from the database. A resultSet is used only
			* for avoid a long list of variables.
			**/
			rsComponentDetails = (GEAEResultSet) arrOutParam.get(0);

			/*this result set will hold the Part details
			* this result set will hold the part details of all the
			* parts that are associated with the component*/
			rsPartDetails = (GEAEResultSet) arrOutParam.get(1);

			/*this result set will hold the Site  details
			 * this result set will have all the site details
			 * that are associated with the component*/
			rsSiteDetails = (GEAEResultSet) arrOutParam.get(2);

			/*Initialize the result Set so tht they point to first record*/
			rsComponentDetails.setCurrentRow(0);
			rsComponentDetails.next();

			rsPartDetails.setCurrentRow(0);
			rsPartDetails.next();

			rsSiteDetails.setCurrentRow(0);
			rsSiteDetails.next();

			/*set the component attributes that are fetched  from db */
			this.strComponentCode = strComponentCode;
			strComponentDesc = eCRDUtil.verifyNull(rsComponentDetails.getString("compDescription"));
			strATARefNo = eCRDUtil.verifyNull(rsComponentDetails.getString("ataRefNum"));
			strBaseLineTAT = eCRDUtil.verifyNull(rsComponentDetails.getString("baseLineTAT"));
			dtComponentEffDt = eCRDUtil.verifyNull(rsComponentDetails.getString("compEfftDate"));
			strQtyCompPerEngine = eCRDUtil.verifyNull(rsComponentDetails.getString("engQnty"));
			strShopVisitExposureRate = eCRDUtil.verifyNull(rsComponentDetails.getString("shopVistExpRate"));
			strScrapRateAtExposure = eCRDUtil.verifyNull(rsComponentDetails.getString("scrapRateExp"));
			strServicableAtExposure = eCRDUtil.verifyNull(rsComponentDetails.getString("serviceAtExp"));
			strPercetageYield = eCRDUtil.verifyNull(rsComponentDetails.getString("repairYld"));
			strCycValClass = eCRDUtil.verifyNull(rsComponentDetails.getString("class"));
			strTechLvl = eCRDUtil.verifyNull(rsComponentDetails.getString("tech_lvl"));
			strAlternateComponent = eCRDUtil.verifyNull(rsComponentDetails.getString("alternateComp"));

			/*Initialize the Arraylist that will hold all
			 * all the part details
			 * */
			if (arrlstParts == null)
			{
				arrlstParts = new ArrayList();
			}

			/*Iterate through the result set and set the
			 * part number into the arraylist
			 * */
			for (int i = 0; i < rsPartDetails.size(); i++, rsPartDetails.next())
			{
				arrlstParts.add((String) rsPartDetails.getObject("partNumber"));
			}

			/*Initialze the arrayList that holds the reference
			 * to the site related to the component*/
			if (arrlstSites == null)
			{
				arrlstSites = new ArrayList();
			}

			/*
			 the site information associated with the components
			 is stored in an arrayList. to access individual site infromation
			 use the following syntax
			 objECRDSite = (eCRDSite)arrlstSites.get(0);
			 String strSite Code = objECRDSite.getSiteCode();
			*/
			for (int i = 0; i < rsSiteDetails.size(); i++, rsSiteDetails.next())
			{
				objECRDSite = new eCRDSite();
				objECRDSite.setSiteDescription(rsSiteDetails.getString("locName"));
				objECRDSite.setSiteCode(rsSiteDetails.getString("locCode"));
				objECRDSite.setLocationLaborRate(eCRDUtil.verifyDouble(rsSiteDetails.getString("laborRate")));
//				Added new For Hide Component Indicator
				objECRDSite.setHideComponentInd(eCRDUtil.verifyNull(rsSiteDetails.getString("hideCompInd")));
//				End of Added New

				this.arrlstSites.add(objECRDSite);
			}
		}
		/*Destroy all the objects used. */
		finally
		{
			arrInParam = null;
			arrOutParam = null;
			strActionId = null;
			rsComponentDetails = null;
			rsPartDetails = null;
			rsSiteDetails = null;
			objECRDSite = null;
		}
	}
	/**
	 *
	 * @param strRepairType
	 * @param strRepairSubType
	 * @return
	 */
	public ArrayList getRepairs(String strRepairType, String strRepairSubType)
	{
		ArrayList arrlstRepairs = null;
		eCRDRepair objeCRDRepair = null;
		eCRDGroupedRepair objGrpRepair = null;
		eCRDIndRepair objIndRepair = null;
		int intRepairsSize = 0;

		try
		{
			arrlstRepairs = new ArrayList();
			intRepairsSize = this.arrlstRepair.size();
			for (int intCtr = 0; intCtr < intRepairsSize; intCtr++)
			{
				objeCRDRepair = (eCRDRepair) this.arrlstRepair.get(intCtr);
				if (objeCRDRepair.getRepairType().equals(strRepairType))
				{
					if ("M".equals(strRepairSubType))
					{
						try
						{
							objGrpRepair = (eCRDGroupedRepair) objeCRDRepair;
							if (objGrpRepair.isCreatedFromMerge())
							{
								arrlstRepairs.add(objGrpRepair);
							}
							objGrpRepair = null;
						}
						catch (ClassCastException e)
						{
							//do nothing
						}
					}
					else
					{
						try
						{
							objIndRepair = (eCRDIndRepair) objeCRDRepair;
							if (objIndRepair.isCreatedFromSplit())
							{
								arrlstRepairs.add(objIndRepair);
							}
							objIndRepair = null;
						}
						catch (ClassCastException e)
						{
							//do nothing
						}
					}
				}
				objeCRDRepair = null;
			}
			return arrlstRepairs;
		}
		finally
		{
			arrlstRepairs = null;
			objeCRDRepair = null;
			objGrpRepair = null;
			objIndRepair = null;
		}
	}
	/**
		 *
		 * @param strRepairType
		 * @param strRepairSubType
		 * @return
		 */
	public String removeRepairs(String strRepairType, String strRepairSubType)
	{

		eCRDRepair objeCRDRepair = null;
		eCRDGroupedRepair objGrpRepair = null;
		eCRDIndRepair objIndRepair = null;
		int intRepairsSize = 0;
		int intCtr = 0;
		try
		{
			if (this.arrlstRepair != null && this.arrlstRepair.size() > 0)
			{
				intRepairsSize = this.arrlstRepair.size();
				while (intCtr < intRepairsSize && arrlstRepair.size() != 0)
				{
					objeCRDRepair = (eCRDRepair) this.arrlstRepair.get(0);
					if (objeCRDRepair.getRepairType().equals(strRepairType))
					{
						if ("M".equals(strRepairSubType))
						{
							try
							{
								objGrpRepair = (eCRDGroupedRepair) objeCRDRepair;
								if (objGrpRepair.isCreatedFromMerge())
								{
									this.arrlstRepair.remove(0);
								}
								objGrpRepair = null;
							}
							catch (ClassCastException e)
							{
								//do nothing
							}
						}
						else
						{
							try
							{
								objIndRepair = (eCRDIndRepair) objeCRDRepair;
								if (objIndRepair.isCreatedFromSplit())
								{
									this.arrlstRepair.remove(0);
								}
								objIndRepair = null;
							}
							catch (ClassCastException e)
							{
								//do nothing
							}
						}
					}
					objeCRDRepair = null;
					intCtr++;
				}
			}
			return "";
		}
		finally
		{
			objeCRDRepair = null;
			objGrpRepair = null;
			objIndRepair = null;
		}
	}

	/**
	 * 		This method is used for saving the Price Adjustment values.
		 * @return String
		 */
	public String savePriceAdjusment(String strActionId, ArrayList arrlstInpParam) throws Exception
	{
		String strMessage = null;
		ArrayList arrlstOutParam = null;
		try
		{

			arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);
			strMessage = (String) arrlstOutParam.get(0);
			return strMessage;
		}
		finally
		{
			arrlstInpParam = null;
			arrlstOutParam = null;
			strActionId = null;
		}
	}

	public String removeRepairs() throws Exception
	{
		try
		{
			this.arrlstRepair = null;
			return "";
		}
		finally
		{
		}
	}
	public ArrayList getAllRepairs()
	{
		return this.arrlstRepair;
	}

	public String isComponentSiteAppPending(String strAction, ArrayList arrlstInParam) throws Exception
	{
		String strMessage = null;
		ArrayList arrlstOutParam = null;
		try
		{
			arrlstOutParam = new ArrayList();
			arrlstOutParam = eCRDDBMediator.doDBOperation(strAction,arrlstInParam);
			strMessage = eCRDUtil.verifyNull((String)arrlstOutParam.get(0));
			return strMessage;
		}
		finally
		{
			arrlstOutParam = null;
		}
	}

    /**
        * Populate list of components from the database based on the search criteria (do
        * not populate repirs for the components). Search Criteria would be passed to
        * this method through request.
        * @param pagecontext
        * @param s
        * @return void
        */
    public ArrayList mapComponent(String strAction, ArrayList arrLstInParam) throws Exception
    {
        ArrayList arrLstOutParam = null;
        ArrayList arrLstResult = null;
        String strMessage = "";
        arrLstOutParam = new ArrayList();
        GEAEResultSet rsComponentList = null;
        try
        {
            rsComponentList = new GEAEResultSet();
            arrLstResult = new ArrayList();
            arrLstOutParam = eCRDDBMediator.doDBOperation(strAction, arrLstInParam);
            rsComponentList = (GEAEResultSet) arrLstOutParam.get(0);
            strMessage = eCRDUtil.verifyNull((String)arrLstOutParam.get(1));
            arrLstResult.add(rsComponentList);
            arrLstResult.add(strMessage);
            return arrLstResult;
        }
        finally
        {
            arrLstOutParam = null;
            rsComponentList = null;
        }
    }

    public ArrayList deleteMapping(String strAction, ArrayList arrLstInParam) throws Exception
    {
        ArrayList arrLstOutParam = null;
        ArrayList arrLstResult = null;
        String strMessage = "";
        arrLstOutParam = new ArrayList();
        GEAEResultSet rsComponentList = null;
        try
        {
            rsComponentList = new GEAEResultSet();
            arrLstResult = new ArrayList();
            arrLstOutParam = eCRDDBMediator.doDBOperation(strAction, arrLstInParam);
            rsComponentList = (GEAEResultSet) arrLstOutParam.get(0);
            strMessage = eCRDUtil.verifyNull((String)arrLstOutParam.get(1));
            arrLstResult.add(rsComponentList);
            arrLstResult.add(strMessage);
            return arrLstResult;
        }
        finally
        {
            arrLstOutParam = null;
            rsComponentList = null;
        }
    }

    /**
     * Populate list of components from the database based on the search criteria (do
     * not populate repirs for the components). Search Criteria would be passed to
     * this method through request.
     * @param pagecontext
     * @param s
     * @return void
     */
    public ArrayList editmapComponent(String strAction, ArrayList arrLstInParam) throws Exception
    {
     ArrayList arrLstOutParam = null;
     ArrayList arrLstResult = null;
     String strMessage = "";
     arrLstOutParam = new ArrayList();
     GEAEResultSet rsComponentList = null;
     try
     {
         rsComponentList = new GEAEResultSet();
         arrLstResult = new ArrayList();
         arrLstOutParam = eCRDDBMediator.doDBOperation(strAction, arrLstInParam);
         rsComponentList = (GEAEResultSet) arrLstOutParam.get(0);
         strMessage = eCRDUtil.verifyNull((String)arrLstOutParam.get(1));
         arrLstResult.add(rsComponentList);
         arrLstResult.add(strMessage);
         return arrLstResult;
     }
     finally
     {
         arrLstOutParam = null;
         rsComponentList = null;
     }
    }

    /**
     * Populate list of components from the database based on the search criteria (do
     * not populate repirs for the components). Search Criteria would be passed to
     * this method through request.
     * @param pagecontext
     * @param s
     * @return void
     */
    public ArrayList getmapComponent(String strAction, ArrayList arrLstInParam) throws Exception
    {
         ArrayList arrLstOutParam = null;
         ArrayList arrLstResult = null;
         String strMessage = "";
         arrLstOutParam = new ArrayList();
         GEAEResultSet rsComponentList = null;
         try
         {
             rsComponentList = new GEAEResultSet();
             arrLstResult = new ArrayList();
             arrLstOutParam = eCRDDBMediator.doDBOperation(strAction, arrLstInParam);
             rsComponentList = (GEAEResultSet) arrLstOutParam.get(0);
             strMessage = eCRDUtil.verifyNull((String)arrLstOutParam.get(1));
             arrLstResult.add(rsComponentList);
             arrLstResult.add(strMessage);
             return arrLstResult;
         }
         finally
         {
             arrLstOutParam = null;
             rsComponentList = null;
         }
    }

} // end of class