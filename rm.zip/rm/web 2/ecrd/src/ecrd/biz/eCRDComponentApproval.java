 /*
* Module    	    : eCRDComponentApproval.java
* Author      	    : PATNI-Offshore
* Project	        : eCRD
* Date Written		: October 2004
* Security	        : Unclassified
* Restrictions		: GE PROPRIETARY INFORMATION, FOR GE USE ONLY
*
*     ****************************************************
*     *  Copyright (2000) with all rights reserved       *
*     *          General Electric Company                *
*     ****************************************************
*
* Description: eCRDBusinessBean is used for getting the GEAE Row Cache Tag
*
* Revision Log  (mm/dd/yy initials description)
* --------------------------------------------------------------
*/

package ecrd.biz;

import java.util.ArrayList;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDSearchBean;
import ecrd.util.eCRDUtil;
import ecrd.common.eCRDDBMediator;
import ecrd.exception.eCRDException;

import java.io.Serializable;

import geae.dao.GEAEResultSet;
import geae.messaging.GEAEMailMessage;
import geae.messaging.GEAEMailMessageException;

/**
 * This class is a sublcass of the eCRDApprovalRequest class and 
 * implements the abstract methods for the Approval Request for 
 * Components.
 * It has accessor and mutator method to hold Component Object.
 */
public class eCRDComponentApproval extends eCRDApprovalRequest implements Serializable
{
	private eCRDComponent objeCRDComponent = null; //existing component
	private eCRDComponent objStgeCRDComponent = null; //staging component
	private String approvalMailId = null;
	

	//Empty Constructor
	public eCRDComponentApproval()
	{

	}

	/**
	 * This method returns the eCRDComponent object 
	 * @parameter none
	 * @return eCRDComponent
	 */
	
	public String getApprovalMailId() {
		return approvalMailId;
	}

	public void setApprovalMailId(String approvalMailId) {
		this.approvalMailId = approvalMailId;
	}
	
	public eCRDComponent getApprovalComponent()
	{
		return this.objeCRDComponent;
	}

	public eCRDComponent getStgComponent()
	{
		return this.objStgeCRDComponent;
	}
	/**
	 * This method sets the eCRDComponent object
	 * @param objeCRDComponent
	 * @return void
	 */
	public void setApprovalComponent(eCRDComponent objeCRDComponent)
	{
		this.objeCRDComponent = objeCRDComponent;
	}

	public void setStgComponent(eCRDComponent objStgComponent)
	{
		this.objStgeCRDComponent = objStgComponent;
	}
	/**
	 * This method is an implementation of the abstract method in the SuperClass
	 * eCRDApprovalRequest for approving Components
	 * @param none
	 * @return void
	 * 
	 */
	public String approve() throws Exception
	{
		ArrayList arrInParam = null;
		ArrayList arrOutParam = null;
		String strMessage = "";
		String strActionId = "";

		try
		{

			arrInParam = new ArrayList();
			arrOutParam = new ArrayList();

			arrInParam.add(this.objeCRDComponent.getComponentCode());
			arrInParam.add(this.objStgeCRDComponent.getComponentDesc());
			arrInParam.add(this.objeCRDComponent.getModule().getEngineModel().getEngineModelCode());
			arrInParam.add(this.objeCRDComponent.getModule().getModuleCode());
			arrInParam.add(this.objStgeCRDComponent.getATARefNo());
			arrInParam.add(this.objStgeCRDComponent.getBaseLineTAT());
			arrInParam.add(this.objStgeCRDComponent.getComponentEffDt());
			arrInParam.add(this.objStgeCRDComponent.getCycValClass());
			arrInParam.add(this.objStgeCRDComponent.getQtyCompPerEngine());
			arrInParam.add(this.objStgeCRDComponent.getShopVisitExposureRate());
			arrInParam.add(this.objStgeCRDComponent.getScrapRateAtExposure());
			arrInParam.add(this.objStgeCRDComponent.getServicableAtExposure());
			arrInParam.add(this.objStgeCRDComponent.getPercentageYield());
			arrInParam.add(this.objStgeCRDComponent.getAlternateComponent());
			arrInParam.add(this.getApprovedBy());
			arrInParam.add(this.getChgType());
			arrInParam.add(this.objStgeCRDComponent.getTechLvl());
			strActionId = eCRDConstants.getActionId("eCRD_INSERT_COMP_APPROVAL_DET");

			arrOutParam = eCRDDBMediator.doDBOperation(strActionId, arrInParam);
			strMessage = (String) arrOutParam.get(0);
			
			if (strMessage.equalsIgnoreCase("COMPONENT_APPROVE_SUCCESS"))
			{
				sendApprovalMail();
			}
		}
		finally
		{
			arrInParam = null;
			arrOutParam = null;
		}
		return strMessage;
	}

	/**
	 * this method is an overridden method to approve a new component along with the repairs
	 */

	public String approve(ArrayList arlstRepairId) throws Exception
	{
		String strActionId = "";
		ArrayList arrInParam = null;
		ArrayList arrOutParam = null;
		String strMessage = "";

//		ArrayList arrlstRepair = null;
		ArrayList arrlstChildRepair = null;
		ArrayList arrlstRepairSite = null;
//		ArrayList arrlstOut = null;
		ArrayList arrlstCompSite = null;
		ArrayList arrlstCompParts = null;
		StringBuffer strRepairBuff = null;
		StringBuffer strChildRepairBuff = null;
		StringBuffer strRepairSiteBuff = null;
		StringBuffer strCompSiteBuff = null;
		StringBuffer strCompPartBuff = null;
		GEAEResultSet rsRepairs = null;
		eCRDRepair objRepair = null;
		eCRDIndRepair objIndRepair = null;
		eCRDGroupedRepair objGrpRepair = null;
		eCRDChildRepair objChildRepair = null;
		eCRDRepairSite objRepairSite = null;
		eCRDSearchBean objeCRDSearchBean = null;
		eCRDSite objCompSite = null;
		eCRDPart objPart = null;
		arrlstChildRepair = new ArrayList();
		arrlstRepairSite = new ArrayList();
		arrlstCompParts = new ArrayList();
		strRepairBuff = new StringBuffer();
		strChildRepairBuff = new StringBuffer();
		strRepairSiteBuff = new StringBuffer();
		strCompPartBuff = new StringBuffer();
		objeCRDSearchBean = new eCRDSearchBean();
		rsRepairs = new GEAEResultSet();
		try
		{
			arrInParam = new ArrayList();
			arrOutParam = new ArrayList();

			
			arrInParam.add(this.objStgeCRDComponent.getComponentCode());
			arrInParam.add(this.objStgeCRDComponent.getComponentDesc());
			arrInParam.add(this.objStgeCRDComponent.getModule().getEngineModel().getEngineModelCode());
			arrInParam.add(this.objStgeCRDComponent.getModule().getModuleCode());
			arrInParam.add(this.objStgeCRDComponent.getATARefNo());
			arrInParam.add(this.objStgeCRDComponent.getBaseLineTAT());
			arrInParam.add(this.objStgeCRDComponent.getComponentEffDt());
			arrInParam.add(this.objStgeCRDComponent.getCycValClass());
			arrInParam.add(this.objStgeCRDComponent.getTechLvl());
			arrInParam.add(this.objStgeCRDComponent.getQtyCompPerEngine());
			arrInParam.add(this.objStgeCRDComponent.getShopVisitExposureRate());
			arrInParam.add(this.objStgeCRDComponent.getScrapRateAtExposure());
			arrInParam.add(this.objStgeCRDComponent.getServicableAtExposure());
			arrInParam.add(this.objStgeCRDComponent.getPercentageYield());
			arrInParam.add(this.objStgeCRDComponent.getAlternateComponent());

			arrInParam.add(this.getApprovedBy());

			for (int intRsRepairSize = 0; intRsRepairSize < arlstRepairId.size(); intRsRepairSize += 2)
			{
				objRepair = this.objStgeCRDComponent.getRepair((String) arlstRepairId.get(intRsRepairSize), (String) arlstRepairId.get(intRsRepairSize + 1));
				strRepairBuff.append(objRepair.getRepairType());
				strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
				strRepairBuff.append(objRepair.getStrRepairCode());
				strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
				strRepairBuff.append(objRepair.getStrRepairDesc());
				strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
				strRepairBuff.append(objRepair.getDtRepairEffDate());
				strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
				strRepairBuff.append(objRepair.getStrRepairVolume());
				strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
				if (objRepair instanceof eCRDIndRepair)
				{
					objIndRepair = (eCRDIndRepair) objRepair;
					strRepairBuff.append(objIndRepair.getRepairRefNo());
					strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
					strRepairBuff.append(objIndRepair.getRepairRefFormat());
					strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
				}
				strRepairBuff.append(objRepair.getStrComments());
				strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
				if (objRepair.getObjRepairPricing().isFlgIncrTAT())
				{
					strRepairBuff.append(eCRDConstants.STRTRUE);
				}
				else
				{
					strRepairBuff.append(eCRDConstants.STRFALSE);
				}
				strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
				strRepairBuff.append(eCRDUtil.verifyNullReturnObject(objRepair.getObjRepairPricing().getIntTAT()));
				strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
				if (objRepair.getObjRepairPricing().isFlgIncrPrice())
				{
					strRepairBuff.append(eCRDConstants.STRTRUE);
				}
				else
				{
					strRepairBuff.append(eCRDConstants.STRFALSE);
				}
				strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
				strRepairBuff.append(eCRDUtil.verifyNullReturnObject( objRepair.getObjRepairPricing().getDblPrice()));
				strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
				strRepairBuff.append(objRepair.getObjRepairPricing().getStrPriceType());
				strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
				strRepairBuff.append(eCRDUtil.verifyNullReturnObject(objRepair.getObjRepairPricing().getIntFutureTAT()));
				strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
				strRepairBuff.append(eCRDUtil.verifyNullReturnObject( objRepair.getObjRepairPricing().getDblFuturePrice()));
				strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
				strRepairBuff.append(objRepair.getObjRepairPricing().getDtFuturePriceTATEffDt());
				strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
				strRepairBuff.append(this.objStgeCRDComponent.getModule().getEngineModel().getCatalog().getCatalogSeqId());
				strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
				strRepairBuff.append(objRepair.getObjRepairPricing().getRepairSeqNo());
				strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);

				arrlstRepairSite = objRepair.getArrlstECRDRepairSite();

				strRepairSiteBuff = new StringBuffer();
				for (int intRepairSiteSize = 0; intRepairSiteSize < arrlstRepairSite.size(); intRepairSiteSize++)
				{
					objRepairSite = (eCRDRepairSite) arrlstRepairSite.get(intRepairSiteSize);
					strRepairSiteBuff.append(objRepairSite.getSiteCode());
					
					strRepairSiteBuff.append("#");
					strRepairSiteBuff.append(objRepairSite.getMaterialCost());
					
					strRepairSiteBuff.append("#");
					strRepairSiteBuff.append(objRepairSite.getLaborHr());
					strRepairSiteBuff.append("#");

					strRepairSiteBuff.append("*");
				}
				strRepairBuff.append(strRepairSiteBuff.toString());
				strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
				if (objRepair instanceof eCRDGroupedRepair)
				{
					objGrpRepair = (eCRDGroupedRepair) objRepair;
					arrlstChildRepair = objGrpRepair.getChildRepairsList();
					strChildRepairBuff = new StringBuffer();
					for (int intChildRepairSize = 0; intChildRepairSize < arrlstChildRepair.size(); intChildRepairSize++)
					{
						objChildRepair = (eCRDChildRepair) arrlstChildRepair.get(intChildRepairSize);
						strChildRepairBuff.append(eCRDUtil.verifyNull(objChildRepair.getStrChildRepairCode()));
						
						strChildRepairBuff.append("#");
						strChildRepairBuff.append(eCRDUtil.verifyNull(objChildRepair.getStrReapirDesc()));
						strChildRepairBuff.append("#");
						strChildRepairBuff.append(eCRDUtil.verifyNull(objGrpRepair.getStrRepairCode()));
						strChildRepairBuff.append("#");
						strChildRepairBuff.append(eCRDUtil.verifyNull(objChildRepair.getStrRepairRefNo()));
						strChildRepairBuff.append("#");
						strChildRepairBuff.append(eCRDUtil.verifyNull(objChildRepair.getStrComments()));
						strChildRepairBuff.append("#");
						strChildRepairBuff.append(eCRDUtil.verifyNull(objChildRepair.getStrReapairRefFormat()));
						strChildRepairBuff.append("#");
						strChildRepairBuff.append(eCRDUtil.verifyNull(objGrpRepair.getDtRepairEffDate()));
						strChildRepairBuff.append("#");
						strChildRepairBuff.append(eCRDUtil.verifyNull(objGrpRepair.getStrRepairVolume()));
						strChildRepairBuff.append("#");
						strChildRepairBuff.append(eCRDUtil.verifyNull(objChildRepair.getRepairSeqNo()));
						strChildRepairBuff.append("#");

                        strChildRepairBuff.append(eCRDUtil.verifyNull(objChildRepair.getStrRDNumber()));
                        strChildRepairBuff.append("#");
                        strChildRepairBuff.append(eCRDUtil.verifyNull(objChildRepair.getStrReasonRDOverride()));
                        strChildRepairBuff.append("#");
                        strChildRepairBuff.append(eCRDUtil.verifyNull(objChildRepair.getStrRDNumberComment()));
                        strChildRepairBuff.append("#");
                        strChildRepairBuff.append(eCRDUtil.verifyNull(objChildRepair.getStrRDAssociation()));
                        strChildRepairBuff.append("#");
                        strChildRepairBuff.append(eCRDUtil.verifyNull(objChildRepair.getStrRDCreationDt()));
                        strChildRepairBuff.append("#");
                        strChildRepairBuff.append(eCRDUtil.verifyNull(objChildRepair.getStrRDModifiedDt()));
                        strChildRepairBuff.append("#");                        
                        
						strChildRepairBuff.append("*");
					}
					strRepairBuff.append(strChildRepairBuff.toString());
					strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);

                    strRepairBuff.append(eCRDUtil.verifyNull(objGrpRepair.getStrRDNumber()));
                    strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                    strRepairBuff.append(eCRDUtil.verifyNull(objGrpRepair.getStrReasonRDOverride()));
                    strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                    strRepairBuff.append(eCRDUtil.verifyNull(objGrpRepair.getStrRDNumberComment()));
                    strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                    strRepairBuff.append(eCRDUtil.verifyNull(objGrpRepair.getStrRDAssociation()));
                    strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                    strRepairBuff.append(eCRDUtil.verifyNull(objGrpRepair.getStrNPIClassification()));
                    strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                }
                if (objRepair instanceof eCRDIndRepair)
                {
                    objIndRepair = (eCRDIndRepair) objRepair;
                    strRepairBuff.append(eCRDUtil.verifyNull(objIndRepair.getStrRDNumber()));
                    strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                    strRepairBuff.append(eCRDUtil.verifyNull(objIndRepair.getStrReasonRDOverride()));
                    strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                    strRepairBuff.append(eCRDUtil.verifyNull(objIndRepair.getStrRDNumberComment()));
                    strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                    strRepairBuff.append(eCRDUtil.verifyNull(objIndRepair.getStrRDAssociation()));
                    strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                    strRepairBuff.append(eCRDUtil.verifyNull(objIndRepair.getStrNPIClassification()));
                    strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                }
                strRepairBuff.append(eCRDConstants.STRROWDELIM);

            }
			arrInParam.add(strRepairBuff.toString());
			arrlstCompSite = this.objStgeCRDComponent.getSiteList();
			
			strCompSiteBuff = new StringBuffer();
			for (int j = 0; j < arrlstCompSite.size(); j++)
			{
				objCompSite = (eCRDSite) arrlstCompSite.get(j);
				strCompSiteBuff.append(objCompSite.getSiteCode());
				strCompSiteBuff.append(eCRDConstants.STRCOLUMNDELIM);
/* Added new for Hide Component Indicator */
				strCompSiteBuff.append(objCompSite.getHideComponentInd());
				strCompSiteBuff.append(eCRDConstants.STRCOLUMNDELIM);
/* End of Added new for Hide Component Indicator */

				strCompSiteBuff.append(eCRDConstants.STRROWDELIM);
			}
			arrInParam.add(strCompSiteBuff.toString());
			arrlstCompParts = this.objStgeCRDComponent.getPart();
			
			for (int j = 0; j < arrlstCompParts.size(); j++)
			{
				//	objPart = (eCRDPart)arrlstCompParts.get(j);

				strCompPartBuff.append(arrlstCompParts.get(j));
				strCompPartBuff.append(eCRDConstants.STRCOLUMNDELIM);

				strCompPartBuff.append(eCRDConstants.STRROWDELIM);
			}
			arrInParam.add(strCompPartBuff.toString());
			

			strActionId = eCRDConstants.getActionId("eCRD_INSERT_NEW_COMP_APPROVAL_DET");
			
			arrOutParam = eCRDDBMediator.doDBOperation(strActionId, arrInParam);
			strMessage = (String) arrOutParam.get(0);
			if (strMessage.equalsIgnoreCase("COMPONENT_APPROVE_SUCCESS"))
			{
				sendApprovalMail();
			}
		}
		finally
		{

		}
		return strMessage;
	}
	/**
	 * This method is an implementation of the abstract method in the SuperClass
	 * eCRDApprovalRequest for Rejection of Components.
	 * @param none
	 * @return void
	 */
	public String reject() throws Exception
	{
		ArrayList arrInParam = null;
		ArrayList arrOutParam = null;
		String strActionId = "";
		String strMessage = "";
		try
		{
			arrInParam = new ArrayList();
			arrOutParam = new ArrayList();
			arrInParam.add(this.objStgeCRDComponent.getComponentCode());
			
			arrInParam.add(this.objStgeCRDComponent.getModule().getModuleCode());
			arrInParam.add(this.getApprovedBy());
			arrInParam.add(this.getRejectionComments());

			
			strActionId = eCRDConstants.getActionId("eCRD_REJECT_COMP_APPROVAL_DET");
			arrOutParam = eCRDDBMediator.doDBOperation(strActionId, arrInParam);
			strMessage = (String) arrOutParam.get(0);
			
			sendApprovalMailForRejection();
			
		}
		finally
		{
			arrInParam = null;
			arrOutParam = null;
		}
		return strMessage;
	}

	/**
	 * This method returns Component Details from the Staging table
	 * @param eCRDComponent
	 * @return eCRDComponent
	 */
	public eCRDComponent getStagingData() throws Exception
	{
		ArrayList arrInParam = null;
		ArrayList arrOutParam = null;
		String strActionId = "";
		try
		{
			this.objStgeCRDComponent = new eCRDComponent(this.objeCRDComponent.getComponentCode(), this.objeCRDComponent.getModule().getModuleCode(), eCRDConstants.STRSTAGINGDATA);
			//arrInParam = new ArrayList();
			//arrOutParam= new ArrayList();
			//arrInParam.add(this.getApprovalComponent().getComponentCode());
			//arrOutParam = eCRDDBMediator.doDBOperation(strActionId,arrInParam);
		}
		finally
		{
			arrInParam = null;
		}
		return this.objStgeCRDComponent;
	}
	public eCRDComponent getMasterData() throws Exception
	{
		this.objeCRDComponent = new eCRDComponent(this.objeCRDComponent.getComponentCode(), this.objeCRDComponent.getModule().getModuleCode(), eCRDConstants.STRMASTERDATA);

		return this.objeCRDComponent;
	}
	public ArrayList getApprovalComp(String strActionID,String strRole,String strUserId) throws Exception
	{
		ArrayList arrLstInParam =null;
		ArrayList arrLstOutParam =null;
		try
		{
			arrLstOutParam = new ArrayList();
			arrLstInParam = new ArrayList();
			arrLstInParam.add(eCRDUtil.verifyNull(strRole));
			arrLstInParam.add(eCRDUtil.verifyNull(strUserId));
			arrLstOutParam = eCRDDBMediator.doDBOperation(strActionID, arrLstInParam);
			return arrLstOutParam;	
		}
		finally
		{
			arrLstInParam = null;
			arrLstOutParam =null;
		}
		
	}
	public ArrayList getApprovalHist(String strActionID, String strComponentCode, String strModuleCode) throws Exception
	{
		ArrayList arrLstOutParam = new ArrayList();
		ArrayList arrLstInParam = new ArrayList();
		try
		{
			arrLstInParam.add(strComponentCode);
			arrLstInParam.add(strModuleCode);
			arrLstOutParam = eCRDDBMediator.doDBOperation(strActionID, arrLstInParam);
		}
		finally
		{
			arrLstInParam = null;
		}
		return arrLstOutParam;
	}
	public void sendApprovalMail() throws eCRDException, Exception
	{
		ArrayList arlstMailTo = null;
		GEAEMailMessage eCRDMail = null;
		String strMailId[] = null;
		StringBuffer strMailBody = null;
		try
		{
			arlstMailTo = new ArrayList();
			//arlstMailTo = eCRDUtil.getEmaiID(this.objStgeCRDComponent);
			//arlstMailTo.add("sachin.shrivastav@ge.com");
			arlstMailTo.add("kumar.naravamakula@ge.com");
			arlstMailTo.add("Sreesujitha.Venkata@ge.com");	
			strMailBody =new StringBuffer();
			if (arlstMailTo.size() > 0)
			{
				eCRDMail = new GEAEMailMessage();
				strMailId = eCRDUtil.convertArrayListtoArray(arlstMailTo);
				

				eCRDMail.setSender(this.getApprovedBy());
				eCRDMail.setSubject("The component " + this.objStgeCRDComponent.getComponentCode() + " is approved by eCRD Administrator" );
				eCRDMail.setRecipients(GEAEMailMessage.TO, strMailId);
				strMailBody.append("*** This email message was generated by eCRD system. Please do not reply as the mail-box is not monitored ***\n\r");
				strMailBody.append("Engine Model    : " + this.objStgeCRDComponent.getModule().getEngineModel().getEngineModelDesc() + "\n\r" );
				strMailBody.append("Engine Module   : " + this.objStgeCRDComponent.getModule().getModuleDesc()+ "\n\r" );
				strMailBody.append("Component Code  : " + this.objStgeCRDComponent.getComponentCode()+ "\n\r" );
				strMailBody.append("Component Desc  : " + this.objStgeCRDComponent.getComponentDesc()+ "\n\r" );
				strMailBody.append("The above component has been approved by eCRD Administrator \n\r" );
				strMailBody.append("\n\r");
				strMailBody.append("\n\r");
				strMailBody.append("\n\r");
				strMailBody.append("\n\r");
				strMailBody.append("\n\r");
				strMailBody.append("\n\r");
				strMailBody.append("\n\r");
				strMailBody.append("\n\r");
				strMailBody.append(eCRDConstants.STRDISCLAIMER);
				eCRDMail.setText(strMailBody.toString() );
				eCRDMail.send();
				
			}
		}
		catch (GEAEMailMessageException objMailException)
		{
			eCRDException objException = null;
			objException = new eCRDException();
			objException.setExcpId("EMAIL_SEND_ERROR");
			throw objException;
		}
		finally
		{
			arlstMailTo = null;
			eCRDMail = null;
			strMailId = null;

		}
	}
	
	
	public void sendApprovalMailForRejection() throws eCRDException, Exception
	{
		ArrayList arlstMailTo = null;
		GEAEMailMessage eCRDMail = null;
		String strMailId[] = null;
		String strMailIdCC[] =new String[1];
		
		StringBuffer strMailBody = null;
		try
		{
			
			arlstMailTo= new ArrayList();
			
			//arlstMailTo = eCRDUtil.getEmaiID(this.objStgeCRDComponent);
			//arlstMailTo.add("sachin.shrivastav@ge.com");
			arlstMailTo.add("kumar.naravamakula@ge.com");
			arlstMailTo.add("Sreesujitha.Venkata@ge.com");	
			/*
			 * Changes done by TCS Team on 16 Nov 2011
			 */
			if(this.getRequestorMailId()!=null)
			arlstMailTo.add(this.getRequestorMailId());

			strMailBody =new StringBuffer();
			if (arlstMailTo.size() > 0)
			{
				eCRDMail = new GEAEMailMessage();
				strMailId = eCRDUtil.convertArrayListtoArray(arlstMailTo);
				strMailIdCC[0]= this.getApprovalMailId();

				eCRDMail.setSender(this.getApprovalMailId());
				
				eCRDMail.setSubject("The component " + this.objStgeCRDComponent.getComponentCode() + " is rejected by eCRD Administrator" );
				eCRDMail.setRecipients(GEAEMailMessage.TO, strMailId);
				eCRDMail.setRecipients(GEAEMailMessage.CC, strMailIdCC);
				strMailBody.append("*** This email message was generated by eCRD system. Please do not reply as the mail-box is not monitored ***\n\r");
				strMailBody.append("Engine Model    : " + this.objStgeCRDComponent.getModule().getEngineModel().getEngineModelDesc() + "\n\r" );
				strMailBody.append("Engine Module   : " + this.objStgeCRDComponent.getModule().getModuleDesc()+ "\n\r" );
				strMailBody.append("Component Code  : " + this.objStgeCRDComponent.getComponentCode()+ "\n\r" );
				strMailBody.append("Component Desc  : " + this.objStgeCRDComponent.getComponentDesc()+ "\n\r" );
				strMailBody.append("The above component has been rejected by eCRD Administrator \n\r" );
				strMailBody.append("Rejection Comments: \n" +  this.getRejectionComments());
				
				strMailBody.append("\n\r");
				strMailBody.append("\n\r");
				strMailBody.append("\n\r");
				strMailBody.append("\n\r");
				strMailBody.append("\n\r");
				strMailBody.append("\n\r");
				strMailBody.append("\n\r");
				strMailBody.append("\n\r");
				strMailBody.append(eCRDConstants.STRDISCLAIMER);
				eCRDMail.setText(strMailBody.toString() );
				eCRDMail.send();
				
			}
		}
		catch (GEAEMailMessageException objMailException)
		{
			eCRDException objException = null;
			objException = new eCRDException();
			objException.setExcpId("EMAIL_SEND_ERROR");
			throw objException;
		}
		finally
		{
			arlstMailTo = null;
			eCRDMail = null;
			strMailId = null;

		}
	}
	
}
