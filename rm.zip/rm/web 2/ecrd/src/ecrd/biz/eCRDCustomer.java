//Source file: D:\\ECRD\\SOURCE CODE\\ecrd\\biz\\eCRDCustomer.java
/*
* Module    	    : eCRDCustomer.java
* Author      	    : PATNI-Offshore
* Project	        : eCRD
* Date Written		: October 2004
* Security	        : Unclassified
* Restrictions		: GE PROPRIETARY INFORMATION, FOR GE USE ONLY
*
*     ****************************************************
*     *  Copyright (2000) with all rights reserved       *
*     *          General Electric Company                *
*     ****************************************************
*
* Description: eCRDCustomer is used for getting the Customer related data
*
* Revision Log  (mm/dd/yy initials description)
* --------------------------------------------------------------
*/

package ecrd.biz;

import java.io.Serializable;
import java.util.ArrayList;

import ecrd.common.eCRDDBMediator;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDUtil;
import geae.dao.GEAEResultSet;

/**
 * This entity represent the customer.
 */
public class eCRDCustomer implements Serializable
{
   private String strCustomerCode = null;
   private String strContractCode = null;
   private String strStartDate    = null;
   private String strEndDate      = null;
   private String strCustomerName = null;
   private String strContractDesc = null;	   
   /**
    * Load customer details from the database based on the customer code supplied
    * @param strCustomerCode
    */
   public eCRDCustomer(String strCustomerCode) throws Exception
   {
    ArrayList     arrlstInParam     = null ;
	ArrayList     arrlstOutParam    = null ;
	GEAEResultSet geaersetCustomer  = null ;
	String        strCustomerName   = ""   ;
	String        strContractCode   = ""   ;
	String        strStartDate      = ""   ;
	String        strEndDate        = ""   ;     
    try
    {
		arrlstInParam     = new ArrayList() ;
		arrlstInParam.add(strCustomerCode);   
		arrlstOutParam=eCRDDBMediator.doDBOperation(
						eCRDConstants.getActionId("eCRD_GET_CUSTOMER_DETAILS")
						,arrlstInParam);
		geaersetCustomer = ( GEAEResultSet )arrlstOutParam.get(0);
	
		if(geaersetCustomer!=null && geaersetCustomer.size()>0  )
		{
			
			geaersetCustomer.next();
			strCustomerName   = eCRDUtil.verifyNull(geaersetCustomer.getString("customer_name"));
			strContractCode   = eCRDUtil.verifyNull(geaersetCustomer.getString("contract_code"));
			strStartDate      = eCRDUtil.verifyNull(geaersetCustomer.getString("start_date"));
			strEndDate        = eCRDUtil.verifyNull(geaersetCustomer.getString("end_date"));
			strContractDesc   = eCRDUtil.verifyNull(geaersetCustomer.getString("contract_description"));
			this.setStartDate(strStartDate);
			this.setEndDate(strEndDate);
			this.setContractCode(strContractCode);
			this.setCustomerName(strCustomerName);	
			this.setContractDesc(strContractDesc);				
		}
		else
		{
			throw new Exception("Customer Not Found"); 				  
		}
    }
    finally
    {
    	
    }
   }
   
   public eCRDCustomer() 
   {
    
   }
   
   /**
    * @return String
    */
   public String getCustomerCode() 
   {
    return this.strCustomerCode;
   }
   public void setCustomerName(String strCustomerName)
   {
   	this.strCustomerName= strCustomerName;
   }
   /**
    * @return String
    */
   public String getContractCode() 
   {
    return this.strContractCode;
   }
   
   /**
    * @return String
    */
   public String getStartDate() 
   {
    return this.strStartDate;
   }
   
   /**
    * @return String
    */
   public String getEndDate() 
   {
    return this.strEndDate;
   }
   
   /**
    * @return String
    */
   public String getCustomerName() 
   {
    return this.strCustomerName;
   }
   
   /**
    * @param strCustomerCode
    */
   public void setCustomerCode(String strCustomerCode) 
   {
    this.strCustomerCode=strCustomerCode;
   }
   
   /**
    * @param strContractCode
    */
   public void setContractCode(String strContractCode) 
   {
    this.strContractCode=strContractCode;
   }
   
   /**
    * @param strStartDate
    */
   public void setStartDate(String strStartDate) 
   {
    this.strStartDate = strStartDate;
   }
   
   /**
    * @param strEndDate
    */
   public void setEndDate(String strEndDate) 
   {
    this.strEndDate = strEndDate;
   }
  /**
   * @return
   */
   public String getContractDesc()
   {
	  return strContractDesc;
   }

  /**
   * @param string
   */
   public void setContractDesc(String strContractDesc)
   {
	  this.strContractDesc = eCRDUtil.replaceString(strContractDesc, "\r\n", " "); 
   }

}
