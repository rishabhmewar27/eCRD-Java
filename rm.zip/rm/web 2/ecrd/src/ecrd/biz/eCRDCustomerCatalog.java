//Source file: D:\\ECRD\\SOURCE CODE\\ecrd\\biz\\eCRDCustomerCatalog.java
/*
* Module    	    : eCRDCustomerCatalog.java
* Author      	    : PATNI-Offshore
* Project	        : eCRD
* Date Written		: October 2004
* Security	        : Unclassified
* Restrictions		: GE PROPRIETARY INFORMATION, FOR GE USE ONLY
*
*     ****************************************************
*     *  Copyright (2000) with all rights reserved       *
*     *          General Electric Company                *
*     ****************************************************
*
* Description: eCRDCustomerCatalog is used for getting the
* Customer catalog data
*
* Revision Log  (mm/dd/yy initials description)
* --------------------------------------------------------------
*   31/15/2005     patni  Phase 1 requirement updations 
*/

package ecrd.biz;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import ecrd.common.eCRDDBMediator;
import ecrd.exception.eCRDException;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDUtil;
import geae.dao.GEAEResultSet;


/**
 * This is subclass of eCRDCatalog. This represent the customer catalog.
 */
public class eCRDCustomerCatalog extends eCRDCatalog implements Serializable
{

	/**
	 * This code is for OSB interface.
	 * Catalog number would generally consist of Engine Model, Customer Code, some
	 * contract details like %discount etc
	 */
	private String    strCatalogNumber = null;
	private ArrayList arrlstRules      = null;

	public  ArrayList arrlsteCRDCatalogRule = null;
	private HashMap   hmeCRDCustomers       = null;
	private Iterator  iterator              = null;

	/**
	 * Calculated price should be less than default value.
	 * For these rule level will be always catalog.
	 */
	private boolean flgDefaultValCompare = false;

	/**
	 * Whether to flow changes from Default Catalog.
	 * For these rule level will be always catalog.
	 */
	private boolean flgFlowChangesFrmDef = false;

	/**
	 * This will indicate if the Catalog is Discount Only Catalog or Escalation has been applied for it.
	 */
	private boolean flgEscalationInd = false;

	/**
	 * Constructor to load catalog details
	 * @param strCatlogCode
	 */

	public eCRDCustomerCatalog(String strCatlogCode) throws Exception
	{
		String          strActionId         = null ;
		String 			strActive 			= null;
		String 			strValue			= "";

		ArrayList       arrlstInParam       = null ;
		ArrayList       arrlstOutParam      = null ;

		GEAEResultSet   geaersetCustData    = null ;
		GEAEResultSet   geaersetCatalogData = null ;

		eCRDCustomer    objeCRDCustomer     = null ;
		try
		{
			strActionId = eCRDConstants.getActionId("eCRD_GET_CUSTOMER_CATALOG");
			arrlstInParam = new ArrayList();
			arrlstInParam.add(strCatlogCode);
			arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInParam);
			geaersetCatalogData = (GEAEResultSet)arrlstOutParam.get(0);
			geaersetCustData    = (GEAEResultSet)arrlstOutParam.get(1);
			strValue = eCRDUtil.verifyNull((String)arrlstOutParam.get(2));
			if(!"".equals(strValue))
			{
				this.setEscalationInd(retBoolean(strValue));
			}
			if(geaersetCatalogData!=null && geaersetCatalogData.size()>0)
			{
				geaersetCatalogData.next();
				this.setCatalogSeqId(strCatlogCode);
				this.setCatalogDesc(geaersetCatalogData.getString("catalog_desc"));
				
				//this.setCatInd(geaersetCatalogData.getString("cat_ind"));  //changes by vikrant
				
				this.setCatalogEndDate(geaersetCatalogData.getString("end_date"));
				this.setCatalogStartDate(geaersetCatalogData.getString("start_date"));
				this.setCopiedCatalogSeq(geaersetCatalogData.getString("copied_catalog_seq"));
				this.setCatalogNumber(geaersetCatalogData.getString("catalog_number"));
                this.setCatalogCreationBy(geaersetCatalogData.getString("created_by"));
                this.setCatalogCreationDate(geaersetCatalogData.getString("creation_date"));
                this.setCatalogEndDateModifiedBy(geaersetCatalogData.getString("end_date_modified_by"));
                this.setCatalogEndDateModifiedDate(geaersetCatalogData.getString("end_date_modified_date"));
				strActive = geaersetCatalogData.getString("active");
                if("true".equalsIgnoreCase(strActive))
				{
					this.setActive(true);
				}
				else
				{
					this.setActive(false);
				}
				this.setCatalogType("C");
				if(this.getEngineModel() == null)
				{
					eCRDEngineModel objeCRDEngineModel = new eCRDEngineModel();
					this.setEngineModel(objeCRDEngineModel);
				}
				this.getEngineModel().setEngineModelCode(geaersetCatalogData.getString("eng_mod_cd"));
				this.getEngineModel().setEngineModelDesc(geaersetCatalogData.getString("eng_mod_desc"));
				strValue = eCRDUtil.verifyNull(geaersetCatalogData.getString("flow_down_ind"));

				this.setFlowChangesFrmDef(retBoolean(strValue));

				strValue = null;
				strValue = eCRDUtil.verifyNull(geaersetCatalogData.getString("calc_price_default_ind"));

				this.setDefaltValCompare(retBoolean(strValue));
//            19-05-2006 patni checking null value Begin 
				if(geaersetCustData !=null)
                {
//            19-05-2006 patni checking null value End                    
                while(geaersetCustData.next())
				{
					objeCRDCustomer = new eCRDCustomer();
					objeCRDCustomer.setContractCode(
									geaersetCustData.getString("contract_code"));
					objeCRDCustomer.setCustomerCode(
									geaersetCustData.getString("cust_code"));
					objeCRDCustomer.setCustomerName(
									geaersetCustData.getString("cust_name"));
					objeCRDCustomer.setEndDate(
									geaersetCustData.getString("end_date"));
					objeCRDCustomer.setStartDate(
									geaersetCustData.getString("start_date"));
					objeCRDCustomer.setContractDesc(
									geaersetCustData.getString("cont_desc"));
					this.addCustomer(objeCRDCustomer);
					objeCRDCustomer = null;
				}
//              19-05-2006 patni checking null value Begin              
                } // end if
//              19-05-2006 patni checking null value End                
			}
			else
			{
				throw new eCRDException();
			}


		}
		finally
		{
			strActionId         = null;
			strActive 			= null;
			arrlstInParam       = null;
			arrlstOutParam      = null;
			geaersetCatalogData = null;
			geaersetCustData    = null;
		}
	}

	/**
	 * Default Constructor
	 */
	public eCRDCustomerCatalog()
	{

	}

	/**
	 * 1) Verify that Start and End date for all the customers fall within Start and
	 * End date of the catalog.
	 * 2) Verify that Customer Code and Contract Id combination doesn't already exist
	 * in some other customer catalog for the same Engine Model that is still active.
	 * (i.e. End date is not past due.)
	 * 3)
	 */
	public boolean create(String strUserId) throws Exception
	{
		ArrayList  arrlstInParam = null;
		ArrayList  arrlstOutParam = null;

		eCRDCustomer objeCRDCustomer = null;

		String strActionId = "";
		String strActive = "";
		String strAlertCd = "";
		String strCustCodes = "";
		String strCustDesc = "";
		String strCustContCodes = "";
		String strStartDates = "";
		String strEndDates = "";
		String strValue = "";
		boolean blnCatalogCreated = false;
		int intNoOfCusts = 0;
		GEAEResultSet geaersetCatalogData = null;
		GEAEResultSet geaersetCustData = null;
		try
		{
			arrlstInParam = new ArrayList();
			geaersetCatalogData = new GEAEResultSet();
			geaersetCustData = new GEAEResultSet();
			iterator = this.hmeCRDCustomers.keySet().iterator();

			if (hmeCRDCustomers == null)
			{
				throw new Exception("No customers found for catalog");
			}
			else
			{
				intNoOfCusts = this.hmeCRDCustomers.size();
			}
			if (intNoOfCusts == 0)
			{
				throw new Exception("No customers found for catalog");
			}
			while (iterator.hasNext())
			{
				objeCRDCustomer = (eCRDCustomer) hmeCRDCustomers.get((String) iterator.next());

				strCustCodes = strCustCodes + objeCRDCustomer.getCustomerCode() + eCRDConstants.STRCOLUMNDELIM;
				strCustContCodes = strCustContCodes + objeCRDCustomer.getContractCode() + eCRDConstants.STRCOLUMNDELIM;
				strCustDesc= strCustDesc+ objeCRDCustomer.getContractDesc() + eCRDConstants.STRCOLUMNDELIM;
				strStartDates = strStartDates + objeCRDCustomer.getStartDate() + eCRDConstants.STRCOLUMNDELIM;
				strEndDates = strEndDates + objeCRDCustomer.getEndDate() + eCRDConstants.STRCOLUMNDELIM;

			}
			arrlstInParam.add(this.getEngineModel().getEngineModelCode());
			arrlstInParam.add(eCRDUtil.verifyNull(getStartDate()));
			arrlstInParam.add(eCRDUtil.verifyNull(getEndDate()));
			arrlstInParam.add(eCRDUtil.verifyNullNoTrim(strCustCodes));
			arrlstInParam.add(eCRDUtil.verifyNull(strCustContCodes));
			arrlstInParam.add(eCRDUtil.verifyNull(strCustDesc));
			arrlstInParam.add(eCRDUtil.verifyNull(strStartDates));
			arrlstInParam.add(eCRDUtil.verifyNull(strEndDates));
			arrlstInParam.add(eCRDUtil.verifyNull(getCatalogNumber()));
			arrlstInParam.add(eCRDUtil.verifyNull(getCatalogDesc()));
			
			arrlstInParam.add(eCRDUtil.verifyNull(getCatInd()));  //changes by vikrant
			
			arrlstInParam.add(eCRDUtil.verifyNull(getCopiedCatalogSeq()));
			arrlstInParam.add(strUserId);
			strActionId = eCRDConstants.getActionId("eCRD_CREATE_CUSTOMER_CATALOG");
			arrlstOutParam = (ArrayList) eCRDDBMediator.doDBOperation(strActionId, arrlstInParam);
			strAlertCd = eCRDUtil.verifyNull((String) arrlstOutParam.get(3));
			this.setCatalogType("C");
			geaersetCatalogData = (GEAEResultSet)arrlstOutParam.get(0);
			geaersetCustData    = (GEAEResultSet)arrlstOutParam.get(1);
			if ("CREATE_SUCCESS".equals(strAlertCd))
			{
				setCatalogSeqId((String) arrlstOutParam.get(2));
				blnCatalogCreated = true;
			}
			else
			{
				blnCatalogCreated = false;
			}
			strValue = eCRDUtil.verifyNull((String)arrlstOutParam.get(4));
			if(!"".equals(strValue))
			{
				this.setEscalationInd(retBoolean(strValue));
			}
			if(geaersetCatalogData!=null && geaersetCatalogData.size()>0)
			{
				geaersetCatalogData.next();
				this.setCatalogSeqId((String) arrlstOutParam.get(2));
				this.setCatalogDesc(geaersetCatalogData.getString("catalog_desc"));
				this.setCatalogEndDate(geaersetCatalogData.getString("end_date"));
				this.setCatalogStartDate(geaersetCatalogData.getString("start_date"));
				this.setCopiedCatalogSeq(geaersetCatalogData.getString("copied_catalog_seq"));
				this.setCatalogNumber(geaersetCatalogData.getString("catalog_number"));
				this.setCatalogType("C");
				strActive = geaersetCatalogData.getString("active");
				if("true".equalsIgnoreCase(strActive))
				{
					this.setActive(true);
				}
				else
				{
					this.setActive(false);
				}
				if(this.getEngineModel() == null)
				{
					eCRDEngineModel objeCRDEngineModel = new eCRDEngineModel();
					this.setEngineModel(objeCRDEngineModel);
				}
				this.getEngineModel().setEngineModelCode(geaersetCatalogData.getString("eng_mod_cd"));
				this.getEngineModel().setEngineModelDesc(geaersetCatalogData.getString("eng_mod_desc"));
				strValue = eCRDUtil.verifyNull(geaersetCatalogData.getString("flow_down_ind"));

				this.setFlowChangesFrmDef(retBoolean(strValue));

				strValue = null;
				strValue = eCRDUtil.verifyNull(geaersetCatalogData.getString("calc_price_default_ind"));

				this.setDefaltValCompare(retBoolean(strValue));
//            19-05-2006 patni checking null value Begin 
                if (geaersetCustData != null)
                {
//            19-05-2006 patni checking null value End                     
				while(geaersetCustData.next())
				{
					objeCRDCustomer = new eCRDCustomer();
					objeCRDCustomer.setContractCode(
									geaersetCustData.getString("contract_code"));
					objeCRDCustomer.setCustomerCode(
									geaersetCustData.getString("cust_code"));
					objeCRDCustomer.setCustomerName(
									geaersetCustData.getString("cust_name"));
					objeCRDCustomer.setEndDate(
									geaersetCustData.getString("end_date"));
					objeCRDCustomer.setStartDate(
									geaersetCustData.getString("start_date"));
					objeCRDCustomer.setContractDesc(
									geaersetCustData.getString("cont_desc"));
					this.addCustomer(objeCRDCustomer);
					objeCRDCustomer = null;
				}
//            19-05-2006 patni checking null value Begin 
                } // end if 
//              19-05-2006 patni checking null value End                
			}
			else
			{
				throw new eCRDException();
			}

			return blnCatalogCreated;
		}
		finally
		{
			arrlstInParam = null;
			arrlstOutParam = null;
			strActionId = null;
			strActive = null;
			strAlertCd = null;
			strCustCodes = null;
			strCustContCodes = null;
			strStartDates = null;
			strEndDates = null;

		}

	}

	public boolean save(String strUserId) throws Exception
	{
		ArrayList arrlstInParam = null;
		ArrayList arrlstOutParam = null;

		eCRDCustomer objeCRDCustomer = null;

		String strActionId = "";
		String strAlertCd = "";
		String strCustCodes = "";
		String strCustContCodes = "";
		String strStartDates = "";
		String strEndDates = "";
		boolean blnCatalogSaved = false;
		int intNoOfCusts = 0;
		try
		{
			arrlstInParam = new ArrayList();
			iterator = this.hmeCRDCustomers.keySet().iterator();

			if (hmeCRDCustomers == null)
			{
				throw new Exception("No customers found for catalog");
			}
			else
			{
				intNoOfCusts = this.hmeCRDCustomers.size();
			}
			if (intNoOfCusts == 0)
			{
				throw new Exception("No customers found for catalog");
			}
			while (iterator.hasNext())
			{
				objeCRDCustomer = (eCRDCustomer) hmeCRDCustomers.get((String) iterator.next());

				strCustCodes = strCustCodes + objeCRDCustomer.getCustomerCode() + eCRDConstants.STRCOLUMNDELIM;
				strCustContCodes = strCustContCodes + objeCRDCustomer.getContractCode() + eCRDConstants.STRCOLUMNDELIM;
				strStartDates = strStartDates + objeCRDCustomer.getStartDate() + eCRDConstants.STRCOLUMNDELIM;
				strEndDates = strEndDates + objeCRDCustomer.getEndDate() + eCRDConstants.STRCOLUMNDELIM;

			}
			arrlstInParam.add(this.getCatalogSeqId());
			arrlstInParam.add(getStartDate());
			arrlstInParam.add(getEndDate());

			arrlstInParam.add(strCustCodes);
			arrlstInParam.add(strCustContCodes);
			arrlstInParam.add(strStartDates);
			arrlstInParam.add(strEndDates);
			arrlstInParam.add(getCatalogDesc());
			
			arrlstInParam.add(getCatInd());  //changes by vikrant
			
			arrlstInParam.add(strUserId);
			strActionId = eCRDConstants.getActionId("eCRD_SAVE_CUSTOMER_CATALOG");
			arrlstOutParam = (ArrayList) eCRDDBMediator.doDBOperation(strActionId, arrlstInParam);
			strAlertCd = eCRDUtil.verifyNull((String) arrlstOutParam.get(1));
			if ("".equals(strAlertCd))
			{
				setCatalogSeqId((String) arrlstOutParam.get(0));
				blnCatalogSaved = true;
			}
			else
			{
				blnCatalogSaved = false;
			}
			return blnCatalogSaved;
		}
		finally
		{
			arrlstInParam = null;
			arrlstOutParam = null;
			strActionId = null;
			strAlertCd = null;
			strCustCodes = null;
			strCustContCodes = null;
			strStartDates = null;
			strEndDates = null;
		}

	}

	/**
	 * Copies current customer/default catalog and returns reference to the new copied
	 * catalog. User needs to set engine model, start date end date of this new
	 * catalog.
	 * @return ecrd.biz.eCRDCatalog
	 */
	public boolean copyCatalog(eCRDCatalog objCopiedCatalog, String strUserId) throws Exception
	{

		ArrayList         arrlstInParam       = null;
		ArrayList         arrlstOutParam      = null;

		eCRDEngineModel   objeCRDEngineModel  = null;
		eCRDCustomer      objeCRDCustomer     = null;

		String            strActionId         = "";
		String            strAlertCd          = "";
		String            strCustCodes        = "";
		String            strCustContCodes    = "";
		String            strStartDates       = "";
		String            strEndDates         = "";

		int               intNoOfCusts        = 0;
		boolean           blnIsCopied         = false;

		try
		{
			arrlstInParam = new ArrayList();
			iterator = this.hmeCRDCustomers.keySet().iterator();
			if (hmeCRDCustomers == null)
			{
				throw new Exception("No customers found for catalog");
			}
			else
			{
				intNoOfCusts = this.hmeCRDCustomers.size();
			}
			if (intNoOfCusts == 0)
			{
				throw new Exception("No customers found for catalog");
			}
			while (iterator.hasNext())
			{
				objeCRDCustomer = (eCRDCustomer) hmeCRDCustomers.get((String) iterator.next());

				strCustCodes = strCustCodes + objeCRDCustomer.getCustomerCode() + eCRDConstants.STRCOLUMNDELIM;
				strCustContCodes = strCustContCodes + objeCRDCustomer.getContractCode() + eCRDConstants.STRCOLUMNDELIM;
				strStartDates = strStartDates + objeCRDCustomer.getStartDate() + eCRDConstants.STRCOLUMNDELIM;
				strEndDates = strEndDates + objeCRDCustomer.getEndDate() + eCRDConstants.STRCOLUMNDELIM;

			}
			arrlstInParam.add(objCopiedCatalog.getCatalogSeqId());
			arrlstInParam.add(this.getEngineModel().getEngineModelCode());
			arrlstInParam.add(this.getStartDate());
			arrlstInParam.add(this.getEndDate());

			arrlstInParam.add(strCustCodes);
			arrlstInParam.add(strCustContCodes);
			arrlstInParam.add(strStartDates);
			arrlstInParam.add(strEndDates);
			arrlstInParam.add(getCatalogDesc());
			
			arrlstInParam.add(getCatInd());  //changes by vikrant
			
			arrlstInParam.add(strUserId);
			strActionId = eCRDConstants.getActionId("eCRD_COPY_CUSTOMER_CATALOG");
			arrlstOutParam = (ArrayList) eCRDDBMediator.doDBOperation(strActionId, arrlstInParam);
			strAlertCd = eCRDUtil.verifyNull((String) arrlstOutParam.get(1));
			if ("".equals(strAlertCd))
			{
				setCatalogSeqId((String) arrlstOutParam.get(0));
				setCopiedCatalogSeq("");
				blnIsCopied = true;
			}

			return blnIsCopied;
		}
		finally
		{
			arrlstInParam = null;
			arrlstOutParam = null;
			strActionId = null;
			strAlertCd = null;
			strCustCodes = null;
			strCustContCodes = null;
			strStartDates = null;
			strEndDates = null;
		}
	}
	/**
	 * Add customer to the catalog
	 * @param objCustomer
	 */
	public void addCustomer(eCRDCustomer objCustomer)
	{
		if (hmeCRDCustomers == null)
		{
			hmeCRDCustomers = new HashMap();
		}
		//this.arrlsteCRDCustomers.add(objCustomer);
		this.hmeCRDCustomers.put(objCustomer.getCustomerCode(), objCustomer);
	}
	/**
	 * This method will return customer object depending on
	 * the customer code given to it
	 * @param strCustomerCode
	 * @return eCRDCustomer
	 */
	public eCRDCustomer getCustomer(String strCustomerCode)
	{
		return (eCRDCustomer) this.hmeCRDCustomers.get(strCustomerCode);
	}

	/**
	 * Creates a new rule for this Catalog . The rule is also added to the list of
	 * rules.
	 * @return ecrd.biz.eCRDCatalogRule
	 */
	public eCRDCatalogRule addRule()
	{
		eCRDCatalogRule objeCRDCatalogRule = new eCRDCatalogRule();
		if (arrlstRules == null)
		{
			arrlstRules = new ArrayList();
		}
		arrlstRules.add(objeCRDCatalogRule);
		return objeCRDCatalogRule;
	}

	/**
	 * Updates rule for a customer catalog.
	 * @param eCRDCatalogRule
	 * @param strUserId
	 */
	public String UpdateCatalogRule(eCRDCatalogRule objeCRDCatalogRule, String strUserId) throws Exception
	{
		String          strAlertCode         = null;
		String          strActionId          = null;
		//StringTokenizer strTknLevelCd        = null;
		ArrayList       arrlstInParam        = null;
		ArrayList       arrlstOutParam       = null;
		String strFlowDownChanges = "";
		String strDefaultValCompare = "";

		try
		{
			strFlowDownChanges = eCRDUtil.retString(getFlowChangesFrmDef());
			strDefaultValCompare = eCRDUtil.retString(getDefaultValCompare());
			arrlstInParam = new ArrayList();
			arrlstInParam.add(objeCRDCatalogRule.getRuleLevel());
			arrlstInParam.add(getCatalogSeqId()+"");
			arrlstInParam.add(objeCRDCatalogRule.getComponentCd());
			arrlstInParam.add(objeCRDCatalogRule.getModuleCd());
			arrlstInParam.add(objeCRDCatalogRule.getRepairCd());
			arrlstInParam.add(objeCRDCatalogRule.getYear());
			arrlstInParam.add(eCRDUtil.verifyNullReturnObject(objeCRDCatalogRule.getTAT()) + "");
			arrlstInParam.add(eCRDUtil.verifyNullReturnObject(objeCRDCatalogRule.getDiscount()) + "");
			arrlstInParam.add(strDefaultValCompare);
			arrlstInParam.add(strFlowDownChanges);
			arrlstInParam.add(eCRDUtil.verifyNullReturnObject(objeCRDCatalogRule.getEscalation().getEscalation()) + "");
			arrlstInParam.add(objeCRDCatalogRule.getIndexDep());
			arrlstInParam.add(strUserId);

			strActionId = eCRDConstants.getActionId("eCRD_UPDATE_RULE");

			arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInParam);

			strAlertCode = (String)arrlstOutParam.get(0);

			return strAlertCode;
		}
		finally
		{
			strAlertCode = null;
			strFlowDownChanges = "";
			strDefaultValCompare = "";
			arrlstInParam = null;
			arrlstOutParam = null;
			strFlowDownChanges = "";
			strDefaultValCompare = "";
		}
	}


	/**
	 * Remove customer from the catalog
	 * @param strCustomerCode
	 */
	public void removeCustomer(String strCustomerCode) throws Exception
	{
		if (hmeCRDCustomers != null && hmeCRDCustomers.size() > 0)
		{
			this.hmeCRDCustomers.remove(strCustomerCode);
		}
		else
		{
			throw new Exception("Customer not associated with Catalog");
		}
	}

	/**
	 * Retrieves all eCRDCustomer objets for this customer catalog.
	 * @return HashMap
	 */
	public HashMap getCustomers()
	{
		return this.hmeCRDCustomers;
	}

	/**
	 * Returns fully loaded Rule object for the specified rule code.
	 * If the object is not in hasMap, calls constructor with parameters and load the
	 * object and add it to the hashmap.
	 * If the catalogRule object is in hashmap and partially loaded then calls
	 * constructor with parameters for the component object and assigns new object to
	 * the exisitng reference.
	 * @param strRuleCode
	 * @return ecrd.biz.eCRDCatalogRule
	 */
	public eCRDCatalogRule getRule(String strYear, String strRuleLevel, String strComponentCode, String strModuleCode, String strRepairCode) throws Exception
	{
		String strLevelAppendedCd = null;
		String strValue = null;
		String[][] arrIndex = null;
		String strActionId = "";
		int intCtr = 0;

		eCRDCatalogRule objeCRDCatalogRule = null;
		eCRDEscalation objeCRDEscalation = null;

		ArrayList arrlstRuleLevelCd = null;
		ArrayList arrlstInParam = null;
		ArrayList arrlstOutParam = null;

		GEAEResultSet geaersetRules = null;
		GEAEResultSet geaersetInflation = null;
		GEAEResultSet geaersetDefaultFlow = null;
		try
		{

			objeCRDCatalogRule = new eCRDCatalogRule(strYear, strRuleLevel, strComponentCode, strModuleCode, strRepairCode);

			arrlstInParam = new ArrayList();
			arrlstInParam = new ArrayList();
			arrlstInParam.add(getCatalogSeqId()+"");

			arrlstInParam.add(strYear);
			arrlstInParam.add(strRuleLevel);
			arrlstInParam.add(strModuleCode);
			arrlstInParam.add(strComponentCode);
			arrlstInParam.add(strRepairCode);

			strActionId = eCRDConstants.getActionId("eCRD_GET_RULES");

			arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInParam);

			geaersetRules = (GEAEResultSet) arrlstOutParam.get(0);
			geaersetInflation = (GEAEResultSet) arrlstOutParam.get(1);
			geaersetDefaultFlow = (GEAEResultSet) arrlstOutParam.get(2);
			if (geaersetRules != null && geaersetRules.size() == 1)
			{
				geaersetRules.setCurrentRow(0);
				geaersetRules.next();
				strValue = eCRDUtil.verifyNull(geaersetRules.getString("tat"));

				if (!"".equals(strValue))
				{
					objeCRDCatalogRule.setTAT(eCRDUtil.verifyIntObj(strValue));
				}
				else
				{
					objeCRDCatalogRule.setTAT(null);
				}
				strValue = null;
				strValue = eCRDUtil.verifyNull(geaersetRules.getString("discount"));

				if (!"".equals(strValue))
				{
					objeCRDCatalogRule.setDiscount(eCRDUtil.verifyDoubleObj(strValue));
				}
				else
				{
					objeCRDCatalogRule.setDiscount(null);
				}

				strValue = null;
				if ("C".equals(strRuleLevel))
				{
					if(geaersetDefaultFlow != null && geaersetDefaultFlow.size() == 1)
					{
						geaersetDefaultFlow.setCurrentRow(0);
						geaersetDefaultFlow.next();
						strValue = null;
						strValue = eCRDUtil.verifyNull(geaersetDefaultFlow.getString("flow_down_ind"));
						objeCRDCatalogRule.setFlowChangesFrmDef(retBoolean(strValue));
						this.flgFlowChangesFrmDef = retBoolean(strValue);

						strValue = null;
						strValue = eCRDUtil.verifyNull(geaersetDefaultFlow.getString("calc_price_default_ind"));
						objeCRDCatalogRule.setDefaltValCompare(retBoolean(strValue));
						this.flgDefaultValCompare = retBoolean(strValue);
					}
					/*
					 *
					 */
					strValue = eCRDUtil.verifyNull(geaersetRules.getString("escalation"));

					objeCRDEscalation = new eCRDEscalation();

					if ("".equals(strValue))
					{
						if (geaersetInflation != null && geaersetInflation.size() > 0)
						{
							geaersetInflation.setCurrentRow(0);
							arrIndex = new String[geaersetInflation.size()][2];

							while (geaersetInflation.next())
							{

								arrIndex[intCtr][0] = geaersetInflation.getString("index_value");
								arrIndex[intCtr][1] = geaersetInflation.getString("index_dep");

								intCtr++;
							}
						}
						objeCRDEscalation.setIndexDependency(arrIndex);
					}
					else
					{
						objeCRDEscalation.setEscalation(eCRDUtil.verifyDoubleObj(strValue));
					}
					strValue = null;
					objeCRDCatalogRule.addEscalation(objeCRDEscalation);
				}
			}
			return objeCRDCatalogRule;
		}
		finally
		{
			strLevelAppendedCd = null;
			strValue = null;
			arrIndex = null;
			strActionId = "";
			objeCRDCatalogRule = null;
			objeCRDEscalation = null;
			arrlstRuleLevelCd = null;
			arrlstInParam = null;
			arrlstOutParam = null;
			geaersetRules = null;
			geaersetInflation = null;
		}
	}
	private boolean retBoolean(String strBoolean)
	{
		if (strBoolean.toUpperCase().equals("Y") || strBoolean.toUpperCase().equals("TRUE"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	/*
	 *
	 */
	public String createCatalogRule(eCRDCatalogRule objeCRDCatalogRule, String strUserId) throws Exception
	{
		String          strAlertCode         = null;
		String          strActionId          = null;
		//StringTokenizer strTknLevelCd        = null;
		ArrayList       arrlstInParam        = null;
		ArrayList       arrlstOutParam       = null;
		String strFlowDownChanges = "";
		String strDefaultValCompare = "";
		GEAEResultSet rsCatalogRules = null;
		GEAEResultSet rsModuleRules = null;
		GEAEResultSet rsComponentRules = null;
		GEAEResultSet rsRepairRules = null;
		GEAEResultSet rsInflation = null;
		try
		{
			strFlowDownChanges = eCRDUtil.retString(objeCRDCatalogRule.getFlowChangesFrmDef());
			strDefaultValCompare = eCRDUtil.retString(objeCRDCatalogRule.getDefaultValCompare());
			arrlstInParam = new ArrayList();
			arrlstInParam.add(objeCRDCatalogRule.getRuleLevel());
			arrlstInParam.add(getCatalogSeqId()+"");
			arrlstInParam.add(objeCRDCatalogRule.getComponentCd());
			arrlstInParam.add(objeCRDCatalogRule.getModuleCd());
			arrlstInParam.add(objeCRDCatalogRule.getRepairCd());
			arrlstInParam.add(objeCRDCatalogRule.getYear());
			arrlstInParam.add(eCRDUtil.verifyNullReturnObject(objeCRDCatalogRule.getTAT()) + "");
			arrlstInParam.add(eCRDUtil.verifyNullReturnObject(objeCRDCatalogRule.getDiscount()) + "");
			arrlstInParam.add(strDefaultValCompare);
			arrlstInParam.add(strFlowDownChanges);
			arrlstInParam.add(eCRDUtil.verifyNullReturnObject(objeCRDCatalogRule.getEscalation().getEscalation()) + "");
			arrlstInParam.add(objeCRDCatalogRule.getIndexDep());
			arrlstInParam.add(strUserId);

			strActionId = eCRDConstants.getActionId("eCRD_CREATE_RULES");

			arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInParam);

			strAlertCode = (String)arrlstOutParam.get(0);



			return strAlertCode;
		}
		finally
		{
			strAlertCode   = null;
			strFlowDownChanges = "";
			strDefaultValCompare = "";
			arrlstInParam  = null;
			arrlstOutParam = null;
			strFlowDownChanges = "";
			strDefaultValCompare = "";
			rsCatalogRules = null;
			rsModuleRules = null;
			rsComponentRules = null;
			rsRepairRules = null;
			rsInflation = null;
		}

	}
	/**
	 * @return
	 */
	public String getCatalogNumber()
	{
		return strCatalogNumber;
	}

	/**
	 * @param string
	 */
	public void setCatalogNumber(String strCatalogNumber)
	{
		this.strCatalogNumber = strCatalogNumber;
	}

	public GEAEResultSet[] viewRules(String strYear) throws Exception
	{
		GEAEResultSet rsCatalog = null;
		GEAEResultSet rsInflation = null;
		GEAEResultSet rsModules = null;
		GEAEResultSet rsComponent = null;
		GEAEResultSet rsRepair = null;
		ArrayList arrlstInParam = null;
		ArrayList arrlstOutParam = null;
		String strActionId = "";
		//String strMessage = "";
		GEAEResultSet rsResults[] = null;
		try
		{
			arrlstInParam = new ArrayList();
			arrlstOutParam = new ArrayList();
			rsResults = new GEAEResultSet[5];
			arrlstInParam.add(this.getCatalogSeqId());
			arrlstInParam.add(strYear);
			strActionId = eCRDConstants.getActionId("eCRD_VIEW_RULES");

			arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId,arrlstInParam);
			rsCatalog = (GEAEResultSet)arrlstOutParam.get(0);
			rsInflation = (GEAEResultSet)arrlstOutParam.get(1);
			rsModules = (GEAEResultSet)arrlstOutParam.get(2);
			rsComponent = (GEAEResultSet)arrlstOutParam.get(3);
			rsRepair = (GEAEResultSet)arrlstOutParam.get(4);
			//strMessage = (String)arrlstOutParam.get(5);

			rsResults[0] = rsCatalog;
			rsResults[1] = rsInflation;
			rsResults[2] = rsModules;
			rsResults[3] = rsComponent;
			rsResults[4] = rsRepair;

			return rsResults;
		}
		finally
		{
			rsCatalog = null;
			rsInflation = null;
			rsModules = null;
			rsComponent = null;
			rsRepair = null;
			arrlstInParam = null;
			arrlstOutParam = null;
			strActionId =null;
			//strMessage = "";
			//rsResults = null;
		}
	}

	public String copyAndApplyRules(String strUserId) throws Exception
	{
		ArrayList arrlstInParam = null;
		ArrayList arrlstOutParam = null;
		String strMessage = "";
		String strAction = "";
		try
		{
			arrlstInParam = new ArrayList();
			arrlstOutParam = new ArrayList();

			arrlstInParam.add(this.getCatalogSeqId()+"");
			arrlstInParam.add(strUserId);

			strAction = eCRDConstants.getActionId("eCRD_COPY_AND_APPLY_RULE");
			arrlstOutParam = eCRDDBMediator.doDBOperation(strAction,arrlstInParam);

			strMessage = (String)arrlstOutParam.get(0);

			return strMessage;
		}
		finally
		{
			arrlstInParam = null;
			arrlstOutParam = null;
			strMessage = null;
			strAction =null;
		}
	}
	 //The below method is added for applying default refresh - Kumar
	public String ApplyDefaultRefreshRules (String strUserId) throws Exception
	{
		ArrayList arrlstInParam = null;
		ArrayList arrlstOutParam = null;
		String strMessage = "";
		String strAction = "";
		try
		{
			arrlstInParam = new ArrayList();
			arrlstOutParam = new ArrayList();

			arrlstInParam.add(this.getCatalogSeqId()+"");
			arrlstInParam.add(strUserId);

			strAction = eCRDConstants.getActionId("eCRD_APPLY_Default_Refresh_RULE");
			arrlstOutParam = eCRDDBMediator.doDBOperation(strAction,arrlstInParam);

			strMessage = (String)arrlstOutParam.get(0);
			return strMessage;
		}
		finally
		{
			arrlstInParam = null;
			arrlstOutParam = null;
			strMessage = null;
			strAction =null;
		}
	}

	public String copyCatalogRules(String strUserId) throws Exception
	{
		String strMessage = "";
		ArrayList arrlstInParam = null;
		ArrayList arrlstOutParam = null;
		String strActionId = "";
		String strFlowDownInd = "";
		String strDefaultInd = "";
		try
		{
			arrlstInParam = new ArrayList();
			arrlstOutParam = new ArrayList();

			arrlstInParam.add(this.getCatalogSeqId()+"");
			arrlstInParam.add(this.getCopiedCatalogSeq()+"");
			arrlstInParam.add(strUserId);
			strActionId = eCRDConstants.getActionId("eCRD_COPY_CATALOG");
			arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId,arrlstInParam);

			strMessage = eCRDUtil.verifyNull((String)arrlstOutParam.get(0));
			strFlowDownInd = eCRDUtil.verifyNull((String)arrlstOutParam.get(1));
			strDefaultInd = eCRDUtil.verifyNull((String)arrlstOutParam.get(2));

			this.setFlowChangesFrmDef(eCRDUtil.retBoolean(strFlowDownInd));
			this.setDefaltValCompare(eCRDUtil.retBoolean(strDefaultInd));

			return strMessage;
		}
		finally
		{
			strMessage =null;
			arrlstInParam = null;
			arrlstOutParam = null;
			strActionId = null;
		}
	}

	public String checkRuleExists(String strYear,String strRuleCd,String strComponentCd,String strModuleCd,String strRepairCd) throws Exception
	{
		ArrayList arrlstInParam = null;
		ArrayList arrlstOutParam = null;
		String strMessage = "";
		String strActionId = "";
		try
		{
			arrlstInParam = new ArrayList();
			arrlstOutParam = new ArrayList();

			arrlstInParam.add(getCatalogSeqId()+"");

			arrlstInParam.add(strYear);
			arrlstInParam.add(strRuleCd);
			arrlstInParam.add(strModuleCd);
			arrlstInParam.add(strComponentCd);
			arrlstInParam.add(strRepairCd);

			strActionId = eCRDConstants.getActionId("eCRD_CHECK_RULE");
			arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId,arrlstInParam);
			strMessage = eCRDUtil.verifyNull((String)arrlstOutParam.get(0));

			return strMessage;
		}
		finally
		{
			arrlstInParam = null;
			arrlstOutParam = null;
			strActionId =null;
		}
	}

	public String deleteRule(String strYear, String strRuleCd, String strComponentId, String strModuleId, String strRepairId, String strCatalogId) throws Exception
	{
		String strMessage = "";
		String strAction = "";
		ArrayList arrlstInParam = null;
		ArrayList arrlstOutParam = null;
		try
		{
			arrlstInParam = new ArrayList();
			arrlstOutParam = new ArrayList();
			strAction = eCRDConstants.getActionId("eCRD_DELETE_RULE");
			arrlstInParam.add(strYear);
			arrlstInParam.add(strRuleCd);
			arrlstInParam.add(strComponentId);
			arrlstInParam.add(strModuleId);
			arrlstInParam.add(strRepairId);
			arrlstInParam.add(strCatalogId);

			arrlstOutParam = eCRDDBMediator.doDBOperation(strAction,arrlstInParam);

			strMessage = eCRDUtil.verifyNull((String)arrlstOutParam.get(0));

			return strMessage;
		}
		finally
		{
			strMessage = null;
			strAction = null;
			arrlstInParam = null;
			arrlstOutParam = null;
		}
	}

	/**
	 * @return boolean
	 */
	public boolean getDefaultValCompare()
	{
		return this.flgDefaultValCompare;
	}

	/**
	 * @return boolean
	 */
	public boolean getFlowChangesFrmDef()
	{
		return this.flgFlowChangesFrmDef;
	}

	/**
	 * For setting Catalog Level Rule
	 * @param flgDefaltValCompare
	 */
	public void setDefaltValCompare(boolean flgDefaultValCompare)
	{
		this.flgDefaultValCompare = flgDefaultValCompare;
	}

	/**
	 * For setting Catalog Level Rule
	 * @param flgFolwChangesFrmDef
	 */
	public void setFlowChangesFrmDef(boolean flgFlowChangesFrmDef)
	{
		this.flgFlowChangesFrmDef = flgFlowChangesFrmDef;
	}

	/**
	 * @return boolean
	 */
	public boolean getEscalationInd()
	{
		return this.flgEscalationInd;
	}

	/**
	 * For Finding if Catalog has any escalation
	 * @param flgFolwChangesFrmDef
	 */
	public void setEscalationInd(boolean flgEscalationInd)
	{
		this.flgEscalationInd = flgEscalationInd;
	}

	public String doesContractExists(String strEngModel, String strCustomerCd, String strContractCodes) throws Exception
	{
		String strMessage = "";
		ArrayList arrlstInParam= null;
		ArrayList arrlstOutParam = null;
		String strActionId = "";
		try
		{
			arrlstInParam = new ArrayList();
			arrlstOutParam = new ArrayList();

			strActionId = eCRDConstants.getActionId("eCRD_EXIST_CUSTOMER_CATALOG");
			arrlstInParam.add(strEngModel);
			arrlstInParam.add(strCustomerCd);
			arrlstInParam.add(strContractCodes);
			arrlstInParam.add(this.getStartDate());
			arrlstInParam.add(this.getEndDate());
			arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId,arrlstInParam);

			strMessage = eCRDUtil.verifyNull((String)arrlstOutParam.get(0));

			return strMessage;
		}
		finally
		{

			arrlstInParam= null;
			arrlstOutParam = null;
			strActionId = null;
		}
	}
}
