//Source file: D:\\ECRD\\SOURCE CODE\\ecrd\\biz\\eCRDDefaultCatalog.java
/*
* Module    	    : eCRDDefaultCatalog.java
* Author      	    : PATNI-Offshore
* Project	        : eCRD
* Date Written		: October 2004
* Security	        : Unclassified
* Restrictions		: GE PROPRIETARY INFORMATION, FOR GE USE ONLY
*
*     ****************************************************
*     *  Copyright (2000) with all rights reserved       *
*     *          General Electric Company                *
*     ****************************************************
*
* Description: eCRDDefaultCatalog is used for getting Default catalog data
*
* Revision Log  (mm/dd/yy initials description)
* --------------------------------------------------------------
*/
package ecrd.biz;

import java.io.Serializable;
import java.util.ArrayList;
import ecrd.common.eCRDDBMediator;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDUtil;
import geae.dao.GEAEResultSet;
/**
 * THis entity brepresent the Default catalog.
 */
public class eCRDDefaultCatalog extends eCRDCatalog implements Serializable
{

	/**
	 * Just loads catalog specific parameters e.g. Start Date, End Date etc.
	 * @param intCatalogSeqCode
	 */
	public eCRDDefaultCatalog(String strCatalogSeqCode) throws Exception
	{
		String strActionId = null;
		String strActive = null;

		ArrayList arrlstInParam = null;
		ArrayList arrlstOutParam = null;

		GEAEResultSet geaersetCatalogData = null;

		try
		{
			strActionId = eCRDConstants.getActionId("eCRD_GET_DEFAULT_CATALOG");
			arrlstInParam = new ArrayList();
			arrlstInParam.add(strCatalogSeqCode);
			arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInParam);
			geaersetCatalogData = (GEAEResultSet) arrlstOutParam.get(0);

			if (geaersetCatalogData != null && geaersetCatalogData.size() > 0)
			{
				geaersetCatalogData.next();
				this.setCatalogSeqId(strCatalogSeqCode);
				this.setCatalogDesc(geaersetCatalogData.getString("catalog_desc"));
				
				//this.setCatInd(geaersetCatalogData.getString("cat_ind"));  //changes by vikrant
				
				this.setCatalogEndDate(geaersetCatalogData.getString("end_date"));
				this.setCatalogStartDate(geaersetCatalogData.getString("start_date"));
				this.setCopiedCatalogSeq(geaersetCatalogData.getString("copied_catalog_seq"));
                this.setCatalogCreationBy(geaersetCatalogData.getString("created_by"));
                this.setCatalogCreationDate(geaersetCatalogData.getString("creation_date"));
                this.setCatalogEndDateModifiedBy(geaersetCatalogData.getString("end_date_modified_by"));
                this.setCatalogEndDateModifiedDate(geaersetCatalogData.getString("end_date_modified_date"));
				strActive = geaersetCatalogData.getString("active");				
				if ("true".equalsIgnoreCase(strActive))
				{
					this.setActive(true);
				}
				else
				{
					this.setActive(false);
				}
				this.setCatalogType("D");
				if (this.getEngineModel() == null)
				{
					this.setEngineModel(new eCRDEngineModel());
				}
				this.getEngineModel().setEngineModelCode(geaersetCatalogData.getString("eng_mod_cd"));
				this.getEngineModel().setEngineModelDesc(geaersetCatalogData.getString("eng_mod_desc"));
				
				
			}
		}
		finally
		{
			strActionId = null;
			arrlstInParam = null;
			arrlstOutParam = null;
			geaersetCatalogData = null;
			strActive = "";
		}
	}

	public eCRDDefaultCatalog()
	{

	}

	public eCRDDefaultCatalog(String strEngModelCode,String strConstant) throws Exception
	{
		String strCatalogSeqCode = null;
		String strActionId = null;
		String strActive = null;

		ArrayList arrlstInParam = null;
		ArrayList arrlstOutParam = null;

		GEAEResultSet geaersetCatalogData = null;

		System.out.println("eCRDDefaultCatalog Test 1");
		
		try
		{
			strCatalogSeqCode=eCRDCatalog.getCurrentDefaultSeqId(strEngModelCode);
			strActionId = eCRDConstants.getActionId("eCRD_GET_DEFAULT_CATALOG");
			arrlstInParam = new ArrayList();
			arrlstInParam.add(strCatalogSeqCode);
			arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInParam);
			geaersetCatalogData = (GEAEResultSet) arrlstOutParam.get(0);

			if (geaersetCatalogData != null && geaersetCatalogData.size() > 0)
			{
				geaersetCatalogData.next();
				this.setCatalogSeqId(strCatalogSeqCode);
				this.setCatalogDesc(geaersetCatalogData.getString("catalog_desc"));
				
				//this.setCatInd(geaersetCatalogData.getString("cat_ind"));  //changes by vikrant
				
				System.out.println("Test 1");
				
				this.setCatalogEndDate(geaersetCatalogData.getString("end_date"));
				this.setCatalogStartDate(geaersetCatalogData.getString("start_date"));
				this.setCopiedCatalogSeq(geaersetCatalogData.getString("copied_catalog_seq"));
				strActive = geaersetCatalogData.getString("active");
				if ("true".equalsIgnoreCase(strActive))
				{
					this.setActive(true);
				}
				else
				{
					this.setActive(false);
				}
				this.setCatalogType("D");
				if (this.getEngineModel() == null)
				{
					this.setEngineModel(new eCRDEngineModel());
				}
				this.getEngineModel().setEngineModelCode(geaersetCatalogData.getString("eng_mod_cd"));
				this.getEngineModel().setEngineModelDesc(geaersetCatalogData.getString("eng_mod_desc"));
			}

						
		}
		finally
		{		
			strCatalogSeqCode = null;
			strActionId = null;
			arrlstInParam = null;
			arrlstOutParam = null;
			geaersetCatalogData = null;
			strActive = null;			
		}

	}
	/**
	 * Stores the catalog details to the database
	 */
	public boolean create(String strUserId) throws Exception
	{
		ArrayList arrlstInParam = null;
		ArrayList arrlstOutParam = null;

		String strActionId = null;
		String strAlertCd = null;
		boolean blnCatalogCreated = false;
		try
		{
			arrlstInParam = new ArrayList();

			arrlstInParam.add(getEngineModel().getEngineModelCode());
			arrlstInParam.add(getEngineModel().getEngineModelDesc());
			arrlstInParam.add(getStartDate());
			arrlstInParam.add(getEndDate());
			arrlstInParam.add(getCatalogDesc());
			
			arrlstInParam.add(getCatInd());  //changes by vikrant
			
			arrlstInParam.add(strUserId);
			arrlstInParam.add(eCRDUtil.verifyNull(getVisibleToCWC()));

			strActionId = eCRDConstants.getActionId("eCRD_CREATE_BLANK_CATALOG");
			arrlstOutParam = (ArrayList) eCRDDBMediator.doDBOperation(strActionId, arrlstInParam);

			strAlertCd = eCRDUtil.verifyNull((String) arrlstOutParam.get(1));
			if ("".equals(strAlertCd))
			{
				setCatalogSeqId((String) arrlstOutParam.get(0));
				this.setCatalogType("D");
				blnCatalogCreated = true;
			}
			else
			{
				blnCatalogCreated = false;
			}
			return blnCatalogCreated;
		}
		finally
		{
			arrlstInParam = null;
			arrlstOutParam = null;
			strActionId = null;
			strAlertCd = null;
		}
	}

	/**
	 * Updates the catalog and its dependent entities details to the database.
	 */
	public boolean save(String strUserId) throws Exception
	{
		ArrayList arrlstInParam = null;
		ArrayList arrlstOutParam = null;
		eCRDEngineModel objeCRDEngineModel = null;
		String strActionId = "";
		String strAlertCd = "";
		boolean blnCatalogSaved = false;
		try
		{
			arrlstInParam = new ArrayList();
			arrlstInParam.add(this.getCatalogSeqId());
			arrlstInParam.add(getStartDate());
			arrlstInParam.add(getEndDate());
			arrlstInParam.add(getCatalogDesc());
			
			arrlstInParam.add(getCatInd());  //changes by vikrant
			
			arrlstInParam.add(strUserId);
			strActionId = eCRDConstants.getActionId("eCRD_SAVE_DEFAULT_CATALOG");
			arrlstOutParam = (ArrayList) eCRDDBMediator.doDBOperation(strActionId, arrlstInParam);
			strAlertCd = eCRDUtil.verifyNull((String) arrlstOutParam.get(1));
			if ("".equals(strAlertCd))
			{
				setCatalogSeqId((String) arrlstOutParam.get(0));
				blnCatalogSaved = true;
			}
			else
			{
				blnCatalogSaved = false;
			}
			return blnCatalogSaved;
		}
		finally
		{
			arrlstInParam = null;
			arrlstOutParam = null;
			strActionId = null;
			strAlertCd = null;
		}

	}

	/**
	 * Copies current catalog and returns reference to the new copied catalog. User 
	 * needs to set engine model, start date end date of this new catalog.
	 * @return ecrd.biz.eCRDCatalog
	 */
	public boolean copyCatalog(eCRDCatalog objCopiedCatalog, String strUserId) throws Exception
	{

		ArrayList arrlstInParam = null;
		ArrayList arrlstOutParam = null;

		String strActionId = "";
		String strAlertCd = "";

		boolean blnIsCatalogCopied = false;

		try
		{
			arrlstInParam = new ArrayList();
			arrlstInParam.add(objCopiedCatalog.getCatalogSeqId());
			arrlstInParam.add(getEngineModel().getEngineModelCode());
			arrlstInParam.add(getEngineModel().getEngineModelDesc());
			arrlstInParam.add(this.getStartDate());
			arrlstInParam.add(this.getEndDate());
			arrlstInParam.add(getCatalogDesc());
			
			arrlstInParam.add(getCatInd());  //changes by vikrant
			
			arrlstInParam.add(strUserId);
			arrlstInParam.add(eCRDUtil.verifyNull(getVisibleToCWC()));
			strActionId = eCRDConstants.getActionId("eCRD_COPY_DEFAULT_CATALOG");
			arrlstOutParam = (ArrayList) eCRDDBMediator.doDBOperation(strActionId, arrlstInParam);
			strAlertCd = eCRDUtil.verifyNull((String) arrlstOutParam.get(1));
			if ("".equals(strAlertCd))
			{
				this.setCatalogSeqId((String) arrlstOutParam.get(0));
				blnIsCatalogCopied = true;
			}
			return blnIsCatalogCopied;

		}
		finally
		{
			arrlstInParam = null;
			arrlstOutParam = null;
			strActionId = null;
			strAlertCd = null;
		}
	}
}
