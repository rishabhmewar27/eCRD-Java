/*
 *  Project     :   eCRD
 *  Program     :   eCRDDownload.java
 *  Author      :   Patni Team
 *  Date        :   October 2004
 *  Security    :   Classified/Unclassified
 *  Restrictions:   GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 *
 *  ****************************************************
 *  *  Copyright(Year) with all rights reserved        *
 *  *          General Electric Company                *
 *  ****************************************************
 *  Description:   This class will download the excel sheet.
 *
 *
 *
 *  Revision Log  (mm/dd/yy initials description)
 *  --------------------------------------------------------
 *  Patni Team    October 07, 2004  sCreated
 *
 */
package ecrd.biz;

import ecrd.common.eCRDDBMediator;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDUtil;
import geae.dao.GEAEResultSet;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import com.lowagie.text.Document;
import com.lowagie.text.Font;
import com.lowagie.text.HeaderFooter;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
public class eCRDDownload
{
	/**
	 * Empty Constructor
	 */
	Font GEInspira12 = null;
	Font GEInspira20B = null;
	Font GEInspira22 = null;
	Font GEInspira11B = null;
	Font GEInspira9B = null;
	Font GEInspira8 = null;
	Font GEInspira8B = null;
	Font GEInspira10 = null;
	Font GEInspira6 = null;
	Font GEInspira16 = null;
	Font GEInspira12G = null;
	Font GEInspira120 = null;
	Font GEInspira20G = null;
	Font GEInspira13 = null;
	Font GEInspira14B = null;
	Font GEInspira4 = null;

	BaseFont bfGEInspRg = null;
	Document document = null;

	public eCRDDownload()
	{

	}

	public ByteArrayOutputStream getPDFReport(HttpServletRequest request) throws Exception
	{
		ByteArrayOutputStream baosPDF = null;
		PdfWriter docWriter = null;
		int numColumns = 0;
		float gutter = 0;
		float fullWidth = 0;
		float columnWidth = 0;
		PdfPTable pdfTable = null;
		PdfPCell cellData = null;
		ArrayList arrlstInParam = null;
		ArrayList arrlstOutParam = null;
		GEAEResultSet rsCatalog = null;
		GEAEResultSet rsChildRepairCatalogs = null;
		String strActionId = null;
		String strCatalogId = null;
		String strEngine = null;
		String strYear = null;
		String strImagePath = null;
		Image GEImage = null;
		Phrase phFooter = null;
		Phrase phFooter1 = null;
		Phrase phFooter2 = null;

        String strRprEffDate= null;

		try
		{
			baosPDF = new ByteArrayOutputStream();
			document = new Document();
			docWriter = PdfWriter.getInstance(document, baosPDF);
			document.setPageSize(PageSize.A4);
			document.setMargins(25, 25, 50, 10);

			setFonts();

			document.open();

			arrlstInParam = new ArrayList();
			arrlstOutParam = new ArrayList();

			strCatalogId = eCRDUtil.verifyNull(request.getParameter("hdnCatalogValue"));
			strEngine = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, "Engine"));
			strActionId = eCRDConstants.getActionId("eCRD_DOWNLOAD_EXCEL");

//Start For Repair Effective Date on 08Nov2005 By Rajiv
            strRprEffDate = eCRDUtil.verifyNull(request.getParameter("hdnRprEffDate"));
//End For Repair Effective Date on 08Nov2005 By Rajiv

			arrlstInParam.add(strCatalogId);
//Start For Repair Effective Date on 08Nov2005 By Rajiv
            arrlstInParam.add(strRprEffDate);
//End For Repair Effective Date on 08Nov2005 By Rajiv

            // Hitting the Database and getting the details for that Catalog.
			arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInParam);
			rsCatalog = (GEAEResultSet) arrlstOutParam.get(0);
			rsChildRepairCatalogs = (GEAEResultSet) arrlstOutParam.get(1);
			strYear = (String)arrlstOutParam.get(2);

			gutter = 0;
			numColumns = 1;
			fullWidth = document.right() - document.left();
			columnWidth = (fullWidth - (numColumns - 1) * gutter) / numColumns;
			pdfTable = new PdfPTable(new float[] {(columnWidth*0.095f),(columnWidth*0.905f)});

			pdfTable.setWidthPercentage(100);

			cellData = new PdfPCell(new Phrase("GE Transportation", GEInspira12G));
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setColspan(2);
			pdfTable.addCell(cellData);
			cellData = null;

			cellData = new PdfPCell(new Phrase("Aircraft Engines", GEInspira12));
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setFixedHeight(20F);
			cellData.setColspan(2);
			pdfTable.addCell(cellData);
			cellData = null;

			cellData = new PdfPCell(new Phrase(strEngine, GEInspira120));
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setFixedHeight(450F);
			cellData.setColspan(2);
			cellData.setVerticalAlignment(cellData.ALIGN_BOTTOM);
			cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
			pdfTable.addCell(cellData);
			cellData = null;

			cellData = new PdfPCell(new Phrase(strYear,GEInspira20G));
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setFixedHeight(30F);
			cellData.setVerticalAlignment(cellData.ALIGN_BOTTOM);
			cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
			pdfTable.addCell(cellData);
			cellData = null;

			cellData = new PdfPCell(new Phrase("Component Repair Directory", GEInspira20B));
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setFixedHeight(30F);
			cellData.setVerticalAlignment(cellData.ALIGN_BOTTOM);
			cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
			pdfTable.addCell(cellData);
			cellData = null;

			cellData = new PdfPCell(new Phrase("Issued: January 1, "+strYear, GEInspira22));
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setColspan(2);
			cellData.setFixedHeight(30F);
			cellData.setVerticalAlignment(cellData.ALIGN_BOTTOM);
			cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
			pdfTable.addCell(cellData);
			cellData = null;

			strImagePath = eCRDUtil.getAFSPath() +eCRDConstants.STRGEIMG;

			GEImage = Image.getInstance(strImagePath);
            GEImage.scaleAbsolute(200,70);
			cellData = new PdfPCell(GEImage);
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setColspan(3);
			cellData.setFixedHeight(200F);
			cellData.setVerticalAlignment(cellData.ALIGN_BOTTOM);
			cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
			pdfTable.addCell(cellData);
			cellData = null;

			document.add(pdfTable);
			/* code written for module-wise page numbering - STARTS */
			document.setPageCount(0);
			/* code written for module-wise page numbering - ENDS */
			document.setMargins(25, 25, 50, 10);
			loadDetails(document,rsCatalog,rsChildRepairCatalogs,strEngine,strYear);
			return baosPDF;
		}
		finally
		{
		}
	}

	private void setFonts() throws Exception
	{
		try
		{
			bfGEInspRg = BaseFont.createFont(eCRDUtil.getAFSPath() + eCRDConstants.STRCTRL + eCRDConstants.STRGEINSPRAFONT,  BaseFont.CP1252,BaseFont.EMBEDDED);

			GEInspira12 = new Font(bfGEInspRg,12,0,new Color(0,0,0));
			GEInspira13 = new Font(bfGEInspRg,13,0,new Color(0,0,0));
			GEInspira20B = new Font(bfGEInspRg,20,Font.BOLD);
			GEInspira14B = new Font(bfGEInspRg,14,Font.BOLD);
			GEInspira22 = new Font(bfGEInspRg,22);
			GEInspira11B = new Font(bfGEInspRg,11,Font.BOLD);
			GEInspira10 = new Font(bfGEInspRg,10);
			GEInspira9B = new Font(bfGEInspRg,9,Font.BOLD,new Color(255,255,255));
			GEInspira8 = new Font(bfGEInspRg,8,0,new Color(0,0,0));
			GEInspira6 = new Font(bfGEInspRg,7,0,new Color(0,0,0));
			GEInspira8B = new Font(bfGEInspRg,9,Font.BOLD,new Color(0,0,0));
			GEInspira16 = new Font(bfGEInspRg,16,0,new Color(0,0,0));
			GEInspira12G = new Font(bfGEInspRg, 12, 0, new Color(192,192,192));
			GEInspira120 = new Font(bfGEInspRg,120,0,new Color(0,0,0));
			GEInspira20G = new Font(bfGEInspRg, 20, 0, new Color(192,192,192));
			GEInspira4 = new Font(bfGEInspRg,4);
		}
		finally
		{
		}
	}

	public void loadDetails(Document document,GEAEResultSet rsCatalog,GEAEResultSet rsChildRepairCatalogs,String strEngine, String strYear) throws Exception
	{
		int intColumnIndex = 0;
		int intColumnCount = 0;
		int intPart = 0;
		int intModules = 1;
		int intSite = 0;
		int numColumns = 0;
		String strPrevModule = "";
		String strPrevComponentCode = "";
		String strComponentCode = null;
		String strRepairComments = null;
		String strRepairType = null;
		String strRepairId = null;
		String strModule = null;
		ArrayList arrlstParts = null;
		ArrayList arrlstSites = null;
		boolean blnFlag = false;
		PdfPTable pdfTableData = null;
		PdfPTable pdfInnerTable = null;
		PdfPCell cellData = null;
		Phrase phTAT = null;
		Phrase phComment = null;
		Phrase phComplete = null;
		float gutter = 0;
		float fullWidth = 0;
		float columnWidth = 0;
		float columnDataWidth = 0;
		float innerColumnWidth = 0;
		HeaderFooter footer = null;

		try
		{
			intColumnIndex = 0;
			intColumnCount = rsCatalog.getColumnCount();
			gutter = 0;
			numColumns = 1;
			fullWidth = document.right() - document.left();
			columnWidth = (fullWidth - (numColumns - 1) * gutter) / numColumns;
			columnDataWidth = (columnWidth-20f)/7f;
			innerColumnWidth = (columnWidth - (2f*columnDataWidth-38f)+10);
			arrlstParts = new ArrayList();
			arrlstSites = new ArrayList();
			pdfTableData = new PdfPTable(new float[]{columnDataWidth-18,columnDataWidth-15,columnDataWidth*0.7f,columnDataWidth*0.8f,(columnDataWidth*2.4f)+33f,columnDataWidth*0.5f,columnDataWidth*0.6f+10});
			pdfTableData.setWidthPercentage(100);
			pdfTableData.setHeaderRows(5);
			while (rsCatalog.next())
			{
				strModule = rsCatalog.getString(1);
				if (!(strPrevModule.equals(strModule))) // Check to identify whetherto create a New Sheet or Not.
				{
					intColumnIndex = 0;

					/*
					 * Checking if there are any More Parts or Sites that have to be Displayed f
					 * for the previous Module before creating a new Module sheet.
					 */
			 		insertRemainingPartSiteDetails(pdfTableData,arrlstParts,arrlstSites,intColumnCount);
			 		document.add(pdfTableData);

					/* code written for module-wise page numbering - STARTS */
					if(intModules>0)
					{
						document.resetPageCount();
						document.resetFooter();
						footer = new HeaderFooter(new Phrase( "GE Proprietary. Prior" +
									" to any repairs, all parts will be inspected per the 5/M as required," +
									" unless otherwise noted.\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
									"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
									"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"+(intModules)+".",GEInspira8), true);
						footer.setBorder(Rectangle.NO_BORDER);
						document.setFooter(footer);
						document.newPage();
					}

					/* code written for module-wise page numbering - ENDS */
					pdfTableData = null;
					pdfTableData = new PdfPTable(new float[]{columnDataWidth-18,
															columnDataWidth-16,
															columnDataWidth*0.7f,
															columnDataWidth*0.8f-1,
															(columnDataWidth*2.4f)+35f,
															columnDataWidth*0.5f,
															columnDataWidth*0.6f+10});
					pdfInnerTable = new PdfPTable(new float[]{innerColumnWidth,innerColumnWidth});
					pdfTableData.setWidthPercentage(100);
					pdfTableData.setHeaderRows(5);
					arrlstSites = null;
					arrlstParts = null;

					cellData = new PdfPCell(new Phrase("GE Transportation",GEInspira12));
					cellData.setBorder(Rectangle.NO_BORDER);
					cellData.setColspan(3);
					cellData.setVerticalAlignment(cellData.ALIGN_TOP);
					cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
					pdfTableData.addCell(cellData);
					cellData = null;
					/*
					 * Start of Data to Be Displayed in the First Row of Every Sheet.
					 */

					cellData = new PdfPCell(new Phrase(strEngine,GEInspira14B));
					cellData.setBorder(Rectangle.NO_BORDER);
					cellData.setVerticalAlignment(cellData.ALIGN_BOTTOM);
					cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
					pdfInnerTable.addCell(cellData);
					cellData = null;

					cellData = new PdfPCell(new Phrase(strModule + " Module" ,GEInspira11B));
					cellData.setBorder(Rectangle.NO_BORDER);
					cellData.setVerticalAlignment(cellData.ALIGN_BOTTOM);
					cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
					pdfInnerTable.addCell(cellData);
					cellData = null;

					cellData = new PdfPCell(pdfInnerTable);
					cellData.setBorder(Rectangle.NO_BORDER);
					cellData.setColspan(6);
					cellData.setVerticalAlignment(cellData.ALIGN_BOTTOM);
					cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
					pdfTableData.addCell(cellData);
					cellData = null;

					cellData = new PdfPCell(new Phrase("Aircraft Engines",GEInspira13));
					cellData.setBorder(Rectangle.NO_BORDER);
					cellData.setColspan(3);
					cellData.setVerticalAlignment(cellData.ALIGN_TOP);
					cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
					pdfTableData.addCell(cellData);
					cellData = null;

					pdfInnerTable = null;
					pdfInnerTable = new PdfPTable(new float[]{innerColumnWidth,innerColumnWidth});
					cellData = new PdfPCell(new Phrase("",GEInspira6));
					cellData.setBorder(Rectangle.NO_BORDER);
					cellData.setVerticalAlignment(cellData.ALIGN_BOTTOM);
					cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
					pdfInnerTable.addCell(cellData);
					cellData = null;

					cellData = new PdfPCell(new Phrase("Section "+intModules ,GEInspira12));
					cellData.setBorder(Rectangle.NO_BORDER);
					cellData.setVerticalAlignment(cellData.ALIGN_BOTTOM);
					cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
					pdfInnerTable.addCell(cellData);
					cellData = null;

					cellData = new PdfPCell(pdfInnerTable);
					cellData.setBorder(Rectangle.NO_BORDER);
					cellData.setColspan(6);
					cellData.setVerticalAlignment(cellData.ALIGN_BOTTOM);
					cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
					pdfTableData.addCell(cellData);
					cellData = null;

					cellData = new PdfPCell(new Phrase("",GEInspira6));
					cellData.setBorder(Rectangle.NO_BORDER);
					cellData.setColspan(3);
					cellData.setVerticalAlignment(cellData.ALIGN_BOTTOM);
					cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
					pdfTableData.addCell(cellData);
					cellData = null;

					pdfInnerTable = null;
					pdfInnerTable = new PdfPTable(new float[]{innerColumnWidth,innerColumnWidth});
					cellData = new PdfPCell(new Phrase(strYear + " Component Repair Directory",GEInspira10));
					cellData.setBorder(Rectangle.NO_BORDER);
					cellData.setVerticalAlignment(cellData.ALIGN_BOTTOM);
					cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
					pdfInnerTable.addCell(cellData);
					cellData = null;

					cellData = new PdfPCell(new Phrase("Issued: January 1, " + strYear,GEInspira6));
					cellData.setBorder(Rectangle.NO_BORDER);
					cellData.setVerticalAlignment(cellData.ALIGN_BOTTOM);
					cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
					pdfInnerTable.addCell(cellData);
					cellData = null;

					cellData = new PdfPCell(pdfInnerTable);
					cellData.setBorder(Rectangle.NO_BORDER);
					cellData.setColspan(6);
					cellData.setVerticalAlignment(cellData.ALIGN_BOTTOM);
					cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
					pdfTableData.addCell(cellData);
					cellData = null;

					insertEmptyRow(pdfTableData,intColumnCount-9);

					/*
					 * End of the Data to be Displayed in the First Row.
					 */
					/*
					 * Loop to Display the Headings of the Data to be Displayed.
					 */
					for (intColumnIndex = 0; intColumnIndex <= intColumnCount - 9; intColumnIndex++)
					{
						if(intColumnIndex ==1)
						{
							cellData = new PdfPCell(new Phrase(eCRDUtil.replaceString(rsCatalog.getColumnHeading(intColumnIndex+2),"/","/ "),GEInspira9B));
						}
						else if(intColumnIndex == 2)
						{
							cellData = new PdfPCell(new Phrase(eCRDUtil.replaceString(rsCatalog.getColumnHeading(intColumnIndex+2)," ","            "),GEInspira9B));
						}
						else
						{
							cellData = new PdfPCell(new Phrase(rsCatalog.getColumnHeading(intColumnIndex+2),GEInspira9B));
						}
						cellData.setBorder(Rectangle.NO_BORDER);
						cellData.setBorderColor( new Color(0,255,0));
						cellData.setBackgroundColor(new Color(0,0,0));
						cellData.setVerticalAlignment(cellData.ALIGN_TOP);
						cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
						pdfTableData.addCell(cellData);
						cellData = null;
					}
					intModules++;
				}

				strPrevModule = strModule;
				strComponentCode = rsCatalog.getString(2);

				// Inserting a blank row btwn the Header and the actual Data.
				if (!strPrevComponentCode.equals(strComponentCode))
				{
					insertEmptyRow(pdfTableData,intColumnCount-9);
					arrlstSites = null;
					arrlstParts = null;
				}
				/*
				 * Start of Displaying Actual Data.
				 */
				strRepairType = rsCatalog.getString(11);
				for (intColumnIndex = 0; intColumnIndex <= intColumnCount - 9; intColumnIndex++)
				{
					if (!(strPrevComponentCode).equals(strComponentCode))
					{
							//Inserting the component details
						/*
						 * Checking if there are any part or Sites left to be displayed for previous component.
						 * when the new component has come for display
						 * Checking only for the 1st column.
						 */
						if(intColumnIndex == 0)
						{
							insertRemainingPartSiteDetails(pdfTableData,arrlstParts,arrlstSites,intColumnCount);
						}
						/*
						 * Start of Display of Component releated Details.
						 */
						if (intColumnIndex < 4)
						{
							/*
							 * Checking if it is 1st column to be displayed then creating the ArrayList of Parts for tht component.
							 * If it is 3rd Column to be Displayed then creating the Arraylist of sites.
							 * else Displaying the Component Details.
							 */
							if(intColumnIndex == 1)
							{
								cellData = new PdfPCell(new Phrase(rsCatalog.getString(intColumnIndex + 2),GEInspira8B));
								cellData.setBorder(Rectangle.NO_BORDER);
								cellData.setVerticalAlignment(cellData.ALIGN_TOP);
								cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
								pdfTableData.addCell(cellData);
								cellData = null;
								arrlstParts = new ArrayList();
								arrlstParts = eCRDUtil.convertStringToArrayList((String)rsCatalog.getString(9),",");
							}
							else if(intColumnIndex == 2)
							{
								arrlstSites = new ArrayList();
								arrlstSites = eCRDUtil.convertStringToArrayList((String)rsCatalog.getString(4),",");
								intSite = arrlstSites.size();
								if(intSite > 0)
								{
									cellData = new PdfPCell(new Phrase((String)arrlstSites.get(intSite-1),GEInspira8B));
									arrlstSites.remove(intSite-1);
								}
								else
								{
									cellData = new PdfPCell(new Phrase("",GEInspira8B));
								}
								cellData.setBorder(Rectangle.NO_BORDER);
								cellData.setVerticalAlignment(cellData.ALIGN_TOP);
								cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
								pdfTableData.addCell(cellData);
								cellData = null;
							}
							else
							{
								if(intColumnIndex == 3)
								{
									cellData = new PdfPCell(new Phrase(rsCatalog.getString(intColumnIndex + 2),GEInspira8B));
									cellData.setBorder(Rectangle.NO_BORDER);
									cellData.setVerticalAlignment(cellData.ALIGN_TOP);
									cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
									pdfTableData.addCell(cellData);
									cellData = null;

									cellData = new PdfPCell(new Phrase("",GEInspira8B));
									cellData.setBorder(Rectangle.NO_BORDER);
									cellData.setVerticalAlignment(cellData.ALIGN_TOP);
									cellData.setHorizontalAlignment(cellData.ALIGN_RIGHT);
									pdfTableData.addCell(cellData);
									cellData = null;

									if(!"".equals(rsCatalog.getString(15)))
									{
										phTAT = new Phrase(rsCatalog.getString(15),GEInspira8B);
										phComment = new Phrase(" (CONTRACT TAT)",GEInspira4);
										phComplete = new Phrase();
										phComplete.add(phTAT);
										phComplete.add(phComment);
									}
									else
									{
										phComplete = new Phrase("");
									}
									cellData = new PdfPCell(phComplete);
									cellData.setBorder(Rectangle.NO_BORDER);
									cellData.setVerticalAlignment(cellData.ALIGN_TOP);
									cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
									pdfTableData.addCell(cellData);
									cellData = null;
								}
								else if(intColumnIndex == 0)
								{
									cellData = new PdfPCell(new Phrase(rsCatalog.getString(intColumnIndex + 2),GEInspira8B));
									cellData.setBorder(Rectangle.NO_BORDER);
									cellData.setVerticalAlignment(cellData.ALIGN_TOP);
									cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
									pdfTableData.addCell(cellData);
									cellData = null;
								}
							}
						}
						/*
						 * Start of 1st Repair Data for the Current Component
						 */
						else // inserting Repair Details in next row.
						{
							/*
							 * Identifies if we need to create a new repair row.
							 * If So then check if we need to display and Part/Site Information for the current component.
							 * If So then Display it
							 * Else Display the Repair Data.
							 */
							if (!blnFlag)
							{
								for(int intEmptyCell = 0; intEmptyCell <1;intEmptyCell++)
								{
									cellData = new PdfPCell(new Phrase(""));
									cellData.setBorder(Rectangle.NO_BORDER);
									pdfTableData.addCell(cellData);
								}
								for(int intEmptyCell = 0; intEmptyCell < 4; intEmptyCell++)
								{
									/*
									 * Start of Displaying the Site/Part Data for Current Component
									 */
									intSite = arrlstSites.size();
									if(intEmptyCell == 1)
									{
										arrlstParts = eCRDUtil.convertStringToArrayList((String)rsCatalog.getString(9),",");
										intPart = arrlstParts.size();
										if(intPart > 0)
										{
											cellData = new PdfPCell(new Phrase((String)arrlstParts.get(intPart-1),GEInspira8));
											arrlstParts.remove(intPart-1);
										}
										else
										{
											cellData = new PdfPCell(new Phrase("",GEInspira8));
										}
										cellData.setBorder(Rectangle.NO_BORDER);
										cellData.setVerticalAlignment(cellData.ALIGN_TOP);
										cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
										pdfTableData.addCell(cellData);
										cellData = null;
									}
									else if(intEmptyCell == 2)
									{
										if(intSite > 0)
										{
											cellData = new PdfPCell(new Phrase((String)arrlstSites.get(intSite-1),GEInspira8));
											arrlstSites.remove(intSite-1);
										}
										else
										{
											cellData = new PdfPCell(new Phrase("",GEInspira8));
										}
										cellData.setBorder(Rectangle.NO_BORDER);
										cellData.setVerticalAlignment(cellData.ALIGN_TOP);
										cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
										pdfTableData.addCell(cellData);
										cellData = null;
									}
									/*
									 * End of Code for Displaying Site/Part Information
									 */
									else if(intEmptyCell == 0)
									{
										cellData = new PdfPCell(new Phrase("",GEInspira8));
										cellData.setBorder(Rectangle.NO_BORDER);
										cellData.setVerticalAlignment(cellData.ALIGN_TOP);
										cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
										pdfTableData.addCell(cellData);
										cellData = null;
									}
									// Display the Repair Display Seq Id
									else
									{
										cellData = new PdfPCell(new Phrase(rsCatalog.getString(10),GEInspira8));
										cellData.setBorder(Rectangle.NO_BORDER);
										cellData.setVerticalAlignment(cellData.ALIGN_TOP);
										cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
										pdfTableData.addCell(cellData);
										cellData = null;
									}
									blnFlag = true;
								}
							}
							cellData = new PdfPCell(new Phrase(rsCatalog.getString(intColumnIndex+2),GEInspira8));
							cellData.setBorder(Rectangle.NO_BORDER);
							cellData.setVerticalAlignment(cellData.ALIGN_TOP);
							cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
							pdfTableData.addCell(cellData);
							cellData = null;
							/*
							 * Start of Code for Display of Repair Comments if Present
							 */
							if(intColumnIndex == (intColumnCount-9))
							{
								strRepairComments = eCRDUtil.verifyNull(rsCatalog.getString(13));
								if(!"".equals(strRepairComments))
								{
									insertRepairComments(pdfTableData,intColumnCount,strRepairComments,arrlstParts,arrlstSites);
								}
							}
							/*
							 * End Of Code for Display of Repair Comments.
							 */
						}// End of Code for Display of Repair.
					}//End of Code for Display of Component Details
					/*
					 * Start of Code for Display of Data for Repair present in the Component
					 */
					else // Data for Repair of the same component
					{
						/*
						 * Start of Code for Display of Following Things.
						 * 1) Part if any left for the Component
						 * 2) Sites if any left for the Component
						 * 3) Repair Display Seq Id For the current Repair.
						 */
						if (intColumnIndex < 4)
						{
							if (intColumnIndex == 1)
							{
								intPart = arrlstParts.size();
								if(intPart > 0)
								{
									cellData = new PdfPCell(new Phrase((String)arrlstParts.get(intPart-1),GEInspira8));
									arrlstParts.remove(intPart-1);
								}
								else
								{
									cellData = new PdfPCell(new Phrase("",GEInspira8));
								}
							}
							else if (intColumnIndex == 2)
							{
								intSite = arrlstSites.size();
								if(intSite > 0)
								{
									cellData = new PdfPCell(new Phrase((String)arrlstSites.get(intSite-1),GEInspira8));
									arrlstSites.remove(intSite-1);
								}
								else
								{
									cellData = new PdfPCell(new Phrase("",GEInspira8));
								}
							}
							else if (intColumnIndex == 3)
							{
								cellData = new PdfPCell(new Phrase(rsCatalog.getString(intColumnIndex+7),GEInspira8));
							}
							else
							{
								cellData = new PdfPCell(new Phrase("",GEInspira8));
							}
							cellData.setBorder(Rectangle.NO_BORDER);
							cellData.setVerticalAlignment(cellData.ALIGN_TOP);
							cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
							pdfTableData.addCell(cellData);
							cellData = null;
						}
						/*
						 * End of Code for display of Sites/Parts/Display Seq.
						 * Start of Code for Display of Other Repair Details.
						 */
						else
						{
							cellData = new PdfPCell(new Phrase(rsCatalog.getString(intColumnIndex + 2),GEInspira8));
							cellData.setBorder(Rectangle.NO_BORDER);
							cellData.setVerticalAlignment(cellData.ALIGN_TOP);
							cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
							pdfTableData.addCell(cellData);
							cellData = null;
							/*
							 * Start of Code for Display of Repair Comments if Available
							 */
							if(intColumnIndex == (intColumnCount-9))
							{
								strRepairComments = eCRDUtil.verifyNull(rsCatalog.getString(13));
								if(!"".equals(strRepairComments))
								{
									insertRepairComments(pdfTableData,intColumnCount,strRepairComments,arrlstParts,arrlstSites);
								}
							}/*
							  * End of Code for Display of Repair Comments
							  */
						}/*
						  * End of Code for Display of Repari Details
						  */
					}/*
					  * End of Code for Display of Repair for the Same Component
					  */
				}/*
				  * End of the For Loop for the Display of Actual Data
				  */
				if(eCRDConstants.STRGROUPREPAIR.equals(strRepairType))
				{
					strRepairId = rsCatalog.getString(14);
					insertChildRepairsData(pdfTableData,rsChildRepairCatalogs,arrlstParts,arrlstSites,strRepairId);
				}
				blnFlag = false;
				strPrevComponentCode = rsCatalog.getString(2);
			}
			insertRemainingPartSiteDetails(pdfTableData,arrlstParts,arrlstSites,intColumnCount);
			document.add(pdfTableData);
			document.close();
		}
		finally
		{
			intColumnIndex = 0;
			intColumnCount = 0;
			intPart = 0;
			intModules = 0;
			intSite = 0;
			numColumns = 0;
			strPrevModule = "";
			strPrevComponentCode = "";
			strComponentCode = null;
			strRepairComments = null;
			strRepairType = null;
			strRepairId = null;
			strModule = null;
			arrlstParts = null;
			arrlstSites = null;
			blnFlag = false;
			pdfTableData = null;
			cellData = null;
			gutter = 0;
			fullWidth = 0;
			columnWidth = 0;
			columnDataWidth = 0;
		}
	}

	private void insertChildRepairsData(PdfPTable pdfTableData,GEAEResultSet rsChildRepairs,ArrayList arrlstParts, ArrayList arrlstSites,String strRepairId) throws Exception
	{
		int intColumnIndex = 0;
		int intPart = 0;
		int intSite = 0;
		int intColumnCount =0;
		PdfPCell cellData;
		String strRepairComments = null;
		String strParentRepairId = null;
		try
		{
			intColumnCount = rsChildRepairs.getColumnCount();
			/*
			 * Start of Code for Display of Following Things.
			 * 1) Part if any left for the Component
			 * 2) Sites if any left for the Component
			 * 3) Repair Display Seq Id For the current Repair.
			 */

			rsChildRepairs.setCurrentRow(0);
			while(rsChildRepairs.next())
			{
				strParentRepairId = rsChildRepairs.getString(12);
				if(strRepairId.equals(strParentRepairId))
				{
					for(intColumnIndex = 0; intColumnIndex <= intColumnCount -9; intColumnIndex ++)
					{
						if (intColumnIndex < 4)
						{
							if (intColumnIndex == 1)
							{
								intPart = arrlstParts.size();
								if(intPart > 0)
								{
									cellData = new PdfPCell(new Phrase((String)arrlstParts.get(intPart-1),GEInspira8));
									arrlstParts.remove(intPart-1);
								}
								else
								{
									cellData = new PdfPCell(new Phrase("",GEInspira8));
								}
							}
							else if (intColumnIndex == 2)
							{
								intSite = arrlstSites.size();
								if(intSite > 0)
								{
									cellData = new PdfPCell(new Phrase((String)arrlstSites.get(intSite-1),GEInspira8));
									arrlstSites.remove(intSite-1);
								}
								else
								{
									cellData = new PdfPCell(new Phrase("",GEInspira8));
								}
							}
							else if (intColumnIndex == 3)
							{
								cellData = new PdfPCell(new Phrase(rsChildRepairs.getString(intColumnIndex + 7),GEInspira8));
							}
							else
							{
								cellData = new PdfPCell(new Phrase("",GEInspira8));
							}
							cellData.setBorder(Rectangle.NO_BORDER);
							cellData.setVerticalAlignment(cellData.ALIGN_TOP);
							cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
							pdfTableData.addCell(cellData);
							//document.add(pdfTableData);
							cellData = null;
						}
						/*
						 * End of Code for display of Sites/Parts/Display Seq.
						 * Start of Code for Display of Other Repair Details.
						 */
						else
						{
							cellData = new PdfPCell(new Phrase(rsChildRepairs.getString(intColumnIndex + 2),GEInspira8));
							cellData.setBorder(Rectangle.NO_BORDER);
							cellData.setVerticalAlignment(cellData.ALIGN_TOP);
							cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
							pdfTableData.addCell(cellData);
							cellData = null;
							/*
							 * Start of Code for Display of Repair Comments if Available
							 */
							if(intColumnIndex == (intColumnCount-9))
							{
								strRepairComments = eCRDUtil.verifyNull(rsChildRepairs.getString(13));
								if(!"".equals(strRepairComments))
								{
									insertRepairComments(pdfTableData,intColumnCount,strRepairComments,arrlstParts,arrlstSites);
								}
							}
						}
					}
				}
			}
		}
		finally
		{
			intColumnIndex = 0;
			intPart = 0;
			intSite = 0;
			strRepairComments = null;
			intColumnCount =0;
			strParentRepairId = null;
		}
	}

	private void insertEmptyRow(PdfPTable pdfTableData,int endCell) throws Exception
	{
		PdfPCell cellData;
		int inti = 0;
		try
		{
			for (inti = 0; inti <= endCell; inti++)
			{
				cellData = new PdfPCell(new Phrase("",GEInspira8));
				cellData.setBorder(Rectangle.BOTTOM);
				cellData.setFixedHeight(10f);
				cellData.setVerticalAlignment(cellData.ALIGN_BOTTOM);
				cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
				pdfTableData.addCell(cellData);
				cellData = null;
			}
		}
		finally
		{
			cellData = null;
			inti = 0;
		}
	}

	private void insertRepairComments(PdfPTable pdfTableData,int intColumnCount,String strRepairComments,ArrayList arrlstParts,ArrayList arrlstSites) throws Exception
	{
		PdfPCell cellData = null;
		int intPart = 0;
		int intSite = 0;
		try
		{
			for(int intEmptyCell =0;intEmptyCell<=intColumnCount-9;intEmptyCell++)
			{
				if(intEmptyCell == 1)
				{
					intPart = arrlstParts.size();
					if(intPart > 0)
					{
						cellData = new PdfPCell(new Phrase((String)arrlstParts.get(intPart-1),GEInspira8));
						arrlstParts.remove(intPart-1);
					}
					else
					{
						cellData = new PdfPCell(new Phrase("",GEInspira8));
					}
				}
				else if(intEmptyCell == 2)
				{
					intSite = arrlstSites.size();
					if(intSite > 0)
					{
						cellData = new PdfPCell(new Phrase((String)arrlstSites.get(intSite-1),GEInspira8));
						arrlstSites.remove(intSite-1);
					}
					else
					{
						cellData = new PdfPCell(new Phrase("",GEInspira8));
					}
				}
				else if(intEmptyCell==4)
				{
					cellData = new PdfPCell(new Phrase(strRepairComments,GEInspira8));
				}
				else
				{
					cellData = new PdfPCell(new Phrase("",GEInspira8));
				}
				cellData.setBorder(Rectangle.NO_BORDER);
				cellData.setVerticalAlignment(cellData.ALIGN_TOP);
				cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
				pdfTableData.addCell(cellData);
				cellData = null;
			}
		}
		finally
		{
			cellData = null;
			intPart = 0;
			intSite = 0;
		}
	}

	private void insertRemainingPartSiteDetails(PdfPTable pdfTableData,ArrayList arrlstParts,ArrayList arrlstSites,int intColumnCount) throws Exception
	{
		int intPart = 0;
		int intSite = 0;
		int intColumn = 0;
		PdfPCell cellData = null;
		try
		{
			if(arrlstParts != null)
			{
				intPart = arrlstParts.size();
			}
			else
			{
				intPart = 0;
			}
			if(arrlstSites != null)
			{
				intSite = arrlstSites.size();
			}
			else
			{
				intSite = 0;
			}
			if(intPart > 0 || intSite > 0)
			{
				//Indentifying whether there are more parts or more sites to be displayed.
				if(intPart > intSite)
				{
					intColumn = intPart;
				}
				else
				{
					intColumn = intSite;
				}
				// Loop to display all the remaining Sites and Parts for the Previous Component
				for(int inti = 0 ; inti < intColumn; inti++)
				{
					for(int intEmptyCell = 0;intEmptyCell <= intColumnCount-9; intEmptyCell++ )
					{
						if(intEmptyCell == 1)
						{
							//creating cell for parts data.
							intPart = arrlstParts.size();
							if(intPart > 0)
							{
								// Displaying the Part Numbers.
								cellData = new PdfPCell(new Phrase((String)arrlstParts.get(intPart-1),GEInspira8));
								arrlstParts.remove(intPart-1);
							}
							else
							{
								// No Value to be displayed in the cell for Part Number.
								cellData = new PdfPCell(new Phrase("",GEInspira8));
							}
						}
						else if(intEmptyCell == 2)
						{
							intSite = arrlstSites.size();
							if(intSite > 0)
							{
								// Displaying the Sites.
								cellData = new PdfPCell(new Phrase((String)arrlstSites.get(intSite-1),GEInspira8));
								// Removing the Sites frm the Site ArrayList.
								arrlstSites.remove(intSite-1);
							}
							else
							{
								// No Value to be Dispalyed in the Cell for Sites.
								cellData = new PdfPCell(new Phrase("",GEInspira8));
							}
						}
						else
						{
							cellData = new PdfPCell(new Phrase("",GEInspira8));
						}
						cellData.setBorder(Rectangle.NO_BORDER);
						cellData.setVerticalAlignment(cellData.ALIGN_BOTTOM);
						cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
						pdfTableData.addCell(cellData);
						cellData = null;
					}
				}
			}
		}
		finally
		{
			intPart = 0;
			intSite = 0;
			intColumn = 0;
			cellData = null;
		}
	}
}
