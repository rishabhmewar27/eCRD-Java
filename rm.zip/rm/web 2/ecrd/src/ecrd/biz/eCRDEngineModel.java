//Source file: D:\\ECRD\\SOURCE CODE\\ecrd\\biz\\eCRDEngineModel.java
/*
* Module    	    : eCRDEngineModule.java
* Author      	    : PATNI-Offshore
* Project	        : eCRD
* Date Written		: October 2004
* Security	        : Unclassified
* Restrictions		: GE PROPRIETARY INFORMATION, FOR GE USE ONLY
*
*     ****************************************************
*     *  Copyright (2000) with all rights reserved       *
*     *          General Electric Company                *
*     ****************************************************
*
* Description: eCRDBusinessBean is used for getting the GEAE Row Cache Tag
*
* Revision Log  (mm/dd/yy initials description)
* --------------------------------------------------------------
*/

package ecrd.biz;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.StringTokenizer;

import ecrd.common.eCRDDBMediator;
import ecrd.exception.eCRDException;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDUtil;
import geae.dao.GEAEResultSet;
/**
 * This entity represents Engine Model
 */
public class eCRDEngineModel implements Serializable
{

	/**
	 * Engine Model Code
	 */
	private String strEngineModelCode = "";
	private String strEngineModelDesc = "";
	private int intDisplayOrder = 0;
	private ArrayList arrlstECRDModule = null;
	private eCRDCatalog objeCRDCatalog = null;
	/**
	 * For loading data related to engine model.
	 * @param strEngineMOdelCode
	 */
	public eCRDEngineModel(String strEngineMOdelCode) throws Exception
	{
		ArrayList arrlstDataInParam = null;
		ArrayList arrlstDataOutParam = null;
		String strActionId = "";
		eCRDException objException = null;
		try
		{ 
			arrlstDataInParam = new ArrayList();
			arrlstDataOutParam = new ArrayList();
			if(strEngineMOdelCode == null || "".equals(strEngineMOdelCode))
			{
				objException = new eCRDException();
			    objException.setExcpId("ENGINE_MODEL_NULL");
			    throw  objException;
			}
			
			arrlstDataInParam.add(strEngineMOdelCode);
			strActionId =
				eCRDUtil.verifyNull(
					(String) eCRDConstants.getActionId("eCRD_GET_MODEL"));
	
			arrlstDataOutParam =
				eCRDDBMediator.doDBOperation(strActionId, arrlstDataInParam);

			this.strEngineModelCode = (String) arrlstDataOutParam.get(1);
			this.strEngineModelDesc = (String) arrlstDataOutParam.get(0);


		}
		finally
		{
			arrlstDataInParam = null;
			arrlstDataOutParam = null;
		}
	}

	/**
	 * Create a Enigne Model. 
	 * Send notification using notification service.
	 */
	public eCRDEngineModel()
	{

	}

	/**
	 * Insert Engine Model in master data.
	 * @param strUserId
	 * @param strUserRole
	 * @return strMessage
	 * throws Exception
	 */
	public String create( String strUserId, String strUserRole) throws Exception
	{
		ArrayList arrlstInData = null;
		ArrayList arrlstOutData = null;
		String strActionId = "";
		String strMessage = "";
		eCRDException objeCRDException = null;
		try
		{
			arrlstInData = new ArrayList();
			arrlstOutData = new ArrayList();
			if(this.strEngineModelCode == null || "".equals(this.strEngineModelCode) 
			|| this.strEngineModelDesc == null || "".equals(this.strEngineModelDesc) || strUserId == null || "".equals(strUserId) || 
			strUserRole == null || "".equals(strUserRole))
			{
				objeCRDException = new eCRDException();
				objeCRDException.setExcpId("SET_PARAMETERS_NULL");
				throw objeCRDException;
			}
			arrlstInData.add(this.strEngineModelCode);
			arrlstInData.add(this.strEngineModelDesc);
			arrlstInData.add(strUserId);
			arrlstInData.add(strUserRole);
			
			strActionId = eCRDConstants.getActionId("eCRD_SAVE_MODEL");
			arrlstOutData = eCRDDBMediator.doDBOperation(strActionId,arrlstInData);
			
			strMessage = (String)arrlstOutData.get(0);
		}
		finally
		{
			arrlstInData = null;
			arrlstOutData = null;
			strActionId = "";
		}
		return strMessage;
	}
	
	/**
	 * Save the Engine Module in database and also updates its relationships with model
	 * @param strUserId
	 * @return String
	 * throws Exception
	 */
	public String saveModule(String strUserId) throws Exception
	{
		eCRDModule objeCRDModule = null;
		ArrayList arrlstinData = null;
		ArrayList arrlstOutData = null;
		String strMessage = "";
		int intarrLstSize = arrlstECRDModule.size();
		String strModuleDesc = "";
		StringBuffer strbufModule = null;
		String strActionid = "";
		GEAEResultSet rsModules = null;
		eCRDException objException = null;
		try
		{
		    arrlstinData = new ArrayList();
		    arrlstOutData = new ArrayList();
		    strbufModule = new StringBuffer();
		    rsModules = new GEAEResultSet();
			if(strUserId == null || "".equals(strUserId))
			{
				objException = new eCRDException();
				objException.setExcpId("USER_ID_NULL");
				throw  objException;
			}
			
			for (int i = 0; i < intarrLstSize; i++)
			{
				objeCRDModule = (eCRDModule) arrlstECRDModule.get(i);
				strbufModule = strbufModule.append(objeCRDModule.getModuleDesc());
				strbufModule = strbufModule.append(eCRDConstants.STRCOLUMNDELIM);
			}
			strbufModule.deleteCharAt(strbufModule.length()-1);
			strbufModule = strbufModule.append(eCRDConstants.STRROWDELIM);
			strModuleDesc = strbufModule.toString();
			
			strActionid = eCRDConstants.getActionId("eCRD_SAVE_MODULE");
			
			arrlstinData.add(strEngineModelCode);
			arrlstinData.add(strModuleDesc);
			arrlstinData.add(strUserId);
			arrlstinData.add(eCRDConstants.STRROWDELIM);
			arrlstinData.add(eCRDConstants.STRCOLUMNDELIM);
	
			/* Db will return me the cursor containing the Module cd and 
			module desc of the selected Engine Model*/
	
			arrlstOutData = eCRDDBMediator.doDBOperation(strActionid, arrlstinData);
			
			rsModules = (GEAEResultSet) arrlstOutData.get(0);
			
			strMessage = eCRDUtil.verifyNull((String) arrlstOutData.get(1));
			this.arrlstECRDModule = null;
			this.arrlstECRDModule = new ArrayList();
			if (rsModules != null && rsModules.size() > 0)
			{
				while (rsModules.next())
				{
					objeCRDModule = new eCRDModule();
					objeCRDModule.setModuleCode(rsModules.getString("Module_Code"));
					objeCRDModule.setModuleDesc(rsModules.getString("Module_Desc"));
					
					arrlstECRDModule.add(objeCRDModule);
				}
			}
			return strMessage;
		}
		finally
		{
			arrlstinData = null;
			arrlstOutData = null;
			rsModules = null;
			strbufModule = null;
		}
	}

	/**
	 * Remove Engine Model from the database and its dependent entities if any.
	 */
	public void remove()
	{

	}

	/**
	 * To add module to the Engine Model
	 * @return objModule
	 */
	public eCRDModule addModule()
	{
		// Creating a new eCRDModule and adding it to ArrayList 
		eCRDModule objeCRDModule = new eCRDModule();
		if (this.arrlstECRDModule == null)
			this.arrlstECRDModule = new ArrayList();
		objeCRDModule.setEngineModel(this);
		this.arrlstECRDModule.add(objeCRDModule);

		return objeCRDModule;
	}

	/**
	 * Remove related module from the collection.
	 * @param strModuleCode
	 * @param strUserId
	 * @return String 
	 * throws Exception
	 */
	public String removeModule(String strModuleCode, String strUserRole)
		throws Exception
	{
		ArrayList arrlstInData = null;
		ArrayList arrlstOutData = null;
		String strActionId = "";
		String strMessage = "";
		//int intArrlistSize = 0;
		eCRDModule objeCRDModule = null;
		eCRDException objException = null;
		String strModuleCodes = "";
		
		try
		{
			arrlstInData = new ArrayList();
			arrlstOutData = new ArrayList();
			
			if(strModuleCode == null || "".equals(strModuleCode) || strUserRole == null || "".equals(strUserRole))
			{
				objException = new eCRDException();
				objException.setExcpId("SET_PARAMETERS_NULL");
				throw  objException;
			}
			strModuleCodes = strModuleCode + eCRDConstants.STRROWDELIM;
			//arrlstInData.add(strEngineModelCode);
			arrlstInData.add(strModuleCodes);
			arrlstInData.add(strUserRole);
			strActionId = eCRDConstants.getActionId("eCRD_REMOVE_MODULE");
			// This procedure will delete the modules and all the associated Components,Repairs etc.
			arrlstOutData = eCRDDBMediator.doDBOperation(strActionId, arrlstInData);
	
			strMessage = (String) arrlstOutData.get(0);
			if("MODULE_REMOVE_SUCCESS".equals(strMessage))
			{
				StringTokenizer strTokens = new StringTokenizer(strModuleCode,eCRDConstants.STRCOLUMNDELIM);
				while(strTokens.hasMoreTokens())
				{
					if(arrlstECRDModule != null)
					{
						for(int inti = 0; inti < arrlstECRDModule.size() ; inti++)
						{
							objeCRDModule = (eCRDModule)arrlstECRDModule.get(inti);
							if(strModuleCode.equals(objeCRDModule.getModuleCode()))
							{
								arrlstECRDModule.remove(inti);
							}
						}
					}
				}
			}
		}
		finally
		{
			arrlstInData = null;
			arrlstOutData = null;
			strActionId = null;
			objeCRDModule = null;
			objException = null;
			strModuleCodes = null;
		}
		return strMessage;
	}

	/**
	 * @param strModuleCode
	 * @param strUserId
	 * @return String
	 * @throws Exception
	 */
	/**
	 * Updates the specified Module.
	 * @param strModuleCode
	 */
	public String updateModule(String strModuleCode, String strModuleDesc, String strUserId)
		throws Exception
	{
		ArrayList arrlstInData = null;
		ArrayList arrlstOutData = null;
		String strActionId = "";
		String strMessage = "";
		eCRDException objException = null;
		try
		{
			arrlstInData = new ArrayList();
			arrlstOutData = new ArrayList();
			if(strUserId == null || "".equals(strUserId) || strModuleCode == null || "".equals(strModuleCode) || 
			strModuleDesc == null || "".equals(strModuleDesc))
			{
				objException = new eCRDException();
				objException.setExcpId("SET_PARAMETERS_NULL");
				throw  objException;
			}
			//arrlstInData.add(strEngineModelCode);
			arrlstInData.add(strModuleCode);
			arrlstInData.add(strModuleDesc);
			arrlstInData.add(strUserId);
			strActionId = eCRDConstants.getActionId("eCRD_UPDATE_MODULE");
			
			arrlstOutData = eCRDDBMediator.doDBOperation(strActionId, arrlstInData);
	
			strMessage = (String) arrlstOutData.get(0);
			
		}
		finally
		{
			arrlstInData = null;
			arrlstOutData = null;
			strActionId = null;
			objException = null;
		}
		return strMessage;
	}

	/**
	 * Returns fully loaded Module object. 
	 * If the object is not in ArrayList call constructor with parameters and load the 
	 * object and add it to the ArrayList.
	 * @param strModuleCd
	 * @return ecrd.biz.eCRDModule
	 * throws Exception
	 */
    public eCRDModule getModule(String strModuleCd) throws Exception 
    {
	   eCRDModule objeCRDModule = null;
	   int intComponent = 0;
       boolean blnFound = false;
	   eCRDException objException = null;
	   try
	   {
		   if(strModuleCd == null || "".equals(strModuleCd))
		   {
			   objException = new eCRDException();
			   objException.setExcpId("MODULE_CODE_NULL");
			   throw  objException;
		   }
		   if(this.arrlstECRDModule != null)
		   {
		   	   intComponent=this.arrlstECRDModule.size(); 	
			   for (int i = 0; i < intComponent; i++)
			   {
				   objeCRDModule = (eCRDModule)arrlstECRDModule.get(i);
				   if(strModuleCd.equals(objeCRDModule.getModuleCode()))
				   {

						//arrlstECRDModule.add(objeCRDModule);
						blnFound = true;
						break;
				   }
			   }	
		   }
		   else
		   {
		   	   this.arrlstECRDModule = new ArrayList();
		   }
		   if(!blnFound)
		   {
			  objeCRDModule = new eCRDModule(strModuleCd);

			  objeCRDModule.setEngineModel(this);
		   	  arrlstECRDModule.add(objeCRDModule);
		   }
	   }
	   finally
	   {
		  intComponent = 0;
		  blnFound = false;
		  objException = null;
	   }
	   return objeCRDModule;
    }
	/**
	 * Sets the Engine Model Code.
	 * @param strEngineModelCode.
	 */
	public void setEngineModelCode(String strEngineModelCode)
	{
		this.strEngineModelCode = strEngineModelCode;
	}

	/**
	 * Gets the Engine Model Code.
	 * @return strEngineModelCode
	 */
	public String getEngineModelCode()
	{
		return strEngineModelCode;
	}

	/**
	 * Gets the Engine Model Desc.
	 * @return strEngineModelDesc
	 */
	public String getEngineModelDesc()
	{
		return strEngineModelDesc;
	}

	/**
	 * Gets the Customer Catalog Object.
	 * @return eCRDCustomerCatalog
	 */
	public int getDisplayOrder()
	{
		return intDisplayOrder;
	}

	/**
	 * Returns the list of module object in a ArrayList form.
	 * @return ArrayList
	 
	public ArrayList getModuleList()
	{
		return null;
	}*/

	/**
	 * Sets the Engine Module Description.
	 * @param strEngineModelDesc
	 */
	public void setEngineModelDesc(String strEngineModelDesc)
	{
		this.strEngineModelDesc = strEngineModelDesc;
	}

	/**
	 * Sets the Display Order.
	 * @param intDisplayOrder
	 */
	public void setDisplayOrder(int intDisplayOrder)
	{
		this.intDisplayOrder = intDisplayOrder;
	}

	/**
	 * Gets the Catalog Object.
	 * @return eCRDCatalog
	 */
	public eCRDCatalog getCatalog()
	{
		return this.objeCRDCatalog;
	}

	/**
	 * Sets the Catalog Object.
	 * @param objeCRDCatalog.
	 */
	public void setCatalog(eCRDCatalog objeCRDCatalog)
	{
		this.objeCRDCatalog= objeCRDCatalog;
	}

}
