//Source file: D:\\ECRD\\SOURCE CODE\\ecrd\\biz\\eCRDEscalation.java
/*
* Module    	    : eCRDEscalation.java
* Author      	    : PATNI-Offshore
* Project	        : eCRD
* Date Written		: October 2004
* Security	        : Unclassified
* Restrictions		: GE PROPRIETARY INFORMATION, FOR GE USE ONLY
*
*     ****************************************************
*     *  Copyright (2000) with all rights reserved       *
*     *          General Electric Company                *
*     ****************************************************
*
* Description: eCRDBusinessBean is used for getting the GEAE Row Cache Tag
*
* Revision Log  (mm/dd/yy initials description)
* --------------------------------------------------------------
*/

package ecrd.biz;




/**
 * This Entity represents the Escalation for the customer catalog.
 */
public class eCRDEscalation 
{
   private Double dblEscalation = null;
   
   /**
    * A 2 dimentional array , which stores index and % dependency
    */
   private String[][] lstIndexDependency;
   
   public eCRDEscalation() 
   {
    
   }
   
   /**
    * @param arrIndexDependency
    */
   public void setIndexDependency(String[][] arrIndexDependency) 
   {
    this.lstIndexDependency=arrIndexDependency;
   }
   
   /**
    * @return java.lang.String[][]
    */
   public String[][] getIndexDependency() 
   {
    return lstIndexDependency;
   }
   
   /**
    * Calculate Escalation and retrieve Escalation. If the array for the index 
    * dependency is null then directly return escalation attribute else calculate 
    * escalation and return.
    * @return double
    */
   public Double getEscalation() 
   {
    return this.dblEscalation;
   }
   
   /**
    * @param dblEscalation
    */
   public void setEscalation(Double dblEscalation) 
   {
    this.dblEscalation=dblEscalation;
   }
}
