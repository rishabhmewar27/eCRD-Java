/*
* Module    	    : eCRDGroupedRepair.java
* Author      	    : PATNI-Offshore
* Project	        : eCRD
* Date Written		: October 2004
* Security	        : Unclassified
* Restrictions		: GE PROPRIETARY INFORMATION, FOR GE USE ONLY
*
*     ****************************************************
*     *  Copyright (2000) with all rights reserved       *
*     *          General Electric Company                *
*     ****************************************************
*
* Description: eCRDBusinessBean is used for getting the GEAE Row Cache Tag
*
* Revision Log  (mm/dd/yy initials description)
* --------------------------------------------------------------
 *   31/15/2005     patni  Phase 1 requirement updations 
*/

package ecrd.biz;

import java.util.ArrayList;
import ecrd.common.eCRDDBMediator;
import ecrd.util.eCRDConstants;
import ecrd.exception.eCRDException;
import geae.dao.GEAEResultSet;
import ecrd.util.eCRDUtil;
import ecrd.biz.eCRDComponent;
import javax.servlet.http.HttpServletRequest;
/**
 * This entity represent Grouped Reapir. They will have list of child repair as
 * one of their attribute.
 *
 * @author Patni Computer Systems Ltd.
 */
public class eCRDGroupedRepair extends eCRDRepair
{

    /**
    	* Is this from Merged repair
    	*/
    private boolean flgIsFromMerge = false;

    /**
    	* ArrayList of eCRDChildRepair for the Grouped Repair.
    	*/
    private ArrayList arrlstChildRepair = null;

    public eCRDGroupedRepair()
    {

    }
    public eCRDGroupedRepair(String strRepairCode, String strModuleCode, String strComponentCode, String strCataloSeqId) throws Exception
    {
        ArrayList arrlstInpParam = null;
        ArrayList arrlstOutParam = null;
        String strActionId = null;
        String strErrorMsg = null;
        String strLaboutHr = null;
        String strLocLbrRate = null;
        String strMaterialCost = null;
        double dblTotalCost;
        double dblCM;
        double dblMaterialCost;
        double dblLabourHrs;
        double dblLocLabourRate;
        double dblRepairPrice;

        eCRDException objException = null;
        GEAEResultSet rsGrpRepairDetails = null;
        GEAEResultSet rsRepairSite = null;
        GEAEResultSet rsChildRepairDetails = null;
        GEAEResultSet rsRepairPricingDetails = null;
        eCRDComponent objECRDComponent = null;
        eCRDModule objECRDModule = null;
        eCRDEngineModel objECRDModel = null;
        eCRDCatalog objCataLog = null;
        eCRDRepairPricing objRepairPricing = null;
        eCRDChildRepair objECRDChildRepair = null;
        eCRDChildRepair objChildRepair = null;
        eCRDRepairSite objECRDRepairSite = null;
        
        try
        {
            if (strRepairCode == null || strRepairCode.equals(""))
            {
                objException = new eCRDException();
                objException.setExcpId("REPAIR_SEQ_ID_NOT_SET");
                throw objException;
            }
            if (strModuleCode == null || strModuleCode.equals(""))
            {
                objException = new eCRDException();
                objException.setExcpId("MODULE_CODE_NOT_SET");
                throw objException;
            }
            if (strComponentCode == null || strComponentCode.equals(""))
            {
                objException = new eCRDException();
                objException.setExcpId("COMPONENT_CODE_NOT_SET");
                throw objException;
            }
            if (strCataloSeqId == null || strCataloSeqId.equals(""))
            {
                objException = new eCRDException();
                objException.setExcpId("CATALOG_SEQ_ID_NOT_SET");
                throw objException;
            }

            //Set the action this to call procedure to get child repair details
            strActionId = eCRDConstants.getActionId("eCRD_STG_MAIN_REPAIR_DETAILS");
            //ArrayList of Input Parameters
            arrlstInpParam = new ArrayList();
            //ArrayList of Output Parameters
            arrlstOutParam = new ArrayList();
            //Pass procedure input parameters to ArrayList

            arrlstInpParam.add(strRepairCode);
            arrlstInpParam.add(strCataloSeqId);
            arrlstInpParam.add(strModuleCode);
            arrlstInpParam.add(strComponentCode);
            
          //Adding CSM Queue changes - kumar(502321240)
            arrlstInpParam.add("ApprovalQueue");
            arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);

            //Return the message code retrieved from procedure

            rsGrpRepairDetails = (GEAEResultSet) arrlstOutParam.get(0);
            rsRepairSite = (GEAEResultSet) arrlstOutParam.get(1);
            rsRepairPricingDetails = (GEAEResultSet) arrlstOutParam.get(2);
            rsChildRepairDetails = (GEAEResultSet) arrlstOutParam.get(3);
            this.setIsLastRepair(eCRDUtil.verifyNull((String) arrlstOutParam.get(4)));

            rsGrpRepairDetails.setCurrentRow(0);
            rsGrpRepairDetails.next();

            //this.setCreatedFromSplit(rsIndRepairDetails.getString("compDescription"));
            this.setDtRepairEffDate(rsGrpRepairDetails.getString("Repair_Eff_Date"));
            
            this.setRepairInd(rsGrpRepairDetails.getString("Repair_Ind")); // changes by rishabh mewar
            
            this.setStrComments(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("Repair_Comments")));
            this.setStrRapairVolume(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("Repair_Volm")));
            this.setStrRepairCode(strRepairCode);
            this.setStrRepairDesc(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("Repair_Desc")));
            // Sushant
            this.setStrRDNumber(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("RD_NUMBER")));
            this.setStrReasonRDOverride(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("RD_OVERRIDE_REASON")));            
            this.setStrRDAssociation(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("RD_ASSOCIATION")));
            this.setStrRDNumberComment(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("RD_COMMENT")));
            this.setStrRDCreationDt(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("RD_CREATION_DATE")));
            this.setStrRDModifiedDt(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("RD_UPDATED_DATE")));
            this.setStrNPIClassification(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("NPI_CLASSIFICATION")));
/*502634089 */
            this.setStrModeOfRepair(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("MODE_OF_REPAIR")));
            this.setStrLinkServiceEngineer(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("LINK_SERVICE_ENGINEER")));
            /*added by 502633024*/
            this.setStrLevelOfDifficulty(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("LEVEL_OF_DIFFICULTY")));
            this.setStrSPADPartPrice(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("SPAD_PART_PRICE")));
            this.setStrSPADPartNumber(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("SPAD_PART_NUMBER")));
            this.setStrRepairFre(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("REPAIR_FREQUENCY")));
            this.setStrRationale(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("RATIONALE_FOR_CHANGE")));
            this.setStrRepairFlg(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("Repair_Flag")));
            
            /* SAP columns addition start Kumar */
            this.setStrSAPFlag(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("Sap_Flag")));            
            this.setStrSAPFeatureQuantity(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("Sap_Feature_Quantity")));
            /* SAP columns addition end*/
            rsRepairPricingDetails.setCurrentRow(0);
            rsRepairPricingDetails.next();

            objRepairPricing = addRepairPricing();

            objRepairPricing.setDblFuturePrice(eCRDUtil.verifyDoubleObj(rsRepairPricingDetails.getString("Future_Price")));

            if (rsRepairPricingDetails.getString("Incremantal_Price").equalsIgnoreCase(eCRDConstants.STRTRUE))
            {
                objRepairPricing.setFlgIncrPrice(true);
            }
            else if (rsRepairPricingDetails.getString("Incremantal_Price").equalsIgnoreCase(eCRDConstants.STRFALSE))
            {
                objRepairPricing.setFlgIncrPrice(false);
            }
            objRepairPricing.setDblPrice(eCRDUtil.verifyDoubleObj(rsRepairPricingDetails.getString("Repair_Price")));

            if (rsRepairPricingDetails.getString("Incremntal_tat_ind").equalsIgnoreCase(eCRDConstants.STRTRUE))
            {
                objRepairPricing.setFlgIncrTAT(true);
            }
            else if (rsRepairPricingDetails.getString("Incremntal_tat_ind").equalsIgnoreCase(eCRDConstants.STRFALSE))
            {
                objRepairPricing.setFlgIncrTAT(false);
            }

            objRepairPricing.setIntFutureTAT(eCRDUtil.verifyIntObj(rsRepairPricingDetails.getString("Future_TAT")));
            objRepairPricing.setRepairSeqNo(eCRDUtil.verifyNull(rsRepairPricingDetails.getString("Repair_Seq_No")));
            objRepairPricing.setIntTAT(eCRDUtil.verifyIntObj(rsRepairPricingDetails.getString("Repair_TAT")));
            objRepairPricing.setDtFuturePriceTATEffDt(eCRDUtil.verifyNull(rsRepairPricingDetails.getString("Future_Eff_Date")));
            objRepairPricing.setStrPriceType(eCRDUtil.verifyNull(rsRepairPricingDetails.getString("Price_Type")));
			
			if (rsRepairPricingDetails.getString("price_overwite_ind").equalsIgnoreCase(eCRDConstants.STRTRUE))
			{
				objRepairPricing.setFlgPriceOverWriteInd(true);
			}
			else if (rsRepairPricingDetails.getString("price_overwite_ind").equalsIgnoreCase(eCRDConstants.STRFALSE))
			{
				objRepairPricing.setFlgPriceOverWriteInd(false);
			}
			
            rsChildRepairDetails.setCurrentRow(0); //Set the cursor position to start
//          19-05-2006 patni checking null value Begin           
            if(rsChildRepairDetails != null)
            {    
//              19-05-2006 patni checking null value End                
            while (rsChildRepairDetails.next())
            {
                objChildRepair = this.addChildRepair();

                objChildRepair.setRepairSeqNo(eCRDUtil.verifyNull(rsChildRepairDetails.getString("Repair_Seq_No")));
                
                objChildRepair.setRepairInd(eCRDUtil.verifyNull(rsChildRepairDetails.getString("Repair_Ind"))); // changes by rishabh mewar
                
                objChildRepair.setStrChildRepairCode(eCRDUtil.verifyNull(rsChildRepairDetails.getString("Repair_Code")));
                objChildRepair.setStrComments(eCRDUtil.verifyNull(rsChildRepairDetails.getString("Repair_Comm")));
                objChildRepair.setStrReapairRefFormat(eCRDUtil.verifyNull(rsChildRepairDetails.getString("Rep_Ref_Format")));
                objChildRepair.setStrRepairRefNo(eCRDUtil.verifyNull(rsChildRepairDetails.getString("Repair_Ref_No")));
                objChildRepair.setStrReapirDesc(eCRDUtil.verifyNull(rsChildRepairDetails.getString("Repair_Desc")));
                // Sushant
                objChildRepair.setStrRDNumber(eCRDUtil.verifyNull(rsChildRepairDetails.getString("RD_NUMBER")));
                objChildRepair.setStrReasonRDOverride(eCRDUtil.verifyNull(rsChildRepairDetails.getString("RD_OVERRIDE_REASON")));            
                objChildRepair.setStrRDAssociation(eCRDUtil.verifyNull(rsChildRepairDetails.getString("RD_ASSOCIATION")));
                objChildRepair.setStrRDNumberComment(eCRDUtil.verifyNull(rsChildRepairDetails.getString("RD_COMMENT")));
                objChildRepair.setStrRDCreationDt(eCRDUtil.verifyNull(rsChildRepairDetails.getString("RD_CREATION_DATE")));
                objChildRepair.setStrRDModifiedDt(eCRDUtil.verifyNull(rsChildRepairDetails.getString("RD_UPDATED_DATE")));
              //DES1146388 SAP flag added by Kumar
                objChildRepair.setStrChildSAPFlag(eCRDUtil.verifyNull(rsChildRepairDetails.getString("Sap_Flag")));
                objChildRepair.setStrChildSAPFeatureQuantity(eCRDUtil.verifyNull(rsChildRepairDetails.getString("Sap_Feature_Quantity")));
            } 
//          19-05-2006 patni checking null value Begin             
            } // End if 
//          19-05-2006 patni checking null value End
            rsRepairSite.setCurrentRow(0); //Set the cursor position to start
//          19-05-2006 patni checking null value Begin  
            if (rsRepairSite !=null)
            { 
//              19-05-2006 patni checking null value End            
            while (rsRepairSite.next())
            {
                objECRDRepairSite = this.addECRDRepairSite();
                objECRDRepairSite.setSiteCode(eCRDUtil.verifyNull(rsRepairSite.getString("Location_Id")));

                objECRDRepairSite.setLaborHr(eCRDUtil.verifyDouble(rsRepairSite.getString("Labour_Hours")));
                strLaboutHr = eCRDUtil.verifyNullReturnZero(rsRepairSite.getString("Labour_Hours"));
                strLocLbrRate = eCRDUtil.verifyNullReturnZero(rsRepairSite.getString("LOC_Labour_rate"));
                strMaterialCost = eCRDUtil.verifyNullReturnZero(rsRepairSite.getString("Material_Cost"));
                dblMaterialCost =eCRDUtil.verifyDouble(strMaterialCost);
                dblLocLabourRate = eCRDUtil.verifyDouble(strLocLbrRate);
                dblLabourHrs =eCRDUtil.verifyDouble(strLaboutHr);

                //Calculate Total Cost = Material Cost + (Labor Hours * Labour Rate)
                dblTotalCost = dblMaterialCost + (dblLocLabourRate * dblLabourHrs);

                //Get repair price for calculation of CM%
                if(objRepairPricing.getDblPrice()==null)
                {
					dblRepairPrice =0;
                }
                else
                {
					dblRepairPrice = objRepairPricing.getDblPrice().doubleValue();
                }

                //Calculate CM% = (price-total cost)/price * 100
                if (dblRepairPrice == 0.0)
                {
					objECRDRepairSite.setCM(0.0);
                    
                }
                else
                {
					dblCM = ((dblRepairPrice - dblTotalCost) / (dblRepairPrice)) * 100;
					objECRDRepairSite.setCM(Double.parseDouble(eCRDUtil.Format(dblCM, 2)));
                }
                
                objECRDRepairSite.setMaterialCost(eCRDUtil.verifyDouble(rsRepairSite.getString("Material_Cost")));
                objECRDRepairSite.setSiteDescription(eCRDUtil.verifyNull(rsRepairSite.getString("Location_Desc")));
                objECRDRepairSite.setTotalCost(dblTotalCost);
                objECRDRepairSite.setLocationLaborRate(eCRDUtil.verifyDouble(rsRepairSite.getString("LOC_Labour_rate")));
            }
//          19-05-2006 patni checking null value Begin              
            } //end if 
//          19-05-2006 patni checking null value End
        }

        finally
        {
            arrlstInpParam = null;
            arrlstOutParam = null;
            strActionId = null;
            strErrorMsg = null;
        }
    }
    
    public eCRDGroupedRepair(String strRepairCode, String strModuleCode, String strComponentCode, String strCataloSeqId,int notRequired) throws Exception
    {
        ArrayList arrlstInpParam = null;
        ArrayList arrlstOutParam = null;
        String strActionId = null;
        String strErrorMsg = null;
        String strLaboutHr = null;
        String strLocLbrRate = null;
        String strMaterialCost = null;
        double dblTotalCost;
        double dblCM;
        double dblMaterialCost;
        double dblLabourHrs;
        double dblLocLabourRate;
        double dblRepairPrice;

        eCRDException objException = null;
        GEAEResultSet rsGrpRepairDetails = null;
        GEAEResultSet rsRepairSite = null;
        GEAEResultSet rsChildRepairDetails = null;
        GEAEResultSet rsRepairPricingDetails = null;
        eCRDComponent objECRDComponent = null;
        eCRDModule objECRDModule = null;
        eCRDEngineModel objECRDModel = null;
        eCRDCatalog objCataLog = null;
        eCRDRepairPricing objRepairPricing = null;
        eCRDChildRepair objECRDChildRepair = null;
        eCRDChildRepair objChildRepair = null;
        eCRDRepairSite objECRDRepairSite = null;
        try
        {
            if (strRepairCode == null || strRepairCode.equals(""))
            {
                objException = new eCRDException();
                objException.setExcpId("REPAIR_SEQ_ID_NOT_SET");
                throw objException;
            }
            if (strModuleCode == null || strModuleCode.equals(""))
            {
                objException = new eCRDException();
                objException.setExcpId("MODULE_CODE_NOT_SET");
                throw objException;
            }
            if (strComponentCode == null || strComponentCode.equals(""))
            {
                objException = new eCRDException();
                objException.setExcpId("COMPONENT_CODE_NOT_SET");
                throw objException;
            }
            if (strCataloSeqId == null || strCataloSeqId.equals(""))
            {
                objException = new eCRDException();
                objException.setExcpId("CATALOG_SEQ_ID_NOT_SET");
                throw objException;
            }

            //Set the action this to call procedure to get child repair details
            strActionId = eCRDConstants.getActionId("eCRD_STG_MAIN_REPAIR_DETAILS_FOR_SAVE");
            //ArrayList of Input Parameters
            arrlstInpParam = new ArrayList();
            //ArrayList of Output Parameters
            arrlstOutParam = new ArrayList();
            //Pass procedure input parameters to ArrayList

           /* */
            arrlstInpParam.add(strRepairCode);
            arrlstInpParam.add(strCataloSeqId);
            arrlstInpParam.add(strModuleCode);
            arrlstInpParam.add(strComponentCode);
            
          //Adding CSM Queue changes - kumar(502321240)
            /*arrlstInpParam.add("ApprovalQueue");*/
            arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);

            //Return the message code retrieved from procedure

            rsGrpRepairDetails = (GEAEResultSet) arrlstOutParam.get(0);
            rsRepairSite = (GEAEResultSet) arrlstOutParam.get(1);
            rsRepairPricingDetails = (GEAEResultSet) arrlstOutParam.get(2);
            rsChildRepairDetails = (GEAEResultSet) arrlstOutParam.get(3);
            this.setIsLastRepair(eCRDUtil.verifyNull((String) arrlstOutParam.get(4)));

            rsGrpRepairDetails.setCurrentRow(0);
            rsGrpRepairDetails.next();

            //this.setCreatedFromSplit(rsIndRepairDetails.getString("compDescription"));
            this.setStrRepairFre(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("REPAIR_FREQUENCY")));
            
            this.setRepairInd(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("Repair_Ind"))); // changes by rishabh mewar
            
            this.setStrRationale(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("RATIONALE_FOR_CHANGE")));
            this.setStrRepairFlg(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("Repair_Flag")));
            this.setDtRepairEffDate(rsGrpRepairDetails.getString("Repair_Eff_Date"));
            this.setStrComments(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("Repair_Comments")));
            this.setStrRapairVolume(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("Repair_Volm")));
            this.setStrRepairCode(strRepairCode);
            this.setStrRepairDesc(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("Repair_Desc")));
            // Sushant
            this.setStrRDNumber(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("RD_NUMBER")));
            this.setStrReasonRDOverride(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("RD_OVERRIDE_REASON")));            
            this.setStrRDAssociation(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("RD_ASSOCIATION")));
            this.setStrRDNumberComment(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("RD_COMMENT")));
            this.setStrRDCreationDt(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("RD_CREATION_DATE")));
            this.setStrRDModifiedDt(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("RD_UPDATED_DATE")));
            this.setStrNPIClassification(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("NPI_CLASSIFICATION")));
/*502634089 */
            this.setStrModeOfRepair(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("MODE_OF_REPAIR")));
            this.setStrLinkServiceEngineer(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("LINK_SERVICE_ENGINEER")));
            
            this.setStagingInd(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("STAGING_IND")));
            /*added by 502633024*/
            this.setStrLevelOfDifficulty(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("LEVEL_OF_DIFFICULTY")));
            this.setStrSPADPartPrice(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("SPAD_PART_PRICE")));
            this.setStrSPADPartNumber(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("SPAD_PART_NUMBER")));
            this.setStrRepairFre(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("REPAIR_FREQUENCY")));
            this.setStrRationale(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("RATIONALE_FOR_CHANGE")));
            this.setStrRepairFlg(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("Repair_Flag")));
            
            /* SAP columns addition start Kumar */
            this.setStrSAPFlag(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("Sap_Flag")));            
            this.setStrSAPFeatureQuantity(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("Sap_Feature_Quantity")));
            /* SAP columns addition end*/
            rsRepairPricingDetails.setCurrentRow(0);
            rsRepairPricingDetails.next();

            objRepairPricing = addRepairPricing();

            objRepairPricing.setDblFuturePrice(eCRDUtil.verifyDoubleObj(rsRepairPricingDetails.getString("Future_Price")));

            if (rsRepairPricingDetails.getString("Incremantal_Price").equalsIgnoreCase(eCRDConstants.STRTRUE))
            {
                objRepairPricing.setFlgIncrPrice(true);
            }
            else if (rsRepairPricingDetails.getString("Incremantal_Price").equalsIgnoreCase(eCRDConstants.STRFALSE))
            {
                objRepairPricing.setFlgIncrPrice(false);
            }
            objRepairPricing.setDblPrice(eCRDUtil.verifyDoubleObj(rsRepairPricingDetails.getString("Repair_Price")));

            if (rsRepairPricingDetails.getString("Incremntal_tat_ind").equalsIgnoreCase(eCRDConstants.STRTRUE))
            {
                objRepairPricing.setFlgIncrTAT(true);
            }
            else if (rsRepairPricingDetails.getString("Incremntal_tat_ind").equalsIgnoreCase(eCRDConstants.STRFALSE))
            {
                objRepairPricing.setFlgIncrTAT(false);
            }

            objRepairPricing.setIntFutureTAT(eCRDUtil.verifyIntObj(rsRepairPricingDetails.getString("Future_TAT")));
            objRepairPricing.setRepairSeqNo(eCRDUtil.verifyNull(rsRepairPricingDetails.getString("Repair_Seq_No")));
            objRepairPricing.setIntTAT(eCRDUtil.verifyIntObj(rsRepairPricingDetails.getString("Repair_TAT")));
            objRepairPricing.setDtFuturePriceTATEffDt(eCRDUtil.verifyNull(rsRepairPricingDetails.getString("Future_Eff_Date")));
            objRepairPricing.setStrPriceType(eCRDUtil.verifyNull(rsRepairPricingDetails.getString("Price_Type")));
			
			if (rsRepairPricingDetails.getString("price_overwite_ind").equalsIgnoreCase(eCRDConstants.STRTRUE))
			{
				objRepairPricing.setFlgPriceOverWriteInd(true);
			}
			else if (rsRepairPricingDetails.getString("price_overwite_ind").equalsIgnoreCase(eCRDConstants.STRFALSE))
			{
				objRepairPricing.setFlgPriceOverWriteInd(false);
			}
			
            rsChildRepairDetails.setCurrentRow(0); //Set the cursor position to start
//          19-05-2006 patni checking null value Begin           
            if(rsChildRepairDetails != null)
            {    
//              19-05-2006 patni checking null value End                
            while (rsChildRepairDetails.next())
            {
                objChildRepair = this.addChildRepair();

                objChildRepair.setRepairSeqNo(eCRDUtil.verifyNull(rsChildRepairDetails.getString("Repair_Seq_No")));
                
                objChildRepair.setRepairInd(eCRDUtil.verifyNull(rsChildRepairDetails.getString("Repair_Ind"))); //changes by rishabh mewar
                
                objChildRepair.setStrChildRepairCode(eCRDUtil.verifyNull(rsChildRepairDetails.getString("Repair_Code")));
                objChildRepair.setStrComments(eCRDUtil.verifyNull(rsChildRepairDetails.getString("Repair_Comm")));
                objChildRepair.setStrReapairRefFormat(eCRDUtil.verifyNull(rsChildRepairDetails.getString("Rep_Ref_Format")));
                objChildRepair.setStrRepairRefNo(eCRDUtil.verifyNull(rsChildRepairDetails.getString("Repair_Ref_No")));
                objChildRepair.setStrReapirDesc(eCRDUtil.verifyNull(rsChildRepairDetails.getString("Repair_Desc")));
                // Sushant
                objChildRepair.setStrRDNumber(eCRDUtil.verifyNull(rsChildRepairDetails.getString("RD_NUMBER")));
                objChildRepair.setStrReasonRDOverride(eCRDUtil.verifyNull(rsChildRepairDetails.getString("RD_OVERRIDE_REASON")));            
                objChildRepair.setStrRDAssociation(eCRDUtil.verifyNull(rsChildRepairDetails.getString("RD_ASSOCIATION")));
                objChildRepair.setStrRDNumberComment(eCRDUtil.verifyNull(rsChildRepairDetails.getString("RD_COMMENT")));
                objChildRepair.setStrRDCreationDt(eCRDUtil.verifyNull(rsChildRepairDetails.getString("RD_CREATION_DATE")));
                objChildRepair.setStrRDModifiedDt(eCRDUtil.verifyNull(rsChildRepairDetails.getString("RD_UPDATED_DATE")));
              //DES1146388 SAP flag added by Kumar
                objChildRepair.setStrChildSAPFlag(eCRDUtil.verifyNull(rsChildRepairDetails.getString("Sap_Flag")));
                objChildRepair.setStrChildSAPFeatureQuantity(eCRDUtil.verifyNull(rsChildRepairDetails.getString("Sap_Feature_Quantity")));
            } 
//          19-05-2006 patni checking null value Begin             
            } // End if 
//          19-05-2006 patni checking null value End
            rsRepairSite.setCurrentRow(0); //Set the cursor position to start
//          19-05-2006 patni checking null value Begin  
            if (rsRepairSite !=null)
            { 
//              19-05-2006 patni checking null value End            
            while (rsRepairSite.next())
            {
                objECRDRepairSite = this.addECRDRepairSite();
                objECRDRepairSite.setSiteCode(eCRDUtil.verifyNull(rsRepairSite.getString("Location_Id")));

                objECRDRepairSite.setLaborHr(eCRDUtil.verifyDouble(rsRepairSite.getString("Labour_Hours")));
                strLaboutHr = eCRDUtil.verifyNullReturnZero(rsRepairSite.getString("Labour_Hours"));
                strLocLbrRate = eCRDUtil.verifyNullReturnZero(rsRepairSite.getString("LOC_Labour_rate"));
                strMaterialCost = eCRDUtil.verifyNullReturnZero(rsRepairSite.getString("Material_Cost"));
                dblMaterialCost =eCRDUtil.verifyDouble(strMaterialCost);
                dblLocLabourRate = eCRDUtil.verifyDouble(strLocLbrRate);
                dblLabourHrs =eCRDUtil.verifyDouble(strLaboutHr);

                //Calculate Total Cost = Material Cost + (Labor Hours * Labour Rate)
                dblTotalCost = dblMaterialCost + (dblLocLabourRate * dblLabourHrs);

                //Get repair price for calculation of CM%
                if(objRepairPricing.getDblPrice()==null)
                {
					dblRepairPrice =0;
                }
                else
                {
					dblRepairPrice = objRepairPricing.getDblPrice().doubleValue();
					
                }

                //Calculate CM% = (price-total cost)/price * 100
                if (dblRepairPrice == 0.0)
                {
					objECRDRepairSite.setCM(0.0);
                    
                }
                else
                {
					dblCM = ((dblRepairPrice - dblTotalCost) / (dblRepairPrice)) * 100;
					objECRDRepairSite.setCM(Double.parseDouble(eCRDUtil.Format(dblCM, 2)));
                }
                
                objECRDRepairSite.setMaterialCost(eCRDUtil.verifyDouble(rsRepairSite.getString("Material_Cost")));
                objECRDRepairSite.setSiteDescription(eCRDUtil.verifyNull(rsRepairSite.getString("Location_Desc")));
                objECRDRepairSite.setTotalCost(dblTotalCost);
                objECRDRepairSite.setLocationLaborRate(eCRDUtil.verifyDouble(rsRepairSite.getString("LOC_Labour_rate")));
            }
//          19-05-2006 patni checking null value Begin              
            } //end if 
//          19-05-2006 patni checking null value End
        }

        finally
        {
            arrlstInpParam = null;
            arrlstOutParam = null;
            strActionId = null;
            strErrorMsg = null;
        }
    }
    
    // Adding CSM Queue changes - kumar(502321240)
    public eCRDGroupedRepair(String strRepairCode, String strModuleCode, String strComponentCode, String strCataloSeqId, HttpServletRequest request) throws Exception
    {
        ArrayList arrlstInpParam = null;
        ArrayList arrlstOutParam = null;
        String strActionId = null;
        String strErrorMsg = null;
        String strLaboutHr = null;
        String strLocLbrRate = null;
        String strMaterialCost = null;
        double dblTotalCost;
        double dblCM;
        double dblMaterialCost;
        double dblLabourHrs;
        double dblLocLabourRate;
        double dblRepairPrice;

        eCRDException objException = null;
        GEAEResultSet rsGrpRepairDetails = null;
        GEAEResultSet rsRepairSite = null;
        GEAEResultSet rsChildRepairDetails = null;
        GEAEResultSet rsRepairPricingDetails = null;
        eCRDComponent objECRDComponent = null;
        eCRDModule objECRDModule = null;
        eCRDEngineModel objECRDModel = null;
        eCRDCatalog objCataLog = null;
        eCRDRepairPricing objRepairPricing = null;
        eCRDChildRepair objECRDChildRepair = null;
        eCRDChildRepair objChildRepair = null;
        eCRDRepairSite objECRDRepairSite = null;
        try
        {
        	//System.out.println("getting queue type in ecrdGroupedRepair overloaded method: "+request.getParameter("hdnGetRepairDetails"));
            if (strRepairCode == null || strRepairCode.equals(""))
            {
                objException = new eCRDException();
                objException.setExcpId("REPAIR_SEQ_ID_NOT_SET");
                throw objException;
            }
            if (strModuleCode == null || strModuleCode.equals(""))
            {
                objException = new eCRDException();
                objException.setExcpId("MODULE_CODE_NOT_SET");
                throw objException;
            }
            if (strComponentCode == null || strComponentCode.equals(""))
            {
                objException = new eCRDException();
                objException.setExcpId("COMPONENT_CODE_NOT_SET");
                throw objException;
            }
            if (strCataloSeqId == null || strCataloSeqId.equals(""))
            {
                objException = new eCRDException();
                objException.setExcpId("CATALOG_SEQ_ID_NOT_SET");
                throw objException;
            }

            //Set the action this to call procedure to get child repair details
            strActionId = eCRDConstants.getActionId("eCRD_STG_MAIN_REPAIR_DETAILS");
            //ArrayList of Input Parameters
            arrlstInpParam = new ArrayList();
            //ArrayList of Output Parameters
            arrlstOutParam = new ArrayList();
            //Pass procedure input parameters to ArrayList

            arrlstInpParam.add(strRepairCode);
            arrlstInpParam.add(strCataloSeqId);
            arrlstInpParam.add(strModuleCode);
            arrlstInpParam.add(strComponentCode);
            
          //Adding CSM Queue changes - kumar(502321240)
            arrlstInpParam.add("CSMQueue");
            arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);

            //Return the message code retrieved from procedure

            rsGrpRepairDetails = (GEAEResultSet) arrlstOutParam.get(0);
            rsRepairSite = (GEAEResultSet) arrlstOutParam.get(1);
            rsRepairPricingDetails = (GEAEResultSet) arrlstOutParam.get(2);
            rsChildRepairDetails = (GEAEResultSet) arrlstOutParam.get(3);
            this.setIsLastRepair(eCRDUtil.verifyNull((String) arrlstOutParam.get(4)));

            rsGrpRepairDetails.setCurrentRow(0);
            rsGrpRepairDetails.next();

            //this.setCreatedFromSplit(rsIndRepairDetails.getString("compDescription"));
            this.setDtRepairEffDate(rsGrpRepairDetails.getString("Repair_Eff_Date"));
            
            this.setRepairInd(rsGrpRepairDetails.getString("Repair_Ind")); //changes by rishabh mewar
            
            this.setStrComments(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("Repair_Comments")));
            this.setStrRapairVolume(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("Repair_Volm")));
            this.setStrRepairCode(strRepairCode);
            this.setStrRepairDesc(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("Repair_Desc")));
            // Sushant
            this.setStrRDNumber(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("RD_NUMBER")));
            this.setStrReasonRDOverride(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("RD_OVERRIDE_REASON")));            
            this.setStrRDAssociation(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("RD_ASSOCIATION")));
            this.setStrRDNumberComment(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("RD_COMMENT")));
            this.setStrRDCreationDt(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("RD_CREATION_DATE")));
            this.setStrRDModifiedDt(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("RD_UPDATED_DATE")));
            this.setStrNPIClassification(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("NPI_CLASSIFICATION")));
            
/*502634089 */
            this.setStrModeOfRepair(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("MODE_OF_REPAIR")));
            this.setStrLinkServiceEngineer(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("LINK_SERVICE_ENGINEER")));
            /*added by 502633024*/
            this.setStrLevelOfDifficulty(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("LEVEL_OF_DIFFICULTY")));
            this.setStrSPADPartPrice(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("SPAD_PART_PRICE")));
            this.setStrSPADPartNumber(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("SPAD_PART_NUMBER")));
            
            
            
            this.setStrRepairFre(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("REPAIR_FREQUENCY")));
            this.setStrRationale(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("RATIONALE_FOR_CHANGE")));
            this.setStrRepairFlg(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("Repair_Flag")));
            /* SAP columns addition start Kumar */
            this.setStrSAPFlag(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("Sap_Flag")));            
            this.setStrSAPFeatureQuantity(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("Sap_Feature_Quantity")));
            /* SAP columns addition end*/
            rsRepairPricingDetails.setCurrentRow(0);
            rsRepairPricingDetails.next();

            objRepairPricing = addRepairPricing();

            objRepairPricing.setDblFuturePrice(eCRDUtil.verifyDoubleObj(rsRepairPricingDetails.getString("Future_Price")));

            if (rsRepairPricingDetails.getString("Incremantal_Price").equalsIgnoreCase(eCRDConstants.STRTRUE))
            {
                objRepairPricing.setFlgIncrPrice(true);
            }
            else if (rsRepairPricingDetails.getString("Incremantal_Price").equalsIgnoreCase(eCRDConstants.STRFALSE))
            {
                objRepairPricing.setFlgIncrPrice(false);
            }
            objRepairPricing.setDblPrice(eCRDUtil.verifyDoubleObj(rsRepairPricingDetails.getString("Repair_Price")));

            if (rsRepairPricingDetails.getString("Incremntal_tat_ind").equalsIgnoreCase(eCRDConstants.STRTRUE))
            {
                objRepairPricing.setFlgIncrTAT(true);
            }
            else if (rsRepairPricingDetails.getString("Incremntal_tat_ind").equalsIgnoreCase(eCRDConstants.STRFALSE))
            {
                objRepairPricing.setFlgIncrTAT(false);
            }

            objRepairPricing.setIntFutureTAT(eCRDUtil.verifyIntObj(rsRepairPricingDetails.getString("Future_TAT")));
            objRepairPricing.setRepairSeqNo(eCRDUtil.verifyNull(rsRepairPricingDetails.getString("Repair_Seq_No")));
            objRepairPricing.setIntTAT(eCRDUtil.verifyIntObj(rsRepairPricingDetails.getString("Repair_TAT")));
            objRepairPricing.setDtFuturePriceTATEffDt(eCRDUtil.verifyNull(rsRepairPricingDetails.getString("Future_Eff_Date")));
            objRepairPricing.setStrPriceType(eCRDUtil.verifyNull(rsRepairPricingDetails.getString("Price_Type")));
			
			if (rsRepairPricingDetails.getString("price_overwite_ind").equalsIgnoreCase(eCRDConstants.STRTRUE))
			{
				objRepairPricing.setFlgPriceOverWriteInd(true);
			}
			else if (rsRepairPricingDetails.getString("price_overwite_ind").equalsIgnoreCase(eCRDConstants.STRFALSE))
			{
				objRepairPricing.setFlgPriceOverWriteInd(false);
			}
			
            rsChildRepairDetails.setCurrentRow(0); //Set the cursor position to start
//          19-05-2006 patni checking null value Begin           
            if(rsChildRepairDetails != null)
            {    
//              19-05-2006 patni checking null value End                
            while (rsChildRepairDetails.next())
            {
                objChildRepair = this.addChildRepair();

                objChildRepair.setRepairSeqNo(eCRDUtil.verifyNull(rsChildRepairDetails.getString("Repair_Seq_No")));
                
                objChildRepair.setRepairInd(eCRDUtil.verifyNull(rsChildRepairDetails.getString("Repair_Ind"))); //changes by rishabh mewar
                
                objChildRepair.setStrChildRepairCode(eCRDUtil.verifyNull(rsChildRepairDetails.getString("Repair_Code")));
                objChildRepair.setStrComments(eCRDUtil.verifyNull(rsChildRepairDetails.getString("Repair_Comm")));
                objChildRepair.setStrReapairRefFormat(eCRDUtil.verifyNull(rsChildRepairDetails.getString("Rep_Ref_Format")));
                objChildRepair.setStrRepairRefNo(eCRDUtil.verifyNull(rsChildRepairDetails.getString("Repair_Ref_No")));
                objChildRepair.setStrReapirDesc(eCRDUtil.verifyNull(rsChildRepairDetails.getString("Repair_Desc")));
                // Sushant
                objChildRepair.setStrRDNumber(eCRDUtil.verifyNull(rsChildRepairDetails.getString("RD_NUMBER")));
                objChildRepair.setStrReasonRDOverride(eCRDUtil.verifyNull(rsChildRepairDetails.getString("RD_OVERRIDE_REASON")));            
                objChildRepair.setStrRDAssociation(eCRDUtil.verifyNull(rsChildRepairDetails.getString("RD_ASSOCIATION")));
                objChildRepair.setStrRDNumberComment(eCRDUtil.verifyNull(rsChildRepairDetails.getString("RD_COMMENT")));
                objChildRepair.setStrRDCreationDt(eCRDUtil.verifyNull(rsChildRepairDetails.getString("RD_CREATION_DATE")));
                objChildRepair.setStrRDModifiedDt(eCRDUtil.verifyNull(rsChildRepairDetails.getString("RD_UPDATED_DATE")));
              //DES1146388 SAP flag added by Kumar
                objChildRepair.setStrChildSAPFlag(eCRDUtil.verifyNull(rsChildRepairDetails.getString("Sap_Flag")));
                objChildRepair.setStrChildSAPFeatureQuantity(eCRDUtil.verifyNull(rsChildRepairDetails.getString("Sap_Feature_Quantity")));
            } 
//          19-05-2006 patni checking null value Begin             
            } // End if 
//          19-05-2006 patni checking null value End
            rsRepairSite.setCurrentRow(0); //Set the cursor position to start
//          19-05-2006 patni checking null value Begin  
            if (rsRepairSite !=null)
            { 
//              19-05-2006 patni checking null value End            
            while (rsRepairSite.next())
            {
                objECRDRepairSite = this.addECRDRepairSite();
                objECRDRepairSite.setSiteCode(eCRDUtil.verifyNull(rsRepairSite.getString("Location_Id")));

                objECRDRepairSite.setLaborHr(eCRDUtil.verifyDouble(rsRepairSite.getString("Labour_Hours")));
                strLaboutHr = eCRDUtil.verifyNullReturnZero(rsRepairSite.getString("Labour_Hours"));
                strLocLbrRate = eCRDUtil.verifyNullReturnZero(rsRepairSite.getString("LOC_Labour_rate"));
                strMaterialCost = eCRDUtil.verifyNullReturnZero(rsRepairSite.getString("Material_Cost"));
                dblMaterialCost =eCRDUtil.verifyDouble(strMaterialCost);
                dblLocLabourRate = eCRDUtil.verifyDouble(strLocLbrRate);
                dblLabourHrs =eCRDUtil.verifyDouble(strLaboutHr);

                //Calculate Total Cost = Material Cost + (Labor Hours * Labour Rate)
                dblTotalCost = dblMaterialCost + (dblLocLabourRate * dblLabourHrs);

                //Get repair price for calculation of CM%
                if(objRepairPricing.getDblPrice()==null)
                {
					dblRepairPrice =0;
                }
                else
                {
					dblRepairPrice = objRepairPricing.getDblPrice().doubleValue();
					
                }

                //Calculate CM% = (price-total cost)/price * 100
                if (dblRepairPrice == 0.0)
                {
					objECRDRepairSite.setCM(0.0);
                    
                }
                else
                {
					dblCM = ((dblRepairPrice - dblTotalCost) / (dblRepairPrice)) * 100;
					objECRDRepairSite.setCM(Double.parseDouble(eCRDUtil.Format(dblCM, 2)));
                }
                
                objECRDRepairSite.setMaterialCost(eCRDUtil.verifyDouble(rsRepairSite.getString("Material_Cost")));
                objECRDRepairSite.setSiteDescription(eCRDUtil.verifyNull(rsRepairSite.getString("Location_Desc")));
                objECRDRepairSite.setTotalCost(dblTotalCost);
                objECRDRepairSite.setLocationLaborRate(eCRDUtil.verifyDouble(rsRepairSite.getString("LOC_Labour_rate")));
            }
//          19-05-2006 patni checking null value Begin              
            } //end if 
//          19-05-2006 patni checking null value End
        }

        finally
        {
            arrlstInpParam = null;
            arrlstOutParam = null;
            strActionId = null;
            strErrorMsg = null;
        }
    }
    public eCRDGroupedRepair(String strRepairCode, String strModuleCode, String strComponentCode, String strCataloSeqId, String strDataFrom) throws Exception
    {
        ArrayList arrlstInpParam = null;
        ArrayList arrlstOutParam = null;
        String strActionId = null;
        String strErrorMsg = null;
        String strLaboutHr = null;
        String strLocLbrRate = null;
        String strMaterialCost = null;
        double dblTotalCost;
        double dblCM;
        double dblMaterialCost;
        double dblLabourHrs;
        double dblLocLabourRate;
        double dblRepairPrice; //Repair Pricing

        eCRDException objException = null;
        GEAEResultSet rsGrpRepairDetails = null;
        GEAEResultSet rsRepairSite = null;
        GEAEResultSet rsChildRepairDetails = null;
        GEAEResultSet rsRepairPricingDetails = null;
        eCRDComponent objECRDComponent = null;
        eCRDModule objECRDModule = null;
        eCRDEngineModel objECRDModel = null;
        eCRDCatalog objCataLog = null;
        eCRDRepairPricing objRepairPricing = null;
        eCRDChildRepair objECRDChildRepair = null;
        eCRDChildRepair objChildRepair = null;
        eCRDRepairSite objECRDRepairSite = null;

        try
        {
            if (strRepairCode == null || strRepairCode.equals(""))
            {
                objException = new eCRDException();
                objException.setExcpId("REPAIR_SEQ_ID_NOT_SET");
                throw objException;
            }

            if (strModuleCode == null || strModuleCode.equals(""))
            {
                objException = new eCRDException();
                objException.setExcpId("MODULE_CODE_NOT_SET");
                throw objException;
            }
            if (strComponentCode == null || strComponentCode.equals(""))
            {
                objException = new eCRDException();
                objException.setExcpId("COMPONENT_CODE_NOT_SET");
                throw objException;
            }
            if (strCataloSeqId == null || strCataloSeqId.equals(""))
            {
                objException = new eCRDException();
                objException.setExcpId("CATALOG_SEQ_ID_NOT_SET");
                throw objException;
            }
            if (strDataFrom == null || strDataFrom.equals(""))
            {
                objException = new eCRDException();
                objException.setExcpId("PARAMETER_DATA_FROM_NOT_SET");
                throw objException;
            }

            //Set the action this to call procedure to get child repair details
            strActionId = eCRDConstants.getActionId("eCRD_REPAIR_DETAILS");
            //ArrayList of Input Parameters
            arrlstInpParam = new ArrayList();
            //ArrayList of Output Parameters
            arrlstOutParam = new ArrayList();
            //Pass procedure input parameters to ArrayList

            /*	  objECRDComponent = this.getObjECRDComponent();
            	  objECRDModule=objECRDComponent.getModule();
            	  objECRDModel =objECRDModule.getEngineModel();
            	  objCataLog = objECRDModel.getCatalog();
            */
            arrlstInpParam.add(strRepairCode);
            arrlstInpParam.add(strCataloSeqId);
            arrlstInpParam.add(strModuleCode);
            arrlstInpParam.add(strComponentCode);
            arrlstInpParam.add(strDataFrom);
            // Call this function to update site details
         
            // Adding CSM Queue changes - kumar(502321240)
            arrlstInpParam.add("ApprovalQueue");
            
            arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);

            //Return the message code retrieved from procedure

            rsGrpRepairDetails = (GEAEResultSet) arrlstOutParam.get(0);
            rsRepairSite = (GEAEResultSet) arrlstOutParam.get(1);
            rsRepairPricingDetails = (GEAEResultSet) arrlstOutParam.get(2);
            rsChildRepairDetails = (GEAEResultSet) arrlstOutParam.get(3);
            this.setIsLastRepair(eCRDUtil.verifyNull((String) arrlstOutParam.get(4)));


            rsGrpRepairDetails.setCurrentRow(0);
            rsGrpRepairDetails.next();

            //this.setCreatedFromSplit(rsIndRepairDetails.getString("compDescription"));
            this.setDtRepairEffDate(rsGrpRepairDetails.getString("Repair_Eff_Date"));
            
            this.setRepairInd(rsGrpRepairDetails.getString("Repair_Ind")); //changes by rishabh mewar
            
            this.setStrComments(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("Repair_Comments")));
            this.setStrRapairVolume(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("Repair_Volm")));
            this.setStrRepairCode(strRepairCode);
            this.setStrRepairDesc(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("Repair_Desc")));
            // Sushant
            this.setStrRDNumber(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("RD_NUMBER")));
            this.setStrReasonRDOverride(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("RD_OVERRIDE_REASON")));            
            this.setStrRDAssociation(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("RD_ASSOCIATION")));
            this.setStrRDNumberComment(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("RD_COMMENT")));
            this.setStrRDCreationDt(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("RD_CREATION_DATE")));
            this.setStrRDModifiedDt(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("RD_UPDATED_DATE")));
            this.setStrNPIClassification(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("NPI_CLASSIFICATION")));
/*502634089 */
            this.setStrModeOfRepair(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("MODE_OF_REPAIR")));
            this.setStrLinkServiceEngineer(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("LINK_SERVICE_ENGINEER")));
            /*added by 502633024*/
            this.setStrLevelOfDifficulty(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("LEVEL_OF_DIFFICULTY")));
            this.setStrSPADPartPrice(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("SPAD_PART_PRICE")));
            this.setStrSPADPartNumber(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("SPAD_PART_NUMBER")));
            
            
            this.setStrRepairFre(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("REPAIR_FREQUENCY")));
            this.setStrRationale(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("RATIONALE_FOR_CHANGE")));
            this.setStrRepairFlg(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("Repair_Flag")));
            
            
            /* SAP columns addition start Kumar */
            this.setStrSAPFlag(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("Sap_Flag")));            
            this.setStrSAPFeatureQuantity(eCRDUtil.verifyNull(rsGrpRepairDetails.getString("Sap_Feature_Quantity")));
            /* SAP columns addition end*/
            rsRepairPricingDetails.setCurrentRow(0);
            rsRepairPricingDetails.next();

            objRepairPricing = addRepairPricing();

            objRepairPricing.setDblFuturePrice(eCRDUtil.verifyDoubleObj(rsRepairPricingDetails.getString("Future_Price")));

            if (rsRepairPricingDetails.getString("Incremantal_Price").equalsIgnoreCase(eCRDConstants.STRTRUE))
            {
                objRepairPricing.setFlgIncrPrice(true);
            }
            else if (rsRepairPricingDetails.getString("Incremantal_Price").equalsIgnoreCase(eCRDConstants.STRFALSE))
            {
                objRepairPricing.setFlgIncrPrice(false);
            }
            objRepairPricing.setDblPrice(eCRDUtil.verifyDoubleObj(rsRepairPricingDetails.getString("Repair_Price")));
            if (rsRepairPricingDetails.getString("Incremntal_tat_ind").equalsIgnoreCase(eCRDConstants.STRTRUE))
            {
                objRepairPricing.setFlgIncrTAT(true);
            }
            else if (rsRepairPricingDetails.getString("Incremntal_tat_ind").equalsIgnoreCase(eCRDConstants.STRFALSE))
            {
                objRepairPricing.setFlgIncrTAT(false);
            }
            objRepairPricing.setIntFutureTAT(eCRDUtil.verifyIntObj(rsRepairPricingDetails.getString("Future_TAT")));
            objRepairPricing.setRepairSeqNo(eCRDUtil.verifyNull(rsRepairPricingDetails.getString("Repair_Seq_No")));
            objRepairPricing.setIntTAT(eCRDUtil.verifyIntObj(rsRepairPricingDetails.getString("Repair_TAT")));
            objRepairPricing.setDtFuturePriceTATEffDt(eCRDUtil.verifyNull(rsRepairPricingDetails.getString("Future_Eff_Date")));
            objRepairPricing.setStrPriceType(eCRDUtil.verifyNull(rsRepairPricingDetails.getString("Price_Type")));
            
			if (rsRepairPricingDetails.getString("price_overwite_ind").equalsIgnoreCase(eCRDConstants.STRTRUE))
			{
				objRepairPricing.setFlgPriceOverWriteInd(true);
			}
			else if (rsRepairPricingDetails.getString("price_overwite_ind").equalsIgnoreCase(eCRDConstants.STRFALSE))
			{
				objRepairPricing.setFlgPriceOverWriteInd(false);
			}
			
            rsChildRepairDetails.setCurrentRow(0); //Set cursor position to start
//          19-05-2006 patni checking null value Begin  
            if (rsChildRepairDetails!=null )
            {
//              19-05-2006 patni checking null value ENd      
            while (rsChildRepairDetails.next())
            {
                objChildRepair = this.addChildRepair();

                objChildRepair.setRepairSeqNo(eCRDUtil.verifyNull(rsChildRepairDetails.getString("Repair_Seq_No")));
                
                objChildRepair.setRepairInd(eCRDUtil.verifyNull(rsChildRepairDetails.getString("Repair_Ind"))); //changes by rishabh mewar
                
                objChildRepair.setStrChildRepairCode(eCRDUtil.verifyNull(rsChildRepairDetails.getString("Repair_Code")));
                objChildRepair.setStrComments(eCRDUtil.verifyNull(rsChildRepairDetails.getString("Repair_Comm")));
                objChildRepair.setStrReapairRefFormat(eCRDUtil.verifyNull(rsChildRepairDetails.getString("Rep_Ref_Format")));
                objChildRepair.setStrRepairRefNo(eCRDUtil.verifyNull(rsChildRepairDetails.getString("Repair_Ref_No")));
                objChildRepair.setStrReapirDesc(eCRDUtil.verifyNull(rsChildRepairDetails.getString("Repair_Desc")));
                // Sushant
                objChildRepair.setStrRDNumber(eCRDUtil.verifyNull(rsChildRepairDetails.getString("RD_NUMBER")));
                objChildRepair.setStrReasonRDOverride(eCRDUtil.verifyNull(rsChildRepairDetails.getString("RD_OVERRIDE_REASON")));            
                objChildRepair.setStrRDAssociation(eCRDUtil.verifyNull(rsChildRepairDetails.getString("RD_ASSOCIATION")));
                objChildRepair.setStrRDNumberComment(eCRDUtil.verifyNull(rsChildRepairDetails.getString("RD_COMMENT")));
                objChildRepair.setStrRDCreationDt(eCRDUtil.verifyNull(rsChildRepairDetails.getString("RD_CREATION_DATE")));
                objChildRepair.setStrRDModifiedDt(eCRDUtil.verifyNull(rsChildRepairDetails.getString("RD_UPDATED_DATE")));
              //DES1146388 SAP flag added by Kumar
                objChildRepair.setStrChildSAPFlag(eCRDUtil.verifyNull(rsChildRepairDetails.getString("Sap_Flag")));
                objChildRepair.setStrChildSAPFeatureQuantity(eCRDUtil.verifyNull(rsChildRepairDetails.getString("Sap_Feature_Quantity")));
                

            }
            } //end if 

            //Populate Repair Site Information
            rsRepairSite.setCurrentRow(0); //Set Cursor position to start
//          19-05-2006 patni checking null value Begin    
            if (rsRepairSite != null)
            {
            while (rsRepairSite.next())
            {
                objECRDRepairSite = this.addECRDRepairSite();
                objECRDRepairSite.setSiteCode(eCRDUtil.verifyNull(rsRepairSite.getString("Location_Id")));
                // objECRDRepairSite.setCM(eCRDUtil.verifyDouble(rsRepairSite.getString("compDescription")));
                objECRDRepairSite.setLaborHr(eCRDUtil.verifyDouble(rsRepairSite.getString("Labour_Hours")));
                strLaboutHr = eCRDUtil.verifyNullReturnZero(rsRepairSite.getString("Labour_Hours"));
                strLocLbrRate = eCRDUtil.verifyNullReturnZero(rsRepairSite.getString("LOC_Labour_rate"));
                strMaterialCost = eCRDUtil.verifyNullReturnZero(rsRepairSite.getString("Material_Cost"));
                dblMaterialCost = Double.parseDouble(strMaterialCost);
                dblLocLabourRate = Double.parseDouble(strLocLbrRate);
                dblLabourHrs = Double.parseDouble(strLaboutHr);

                //Calculate Total Cost = Material Cost + (Labor Hours * Labour Rate)
                dblTotalCost = dblMaterialCost + (dblLocLabourRate * dblLabourHrs);

		if(objRepairPricing.getDblPrice()!=null)
		{
			dblRepairPrice = objRepairPricing.getDblPrice().doubleValue();
		}
		else
		{
			dblRepairPrice =0;
		}

                //Calculate CM% = (price-total cost)/price * 100
                if (dblRepairPrice != 0.0)
                {
                    dblCM = ((dblRepairPrice - dblTotalCost) / (dblRepairPrice)) * 100;
                    objECRDRepairSite.setCM(Double.parseDouble(eCRDUtil.Format(dblCM, 2)));
                }
                else
                {
                    objECRDRepairSite.setCM(0.0);
                }

                objECRDRepairSite.setMaterialCost(eCRDUtil.verifyDouble(rsRepairSite.getString("Material_Cost")));
                objECRDRepairSite.setSiteDescription(eCRDUtil.verifyNull(rsRepairSite.getString("Location_Desc")));
                objECRDRepairSite.setTotalCost(dblTotalCost);
                objECRDRepairSite.setLocationLaborRate(eCRDUtil.verifyDouble(rsRepairSite.getString("LOC_Labour_rate")));
            }
            } //End if 
        }
        finally
        {
            arrlstInpParam = null;
            arrlstOutParam = null;
            strActionId = null;
            strErrorMsg = null;
        }
    }

    /**
    	* Add site to the repair
    	*/
    public eCRDRepairSite addSite()
    {
        eCRDRepairSite objCRDRepairSite = null;
        objCRDRepairSite = addECRDRepairSite();
        return objCRDRepairSite;
    }

    /**
    	* Creates a new child repair and adds it to the arraylist of repairs.
    	* Returns reference to the object so that other parameters could be set.
    	* @param objChildRepair
    	* @return ecrd.biz.eCRDChildRepair
    	*/
    public eCRDChildRepair addChildRepair()
    {

        eCRDChildRepair objECRDChildRepair = null;
        if (arrlstChildRepair == null)
        {
            arrlstChildRepair = new ArrayList();
        }
        objECRDChildRepair = new eCRDChildRepair();
        arrlstChildRepair.add(objECRDChildRepair);
        return objECRDChildRepair;
    }

    /**
    	* Removes all child repairs from  ArrayList of child repairs. Also
    	* removes the child repair from database.
    	*/
    public String removeDeleteRepairs(String strUserId, String strUserRole) throws Exception
    {
        ArrayList arrlstInpParam = null;
        ArrayList arrlstOutParam = null;
        String strActionId = null;
        String strErrorMsg = null;
        eCRDException objException = null;
        eCRDChildRepair objECRDChildRepair = null;
        GEAEResultSet rsChildRepairDetails = null;
        StringBuffer strChildRepairCodesBuff = null;
        eCRDComponent objECRDComponent = null;
        eCRDModule objECRDModule = null;
        eCRDEngineModel objECRDModel = null;
        eCRDCatalog objCataLog = null;

        try
        {
            //Set the action this to call procedure to get child repair details
            strActionId = eCRDConstants.getActionId("eCRD_DELETE_CHILD_REPAIR");
            //ArrayList of Input Parameters
            arrlstInpParam = new ArrayList();
            //ArrayList of Output Parameters
            arrlstOutParam = new ArrayList();

            objECRDComponent = new eCRDComponent();
            objECRDModule = new eCRDModule();
            objECRDModel = new eCRDEngineModel();
            objECRDChildRepair = new eCRDChildRepair();
            strChildRepairCodesBuff = new StringBuffer();
            objECRDComponent = getObjECRDComponent();

            if (objECRDComponent == null)
            {
                objException = new eCRDException();
                objException.setExcpId("COMPONENT_OBJECT_NOT_SET");
                throw objException;
            }

            objECRDModule = objECRDComponent.getModule();
            if (objECRDModule == null)
            {
                objException = new eCRDException();
                objException.setExcpId("MODULE_OBJECT_NOT_SET");
                throw objException;
            }

            objECRDModel = objECRDModule.getEngineModel();

            if (objECRDModel == null)
            {
                objException = new eCRDException();
                objException.setExcpId("MODEL_OBJECT_NOT_SET");
                throw objException;
            }

            objCataLog = objECRDModel.getCatalog();
            if (objCataLog == null)
            {
                objException = new eCRDException();
                objException.setExcpId("CATALOG_OBJECT_NOT_SET");
                throw objException;
            }

            for (int i = 0; i < arrlstChildRepair.size(); i++)
            {
                objECRDChildRepair = (eCRDChildRepair) arrlstChildRepair.get(i);
                strChildRepairCodesBuff.append(objECRDChildRepair.getStrChildRepairCode());
                strChildRepairCodesBuff.append(eCRDConstants.STRCOLUMNDELIM);
            }
            strChildRepairCodesBuff.append(eCRDConstants.STRROWDELIM);

            arrlstInpParam.add(objCataLog.getCatalogSeqId());
            arrlstInpParam.add(strChildRepairCodesBuff.toString());
            arrlstInpParam.add(strUserId);
            arrlstInpParam.add(strUserRole);
            // Call this function to update site details
            arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);
            //Return the message code retrieved from procedure
            strErrorMsg = (String) arrlstOutParam.get(0);

            // set the arrayList to null
            arrlstChildRepair = null;
            return strErrorMsg;
        }

        finally
        {
            arrlstInpParam = null;
            arrlstOutParam = null;
            strActionId = null;
            strErrorMsg = null;
            strChildRepairCodesBuff = null;
            objECRDChildRepair = null;
        }
    }

    /**
     * this method removes the reference of the child repair from the arrayList
     *
     */

    public void removeChildRepair()
    {
        eCRDChildRepair objeCRDChildRepair = null;
        arrlstChildRepair = null;
    }
    /**
    	* Returns list of child repairs based on the child repair sequence id.
    	* @return ArrayList
    	*/
    public ArrayList getChildRepairsList() throws Exception
    {
        ArrayList arrlstInpParam = null;
        ArrayList arrlstOutParam = null;
        String strActionId = null;
        String strErrorMsg = null;
        eCRDChildRepair objECRDChildRepair = null;
        eCRDChildRepair objChildRp = null;
        eCRDException objException = null;
        GEAEResultSet rsChildRepairDetails = null;
        eCRDComponent objECRDComponent = null;
        eCRDModule objECRDModule = null;
        eCRDEngineModel objECRDModel = null;
        eCRDCatalog objCataLog = null;
        String strCatalogSeqId = null;
        try
        {
         System.out.println("getChildRepairsList->01");   
            if (arrlstChildRepair != null)
            {
                return arrlstChildRepair;
            }
            System.out.println("getChildRepairsList->02");
            //Set the action this to call procedure to get child repair details
            strActionId = eCRDConstants.getActionId("eCRD_GET_CHILD_REPAIRS");
            //ArrayList of Input Parameters
            arrlstInpParam = new ArrayList();
            //ArrayList of Output Parameters
            arrlstOutParam = new ArrayList();
            objECRDComponent = new eCRDComponent();
            objECRDModule = new eCRDModule();
            objECRDModel = new eCRDEngineModel();
            objECRDChildRepair = new eCRDChildRepair();

            //Pass procedure input parameters to ArrayList

            objECRDComponent = getObjECRDComponent();
            System.out.println("getChildRepairsList->03");
            
            /*FOR save 502634089 */
            if (objECRDComponent == null)
            {
            	System.out.println("getChildRepairsList->04");
                objException = new eCRDException();
                objException.setExcpId("COMPONENT_OBJECT_NOT_SET");
                throw objException;

            }
            System.out.println("getChildRepairsList->979");
            objECRDModule = objECRDComponent.getModule();
            System.out.println("getChildRepairsList->981");
            if (objECRDModule == null)
            {
            	System.out.println("getChildRepairsList->984");
                objException = new eCRDException();
                objException.setExcpId("MODULE_OBJECT_NOT_SET");
                throw objException;

            }
            objECRDModel = objECRDModule.getEngineModel();
            System.out.println("getChildRepairsList->985");
            if (objECRDModel == null)
            {
            	System.out.println("getChildRepairsList->986");
                objException = new eCRDException();
                objException.setExcpId("MODEL_OBJECT_NOT_SET");
                throw objException;

            }
            System.out.println("getChildRepairsList->987");

            objCataLog = objECRDModel.getCatalog();
            if (objCataLog == null)
            {
            	System.out.println("getChildRepairsList->989");
            	System.out.println("getChildRepairsList->988");
                objException = new eCRDException();
                objException.setExcpId("CATALOG_OBJECT_NOT_SET");
                throw objException;

            }
            System.out.println("getChildRepairsList->1011");
            arrlstInpParam.add(objCataLog.getCatalogSeqId());
            System.out.println("getChildRepairsList->1013");
            // Call this function to update site details
            arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);
            System.out.println("getChildRepairsList->1016");
            //Return the message code retrieved from procedure
            rsChildRepairDetails = (GEAEResultSet) arrlstOutParam.get(0);
            System.out.println("getChildRepairsList->1017");
            rsChildRepairDetails.first();
            rsChildRepairDetails.previous();
//          19-05-2006 patni checking null value Begin 
            if(rsChildRepairDetails!=null)
            {
            	 System.out.println("getChildRepairsList->1018");
//              19-05-2006 patni checking null value End                
            while (rsChildRepairDetails.next())
            {
            	 System.out.println("getChildRepairsList->1019");
                objECRDChildRepair = new eCRDChildRepair();
                objECRDChildRepair.setRepairSeqNo(eCRDUtil.verifyNull(rsChildRepairDetails.getString("compDescription")));
                objECRDChildRepair.setStrChildRepairCode(eCRDUtil.verifyNull(rsChildRepairDetails.getString("compDescription")));
                objECRDChildRepair.setStrComments(eCRDUtil.verifyNull(rsChildRepairDetails.getString("compDescription")));
                objECRDChildRepair.setStrReapairRefFormat(eCRDUtil.verifyNull(rsChildRepairDetails.getString("compDescription")));
                objECRDChildRepair.setStrReapirDesc(eCRDUtil.verifyNull(rsChildRepairDetails.getString("compDescription")));
                objECRDChildRepair.setStrRepairRefNo(eCRDUtil.verifyNull(rsChildRepairDetails.getString("compDescription")));
                System.out.println("getChildRepairsList->1028");
                arrlstChildRepair.add(objECRDChildRepair);
                System.out.println("getChildRepairsList->1031");
            }
            } //end if 
            System.out.println("getChildRepairsList->1034");
            return arrlstChildRepair;
            
        }
        finally
        {
            arrlstInpParam = null;
            arrlstOutParam = null;
            strActionId = null;
            strErrorMsg = null;
        }
    }

    /**
    	* Retruns object of the eCRDChildRepair class which is contained in current
    	* grouped reapir. The object is returned based on child repair code.
    	* @param strReapirCode
    	* @return ecrd.biz.eCRDRepair
    	*/
    public eCRDChildRepair getChildRepair(String strRepairCode) throws Exception
    {

        ArrayList arrlstInpParam = null;
        ArrayList arrlstOutParam = null;
        String strActionId = null;
        String strErrorMsg = null;
        eCRDChildRepair objECRDChildRepair = null;
        eCRDChildRepair objChildRp = null;
        eCRDException objException = null;
        GEAEResultSet rsChildRepairDetails = null;
        eCRDComponent objECRDComponent = null;
        eCRDModule objECRDModule = null;
        eCRDEngineModel objECRDModel = null;
        eCRDCatalog objCataLog = null;

        try
        {
            objECRDChildRepair = new eCRDChildRepair();

            if (this.arrlstChildRepair != null)
            {
                for (int i = 0; i < arrlstChildRepair.size(); i++)
                {
                    objECRDChildRepair = (eCRDChildRepair) arrlstChildRepair.get(i);
                    if (objECRDChildRepair.getStrChildRepairCode().equalsIgnoreCase(strRepairCode))
                    {
                        return objECRDChildRepair;
                    }
                }

            }
            //Set the action this to call procedure to get child repair details
            strActionId = eCRDConstants.getActionId("eCRD_GET_CHILD_REPAIR_DETAILS");
            //ArrayList of Input Parameters
            arrlstInpParam = new ArrayList();
            //ArrayList of Output Parameters
            arrlstOutParam = new ArrayList();

            arrlstOutParam = new ArrayList();

            //Pass procedure input parameters to ArrayList
            if (strRepairCode == null || strRepairCode == "")
            {
                objException = new eCRDException();
                objException.setExcpId("INPUT_PARAMETERS_NOT_SET");
                throw objException;
            }

            objECRDComponent = new eCRDComponent();
            objECRDModule = new eCRDModule();
            objECRDModel = new eCRDEngineModel();

            //Pass procedure input parameters to ArrayList

            objECRDComponent = getObjECRDComponent();
            objECRDModule = objECRDComponent.getModule();
            objECRDModel = objECRDModule.getEngineModel();
            objCataLog = objECRDModel.getCatalog();

            //TBD GET THE CATALOG ID REFERNCE FOR THE REPAIR
            arrlstInpParam.add(objCataLog.getCatalogSeqId());
            arrlstInpParam.add(strRepairCode);
            // Call this function to update site details
            arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);
            //Return the message code retrieved from procedure
            rsChildRepairDetails = (GEAEResultSet) arrlstOutParam.get(0);
            objECRDChildRepair = new eCRDChildRepair();
            rsChildRepairDetails.first();
            rsChildRepairDetails.previous();
            objECRDChildRepair.setRepairSeqNo(eCRDUtil.verifyNull(rsChildRepairDetails.getString("compDescription")));
            objECRDChildRepair.setStrChildRepairCode(eCRDUtil.verifyNull(rsChildRepairDetails.getString("compDescription")));
            objECRDChildRepair.setStrComments(eCRDUtil.verifyNull(rsChildRepairDetails.getString("compDescription")));
            objECRDChildRepair.setStrReapairRefFormat(eCRDUtil.verifyNull(rsChildRepairDetails.getString("compDescription")));
            objECRDChildRepair.setStrReapirDesc(eCRDUtil.verifyNull(rsChildRepairDetails.getString("compDescription")));
            objECRDChildRepair.setStrRepairRefNo(eCRDUtil.verifyNull(rsChildRepairDetails.getString("compDescription")));

            for (int i = 0; i < arrlstChildRepair.size(); i++)
            {
                objChildRp = new eCRDChildRepair();
                objChildRp = (eCRDChildRepair) arrlstChildRepair.get(0);
                if (objChildRp.getStrChildRepairCode().equalsIgnoreCase(strRepairCode))
                {
                    arrlstChildRepair.remove(i);
                    break;
                }
            }
            arrlstChildRepair.add(objECRDChildRepair);
            return objECRDChildRepair;
        }
        finally
        {
            arrlstInpParam = null;
            arrlstOutParam = null;
            strActionId = null;
            strErrorMsg = null;
            objChildRp = null;
        }
    }

    /**
    	* @return boolean
    	*/
    public boolean isCreatedFromMerge()
    {
        /*NOT SURE OF THIS .. NEED TO UNDERSTAND*/
        return true;
    }

    /**
    	* @param flgCreatedFromMerger
    	*/
    public void setCreatedFromMerge(Boolean flgCreatedFromMerger)
    {
        /*NOT SURE OF THIS .. NEED TO UNDERSTAND*/

    }

    /**
    	* 1)Updates the specified repair from the database.
    	* @param strReapirCode
    	* @throws Exception
    	*/
    public String update() throws Exception
    {
        ArrayList arrlstInpParam = null;
        ArrayList arrlstOutParam = null;

        String strActionId = null;
        String strErrorMsg = null;
        String strEngineModule = null;
        eCRDException objException = null;
        ArrayList alChildRepairs = null;
        ArrayList alGrpRepairSites = null;
        eCRDChildRepair objChildRepair = null;
        eCRDRepairSite objRepairSite = null;
        eCRDRepairPricing objRepairPricing = null;
        StringBuffer strRepairBuff = null;
        StringBuffer strRepairSiteBuff = null;
        StringBuffer strChildRepairBuff = null;
        eCRDEngineModel objECRDEngModel = null;
        eCRDCatalog objECRDCatalog = null;
        eCRDComponent ECRDobjComponent = null;
        eCRDModule objECRDModule = null;

        try
        {
            //Set the action this to call procedure to delete the repair
            strActionId = eCRDConstants.getActionId("eCRD_UPDATE_REPAIR");
            //ArrayList of Input Parameters
            arrlstInpParam = new ArrayList();
            //ArrayList of Output Parameters
            arrlstOutParam = new ArrayList();
            alChildRepairs = new ArrayList();
            alGrpRepairSites = new ArrayList();
            strRepairBuff = new StringBuffer();
            objChildRepair = new eCRDChildRepair();
            objRepairPricing = new eCRDRepairPricing();
            strRepairSiteBuff = new StringBuffer();
            strChildRepairBuff = new StringBuffer();
            objException = new eCRDException();

            if (this.getStrRepairCode() == null || this.getStrRepairCode() == "")
            {
                objException = new eCRDException();
                objException.setExcpId("REPAIR_CODE_NOT_SET");
                throw objException;
            }
            ECRDobjComponent = this.getObjECRDComponent();
            objECRDModule = ECRDobjComponent.getModule();
            strEngineModule = objECRDModule.getModuleCode();
            objECRDEngModel = objECRDModule.getEngineModel();
            objECRDCatalog = objECRDEngModel.getCatalog();

            if (objECRDCatalog == null)
            {
                objException = new eCRDException();
                objException.setExcpId("CATALOG_OBJECT_NOT_SET");
                throw objException;
            }

            arrlstInpParam.add(this.getStrRepairCode());
            arrlstInpParam.add(objECRDCatalog.getCatalogSeqId());

            objRepairPricing = this.getObjRepairPricing();
            strRepairBuff.append("#");
            strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
            strRepairBuff.append("#");
            strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
            strRepairBuff.append(getStrRepairDesc());
            strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
            strRepairBuff.append(getStrRepairVolume());
            strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
            strRepairBuff.append(getDtRepairEffDate());
            strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
            strRepairBuff.append(getStrComments());
            strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
            /* SAP columns addition start Kumar */

            strRepairBuff.append(getStrSAPFeatureQuantity());
            strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);

            /* SAP columns addition end*/
            if (objRepairPricing.isFlgIncrTAT())
            {
                strRepairBuff.append(eCRDConstants.STRTRUE);
                strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
            }
            else
            {
                strRepairBuff.append(eCRDConstants.STRFALSE);
                strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
            }

            strRepairBuff.append(objRepairPricing.getIntTAT());
            strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);

            if (objRepairPricing.isFlgIncrPrice())
            {
                strRepairBuff.append(eCRDConstants.STRTRUE);
                strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
            }
            else
            {
                strRepairBuff.append(eCRDConstants.STRFALSE);
                strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
            }
            strRepairBuff.append(objRepairPricing.getDblPrice());
            strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
            strRepairBuff.append(objRepairPricing.getStrPriceType());
            strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
            strRepairBuff.append(objRepairPricing.getDblFuturePrice());
            strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
            strRepairBuff.append(objRepairPricing.getIntFutureTAT());
            strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
            strRepairBuff.append(objRepairPricing.getDtFuturePriceTATEffDt());
            strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
            strRepairBuff.append(eCRDConstants.STRROWDELIM);

            /* get the sites assocated with the group repair.
            	* convert the data assocaited with the sites into
            	* a delimted string
            */

            alGrpRepairSites = this.getArrlstECRDRepairSite();
            for (int j = 0; j < alGrpRepairSites.size(); j++)
            {
                objRepairSite = (eCRDRepairSite) alGrpRepairSites.get(j);
                strRepairSiteBuff.append(objRepairSite.getSiteCode());
                strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                strRepairSiteBuff.append(objRepairSite.getMaterialCost());
                strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                strRepairSiteBuff.append(objRepairSite.getLaborHr());
                strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                strRepairSiteBuff.append("#");
                strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                strRepairSiteBuff.append((String) arrlstInpParam.get(0));
                strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                strRepairBuff.append(eCRDConstants.STRROWDELIM);
            }
            /* get the child repairs associated with the repair
            * convert the data assocaited with the child repair
            * into a delimted string
            */

            alChildRepairs = this.getChildRepairsList();
            for (int k = 0; k < alChildRepairs.size(); k++)
            {
                objChildRepair = (eCRDChildRepair) alChildRepairs.get(k);
                // this is a dummy value so tht the same proc can be used.
                strChildRepairBuff.append("#");
                strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                // this is a dummy value so tht the same proc can be used.
                strChildRepairBuff.append("#");
                strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                strChildRepairBuff.append(objChildRepair.getRepairSeqNo());
                strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                strChildRepairBuff.append(objChildRepair.getStrReapirDesc());
                strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                strChildRepairBuff.append(objChildRepair.getStrRepairRefNo());
                strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                strChildRepairBuff.append(objChildRepair.getStrComments());
                strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                strChildRepairBuff.append(eCRDConstants.STRROWDELIM);
            }
            // Call this function to update site details
            arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);
            //Return the message code retrieved from procedure
            return (String) arrlstOutParam.get(0);
        }
        finally
        {
            arrlstInpParam = null;
            arrlstOutParam = null;
            strActionId = null;
            strErrorMsg = null;
        }

    }
}
