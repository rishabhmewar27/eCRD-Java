 /*
* Module    	    : eCRDIndRepair.java
* Author      	    : PATNI-Offshore
* Project	        : eCRD
* Date Written		: October 2004
* Security	        : Unclassified
* Restrictions		: GE PROPRIETARY INFORMATION, FOR GE USE ONLY
*
*     ****************************************************
*     *  Copyright (2000) with all rights reserved       *
*     *          General Electric Company                *
*     ****************************************************
*
* Description: eCRDBusinessBean is used for getting the GEAE Row Cache Tag
*
* Revision Log  (mm/dd/yy initials description)
* --------------------------------------------------------------
*/
package ecrd.biz;

import java.util.ArrayList;

import ecrd.util.eCRDConstants;
import ecrd.util.eCRDUtil;
import ecrd.exception.eCRDException;
import geae.dao.GEAEResultSet;
import ecrd.common.eCRDDBMediator;

import java.io.Serializable;

import javax.servlet.http.HttpServletRequest;

/**
 * This entiry represent the Individual repair. It is subclass of the eCRDRepair.
 */
public class eCRDIndRepair extends eCRDRepair implements Serializable
{
	
    private String strRepairRefFormat = null;
    private String strRepairRefNo = null;
    private boolean flgIsFromSplit = false;
    private String strMergeSplitSeqId = null;

    /**
     * @return
     */
    public String getRepairRefFormat()
    {
        return strRepairRefFormat;
    }

    /**
     * @param strRepairRefFormat
     */
    public void setRepairRefFormat(String strRepairRefFormat)
    {
        this.strRepairRefFormat = strRepairRefFormat;
    }

    /**
     * @return
     */
    public String getRepairRefNo()
    {
        return strRepairRefNo;
    }

    /**
     * @param strRepairRefNo
     */
    public void setRepairRefNo(String strRepairRefNo)
    {
        this.strRepairRefNo = strRepairRefNo;
    }

    /**
     * Default constructor
     * @param
     */
    public eCRDIndRepair()
    {
    }

    public eCRDIndRepair(String strRepairCode, String strModuleCode, String strComponentCode, String strCatalogSeqId) throws Exception
    {
    	
        ArrayList arrlstInpParam = null;
        ArrayList arrlstOutParam = null;
        String strActionId = null;
        String strLaboutHr = null;
        String strLocLbrRate = null;
        String strMaterialCost = null;
        double dblTotalPr = 0.0;
        double dblCM = 0.0;
        double dblMaterialCost = 0.0;
        double dblLabourHrs = 0.0;
        double dblLocLabourRate = 0.0;
        double dblPrice=0.0;
        eCRDException objException = null;
        GEAEResultSet rsIndRepairDetails = null;
        GEAEResultSet rsRepairPricing = null;
        GEAEResultSet rsRepairSite = null;

        eCRDRepairPricing objRepairPricing = null;
        eCRDRepairSite objECRDRepairSite = null;

        try
        {
        	System.out.println("in ecrdind repair 1:"+strRepairCode);
        	System.out.println("in ecrdind repair 2:"+strModuleCode);
        	System.out.println("in ecrdind repair 3:"+strComponentCode);
        	
            if (strRepairCode == null || strRepairCode.equals(""))
            {
            	System.out.println("in ecrdind repair 3:"+strRepairCode);
                objException = new eCRDException();
                objException.setExcpId("REPAIR_SEQ_ID_NOT_SET");
                throw objException;
            }
            if (strModuleCode == null || strModuleCode.equals(""))
            {
                objException = new eCRDException();
                objException.setExcpId("MODULE_CODE_NOT_SET");
                throw objException;
            }
            if (strComponentCode == null || strComponentCode.equals(""))
            {System.out.println("in ecrdind repair 5:"+strComponentCode);
                objException = new eCRDException();
                objException.setExcpId("COMPONENT_CODE_NOT_SET");
                throw objException;
            }
            if (strCatalogSeqId == null || strCatalogSeqId.equals(""))
            {
                objException = new eCRDException();
                objException.setExcpId("CATALOG_SEQ_ID_NOT_SET");
                throw objException;
            }
            
           
            //				Set the action this to call procedure to get child repair details
				
            strActionId = eCRDConstants.getActionId("eCRD_STG_MAIN_REPAIR_DETAILS");
			
         
           
            //ArrayList of Input Parameters
            arrlstInpParam = new ArrayList();
            //ArrayList of Output Parameters
            arrlstOutParam = new ArrayList();

            arrlstInpParam.add(strRepairCode);
            arrlstInpParam.add(strCatalogSeqId);
            arrlstInpParam.add(strModuleCode);
            arrlstInpParam.add(strComponentCode);
            arrlstInpParam.add("ApprovalQueue");
            
            System.out.println(arrlstInpParam);
            
            arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);
            //Return the message code retrieved from procedure
            
            rsIndRepairDetails = (GEAEResultSet)arrlstOutParam.get(0);
            rsRepairSite = (GEAEResultSet)arrlstOutParam.get(1);
            rsRepairPricing = (GEAEResultSet)arrlstOutParam.get(2);
            this.setIsLastRepair(eCRDUtil.verifyNull((String)arrlstOutParam.get(4)));

            rsIndRepairDetails.setCurrentRow(0);
            rsIndRepairDetails.next();

            rsRepairPricing.setCurrentRow(0);
            rsRepairPricing.next();

            rsRepairSite.setCurrentRow(0);
            rsRepairSite.next();

            // TBD WILL HAVE TO CHANGE THE GETSTRING DEPENDING ON WHAT
            // THE RESULT WILL RETURN WILL DO IT WHEN I WRITE THE PROC
            this.setRepairRefFormat(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Rep_Ref_Format")));
            //this.setCreatedFromSplit(rsIndRepairDetails.getString("compDescription"));
            this.setDtRepairEffDate(rsIndRepairDetails.getString("Repair_Eff_Date"));
            
            this.setRepairInd(rsIndRepairDetails.getString("Repair_Ind")); // changes by rishabh mewar
            
            this.setRepairRefNo(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Repair_Ref")));
            this.setStrComments(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Repair_Comments")));
            this.setStrRapairVolume(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Repair_Volm")));
            this.setStrRepairCode(strRepairCode);
            this.setStrRepairDesc(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Repair_Desc")));
            // Sushant
            this.setStrRDNumber(eCRDUtil.verifyNull(rsIndRepairDetails.getString("RD_NUMBER")));
            System.out.println("set repair description number in ind repair"+eCRDUtil.verifyNull(rsIndRepairDetails.getString("Repair_Desc")));
            this.setStrReasonRDOverride(eCRDUtil.verifyNull(rsIndRepairDetails.getString("RD_OVERRIDE_REASON")));            
            this.setStrRDAssociation(eCRDUtil.verifyNull(rsIndRepairDetails.getString("RD_ASSOCIATION")));
            this.setStrRDNumberComment(eCRDUtil.verifyNull(rsIndRepairDetails.getString("RD_COMMENT")));
            this.setStrRDCreationDt(eCRDUtil.verifyNull(rsIndRepairDetails.getString("RD_CREATION_DATE")));
            this.setStrRDModifiedDt(eCRDUtil.verifyNull(rsIndRepairDetails.getString("RD_UPDATED_DATE")));
            this.setStrNPIClassification(eCRDUtil.verifyNull(rsIndRepairDetails.getString("NPI_CLASSIFICATION")));
            //Sushant
 /*502634089 */
            this.setStrModeOfRepair(eCRDUtil.verifyNull(rsIndRepairDetails.getString("MODE_OF_REPAIR")));
            this.setStrLinkServiceEngineer(eCRDUtil.verifyNull(rsIndRepairDetails.getString("LINK_SERVICE_ENGINEER")));            
            /*added by 502633024*/
            
            this.setStrLevelOfDifficulty(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Level_Of_Difficulty")));
            this.setStrSPADPartPrice(eCRDUtil.verifyNull(rsIndRepairDetails.getString("SPAD_PART_PRICE")));
            this.setStrSPADPartNumber(eCRDUtil.verifyNull(rsIndRepairDetails.getString("SPAD_PART_NUMBER")));
            
            this.setStrRepairFre(eCRDUtil.verifyNull(rsIndRepairDetails.getString("REPAIR_FREQUENCY")));
            this.setStrRationale(eCRDUtil.verifyNull(rsIndRepairDetails.getString("RATIONALE_FOR_CHANGE")));
            this.setStrRepairFlg(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Repair_Flag")));
            
            /* SAP columns addition start Kumar */
            this.setStrSAPFlag(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Sap_Flag")));           
            this.setStrSAPFeatureQuantity(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Sap_Feature_Quantity")));
            /* SAP columns addition end*/
            
            if (rsIndRepairDetails.getString("Repair_Type").equals(eCRDConstants.STRINDIVIDUALREPAIR))
                this.flgIsFromSplit = false;
            else if (rsIndRepairDetails.getString("Repair_Type").equals(eCRDConstants.STRGROUPREPAIR))
                this.flgIsFromSplit = true;

            objRepairPricing = this.addRepairPricing();
            objRepairPricing.setObjCRDRepair(this);
            objRepairPricing.setDblFuturePrice(eCRDUtil.verifyDoubleObj(rsRepairPricing.getString("Future_Price")));
           
            if (rsRepairPricing.getString("Incremantal_Price").equalsIgnoreCase(eCRDConstants.STRTRUE))
            {
                objRepairPricing.setFlgIncrPrice(true);
            }
            else if (rsRepairPricing.getString("Incremantal_Price").equalsIgnoreCase(eCRDConstants.STRFALSE))
            {
                objRepairPricing.setFlgIncrPrice(false);
            }
            
            if (rsRepairPricing.getString("Incremntal_tat_ind").equalsIgnoreCase(eCRDConstants.STRTRUE))
            {
                objRepairPricing.setFlgIncrTAT(true);
            }
            else if (rsRepairPricing.getString("Incremntal_tat_ind").equalsIgnoreCase(eCRDConstants.STRFALSE))
            {
                objRepairPricing.setFlgIncrTAT(false);
            }
            
            objRepairPricing.setDblPrice(eCRDUtil.verifyDoubleObj(rsRepairPricing.getString("Repair_Price")));
            objRepairPricing.setIntFutureTAT(eCRDUtil.verifyIntObj(rsRepairPricing.getString("Future_TAT")));
            objRepairPricing.setRepairSeqNo(strRepairCode);
            objRepairPricing.setIntTAT(eCRDUtil.verifyIntObj(rsRepairPricing.getString("Repair_TAT")));
            objRepairPricing.setDblFuturePrice(eCRDUtil.verifyDoubleObj(rsRepairPricing.getString("Future_Price")));
            objRepairPricing.setStrPriceType(eCRDUtil.verifyNull(rsRepairPricing.getString("Price_Type")));
            objRepairPricing.setRepairSeqNo(eCRDUtil.verifyNull(rsRepairPricing.getString("Repair_Seq_No")));
            
            objRepairPricing.setDtFuturePriceTATEffDt(eCRDUtil.verifyNull(rsRepairPricing.getString("Future_Eff_Date")));
			
            if (rsRepairPricing.getString("price_overwite_ind").equalsIgnoreCase(eCRDConstants.STRTRUE))
			{
				objRepairPricing.setFlgPriceOverWriteInd(true);
			}
			else if (rsRepairPricing.getString("price_overwite_ind").equalsIgnoreCase(eCRDConstants.STRFALSE))
			{
				objRepairPricing.setFlgPriceOverWriteInd(false);
			}
			
            for (int i = 0; i < rsRepairSite.size(); i++, rsRepairSite.next())
            {
                objECRDRepairSite = this.addECRDRepairSite();
                objECRDRepairSite.setSiteCode(eCRDUtil.verifyNull(rsRepairSite.getString("Location_Id")));
                //
                strLaboutHr = eCRDUtil.verifyNullReturnZero(rsRepairSite.getString("Labour_Hours"));
                strLocLbrRate = eCRDUtil.verifyNullReturnZero(rsRepairSite.getString("LOC_Labour_rate"));
                strMaterialCost = eCRDUtil.verifyNullReturnZero(rsRepairSite.getString("Material_Cost"));
                dblMaterialCost = Double.parseDouble(strMaterialCost);
                dblLocLabourRate = Double.parseDouble(strLocLbrRate);
                dblLabourHrs = Double.parseDouble(strLaboutHr);
                dblTotalPr = dblMaterialCost + (dblLocLabourRate * dblLabourHrs);
                
                if(objRepairPricing.getDblPrice()==null)
                {
					dblPrice =0;	
                }
				else
				{
					dblPrice =objRepairPricing.getDblPrice().doubleValue();
				}
                
                if (dblTotalPr != 0.0  && (dblPrice!=0.0))
                {
                    dblCM = ((dblPrice - dblTotalPr) / (dblPrice)) * 100;
                    objECRDRepairSite.setCM(Double.parseDouble(eCRDUtil.verifyNullReturnZero(eCRDUtil.Format(dblCM, 2))));
                }
                else
                {
                    objECRDRepairSite.setCM(0.0);
                }
                
                objECRDRepairSite.setLaborHr(eCRDUtil.verifyDouble(rsRepairSite.getString("Labour_Hours")));
                objECRDRepairSite.setMaterialCost(eCRDUtil.verifyDouble(rsRepairSite.getString("Material_Cost")));
                objECRDRepairSite.setSiteDescription(eCRDUtil.verifyNull(rsRepairSite.getString("Location_Desc")));
                objECRDRepairSite.setTotalCost(dblTotalPr);
                objECRDRepairSite.setLocationLaborRate(eCRDUtil.verifyDouble(rsRepairSite.getString("LOC_Labour_rate")));
            
            }
            
        }
        
        finally
        {
            arrlstInpParam = null;
            arrlstOutParam = null;
            strActionId = null;
        }
        
        
    }
    
    
    

    public eCRDIndRepair(String strRepairCode, String strModuleCode, String strComponentCode, String strCatalogSeqId, String strHndSave,int notRequired) throws Exception
    {
    	System.out.println("in save procedure calling in ind repair");
    	
        ArrayList arrlstInpParam = null;
        ArrayList arrlstOutParam = null;
        String strActionId = null;
        String strLaboutHr = null;
        String strLocLbrRate = null;
        String strMaterialCost = null;
        double dblTotalPr = 0.0;
        double dblCM = 0.0;
        double dblMaterialCost = 0.0;
        double dblLabourHrs = 0.0;
        double dblLocLabourRate = 0.0;
        double dblPrice=0.0;
        eCRDException objException = null;
        GEAEResultSet rsIndRepairDetails = null;
        GEAEResultSet rsRepairPricing = null;
        GEAEResultSet rsRepairSite = null;

        eCRDRepairPricing objRepairPricing = null;
        eCRDRepairSite objECRDRepairSite = null;
        String  hdnStagingHistoryInd="";
        
        try
        {
        	System.out.println("in ecrdind repair 1:"+strRepairCode);
        	System.out.println("in ecrdind repair 2:"+strModuleCode);
        	System.out.println("in ecrdind repair 3:"+strComponentCode);
        	
            if (strRepairCode == null || strRepairCode.equals(""))
            {
            	System.out.println("in ecrdind repair 3:"+strRepairCode);
                objException = new eCRDException();
                objException.setExcpId("REPAIR_SEQ_ID_NOT_SET");
                throw objException;
            }
            if (strModuleCode == null || strModuleCode.equals(""))
            {
                objException = new eCRDException();
                objException.setExcpId("MODULE_CODE_NOT_SET");
                throw objException;
            }
            if (strComponentCode == null || strComponentCode.equals(""))
            {System.out.println("in ecrdind repair 5:"+strComponentCode);
                objException = new eCRDException();
                objException.setExcpId("COMPONENT_CODE_NOT_SET");
                throw objException;
            }
            if (strCatalogSeqId == null || strCatalogSeqId.equals(""))
            {
                objException = new eCRDException();
                objException.setExcpId("CATALOG_SEQ_ID_NOT_SET");
                throw objException;
            }
            
            /*502634089 */
           
            strActionId = eCRDConstants.getActionId("eCRD_STG_MAIN_REPAIR_DETAILS_FOR_SAVE");
			
         
           
            //ArrayList of Input Parameters
            arrlstInpParam = new ArrayList();
            //ArrayList of Output Parameters
            arrlstOutParam = new ArrayList();

            arrlstInpParam.add(strRepairCode);
            arrlstInpParam.add(strCatalogSeqId);
            arrlstInpParam.add(strModuleCode);
            arrlstInpParam.add(strComponentCode);
            /*arrlstInpParam.add("ApprovalQueue");*/
            System.out.println(arrlstInpParam);
            arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);
            //Return the message code retrieved from procedure
            
            rsIndRepairDetails = (GEAEResultSet)arrlstOutParam.get(0);
            rsRepairSite = (GEAEResultSet)arrlstOutParam.get(1);
            rsRepairPricing = (GEAEResultSet)arrlstOutParam.get(2);
           this.setIsLastRepair(eCRDUtil.verifyNull((String)arrlstOutParam.get(4)));

            rsIndRepairDetails.setCurrentRow(0);
            rsIndRepairDetails.next();

            rsRepairPricing.setCurrentRow(0);
            rsRepairPricing.next();

            rsRepairSite.setCurrentRow(0);
            rsRepairSite.next();

            // TBD WILL HAVE TO CHANGE THE GETSTRING DEPENDING ON WHAT
            // THE RESULT WILL RETURN WILL DO IT WHEN I WRITE THE PROC
            this.setRepairRefFormat(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Rep_Ref_Format")));
            //this.setCreatedFromSplit(rsIndRepairDetails.getString("compDescription"));
            this.setDtRepairEffDate(rsIndRepairDetails.getString("Repair_Eff_Date"));
            
            this.setRepairInd(rsIndRepairDetails.getString("Repair_Ind")); // changes by rishabh mewar
            
            this.setRepairRefNo(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Repair_Ref")));
            this.setStrComments(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Repair_Comments")));
            this.setStrRapairVolume(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Repair_Volm")));
            this.setStrRepairCode(strRepairCode);
            this.setStrRepairDesc(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Repair_Desc")));
            System.out.println("set repair description number in ind repair"+eCRDUtil.verifyNull(rsIndRepairDetails.getString("Repair_Desc")));
            // Sushant
            this.setStrRDNumber(eCRDUtil.verifyNull(rsIndRepairDetails.getString("RD_NUMBER")));
            System.out.println("set rd number in ind repair"+eCRDUtil.verifyNull(rsIndRepairDetails.getString("Repair_Desc")));
            this.setStrReasonRDOverride(eCRDUtil.verifyNull(rsIndRepairDetails.getString("RD_OVERRIDE_REASON")));            
            this.setStrRDAssociation(eCRDUtil.verifyNull(rsIndRepairDetails.getString("RD_ASSOCIATION")));
            this.setStrRDNumberComment(eCRDUtil.verifyNull(rsIndRepairDetails.getString("RD_COMMENT")));
            this.setStrRDCreationDt(eCRDUtil.verifyNull(rsIndRepairDetails.getString("RD_CREATION_DATE")));
            this.setStrRDModifiedDt(eCRDUtil.verifyNull(rsIndRepairDetails.getString("RD_UPDATED_DATE")));
            this.setStrNPIClassification(eCRDUtil.verifyNull(rsIndRepairDetails.getString("NPI_CLASSIFICATION")));
            //Sushant
 /*502634089 */
            this.setStrModeOfRepair(eCRDUtil.verifyNull(rsIndRepairDetails.getString("MODE_OF_REPAIR")));
            this.setStrLinkServiceEngineer(eCRDUtil.verifyNull(rsIndRepairDetails.getString("LINK_SERVICE_ENGINEER")));            
            /*added by 502633024*/
            
            this.setStagingInd(eCRDUtil.verifyNull(rsIndRepairDetails.getString("STAGING_IND")));
            this.setRepairSeqid(eCRDUtil.verifyNull(rsIndRepairDetails.getString("repair_seq")));
            System.out.println("in individual repair class staging value:"+eCRDUtil.verifyNull(rsIndRepairDetails.getString("repair_seq")));
            System.out.println("in individual repair class staging value:"+eCRDUtil.verifyNull(rsIndRepairDetails.getString("STAGING_IND")));
            this.setStrLevelOfDifficulty(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Level_Of_Difficulty")));
            this.setStrSPADPartPrice(eCRDUtil.verifyNull(rsIndRepairDetails.getString("SPAD_PART_PRICE")));
            this.setStrSPADPartNumber(eCRDUtil.verifyNull(rsIndRepairDetails.getString("SPAD_PART_NUMBER")));
            
            this.setStrRepairFre(eCRDUtil.verifyNull(rsIndRepairDetails.getString("REPAIR_FREQUENCY")));
            this.setStrRationale(eCRDUtil.verifyNull(rsIndRepairDetails.getString("RATIONALE_FOR_CHANGE")));
            this.setStrRepairFlg(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Repair_Flag")));
            
            
            /* SAP columns addition start Kumar */
            this.setStrSAPFlag(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Sap_Flag")));           
            this.setStrSAPFeatureQuantity(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Sap_Feature_Quantity")));
            /* SAP columns addition end*/
            
            if (rsIndRepairDetails.getString("Repair_Type").equals(eCRDConstants.STRINDIVIDUALREPAIR))
                this.flgIsFromSplit = false;
            else if (rsIndRepairDetails.getString("Repair_Type").equals(eCRDConstants.STRGROUPREPAIR))
                this.flgIsFromSplit = true;

            objRepairPricing = this.addRepairPricing();
            objRepairPricing.setObjCRDRepair(this);
            objRepairPricing.setDblFuturePrice(eCRDUtil.verifyDoubleObj(rsRepairPricing.getString("Future_Price")));
            
            if (rsRepairPricing.getString("Incremantal_Price").equalsIgnoreCase(eCRDConstants.STRTRUE))
            {
                objRepairPricing.setFlgIncrPrice(true);
            }
            else if (rsRepairPricing.getString("Incremantal_Price").equalsIgnoreCase(eCRDConstants.STRFALSE))
            {
                objRepairPricing.setFlgIncrPrice(false);
            }
            
            if (rsRepairPricing.getString("Incremntal_tat_ind").equalsIgnoreCase(eCRDConstants.STRTRUE))
            {
                objRepairPricing.setFlgIncrTAT(true);
            }
            else if (rsRepairPricing.getString("Incremntal_tat_ind").equalsIgnoreCase(eCRDConstants.STRFALSE))
            {
                objRepairPricing.setFlgIncrTAT(false);
            }
            
            objRepairPricing.setDblPrice(eCRDUtil.verifyDoubleObj(rsRepairPricing.getString("Repair_Price")));
            System.out.println("getting Repair_Price details in ind object:"+eCRDUtil.verifyDoubleObj(rsRepairPricing.getString("Repair_Price")));
            objRepairPricing.setIntFutureTAT(eCRDUtil.verifyIntObj(rsRepairPricing.getString("Future_TAT")));
            objRepairPricing.setRepairSeqNo(strRepairCode);
            objRepairPricing.setIntTAT(eCRDUtil.verifyIntObj(rsRepairPricing.getString("Repair_TAT")));
            objRepairPricing.setDblFuturePrice(eCRDUtil.verifyDoubleObj(rsRepairPricing.getString("Future_Price")));
            objRepairPricing.setStrPriceType(eCRDUtil.verifyNull(rsRepairPricing.getString("Price_Type")));
            System.out.println("getting Price_Type details in ind object:"+eCRDUtil.verifyDoubleObj(rsRepairPricing.getString("Repair_Price")));
            objRepairPricing.setRepairSeqNo(eCRDUtil.verifyNull(rsRepairPricing.getString("Repair_Seq_No")));
            
            objRepairPricing.setDtFuturePriceTATEffDt(eCRDUtil.verifyNull(rsRepairPricing.getString("Future_Eff_Date")));
			
            if (rsRepairPricing.getString("price_overwite_ind").equalsIgnoreCase(eCRDConstants.STRTRUE))
			{
				objRepairPricing.setFlgPriceOverWriteInd(true);
			}
			else if (rsRepairPricing.getString("price_overwite_ind").equalsIgnoreCase(eCRDConstants.STRFALSE))
			{
				objRepairPricing.setFlgPriceOverWriteInd(false);
			}
			
            for (int i = 0; i < rsRepairSite.size(); i++, rsRepairSite.next())
            {
                objECRDRepairSite = this.addECRDRepairSite();
                objECRDRepairSite.setSiteCode(eCRDUtil.verifyNull(rsRepairSite.getString("Location_Id")));
                //
                strLaboutHr = eCRDUtil.verifyNullReturnZero(rsRepairSite.getString("Labour_Hours"));
                strLocLbrRate = eCRDUtil.verifyNullReturnZero(rsRepairSite.getString("LOC_Labour_rate"));
                strMaterialCost = eCRDUtil.verifyNullReturnZero(rsRepairSite.getString("Material_Cost"));
                dblMaterialCost = Double.parseDouble(strMaterialCost);
                dblLocLabourRate = Double.parseDouble(strLocLbrRate);
                dblLabourHrs = Double.parseDouble(strLaboutHr);
                dblTotalPr = dblMaterialCost + (dblLocLabourRate * dblLabourHrs);
                if(objRepairPricing.getDblPrice()==null)
                {
					dblPrice =0;	
                }
				else
				{
					dblPrice =objRepairPricing.getDblPrice().doubleValue();
				}
               
                if (dblTotalPr != 0.0  && (dblPrice!=0.0))
                {
                    dblCM = ((dblPrice - dblTotalPr) / (dblPrice)) * 100;
                    objECRDRepairSite.setCM(Double.parseDouble(eCRDUtil.verifyNullReturnZero(eCRDUtil.Format(dblCM, 2))));
                }
                else
                {
                    objECRDRepairSite.setCM(0.0);
                }
                
                objECRDRepairSite.setLaborHr(eCRDUtil.verifyDouble(rsRepairSite.getString("Labour_Hours")));
                objECRDRepairSite.setMaterialCost(eCRDUtil.verifyDouble(rsRepairSite.getString("Material_Cost")));
                objECRDRepairSite.setSiteDescription(eCRDUtil.verifyNull(rsRepairSite.getString("Location_Desc")));
                objECRDRepairSite.setTotalCost(dblTotalPr);
                objECRDRepairSite.setLocationLaborRate(eCRDUtil.verifyDouble(rsRepairSite.getString("LOC_Labour_rate")));
            
            }
            
            
        }
        
        finally
        {
            arrlstInpParam = null;
            arrlstOutParam = null;
            strActionId = null;
        }
    }
    
    
    
    // Adding CSM Queue changes - kumar(502321240)
    public eCRDIndRepair(String strRepairCode, String strModuleCode, String strComponentCode, String strCatalogSeqId,  HttpServletRequest request) throws Exception
    {
    	ArrayList arrlstInpParam = null;
        ArrayList arrlstOutParam = null;
        String strActionId = null;
        String strLaboutHr = null;
        String strLocLbrRate = null;
        String strMaterialCost = null;
        double dblTotalPr = 0.0;
        double dblCM = 0.0;
        double dblMaterialCost = 0.0;
        double dblLabourHrs = 0.0;
        double dblLocLabourRate = 0.0;
        double dblPrice=0.0;
        eCRDException objException = null;
        GEAEResultSet rsIndRepairDetails = null;
        GEAEResultSet rsRepairPricing = null;
        GEAEResultSet rsRepairSite = null;

        eCRDRepairPricing objRepairPricing = null;
        eCRDRepairSite objECRDRepairSite = null;
        
        try
        {
        	//System.out.println("getting queue type in ecrdIndRepair overloaded method: "+request.getParameter("hdnGetRepairDetails"));
            if (strRepairCode == null || strRepairCode.equals(""))
            {
                objException = new eCRDException();
                objException.setExcpId("REPAIR_SEQ_ID_NOT_SET");
                throw objException;
            }
            if (strModuleCode == null || strModuleCode.equals(""))
            {
                objException = new eCRDException();
                objException.setExcpId("MODULE_CODE_NOT_SET");
                throw objException;
            }
            if (strComponentCode == null || strComponentCode.equals(""))
            {
                objException = new eCRDException();
                objException.setExcpId("COMPONENT_CODE_NOT_SET");
                throw objException;
            }
            if (strCatalogSeqId == null || strCatalogSeqId.equals(""))
            {
                objException = new eCRDException();
                objException.setExcpId("CATALOG_SEQ_ID_NOT_SET");
                throw objException;
            }
            // Adding CSM Queue changes - kumar(502321240)
           // repairQueue = eCRDUtil.getFromSession(request, "repairQueue");
           // System.out.println("repairQueue in eCRDIndRepair is: "+repairQueue);
            //				Set the action this to call procedure to get child repair details
            
            /*502634089 */
            strActionId = eCRDConstants.getActionId("eCRD_STG_MAIN_REPAIR_DETAILS");
           
            //ArrayList of Input Parameters
            arrlstInpParam = new ArrayList();
            //ArrayList of Output Parameters
            arrlstOutParam = new ArrayList();

            arrlstInpParam.add(strRepairCode);
            arrlstInpParam.add(strCatalogSeqId);
            arrlstInpParam.add(strModuleCode);
            arrlstInpParam.add(strComponentCode);
            arrlstInpParam.add("CSMQueue");
            
         
            arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);
            //Return the message code retrieved from procedure
            System.out.println("in ind repair rsIndRepairDetails before rsIndRepairDetails ");
            rsIndRepairDetails = (GEAEResultSet)arrlstOutParam.get(0);
            System.out.println("in ind repair rsIndRepairDetails"+rsIndRepairDetails);
            
            rsRepairSite = (GEAEResultSet)arrlstOutParam.get(1);
            rsRepairPricing = (GEAEResultSet)arrlstOutParam.get(2);
            this.setIsLastRepair(eCRDUtil.verifyNull((String)arrlstOutParam.get(4)));

            rsIndRepairDetails.setCurrentRow(0);
            rsIndRepairDetails.next();
            

            rsRepairPricing.setCurrentRow(0);
            rsRepairPricing.next();

            rsRepairSite.setCurrentRow(0);
            rsRepairSite.next();

            // TBD WILL HAVE TO CHANGE THE GETSTRING DEPENDING ON WHAT
            // THE RESULT WILL RETURN WILL DO IT WHEN I WRITE THE PROC
            this.setRepairRefFormat(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Rep_Ref_Format")));
            
           // System.out.println("this.setRepairRefFormat(eCRDUtil.verifyNull(rsIndRepairDetails.getString::"+this.setRepairRefFormat(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Rep_Ref_Format"))));
            
            //this.setCreatedFromSplit(rsIndRepairDetails.getString("compDescription"));
            this.setDtRepairEffDate(rsIndRepairDetails.getString("Repair_Eff_Date"));
            this.setRepairRefNo(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Repair_Ref")));
            
            this.setRepairInd(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Repair_Ind"))); // changes by rishabh mewar
            
            this.setStrComments(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Repair_Comments")));
            this.setStrRapairVolume(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Repair_Volm")));
            this.setStrRepairCode(strRepairCode);
            this.setStrRepairDesc(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Repair_Desc")));
            // Sushant
            this.setStrRDNumber(eCRDUtil.verifyNull(rsIndRepairDetails.getString("RD_NUMBER")));
            this.setStrReasonRDOverride(eCRDUtil.verifyNull(rsIndRepairDetails.getString("RD_OVERRIDE_REASON")));            
            this.setStrRDAssociation(eCRDUtil.verifyNull(rsIndRepairDetails.getString("RD_ASSOCIATION")));
            this.setStrRDNumberComment(eCRDUtil.verifyNull(rsIndRepairDetails.getString("RD_COMMENT")));
            this.setStrRDCreationDt(eCRDUtil.verifyNull(rsIndRepairDetails.getString("RD_CREATION_DATE")));
            this.setStrRDModifiedDt(eCRDUtil.verifyNull(rsIndRepairDetails.getString("RD_UPDATED_DATE")));
            this.setStrNPIClassification(eCRDUtil.verifyNull(rsIndRepairDetails.getString("NPI_CLASSIFICATION")));
            //Sushant
           
            this.setStrModeOfRepair(eCRDUtil.verifyNull(rsIndRepairDetails.getString("MODE_OF_REPAIR")));
            this.setStrLinkServiceEngineer(eCRDUtil.verifyNull(rsIndRepairDetails.getString("LINK_SERVICE_ENGINEER")));
            this.setStrLevelOfDifficulty(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Level_Of_Difficulty")));
            this.setStrSPADPartPrice(eCRDUtil.verifyNull(rsIndRepairDetails.getString("SPAD_PART_PRICE")));
            this.setStrSPADPartNumber(eCRDUtil.verifyNull(rsIndRepairDetails.getString("SPAD_PART_NUMBER")));
            
/*added by 502633024*/
            
            
            this.setStrRepairFre(eCRDUtil.verifyNull(rsIndRepairDetails.getString("REPAIR_FREQUENCY")));
            this.setStrRationale(eCRDUtil.verifyNull(rsIndRepairDetails.getString("RATIONALE_FOR_CHANGE")));
            this.setStrRepairFlg(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Repair_Flag")));
  
            /* SAP columns addition start Kumar */
            this.setStrSAPFlag(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Sap_Flag")));           
            this.setStrSAPFeatureQuantity(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Sap_Feature_Quantity")));
            /* SAP columns addition end*/
            if (rsIndRepairDetails.getString("Repair_Type").equals(eCRDConstants.STRINDIVIDUALREPAIR))
                this.flgIsFromSplit = false;
            else if (rsIndRepairDetails.getString("Repair_Type").equals(eCRDConstants.STRGROUPREPAIR))
                this.flgIsFromSplit = true;

            objRepairPricing = this.addRepairPricing();
            objRepairPricing.setObjCRDRepair(this);
            objRepairPricing.setDblFuturePrice(eCRDUtil.verifyDoubleObj(rsRepairPricing.getString("Future_Price")));
            
            if (rsRepairPricing.getString("Incremantal_Price").equalsIgnoreCase(eCRDConstants.STRTRUE))
            {
                objRepairPricing.setFlgIncrPrice(true);
            }
            else if (rsRepairPricing.getString("Incremantal_Price").equalsIgnoreCase(eCRDConstants.STRFALSE))
            {
                objRepairPricing.setFlgIncrPrice(false);
            }
            
            if (rsRepairPricing.getString("Incremntal_tat_ind").equalsIgnoreCase(eCRDConstants.STRTRUE))
            {
                objRepairPricing.setFlgIncrTAT(true);
            }
            else if (rsRepairPricing.getString("Incremntal_tat_ind").equalsIgnoreCase(eCRDConstants.STRFALSE))
            {
                objRepairPricing.setFlgIncrTAT(false);
            }
            
            objRepairPricing.setDblPrice(eCRDUtil.verifyDoubleObj(rsRepairPricing.getString("Repair_Price")));
            objRepairPricing.setIntFutureTAT(eCRDUtil.verifyIntObj(rsRepairPricing.getString("Future_TAT")));
            objRepairPricing.setRepairSeqNo(strRepairCode);
            objRepairPricing.setIntTAT(eCRDUtil.verifyIntObj(rsRepairPricing.getString("Repair_TAT")));
            objRepairPricing.setDblFuturePrice(eCRDUtil.verifyDoubleObj(rsRepairPricing.getString("Future_Price")));
            objRepairPricing.setStrPriceType(eCRDUtil.verifyNull(rsRepairPricing.getString("Price_Type")));
            objRepairPricing.setRepairSeqNo(eCRDUtil.verifyNull(rsRepairPricing.getString("Repair_Seq_No")));
            
            objRepairPricing.setDtFuturePriceTATEffDt(eCRDUtil.verifyNull(rsRepairPricing.getString("Future_Eff_Date")));
			
            if (rsRepairPricing.getString("price_overwite_ind").equalsIgnoreCase(eCRDConstants.STRTRUE))
			{
				objRepairPricing.setFlgPriceOverWriteInd(true);
			}
			else if (rsRepairPricing.getString("price_overwite_ind").equalsIgnoreCase(eCRDConstants.STRFALSE))
			{
				objRepairPricing.setFlgPriceOverWriteInd(false);
			}
			
            for (int i = 0; i < rsRepairSite.size(); i++, rsRepairSite.next())
            {
                objECRDRepairSite = this.addECRDRepairSite();
                objECRDRepairSite.setSiteCode(eCRDUtil.verifyNull(rsRepairSite.getString("Location_Id")));
                //
                strLaboutHr = eCRDUtil.verifyNullReturnZero(rsRepairSite.getString("Labour_Hours"));
                strLocLbrRate = eCRDUtil.verifyNullReturnZero(rsRepairSite.getString("LOC_Labour_rate"));
                strMaterialCost = eCRDUtil.verifyNullReturnZero(rsRepairSite.getString("Material_Cost"));
                dblMaterialCost = Double.parseDouble(strMaterialCost);
                dblLocLabourRate = Double.parseDouble(strLocLbrRate);
                dblLabourHrs = Double.parseDouble(strLaboutHr);
                dblTotalPr = dblMaterialCost + (dblLocLabourRate * dblLabourHrs);
                
                if(objRepairPricing.getDblPrice()==null)
                {
					dblPrice =0;	
                }
				else
				{
					dblPrice =objRepairPricing.getDblPrice().doubleValue();
				}
                
                if (dblTotalPr != 0.0  && (dblPrice!=0.0))
                {
                    dblCM = ((dblPrice - dblTotalPr) / (dblPrice)) * 100;
                    objECRDRepairSite.setCM(Double.parseDouble(eCRDUtil.verifyNullReturnZero(eCRDUtil.Format(dblCM, 2))));
                }
                else
                {
                    objECRDRepairSite.setCM(0.0);
                }
                
                objECRDRepairSite.setLaborHr(eCRDUtil.verifyDouble(rsRepairSite.getString("Labour_Hours")));
                objECRDRepairSite.setMaterialCost(eCRDUtil.verifyDouble(rsRepairSite.getString("Material_Cost")));
                objECRDRepairSite.setSiteDescription(eCRDUtil.verifyNull(rsRepairSite.getString("Location_Desc")));
                objECRDRepairSite.setTotalCost(dblTotalPr);
                objECRDRepairSite.setLocationLaborRate(eCRDUtil.verifyDouble(rsRepairSite.getString("LOC_Labour_rate")));
            
            }
            
            
            
        }
        
        
        finally
        {
            arrlstInpParam = null;
            arrlstOutParam = null;
            strActionId = null;
        }
        
        
    }
    
    
    
    
    /**
     * Load repair based on the Repair Code
     * @param strReapairCode
     */
    public eCRDIndRepair(String strRepairCode, String strModuleCode, String strComponentCode, String strCatalogSeqId, String strDataFrom) throws Exception
    {
        ArrayList arrlstInpParam = null;
        ArrayList arrlstOutParam = null;
        String strActionId = null;
        String strLaboutHr = null;
        String strLocLbrRate = null;
        String strMaterialCost = null;
        double dblTotalPr;
        double dblCM;
        double dblMaterialCost;
        double dblLabourHrs;
        double dblLocLabourRate;
        eCRDException objException = null;
        GEAEResultSet rsIndRepairDetails = null;
        GEAEResultSet rsRepairPricing = null;
        GEAEResultSet rsRepairSite = null;

        eCRDComponent objECRDComponent = null;
        eCRDModule objECRDModule = null;
        eCRDEngineModel objECRDModel = null;
        eCRDRepairPricing objRepairPricing = null;
        eCRDRepairSite objECRDRepairSite = null;

        try
        {
            if (strRepairCode == null || strRepairCode.equals(""))
            {
                objException = new eCRDException();
                objException.setExcpId("REPAIR_SEQ_ID_NOT_SET");
                throw objException;
            }

            if (strModuleCode == null || strModuleCode.equals(""))
            {
                objException = new eCRDException();
                objException.setExcpId("MODULE_CODE_NOT_SET");
                throw objException;
            }
            if (strComponentCode == null || strComponentCode.equals(""))
            {
                objException = new eCRDException();
                objException.setExcpId("COMPONENT_CODE_NOT_SET");
                throw objException;
            }
            if (strCatalogSeqId == null || strCatalogSeqId.equals(""))
            {
                objException = new eCRDException();
                objException.setExcpId("CATALOG_SEQ_ID_NOT_SET");
                throw objException;
            }
            if (strDataFrom == null || strDataFrom.equals(""))
            {
                objException = new eCRDException();
                objException.setExcpId("PARAMETER_DATA_FROM_NOT_SET");
                throw objException;
            }
            
            //Set the action this to call procedure to get child repair details
            strActionId = eCRDConstants.getActionId("eCRD_REPAIR_DETAILS");
            //ArrayList of Input Parameters
            arrlstInpParam = new ArrayList();
            //ArrayList of Output Parameters
            arrlstOutParam = new ArrayList();

            arrlstInpParam.add(strRepairCode);
            arrlstInpParam.add(strCatalogSeqId);
            arrlstInpParam.add(strModuleCode);
            arrlstInpParam.add(strComponentCode);
            arrlstInpParam.add(strDataFrom);

            // Adding CSM Queue changes - kumar(502321240)
            arrlstInpParam.add("ApprovalQueue");
            
            // Call this function to update site details
            arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);
            //Return the message code retrieved from procedure

            rsIndRepairDetails = (GEAEResultSet)arrlstOutParam.get(0);
            rsRepairSite = (GEAEResultSet)arrlstOutParam.get(1);
            rsRepairPricing = (GEAEResultSet)arrlstOutParam.get(2);
            this.setIsLastRepair(eCRDUtil.verifyNull((String)arrlstOutParam.get(4)));

            rsIndRepairDetails.setCurrentRow(0);
            rsIndRepairDetails.next();

            rsRepairPricing.setCurrentRow(0);
            rsRepairPricing.next();

            rsRepairSite.setCurrentRow(0);
            rsRepairSite.next();

            // TBD WILL HAVE TO CHANGE THE GETSTRING DEPENDING ON WHAT
            // THE RESULT WILL RETURN WILL DO IT WHEN I WRITE THE PROC
            this.setRepairRefFormat(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Rep_Ref_Format")));
            //this.setCreatedFromSplit(rsIndRepairDetails.getString("compDescription"));
            this.setDtRepairEffDate(rsIndRepairDetails.getString("Repair_Eff_Date"));
            
            this.setRepairInd(rsIndRepairDetails.getString("Repair_Ind")); // changes by rishabh mewar
            
            this.setRepairRefNo(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Repair_Ref")));
            this.setStrComments(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Repair_Comments")));
            this.setStrRapairVolume(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Repair_Volm")));
            this.setStrRepairCode(strRepairCode);
            this.setStrRepairDesc(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Repair_Desc")));
            // Sushant
            this.setStrRDNumber(eCRDUtil.verifyNull(rsIndRepairDetails.getString("RD_NUMBER")));
            this.setStrReasonRDOverride(eCRDUtil.verifyNull(rsIndRepairDetails.getString("RD_OVERRIDE_REASON")));            
            this.setStrRDAssociation(eCRDUtil.verifyNull(rsIndRepairDetails.getString("RD_ASSOCIATION")));
            this.setStrRDNumberComment(eCRDUtil.verifyNull(rsIndRepairDetails.getString("RD_COMMENT")));
            this.setStrRDCreationDt(eCRDUtil.verifyNull(rsIndRepairDetails.getString("RD_CREATION_DATE")));
            this.setStrRDModifiedDt(eCRDUtil.verifyNull(rsIndRepairDetails.getString("RD_UPDATED_DATE")));
            this.setStrNPIClassification(eCRDUtil.verifyNull(rsIndRepairDetails.getString("NPI_CLASSIFICATION")));
 /*502634089 */
            this.setStrModeOfRepair(eCRDUtil.verifyNull(rsIndRepairDetails.getString("MODE_OF_REPAIR")));
            this.setStrLinkServiceEngineer(eCRDUtil.verifyNull(rsIndRepairDetails.getString("LINK_SERVICE_ENGINEER")));
                                 
/*added by 502633024*/
            
            
            this.setStrLevelOfDifficulty(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Level_Of_Difficulty")));
            this.setStrSPADPartPrice(eCRDUtil.verifyNull(rsIndRepairDetails.getString("SPAD_PART_PRICE")));
            this.setStrSPADPartNumber(eCRDUtil.verifyNull(rsIndRepairDetails.getString("SPAD_PART_NUMBER")));
            
            this.setStrRepairFre(eCRDUtil.verifyNull(rsIndRepairDetails.getString("REPAIR_FREQUENCY")));
            this.setStrRationale(eCRDUtil.verifyNull(rsIndRepairDetails.getString("RATIONALE_FOR_CHANGE")));
            this.setStrRepairFlg(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Repair_Flag")));
            
   /* SAP columns addition start Kumar */
            this.setStrSAPFlag(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Sap_Flag")));           
            this.setStrSAPFeatureQuantity(eCRDUtil.verifyNull(rsIndRepairDetails.getString("Sap_Feature_Quantity")));
            /* SAP columns addition end*/
            //Sushant
            if (rsIndRepairDetails.getString("Repair_Type").equals(eCRDConstants.STRINDIVIDUALREPAIR))
                this.flgIsFromSplit = false;
            else if (rsIndRepairDetails.getString("Repair_Type").equals(eCRDConstants.STRGROUPREPAIR))
                this.flgIsFromSplit = true;

            
            
            objRepairPricing = this.addRepairPricing();
            objRepairPricing.setObjCRDRepair(this);
            objRepairPricing.setDblFuturePrice(eCRDUtil.verifyDoubleObj(rsRepairPricing.getString("Future_Price")));

            
            
            if (rsRepairPricing.getString("Incremantal_Price").equalsIgnoreCase(eCRDConstants.STRTRUE))
            {
                objRepairPricing.setFlgIncrPrice(true);

            }
            else if (rsRepairPricing.getString("Incremantal_Price").equalsIgnoreCase(eCRDConstants.STRFALSE))
            {
                objRepairPricing.setFlgIncrPrice(false);
            }

            
            if (rsRepairPricing.getString("Incremntal_tat_ind").equalsIgnoreCase(eCRDConstants.STRTRUE))
            {
                objRepairPricing.setFlgIncrTAT(true);
            }
            else if (rsRepairPricing.getString("Incremntal_tat_ind").equalsIgnoreCase(eCRDConstants.STRFALSE))
            {
                objRepairPricing.setFlgIncrTAT(false);
            }
            
            objRepairPricing.setDblPrice(eCRDUtil.verifyDoubleObj(rsRepairPricing.getString("Repair_Price")));
            objRepairPricing.setIntFutureTAT(eCRDUtil.verifyIntObj(rsRepairPricing.getString("Future_TAT")));
			objRepairPricing.setRepairSeqNo(eCRDUtil.verifyNull(rsRepairPricing.getString("Repair_Seq_No")));
            objRepairPricing.setIntTAT(eCRDUtil.verifyIntObj(rsRepairPricing.getString("Repair_TAT")));
            objRepairPricing.setDblFuturePrice(eCRDUtil.verifyDoubleObj(rsRepairPricing.getString("Future_Price")));
            objRepairPricing.setStrPriceType(eCRDUtil.verifyNull(rsRepairPricing.getString("Price_Type")));
            objRepairPricing.setDtFuturePriceTATEffDt(eCRDUtil.verifyNull(rsRepairPricing.getString("Future_Eff_Date")));
            
			if (rsRepairPricing.getString("price_overwite_ind").equalsIgnoreCase(eCRDConstants.STRTRUE))
			{
				objRepairPricing.setFlgPriceOverWriteInd(true);
			}
			else if (rsRepairPricing.getString("price_overwite_ind").equalsIgnoreCase(eCRDConstants.STRFALSE))
			{
				objRepairPricing.setFlgPriceOverWriteInd(false);
			}
            
			
			for (int i = 0; i < rsRepairSite.size(); i++, rsRepairSite.next())
            {
                objECRDRepairSite = this.addECRDRepairSite();
                objECRDRepairSite.setSiteCode(eCRDUtil.verifyNull(rsRepairSite.getString("Location_Id")));
                // objECRDRepairSite.setCM(eCRDUtil.verifyDouble(rsRepairSite.getString("compDescription")));
                strLaboutHr = eCRDUtil.verifyNullReturnZero(rsRepairSite.getString("Labour_Hours"));
                strLocLbrRate = eCRDUtil.verifyNullReturnZero(rsRepairSite.getString("LOC_Labour_rate"));
                strMaterialCost = eCRDUtil.verifyNullReturnZero(rsRepairSite.getString("Material_Cost"));
                dblMaterialCost = eCRDUtil.verifyDouble(strMaterialCost);
                dblLocLabourRate =eCRDUtil.verifyDouble(strLocLbrRate);
                dblLabourHrs = eCRDUtil.verifyDouble(strLaboutHr);
                dblTotalPr = dblMaterialCost + (dblLocLabourRate * dblLabourHrs);
                
                
                if (objRepairPricing.getDblPrice()==null)
                {
					objECRDRepairSite.setCM(0.0);
                    
                }
                else
                {
					dblCM = ((objRepairPricing.getDblPrice().doubleValue()-dblTotalPr ) / (objRepairPricing.getDblPrice().doubleValue())) * 100;
                    if(dblCM == Double.POSITIVE_INFINITY || dblCM == Double.NEGATIVE_INFINITY)    
                    {
                        dblCM = 0.00;
                    }
					objECRDRepairSite.setCM(Double.parseDouble(eCRDUtil.Format(dblCM, 2)));
                }
                objECRDRepairSite.setLaborHr(eCRDUtil.verifyDouble(rsRepairSite.getString("Labour_Hours")));
                objECRDRepairSite.setMaterialCost(eCRDUtil.verifyDouble(rsRepairSite.getString("Material_Cost")));
                objECRDRepairSite.setSiteDescription(eCRDUtil.verifyNull(rsRepairSite.getString("Location_Desc")));
                objECRDRepairSite.setTotalCost(dblTotalPr);
                objECRDRepairSite.setLocationLaborRate(eCRDUtil.verifyDouble(rsRepairSite.getString("LOC_Labour_rate")));
            
            }
			

        }
        
        finally
        {
            arrlstInpParam = null;
            arrlstOutParam = null;
            strActionId = null;
        }
        
        
    }

    
    
    /**
     * Ad's Site to the Repair
     * @param objSite
     */
    public eCRDRepairSite addSite()
    {
        eCRDRepairSite objCRDRepairSite = null;
        objCRDRepairSite = addECRDRepairSite();
        return objCRDRepairSite;
    }

    public void removeSite()
    {
        // dont need this method.component has a method which remoces all sites
    }

    /**
     * Identifies whether the repair is created from a split of repairs.
     * @return boolean
     */
    public boolean isCreatedFromSplit()
    {
        return flgIsFromSplit;
    }

    /**
     * Set this variable if the repair is created from split of a grouped repair.
     * @param flgCreatedFromSplit
     */
    public void setCreatedFromSplit(boolean flgCreatedFromSplit)
    {
        this.flgIsFromSplit = flgCreatedFromSplit;
    }

    /**
    	* @return
    	*/
    public String getMergeSplitSeqId()
    {
        return strMergeSplitSeqId;
    }

    /**
    	* @param string
    	*/
    public void setMergeSplitSeqId(String strSeqId)
    {
        strMergeSplitSeqId = strSeqId;
    }

}
