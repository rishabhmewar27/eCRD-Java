//Source file: D:\\ECRD\\SOURCE CODE\\ecrd\\biz\\eCRDModule.java
/*
* Module    	    : eCRDModule.java
* Author      	    : PATNI-Offshore
* Project	        : eCRD
* Date Written		: October 2004
* Security	        : Unclassified
* Restrictions		: GE PROPRIETARY INFORMATION, FOR GE USE ONLY
*
*     ****************************************************
*     *  Copyright (2000) with all rights reserved       *
*     *          General Electric Company                *
*     ****************************************************
*
* Description: eCRDBusinessBean is used for getting the GEAE Row Cache Tag
*
* Revision Log  (mm/dd/yy initials description)
* --------------------------------------------------------------
*/
package ecrd.biz;

import java.io.Serializable;
import java.util.ArrayList;

import ecrd.common.eCRDDBMediator;
import ecrd.exception.eCRDException;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDUtil;
/**
 * Represent module in the application.
 */
public class eCRDModule implements Serializable
{
	private String strModuleCode = null;
	private String strModuleDesc = null;
	private ArrayList arrlstComponent = null;
	private eCRDEngineModel objeCRDModel = null;

	/**
	 * Constructor with a Parameter. Use this constructor to load data from database
	 * for the passed code.
	 * @param strModule
	 */
	public eCRDModule(String strModule) throws Exception
	{
		ArrayList arrlstDataInParam = null;
		ArrayList arrlstDataOutParam = null;
		String strActionId = "";
		eCRDException objeCRDException = null;
		try
		{
			arrlstDataInParam = new ArrayList();
			arrlstDataOutParam = new ArrayList();
			if (strModule == null || "".equals(strModule))
			{
				objeCRDException = new eCRDException();
				objeCRDException.setExcpId("MODULE_CODE_NULL");
				throw objeCRDException;
			}
			arrlstDataInParam.add(strModule);

			strActionId = eCRDUtil.verifyNull((String) eCRDConstants.getActionId("eCRD_GET_MODULE"));

			arrlstDataOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstDataInParam);

			this.strModuleCode = (String) arrlstDataOutParam.get(0);
			this.strModuleDesc = (String) arrlstDataOutParam.get(1);
		}
		finally
		{
			arrlstDataInParam = null;
			arrlstDataOutParam = null;
		}
	}

	/**
	 * Default Constructor. Blank object is created.
	 */
	public eCRDModule()
	{

	}

	/**
	 * Creates a new record for module in the database. Also stores the related
	 * relations.
	 */
	public void create()
	{

	}

	/**
	 * This will basically call the save or create method of the Component object to
	 * save all the details in the Database.
	 * Details like Component, Repair ,Site and Part Numbers associated with the component
	 */
	public String saveComponent(String strUserId, String strUserRole) throws Exception
	{
		eCRDComponent objeCRDComponent = null;
		String strMessage = "";
		int intarrLstSize = arrlstComponent.size();
		eCRDException objeCRDException = null;
		try
		{
			if (this.strModuleCode == null || "".equals(this.strModuleCode))
			{
				objeCRDException = new eCRDException();
				objeCRDException.setExcpId("MODULE_CODE_NULL");
				throw objeCRDException;
			}
			for (int i = 0; i < intarrLstSize; i++)
			{
				objeCRDComponent = (eCRDComponent) arrlstComponent.get(i);
				strMessage = objeCRDComponent.create(strUserId, strUserRole);
			}
		}
		finally
		{
			objeCRDComponent = null;
			objeCRDException = null;
		}

		return strMessage;
	}

	/**
	 * Removes module and its dependent entities from the database.
	 */
	public String remove() throws Exception
	{
		ArrayList arrlstInData = null;
		ArrayList arrlstOutData = null;
		String strActionId = "";
		String strMessage = "";
		//eCRDModule objeCRDModule = null;
		eCRDException objException = null;

		try
		{
			arrlstInData = new ArrayList();
			arrlstOutData = new ArrayList();

			if (strModuleCode == null || "".equals(strModuleCode))
			{
				objException = new eCRDException();
				objException.setExcpId("SET_PARAMETERS_NULL");
				throw objException;
			}
			arrlstInData.add(strModuleCode);
			strActionId = eCRDConstants.getActionId("eCRD_REMOVE_MODULE");
			// This procedure will delete the modules and all the associated Components,Repairs etc.
			arrlstOutData = eCRDDBMediator.doDBOperation(strActionId, arrlstInData);

			strMessage = (String) arrlstOutData.get(0);

		}
		finally
		{
			arrlstInData = null;
			arrlstOutData = null;
			strActionId = "";
			//objeCRDModule = null;
			objException = null;
		}
		return strMessage;
	}

	/**
	 * Creates a component and Add Component to the component list. Returns reference
	 * to the component , so that all parameters for the component could be set.
	 */
	public eCRDComponent addComponent()
	{
		eCRDComponent objeCRDComponent = new eCRDComponent();
		//This has been commented bcz when we create new component and a new repair than
		// when we click on component tab tban we need to re - initialize the component arraylist.
		//if(this.arrlstComponent == null)
		//{

		this.arrlstComponent = new ArrayList();
		//}

		//objeCRDComponent.setModule(this);
		this.arrlstComponent.add(objeCRDComponent);
		return objeCRDComponent;
	}

	/**
	 * Remove component object from the list of components
	 * @param strCompSeqId
	 */
	public String removeComponent(String strCompSeqId, String strUserId, String strUserRole) throws Exception
	{
		ArrayList arrlstInData = null;
		ArrayList arrlstOutData = null;
		String strMessage = "";
		String strActionId = "";
		String strCatalogSeqId = "";
		String strEngineModelCd = "";
		eCRDException objeCRDException = null;
		eCRDComponent objeCRDComponent = null;
		try
		{
			arrlstInData = new ArrayList();
			arrlstOutData = new ArrayList();
			strEngineModelCd = this.objeCRDModel.getEngineModelCode();
			strCatalogSeqId = this.objeCRDModel.getCatalog().getCatalogSeqId() + "";
			if (strUserId == null
				|| "".equals(strUserId)
				|| strCatalogSeqId == null
				|| "".equals(strCatalogSeqId)
				|| strModuleCode == null
				|| "".equals(strModuleCode)
				|| strUserRole == null
				|| "".equals(strUserRole)
				|| strCompSeqId == null
				|| "".equals(strCompSeqId)
				|| strEngineModelCd == null
				|| "".equals(strEngineModelCd))
			{
				objeCRDException = new eCRDException();
				objeCRDException.setExcpId("SET_PARAMETERS_NULL");
				throw objeCRDException;
			}
			strActionId = eCRDConstants.getActionId("eCRD_REMOVE_COMPONENT");
			arrlstInData.add(strCompSeqId);
			arrlstInData.add(strEngineModelCd);
			arrlstInData.add(this.strModuleCode);
			//arrlstInData.add(strCatalogSeqId);
			arrlstInData.add(strUserId);
			arrlstInData.add(strUserRole);

			// This will delete all the repairs and all the Data releated to this Component
			arrlstOutData = eCRDDBMediator.doDBOperation(strActionId, arrlstInData);

			strMessage = (String) arrlstOutData.get(0);
			if ("COMP_REMOVE_SUCCESS".equals(strMessage))
			{
				for (int i = 0; i < arrlstComponent.size(); i++)
				{
					objeCRDComponent = (eCRDComponent) arrlstComponent.get(i);
					if (strCompSeqId.equals(objeCRDComponent.getComponentCode()))
					{
						arrlstComponent.remove(i);
					}
				}
			}
			return strMessage;
		}
		finally
		{
			arrlstInData = null;
			arrlstOutData = null;
			strActionId = "";
			strEngineModelCd = "";
			strCatalogSeqId = "";
			objeCRDException = null;
			objeCRDComponent = null;
		}
	}

	/**
	 * Update the component details for the component whose sequence id is passed.
	 * @param strCompSeqId
	 */
	public String updateComponent(String strCompSeqId, String strUserId, String strUserRole) throws Exception
	{
		ArrayList arrlstInData = null;
		ArrayList arrlstOutData = null;
		eCRDComponent objeCRDComponent = null;
		int intComponent = this.arrlstComponent.size();
		String strComponentCode = "";
		String strComponentDesc = "";
		String strATANumber = "";
		String strBaseLineATA = "";
		String strCompEffectiveDate = "";
		String strQtyPerSet = "";
		String strCompShopVisitExpRate = "";
		String strCompScrapExpRate = "";
		String strServiceExpRate = "";
		String strYieldRate = "";
		String strClass = "";
		String strSite = "";
		String strPartNumber = "";
		String strActionId = "";
		String strMessage = "";
		eCRDException objeCRDException = null;
		try
		{
			arrlstInData = new ArrayList();
			arrlstOutData = new ArrayList();
			if (strUserId == null
				|| "".equals(strUserId)
				|| this.strModuleCode == null
				|| "".equals(this.strModuleCode)
				|| strUserRole == null
				|| "".equals(strUserRole)
				|| strCompSeqId == null
				|| "".equals(strCompSeqId))
			{
				objeCRDException = new eCRDException();
				objeCRDException.setExcpId("SET_PARAMETERS_NULL");
				throw objeCRDException;
			}
			for (int i = 0; i < intComponent; i++)
			{
				objeCRDComponent = (eCRDComponent) arrlstComponent.get(i);
				if (strCompSeqId.equals(objeCRDComponent.getComponentCode()))
					break;
			}
			strComponentCode = objeCRDComponent.getComponentCode();
			strComponentDesc = objeCRDComponent.getComponentDesc();
			strATANumber = objeCRDComponent.getATARefNo();
			strBaseLineATA = objeCRDComponent.getBaseLineTAT();
			//strCompEffectiveDate = objeCRDComponent.getComponentEffDt();
			strQtyPerSet = objeCRDComponent.getQtyCompPerEngine();
			strCompShopVisitExpRate = objeCRDComponent.getShopVisitExposureRate();
			strCompScrapExpRate = objeCRDComponent.getScrapRateAtExposure();
			strServiceExpRate = objeCRDComponent.getServicableAtExposure();
			strYieldRate = objeCRDComponent.getPercentageYield();
			strClass = objeCRDComponent.getCycValClass();
			/*strSite = "";
			strPartNumber = objeCRDComponent.getPart();*/

			arrlstInData.add(strComponentCode);
			arrlstInData.add(strComponentDesc);
			arrlstInData.add(strATANumber);
			arrlstInData.add(strBaseLineATA);
			arrlstInData.add(strCompEffectiveDate);
			arrlstInData.add(strQtyPerSet);
			arrlstInData.add(strCompShopVisitExpRate);
			arrlstInData.add(strCompScrapExpRate);
			arrlstInData.add(strServiceExpRate);
			arrlstInData.add(strYieldRate);
			arrlstInData.add(strClass);
			arrlstInData.add(strSite);
			arrlstInData.add(strPartNumber);
			arrlstInData.add(strUserId);
			arrlstInData.add(strUserRole);
			arrlstInData.add(this.strModuleCode);

			strActionId = eCRDConstants.getActionId("eCRD_UPDATE_COMPONENT");

			arrlstOutData = eCRDDBMediator.doDBOperation(strActionId, arrlstInData);

			strMessage = (String) arrlstOutData.get(0);



		}
		finally
		{
			arrlstInData = null;
			arrlstOutData = null;
			objeCRDComponent = null;
			strComponentCode = null;
			strComponentDesc =null;
			strATANumber = null;
			strBaseLineATA = null;
			strCompEffectiveDate =null;
			strQtyPerSet =null;
			strCompShopVisitExpRate = null;
			strCompScrapExpRate = null;
			strServiceExpRate = null;
			strYieldRate =null;
			strClass = null;
			strSite = null;
			strPartNumber = null;
			strActionId = null;
			objeCRDException = null;
		}
		return strMessage;
	}

	/**
	 * Escalate all prices by a percentage. The prices could be increased or decreased.
	 * @param strChageType - Indicates whether the prices are going to increase or
	 * decrease.
	 * Increase : I
	 * Decrease : D
	 * @param dblPercentage - Percentage Increase or decrease.
	 * @param dtEffectiveDate - Effective date for price change
	 * returns String
	 */
	public String adjustPrices(String strChageType, double dblPercentage, String strEffectiveDate) throws Exception
	{
		ArrayList arrlstInData = null;
		ArrayList arrlstOutData = null;
		String strMessage = "";
		String strActionId = "";
		eCRDException objeCRDException = null;

		try
		{
			arrlstInData = new ArrayList();
			arrlstOutData = new ArrayList();
			if (strChageType == null || "".equals(strChageType) || dblPercentage == 0 || strEffectiveDate == null || "".equals(strEffectiveDate))
			{
				objeCRDException = new eCRDException();
				objeCRDException.setExcpId("SET_PARAMETERS_NULL");
				throw objeCRDException;
			}
			arrlstInData.add(strChageType);
			arrlstInData.add(dblPercentage + "");
			arrlstInData.add(strEffectiveDate);

			strActionId = eCRDConstants.getActionId("eCRD_ESCALATE_PRICES");

			arrlstOutData = eCRDDBMediator.doDBOperation(strActionId, arrlstInData);

			strMessage = (String) arrlstOutData.get(0);
		}
		finally
		{
			arrlstInData = null;
			arrlstOutData = null;
			strActionId =  null;
			objeCRDException = null;
		}
		return strMessage;
	}

	/**
		* Gets the Module Desc.
		* @return strModuleDesc
		*/
	public String getModuleDesc()
	{
		return strModuleDesc;
	}

	/**
		* Gets the Module Code.
		* @return strModuleCode
		*/
	public String getModuleCode()
	{
		return strModuleCode;
	}

	/**
	 * Get list of components in ArrayList format. Objects of eCRDComponent with
	 * component sequence id are loaded.
	 * @return ArrayList

	public ArrayList getComponentList()
	{
	 return null;
	}*/

	/**
	 * Returns fully loaded component object.
	 * If the object is not in ArrayList call constructor with parameters and load the
	 * object and add it to the ArrayList.
	 * If the component object is in ArrayList and partially loaded then calls
	 * constructor with parameters for the component object and assigns new object to
	 * the exisitng reference.
	 * @param strCompSeqId
	 * @return ecrd.biz.eCRDComponent
	 */
	public eCRDComponent getComponent(String strCompSeqId) throws Exception
	{
		eCRDComponent objeCRDComponent = null;
		int intComponent = 0;
		boolean blnFound = false;
		eCRDException objeCRDException = null;
		try
		{
			if (strCompSeqId == null || "".equals(strCompSeqId) || this.strModuleCode == null || "".equals(this.strModuleCode))
			{
				objeCRDException = new eCRDException();
				objeCRDException.setExcpId("SET_PARAMETERS_NULL");
				throw objeCRDException;
			}
			if (this.arrlstComponent != null)
			{
				intComponent = this.arrlstComponent.size();
				for (int i = 0; i < intComponent; i++)
				{
					objeCRDComponent = (eCRDComponent) arrlstComponent.get(i);
					if (strCompSeqId.equalsIgnoreCase(objeCRDComponent.getComponentCode()))
					{
						//arrlstComponent.add(objeCRDComponent);

						blnFound = true;
						break;
					}
				}
			}
			else
			{
				this.arrlstComponent = new ArrayList();
			}
			if (!blnFound)
			{
				objeCRDComponent = new eCRDComponent(strCompSeqId.toUpperCase(), this.strModuleCode);
				objeCRDComponent.setModule(this);
				arrlstComponent.add(objeCRDComponent);
			}
			return objeCRDComponent;
		}
		finally
		{
			intComponent = 0;
			blnFound = false;
			objeCRDException = null;
		}

	}

	/**
	 * Sets the Module Desc
	 * @param strModuleDesc
	 */
	public void setModuleDesc(String strModuleDesc)
	{
		this.strModuleDesc = strModuleDesc;
	}

	/**
		* Sets the Module Code
		* @param strModuleCode
		*/
	public void setModuleCode(String strModuleCode)
	{
		this.strModuleCode = strModuleCode;
	}

	public String Update(String strUserId) throws Exception
	{
		String strMessage = "";
		ArrayList arrlstInData = null;
		ArrayList arrlstOutData = null;
		String strActionId = "";
		//String strEngineModel = "";
		eCRDException objeCRDException = null;
		try
		{
			arrlstInData = new ArrayList();
			arrlstOutData = new ArrayList();
			//strEngineModel = this.objeCRDModel.getEngineModelCode();
			if (strModuleCode == null || "".equals(strModuleCode) || strModuleDesc == null || "".equals(strModuleDesc))
			{
				objeCRDException = new eCRDException();
				objeCRDException.setExcpId("SET_PARAMETERS_NULL");
				throw objeCRDException;
			}
			// The Procedure will just Update the Description for
			strActionId = eCRDConstants.getActionId("eCRD_UPDATE_MODULE");
			//arrlstInData.add(strEngineModel);
			arrlstInData.add(this.strModuleCode);
			arrlstInData.add(this.strModuleDesc);
			arrlstInData.add(strUserId);
			arrlstOutData = eCRDDBMediator.doDBOperation(strActionId, arrlstInData);

			strMessage = (String) arrlstOutData.get(0);
		}
		finally
		{
			arrlstInData = null;
			arrlstOutData = null;
			strActionId =null;
			//strEngineModel="";
			objeCRDException = null;
		}
		return strMessage;
	}

	/**
	 * Sets the Enigne Model Object
		* @param objeCRDModel
		*/
	public void setEngineModel(eCRDEngineModel objeCRDModel)
	{
		this.objeCRDModel = objeCRDModel;
	}

	/**
		* Gets the Engine Model object.
		* @return eCRDEngineModel
		*/
	public eCRDEngineModel getEngineModel()
	{
		return this.objeCRDModel;
	}
	public String updateClassifyCompList(String strUserId,String strActionId,String strCompClassList) throws Exception
	{
		String strMessage = "";
		ArrayList arrlstInData = null;
		ArrayList arrlstOutData = null;
			
		eCRDException objeCRDException = null;
		try
		{
			arrlstInData = new ArrayList();
			arrlstOutData = new ArrayList();
			
			if (strModuleCode == null || "".equals(strModuleCode) || strModuleDesc == null || "".equals(strModuleDesc))
			{
				objeCRDException = new eCRDException();
				objeCRDException.setExcpId("SET_PARAMETERS_NULL");
				throw objeCRDException;
			}
		
			arrlstInData.add(this.strModuleCode);
			arrlstInData.add(strUserId);
			arrlstInData.add(strCompClassList);
			arrlstOutData = eCRDDBMediator.doDBOperation(strActionId, arrlstInData);

			strMessage = (String) arrlstOutData.get(0);
		}
		finally
		{
			arrlstInData = null;
			arrlstOutData = null;
			strActionId =null;
			objeCRDException = null;
		}
		return strMessage;
	}
}
