//Source file: D:\\ECRD\\SOURCE CODE\\ecrd\\biz\\eCRDNotificationGroup.java
/*
* Module    	    : eCRDBusinessBean.java
* Author      	    : PATNI-Offshore
* Project	        : eCRD
* Date Written		: October 2004
* Security	        : Unclassified
* Restrictions		: GE PROPRIETARY INFORMATION, FOR GE USE ONLY
*
*     ****************************************************
*     *  Copyright (2000) with all rights reserved       *
*     *          General Electric Company                *
*     ****************************************************
*
* Description: eCRDBusinessBean is used for getting the GEAE Row Cache Tag
*
* Revision Log  (mm/dd/yy initials description)
* --------------------------------------------------------------
*/
package ecrd.biz;

import java.util.ArrayList;
import java.util.HashMap;


/**
 * Entity represents notification group.
 */
public class eCRDNotificationGroup 
{
   private String strEMailGroupCode = null;
   
   /**
    * Hash map of user e-mail ids. Key would be user id.
    */
   private HashMap hmUserId = null;
   
   /**
    * Hashmap of events. Key would be event code.
    */
   private ArrayList hmEvents = null;
   
   /**
    * Constructor with parameter to laod notification group related data.
    * @param strGroupCode
    */
   public eCRDNotificationGroup(String strGroupCode) 
   {
    
   }
   
   public eCRDNotificationGroup() 
   {
    
   }
   
   /**
    * Add User to the notification group.
    * @param strUserId
    * @param strEMailId
    */
   public void addUser(String strUserId, String strEMailId) 
   {
    
   }
   
   /**
    * Remove User from the notification group.
    * @param strUserId
    */
   public void removeUser(String strUserId) 
   {
    
   }
   
   /**
    * Add events for the Notification Group.
    * @param strEventCode
    */
   public void addEvent(String strEventCode) 
   {
    
   }
   
   /**
    * Remove event from the notification group.
    * @param strEvent
    */
   public void removeEvent(String strEvent) 
   {
    
   }
}
