//Source file: D:\\ECRD\\SOURCE CODE\\ecrd\\biz\\eCRDPart.java
/*
* Module    	    : eCRDBusinessBean.java
* Author      	    : PATNI-Offshore
* Project	        : eCRD
* Date Written		: October 2004
* Security	        : Unclassified
* Restrictions		: GE PROPRIETARY INFORMATION, FOR GE USE ONLY
*
*     ****************************************************
*     *  Copyright (2000) with all rights reserved       *
*     *          General Electric Company                *
*     ****************************************************
*
* Description: eCRDBusinessBean is used for getting the GEAE Row Cache Tag
*
* Revision Log  (mm/dd/yy initials description)
* --------------------------------------------------------------
*/
package ecrd.biz;



/**
 * This entity represents Part for a component in the application.
 */
public class eCRDPart 
{
   private String strPartNo = null;
   private int intPartSeqNo = 0;
   
   /**
    * Deafult Constructor
    */
   public eCRDPart() 
   {
    
   }
   
   public void setPartSeqNo() 
   {
    
   }
   
   public void getPartSeqNo() 
   {
    
   }
   
   /**
    * @return String
    */
   public String getPartNo() 
   {
    return null;
   }
   
   public void setPartNo() 
   {
    
   }
}
