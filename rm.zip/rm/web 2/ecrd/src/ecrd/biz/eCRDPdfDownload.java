/**
 * 
 */
package ecrd.biz;

import imcs.bean.IMCSComponentRepairBean;
import imcs.constants.IMCSCREndPage;
import imcs.constants.IMCSSystemConstant;
import imcs.dao.IMCSComponentRepairDAO;
import imcs.utilities.IMCSUtility;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Font;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

import ecrd.util.eCRDConstants;
import ecrd.util.eCRDUtil;

/**
 * @author 226855
 *
 */
public class eCRDPdfDownload {

	/**
	 * 
	 */
	public eCRDPdfDownload() {
		super();
		docWriter = null;
	}

	Font geINSPIRA12;

	Font geINSPIRA11;

	Font geINSPIRA9B;

	Font geINSPIRA8;

	Font geINSPIRA6;
	
	Font geINSPIRA8B;

	Font geINSPIRA8W;

	Font geINSPIRA12G;

	Font geINSPIRA14B;

	Font geINSPIRA40B;

	Font GEInspira18B;
	Font GEInspira18BG;
	Font GEInspira48B;
	Font GEInspira16B;
	Font GEInspira18;
	Font GEInspira16 = null;
	Font GEInspira12 = null;
	Font GEInspira10 = null;
	
	Font GEInspira24B = null;
	
	BaseFont bfGEInspRg;

	Document document = null;
	
	PdfWriter docWriter = null;
	
	public ByteArrayOutputStream getPDFReport(HttpServletRequest request) throws Exception
	{
		ByteArrayOutputStream baosPDF = null;
		
		ArrayList arrlstOutParam = new ArrayList();
		ArrayList arrlstInParam = new ArrayList();
		ArrayList rsCatalog = null;
		ArrayList rsCatalogCols = null;
		ArrayList rsChildRepairCatalogs = null;
		ArrayList rsChildRepairCatalogsCols = null;
		
		String strCatalogId = null;
		String strEngine = null;
		String strYear = null;
		String strRprEffDate = null;
		String strActionId;
		
		PdfPTable pdfTable = null;
		PdfPCell cellData = null;
		String strImagePath = null;
		Image GEImage = null;
		int numColumns = 0;
		float gutter = 0;
		float fullWidth = 0;
		float columnWidth = 0;
		
		try
		{
			System.out.println("-----------getPDFReport-------------");
			baosPDF = new ByteArrayOutputStream();
			document = new Document();
			document.setPageSize(PageSize.LETTER);
			docWriter = PdfWriter.getInstance(document, baosPDF);
	//		document.setMargins(30, 30, 20, 45);
	//		setFonts();
			document.open();
			
			strCatalogId = eCRDUtil.verifyNull(request.getParameter("hdnCatalogValue"));
			strEngine = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, "Engine"));
			strActionId = eCRDConstants.getActionId("eCRD_DOWNLOAD_EXCEL");
			strRprEffDate = eCRDUtil.verifyNull(request.getParameter("hdnRprEffDate"));
			
			arrlstInParam.add(strCatalogId);
//			Start For Repair Effective Date on 08Nov2005 By Rajiv
			            arrlstInParam.add(strRprEffDate);
//			End For Repair Effective Date on 08Nov2005 By Rajiv
			            
			System.out.println("strCatalogId = " + strCatalogId);
			System.out.println("strEngine = " + strEngine);
			System.out.println("strRprEffDate = " + strRprEffDate);
			// Hitting the Database and getting the details for that Catalog.
			IMCSComponentRepairDAO imcsDAO = new IMCSComponentRepairDAO();
			arrlstOutParam = imcsDAO.getCompRepairDetailsWeb(strActionId, arrlstInParam);
			System.out.println("arrlstOutParam = " + arrlstOutParam.size());
			rsCatalog = (ArrayList) arrlstOutParam.get(0);
			rsCatalogCols = (ArrayList) arrlstOutParam.get(1);
			rsChildRepairCatalogs = (ArrayList) arrlstOutParam.get(2);
			rsChildRepairCatalogsCols = (ArrayList) arrlstOutParam.get(3);
			// TODO: Change strYear
			strYear = (String) arrlstOutParam.get(4);
			System.out.println("rsCatalog = " + rsCatalog.size());
			System.out.println("rsChildRepairCatalogs = " + rsChildRepairCatalogs.size());
			System.out.println("strYear = " + strYear);

			document.setMargins(10, 10, 10, 15);

			setFonts();

			gutter = 0;
			numColumns = 1;
			fullWidth = document.right() - document.left();
			columnWidth = (fullWidth - (numColumns - 1) * gutter) / numColumns;
			pdfTable = new PdfPTable(new float[] {(columnWidth*0.085f),(columnWidth*0.915f)});
	//		pdfTable = new PdfPTable(2);
			pdfTable.setWidthPercentage(100);
			pdfTable.setExtendLastRow(true);
			
			cellData = new PdfPCell(new Phrase("GE Aviation", GEInspira18));
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setColspan(2);
			cellData.setBorder(Rectangle.BOX);
			cellData.setBorderWidth(1);
			cellData.setBorderColor(Color.WHITE);
			pdfTable.addCell(cellData);
			cellData = null;
			
			cellData = new PdfPCell(new Phrase("", GEInspira12));
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setFixedHeight(40F);
			cellData.setColspan(2);
	//		cellData.setBorder(Rectangle.BOX);
	//		cellData.setBorderWidth(1);
			cellData.setBorderColor(Color.WHITE);
			pdfTable.addCell(cellData);
			cellData = null;
			
			cellData = new PdfPCell(new Phrase("", GEInspira16));
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setHorizontalAlignment(Rectangle.ALIGN_RIGHT);
	//		cellData.setFixedHeight(20F);
	//		cellData.setColspan(2);
			cellData.setBorder(Rectangle.BOX);
			cellData.setBorderWidth(1);
			cellData.setBorderColor(Color.WHITE);
			pdfTable.addCell(cellData);
			cellData = null;
			
			cellData = new PdfPCell(new Phrase(IMCSSystemConstant.COMP_REP_TITLE_TEXT_1, GEInspira16B));
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setPaddingLeft(320f);
			cellData.setHorizontalAlignment(Rectangle.ALIGN_LEFT);
			cellData.setLeading(1,1);
	//		cellData.setFixedHeight(20F);
	//		cellData.setColspan(2);
			cellData.setBorder(Rectangle.BOX);
			cellData.setBorderWidth(1);
			cellData.setBorderColor(Color.WHITE);
			pdfTable.addCell(cellData);
			cellData = null;
			
			cellData = new PdfPCell(new Phrase("", GEInspira16));
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setHorizontalAlignment(Rectangle.ALIGN_RIGHT);
	//		cellData.setFixedHeight(20F);
	//		cellData.setColspan(2);
			cellData.setBorder(Rectangle.BOX);
			cellData.setBorderWidth(1);
			cellData.setBorderColor(Color.WHITE);
			pdfTable.addCell(cellData);
			cellData = null;
			
			cellData = new PdfPCell(new Phrase(IMCSSystemConstant.COMP_REP_TITLE_TEXT_2, geINSPIRA8));
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setPaddingLeft(320f);
			cellData.setLeading(1.5f,1.5f);
			cellData.setHorizontalAlignment(Rectangle.ALIGN_LEFT);
	//		cellData.setFixedHeight(20F);
	//		cellData.setColspan(2);
			cellData.setBorder(Rectangle.BOX);
			cellData.setBorderWidth(1);
			cellData.setBorderColor(Color.WHITE);
			pdfTable.addCell(cellData);
			cellData = null;
			
			cellData = new PdfPCell(new Phrase("", GEInspira16));
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setHorizontalAlignment(Rectangle.ALIGN_LEFT);
	//		cellData.setFixedHeight(20F);
	//		cellData.setColspan(2);
			cellData.setBorder(Rectangle.BOX);
			cellData.setBorderWidth(1);
			cellData.setBorderColor(Color.WHITE);
			pdfTable.addCell(cellData);
			cellData = null;
			
			cellData = new PdfPCell(new Phrase("Issued: January 1, " + strYear, geINSPIRA8B));
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setPaddingLeft(320f);
			cellData.setHorizontalAlignment(Rectangle.ALIGN_LEFT);
	//		cellData.setFixedHeight(20F);
	//		cellData.setColspan(2);
			cellData.setBorder(Rectangle.BOX);
			cellData.setBorderWidth(1);
			cellData.setBorderColor(Color.WHITE);
			pdfTable.addCell(cellData);
			cellData = null;
			
			
//beginning_rishabh_pdf_tm
			
          	if ( strEngine.contains("GE Passport"))
          	{
          		strEngine = strEngine.replace("GE Passport","GE Passport\u2122");
          		cellData = new PdfPCell(new Phrase(strEngine, geINSPIRA40B));
          	}
          	
          	else 
          	{
          		cellData = new PdfPCell(new Phrase(strEngine, geINSPIRA40B));
          	}
          	
      	//ending_rishabh_pdf_tm
			
			
			//cellData = new PdfPCell(new Phrase(strEngine, GEInspira48B));
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setFixedHeight(180F);
			cellData.setColspan(2);
			cellData.setBorder(Rectangle.BOX);
			cellData.setBorderWidth(1);
			cellData.setBorderColor(Color.WHITE);
			cellData.setVerticalAlignment(PdfPCell.ALIGN_BOTTOM);
			cellData.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
			pdfTable.addCell(cellData);
			cellData = null;
			
			cellData = new PdfPCell(new Phrase("",GEInspira18BG));
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setFixedHeight(15F);
			cellData.setBorder(Rectangle.BOX);
			cellData.setBorderWidth(1);
			cellData.setBorderColor(Color.WHITE);
			cellData.setColspan(2);
			cellData.setVerticalAlignment(PdfPCell.ALIGN_BOTTOM);
			cellData.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
			pdfTable.addCell(cellData);
			cellData = null;
			
			cellData = new PdfPCell(new Phrase(strYear,GEInspira18BG));
			cellData.setBorder(Rectangle.NO_BORDER);
	//		cellData.setFixedHeight(30F);
			cellData.setBorder(Rectangle.BOX);
			cellData.setBorderWidth(1);
			cellData.setBorderColor(Color.WHITE);
			cellData.setVerticalAlignment(PdfPCell.ALIGN_BOTTOM);
			cellData.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
			pdfTable.addCell(cellData);
			cellData = null;
			
			cellData = new PdfPCell(new Phrase("Component Repair Directory", GEInspira18B));
			cellData.setBorder(Rectangle.NO_BORDER);
	//		cellData.setFixedHeight(30F);
			cellData.setBorder(Rectangle.BOX);
			cellData.setBorderWidth(1);
			cellData.setBorderColor(Color.WHITE);
			cellData.setVerticalAlignment(PdfPCell.ALIGN_BOTTOM);
			cellData.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
			pdfTable.addCell(cellData);
			cellData = null;
			
			cellData = new PdfPCell(new Phrase("Issued: January 1, " + strYear, GEInspira18));
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setColspan(2);
	//		cellData.setFixedHeight(30F);
			cellData.setBorder(Rectangle.BOX);
			cellData.setBorderWidth(1);
			cellData.setBorderColor(Color.WHITE);
			cellData.setVerticalAlignment(PdfPCell.ALIGN_BOTTOM);
			cellData.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
			pdfTable.addCell(cellData);
			cellData = null;
			
			cellData = new PdfPCell(new Phrase("" , GEInspira18));
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setColspan(2);
			cellData.setFixedHeight(70F);
			cellData.setBorder(Rectangle.BOX);
			cellData.setBorderWidth(1);
			cellData.setBorderColor(Color.WHITE);
			cellData.setVerticalAlignment(PdfPCell.ALIGN_BOTTOM);
			cellData.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
			pdfTable.addCell(cellData);
			cellData = null;
			
			strImagePath =  eCRDUtil.getAFSPath() + eCRDConstants.STRGEIMG_NEW;
			System.out.println("strImagePath" + strImagePath);
	/*
			PdfPTable innerTable = new PdfPTable(new float[]{86,400});
			
			GEImage = Image.getInstance(strImagePath);
            GEImage.scaleAbsolute(81,86);
			cellData = new PdfPCell(GEImage);
			cellData.setBorder(Rectangle.NO_BORDER);
	//		cellData.setColspan(2);
	//		cellData.setFixedHeight(30F);
			cellData.setBorder(Rectangle.BOX);
			cellData.setBorderWidth(1);
			cellData.setBorderColor(Color.WHITE);
			cellData.setVerticalAlignment(cellData.ALIGN_BOTTOM);
			cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
			innerTable.addCell(cellData);
			cellData = null;
			
			cellData = new PdfPCell(new Phrase("imagination at work", GEInspira24B));
			cellData.setBorder(Rectangle.NO_BORDER);
	//		cellData.setColspan(2);
	//		cellData.setFixedHeight(30F);
			cellData.setBorder(Rectangle.BOX);
			cellData.setBorderWidth(1);
			cellData.setPaddingTop(25f);
			cellData.setPaddingLeft(-10f);
			cellData.setBorderColor(Color.WHITE);
			cellData.setVerticalAlignment(cellData.ALIGN_CENTER);
			cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
			innerTable.addCell(cellData);
			cellData = null;
			
			cellData = new PdfPCell(innerTable);
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setColspan(2);
	//		cellData.setFixedHeight(30F);
			cellData.setBorder(Rectangle.BOX);
			cellData.setBorderWidth(1);
			cellData.setBorderColor(Color.WHITE);
			cellData.setVerticalAlignment(cellData.ALIGN_BOTTOM);
			cellData.setHorizontalAlignment(cellData.ALIGN_LEFT);
			pdfTable.addCell(cellData);
			cellData = null;
		*/	
			
			GEImage = Image.getInstance(strImagePath);
			GEImage.scaleAbsolute(230,70);
			cellData = new PdfPCell(GEImage);
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setColspan(2);
		//	cellData.setFixedHeight(70F);
			cellData.setBorder(Rectangle.BOX);
			cellData.setBorderWidth(1);
			cellData.setBorderColor(Color.WHITE);
			cellData.setVerticalAlignment(PdfPCell.ALIGN_BOTTOM);
			cellData.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
			pdfTable.addCell(cellData);
			cellData = null;
			
			document.add(pdfTable);
			
			/* code written for module-wise page numbering - STARTS */
			document.setPageCount(0);
			/* code written for module-wise page numbering - ENDS */
			document.setMargins(30, 30, 20, 45);
			
			loadDetails(document, rsCatalog, rsCatalogCols,
					rsChildRepairCatalogs, rsChildRepairCatalogsCols,
					strEngine, strYear);
			 
		} catch (NullPointerException e) {
			System.out.println(" Error :: " + e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println(" Error :: " + e.getMessage());
			e.printStackTrace();
		}
		
		return baosPDF;
	}

		/**
		 * The methods sets the rquired fonts
		 * 
		 * @throws Exception
		 */
		private void setFonts() throws Exception{
			try {
		//		bfGEInspRg = BaseFont.createFont("./styles/GEInspiraReg.TTF", BaseFont.CP1252, BaseFont.EMBEDDED);
				bfGEInspRg = BaseFont.createFont(eCRDUtil.getAFSPath() + eCRDConstants.STRCTRL + eCRDConstants.STRGEINSPRAFONT,  BaseFont.CP1252,BaseFont.EMBEDDED);
				geINSPIRA12 = new Font(bfGEInspRg, 12, 0, new Color(0, 0, 0));
				geINSPIRA14B = new Font(bfGEInspRg, 14, Font.BOLD, new Color(0, 0, 0));
				geINSPIRA11 = new Font(bfGEInspRg, 11, Font.NORMAL, new Color(0, 0,	0));
				geINSPIRA9B = new Font(bfGEInspRg, 9, Font.BOLD, new Color(0, 0, 0));
				geINSPIRA8 = new Font(bfGEInspRg, 8, 0, new Color(0, 0, 0));
				geINSPIRA8W = new Font(bfGEInspRg, 8, Font.BOLD, new Color(255,
						255, 255));
				geINSPIRA6 = new Font(bfGEInspRg, 7, 0, new Color(0, 0, 0));
				geINSPIRA8B = new Font(bfGEInspRg, 8, Font.BOLD, new Color(0, 0, 0));
				geINSPIRA12G = new Font(bfGEInspRg, 12, 0, new Color(192, 192, 192));
				geINSPIRA40B = new Font(bfGEInspRg, 30, Font.BOLD, new Color(0, 0, 0));
				GEInspira48B = new Font(bfGEInspRg, 80, Font.NORMAL, new Color(0, 0, 0));
				GEInspira16B = new Font(bfGEInspRg, 16, Font.BOLD, new Color(0, 0, 0));
				GEInspira18 = new Font(bfGEInspRg, 18, Font.NORMAL, new Color(0, 0, 0));
				GEInspira18B = new Font(bfGEInspRg, 18, Font.BOLD, new Color(0, 0, 0));
				GEInspira18BG = new Font(bfGEInspRg, 18, Font.BOLD, new Color(192,192,192));
				GEInspira16 = new Font(bfGEInspRg,16,0,new Color(0,0,0));
				GEInspira12 = new Font(bfGEInspRg,12,0,new Color(0,0,0));
				GEInspira24B = new Font(bfGEInspRg,22,Font.NORMAL,new Color(0,0,0));
			} catch (IOException e) {
				System.out.println(" Error :: " + e.getMessage());
			} catch (DocumentException e) {
				System.out.println(" Error :: " + e.getMessage());
			}
		}

		/**
		 * @param document
		 * @param rsCatalog
		 * @param rsCatalogCols
		 * @param rsChildRepairCatalogs
		 * @param rsChildRepairCatalogsCols
		 * @param strEngine
		 * @param strYear
		 * @throws Exception
		 */
		public void loadDetails(Document document, ArrayList rsCatalog,
				ArrayList rsCatalogCols, ArrayList rsChildRepairCatalogs,
				ArrayList rsChildRepairCatalogsCols, String strEngine,
				String strYear) throws Exception {
			document.open();
			int intColumnIndex = 0;
			int intColumnCount = 0;
			int intPart = 0;
			int intModules = 1;
			int intSite = 0;
			int numColumns = 0;
			String strPrevModule = "";
		String strPrevComponentCode = "";
		
		
/**beginning of changes rishabh change**/ 
		
		String strPrevCompTat = "" ;	
		String strPrevInspectionTat = "" ;
		String strPrevAverageTat = "" ;
		String strPrevNteTat = "" ;
			
		String strNewCompTat = null ;
		String strNewInspectionTat = null ;
		String strNewAverageTat = null ;
		String strNewNteTat = null ;	
		
	/**end of changes rishabh change**/
		
		
		
		String strComponentCode = null;
		String strRepairComments = null;
		String strRepairType = null;
		String strRepairId = null;
		String strModule = null;
		ArrayList arrlstParts = null;
		ArrayList arrlstSites = null;
		boolean blnFlag = false;
		boolean emptyRowFlag = false;
		PdfPTable pdfTableData = null;
		PdfPTable pdfInnerTable = null;
		PdfPCell cellData = null;
		float gutter = 0;
		float fullWidth = 0;
		float columnWidth = 0;
		float columnDataWidth = 0;
		float innerColumnWidth = 0;
		IMCSComponentRepairBean imcsCRParentBean = null;
		int count = 0;
		try {
			intColumnIndex = 0;
			intColumnCount = rsCatalogCols.size();
			gutter = 0;
			numColumns = 1;
			fullWidth = document.right() - document.left();
			columnWidth = (fullWidth - (numColumns - 1) * gutter) / numColumns;
			
			//columnDataWidth = (columnWidth - 20f) / 7f;//original
			columnDataWidth = (columnWidth - 15f) / 7f; //changes by rishabh mewar
			
			innerColumnWidth = (columnWidth - (2f * columnDataWidth - 38f) + 10);
			arrlstParts = new ArrayList();
			arrlstSites = new ArrayList();
			pdfTableData = new PdfPTable(new float[] { columnDataWidth - 18,
					columnDataWidth - 15, columnDataWidth * 0.7f,
					columnDataWidth * 0.8f, (columnDataWidth * 2.4f) + 33f,
					//columnDataWidth * 0.5f, //original
					columnDataWidth * 0.7f, //changes by rishabh mewar
					columnDataWidth * 0.6f + 10 });
			pdfTableData.setWidthPercentage(100);
			pdfTableData.setHeaderRows(7);
			pdfTableData.setSplitRows(false);
			Iterator parentCatalog = rsCatalog.iterator();
			ArrayList parentCatalogLst;
			Iterator itrParentCatalogLst;
		while (parentCatalog.hasNext()) {
			
			parentCatalogLst = (ArrayList)parentCatalog.next();
			itrParentCatalogLst = parentCatalogLst.iterator();
		 while (itrParentCatalogLst.hasNext()) {
			 System.out.println("inside loadDetails rsCatalog.next()");
			imcsCRParentBean = (IMCSComponentRepairBean) itrParentCatalogLst.next();
			// strModule = rsCatalog.getString(1);
			strModule = imcsCRParentBean.getModuleName();
			int prevNoModule = intModules;
			// System.out.println("strModule " + strModule);
			// System.out.println("strPrevModule " + strPrevModule);
			if (!(strPrevModule.equals(strModule))) // Check to identify
													// whetherto create a
													// New Sheet or Not.
			{
				intColumnIndex = 1;
				count = 0;
				// System.out.println("count = " + count);
				/*
				 * Checking if there are any More Parts or Sites that have
				 * to be Displayed for the previous Module before creating a
				 * new Module sheet.
				 */
				insertRemainingPartSiteDetails(pdfTableData, arrlstParts,
						arrlstSites, intColumnCount);
				
				//insertEmptyRow(pdfTableData, intColumnCount - 9); //original
				insertEmptyRow(pdfTableData, intColumnCount - 12); //changes by rishabh mewar

				document.add(pdfTableData);
				pdfTableData.setSplitRows(false);
				// pdfTableData.setSplitLate(false);
				/* code written for module-wise page numbering - STARTS */
				if (intModules > 0 && prevNoModule == intModules) 
				{
					IMCSCREndPage crEndPage = new IMCSCREndPage(String.valueOf(intModules));
					// System.out.println("Module = " + crEndPage.getIntModules());
					docWriter.setPageEvent(crEndPage);
					document.newPage();
				}
				/* code written for module-wise page numbering - ENDS */
				// System.out.println("ColumnDataWidth = " + columnDataWidth);
				pdfTableData = null;
				pdfTableData = new PdfPTable(new float[] {
						columnDataWidth - 10, columnDataWidth ,
						columnDataWidth * 0.7f, columnDataWidth * 0.8f - 1,
						(columnDataWidth * 2.4f) + 20f,
						//columnDataWidth * 0.5f + 10f, //original
						columnDataWidth * 0.7f + 10f,//changes by rishabh mewar
						columnDataWidth * 0.6f });
				pdfInnerTable = new PdfPTable(new float[] {
						innerColumnWidth, innerColumnWidth,
						innerColumnWidth });

				pdfTableData.setWidthPercentage(100);
				pdfTableData.setHeaderRows(7);
				arrlstSites = null;
				arrlstParts = null;
				/*
				 * Start of Data to Be Displayed in the First Row of Every
				 * Sheet.
				 */
				PdfPTable pdfInnerHeader = new PdfPTable(new float[]{21,47});
				cellData = new PdfPCell(new Phrase("GE", geINSPIRA12));
				cellData.setBorder(Rectangle.NO_BORDER);
				cellData.setFixedHeight(30);
				cellData.setColspan(1);
				cellData.setVerticalAlignment(PdfPCell.ALIGN_TOP);
				cellData.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);
				pdfInnerHeader.addCell(cellData);
				cellData = null;

				cellData = new PdfPCell(new Phrase("Aviation", geINSPIRA12));
				cellData.setBorder(Rectangle.NO_BORDER);
				cellData.setFixedHeight(30);
				cellData.setColspan(1);
				cellData.setVerticalAlignment(PdfPCell.ALIGN_TOP);
				cellData.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
				pdfInnerHeader.addCell(cellData);
				cellData = null;

				cellData = new PdfPCell(pdfInnerHeader);
				cellData.setBorder(Rectangle.NO_BORDER);
				cellData.setColspan(1);
				cellData.setVerticalAlignment(PdfPCell.ALIGN_BOTTOM);
				cellData.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
				pdfTableData.addCell(cellData);
				cellData = null;

				PdfPTable pdfInnerHeader1 = new PdfPTable(1);
				cellData = new PdfPCell(new Phrase("", geINSPIRA12G));
				cellData.setBorder(Rectangle.NO_BORDER);
				cellData.setColspan(1);
				cellData.setVerticalAlignment(PdfPCell.ALIGN_TOP);
				cellData.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
				pdfInnerHeader1.addCell(cellData);
				cellData = null;
				
				cellData = new PdfPCell(pdfInnerHeader1);
				cellData.setBorder(Rectangle.NO_BORDER);
				cellData.setColspan(1);
				cellData.setVerticalAlignment(PdfPCell.ALIGN_BOTTOM);
				cellData.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
				pdfTableData.addCell(cellData);
				cellData = null;
				
				
				//beginning_rishabh_pdf_tm
				
              	/*if ( strEngine.contains("GE Passport"))
              	{
              		strEngine = strEngine.replace("GE Passport","GE Passport\u2122");
              		cellData = new PdfPCell(new Phrase(strEngine, geINSPIRA40B));
              	}
              	
              	else 
              	{
              		cellData = new PdfPCell(new Phrase(strEngine, geINSPIRA40B));
              	}
*/          	
          	    //ending_rishabh_pdf_tm

				
				cellData = new PdfPCell(new Phrase(strEngine, geINSPIRA40B));
				cellData.setBorder(Rectangle.NO_BORDER);
				cellData.enableBorderSide(Rectangle.BOTTOM);
				cellData.setBorderColorBottom(Color.BLACK);
				cellData.setBorderWidthBottom(0.5f);
				cellData.setColspan(2);
				cellData.setPaddingBottom(7f);
				cellData.setVerticalAlignment(PdfPCell.ALIGN_BOTTOM);
				cellData.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
				pdfInnerTable.addCell(cellData);
				cellData = null;

				cellData = new PdfPCell(new Phrase(strModule, geINSPIRA14B));
				cellData.setBorder(Rectangle.NO_BORDER);
				cellData.enableBorderSide(Rectangle.BOTTOM);
				cellData.setBorderColorBottom(Color.BLACK);
				cellData.setBorderWidthBottom(0.5f);
				cellData.setPaddingBottom(4f);
				cellData.setVerticalAlignment(PdfPCell.ALIGN_BOTTOM);
				cellData.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);
				pdfInnerTable.addCell(cellData);
				cellData = null;

				cellData = new PdfPCell(pdfInnerTable);
				cellData.setBorder(Rectangle.NO_BORDER);
				cellData.setColspan(6);
				cellData.setVerticalAlignment(PdfPCell.ALIGN_BOTTOM);
				cellData.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
				pdfTableData.addCell(cellData);
				cellData = null;

				cellData = new PdfPCell(new Phrase("", geINSPIRA11));
				cellData.setBorder(Rectangle.NO_BORDER);
				cellData.setColspan(3);
				cellData.setVerticalAlignment(PdfPCell.ALIGN_TOP);
				cellData.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
				pdfTableData.addCell(cellData);
				cellData = null;

				pdfInnerTable = null;
				pdfInnerTable = new PdfPTable(new float[] {
						innerColumnWidth, innerColumnWidth });
				cellData = new PdfPCell(new Phrase("", geINSPIRA6));
				cellData.setBorder(Rectangle.NO_BORDER);
				cellData.setVerticalAlignment(PdfPCell.ALIGN_BOTTOM);
				cellData.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
				pdfInnerTable.addCell(cellData);
				cellData = null;

				cellData = new PdfPCell(new Phrase("Section " + intModules,
						geINSPIRA12));
				cellData.setBorder(Rectangle.NO_BORDER);
				cellData.setVerticalAlignment(PdfPCell.ALIGN_TOP);
				cellData.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);
				pdfInnerTable.addCell(cellData);
				cellData = null;

				cellData = new PdfPCell(pdfInnerTable);
				cellData.setBorder(Rectangle.NO_BORDER);
				cellData.setColspan(6);
				cellData.setVerticalAlignment(PdfPCell.ALIGN_BOTTOM);
				cellData.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);
				pdfTableData.addCell(cellData);
				cellData = null;

				cellData = new PdfPCell(new Phrase("", geINSPIRA6));
				cellData.setBorder(Rectangle.NO_BORDER);
				cellData.setColspan(4);
				cellData.setVerticalAlignment(PdfPCell.ALIGN_BOTTOM);
				cellData.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
				pdfTableData.addCell(cellData);
				cellData = null;

				cellData = new PdfPCell(new Phrase(strYear
						+ " Component Repair Directory", geINSPIRA9B));
				cellData.setBorder(Rectangle.NO_BORDER);
				cellData.setPaddingTop(10);
				cellData.setColspan(3);
				cellData.setVerticalAlignment(PdfPCell.ALIGN_BOTTOM);
				cellData.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);
				pdfTableData.addCell(cellData);
				cellData = null;

				cellData = new PdfPCell(new Phrase("", geINSPIRA6));
				cellData.setBorder(Rectangle.NO_BORDER);
				cellData.setColspan(4);
				cellData.setVerticalAlignment(PdfPCell.ALIGN_BOTTOM);
				cellData.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
				pdfTableData.addCell(cellData);
				cellData = null;

				cellData = new PdfPCell(new Phrase("Issued: January 1, "
						+ strYear, geINSPIRA8));
				cellData.setBorder(Rectangle.NO_BORDER);
				cellData.setPaddingBottom(3f);
				cellData.setColspan(3);
				cellData.setVerticalAlignment(PdfPCell.ALIGN_BOTTOM);
				cellData.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);
				pdfTableData.addCell(cellData);
				cellData = null;

				cellData = new PdfPCell(new Phrase("", geINSPIRA8));
				cellData.setBorder(Rectangle.NO_BORDER);
				cellData.setFixedHeight(2f);
				cellData.setColspan(7);
				cellData.setVerticalAlignment(PdfPCell.ALIGN_BOTTOM);
				cellData.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);
				pdfTableData.addCell(cellData);
				cellData = null;
				//insertEmptyRow(pdfTableData, intColumnCount - 9); //original
				insertEmptyRow(pdfTableData, intColumnCount - 12); //changes by rishabh mewar

				cellData = new PdfPCell(new Phrase("Component\nCode",geINSPIRA8W));
				cellData.setBorder(Rectangle.NO_BORDER);
				cellData.setBackgroundColor(new Color(0, 0, 0));
				cellData.setPaddingBottom(5f);
				cellData.setColspan(1);
				cellData.setVerticalAlignment(PdfPCell.ALIGN_BOTTOM);
				cellData.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
				pdfTableData.addCell(cellData);
				cellData = null;

				cellData = new PdfPCell(new Phrase("Component/\nParts",	geINSPIRA8W));
				cellData.setBorder(Rectangle.NO_BORDER);
				cellData.setBackgroundColor(new Color(0, 0, 0));
				cellData.setPaddingBottom(5f);
				cellData.setColspan(1);
				cellData.setVerticalAlignment(PdfPCell.ALIGN_BOTTOM);
				cellData.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
				pdfTableData.addCell(cellData);
				cellData = null;

				cellData = new PdfPCell(new Phrase("Repair\nSites",	geINSPIRA8W));
				cellData.setBorder(Rectangle.NO_BORDER);
				cellData.setBackgroundColor(new Color(0, 0, 0));
				cellData.setPaddingBottom(5f);
				cellData.setColspan(1);
				cellData.setVerticalAlignment(PdfPCell.ALIGN_BOTTOM);
				cellData.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
				pdfTableData.addCell(cellData);
				cellData = null;

				cellData = new PdfPCell(new Phrase("ATA/Repair\nNumber",geINSPIRA8W));
				cellData.setBorder(Rectangle.NO_BORDER);
				cellData.setBackgroundColor(new Color(0, 0, 0));
				cellData.setPaddingBottom(5f);
				cellData.setColspan(1);
				cellData.setVerticalAlignment(PdfPCell.ALIGN_BOTTOM);
				cellData.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
				pdfTableData.addCell(cellData);
				cellData = null;

				cellData = new PdfPCell(new Phrase(
						"Repair Description\n      ", geINSPIRA8W));
				cellData.setBorder(Rectangle.NO_BORDER);
				cellData.setBackgroundColor(new Color(0, 0, 0));
				cellData.setPaddingBottom(5f);
				cellData.setColspan(1);
				cellData.setVerticalAlignment(PdfPCell.ALIGN_BOTTOM);
				cellData.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
				pdfTableData.addCell(cellData);
				cellData = null;

				cellData = new PdfPCell(
						new Phrase("Component TAT\nDays", geINSPIRA8W));
				cellData.setBorder(Rectangle.NO_BORDER);
				cellData.setBackgroundColor(new Color(0, 0, 0));
				cellData.setPaddingBottom(5f);
				cellData.setColspan(1);
				cellData.setVerticalAlignment(PdfPCell.ALIGN_BOTTOM);
				cellData.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
				pdfTableData.addCell(cellData);
				cellData = null;

				cellData = new PdfPCell(new Phrase("Price\n    ",
						geINSPIRA8W));
				cellData.setBorder(Rectangle.NO_BORDER);
				cellData.setBackgroundColor(new Color(0, 0, 0));
				cellData.setPaddingBottom(5f);
				cellData.setColspan(1);
				cellData.setVerticalAlignment(PdfPCell.ALIGN_BOTTOM);
				cellData.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
				pdfTableData.addCell(cellData);
				cellData = null;
				/*
				 * End of the Data to be Displayed in the First Row.
				 */
				/*
				 * Loop to Display the Headings of the Data to be Displayed.
				 */
				// System.out.println("intColumnCount = " + intColumnCount);
				/*
				 * for (intColumnIndex = 0; intColumnIndex <= intColumnCount -
				 * 9; intColumnIndex++) { System.out.println("Setting Headings");
				 * if(intColumnIndex == 1) { cellData = new PdfPCell(new
				 * Phrase(IMCSUtility.replaceString((String)rsCatalogCols.get(intColumnIndex +
				 * 1),"/","/ "),geINSPIRA8W)); } else if(intColumnIndex ==
				 * 2) { cellData = new PdfPCell(new
				 * Phrase(IMCSUtility.replaceString((String)rsCatalogCols.get(intColumnIndex +
				 * 1)," "," "),geINSPIRA8W)); } else { cellData = new
				 * PdfPCell(new
				 * Phrase((String)rsCatalogCols.get(intColumnIndex +
				 * 1),geINSPIRA8W)); }
				 * cellData.setBorder(Rectangle.NO_BORDER);
				 * cellData.setPaddingBottom(5f);
				 * cellData.setPaddingTop(3f); cellData.setFixedHeight(30f);
				 * cellData.setLeading(2f,1f);
				 * cellData.enableBorderSide(Rectangle.BOTTOM);
				 * cellData.setBorderColorBottom(Color.BLACK);
				 * cellData.setBackgroundColor(new Color(0,0,0));
				 * cellData.setVerticalAlignment(PdfPCell.ALIGN_CENTER);
				 * cellData.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
				 * pdfTableData.addCell(cellData); cellData = null; }
				 */
				intModules++;
				emptyRowFlag = true;
				strPrevComponentCode = "";
				
				strPrevCompTat = ""; //changes by rishabh mewar
				
			}
			strPrevModule = strModule;
			strComponentCode = imcsCRParentBean.getCompCode();
			/* Commenting the code for parts missing issue in PDF generation
			// Inserting a blank row btwn the Header and the actual Data.
			if ((!strPrevComponentCode.equals(strComponentCode))
					&& (!"".equals(strPrevComponentCode))
					&& !(emptyRowFlag == true)) {
				// System.out.println("Insert blank row...");
				insertEmptyRow(pdfTableData, intColumnCount - 9);
				arrlstSites = null;
				arrlstParts = null;
			}
			*/
			
			
			
			/**beginning of changes by rishabh change**/
			
			strNewInspectionTat = imcsCRParentBean.getInspectionTat();
			strNewAverageTat = imcsCRParentBean.getAverageTat();
			strNewNteTat = imcsCRParentBean.getNteTat();
			strNewCompTat = strNewInspectionTat + " " + strNewAverageTat + " " + strNewNteTat ;		
		
		/**end of changes by rishabh change**/
			
			
			
			
				/*
				 * Start of Displaying Actual Data.
				 */
				strRepairType = imcsCRParentBean.getRepairType();
				// System.out.println("the string repair type" + strRepairType);
				//for (intColumnIndex = 0; intColumnIndex <= intColumnCount - 9; intColumnIndex++) //original
				for (intColumnIndex = 0; intColumnIndex <= intColumnCount - 12; intColumnIndex++) //changes by rishabh mewar
				{
					
					if (!(strPrevComponentCode).equals(strComponentCode)) //original
					//if (!(strPrevComponentCode).equals(strComponentCode) && !(strPrevCompTat).equals(strNewCompTat) ) //changes by rishabh mewar
					{ // Inserting
																			// the
																			// component
																			// details
						/*
						 * Checking if there are any part or Sites left to be
						 * displayed for previous component. when the new
						 * component has come for display Checking only for the
						 * 1st column.
						 */
						if (intColumnIndex == 0) {
							insertRemainingPartSiteDetails(pdfTableData,
									arrlstParts, arrlstSites, intColumnCount);
							
							//Changes start for parts missing issue
							if ((!strPrevComponentCode.equals(strComponentCode))
									&& (!"".equals(strPrevComponentCode))
									&& !(emptyRowFlag == true)) {
								// System.out.println("Insert blank row...");
								
								//insertEmptyRow(pdfTableData, intColumnCount - 9); //original
								insertEmptyRow(pdfTableData,intColumnCount - 12); //changes by rishabh mewar
								
								arrlstSites = null;
								arrlstParts = null;
							}
							//changes end for parts missing issue
						}
						/*
						 * Start of Display of Component releated Details.
						 */
						if (intColumnIndex < 4) { 
							/** Checking if it is 1st column to be displayed
							 *  then creating the ArrayList of Parts for tht component. If it is
							 * 3rd Column to be Displayed then creating the Arraylist of sites.
							 * else Displaying the Component Details.
							 */
							if (intColumnIndex == 1) {
								cellData = new PdfPCell(new Phrase(
										(String) imcsCRParentBean
												.getCompParts(), geINSPIRA8B));
								cellData.setBorder(Rectangle.NO_BORDER);
								cellData
										.setVerticalAlignment(PdfPCell.ALIGN_TOP);
								cellData
										.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
								pdfTableData.addCell(cellData);
								cellData = null;
								arrlstParts = new ArrayList();
								arrlstParts = IMCSUtility
										.convertStringToArrayList(
												(String) imcsCRParentBean
														.getPartNumber(), ",");
							} else if (intColumnIndex == 2) {
								arrlstSites = new ArrayList();
								arrlstSites = IMCSUtility
										.convertStringToArrayList(
												(String) imcsCRParentBean
														.getRepairSites(), ",");
								if (arrlstSites != null) {
									intSite = arrlstSites.size();
								} else {
									intSite = 0;
								}
								if (intSite > 0 && arrlstSites != null) {
									cellData = new PdfPCell(new Phrase(
											(String) arrlstSites
													.get(intSite - 1),
											geINSPIRA8B));
									arrlstSites.remove(intSite - 1);
								} else {
									cellData = new PdfPCell(new Phrase("",
											geINSPIRA8B));
								}
								cellData.setBorder(Rectangle.NO_BORDER);
								cellData
										.setVerticalAlignment(PdfPCell.ALIGN_TOP);
								cellData
										.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
								pdfTableData.addCell(cellData);
								cellData = null;
							} else {
								if (intColumnIndex == 3) {
								cellData = new PdfPCell(new Phrase((String) imcsCRParentBean.getAtaRepairNumber(),geINSPIRA8B));
									cellData.setBorder(Rectangle.NO_BORDER);
									cellData.setVerticalAlignment(PdfPCell.ALIGN_TOP);
									cellData.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
									pdfTableData.addCell(cellData);
									cellData = null;

									cellData = new PdfPCell(new Phrase("",geINSPIRA8B));
									cellData.setBorder(Rectangle.NO_BORDER);
									cellData.setVerticalAlignment(PdfPCell.ALIGN_TOP);
									cellData.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);
									pdfTableData.addCell(cellData);
									cellData = null;
									count++;
									// System.out.println(" count after atarepair = " + count);
									/*
									 * if(!"".equals(imcsCRParentBean.getTatDays())) {
									 * phTAT = new
									 * Phrase(imcsCRParentBean.getTatDays(),geINSPIRA8B);
									 * phComment = new Phrase(); phComplete =
									 * new Phrase(); phComplete.add(phTAT);
									 * phComplete.add(phComment); } else {
									 * phComplete = new Phrase("",geINSPIRA8B); }
									 */
									cellData = new PdfPCell(new Phrase("",
											geINSPIRA8B));
									cellData.setBorder(Rectangle.NO_BORDER);
									cellData
											.setVerticalAlignment(PdfPCell.ALIGN_TOP);
									cellData
											.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
									pdfTableData.addCell(cellData);
									cellData = null;
								} else if (intColumnIndex == 0) {
									cellData = new PdfPCell(new Phrase(
											imcsCRParentBean.getCompCode(),
											geINSPIRA8B));
									cellData.setBorder(Rectangle.NO_BORDER);
									cellData
											.setVerticalAlignment(PdfPCell.ALIGN_TOP);
									cellData
											.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
									pdfTableData.addCell(cellData);
									cellData = null;
								}
							}
						}

						/*
						 * Start of 1st Repair Data for the Current Component
						 */
						else // inserting Repair Details in next row.
						{
							/*
							 * Identifies if we need to create a new repair row.
							 * If So then check if we need to display and
							 * Part/Site Information for the current component.
							 * If So then Display it Else Display the Repair
							 * Data.
							 */
							if (!blnFlag) {
								for (int intEmptyCell = 0; intEmptyCell < 1; intEmptyCell++) {
									cellData = new PdfPCell(new Phrase("",
											geINSPIRA8B));
									cellData.setBorder(Rectangle.NO_BORDER);
									pdfTableData.addCell(cellData);
								}
								for (int intEmptyCell = 0; intEmptyCell < 4; intEmptyCell++) {
									/*
									 * Start of Displaying the Site/Part Data
									 * for Current Component
									 */
									if (arrlstSites != null) {
										intSite = arrlstSites.size();
									} else {
										intSite = 0;
									}
									if (intEmptyCell == 1) {
										arrlstParts = IMCSUtility
												.convertStringToArrayList(
														(String) imcsCRParentBean
																.getPartNumber(),
														",");
										if (arrlstParts != null) {
											intPart = arrlstParts.size();
										} else {
											intPart = 0;
										}
										if (intPart > 0 && arrlstParts != null) {
											cellData = new PdfPCell(new Phrase(
													(String) arrlstParts
															.get(intPart - 1),
													geINSPIRA8));
											arrlstParts.remove(intPart - 1);
										} else {
											cellData = new PdfPCell(new Phrase(
													"", geINSPIRA8));
										}
										cellData.setBorder(Rectangle.NO_BORDER);
										cellData
												.setVerticalAlignment(PdfPCell.ALIGN_TOP);
										cellData
												.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
										pdfTableData.addCell(cellData);
										cellData = null;
									} else if (intEmptyCell == 2) {
										if (intSite > 0 && arrlstSites != null) {
											cellData = new PdfPCell(new Phrase(
													(String) arrlstSites
															.get(intSite - 1),
													geINSPIRA8));
											arrlstSites.remove(intSite - 1);
										} else {
											cellData = new PdfPCell(new Phrase(
													"", geINSPIRA8));
										}
										cellData.setBorder(Rectangle.NO_BORDER);
										cellData
												.setVerticalAlignment(PdfPCell.ALIGN_TOP);
										cellData
												.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
										pdfTableData.addCell(cellData);
										cellData = null;
									}
									/*
									 * End of Code for Displaying Site/Part
									 * Information
									 */
									else if (intEmptyCell == 0) {
										cellData = new PdfPCell(new Phrase("",
												geINSPIRA8));
										cellData.setBorder(Rectangle.NO_BORDER);
										cellData
												.setVerticalAlignment(PdfPCell.ALIGN_TOP);
										cellData
												.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
										pdfTableData.addCell(cellData);
										cellData = null;
									}
									// Display the Repair Display Seq Id

									else {
										cellData = new PdfPCell(new Phrase(
												imcsCRParentBean
														.getRepairDisplayId(),
												geINSPIRA8));
										cellData.setBorder(Rectangle.NO_BORDER);
										cellData
												.setVerticalAlignment(PdfPCell.ALIGN_TOP);
										cellData
												.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
										pdfTableData.addCell(cellData);
										cellData = null;

									}
									blnFlag = true;
								}

							}
							if (intColumnIndex == 4) {

								cellData = new PdfPCell(
										new Phrase(imcsCRParentBean
												.getRepairDescription(),
												geINSPIRA8));
								cellData.setBorder(Rectangle.NO_BORDER);
								cellData
										.setVerticalAlignment(PdfPCell.ALIGN_TOP);
								cellData
										.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
								pdfTableData.addCell(cellData);
								cellData = null;
							} 
							
							else if (intColumnIndex == 5) 
							{
								//cellData = new PdfPCell(new Phrase(imcsCRParentBean.getTatDays(),geINSPIRA8)); //original
								
								
								/**beginning of changes by rishabh mewar**/
								System.out.println("strNewCompTat : ---" + strNewCompTat);
								cellData = new PdfPCell(new Phrase(strNewCompTat,geINSPIRA8));
								/**end of changes by rishabh mewar**/
								
								
								cellData.setBorder(Rectangle.NO_BORDER);
								cellData
										.setVerticalAlignment(PdfPCell.ALIGN_TOP);
								cellData
										.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
								pdfTableData.addCell(cellData);
								cellData = null;
							} else {
								cellData = new PdfPCell(
										new Phrase(imcsCRParentBean.getPrice(),
												geINSPIRA8));
								cellData.setBorder(Rectangle.NO_BORDER);
								cellData
										.setVerticalAlignment(PdfPCell.ALIGN_TOP);
								cellData
										.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
								pdfTableData.addCell(cellData);
								count++;
								// System.out.println(" imcsCRParentBean.getPrice() = " + imcsCRParentBean.getPrice());
								// System.out.println(" count after price 1  = " + count);
								cellData = null;
							}
							/*
							 * Start of Code for Display of Repair Comments if
							 * Present
							 */
							//if (intColumnIndex == (intColumnCount - 9)) //original
							if (intColumnIndex == (intColumnCount - 12)) //changes by rishabh mewar	
							{
								strRepairComments = IMCSUtility
										.verifyNull(imcsCRParentBean
												.getRepairComments());
								if (!"".equals(strRepairComments)) {
									insertRepairComments(pdfTableData,
											intColumnCount, strRepairComments,
											arrlstParts, arrlstSites);
								}
							}
							/*
							 * End Of Code for Display of Repair Comments.
							 */
						}// End of Code for Display of Repair.
					}// End of Code for Display of Component Details
					/*
					 * Start of Code for Display of Data for Repair present in
					 * the Component
					 */
					else // Data for Repair of the same component
					{
						pdfTableData.setSplitRows(false);
						/*
						 * Start of Code for Display of Following Things. 1)
						 * Part if any left for the Component 2) Sites if any
						 * left for the Component 3) Repair Display Seq Id For
						 * the current Repair.
						 */
						if (intColumnIndex < 4) {
							if (intColumnIndex == 1) {
								if (arrlstParts != null) {
									intPart = arrlstParts.size();
								} else {
									intPart = 0;
								}
								if (intPart > 0 && arrlstParts != null) {
									cellData = new PdfPCell(new Phrase(
											(String) arrlstParts
													.get(intPart - 1),
											geINSPIRA8));
									arrlstParts.remove(intPart - 1);
								} else {
									cellData = new PdfPCell(new Phrase("",
											geINSPIRA8));
								}
							} else if (intColumnIndex == 2) {
								if (arrlstSites != null) {
									intSite = arrlstSites.size();
								} else {
									intSite = 0;
								}
								if (intSite > 0 && arrlstSites != null) {
									cellData = new PdfPCell(new Phrase(
											(String) arrlstSites
													.get(intSite - 1),
											geINSPIRA8));
									arrlstSites.remove(intSite - 1);
								} else {
									cellData = new PdfPCell(new Phrase("",
											geINSPIRA8));
								}
							} else if (intColumnIndex == 3) {
								cellData = new PdfPCell(new Phrase(
										imcsCRParentBean.getRepairDisplayId(),
										geINSPIRA8));

							} else {
								cellData = new PdfPCell(new Phrase("",
										geINSPIRA8));
							}
							cellData.setBorder(Rectangle.NO_BORDER);
							cellData.setVerticalAlignment(PdfPCell.ALIGN_TOP);
							cellData
									.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
							pdfTableData.addCell(cellData);
							cellData = null;
						}
						/*
						 * End of Code for display of Sites/Parts/Display Seq.
						 * Start of Code for Display of Other Repair Details.
						 */
						//else //original
						else if(intColumnIndex > 3 && intColumnIndex < 7)	// changes by rishabh mewar
						{
							if (intColumnIndex == 4) {
								cellData = new PdfPCell(
										new Phrase(imcsCRParentBean
												.getRepairDescription(),
												geINSPIRA8));
							}
							
							if (intColumnIndex == 5) 
							{
								//cellData = new PdfPCell(new Phrase(imcsCRParentBean.getTatDays(),geINSPIRA8)); //original
								
								/**beginning of changes by rishabh mewar**/
								
								System.out.println("strNewCompTat 2 : ---" + strNewCompTat);	
								if (!(strPrevCompTat).equals(strNewCompTat))
								{
									cellData = new PdfPCell(new Phrase(strNewCompTat,geINSPIRA8));
								}
								else
								{
									cellData = new PdfPCell(new Phrase("",geINSPIRA8));
								}				
								
								/**end of changes by rishabh mewar**/
								
							}
							if (intColumnIndex == 6) {
								cellData = new PdfPCell(
										new Phrase(imcsCRParentBean.getPrice(),
												geINSPIRA8));
								count++;
						//		System.out.println(" imcsCRParentBean.getPrice() = " + imcsCRParentBean.getPrice());
						//		System.out.println(" count after price 2 = " + count);
							}
							cellData.setBorder(Rectangle.NO_BORDER);
							cellData.setVerticalAlignment(PdfPCell.ALIGN_TOP);
							cellData
									.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
							pdfTableData.addCell(cellData);
							cellData = null;
							/*
							 * Start of Code for Display of Repair Comments if
							 * Available
							 */
							
							//if (intColumnIndex == (intColumnCount - 9)) //original
							if (intColumnIndex == (intColumnCount - 12)) //changes by rishabh mewar
							{
								strRepairComments = IMCSUtility
										.verifyNull(imcsCRParentBean
												.getRepairComments());
								if (!"".equals(strRepairComments)) {
									insertRepairComments(pdfTableData,
											intColumnCount, strRepairComments,
											arrlstParts, arrlstSites);
								}
							}/*
								 * End of Code for Display of Repair Comments
								 */
						}
						/*
						 * End of Code for Display of Repari Details
						 */
					}/*
						 * End of Code for Display of Repair for the Same
						 * Component
						 */
				}/*
					 * End of the For Loop for the Display of Actual Data
					 */
				if (!strPrevModule.equals(strModule)) {
					// System.out.println("Insert blank row...");
					//insertEmptyRow(pdfTableData, intColumnCount - 9); //original
					insertEmptyRow(pdfTableData, intColumnCount - 12); //changes by rishabh mewar
					arrlstSites = null;
					arrlstParts = null;
				}
				if ("PR".equals(strRepairType)) {

					strRepairId = imcsCRParentBean.getRepairId();
					// System.out.println("the repair id"+strRepairId);
					insertChildRepairsData(pdfTableData, rsChildRepairCatalogs,
							rsChildRepairCatalogsCols, arrlstParts,
							arrlstSites, strRepairId);
				}
				blnFlag = false;
				strPrevComponentCode = imcsCRParentBean.getCompCode();
				
				/**beginning of changes rishabh change**/
				strPrevInspectionTat = imcsCRParentBean.getInspectionTat();
				strPrevAverageTat = imcsCRParentBean.getAverageTat();
				strPrevNteTat = imcsCRParentBean.getNteTat();
				
				strPrevCompTat = strPrevInspectionTat + " " + strPrevAverageTat + " " + strPrevNteTat ;			
				/**end of changes rishabh change**/
				
				emptyRowFlag = false;
		 	}
		}

			insertRemainingPartSiteDetails(pdfTableData, arrlstParts,
					arrlstSites, intColumnCount);
			//insertEmptyRow(pdfTableData, intColumnCount - 9); //original
			insertEmptyRow(pdfTableData,intColumnCount - 12); //changes by rishabh mewar
			document.add(pdfTableData);
			pdfTableData.setSplitRows(false);
			// pdfTableData.setSplitLate(false);
			document.close();
		} catch (FileNotFoundException e) {
			System.out.println(" Error :: " + e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println(" Error :: " + e.getMessage());
			e.printStackTrace();
		} finally {
			intColumnIndex = 0;
			intColumnCount = 0;
			intPart = 0;
			intModules = 0;
			intSite = 0;
			numColumns = 0;
			strPrevModule = "";
			strPrevComponentCode = "";
			
			
			/**beginning of changes by rishabh change**/
			strPrevCompTat = "" ;	
			strPrevInspectionTat = "" ;
			strPrevAverageTat = "" ;
			strPrevNteTat = "" ;
							
			strNewCompTat = null ;
			strNewInspectionTat = null ;
			strNewAverageTat = null ;
			strNewNteTat = null ;
			/**end of changes rishabh change**/
			
			
			
				strComponentCode = null;
				strRepairComments = null;
				strRepairType = null;
				strRepairId = null;
				strModule = null;
				arrlstParts = null;
				arrlstSites = null;
				blnFlag = false;
				pdfTableData = null;
				cellData = null;
				gutter = 0;
				fullWidth = 0;
				columnWidth = 0;
				columnDataWidth = 0;
			}
		}

		/**
		 * @param pdfTableData
		 * @param rsChildRepairs
		 * @param rsChildRepairsCols
		 * @param arrlstParts
		 * @param arrlstSites
		 * @param strRepairId1
		 * @throws NullPointerException
		 * @throws Exception
		 */
		private void insertChildRepairsData(PdfPTable pdfTableData,
				ArrayList rsChildRepairs, ArrayList rsChildRepairsCols,
				ArrayList arrlstParts, ArrayList arrlstSites, String strRepairId)
				throws Exception {
			// System.out.println("insertRepairComments()");
		int intColumnIndex = 0;
		int intPart = 0;
		int intSite = 0;
		int intColumnCount = 0;
		PdfPCell cellData;
		String strRepairComments = null;
		String strParentRepairId = null;
		IMCSComponentRepairBean imcsChildRepairBean = null;
		String strRepairId1 = null;
		try {
			intColumnCount = rsChildRepairsCols.size();
			/*
			 * Start of Code for Display of Following Things. 1) Part if any
			 * left for the Component 2) Sites if any left for the Component 3)
			 * Repair Display Seq Id For the current Repair.
			 */
			// rsChildRepairs.absolute(0);
			Iterator childRepairLst = rsChildRepairs.iterator();
			
		//	Iterator parentCatalog = rsCatalog.iterator();
			ArrayList childCatalogLst;
			Iterator itrChildCatalogLst;
		while (childRepairLst.hasNext()) {
			
			childCatalogLst = (ArrayList)childRepairLst.next();
			itrChildCatalogLst = childCatalogLst.iterator();
//		 while (itrParentCatalogLst.hasNext()) {

			while (itrChildCatalogLst.hasNext()) {
				imcsChildRepairBean = (IMCSComponentRepairBean) itrChildCatalogLst.next();
				strParentRepairId = imcsChildRepairBean.getParentRepairId();
				strRepairId1 = IMCSUtility.checkNull(strRepairId, "");

				if (strRepairId1.equals(strParentRepairId)) 
				{
					//for (intColumnIndex = 0; intColumnIndex <= intColumnCount - 9; intColumnIndex++)//original 
					for (intColumnIndex = 0; intColumnIndex <= intColumnCount - 12; intColumnIndex++) //changes by rishabh mewar
					{
						if (intColumnIndex < 4) {
							if (intColumnIndex == 1) {
								if (arrlstParts != null) {
									intPart = arrlstParts.size();
								} else {
									intPart = 0;
								}
								if (intPart > 0 && arrlstParts != null) {
									cellData = new PdfPCell(new Phrase(
											(String) arrlstParts
													.get(intPart - 1),
											geINSPIRA8));
									arrlstParts.remove(intPart - 1);
								} else {
									cellData = new PdfPCell(new Phrase("",
											geINSPIRA8));
								}
							} else if (intColumnIndex == 2) {
								if (arrlstSites != null) {
									intSite = arrlstSites.size();
								} else {
									intSite = 0;
								}
								if (intSite > 0 && arrlstSites != null) {
									cellData = new PdfPCell(new Phrase(
											(String) arrlstSites
													.get(intSite - 1),
											geINSPIRA8));
									arrlstSites.remove(intSite - 1);
								} else {
									cellData = new PdfPCell(new Phrase("",
											geINSPIRA8));
								}
							} else if (intColumnIndex == 3) {

								cellData = new PdfPCell(new Phrase(
										imcsChildRepairBean
												.getRepairDisplayId(),
										geINSPIRA8));
							} else {
								cellData = new PdfPCell(new Phrase("",
										geINSPIRA8));
							}
							cellData.setBorder(Rectangle.NO_BORDER);
							cellData.setVerticalAlignment(PdfPCell.ALIGN_TOP);
							cellData
									.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
							pdfTableData.addCell(cellData);
							pdfTableData.setSplitRows(false);
							// document.add(pdfTableData);
							cellData = null;
						}
						/*
						 * End of Code for display of Sites/Parts/Display Seq.
						 * Start of Code for Display of Other Repair Details.
						 */
						else if (intColumnIndex == 4) {
							cellData = new PdfPCell(new Phrase(
									imcsChildRepairBean.getRepairDescription(),
									geINSPIRA8));
							cellData.setBorder(Rectangle.NO_BORDER);
							cellData.setPaddingLeft(2f);
							cellData.setVerticalAlignment(PdfPCell.ALIGN_TOP);
							cellData
									.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
							pdfTableData.addCell(cellData);
							cellData = null;
						} else {
							cellData = new PdfPCell(new Phrase("", geINSPIRA8));
							cellData.setBorder(Rectangle.NO_BORDER);
							cellData.setVerticalAlignment(PdfPCell.ALIGN_TOP);
							cellData
									.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
							pdfTableData.addCell(cellData);
							cellData = null;
							/*
							 * Start of Code for Display of Repair Comments if
							 * Available
							 */
							//if (intColumnIndex == (intColumnCount - 9)) //original
							if (intColumnIndex == (intColumnCount - 12)) // changes by rishabh mewar
							{
								strRepairComments = IMCSUtility
										.verifyNull(imcsChildRepairBean
												.getRepairComments());
								if (!"".equals(strRepairComments)) {
										insertRepairComments(pdfTableData,
												intColumnCount, strRepairComments,
												arrlstParts, arrlstSites);
									}
								}
							}
						}
					}
				}
		}} catch (NullPointerException e) {
				System.out.println(" Error :: " + e.getMessage());
				e.printStackTrace();
			} catch (Exception e) {
				System.out.println(" Error :: " + e.getMessage());
				e.printStackTrace();
			} finally {
				intColumnIndex = 0;
				intPart = 0;
				intSite = 0;
				strRepairComments = null;
				intColumnCount = 0;
				strParentRepairId = null;
			}
		}

		private void insertEmptyRow(PdfPTable pdfTableData, int endCell)
				throws Exception {
			// System.out.println("insertEmptyRow()");
		PdfPCell cellData;
		int inti = 0;
		try {
			for (inti = 0; inti <= endCell; inti++) {
				cellData = new PdfPCell(new Phrase("", geINSPIRA8));
					cellData.setBorder(Rectangle.NO_BORDER);
					cellData.enableBorderSide(Rectangle.BOTTOM);
					cellData.setBorderColorBottom(Color.BLACK);
					cellData.setFixedHeight(5f);
					cellData.setVerticalAlignment(PdfPCell.ALIGN_CENTER);
					cellData.setHorizontalAlignment(PdfPCell.ALIGN_CENTER);
					pdfTableData.addCell(cellData);
					cellData = null;
				}
			} catch (NullPointerException e) {
				System.out.println(" Error :: " + e.getMessage());
				e.printStackTrace();
			} catch (Exception e) {
				System.out.println(" Error :: " + e.getMessage());
				e.printStackTrace();
			} finally {
				cellData = null;
				inti = 0;
			}
		}

		private void insertRepairComments(PdfPTable pdfTableData,
				int intColumnCount, String strRepairComments,
				ArrayList arrlstParts, ArrayList arrlstSites) throws Exception {
			// System.out.println("insertRepairComments()");
		PdfPCell cellData = null;
		int intPart = 0;
		int intSite = 0;
		try {
			//for (int intEmptyCell = 0; intEmptyCell <= intColumnCount - 9; intEmptyCell++) //original
			for (int intEmptyCell = 0; intEmptyCell <= intColumnCount - 12; intEmptyCell++) //changes by rishabh mewar
			{
				if (intEmptyCell == 1) {
					if (arrlstParts != null) {
						intPart = arrlstParts.size();
					} else {
						intPart = 0;
					}
					if (intPart > 0 && arrlstParts != null) {
						cellData = new PdfPCell(new Phrase((String) arrlstParts
								.get(intPart - 1), geINSPIRA8));
						arrlstParts.remove(intPart - 1);
					} else {
						cellData = new PdfPCell(new Phrase("", geINSPIRA8));
					}
				} else if (intEmptyCell == 2) {
					if (arrlstSites != null) {
						intSite = arrlstSites.size();
					} else {
						intSite = 0;
					}
					if (intSite > 0 && arrlstSites != null) {
						cellData = new PdfPCell(new Phrase((String) arrlstSites
								.get(intSite - 1), geINSPIRA8));
						arrlstSites.remove(intSite - 1);
					} else {
						cellData = new PdfPCell(new Phrase("", geINSPIRA8));
					}
				} else if (intEmptyCell == 4) {
					cellData = new PdfPCell(new Phrase(strRepairComments,
							geINSPIRA8));
				} else {
					cellData = new PdfPCell(new Phrase("", geINSPIRA8));
				}
				cellData.setBorder(Rectangle.NO_BORDER);
				cellData.setVerticalAlignment(PdfPCell.ALIGN_TOP);
				cellData.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
				pdfTableData.addCell(cellData);
				cellData = null;
			}
		} catch (IndexOutOfBoundsException e) {
			 System.out.println(" Error :: " + e.getMessage());
			 e.printStackTrace();
			}catch (Exception e) {
			 System.out.println(" Error :: " + e.getMessage());
			 e.printStackTrace();
			} finally {
				cellData = null;
				intPart = 0;
				intSite = 0;
			}
		}

		private void insertRemainingPartSiteDetails(PdfPTable pdfTableData,
				ArrayList arrlstParts, ArrayList arrlstSites, int intColumnCount)
				throws Exception {
			// System.out.println("insertRemainingPartSiteDetails()");
		int intPart = 0;
		int intSite = 0;
		int intColumn = 0;
		PdfPCell cellData = null;
		try {
			if (arrlstParts != null) {
				intPart = arrlstParts.size();
			} else {
				intPart = 0;
			}
			if (arrlstSites != null) {
				intSite = arrlstSites.size();
			} else {
				intSite = 0;
			}
			if (intPart > 0 || intSite > 0) { // Indentifying whether there
												// are more parts or more sites
												// to be displayed.
				if (intPart > intSite) {
					intColumn = intPart;
				} else {
					intColumn = intSite;
				}
				// Loop to display all the remaining Sites and Parts for the
				// Previous Component
				for (int inti = 0; inti < intColumn; inti++) 
				{
					//for (int intEmptyCell = 0; intEmptyCell <= intColumnCount - 9; intEmptyCell++) //original
					for (int intEmptyCell = 0; intEmptyCell <= intColumnCount - 12; intEmptyCell++) //changes by rishabh mewar
					{
						if (intEmptyCell == 1) { // creating cell for parts
													// data.
							if (arrlstParts != null) {
								intPart = arrlstParts.size();
							} else {
								intPart = 0;
							}
							if (intPart > 0 && arrlstParts != null) { // Displaying the Part Numbers.
								cellData = new PdfPCell(new Phrase((String) arrlstParts.get(intPart - 1),
										geINSPIRA8));
								arrlstParts.remove(intPart - 1);
							} else { // No Value to be displayed in the cell
										// for Part Number.
								cellData = new PdfPCell(new Phrase("",
										geINSPIRA8));
							}
						} else if (intEmptyCell == 2) {
							if (arrlstSites != null) {
								intSite = arrlstSites.size();
							} else {
								intSite = 0;
							}
							if (intSite > 0 && arrlstSites != null) { // Displaying
																		// the
																		// Sites.
								cellData = new PdfPCell(new Phrase(
										(String) arrlstSites.get(intSite - 1),
										geINSPIRA8));
								// Removing the Sites frm the Site ArrayList.
								arrlstSites.remove(intSite - 1);
							} else { // No Value to be Dispalyed in the Cell
										// for Sites.
								cellData = new PdfPCell(new Phrase("",
										geINSPIRA8));
							}
						} else {
							cellData = new PdfPCell(new Phrase("", geINSPIRA8));
						}
						cellData.setBorder(Rectangle.NO_BORDER);
						cellData.setVerticalAlignment(PdfPCell.ALIGN_BOTTOM);
						cellData.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
						pdfTableData.addCell(cellData);
						cellData = null;
					}
				}
			}
		} catch (IndexOutOfBoundsException e) {
			 System.out.println(" Error :: " + e.getMessage());
			 e.printStackTrace();
		}catch (Exception e) {
			 System.out.println(" Error :: " + e.getMessage());
			 e.printStackTrace();
		}
		finally {
				intPart = 0;
				intSite = 0;
				intColumn = 0;
				cellData = null;
			}
		}

		public int getColumnCount(ResultSet rs) {
			ResultSetMetaData rsmd = null;
			int count = 0;
			try {
				rsmd = rs.getMetaData();
				count = rsmd.getColumnCount();
			} catch (Exception e) {
				System.out.println(" Error :: " + e.getMessage());
				e.printStackTrace();
		}
//		 System.out.println("Column Count = " + count);
			return count;
		}

		public String getColumnHeading(ResultSet rs, int colNum) {
			ResultSetMetaData rsmd = null;
			String heading = null;
			try {
				rsmd = rs.getMetaData();
				heading = rsmd.getColumnName(colNum);

			} catch (Exception e) {
				System.out.println(" Error :: " + e.getMessage());
				e.printStackTrace();
		}
//		 System.out.println("Column heading = " + heading);
				return heading;
			}
}
