/*
* Module    	    : eCRDRepair.java
* Author      	    : PATNI-Offshore
* Project	        : eCRD
* Date Written		: October 2004
* Security	        : Unclassified
* Restrictions		: GE PROPRIETARY INFORMATION, FOR GE USE ONLY
*
*     ****************************************************
*     *  Copyright (2000) with all rights reserved       *
*     *          General Electric Company                *
*     ****************************************************
*
* Description: eCRDBusinessBean is used for getting the GEAE Row Cache Tag
*
* Revision Log  (mm/dd/yy initials description)
* --------------------------------------------------------------
*/
package ecrd.biz;

import java.util.ArrayList;
import java.io.Serializable;
import ecrd.biz.eCRDApprovalRequest;
import geae.dao.GEAEResultSet;
import ecrd.exception.eCRDException;
import ecrd.util.eCRDConstants;
import ecrd.common.eCRDDBMediator;
import ecrd.util.eCRDUtil;

/**
 * This entity represents top class in repair hirarchy.
 */
public abstract class eCRDRepair implements Serializable
{
	private String strRepairInd = null; //changes by rishabh mewar
	
	private String strRepairCode = null;
	private String strRepairDesc = null;
	private String dtRepairEffDate = null;
	private String strComments = null;
    private String strRDNumber = null;
    private String strReasonRDOverride = null;
    private String strRDNumberComment = null;
    private String strRDCreationDt = null;
    private String strRDModifiedDt = null;
    private String strRDAssociation = null;
    private String strNPIClassification = null;
    private String strRepairVolume = null;
	private String strRequestedUserID = null;
	private boolean flgIsSpecial = false;
	private String strRepairType = null;
	private String strIsLastRepair = "";
	private eCRDComponent objECRDComponent = null;
	private eCRDRepairPricing objRepairPricing = null;

	private ArrayList arrlstECRDRepairSite = null;
	private eCRDApprovalRequest objECRDApprovalRequest = null;

	/**
	 * @return
	 */
	public eCRDRepairPricing getObjRepairPricing()
	{
		return objRepairPricing;
	}

	/**function to check whether the repair is pending for approval or not
	 * @return
	 */

	public boolean isRepairRequestPending(String strRepairSeqID, String strCatalogSeqId) throws Exception
	{

		ArrayList arrInParam = null;
		ArrayList arrOutParam = null;
		String strActionId = null;
		String strStatus = null;
		boolean isRepairReqPending = false;
		eCRDException objException = null;
		String strModuleCode = null;
		try
		{
			arrInParam = new ArrayList();
			arrOutParam = new ArrayList();

			arrInParam.add(strRepairSeqID);
			arrInParam.add(strCatalogSeqId);

			strActionId = eCRDUtil.verifyNull((String) eCRDConstants.getActionId("eCRD_IS_REPAIR_APPR_PENDING"));
			arrOutParam = eCRDDBMediator.doDBOperation(strActionId, arrInParam);
			strStatus = (String) arrOutParam.get(0);
			if (strStatus.equalsIgnoreCase(eCRDConstants.STRTRUE))
			{
				isRepairReqPending = true;
			}
			else
			{
				isRepairReqPending = false;
			}
			return isRepairReqPending;
		}
		finally
		{

			arrInParam = null;
			arrOutParam = null;
			strActionId = null;
		}

	}
	/**
	 * @param objRepairPricing
	 */
	public eCRDRepairPricing addRepairPricing()
	{
		eCRDRepairPricing objRepairPricing = new eCRDRepairPricing();
		this.objRepairPricing = objRepairPricing;
		return this.objRepairPricing;
	}

	/**
	 * @return
	 */
	public eCRDApprovalRequest getArrlstApprovalRequest()
	{
		return this.objECRDApprovalRequest;
	}

	/**
	 * @param arrlstApprovalRequest
	 */
	public void setApprovalRequest(eCRDApprovalRequest objECRDApprovalRequest)
	{
		this.objECRDApprovalRequest = objECRDApprovalRequest;
	}

	/**
	 * @return
	 */
	public ArrayList getArrlstECRDRepairSite()
	{
		return arrlstECRDRepairSite;
	}

	/**
	 * @param arrlstECRDRepairSite
	 */
	public eCRDRepairSite addECRDRepairSite()
	{
		eCRDRepairSite objECRDRepairSite = new eCRDRepairSite();

		if (arrlstECRDRepairSite == null)
		{
			arrlstECRDRepairSite = new ArrayList();
		}
		arrlstECRDRepairSite.add(objECRDRepairSite);
		return objECRDRepairSite;
	}

	/**
	 * @return
	 */
	public String getDtRepairEffDate()
	{
		return dtRepairEffDate;
	}

	/**
	 * @param dtRepairEffDate
	 */
	public void setDtRepairEffDate(String dtRepairEffDate)
	{
		this.dtRepairEffDate = dtRepairEffDate;
	}

	/**
	 * @return
	 */
	public boolean isFlgIsSpecial()
	{
		return flgIsSpecial;
	}

	/**
	 * @param flgIsSpecial
	 */
	public void setFlgIsSpecial(boolean flgIsSpecial)
	{
		this.flgIsSpecial = flgIsSpecial;
	}

	
	
	
	
	
	
	
	/**beginning changes by rishabh mewar **/

	  	public String getRepairInd()
	    {
	        return strRepairInd;
	    }
	    public void setRepairInd(String strRepairInd)
	    {
	        this.strRepairInd = strRepairInd;
	    }

    /**end of changes by rishabh mewar **/

    
    
    
    
    
	/**
	 * @return
	 */
	public String getStrComments()
	{
		return strComments;
	}

	/**
	 * @param strComments
	 */
	public void setStrComments(String strComments)
	{
		this.strComments = eCRDUtil.replaceString(strComments, "\r\n", " ");
	}

	/**
	 * @return
	 */
	public String getStrRepairVolume()
	{
		return strRepairVolume;
	}

	/**
	 * @param strRapairVolume
	 */
	public void setStrRapairVolume(String strRepairVolume)
	{
		this.strRepairVolume = strRepairVolume;
	}

	/**
	 * @return
	 */
	public String getStrRepairCode()
	{
		return strRepairCode;
	}

	/**
	 * @param strRepairCode
	 */
	public void setStrRepairCode(String strRepairCode)
	{
		this.strRepairCode = strRepairCode;
	}

	/**
	 * @return
	 */
	public String getStrRepairDesc()
	{
		return strRepairDesc;
	}

	/**
	 * @param strRepairDesc
	 */
	public void setStrRepairDesc(String strRepairDesc)
	{
		this.strRepairDesc = eCRDUtil.replaceString(strRepairDesc, "\r\n", " ");
	}

	/**
	 * @return
	 */
	public eCRDComponent getObjECRDComponent()
	{
		return objECRDComponent;
	}

	/**
	 * @param objComponent
	 */
	public void setECRDComponent(eCRDComponent objComponent)
	{
		this.objECRDComponent = objComponent;
	}

	public eCRDRepair()
	{

	}

	/**
	* Creates a new approval request and adds it to the ArrayList of Approvals for
	* the current repair. Returns reference to the newly added approval request so
	* that attributes could be set for it.
	* @return ecrd.biz.eCRDApprovalRequest
	*/
	public eCRDApprovalRequest addApprovalRequest()
	{
		return null;
	}

	/**
	 * Removes site-repair relationship for the repair.
	 * @param strSiteCode
	 */
	public void removeSite(String strSiteCode)
	{
		eCRDSite objERCDRepairSite = new eCRDRepairSite();
		for (int i = 0; i < arrlstECRDRepairSite.size(); i++)
		{
			objERCDRepairSite = (eCRDSite) arrlstECRDRepairSite.get(i);
			if (objERCDRepairSite.getSiteCode().equalsIgnoreCase(strSiteCode))
			{
				arrlstECRDRepairSite.remove(i);
			}
		}
	}

	public eCRDRepairApproval getApproveRepairdetails() throws Exception
	{

		GEAEResultSet rsArroveRequestDetails = null;
		ArrayList arrInParam = null;
		ArrayList arrOutParam = null;
		String strActionId = null;
		String strModuleCode = null;
		String strEngineModel = null;
		eCRDRepairApproval objRepairAppr = null;
		eCRDException objException = null;
		eCRDEngineModel objECRDEngModel = null;
		eCRDComponent objECRDComponent = null;
		eCRDModule objECRDModule = null;
		eCRDEngineModel objECRDModel = null;
		eCRDCatalog objCataLog = null;
		try
		{
			arrInParam = new ArrayList();
			arrOutParam = new ArrayList();
			objRepairAppr = new eCRDRepairApproval();
			objECRDEngModel = new eCRDEngineModel();
			objECRDComponent = new eCRDComponent();
			objECRDModule = new eCRDModule();
			objECRDModel = new eCRDEngineModel();

			//Pass procedure input parameters to ArrayList

			objECRDComponent = getObjECRDComponent();
			if (objECRDComponent == null)
			{
				objException = new eCRDException();
				objException.setExcpId("COMPONENT_OBJECT_NOT_SET");
				throw objException;
			}

			objECRDModule = objECRDComponent.getModule();

			if (objECRDModule == null)
			{
				objException = new eCRDException();
				objException.setExcpId("MODULE_OBJECT_NOT_SET");
				throw objException;
			}

			objECRDModel = objECRDModule.getEngineModel();

			if (objECRDModel == null)
			{
				objException = new eCRDException();
				objException.setExcpId("MODEL_OBJECT_NOT_SET");
				throw objException;
			}

			objCataLog = objECRDModel.getCatalog();
			if (objCataLog == null)
			{
				objException = new eCRDException();
				objException.setExcpId("CATALOG_OBJECT_NOT_SET");
				throw objException;
			}
			strActionId = eCRDUtil.verifyNull((String) eCRDConstants.getActionId("eCRD_GET_REP_APPRV_REQUEST_DETAL"));
			arrInParam.add(this.getStrRepairCode());
			arrOutParam = eCRDDBMediator.doDBOperation(strActionId, arrInParam);
			rsArroveRequestDetails = (GEAEResultSet) arrOutParam.get(0);
			rsArroveRequestDetails.next();
			//objRepairAppr.setApprovalType(rsArroveRequestDetails.getString(0));
			objRepairAppr.setApprovedBy(rsArroveRequestDetails.getString(1));
			objRepairAppr.setApprovedDate(rsArroveRequestDetails.getString(2));
			objRepairAppr.setRequestorSite(rsArroveRequestDetails.getString(3));
			objRepairAppr.setRequestedBy(rsArroveRequestDetails.getString(4));
			objRepairAppr.setRequestStatus(rsArroveRequestDetails.getString(5));
			objRepairAppr.setChgType(rsArroveRequestDetails.getString(6));
			objRepairAppr.setRequestDate(rsArroveRequestDetails.getString(7));
			objRepairAppr.setRequestorMailId(rsArroveRequestDetails.getString(8));
			objRepairAppr.setRequestedByUserId(rsArroveRequestDetails.getString(9));
			return objRepairAppr;
		}
		finally
		{
			rsArroveRequestDetails = null;
			arrInParam = null;
			arrOutParam = null;
			strActionId = null;
			objECRDEngModel = null;
		}
	} // end of method

	public String removeRepair(String strUserId, String strUserRole) throws Exception
	{
		ArrayList arrInParam = null;
		ArrayList arrOutParam = null;
		String strActionId = null;
		String strOutMessage = null;
		eCRDException objException = null;
		eCRDEngineModel objECRDEngModel = null;
		eCRDComponent objECRDComponent = null;
		eCRDModule objECRDModule = null;
		eCRDEngineModel objECRDModel = null;

		try
		{
			arrInParam = new ArrayList();
			arrOutParam = new ArrayList();
			objECRDEngModel = new eCRDEngineModel();
			objECRDComponent = new eCRDComponent();
			objECRDModule = new eCRDModule();
			objECRDModel = new eCRDEngineModel();

			objECRDComponent = getObjECRDComponent();
			if (objECRDComponent == null)
			{
				objException = new eCRDException();
				objException.setExcpId("COMPONENT_OBJECT_NOT_SET");
				throw objException;
			}

			objECRDModule = objECRDComponent.getModule();
			if (objECRDModule == null)
			{
				objException = new eCRDException();
				objException.setExcpId("MODULE_OBJECT_NOT_SET");
				throw objException;
			}

			objECRDModel = objECRDModule.getEngineModel();
			if (objECRDModel == null)
			{
				objException = new eCRDException();
				objException.setExcpId("MODEL_OBJECT_NOT_SET");
				throw objException;
			}
			strActionId = eCRDUtil.verifyNull((String) eCRDConstants.getActionId("eCRD_DELETE_REPAIR"));

			arrInParam.add(this.getStrRepairCode());
			arrInParam.add(objECRDComponent.getComponentCode());
			arrInParam.add(objECRDModel.getEngineModelCode());
			arrInParam.add(objECRDModule.getModuleCode());
			arrInParam.add(eCRDUtil.verifyNull(this.strIsLastRepair));
			arrInParam.add(strUserId);
			arrInParam.add(strUserRole);
			arrOutParam = eCRDDBMediator.doDBOperation(strActionId, arrInParam);

			strOutMessage = (String) arrOutParam.get(0);
			return strOutMessage;
		}
		finally
		{
			arrInParam = null;
			arrOutParam = null;
			strActionId = null;
			objECRDEngModel = null;
		}
	}

	/**
	 * this method returns the site details of a given site associated with a repair
	 * @param strSiteCode
	 * @return
	 * @throws Exception
	 */
	public eCRDRepairSite getRepairSite(String strSiteCode) throws Exception
	{
		eCRDRepairSite objRepairSite = null;
		objRepairSite = new eCRDRepairSite();

		for (int i = 0; i < arrlstECRDRepairSite.size(); i++)
		{

			objRepairSite = (eCRDRepairSite) arrlstECRDRepairSite.get(i);
			if (objRepairSite.getSiteCode().equalsIgnoreCase(strSiteCode))
			{
				return objRepairSite;
			}
		}
		return objRepairSite;
	}

	/**
	 * this method returns all the sites associated with the repair
	 * @return
	 * @throws Exception
	 */

	public ArrayList getRepairSiteList() throws Exception
	{
		if (arrlstECRDRepairSite != null)
		{
			return arrlstECRDRepairSite;
		}
		else
		{
			arrlstECRDRepairSite = new ArrayList();
			return arrlstECRDRepairSite;
		}
	}
	/**get method to get the repair type
	 * @return
	 */
	public String getRepairType()
	{
		return strRepairType;
	}

	/**method to set the repair type
	 * @param string
	 */
	public void setRepairType(String strType)
	{
		strRepairType = strType;
	}

	/**get method to get the repair type
	 * @return
	 */
	public String getIsLastRepair()
	{
		return this.strIsLastRepair;
	}

	/**method to set the repair type
	 * @param string
	 */
	public void setIsLastRepair(String strIsLastRepair)
	{
		this.strIsLastRepair = strIsLastRepair;
	}

    /**
     * @return Returns the strRDNumber.
     */
    public String getStrRDNumber()
    {
        return strRDNumber;
    }
    /**
     * @param strRDNumber The strRDNumber to set.
     */
    public void setStrRDNumber(String strRDNumber)
    {
        this.strRDNumber = strRDNumber;
    }
    /**
     * @return Returns the strReasonRDOverride.
     */
    public String getStrReasonRDOverride()
    {
        return strReasonRDOverride;
    }
    /**
     * @param strReasonRDOverride The strReasonRDOverride to set.
     */
    public void setStrReasonRDOverride(String strReasonRDOverride)
    {
        this.strReasonRDOverride = strReasonRDOverride;
    }
    /**
     * @return Returns the strRDNumberComment.
     */
    public String getStrRDNumberComment()
    {
        return strRDNumberComment;
    }
    /**
     * @param strRDNumberComment The strRDNumberComment to set.
     */
    public void setStrRDNumberComment(String strRDNumberComment)
    {
        this.strRDNumberComment = strRDNumberComment;
    }
    /**
     * @return Returns the strRDNumberCreationDt.
     */
    public String getStrRDCreationDt()
    {
        return strRDCreationDt;
    }
    /**
     * @param strRDCreationDt The strRDCreationDt to set.
     */
    public void setStrRDCreationDt(String strRDCreationDt)
    {
        this.strRDCreationDt = strRDCreationDt;
    }
    /**
     * @return Returns the strRDNumberModifiedDt.
     */
    public String getStrRDModifiedDt()
    {
        return strRDModifiedDt;
    }
    /**
     * @param strRDModifiedDt The strRDModifiedDt to set.
     */
    public void setStrRDModifiedDt(String strRDModifiedDt)
    {
        this.strRDModifiedDt = strRDModifiedDt;
    }
    /**
     * @return Returns the strRDAssociation.
     */
    public String getStrRDAssociation()
    {
        return strRDAssociation;
    }
    /**
     * @param strRDAssociation The strRDAssociation to set.
     */
    public void setStrRDAssociation(String strRDAssociation)
    {
        this.strRDAssociation = strRDAssociation;
    }
    /**
     * @return Returns the strNPIClassification.
     */
    public String getStrNPIClassification()
    {
        return strNPIClassification;
    }
    /**
     * @param strNPIClassification The strNPIClassification to set.
     */
    public void setStrNPIClassification(String strNPIClassification)
    {
        this.strNPIClassification = strNPIClassification;
    }
} // end of class
