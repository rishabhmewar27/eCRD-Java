 /*
* Module    	    : eCRDRepairApproval.java
* Author      	    : PATNI-Offshore
* Project	        : eCRD
* Date Written		: October 2004
* Security	        : Unclassified
* Restrictions		: GE PROPRIETARY INFORMATION, FOR GE USE ONLY
*
*     ****************************************************
*     *  Copyright (2000) with all rights reserved       *
*     *          General Electric Company                *
*     ****************************************************
*
* Description: eCRDBusinessBean is used for getting the GEAE Row Cache Tag
*
* Revision Log  (mm/dd/yy initials description)
* --------------------------------------------------------------
*/

package ecrd.biz;

import ecrd.util.eCRDConstants;
import java.util.ArrayList;
import java.io.Serializable;
import ecrd.util.eCRDUtil;
import ecrd.common.eCRDDBMediator;
import ecrd.exception.eCRDException;
import geae.dao.GEAEResultSet;
import geae.messaging.GEAEMailMessage;
import geae.messaging.GEAEMailMessageException;

public class eCRDRepairApproval extends eCRDApprovalRequest implements Serializable
{
	private eCRDRepair objeCRDRepair = null;
	private eCRDRepair objStgeCRDRepair = null;
	private String strRepType = "";
	private String strRequestedUserID = "";
	private String approvalMailId = null;

	public eCRDRepairApproval()
	{

	}

	/**
	 * This method returns the eCRDComponent object 
	 * @parameter none
	 * @return eCRDRepair
	 */
	public eCRDRepair getMainRepair()
	{
		return this.objeCRDRepair;
	}
	/**
	 * @return
	 */
	public String getRequesterUserId()
	{
		return strRequestedUserID;
	}

	/**set method to get the repair User Id
	 * @return
	 */
	public void setRequestedByUserId(String strRequestedUserID)
	{
		this.strRequestedUserID = strRequestedUserID;
	}
	/**
	 * This method sets the eCRDComponent object
	 * @param eCRDRepair
	 * @return void
	 */
	public void setMainRepair(eCRDRepair objeCRDRepair)
	{
		this.objeCRDRepair = objeCRDRepair;
	}

	public eCRDRepair getStgApprovalRepair()
	{
		return this.objStgeCRDRepair;
	}

	public void setStgApprovalRepair(eCRDRepair objeCRDRepair)
	{
		this.objStgeCRDRepair = objeCRDRepair;
	}
	public String getApprovalMailId() {
		return approvalMailId;
	}

	public void setApprovalMailId(String approvalMailId) {
		this.approvalMailId = approvalMailId;
	}
	/**
	 * This method is an implementation of the abstract method in the SuperClass
	 * eCRDApprovalRequest for approving Components
	 * @param none
	 * @return void
	 * 
	 */
	public String approve() throws Exception, GEAEMailMessageException
	{
		ArrayList arrInParam = null;
		ArrayList arrOutParam = null;
		ArrayList alChildRepairs = null;
		String strActionId = "";
		String strMessage = "";
		String strChildRepairList = "";
		eCRDGroupedRepair objGroupedRepair = null;
		eCRDIndRepair objStgeIndRepair = null;
		eCRDChildRepair objChildRepair = null;
		eCRDRepairSite objRepairSite = null;
		StringBuffer strChildRepairBuff = null;
		StringBuffer strRepairSiteBuff = null;
		try
		{

			arrInParam = new ArrayList();
			arrOutParam = new ArrayList();
			strChildRepairBuff = new StringBuffer();
			if (this.objStgeCRDRepair instanceof eCRDGroupedRepair)
			{
				objGroupedRepair = (eCRDGroupedRepair) this.objStgeCRDRepair;

				alChildRepairs = objGroupedRepair.getChildRepairsList();
				for (int k = 0; k < alChildRepairs.size(); k++)
				{
					objChildRepair = (eCRDChildRepair) alChildRepairs.get(k);
					strChildRepairBuff.append(eCRDUtil.verifyNull(objChildRepair.getStrChildRepairCode()));
					
					strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
					strChildRepairBuff.append(eCRDUtil.verifyNull(objChildRepair.getStrReapirDesc()));
					strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
					strChildRepairBuff.append(eCRDUtil.verifyNull(this.getStgApprovalRepair().getStrRepairCode()));
					strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
					strChildRepairBuff.append(eCRDUtil.verifyNull(objChildRepair.getStrRepairRefNo()));
					strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
					strChildRepairBuff.append(eCRDUtil.verifyNull(objChildRepair.getStrComments()));
					strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
					strChildRepairBuff.append(eCRDUtil.verifyNull(objChildRepair.getStrReapairRefFormat()));
					strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
					strChildRepairBuff.append(eCRDUtil.verifyNull(this.getStgApprovalRepair().getDtRepairEffDate()));
					strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
					strChildRepairBuff.append(eCRDUtil.verifyNull(this.getStgApprovalRepair().getStrRepairVolume()));
					strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
					strChildRepairBuff.append(eCRDUtil.verifyNull(objChildRepair.getRepairSeqNo()));
					strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);

                    // Add new RD Number Values Sushant

                    strChildRepairBuff.append(eCRDUtil.verifyNull(objChildRepair.getStrRDNumber()));
                    strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                    strChildRepairBuff.append(eCRDUtil.verifyNull(objChildRepair.getStrReasonRDOverride()));
                    strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                    strChildRepairBuff.append(eCRDUtil.verifyNull(objChildRepair.getStrRDNumberComment()));
                    strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                    strChildRepairBuff.append(eCRDUtil.verifyNull(objChildRepair.getStrRDAssociation()));
                    strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                    strChildRepairBuff.append(eCRDUtil.verifyNull(objChildRepair.getStrRDCreationDt()));
                    strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                    strChildRepairBuff.append(eCRDUtil.verifyNull(objChildRepair.getStrRDModifiedDt()));
                    strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                    
                    strChildRepairBuff.append(eCRDConstants.STRROWDELIM);
				}
				arrInParam.add(eCRDUtil.verifyNull(objGroupedRepair.getStrRepairCode()));
				arrInParam.add(eCRDUtil.verifyNull(objGroupedRepair.getStrRepairDesc()));
				arrInParam.add(eCRDUtil.verifyNull(objGroupedRepair.getObjECRDComponent().getModule().getModuleCode()));
				arrInParam.add(eCRDUtil.verifyNull(objGroupedRepair.getObjECRDComponent().getComponentCode()));
				arrInParam.add(eCRDUtil.verifyNull(objGroupedRepair.getDtRepairEffDate()));
				arrInParam.add(eCRDUtil.verifyNull(objGroupedRepair.getStrRepairVolume()));
				arrInParam.add(eCRDUtil.verifyNull(objGroupedRepair.getStrComments()));
				if (objGroupedRepair.getObjRepairPricing().isFlgIncrTAT())
				{
					arrInParam.add(eCRDConstants.STRTRUE);
				}
				else
				{
					arrInParam.add(eCRDConstants.STRFALSE);
				}
				arrInParam.add(""+eCRDUtil.verifyNullReturnObject(objGroupedRepair.getObjRepairPricing().getIntTAT()));
				if (objGroupedRepair.getObjRepairPricing().isFlgIncrPrice())
				{
					arrInParam.add(eCRDConstants.STRTRUE);
				}
				else
				{
					arrInParam.add(eCRDConstants.STRFALSE);
				}
				arrInParam.add(""+eCRDUtil.verifyNullReturnObject( objGroupedRepair.getObjRepairPricing().getDblPrice()));
				arrInParam.add(eCRDUtil.verifyNull(objGroupedRepair.getObjRepairPricing().getStrPriceType()));
				arrInParam.add(""+eCRDUtil.verifyNullReturnObject( objGroupedRepair.getObjRepairPricing().getIntFutureTAT()));
				arrInParam.add(""+eCRDUtil.verifyNullReturnObject( objGroupedRepair.getObjRepairPricing().getDblFuturePrice()));
				arrInParam.add(eCRDUtil.verifyNull(objGroupedRepair.getObjRepairPricing().getDtFuturePriceTATEffDt()));
				arrInParam.add(eCRDUtil.verifyNull(this.getApprovedBy()));
				arrInParam.add(eCRDUtil.verifyNull(this.objStgeCRDRepair.getObjECRDComponent().getModule().getEngineModel().getCatalog().getCatalogSeqId()));
				arrInParam.add(eCRDUtil.verifyNull(objGroupedRepair.getObjRepairPricing().getRepairSeqNo()));
				arrInParam.add(eCRDUtil.verifyNull(this.getChgType()));
                arrInParam.add(eCRDUtil.verifyNull(strChildRepairBuff.toString()));
				arrInParam.add(eCRDUtil.verifyNull(eCRDConstants.STRROWDELIM));
				arrInParam.add(eCRDUtil.verifyNull(eCRDConstants.STRCOLUMNDELIM));

                arrInParam.add(eCRDUtil.verifyNull(objGroupedRepair.getStrRDNumber()));
                arrInParam.add(eCRDUtil.verifyNull(objGroupedRepair.getStrReasonRDOverride()));
                arrInParam.add(eCRDUtil.verifyNull(objGroupedRepair.getStrRDNumberComment()));
                arrInParam.add(eCRDUtil.verifyNull(objGroupedRepair.getStrRDAssociation()));
                arrInParam.add(eCRDUtil.verifyNull(objGroupedRepair.getStrNPIClassification()));

                if (this.getChgType().equals("M"))
				{
					strActionId = eCRDConstants.getActionId("eCRD_APPRV_GRP_REPAIR");
				}
				else if (this.getChgType().equals("N"))
				{
					strActionId = eCRDConstants.getActionId("eCRD_APPROVE_NEW_GRP_REPAIR");
				}

			}
			else if (this.objStgeCRDRepair instanceof eCRDIndRepair)
			{
				objStgeIndRepair = (eCRDIndRepair) this.objStgeCRDRepair;

				arrInParam.add(eCRDUtil.verifyNull(objStgeIndRepair.getStrRepairCode()));
				arrInParam.add(eCRDUtil.verifyNull(objStgeIndRepair.getStrRepairDesc()));
				arrInParam.add(eCRDUtil.verifyNull(objStgeIndRepair.getObjECRDComponent().getModule().getModuleCode()));
				arrInParam.add(eCRDUtil.verifyNull(objStgeIndRepair.getObjECRDComponent().getComponentCode()));
				arrInParam.add(eCRDUtil.verifyNull(objStgeIndRepair.getDtRepairEffDate()));
				arrInParam.add(eCRDUtil.verifyNull(objStgeIndRepair.getStrRepairVolume()));
				arrInParam.add(eCRDUtil.verifyNull(objStgeIndRepair.getRepairRefNo()));
				arrInParam.add(eCRDUtil.verifyNull(objStgeIndRepair.getRepairRefFormat()));
				arrInParam.add(eCRDUtil.verifyNull(objStgeIndRepair.getStrComments()));
				if (objStgeIndRepair.getObjRepairPricing().isFlgIncrTAT())
				{
					arrInParam.add(eCRDConstants.STRTRUE);
				}
				else
				{
					arrInParam.add(eCRDConstants.STRFALSE);
				}
				arrInParam.add(""+eCRDUtil.verifyNullReturnObject(objStgeIndRepair.getObjRepairPricing().getIntTAT()));
				if (objStgeIndRepair.getObjRepairPricing().isFlgIncrPrice())
				{
					arrInParam.add(eCRDConstants.STRTRUE);
				}
				else
				{
					arrInParam.add(eCRDConstants.STRFALSE);
				}

				arrInParam.add(""+eCRDUtil.verifyNullReturnObject( objStgeIndRepair.getObjRepairPricing().getDblPrice()));
				arrInParam.add(eCRDUtil.verifyNull(objStgeIndRepair.getObjRepairPricing().getStrPriceType()));
				arrInParam.add(""+eCRDUtil.verifyNullReturnObject(objStgeIndRepair.getObjRepairPricing().getIntFutureTAT()));
				arrInParam.add(""+eCRDUtil.verifyNullReturnObject(objStgeIndRepair.getObjRepairPricing().getDblFuturePrice()));
				arrInParam.add(eCRDUtil.verifyNull(objStgeIndRepair.getObjRepairPricing().getDtFuturePriceTATEffDt()));
				arrInParam.add(eCRDUtil.verifyNull(this.getApprovedBy()));
				arrInParam.add(eCRDUtil.verifyNull(objStgeIndRepair.getObjECRDComponent().getModule().getEngineModel().getCatalog().getCatalogSeqId()));
				arrInParam.add(eCRDUtil.verifyNull(this.objStgeCRDRepair.getObjRepairPricing().getRepairSeqNo()));
                
				if (this.getChgType().equals("M"))
				{
					arrInParam.add(eCRDUtil.verifyNull(this.getChgType()));
				}

                if (this.getChgType().equals("N"))
				{
					arrInParam.add(eCRDConstants.STRROWDELIM);
					arrInParam.add(eCRDConstants.STRCOLUMNDELIM);
				}
				
				if (this.getChgType().equals("M"))
				{
					strActionId = eCRDConstants.getActionId("eCRD_APPROVE_IND_REPAIR");
				}
				else
				{
					strActionId = eCRDConstants.getActionId("eCRD_APPROVE_NEW_IND_REPAIR");
				}

                arrInParam.add(eCRDUtil.verifyNull(objStgeIndRepair.getStrRDNumber()));
                arrInParam.add(eCRDUtil.verifyNull(objStgeIndRepair.getStrReasonRDOverride()));
                arrInParam.add(eCRDUtil.verifyNull(objStgeIndRepair.getStrRDNumberComment()));
                arrInParam.add(eCRDUtil.verifyNull(objStgeIndRepair.getStrRDAssociation()));
                arrInParam.add(eCRDUtil.verifyNull(objStgeIndRepair.getStrNPIClassification()));

            }

			if (this.getChgType().equals("N"))
			{
				strRepairSiteBuff = new StringBuffer();
				for (int l = 0; l < this.objStgeCRDRepair.getArrlstECRDRepairSite().size(); l++)
				{
					objRepairSite = (eCRDRepairSite) this.objStgeCRDRepair.getArrlstECRDRepairSite().get(l);
					strRepairSiteBuff.append(objRepairSite.getSiteCode());
					
					strRepairSiteBuff.append(eCRDConstants.STRCOLUMNDELIM);
					strRepairSiteBuff.append(objRepairSite.getMaterialCost());
					
					strRepairSiteBuff.append(eCRDConstants.STRCOLUMNDELIM);
					strRepairSiteBuff.append(objRepairSite.getLaborHr());
					strRepairSiteBuff.append(eCRDConstants.STRCOLUMNDELIM);

					strRepairSiteBuff.append(eCRDConstants.STRROWDELIM);
				}
				arrInParam.add(strRepairSiteBuff.toString());
				
			}

            arrOutParam = eCRDDBMediator.doDBOperation(strActionId, arrInParam);
			strMessage = (String) arrOutParam.get(0);
			
			if (strMessage.equalsIgnoreCase("APPROVE_REPAIR_SUCCESS"))
			{
				sendNotification();
			}
		}
		finally
		{
			arrInParam = null;
			arrOutParam = null;
			strChildRepairBuff = null;
			objGroupedRepair = null;
			objStgeIndRepair = null;
			strActionId = null;
		}
		return strMessage;
	}

	/**
	 * This method is an implementation of the abstract method in the SuperClass
	 * eCRDApprovalRequest for Rejection of Components.
	 * @param none
	 * @return void
	 */
	public String reject() throws Exception
	{
		ArrayList arrInParam = null;
		ArrayList arrOutParam = null;
		String strMessage = "";
		String strActionId = "";
		eCRDConstants objeCRDConstants = new eCRDConstants();
		try
		{
			arrInParam = new ArrayList();
			arrOutParam = new ArrayList();
			arrInParam.add(this.objStgeCRDRepair.getStrRepairCode());
			
			arrInParam.add(this.objStgeCRDRepair.getObjECRDComponent().getModule().getEngineModel().getCatalog().getCatalogSeqId());
			arrInParam.add(this.getApprovedBy());
			arrInParam.add(this.getRejectionComments());
			arrInParam.add(this.objStgeCRDRepair.getObjECRDComponent().getModule().getModuleCode());
			arrInParam.add(this.objStgeCRDRepair.getObjECRDComponent().getComponentCode());
			
			strActionId = eCRDConstants.getActionId("eCRD_REJECT_REPAIR");
			
			
			arrOutParam = eCRDDBMediator.doDBOperation(strActionId, arrInParam);
			
			strMessage = (String) arrOutParam.get(0);
			
			if (strMessage.equalsIgnoreCase("REPAIR_REJECT_SUCCESS")) {
				sendNotificationRepair();
			}
			
		}
		finally
		{
			arrInParam = null;
		}
		return strMessage;
	}

	public eCRDRepair getStagingData() throws Exception
	{
		try
		{
			if (this.objeCRDRepair instanceof eCRDIndRepair)
			{
				this.objStgeCRDRepair =
					(eCRDRepair) new eCRDIndRepair(this.objeCRDRepair.getStrRepairCode(),
						this.objeCRDRepair.getObjECRDComponent().getModule().getModuleCode(),
						this.objeCRDRepair.getObjECRDComponent().getComponentCode(),
						eCRDCatalog.getCurrentDefaultSeqId(this.objeCRDRepair.getObjECRDComponent().getModule().getEngineModel().getEngineModelCode()));
			}
			else
			{
				this.objStgeCRDRepair =
					new eCRDGroupedRepair(
						this.objeCRDRepair.getStrRepairCode(),
						this.objeCRDRepair.getObjECRDComponent().getModule().getModuleCode(),
						this.objeCRDRepair.getObjECRDComponent().getComponentCode(),
						eCRDCatalog.getCurrentDefaultSeqId(this.objeCRDRepair.getObjECRDComponent().getModule().getEngineModel().getEngineModelCode()));
			}
		}
		finally
		{
		}
		return this.objStgeCRDRepair;
	}
	public eCRDRepair getMasterData(String strRepairType) throws Exception
	{
		try
		{
			if (strRepairType.equals("IR"))
			{
				this.objeCRDRepair =
					(eCRDRepair) new eCRDIndRepair(this.objStgeCRDRepair.getStrRepairCode(),
						this.objStgeCRDRepair.getObjECRDComponent().getModule().getModuleCode(),
						this.objStgeCRDRepair.getObjECRDComponent().getComponentCode(),
						eCRDCatalog.getCurrentDefaultSeqId(this.objStgeCRDRepair.getObjECRDComponent().getModule().getEngineModel().getEngineModelCode()),
						eCRDConstants.STRMASTERDATA);
			}
			else
			{
				this.objeCRDRepair =
					(eCRDRepair) new eCRDGroupedRepair(this.objStgeCRDRepair.getStrRepairCode(),
						this.objStgeCRDRepair.getObjECRDComponent().getModule().getModuleCode(),
						this.objStgeCRDRepair.getObjECRDComponent().getComponentCode(),
						eCRDCatalog.getCurrentDefaultSeqId(this.objStgeCRDRepair.getObjECRDComponent().getModule().getEngineModel().getEngineModelCode()),
						eCRDConstants.STRMASTERDATA);
			}
		}
		finally
		{
		}
		return this.objeCRDRepair;
	}
	/**This method set the type of the repair that has to be approved
	 */
	public void setRepairType(String strRepairType)
	{
		this.strRepType = strRepairType;
	}

	/*This method return the repair type of the repair
	 * 
	 */

	public String getRepairType()
	{
		return this.strRepType;
	}

	public String getStringChildRepairList(ArrayList arrLstChldRep) throws Exception
	{
		String strChRep = "";
		eCRDChildRepair objChldRepair = null;
		StringBuffer strChildRepairBuff = null;
		try
		{
			strChildRepairBuff = new StringBuffer();
			for (int i = 0; i < arrLstChldRep.size(); i++)
			{
				objChldRepair = (eCRDChildRepair) arrLstChldRep.get(i);
				strChildRepairBuff.append(objChldRepair.getStrChildRepairCode());
				strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);

				strChildRepairBuff.append(objChldRepair.getRepairSeqNo());
				strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);

				strChildRepairBuff.append(objChldRepair.getStrComments());
				strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);

				strChildRepairBuff.append(objChldRepair.getStrReapairRefFormat());
				strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);

				strChildRepairBuff.append(objChldRepair.getStrReapirDesc());
				strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);

				strChildRepairBuff.append(objChldRepair.getStrRepairRefNo());

				strChildRepairBuff.append(eCRDConstants.STRROWDELIM);

			}
			strChRep = strChildRepairBuff.toString();
			return strChRep;
		}
		finally
		{
			strChildRepairBuff = null;
		}
	}

	public ArrayList getApprovalRepair(String strActionID,String strRole,String strUserId) throws Exception
	{
		ArrayList arrLstOutParam = null;
		ArrayList arrLstInParam = null;
		try
		{
			arrLstOutParam = new ArrayList();
			arrLstInParam = new ArrayList();
			arrLstInParam.add(eCRDUtil.verifyNull(strRole));
			arrLstInParam.add(eCRDUtil.verifyNull(strUserId));
			arrLstOutParam = eCRDDBMediator.doDBOperation(strActionID, arrLstInParam);
			return arrLstOutParam;
		}
		finally
		{
			arrLstInParam = null;
			arrLstOutParam = null;
		}
		
	}

	public ArrayList getApprovalHist(String strActionID, String strRepairCode, String strCatalogSeqId) throws Exception
	{
		ArrayList arrLstOutParam = new ArrayList();
		ArrayList arrLstInParam = new ArrayList();
		try
		{
			arrLstInParam.add(strRepairCode);
			arrLstInParam.add(strCatalogSeqId);
			arrLstOutParam = eCRDDBMediator.doDBOperation(strActionID, arrLstInParam);
		}
		finally
		{
			arrLstInParam = null;
		}
		return arrLstOutParam;
	}

	public void sendNotification() throws GEAEMailMessageException, Exception
	{
		ArrayList arlstMailTo = null;
		GEAEMailMessage eCRDMail = null;
		String[] strMailId = null;
		StringBuffer strMailBody = null;
		GEAEResultSet rsMailId = null;
		try
		{
			eCRDMail = new GEAEMailMessage();
			strMailBody =new StringBuffer();
			
			arlstMailTo = new ArrayList();
			//arlstMailTo.add("sachin.shrivastav@ge.com");
			arlstMailTo.add("kumar.naravamakula@ge.com");
			arlstMailTo.add("Sreesujitha.Venkata@ge.com");	
			//arlstMailTo = eCRDUtil.getEmaiID(this.getStgApprovalRepair().getObjECRDComponent());
			if (arlstMailTo.size() != 0)
			{
				strMailId = eCRDUtil.convertArrayListtoArray(arlstMailTo);
				eCRDMail.setSender(this.getApprovedBy());
				
				eCRDMail.setSubject("The repair " + this.getStgApprovalRepair().getStrRepairDesc() + " is approved by eCRD Administrator" );
				eCRDMail.setRecipients(GEAEMailMessage.TO, strMailId);
				strMailBody.append("*** This email message was generated by eCRD system. Please do not reply as the mail-box is not monitored ***\n\r");
				strMailBody.append("Engine Model      : " + this.getStgApprovalRepair().getObjECRDComponent().getModule().getEngineModel().getEngineModelDesc() + "\n\r" );
				strMailBody.append("Engine Module     : " + this.getStgApprovalRepair().getObjECRDComponent().getModule().getModuleDesc()+ "\n\r" );
				strMailBody.append("Component Code    : " + this.getStgApprovalRepair().getObjECRDComponent().getComponentCode()+ "\n\r" );
				strMailBody.append("Component Desc    : " + this.getStgApprovalRepair().getObjECRDComponent().getComponentDesc()+ "\n\r" );
				
				
				if(this.getStgApprovalRepair().getObjRepairPricing().getRepairSeqNo()==null)
				{
					if(this.getMainRepair()!=null)
					{
						if(this.getMainRepair().getObjRepairPricing().getRepairSeqNo()!=null)
						{
							strMailBody.append("Repair Disp Seq   : " + this.getMainRepair().getObjRepairPricing().getRepairSeqNo()+ "\n\r" );
						}
					}
				}
				else
				{
					strMailBody.append("Repair Disp Seq   : " + this.getStgApprovalRepair().getObjRepairPricing().getRepairSeqNo()+ "\n\r" );
				}
				strMailBody.append("Repair Desc       : " + this.getStgApprovalRepair().getStrRepairDesc()+ "\n\r" );
				strMailBody.append("The above repair has been approved by eCRD Administrator" );
				strMailBody.append("\n\r");
				strMailBody.append("\n\r");
				strMailBody.append("\n\r");
				strMailBody.append("\n\r");
				strMailBody.append("\n\r");
				strMailBody.append("\n\r");
				strMailBody.append("\n\r");
				strMailBody.append("\n\r");
				strMailBody.append(eCRDConstants.STRDISCLAIMER);
				eCRDMail.setText(strMailBody.toString() );
				eCRDMail.send();
			}
		}
		catch (GEAEMailMessageException objMailException)
		{
			eCRDException objException = null;
			objException = new eCRDException();
			objException.setExcpId("EMAIL_SEND_ERROR");
			throw objException;
		}
		finally
		{
			eCRDMail = null;
		}
	}
	
	
	public void sendNotificationRepair() throws GEAEMailMessageException, Exception
	{
		
		ArrayList arlstMailTo = new ArrayList();
		GEAEMailMessage eCRDMail = null;
		String[] strMailId = null;
		StringBuffer strMailBody = null;
		GEAEResultSet rsMailId = null;
		try
		{
			eCRDMail = new GEAEMailMessage();
			strMailBody =new StringBuffer();
			//arlstMailTo.add("sachin.shrivastav@ge.com");
			arlstMailTo.add("kumar.naravamakula@ge.com");
			arlstMailTo.add("Sreesujitha.Venkata@ge.com");	
			//arlstMailTo = eCRDUtil.getEmaiID(this.getStgApprovalRepair().getObjECRDComponent());
			/*
			 * Changes done by TCS Team on 16 Nov 2011
			 */
			if(this.getRequestorMailId()!=null)
			arlstMailTo.add(this.getRequestorMailId());
			
			if (arlstMailTo.size() != 0)
			{
				strMailId = eCRDUtil.convertArrayListtoArray(arlstMailTo);
				eCRDMail.setSender(this.getApprovalMailId());
				
				
				eCRDMail.setSubject("The repair " + this.getStgApprovalRepair().getStrRepairDesc() + " is rejected by eCRD Administrator" );
				eCRDMail.setRecipients(GEAEMailMessage.TO, strMailId);
				eCRDMail.setRecipients(GEAEMailMessage.CC, new String[]{this.getApprovalMailId()});
				strMailBody.append("*** This email message was generated by eCRD system. Please do not reply as the mail-box is not monitored ***\n\r");
				strMailBody.append("Engine Model      : " + this.getStgApprovalRepair().getObjECRDComponent().getModule().getEngineModel().getEngineModelDesc() + "\n\r" );
				strMailBody.append("Engine Module     : " + this.getStgApprovalRepair().getObjECRDComponent().getModule().getModuleDesc()+ "\n\r" );
				strMailBody.append("Component Code    : " + this.getStgApprovalRepair().getObjECRDComponent().getComponentCode()+ "\n\r" );
				strMailBody.append("Component Desc    : " + this.getStgApprovalRepair().getObjECRDComponent().getComponentDesc()+ "\n\r" );
				
				if(this.getStgApprovalRepair().getObjRepairPricing().getRepairSeqNo()==null)
				{
					if(this.getMainRepair()!=null)
					{
						if(this.getMainRepair().getObjRepairPricing().getRepairSeqNo()!=null)
						{
							strMailBody.append("Repair Disp Seq   : " + this.getMainRepair().getObjRepairPricing().getRepairSeqNo()+ "\n\r" );
						}
					}
				}
				else
				{
					strMailBody.append("Repair Disp Seq   : " + this.getStgApprovalRepair().getObjRepairPricing().getRepairSeqNo()+ "\n\r" );
				}
				
				strMailBody.append("Repair Desc       : " + this.getStgApprovalRepair().getStrRepairDesc()+ "\n\r" );
				strMailBody.append("The above repair has been rejected by eCRD Administrator \n \n" );
				strMailBody.append("Rejection Comments: \n" +  this.getRejectionComments());
				strMailBody.append("\n\r");
				strMailBody.append("\n\r");
				strMailBody.append("\n\r");
				strMailBody.append("\n\r");
				strMailBody.append("\n\r");
				strMailBody.append("\n\r");
				strMailBody.append("\n\r");
				strMailBody.append("\n\r");
				strMailBody.append(eCRDConstants.STRDISCLAIMER);
				eCRDMail.setText(strMailBody.toString() );
				eCRDMail.send();
			}
		}
		catch (GEAEMailMessageException objMailException)
		{
			eCRDException objException = null;
			objException = new eCRDException();
			objException.setExcpId("EMAIL_SEND_ERROR");
			throw objException;
		}
		finally
		{
			eCRDMail = null;
		}
		
	}
	
	
}
