/*
* Module    	    : eCRDRepairPricing.java
* Author      	    : PATNI-Offshore
* Project	        : eCRD
* Date Written		: October 2004
* Security	        : Unclassified
* Restrictions		: GE PROPRIETARY INFORMATION, FOR GE USE ONLY
*
*     ****************************************************
*     *  Copyright (2000) with all rights reserved       *
*     *          General Electric Company                *
*     ****************************************************
*
* Description: eCRDBusinessBean is used for getting the GEAE Row Cache Tag
*
* Revision Log  (mm/dd/yy initials description)
* --------------------------------------------------------------
*/

package ecrd.biz;

import java.util.ArrayList;
import ecrd.common.eCRDDBMediator;

public class eCRDRepairPricing
{
	private String strRepairSeqNo = null;
	private boolean flgIncrTAT = false;
	private Integer intTAT = null;
	private Integer intFutureTAT = null;
	private Double dblFuturePrice = null;
	private String dtFuturePriceTATEffDt = null;
	private String strPriceType = null;

	private boolean flgIncrPrice = false;
	private boolean flgPriceOverWriteInd = false;
	private Double dblPrice = null;
	private eCRDRepair objCRDRepair = null;
	/**
	 * @return
	 */
	public Double getDblFuturePrice()
	{
		return dblFuturePrice;
	}

	/**
	 * @param dblFuturePrice
	 */
	public void setDblFuturePrice(Double dblFuturePrice)
	{
		this.dblFuturePrice = dblFuturePrice;
	}

	/**
	 * @return
	 */
	public Double getDblPrice()
	{
		return dblPrice;
	}

	/**
	 * @param dblPrice
	 */
	public void setDblPrice(Double dblPrice)
	{
		this.dblPrice = dblPrice;
	}

	/**
	 * @return
	 */
	public String getDtFuturePriceTATEffDt()
	{
		return dtFuturePriceTATEffDt;
	}

	/**
	 * @param dtFuturePriceTATEffDt
	 */
	public void setDtFuturePriceTATEffDt(String dtFuturePriceTATEffDt)
	{
		this.dtFuturePriceTATEffDt = dtFuturePriceTATEffDt;
	}

	/**
	 * @return
	 */
	public boolean isFlgIncrPrice()
	{
		return flgIncrPrice;
	}

	/**
	 * @param flgIncrPrice
	 */
	public void setFlgIncrPrice(boolean flgIncrPrice)
	{
		this.flgIncrPrice = flgIncrPrice;
	}

	/**
	 * @return
	 */

	public boolean isFlgPriceOverWriteInd()
	{
		return flgPriceOverWriteInd;
	}

	/**
	 * @param flgIncrPrice
	 */
	public void setFlgPriceOverWriteInd(boolean flgPriceOverWriteInd)
	{
		this.flgPriceOverWriteInd = flgPriceOverWriteInd;
	}

	/**
	 * @return
	 */
	public eCRDRepair getObjCRDRepair()
	{
		return objCRDRepair;
	}

	/**
	 * @param objCRDRepair
	 */
	public void setObjCRDRepair(eCRDRepair objCRDRepair)
	{
		this.objCRDRepair = objCRDRepair;
	}

	/**
	 * Constructor
	 */
	public eCRDRepairPricing()
	{
	}

	public boolean isFlgIncrTAT()
	{
		return flgIncrTAT;
	}

	/**
	 * @param flgIncrTAT
	 */
	public void setFlgIncrTAT(boolean flgIncrTAT)
	{
		this.flgIncrTAT = flgIncrTAT;
	}

	/**
	 * @return
	 */
	public Integer getIntFutureTAT()
	{
		return intFutureTAT;
	}

	/**
	 * @param intFutureTAT
	 */
	public void setIntFutureTAT(Integer intFutureTAT)
	{
		this.intFutureTAT = intFutureTAT;
	}

	/**
	 * @return
	 */
	public String getRepairSeqNo()
	{
		return strRepairSeqNo;
	}

	/**
	 * @param i
	 */
	public void setRepairSeqNo(String repairSeq)
	{
		strRepairSeqNo = repairSeq;
	}

	/**
	 * @return
	 */
	public Integer getIntTAT()
	{
		return intTAT;
	}

	/**
	 * @param intTAT
	 */
	public void setIntTAT(Integer intTAT)
	{
		this.intTAT = intTAT;
	}

	/**
	 * @return
	 	*/
	public String getStrPriceType()
	{
		return strPriceType;
	}


	/**
	 * @param strPriceType
	 */
	public void setStrPriceType(String strPriceType)
	{
		this.strPriceType = strPriceType;
	}

	// This method is used to update repair pricing info
	public String update(String strAction, ArrayList arrlstInParam) throws Exception
	{
		ArrayList arrlstOutParam = null;

		try
		{
			arrlstOutParam = eCRDDBMediator.doDBOperation(strAction, arrlstInParam);
			return ((String) arrlstOutParam.get(0));
		}
		finally
		{
			arrlstOutParam = null;
		}
	}
	
	public void updatePriceOverWriteInd(String strAction, ArrayList arrlstInParam) throws Exception
	{
		ArrayList arrlstOutParam = null;
		try
		{
			arrlstOutParam = eCRDDBMediator.doDBOperation(strAction, arrlstInParam);
		}
		finally
		{
			arrlstOutParam = null;
		}
	}
}