/*
* Module    	    : eCRDRepairSite.java
* Author      	    : PATNI-Offshore
* Project	        : eCRD
* Date Written		: October 2004
* Security	        : Unclassified
* Restrictions		: GE PROPRIETARY INFORMATION, FOR GE USE ONLY
*
*     ****************************************************
*     *  Copyright (2000) with all rights reserved       *
*     *          General Electric Company                *
*     ****************************************************
*
* Description: eCRDBusinessBean is used for getting the GEAE Row Cache Tag
*
* Revision Log  (mm/dd/yy initials description)
* --------------------------------------------------------------
*/
package ecrd.biz;

/**
 * This entity represents sites attached to repair.
 */
public class eCRDRepairSite extends eCRDSite
{
	private double dblMaterialCost = 0;
	private double dblLaborHr = 0;
	private double dblTotalCost = 0;
	private double dblCM = 0;
	public eCRDGroupedRepair objECRDGroupedRepair = null;
	public eCRDIndRepair objECRDIndRepair = null;

	/**
	 * @return
	 */
	public double getCM()
	{
		return dblCM;
	}

	/**
	 * @param dblCM
	 */
	public void setCM(double dblCM)
	{
		this.dblCM = dblCM;
	}

	/**
	 * @return
	 */
	public double getMaterialCost()
	{
		return dblMaterialCost;
	}

	/**
	 * @param dblMaterialCost
	 */
	public void setMaterialCost(double dblMaterialCost)
	{
		this.dblMaterialCost = dblMaterialCost;
	}

	/**
	 * @return
	 */
	public double getTotalCost()
	{
		return dblTotalCost;
	}

	/**
	 * @param dblTotalCost
	 */
	public void setTotalCost(double dblTotalCost)
	{
		this.dblTotalCost = dblTotalCost;
	}

	/**
	 * @return
	 */
	public double getLaborHr()
	{
		return dblLaborHr;
	}

	/**
	 * @param intLaborHr
	 */
	public void setLaborHr(double dblLaborHr)
	{
		this.dblLaborHr = dblLaborHr;
	}

	/**
	 * @return
	 */
	public eCRDIndRepair getECRDIndRepair()
	{
		return objECRDIndRepair;
	}

	/**
	 * @param theECRDGroupedRepair
	 */
	public void setECRDIndRepair(eCRDIndRepair ECRDIndRepair)
	{
		this.objECRDIndRepair = ECRDIndRepair;
	}

	/**
	 * @return
	 */
	public eCRDGroupedRepair getECRDGroupedRepair()
	{
		return objECRDGroupedRepair;
	}

	/**
	 * @param theECRDGroupedRepair
	 */
	public void setECRDGroupedRepair(eCRDGroupedRepair ECRDGroupedRepair)
	{
		this.objECRDGroupedRepair = ECRDGroupedRepair;
	}

	public eCRDRepairSite()
	{

	}

}
