/*
* Module    	    : eCRDSite.java
* Author      	    : PATNI-Offshore
* Project	        : eCRD
* Date Written		: October 2004
* Security	        : Unclassified
* Restrictions		: GE PROPRIETARY INFORMATION, FOR GE USE ONLY
*
*     ****************************************************
*     *  Copyright (2000) with all rights reserved       *
*     *          General Electric Company                *
*     ****************************************************
*
* Description: This class represents Site for the Component. This is a base class. Child Class is for repair site.
*
* Revision Log  (mm/dd/yy initials description)
* --------------------------------------------------------------
*/
package ecrd.biz;
import java.util.ArrayList;
import java.io.Serializable;
import ecrd.util.eCRDConstants;
import ecrd.common.eCRDDBMediator;
import ecrd.exception.eCRDException;

/**
 * This entity represent sites attched to components.
 */
public class eCRDSite implements Serializable 
{
	/**
	 * Site Code.
	 */	
   private String strSiteCode = null;

   /**
	* Site Description.
	*/   
   private String strSiteDescription = null;
   
   /**
    * Location Labor Rate
    */
   private double dblLocationLaborRate = 0;
   
   /**
    * Flag which indicates whether this object is loaded partially or fully. 
    * True : Partial Loading
    * False : Full Loading
    */
   private boolean flgIsLoadedPartially = true;

   /**
	* String variable which indicates whether component has to be hidden from this site or not
	* 'Y' : Component To be hidden
	* 'N' :Component Not To be hidden
	*/
   private String strHideComponentInd = null;

   
   /**
    * Load site details based on the site code passed.
    * @param strSiteCode
    */
   public eCRDSite(String strSiteCode) throws Exception 
   {
	ArrayList arrlstInpParam = null;
	ArrayList arrlstOutParam = null;
	String strActionId = null;
//	String strErrorMsg = null;
	eCRDException objException = null;
	try
	{	
		if (strSiteCode == null)
		{
			objException = new eCRDException();
			objException.setExcpId("SITE_CODE_NULL");
			throw  objException;
		}		
		
		//Set the action id to call appropriate procedure 
		strActionId = eCRDConstants.getActionId("eCRD_LOAD_SITE");
		
		//ArrayList of Input Parameters
		arrlstInpParam = new ArrayList();
		//ArrayList of Output Parameters
		arrlstOutParam = new ArrayList();		
		//ArrayList would be Site Code
		arrlstInpParam.add(strSiteCode);
		
		// Call this function to retrieve details of the site from database
		arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);
		
		//Set all parameters as retrieved from the database
		this.setSiteCode(strSiteCode);
		this.setSiteDescription((String) arrlstOutParam.get(0));
		this.setLocationLaborRate(Double.parseDouble((String) arrlstOutParam.get(1)));
		this.flgIsLoadedPartially = false;
	}
	finally
	{
		arrlstInpParam = null;
		arrlstOutParam = null;
		strActionId = null;
//		strErrorMsg = null;
	}    
   }
   
   /**
    * Default Constructor
    */
   public eCRDSite() 
   {
    
   }
   
   /**
    * Returns Site Code
	* @return String
	*/
   public String getSiteCode() 
   {
	return strSiteCode;
   }

   /**
    * Returns Site Description
    * @return String
    */
   public String getSiteDescription() 
   {
    return strSiteDescription;
   }   
   
   /**
    * Returns Location Labor Rate
    * @return double
    */
   public double getLocationLaborRate() 
   {
    return this.dblLocationLaborRate;
   }

   /**
	* Returns String For Hide Component Indicator
	* @return String
	*/
	  public String  getHideComponentInd() 
	  {
	   return this.strHideComponentInd;
	  }
      


   /**
	* Sets Site Description
	* @return double
	*/   
   public void setSiteDescription(String streCRDSiteDescription) 
   {
	this.strSiteDescription = streCRDSiteDescription;
   }

   /**
	* Sets Site Code
	* @return double
	*/      
   public void setSiteCode(String streCRDSiteCode) 
   {
	this.strSiteCode = streCRDSiteCode;
   }
   
   /**
	* Returns String For Hide Component Indicator
	* @return String
	*/
	public void setHideComponentInd(String strHideComponentInd) 
	{
		this.strHideComponentInd = strHideComponentInd;
	}
       
   
   /**
    * Set the location Labor Rate to the site
    * @param dblLocationLaborRate
    */
   public void setLocationLaborRate(double dbleCRDLocationLaborRate) 
   {
	this.dblLocationLaborRate = dbleCRDLocationLaborRate;    
   }
   
      
   /**
    * Updates the Location labor rate for the site.
    */
   public String update(String strUser, String strRole) throws Exception 
   {
	ArrayList arrlstInpParam = null;
	ArrayList arrlstOutParam = null;
	String strActionId = null;
//	String strErrorMsg = null;
	eCRDException objException = null;
	try
	{
		
		if (this.strSiteCode == null )
		{
			objException = new eCRDException();
			objException.setExcpId("SET_PARAMETERS_NULL");
			throw  objException;
		}		
	
		//Set the action id to call appropriate procedure 
		strActionId = eCRDConstants.getActionId("eCRD_UPDATE_SITE");
		
		
		//ArrayList of Input Parameters
		arrlstInpParam = new ArrayList();		
		//ArrayList of Output Parameters
		arrlstOutParam = new ArrayList();		
		//Pass procedure input parameters to ArrayList
		arrlstInpParam.add(this.strSiteCode);
		
		arrlstInpParam.add(this.strSiteDescription);
		
		arrlstInpParam.add(Double.toString(dblLocationLaborRate));

		arrlstInpParam.add(strUser);	

		
		// Call this function to update site details 
		arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);
		
		//Return the message code retrieved from procedure
		return (String) arrlstOutParam.get(0);
	}
	finally
	{
		arrlstInpParam = null;
		arrlstOutParam = null;
		strActionId = null;
//		strErrorMsg = null;
	}    
   }   
   
   
   
   /**
    * Returns status of the Site object. Retruns true if loaded partially, returns 
    * false if loaded fully.
    * @return boolean
    */
   public boolean getIsLoadedPartially() 
   {
    return flgIsLoadedPartially;
   }
}
