/*
* Title			:       CRCUploadBiz.java							*
* Description	:  		Bean Component for Upload Screen			*
* Copyright		:		Patni
* Date Written	: 		February 2008								*
* Security		:     	Classified/Unclassified						*
*
* Restrictions: GE PROPRIETARY INFORMATION, FOR GE USE ONLY			*
*
*     ****************************************************			*	
*     *  Copyright (2000) with all rights reserved       *			*
*     *          General Electric Company                *			*
*     ****************************************************			*
* @author  Patni
* @version 1.0
* Revision Log  (mm/dd/yy initials description)
*
* ----------------------------------------------------------------------------------------------
*               31/05/2006 Patni Phase 1 Requirement Updations  
*               07/07/2006 Patni Phase 2 Requirement Updations
*               23/08/2006 Patni Modified methods verifySheetHeaders, readSheet, saveSheetData, logErrorToObject
* mm/dd/yy xxx  What you changed ...
*This class reads the excel file and calls the procedure to save the data to the databse
*
*This class is instantiated in the JSP
*/

package ecrd.biz;
// package catalogmaintenance.bean;

// import java.sql.CallableStatement ;
// import java.sql.Connection ;
import ecrd.common.eCRDDBMediator;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDUtil;
import geae.dao.GEAEResultSet;
import geae.office.GEAEOfficeException;
import geae.office.spreadsheet.GEAERow;
import geae.office.spreadsheet.GEAERow2010;								//Changes made for Office 2010.
import geae.office.spreadsheet.GEAESheet;
import geae.office.spreadsheet.GEAESheet2010;							//Changes made for Office 2010.
import geae.office.spreadsheet.excel.GEAEExcelCell;
import geae.office.spreadsheet.excel.GEAEExcelCell2010;					//Changes made for Office 2010.
import geae.office.spreadsheet.excel.GEAEExcelCellStyle;
import geae.office.spreadsheet.excel.GEAEExcelCellStyle2010;			//Changes made for Office 2010.
import geae.office.spreadsheet.excel.GEAEExcelWorkbook;
import geae.office.spreadsheet.excel.GEAEExcelWorkbook2010;				//Changes made for Office 2010.

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.StringTokenizer;
import java.lang.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

// import geae.sql.GEAEConnectionManager;

public class eCRDUploadBiz
{
    // used to set style for all cells
    private GEAEExcelCellStyle style = null;
    
    private GEAEExcelCellStyle2010 style2010 = null;						//Changes made for Office 2010.

    // uesd to store the model for which upload is being done
    private String strEngModelDesc = "";

    // user that has logged
    private String strLoggedUser = "";

    // errors in the sheet
    private ArrayList arrLstError = null;

    // beae connection object
    // private Connection conn=null;

    // stores the site name fromthe file name user uploads
    private String strSite = "";
    
    // stores the EngineModel name from the file name user uploads
    private String strEngineModelDesc = "";

    /*
	 * Constructor
	 */
    public eCRDUploadBiz()
    {

    }
    public GEAEResultSet uploadExcel(String strActionID, String strPath, String strLoggedUser, String strSiteName, String strCatSeqID, String strEngModelCD, String strRoleIndicator) throws Exception
    {
        GEAEResultSet rseCRDBatchUploadErr = null;
        String strEachSheet = "";
        GEAEExcelWorkbook wb = null;
        GEAEExcelWorkbook2010 wb2010 = null;							//Changes made for Office 2010.
        GEAESheet sheet;
        GEAESheet2010 sheet2010;										//Changes made for Office 2010.
        FileInputStream fileInpStrm = null;
        HashMap hmSheetWiseError = null;
        ArrayList arrlstBuffs = null;
        int intNoOfSheetsInExcel = 0;
        // UserTransaction ut = null;
        int intLastSlashInd = 0;
        int intUnderscoreInd = 0;
        String strFileName = "";
        String strUploadPath = "";
        try
        {	System.out.println("Inside the Upload Excel Method");
            hmSheetWiseError = new HashMap();
            arrLstError = new ArrayList();
            this.strLoggedUser = strLoggedUser;
            
            strUploadPath = eCRDUtil.getAFSPath() + eCRDConstants.EXCEL_UPLOAD_PATH + strPath;
            fileInpStrm = new FileInputStream(new File(strUploadPath));
            intLastSlashInd = strPath.lastIndexOf("/");
            strFileName = strPath.substring(intLastSlashInd + 1);
            if ("".equals(strSiteName) || strSiteName == null)
            {
                intUnderscoreInd = strFileName.indexOf("_");
                if (intUnderscoreInd != -1)
                {
                    this.strSite = strFileName.substring(0, intUnderscoreInd);
                }
            }
            else
            {
                this.strSite = strSiteName;
            }

          //Changes made for Office 2010.Start
            
            String extension=strFileName.substring(strFileName.indexOf(".")+1, strFileName.length());
            System.out.println("--Extension  ---"+extension);
            if(extension.toUpperCase().equals("XLSX"))
            {
            	System.out.println("---inside xlsx ---");
            	wb2010    = new GEAEExcelWorkbook2010(fileInpStrm);	
            	System.out.println("--- wb2010  ---"+wb2010);
            	style2010 = wb2010.createCellStyle();
            	if (wb2010 == null)
                {
                    arrLstError.add("Excel File Does not Contain Proper Data");
                    rseCRDBatchUploadErr = setErrors(rseCRDBatchUploadErr, strEachSheet, arrLstError);
                    // hmSheetWiseError.put("-",arrLstError);
                    return rseCRDBatchUploadErr;
                }
            }
            else
            {
            	System.out.println("--- inside xls--- ");
            	wb = new GEAEExcelWorkbook(fileInpStrm);
            	System.out.println("--wb  wb  wb  wb  wb  wb  wb   ---"+wb);
            	style = wb.createCellStyle();
            	if (wb == null)
                {	System.out.println("In if wb==null");
                    arrLstError.add("Excel File Does not Contain Proper Data");
                    rseCRDBatchUploadErr = setErrors(rseCRDBatchUploadErr, strEachSheet, arrLstError);
                    // hmSheetWiseError.put("-",arrLstError);
                    return rseCRDBatchUploadErr;
                }
            }
            System.out.println("-------1-------");
            if(extension.toUpperCase().equals("XLSX"))
			{
				intNoOfSheetsInExcel=wb2010.getNumberOfSheets();	
			}
			else
			{
				intNoOfSheetsInExcel=wb.getNumberOfSheets();
			}
            System.out.println("-------2-------");
            //Changes made for Office 2010.End
            
            /*
			 * loop to fetch each excel sheet in new functionality only one
			 * sheet will be there so no need of this loop
			 */
           
            	//Changes made for Office 2010.Start
                if(extension.toUpperCase().equals("XLSX"))
                {	for (int intSheetCtr = 0; intSheetCtr < intNoOfSheetsInExcel; intSheetCtr++)
                	{
                	sheet2010=wb2010.getSheet(intSheetCtr);
                	strEachSheet = wb2010.getSheetName(intSheetCtr);
                	System.out.println("XLSX Sheet is----- "+sheet2010);
                	arrlstBuffs = new ArrayList();
                    arrlstBuffs = readSheet2010(sheet2010,strSiteName);
                    if (arrlstBuffs != null && arrlstBuffs.size() > 0)
                    {
                       saveSheetData(arrlstBuffs, strActionID, strLoggedUser, strSiteName, strEachSheet, strCatSeqID, strEngModelCD, strRoleIndicator);
                    }
                    if (arrLstError != null && arrLstError.size() > 0)
                    {
                        // hmSheetWiseError.put(strEachSheet,arrLstError);
                        rseCRDBatchUploadErr = setErrors(rseCRDBatchUploadErr, strEachSheet, arrLstError);
                        arrLstError = null;
                        arrLstError = new ArrayList();
                    }
                	}
                }
                else
                {	
                	for (int intSheetCtr = 0; intSheetCtr < intNoOfSheetsInExcel; intSheetCtr++)
                    {	System.out.println("-------3-------");
	                	sheet=wb.getSheet(intSheetCtr);
	                	strEachSheet = wb.getSheetName(intSheetCtr);
	                	System.out.println("XLS Sheet is----- "+sheet);
	                	arrlstBuffs = new ArrayList();
	                    arrlstBuffs = readSheet(sheet,strSiteName);
	                    if (arrlstBuffs != null && arrlstBuffs.size() > 0)
	                    {
	                       saveSheetData(arrlstBuffs, strActionID, strLoggedUser, strSiteName, strEachSheet, strCatSeqID, strEngModelCD, strRoleIndicator);
	                    }
	                    if (arrLstError != null && arrLstError.size() > 0)
	                    {
	                        // hmSheetWiseError.put(strEachSheet,arrLstError);
	                        rseCRDBatchUploadErr = setErrors(rseCRDBatchUploadErr, strEachSheet, arrLstError);
	                        arrLstError = null;
	                        arrLstError = new ArrayList();
	                    }//Changes made for Office 2010.End
                    }
                }
            }
        finally
        {
            fileInpStrm.close();
            wb = null;
            wb2010 = null;									//Changes made for Office 2010.
            arrLstError = null;
        }
        return rseCRDBatchUploadErr;
    }
     /**
		 * Method name: uploadComponentExcel Brief logic: This method will
		 * Upload Excel sheet with Component details.
		 * 
		 * @author Patni Team
		 * @version 1.0
		 * @param
		 * @return
		 * @since JDK1.4
		 */
    public GEAEResultSet uploadComponentExcel(HttpServletRequest request) throws Exception
    {	System.out.println("Inside upload component excel method---");
        GEAEResultSet rseCRDBatchUploadErr = null;
        String strEachSheet = "";
        GEAEExcelWorkbook wb = null;
        GEAEExcelWorkbook2010 wb2010 = null;					//Changes made for Office 2010.
        GEAESheet sheet;
        GEAESheet2010 sheet2010;								//Changes made for Office 2010.
        FileInputStream fileInpStrm = null;
        HashMap hmSheetWiseError = null;
        ArrayList arrlstBuffs = null;
        int intNoOfSheetsInExcel = 0;
        int intLastSlashInd = 0;
        int intUnderscoreInd = 0;
        String strFileName = "";
        String strUploadPath = "";
        String strPath = "";
        String strEngineModelDesc = "";
        String strActionID = "";
        String strEngineModel = "";
        String strLoggedInUser = "";
        eCRDUser objUser = null;
        String strUserRole = null;
        String strRoleIndicator = null;
        try
        {
            hmSheetWiseError = new HashMap();
            arrLstError = new ArrayList();
            strPath              = eCRDUtil.verifyNull(request.getParameter("hdnFile")) ;
            strEngineModelDesc   = eCRDUtil.verifyNull(request.getParameter("hdnEngineModelDesc")) ;
            strActionID          = eCRDUtil.verifyNull(request.getParameter("hdnScreenAction")) ;
            strEngineModel       = eCRDUtil.verifyNull(request.getParameter("hdnEngineModel")) ;
            
            strLoggedInUser      = (String)request.getRemoteUser();
            this.strLoggedUser = strLoggedInUser;
            
            /* Code to fetch User details */
            objUser = (eCRDUser)eCRDUtil.getFromSessionApp(request, "objeCRDUser");
            strUserRole = objUser.getRole();
            if (eCRDConstants.ROLE_TECH_COORD.equalsIgnoreCase(strUserRole))
            {
                strRoleIndicator = "N";
            }
            if (eCRDConstants.ROLE_ADMINISTRATOR.equalsIgnoreCase(strUserRole))
            {
                strRoleIndicator = "Y";
            }
            strUploadPath = eCRDUtil.getAFSPath() + eCRDConstants.EXCEL_UPLOAD_PATH + strPath;
            fileInpStrm = new FileInputStream(new File(strUploadPath));
            intLastSlashInd = strPath.lastIndexOf("/");
            strFileName = strPath.substring(intLastSlashInd + 1);
            
            if ("".equals(strEngineModelDesc) || strEngineModelDesc == null)
            {
                intUnderscoreInd = strFileName.indexOf("_");
                if (intUnderscoreInd != -1)
                {
                    this.strEngineModelDesc = strFileName.substring(0, intUnderscoreInd);
                }
            }
            else
            {
                this.strEngineModelDesc = strEngineModelDesc;
            }
            
          //Changes made for Office 2010.Start
            
            String extension=strFileName.substring(strFileName.indexOf(".")+1, strFileName.length());
            System.out.println("--Extension  ---"+extension);
            
            if(extension.toUpperCase().equals("XLSX"))
            {
            	wb2010 = new GEAEExcelWorkbook2010(fileInpStrm);
                if (wb2010 == null)
                {
                    arrLstError.add("Excel File Does not Contain Proper Data");
                    rseCRDBatchUploadErr = setErrors(rseCRDBatchUploadErr, strEachSheet, arrLstError);
                    return rseCRDBatchUploadErr;
                }
                style2010 = wb2010.createCellStyle();
                intNoOfSheetsInExcel = wb2010.getNumberOfSheets();
                for (int intSheetCtr = 0; intSheetCtr < intNoOfSheetsInExcel; intSheetCtr++)
                {
                    sheet2010 = wb2010.getSheet(intSheetCtr);
                    strEachSheet = wb2010.getSheetName(intSheetCtr);
                    arrlstBuffs = new ArrayList();

                    // calling readComponentSheet() to read the ExcelSheet
                    arrlstBuffs = readComponentSheet2010(sheet2010,strEngineModelDesc);
                    if (arrLstError != null && arrLstError.size() > 0)
                    {
                          rseCRDBatchUploadErr = setErrors(rseCRDBatchUploadErr, strEachSheet, arrLstError);
                          arrLstError = null;
                          arrLstError = new ArrayList();
                    }
                    
                    // if ((arrlstBuffs != null && arrlstBuffs.size() > 0) &&
    				// (arrLstError == null && arrLstError.size()==0) )
                    if ((arrlstBuffs != null && arrlstBuffs.size() > 0) && ( arrLstError.size() < 1 ) )
                    // if ( (arrlstBuffs != null && arrlstBuffs.size() > 0) )
                    {
                        saveComponentSheetData(arrlstBuffs, strActionID, strLoggedUser,strRoleIndicator, strEngineModel, strEachSheet);
                    }
                    if (arrLstError != null && arrLstError.size() > 0)
                    {
                        rseCRDBatchUploadErr = setErrors(rseCRDBatchUploadErr, strEachSheet, arrLstError);

                        arrLstError = null;
                        arrLstError = new ArrayList();
                    }
                }
            }
            
            else
            {
            	wb = new GEAEExcelWorkbook(fileInpStrm);
                if (wb == null)
                {
                    arrLstError.add("Excel File Does not Contain Proper Data");
                    rseCRDBatchUploadErr = setErrors(rseCRDBatchUploadErr, strEachSheet, arrLstError);
                    return rseCRDBatchUploadErr;
                }
                style = wb.createCellStyle();
                intNoOfSheetsInExcel = wb.getNumberOfSheets();
                for (int intSheetCtr = 0; intSheetCtr < intNoOfSheetsInExcel; intSheetCtr++)
                {
                    sheet = wb.getSheet(intSheetCtr);
                    strEachSheet = wb.getSheetName(intSheetCtr);
                    arrlstBuffs = new ArrayList();

                    // calling readComponentSheet() to read the ExcelSheet
                    arrlstBuffs = readComponentSheet(sheet,strEngineModelDesc);
                    if (arrLstError != null && arrLstError.size() > 0)
                    {
                          rseCRDBatchUploadErr = setErrors(rseCRDBatchUploadErr, strEachSheet, arrLstError);
                          arrLstError = null;
                          arrLstError = new ArrayList();
                    }
                    
                    // if ((arrlstBuffs != null && arrlstBuffs.size() > 0) &&
    				// (arrLstError == null && arrLstError.size()==0) )
                    if ((arrlstBuffs != null && arrlstBuffs.size() > 0) && ( arrLstError.size() < 1 ) )
                    // if ( (arrlstBuffs != null && arrlstBuffs.size() > 0) )
                    {
                        saveComponentSheetData(arrlstBuffs, strActionID, strLoggedUser,strRoleIndicator, strEngineModel, strEachSheet);
                    }
                    if (arrLstError != null && arrLstError.size() > 0)
                    {
                        rseCRDBatchUploadErr = setErrors(rseCRDBatchUploadErr, strEachSheet, arrLstError);

                        arrLstError = null;
                        arrLstError = new ArrayList();
                    }
                }  //Changes made for Office 2010.End

            }
                    }
        finally
        {
            fileInpStrm.close();
            wb = null;
            wb2010 = null;									//Changes made for Office 2010.
            arrLstError = null;
        }
        return rseCRDBatchUploadErr;
    }
/* END uploadComponentExcel() */
    
    /**
	 * Method name: uploadMappingExcel 
	 * Brief logic: This method will Upload Excel sheet with Component Mapping details. 
	 * 				Used for upload functionality of eCRDBatchDownloadUploadMapping.
	 * @author	: Patni Team
	 * @version : 1.0
	 * @param 	: HttpServletRequest request
	 * @return  : GEAEResultSet
	 * @since JDK1.4
	 */
    public GEAEResultSet uploadMappingExcel(HttpServletRequest request) throws Exception
    {	System.out.println("Inside upload mapping excel method---");
        GEAEResultSet rseCRDBatchUploadErr = null;
        String strEachSheet = "";
        GEAEExcelWorkbook wb = null;
        GEAEExcelWorkbook2010 wb2010 = null;						//Changes made for Office 2010.
        GEAESheet sheet = null;
        GEAESheet2010 sheet2010 = null;								//Changes made for Office 2010.
        FileInputStream fileInpStrm = null;
        HashMap hmSheetWiseError = null;
        ArrayList arrlstBuffs = null;
        
        int intNoOfSheetsInExcel = 0;
        int intLastSlashInd = 0;
        int intUnderscoreInd = 0;
        
        String strFileName = "";
        String strUploadPath = "";
        String strPath = "";
        String strEngineModelDesc = "";
        String strActionID = "";
        String strEngineModel = "";
        String strSite = "";
        String strLoggedInUser = "";
        
        eCRDUser objUser = null;
        String strUserRole = null;
        try
        {
            hmSheetWiseError = new HashMap();
            arrLstError = new ArrayList();
            
            strPath              = eCRDUtil.verifyNull(request.getParameter("hdnFile")) ;
            strSite			     = eCRDUtil.verifyNull(request.getParameter("hdnSite")) ;
            strActionID          = eCRDUtil.verifyNull(request.getParameter("hdnScreenAction")) ;
            strEngineModelDesc   = eCRDUtil.verifyNull(request.getParameter("hdnEngineModelDesc")) ;
            strEngineModel       = eCRDUtil.verifyNull(request.getParameter("hdnEngineModel")) ;
            
            strLoggedInUser  = (String)request.getRemoteUser();
            this.strLoggedUser = strLoggedInUser;
            
            /* Code to fetch User details */
            objUser = (eCRDUser)eCRDUtil.getFromSessionApp(request, "objeCRDUser");
            strUserRole = objUser.getRole();
            
            strUploadPath = eCRDUtil.getAFSPath() + eCRDConstants.EXCEL_UPLOAD_PATH + strPath;
            fileInpStrm = new FileInputStream(new File(strUploadPath));
            intLastSlashInd = strPath.lastIndexOf("/");
            strFileName = strPath.substring(intLastSlashInd + 1);
            
            if ("".equals(strEngineModelDesc) || strEngineModelDesc == null)
            {
                intUnderscoreInd = strFileName.indexOf("_");
                if (intUnderscoreInd != -1)
                {
                    this.strEngineModelDesc = strFileName.substring(0, intUnderscoreInd);
                }
            }
            else
            {
                this.strEngineModelDesc = strEngineModelDesc;
            }
            
            //Changes made for Office 2010.Start
            
            String extension=strFileName.substring(strFileName.indexOf(".")+1, strFileName.length());
            System.out.println("--Extension  ---"+extension);
            
            if(extension.toUpperCase().equals("XLSX"))
            {
            	wb2010 = new GEAEExcelWorkbook2010(fileInpStrm);
                
                if(wb2010 == null || "".equals(wb2010))
                {
                    arrLstError.add("Excel File Does not Contain Proper Data");
                    rseCRDBatchUploadErr = setErrors(rseCRDBatchUploadErr, strEachSheet, arrLstError);
                    return rseCRDBatchUploadErr;    
                }
                
                /* If row is more than 5000 then return an alert message.*/
                //if(wb.getSheet(0).getLastRowNum()> 5000)
                if(wb2010.getSheet(0).getLastRowNum()> 3000)
                {
             	  arrLstError.add("EXCEEDED THE MAXIMUM NUMBER OF ROW LIMIT");
                  rseCRDBatchUploadErr = setErrors(rseCRDBatchUploadErr, strEachSheet, arrLstError);
                  return rseCRDBatchUploadErr;  
                }
                
                style2010 = wb2010.createCellStyle();
                intNoOfSheetsInExcel = wb2010.getNumberOfSheets();
                for (int intSheetCtr = 0; intSheetCtr < intNoOfSheetsInExcel; intSheetCtr++)
                {
                    sheet2010 = wb2010.getSheet(intSheetCtr);
                    strEachSheet = wb2010.getSheetName(intSheetCtr);
                    arrlstBuffs = new ArrayList();
                   
                    // calling readMappingSheet2010() to read the ExcelSheet
                    try{
                    	arrlstBuffs = readMappingSheet2010(sheet2010,strSite);
                    }
                    catch(Exception ex){
                    	System.out.println("Exception--->"+ex.getMessage());
                    }
                    
                    if (arrLstError != null && arrLstError.size() > 0)
                    {
                    	  rseCRDBatchUploadErr = setErrors(rseCRDBatchUploadErr, strEachSheet, arrLstError);
                          arrLstError = null;
                          arrLstError = new ArrayList();
                    }
                    if ((arrlstBuffs != null && arrlstBuffs.size() > 0) && ( arrLstError.size() < 1 ) )
                    {
                    	saveMappingSheetData(arrlstBuffs, strActionID, strSite,strLoggedUser,strUserRole,strEngineModelDesc, strEachSheet);
                    }
                    if (arrLstError != null && arrLstError.size() > 0)
                    {
                    	rseCRDBatchUploadErr = setErrors(rseCRDBatchUploadErr, strEachSheet, arrLstError);
                        arrLstError = null;
                        arrLstError = new ArrayList();
                    }
                 }
            }
            
            else
            {
            	wb = new GEAEExcelWorkbook(fileInpStrm);
                
                if(wb == null || "".equals(wb))
                {
                    arrLstError.add("Excel File Does not Contain Proper Data");
                    rseCRDBatchUploadErr = setErrors(rseCRDBatchUploadErr, strEachSheet, arrLstError);
                    return rseCRDBatchUploadErr;    
                }
                
                /* If row is more than 5000 then return an alert message.*/
                //if(wb.getSheet(0).getLastRowNum()> 5000)
                if(wb.getSheet(0).getLastRowNum()> 3000)
                {
             	  arrLstError.add("EXCEEDED THE MAXIMUM NUMBER OF ROW LIMIT");
                  rseCRDBatchUploadErr = setErrors(rseCRDBatchUploadErr, strEachSheet, arrLstError);
                  return rseCRDBatchUploadErr;  
                }
                
                style = wb.createCellStyle();
                intNoOfSheetsInExcel = wb.getNumberOfSheets();
                for (int intSheetCtr = 0; intSheetCtr < intNoOfSheetsInExcel; intSheetCtr++)
                {
                    sheet = wb.getSheet(intSheetCtr);
                    strEachSheet = wb.getSheetName(intSheetCtr);
                    arrlstBuffs = new ArrayList();
                   
                    // calling readMappingSheet() to read the ExcelSheet
                    try{
                    	arrlstBuffs = readMappingSheet(sheet,strSite);
                    }
                    catch(Exception ex){
                    	System.out.println("Exception--->"+ex.getMessage());
                    }
                    
                    if (arrLstError != null && arrLstError.size() > 0)
                    {
                    	  rseCRDBatchUploadErr = setErrors(rseCRDBatchUploadErr, strEachSheet, arrLstError);
                          arrLstError = null;
                          arrLstError = new ArrayList();
                    }
                    if ((arrlstBuffs != null && arrlstBuffs.size() > 0) && ( arrLstError.size() < 1 ) )
                    {
                    	saveMappingSheetData(arrlstBuffs, strActionID, strSite,strLoggedUser,strUserRole,strEngineModelDesc, strEachSheet);
                    }
                    if (arrLstError != null && arrLstError.size() > 0)
                    {
                    	rseCRDBatchUploadErr = setErrors(rseCRDBatchUploadErr, strEachSheet, arrLstError);
                        arrLstError = null;
                        arrLstError = new ArrayList();
                    }
                   
                }		//Changes made for Office 2010.End
            }
            
        }
        finally
        {
            fileInpStrm.close();
            wb = null;
            wb2010 = null;								//Changes made for Office 2010.
            arrLstError = null;
        }
        return rseCRDBatchUploadErr;
    }
 /* END uploadMappingExcel() */   


    private ArrayList readSheet(GEAESheet sheet,String strSiteName) throws Exception
    {	System.out.println("Inside read sheet method");
        int intNoOfRows = 0;
        int intNoOfCols = 0;
        GEAERow row = null;
        GEAEExcelCell cell = null;
        ArrayList arrlstBuffs = null;
        StringBuffer strBuffEachRow = null;
        StringBuffer strBuffEachElement = null;
        StringBuffer strBuffTestBlankRow = null;
        StringBuffer strBuffBlanks = null;
        StringBuffer strBuffEmpty = null;
        StringTokenizer strtkn = null;
        String[] strArrEachRow = null;
        String strEachCellValue = "";

        boolean blnValidRow = true;

        /* Start : Added by milind */
        String strModuleName = ""; // module name
        String strCompDesc = ""; // component description
        String strCompCode = ""; // component code
        String strATAChpt = ""; // ATA chapter
       // 08-05-2006 Patni Added Repair Sequence Id filed Begin
       String strRepairSeqId = ""; // Repair Sequence Id
      // 08-05-2006 Patni Added Repair Sequence Id filed End
        String strRepairRef = ""; // repair reference

        String strRPRDesc = ""; // Rpr Description
      // 08-05-2006 Patni Added Repair Effective Date filed Begin
    // String strRepairEffectiveDate = ""; // Repair Effective Date
      // 08-05-2006 Patni Added Repair Effective Date filed End
       
       
        String strPriceType = ""; // Price Type
        String strRprTat = ""; // Rpr TAT
       // 08-05-2006 Patni Added Incremental TAT Indicator filed Begin
       String strIncrTATind = ""; // Incremental TAT Indicator
      // 08-05-2006 Patni Added Incremental TAT Indicator filed End
     
        String strRprPrice = ""; // Rpr Price
// 08-05-2006 Patni Added Incremental Price Indicator filed Begin
       String strIncrPriceind = ""; // Incremental TAT Indicator
      // 08-05-2006 Patni Added Incremental Price Indicator filed End
     
        String strFutTat = ""; // Future TAT
        String strFutPrice = ""; // Future Price
        String strEffDate = ""; // Future Price/TAT Effective date
        String strLaborHr = ""; // Labor Hours
        String strMatCost = ""; // Material Cost
       // 26-06-2006 Patni added for Retain Value Indicator Begin
       String strRetainValueind = ""; 
       // 26-06-2006 Patni added for Retain Value Indicator End

        HashMap hmPriceTypes = null ;// for validations of price types
        
        StringTokenizer strtknModelDesc = null;
        boolean isInvalidATA = false;

        boolean isValidTAT = true;
        boolean isValidRprPrice = true;
        boolean isValidFutTAT = true;
        boolean isValidFutPrice = true;
        boolean isValidLaborHr = true;
        boolean isValidMatCost = true;

        /* End : Added by milind */
        // float fltMaxValue=0;
        int intDecimalInd = 0;
        int intIndexOfYear = 0;
        
        int intCellDataType;					//Changes made for Office 2010.
        
        /*//Changes made for Office 2010.Start
          try 
  		{        	
          	intCellDataType = cell.getCellType();
          } 
  		catch (Exception e) 
  		{
  			return null;
  		}
  		//Changes made for Office 2010.End
*/           
        try
        {
            hmPriceTypes = eCRDConstants.getPriceTypes();
            
            intNoOfRows = sheet.getLastRowNum();
            // milind : check for Empty Sheet
        
            if (!verifySheetHeaders(sheet.getRow((short) 0),strSiteName))
            {
                // Add error

                /* Patni 12-Sep-2006 - Changed the validation message - Begin */
                // arrLstError.add("Excel Sheet has Invalid headers Or Excel has
				// Labor Hours and Material Cost Data");
                arrLstError.add("Excel Sheet has Invalid headers");
                /* Patni 12-Sep-2006 - Changed the validation message - End */
                return new ArrayList();
            }
            
           arrlstBuffs = new ArrayList();
           strBuffEachElement = new StringBuffer();
           
           // Loop to fetch records from Each excel row // milind
            for (int intRowCtr = 1; intRowCtr <= intNoOfRows; intRowCtr++)
            {
                strBuffEachRow = new StringBuffer();
                row = sheet.getRow((short) intRowCtr);
                try
                {
                    intNoOfCols = (int) row.getLastCellNum();
                }
                catch (NullPointerException nullptrExp)
                {
                    intNoOfCols = 0;
                }
                if (intNoOfCols < 0)
                {
                    strArrEachRow = new String[1];
                }
                else
                {
                    strArrEachRow = new String[intNoOfCols];
                }
                strBuffTestBlankRow = new StringBuffer();
                strBuffBlanks = new StringBuffer();
                strBuffEmpty = new StringBuffer();
               
	                // loop to fetch cell values from each column
	                for (int intColCtr = 0; intColCtr < intNoOfCols; intColCtr++)
	                {
	                    try
	                    {
	                        strEachCellValue = "";
	                        cell = (GEAEExcelCell) row.getCell((short) intColCtr);
	                        	
	                        intCellDataType = cell.getCellType();					//Changes made for Office 2010.
	                        
	                        /* Start : to fetch Future Effective date from Excel */
	                       /*
							 * 09-05-2006 Patni Removed 10 and added 13 for Future
							 * effective date Begin
							 */
	                       
	                       /*
							 * Patni 23-Aug-2006 - Column 14 corresponds to Future
							 * Effective Date - Begin
							 */
	                       // if (intColCtr == 13)
	                       if (intColCtr == 14)
	                       /*
							 * Patni 23-Aug-2006 - Column 14 corresponds to Future
							 * Effective Date - End
							 */
	                           
	                   /*
						 * 09-05-2006 Patni Removed 10 and added 13 for Future
						 * effective date End
						 */ 
	                       {
	                            try
	                            {
	                            	//Changes made for Office 2010.Start
	                            	if (intCellDataType == 0)
                            		{	
                            			Date tempDate = cell.getDateCellValue();
                            			strEachCellValue = eCRDUtil.isValidDate(tempDate, "MM/dd/yyyy");
                            			System.out.println("Cell value is "+strEachCellValue);
                            		}	
                            		else
                            		{
                            			strEachCellValue = "";			
                            		}
	                            	//Changes made for Office 2010.End
	                            }
	                            catch (NumberFormatException e)
	                            {
	                                strEachCellValue = eCRDUtil.verifyNull(cell.getStringCellValue().trim());
	                                String tempStrEachCellValue = "";
	                                if (!"".equals(strEachCellValue))
	                                {
	                                    String temp = strEachCellValue.substring(6);
	                                    /*
										 * if year entered is "05" then change it to
										 * "2005"
										 */
	                                    if (temp.length() != 4)
	                                    {
	                                        strEachCellValue = "";
	                                    }
	                                    else
	                                    {
	                                        tempStrEachCellValue = eCRDUtil.isValidDate(strEachCellValue, "MM/dd/yyyy");
	
	                                        if (strEachCellValue.equals(tempStrEachCellValue))
	                                        {
	                                            strEachCellValue = tempStrEachCellValue;
	                                        }
	                                        else
	                                        {
	                                            strEachCellValue = "";
	                                        }
	                                    }
	                                }
	                                else
	                                {
	                                    strEachCellValue = "";
	                                }
	                            }
	                            catch (NullPointerException objNullPtrExp)
	                            {
	                                strEachCellValue = "";
	                            }
	                            
	                        }
	                        /* End : to fetch Future Effective date from Excel */
	                        // else fetch normal String value from excel
	                        else if(intCellDataType == 1)				//Changes for Office 2010.
	                        {
	                            strEachCellValue = cell.getStringCellValue();
	                            System.out.println("In Else If for 1(Alphanueric)"+strEachCellValue);
	                        }
	                       
	                        else if(intCellDataType ==0)				//Changes for Office 2010.
	                        {
	                        	strEachCellValue = cell.getNumericCellValue() + "";
	                        	System.out.println("In Else If for 0(Numeric)"+strEachCellValue);
	                        }
	                    }
	                    /*catch (NumberFormatException numformExp)
	                    {
	                        strEachCellValue = cell.getNumericCellValue() + "";
	                    }*/
	                    // Milind : code need to be added for Date type column
	                    catch (NullPointerException nullptrExp)
	                    {
	                        strEachCellValue = "";
	                    }
	                    finally
	                    {
	                        // store each cell value in String array
	                        strArrEachRow[intColCtr] = strEachCellValue;
	                        strBuffTestBlankRow.append(strEachCellValue + "^");
	                        strBuffBlanks.append(" ^");
	                        strBuffEmpty.append("^");
	                    }
	                } // End of loop for Columns
	                
               System.out.println("End of loop for columns");
	                
                if (strBuffBlanks.toString().equals(strBuffTestBlankRow.toString()) || strBuffEmpty.toString().equals(strBuffTestBlankRow.toString()))
                {
                    
                    if (intRowCtr == intNoOfRows)
                    {
                        arrlstBuffs.add(strBuffEachElement);
                        strBuffEachElement = null;
                        strBuffEachElement = new StringBuffer();
                    }
                }
                else
                {
                    /* Start : milind on 5 November */
                    // these are validations for each column
                    
                    /*
					 * Patni 23-Aug-2006 - Checking Maxlength for the Module
					 * Name - Begin
					 */
                    strModuleName  = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 0), 20, "Module Name", "" + (intRowCtr + 1));
                    /*
					 * Patni 23-Aug-2006 - Checking Maxlength for the Module
					 * Name - End
					 */
                    
                    /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * Begin
					 */
                    // strCompDesc =
					// isGreaterThanMaxLength(returnArrValue(strArrEachRow, 0),
					// 200, "Component Description", "" + (intRowCtr + 1));
                    strCompDesc  = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 1), 200, "Component Description", "" + (intRowCtr + 1));
                    /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * End
					 */
                   
                    /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * Begin
					 */ 
                    // strCompCode =
					// isGreaterThanMaxLength(returnArrValue(strArrEachRow, 1),
					// 20, "Component Code", "" + (intRowCtr + 1));
                    strCompCode  = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 2), 20, "Component Code", "" + (intRowCtr + 1));
                    /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * End
					 */
                    
                    /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * Begin
					 */
                    // strATAChpt =
					// isGreaterThanMaxLength(returnArrValue(strArrEachRow, 2),
					// 20, "ATA Chapter", "" + (intRowCtr + 1));
                    strATAChpt   = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 3), 20, "ATA Chapter", "" + (intRowCtr + 1));
                    /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * End
					 */
                    
                   // 08-05-2006 Patni Addded repair seq id validation Begin
                    
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * Begin
					 */
                   // strRepairSeqId
					// =isGreaterThanMaxLength(returnArrValue(strArrEachRow, 3),
					// 20, "Repair Seq Id", "" + (intRowCtr + 1));
                   strRepairSeqId =isGreaterThanMaxLength(returnArrValue(strArrEachRow, 4), 20, "Repair Seq Id", "" + (intRowCtr + 1));
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * End
					 */                   
                   
                   // 08-05-2006 Patni Addded repair seq id validation End
                   
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * Begin
					 */
                   // strRepairRef =
					// isGreaterThanMaxLength(returnArrValue(strArrEachRow, 4),
					// 100, "Repair Reference", "" + (intRowCtr + 1));
                   strRepairRef = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 5), 100, "Repair Reference", "" + (intRowCtr + 1));
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * End
					 */
                   
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * Begin
					 */
                   // strRPRDesc =
					// isGreaterThanMaxLength(returnArrValue(strArrEachRow, 5),
					// 255, "Rpr Description", "" + (intRowCtr + 1));
                   strRPRDesc   = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 6), 255, "Rpr Description", "" + (intRowCtr + 1));
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * End
					 */
                   
                   // 08-05-2006 Patni Addded Repair Effective date Begin
              // strRepairEffectiveDate= returnArrValue(strArrEachRow, 6);
                   // 08-05-2006 Patni Addded Repair Effective date End
               
                    /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * Begin
					 */
                    // strPriceType =
					// isGreaterThanMaxLength(returnArrValue(strArrEachRow, 6),
					// 10, "Price Type", "" + (intRowCtr + 1));
                    strPriceType = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 7), 10, "Price Type", "" + (intRowCtr + 1));
                    /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * End
					 */
                    
                    if(!(hmPriceTypes.containsValue(strPriceType)|| hmPriceTypes.containsKey(strPriceType)))
                    {
                        arrLstError.add("Please Enter a valid Price Type at Row " + (intRowCtr + 1) + " ");
                        blnValidRow = false;
                    }
                    
                    /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * Begin
					 */
                    // strRprTat =
					// isGreaterThanMaxLength(returnArrValue(strArrEachRow, 7),
					// 11, "Rpr TAT", "" + (intRowCtr + 1));
                    strRprTat = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 8), 11, "Rpr TAT", "" + (intRowCtr + 1));
                    /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * End
					 */
                    
                   // 08-05-2006 Patni Addded Incremental TAT Indicator Begin
                   
                    /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * Begin
					 */
                   // strIncrTATind =
					// isGreaterThanMaxLength(returnArrValue(strArrEachRow,8),
					// 1, "Incremental TAT Indicator", "" + (intRowCtr + 1));
                   strIncrTATind = isGreaterThanMaxLength(returnArrValue(strArrEachRow,9), 1, "Incremental TAT Indicator", "" + (intRowCtr + 1));
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * End
					 */

                   // 08-05-2006 Patni Addded Incremental TAT Indicator ENd
                   
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * Begin
					 */
                   // strRprPrice =
					// isGreaterThanMaxLength(returnArrValue(strArrEachRow,9),
					// 15, "Rpr Price", "" + (intRowCtr + 1));
                   strRprPrice = isGreaterThanMaxLength(returnArrValue(strArrEachRow,10), 15, "Rpr Price", "" + (intRowCtr + 1));
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * End
					 */
                   
                   // 08-05-2006 Patni Addded Incremental Price Indicator Begin
                   
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * Begin
					 */
                   // strIncrPriceind =
					// isGreaterThanMaxLength(returnArrValue(strArrEachRow, 10),
					// 1, "Incremental Price Indicator", "" + (intRowCtr + 1));
                   strIncrPriceind = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 11), 1, "Incremental Price Indicator", "" + (intRowCtr + 1));
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * End
					 */
                   
                   // 08-05-2006 Patni Addded Incremental Price Indicator End
                  
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * Begin
					 */
                   // strFutTat =
					// isGreaterThanMaxLength(returnArrValue(strArrEachRow, 11),
					// 7, "Future TAT", "" + (intRowCtr + 1));
                   strFutTat = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 12), 7, "Future TAT", "" + (intRowCtr + 1));
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * End
					 */
                   
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * Begin
					 */
                   // strFutPrice =
					// isGreaterThanMaxLength(returnArrValue(strArrEachRow, 12),
					// 15, "Future Price", "" + (intRowCtr + 1));
                   strFutPrice = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 13), 15, "Future Price", "" + (intRowCtr + 1));
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * End
					 */
                   
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * Begin
					 */
                   // strEffDate = returnArrValue(strArrEachRow, 13);
                   strEffDate = returnArrValue(strArrEachRow, 14);
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * End
					 */
                   
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * Begin
					 */
                   // strLaborHr =
					// isGreaterThanMaxLength(returnArrValue(strArrEachRow, 14),
					// 15, "Labor Hours", "" + (intRowCtr + 1));
                   strLaborHr = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 15), 15, "Labor Hours", "" + (intRowCtr + 1));
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * End
					 */
                   
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * Begin
					 */
                   // strMatCost =
					// isGreaterThanMaxLength(returnArrValue(strArrEachRow, 15),
					// 15, "Material Cost", "" + (intRowCtr + 1));
                   strMatCost = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 16), 15, "Material Cost", "" + (intRowCtr + 1));
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * End
					 */
                   
                    // 26-06-2006 Added retain value indicator Begin
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * Begin
					 */
                   // strRetainValueind =
					// isGreaterThanMaxLength(returnArrValue(strArrEachRow,16),
					// 1, "Retain Value Indicator", "" + (intRowCtr + 1));
                   strRetainValueind = isGreaterThanMaxLength(returnArrValue(strArrEachRow,17), 1, "Retain Value Indicator", "" + (intRowCtr + 1));
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * End
					 */
                   // 26-06-2006 Added retain value indicator End
                   
                    blnValidRow = true;
                    /*
					 * Start : Future Effective Date Validations :
					 * 
					 * Assumptions 1] If future TAT is present, then Effective
					 * date should be present 2] If future price is present,
					 * then Effective date should be present 3] If effective
					 * date is present, then either future Tat or future price
					 * should be present 4] Future TAT, Future Price and
					 * Effective date can by blank(null)
					 */
                    if (!strEffDate.trim().equals("") )
                    {
                        Date tempDate = new Date();

                        if (tempDate.after(new Date(strEffDate.trim())))
                        {
                            arrLstError.add("Future Effective Date should be greater than today at Row " + (intRowCtr + 1) + " ");
                            blnValidRow = false;
                        }

                        if (!strFutTat.trim().equals(""))
                        {
                            if(strFutTat.startsWith("+"))
                            {
                                isValidFutTAT =false;
                                arrLstError.add("Incremental TAT cannot be entered for Future TAT at Row " + (intRowCtr + 1) + " ");
                            }
                            isValidFutTAT = isValidNumberZeroValid(strFutTat, "9999999", "Future TAT", "" + (intRowCtr + 1), false, "");
                            if (!isValidFutTAT)
                            {
                                blnValidRow = false;
                            }
                        }

                        if (!strFutPrice.trim().equals(""))
                        {
                            if(strFutPrice.startsWith("+"))
                            {
                                isValidFutPrice =false;
                                arrLstError.add("Incremental Price cannot be entered for Future Price at Row " + (intRowCtr + 1) + " ");
                            }
                            isValidFutPrice = isValidNumberZeroValid(strFutPrice, "99999999999.99", "Future Price", "" + (intRowCtr + 1), true, "QUOTE");
                            if (!isValidFutPrice)
                            {
                                blnValidRow = false;
                            }
                        }

                    }
                    /*
					 * if (!strEffDate.trim().equals("")) { if
					 * (strFutTat.trim().equals("") &&
					 * strFutPrice.trim().equals("")) { arrLstError.add("Invalid
					 * Future TAT, Future Price and Future effective date at Row " +
					 * (intRowCtr + 1)); blnValidRow = false; } }
					 */
                    if(!strFutTat.trim().equals("") || !strFutPrice.trim().equals(""))
                    {
                        if(strEffDate.trim().equals(""))
                        {
                            arrLstError.add("Please Enter Future effective date at Row " + (intRowCtr + 1));
                            blnValidRow = false;
                        }
                    }
                    /* End : Date Validations : */

                    // Validation Starts
                    /* Patni 23-Aug-2006 - Validation for Module Name - Begin */
                    if ("".equals(strModuleName.trim()))
                    {
                        arrLstError.add("Module Name not found at Row " + (intRowCtr + 1));
                        blnValidRow = false;
                    }
                    /* Patni 23-Aug-2006 - Validation for Module Name - End */
                    
                    if ("".equals(strCompCode.trim()))
                    {
                        arrLstError.add("Component Code not found at Row " + (intRowCtr + 1));
                        blnValidRow = false;
                    }

                    if ("".equals(strCompDesc.trim()))
                    {
                        arrLstError.add("Component Description not found for " + strCompCode + " at Row " + (intRowCtr + 1));
                        blnValidRow = false;
                    }

                    if ("".equals(strATAChpt.trim()))
                    {
                        arrLstError.add("ATA not found at Row " + (intRowCtr + 1));
                        blnValidRow = false;

                    }
                    else
                    {
                        if (strATAChpt.length() > 20)
                        {
                            arrLstError.add("ATA : " + strATAChpt + " Exceeds Max Allowed length 20 ");
                            blnValidRow = false;
                        }
                        else
                        {
                            isInvalidATA = validateATA(strATAChpt);
                            if (isInvalidATA)
                            {
                                arrLstError.add("ATA : " + strATAChpt + " not in corect format at Row " + (intRowCtr + 1) + " Expected Format NN-NN-NN or GEK * or TO * ");
                                blnValidRow = false;
                            }
                        }
                    }
                    /*
					 * if ("".equals(strRepairRef.trim())) {
					 * arrLstError.add("Repair Reference not found at Row " +
					 * (intRowCtr + 1)); blnValidRow = false; }
					 */
                    if ("".equals(strRPRDesc.trim()))
                    {
                        arrLstError.add("Repair Description not found at Row " + (intRowCtr + 1));
                        blnValidRow = false;
                    }
                    if ("".equals(strPriceType.trim()))
                    {
                        arrLstError.add("Price Type not found at Row " + (intRowCtr + 1));
                        blnValidRow = false;
                    }
                    if("QUOTE".equals(strPriceType.trim()))
                    {
                        if(!strFutPrice.trim().equals(""))
                        {
                            arrLstError.add("Future Repair Price Cannot be entered for Price type QUOTE at Row " + (intRowCtr + 1));
                            blnValidRow = false;    
                        }
                        if(!("".equals(strRprPrice)||" ".equals(strRprPrice) ))
                        {
                            arrLstError.add("Repair Price Cannot be entered for repair type QUOTE at Row No." + (intRowCtr + 1));
                            isValidRprPrice = false;
                        }
                    }
                    else
                    {
                       
                        if(!"+".equals(strRprPrice))
                        {
                          
                            isValidRprPrice = isValidNumberZeroValid(strRprPrice, "99999999999.99", "Repair Price", "" + (intRowCtr + 1), false, "");
                        }
                        
                        if("".equals(strRprPrice)||" ".equals(strRprPrice) )
                        {
                            /*
							 * arrLstError.add("Repair Price not found for
							 * repair at Row No." + (intRowCtr + 1));
							 * isValidRprPrice = false;
							 */
                            strRprPrice = "";
                        }
                    }
                    if(!"+".equals(strRprTat))
                    {
                        
                       isValidTAT = isValidNumberZeroValid(strRprTat, "99999999999", "Repair TAT", "" + (intRowCtr + 1), false, "");
                    }
                    if("".equals(strRprTat)||" ".equals(strRprTat) )
                    {
                        /*
						 * arrLstError.add("Repair TAT not found for repair at
						 * Row No." + (intRowCtr + 1)); isValidTAT = false;
						 */
                        strRprTat = "";
                    }

                    isValidLaborHr = isValidNumberZeroValid(strLaborHr, "99999999999.99", "Labor Hour", "" + (intRowCtr + 1), false, "");
                    isValidMatCost = isValidNumberZeroValid(strMatCost, "99999999999.99", "Material Cost", "" + (intRowCtr + 1), false, "");

                    if (!isValidTAT || !isValidRprPrice || !isValidLaborHr || !isValidMatCost)
                    {
                        blnValidRow = false;
                    }
                  // 10-05-2006 Patni Checking Incremental TAT Indicator/
					// Price Indicator Begin
                  
                  
                   if ("".equals(strIncrTATind))
                   {
                       arrLstError.add("Incremental TAT Indicator not found at Row " + (intRowCtr + 1));
                       blnValidRow = false;
                   }
               
                   if(!"Y".equals(strIncrTATind) && !"N".equals(strIncrTATind) )
                   {
                       arrLstError.add("Incremental TAT Indicator should match with Y/N " + (intRowCtr + 1));
                       blnValidRow = false;
                    }
                  // Incremental Price Indicator
                   if ("".equals(strIncrPriceind))
                   {
                       arrLstError.add("Incremental Price Indicator not found at Row " + (intRowCtr + 1));
                       blnValidRow = false;
                   }

                   if(!"Y".equals(strIncrPriceind) && !"N".equals(strIncrPriceind) )
                   {
                       arrLstError.add("Incremental Price Indicator should match with Y/N " + (intRowCtr + 1));
                       blnValidRow = false;
                    }
                   // 10-05-2006 Patni Checking Incremental TAT Indicator/
					// Price Indicator End
                   // 26-06-2006 Patni Added Retain Value Indicator Validations
					// begin
                   if("".equals(strRetainValueind) && !strSiteName.equals("ALL"))
                   {
                     arrLstError.add("Retain Value Indicator not found at Row " + (intRowCtr + 1));
                     blnValidRow = false;
                   }
                   if(!"N".equals(strRetainValueind) && !"Y".equals(strRetainValueind)&& !strSiteName.equals("ALL") )
                   {
                     arrLstError.add("Retain Value Indicator should match with (Y/N) at Row " + (intRowCtr + 1));
                     blnValidRow = false;
                   }
                   // 26-06-2006 Patni Added Retain Value Indicator Validations
					// end
                    // After Validating all fields..append it to String buffer
                    strBuffEachRow.append((intRowCtr + 1) + "^");
                    
                    /*
					 * Patni 23-Aug-2006 - Included Module Name to the Buffer
					 * String - Begin
					 */
                    strBuffEachRow.append(strModuleName + "^");
                    /*
					 * Patni 23-Aug-2006 - Included Module Name to the Buffer
					 * String - End
					 */
                    
                    strBuffEachRow.append(strCompDesc + "^");
                    strBuffEachRow.append(strCompCode + "^");
                    strBuffEachRow.append(strATAChpt + "^");
                   // 08-05-2006 Added repair seq id into string Buffer Begin
                   strBuffEachRow.append(strRepairSeqId+ "^");
                   // 08-05-2006 Added repair seq id into string Buffer End
                   strBuffEachRow.append(strRepairRef + "^");
                    strBuffEachRow.append(strRPRDesc + "^");
                  // 08-05-2006 Patni Addded Repair Effective date Begin
                // strBuffEachRow.append(strRepairEffectiveDate + "^");
                    // 08-05-2006 Patni Addded Repair Effective date End
                    strBuffEachRow.append(strPriceType + "^");
                    strBuffEachRow.append(strRprTat + "^");
// 08-05-2006 Patni Addded Incremental TAT Indicator Begin
                   strBuffEachRow.append(strIncrTATind + "^");
// 08-05-2006 Patni Addded Incremental TAT Indicator End
                    
                   strBuffEachRow.append(strRprPrice + "^");
                   
// 08-05-2006 Patni Addded Incremental Price Indicator Begin
                   strBuffEachRow.append(strIncrPriceind + "^");
// 08-05-2006 Patni Addded Incremental Price Indicator End
                   
                    strBuffEachRow.append(strFutTat + "^");
                    strBuffEachRow.append(strFutPrice + "^");
                    strBuffEachRow.append(strEffDate + "^");
// 26-06-2006 Patni Added Retain Value Indicator begin
                   strBuffEachRow.append(strRetainValueind + "^");
// 26-06-2006 Patni Added Retain Value Indicator end
                    strBuffEachRow.append(strLaborHr + "^");
                    strBuffEachRow.append(strMatCost + "^");
                    strBuffEachRow.append("^|"); // for next row
                    
                    /*
					 * Patni 23-Aug-2006 - Set Module Name variable to null -
					 * Begin
					 */
                    strModuleName = null; 
                    /*
					 * Patni 23-Aug-2006 - Set Module Name variable to null -
					 * End
					 */
                    
                    strCompDesc = null;
                    strCompCode = null;
                    strATAChpt = null;
                    strRepairRef = null;
                    strRPRDesc = null;
                    strPriceType = null;
                    strRprTat = null;
                    strRprPrice =null;

                    strFutTat = null;
                    strFutPrice = null;
                    strEffDate = null;

                    strLaborHr = null;
                    strMatCost = null;
                   // 08-05-2006 Patni Making null all the values Begin
                    strRepairSeqId = null;
                // strRepairEffectiveDate =null;
                   strIncrTATind = null;
                   strIncrPriceind = null;
                   // 08-05-2006 Patni Making null all the values end
                   // 26-06-2006 Patni Added Making Retain Value Indicator as null Begin
                   strRetainValueind = null;
                   // 26-06-2006 Patni Added Making Retain Value Indicator as null End
                    // Check for buffer size
                    if (strBuffEachElement.length() + strBuffEachRow.length() > 4000)
                    {
                        arrlstBuffs.add(strBuffEachElement);
                        strBuffEachElement = null;
                        strBuffEachElement = new StringBuffer();
                    }

                    /*
					 * If row do not have any errors then add row to element
					 * else do not add that row
					 */

                    if (blnValidRow)
                    {
                        strBuffEachElement.append(strBuffEachRow.toString());
                        strBuffEachRow =  null;
                        strBuffEachRow = new StringBuffer();
                    }

                    // if its a last row then append Buffer to array
                    if (intRowCtr == intNoOfRows)
                    {
                        arrlstBuffs.add(strBuffEachElement);
                        strBuffEachElement = null;
                        strBuffEachElement = new StringBuffer();
                    }
                }
                /* End : milind on 5 November */
            }
        }
        finally
        {
            strBuffEachRow = null;
            // strBuffEachComp = null;
            strBuffEachElement = null;
        }
        
        System.out.println("Read sheet method ends here--");
        return arrlstBuffs;
    }
  
    
  //Changes made for Office 2010.Start
    
    private ArrayList readSheet2010(GEAESheet2010 sheet2010,String strSiteName) throws Exception
    {	System.out.println("Inside read sheet 2010 method");
        int intNoOfRows = 0;
        int intNoOfCols = 0;
        GEAERow2010 row = null;
        GEAEExcelCell2010 cell = null;
        ArrayList arrlstBuffs = null;
        StringBuffer strBuffEachRow = null;
        StringBuffer strBuffEachElement = null;
        StringBuffer strBuffTestBlankRow = null;
        StringBuffer strBuffBlanks = null;
        StringBuffer strBuffEmpty = null;
        StringTokenizer strtkn = null;
        String[] strArrEachRow = null;
        String strEachCellValue = "";

        boolean blnValidRow = true;

        /* Start : Added by milind */
        String strModuleName = ""; // module name
        String strCompDesc = ""; // component description
        String strCompCode = ""; // component code
        String strATAChpt = ""; // ATA chapter
       // 08-05-2006 Patni Added Repair Sequence Id filed Begin
       String strRepairSeqId = ""; // Repair Sequence Id
      // 08-05-2006 Patni Added Repair Sequence Id filed End
        String strRepairRef = ""; // repair reference

        String strRPRDesc = ""; // Rpr Description
      // 08-05-2006 Patni Added Repair Effective Date filed Begin
    // String strRepairEffectiveDate = ""; // Repair Effective Date
      // 08-05-2006 Patni Added Repair Effective Date filed End
       
       
        String strPriceType = ""; // Price Type
        String strRprTat = ""; // Rpr TAT
       // 08-05-2006 Patni Added Incremental TAT Indicator filed Begin
       String strIncrTATind = ""; // Incremental TAT Indicator
      // 08-05-2006 Patni Added Incremental TAT Indicator filed End
     
        String strRprPrice = ""; // Rpr Price
// 08-05-2006 Patni Added Incremental Price Indicator filed Begin
       String strIncrPriceind = ""; // Incremental TAT Indicator
      // 08-05-2006 Patni Added Incremental Price Indicator filed End
     
        String strFutTat = ""; // Future TAT
        String strFutPrice = ""; // Future Price
        String strEffDate = ""; // Future Price/TAT Effective date
        String strLaborHr = ""; // Labor Hours
        String strMatCost = ""; // Material Cost
       // 26-06-2006 Patni added for Retain Value Indicator Begin
       String strRetainValueind = ""; 
       // 26-06-2006 Patni added for Retain Value Indicator End

        HashMap hmPriceTypes = null ;// for validations of price types
        
        StringTokenizer strtknModelDesc = null;
        boolean isInvalidATA = false;

        boolean isValidTAT = true;
        boolean isValidRprPrice = true;
        boolean isValidFutTAT = true;
        boolean isValidFutPrice = true;
        boolean isValidLaborHr = true;
        boolean isValidMatCost = true;

        /* End : Added by milind */
        // float fltMaxValue=0;
        int intDecimalInd = 0;
        int intIndexOfYear = 0;
        
        int intCellDataType;					//Changes made for Office 2010.
                
        /*//Changes made for Office 2010.Start			//65282
          try 
  		{        	
          	intCellDataType = cell.getCellType();
          } 
  		catch (Exception e) 
  		{
  			return "";
  		}
  		//Changes made for Office 2010.End			//65282
*/    
        try
        {
            hmPriceTypes = eCRDConstants.getPriceTypes();
            
            intNoOfRows = sheet2010.getLastRowNum();
            // milind : check for Empty Sheet
            
           if (!verifySheetHeaders2010(sheet2010.getRow((short) 0),strSiteName))
            {
                // Add error

                /* Patni 12-Sep-2006 - Changed the validation message - Begin */
                // arrLstError.add("Excel Sheet has Invalid headers Or Excel has
				// Labor Hours and Material Cost Data");
                arrLstError.add("Excel Sheet has Invalid headers");
                /* Patni 12-Sep-2006 - Changed the validation message - End */
                return new ArrayList();
            }
            
           arrlstBuffs = new ArrayList();
           strBuffEachElement = new StringBuffer();
          
           // Loop to fetch records from Each excel row // milind
            for (int intRowCtr = 1; intRowCtr <= intNoOfRows; intRowCtr++)
            {
                strBuffEachRow = new StringBuffer();
                row = sheet2010.getRow((short) intRowCtr);
                try
                {
                    intNoOfCols = (int) row.getLastCellNum();
                }
                catch (NullPointerException nullptrExp)
                {
                    intNoOfCols = 0;
                }
                if (intNoOfCols < 0)
                {
                    strArrEachRow = new String[1];
                }
                else
                {
                    strArrEachRow = new String[intNoOfCols];
                }
                strBuffTestBlankRow = new StringBuffer();
                strBuffBlanks = new StringBuffer();
                strBuffEmpty = new StringBuffer();

                  // loop to fetch cell values from each column
	                for (int intColCtr = 0; intColCtr < intNoOfCols; intColCtr++)
	                {
	                    try
	                    {
	                        strEachCellValue = "";
	                        cell = (GEAEExcelCell2010) row.getCell((short) intColCtr);
	                        intCellDataType = cell.getCellType();					//Changes made for Office 2010.
	                        
	                        /* Start : to fetch Future Effective date from Excel */
	                       /*
							 * 09-05-2006 Patni Removed 10 and added 13 for Future
							 * effective date Begin
							 */
	                       
	                       /*
							 * Patni 23-Aug-2006 - Column 14 corresponds to Future
							 * Effective Date - Begin
							 */
	                       // if (intColCtr == 13)
	                       if (intColCtr == 14)
	                       /*
							 * Patni 23-Aug-2006 - Column 14 corresponds to Future
							 * Effective Date - End
							 */
	                           
	                   /*
						 * 09-05-2006 Patni Removed 10 and added 13 for Future
						 * effective date End
						 */ 
	                       {	
	                            try
	                            {		//Changes made for Office 2010.Start
	                            		if (intCellDataType == 0)
	                            		{	
	                            			Date tempDate = cell.getDateCellValue();
	                            			strEachCellValue = eCRDUtil.isValidDate(tempDate, "MM/dd/yyyy");
	                            			System.out.println("Cell value is "+strEachCellValue);
	                            		}	
	                            		else
	                            		{
	                            			strEachCellValue = "";			
	                            		}
	                            		//Changes made for Office 2010.End
	                            }
	                            catch (NumberFormatException e)
	                            {	
	                                strEachCellValue = eCRDUtil.verifyNull(cell.getStringCellValue().trim());
	                                String tempStrEachCellValue = "";
	                                if (!"".equals(strEachCellValue))
	                                {
	                                    String temp = strEachCellValue.substring(6);
	                                    /*
										 * if year entered is "05" then change it to
										 * "2005"
										 */
	                                    if (temp.length() != 4)
	                                    {
	                                        strEachCellValue = "";
	                                    }
	                                    else
	                                    {
	                                        tempStrEachCellValue = eCRDUtil.isValidDate(strEachCellValue, "MM/dd/yyyy");
	
	                                        if (strEachCellValue.equals(tempStrEachCellValue))
	                                        {
	                                            strEachCellValue = tempStrEachCellValue;
	                                        }
	                                        else
	                                        {
	                                            strEachCellValue = "";
	                                        }
	                                    }
	                                }
	                                else
	                                {
	                                    strEachCellValue = "";
	                                }
	                            }
	                            catch (NullPointerException objNullPtrExp)
	                            {	
	                                strEachCellValue = "";
	                            }
	                            
	                        }
	                        /* End : to fetch Future Effective date from Excel */
	                        // else fetch normal String value from excel
	                       
	                       else if(intCellDataType == 1)    						//Changes made for Office 2010.
	                        {	
	                            strEachCellValue = cell.getStringCellValue();
	                            System.out.println("In Else If for 1(Alphanueric)"+strEachCellValue);
	                        }
	                       
	                        else if(intCellDataType == 0)							//Changes made for Office 2010.
	                        {	strEachCellValue = cell.getNumericCellValue() + "";
	                        	System.out.println("In Else If for 0(Numeric)"+strEachCellValue);
	                        }
	                                      	
	                    }
	                    /*catch (NumberFormatException numformExp)
	                    {
	                        strEachCellValue = cell.getNumericCellValue() + "";
	                    }*/
	                    // Milind : code need to be added for Date type column
	                    catch (NullPointerException nullptrExp)
	                    {	
	                        strEachCellValue = "";
	                    }
	                    finally
	                    {
	                        // store each cell value in String array
	                        strArrEachRow[intColCtr] = strEachCellValue;
	                        strBuffTestBlankRow.append(strEachCellValue + "^");
	                        strBuffBlanks.append(" ^");
	                        strBuffEmpty.append("^");
	                    }
	                  } // End of loop for Columns
             
	                System.out.println("End of loop for Columns");
                
	            if (strBuffBlanks.toString().equals(strBuffTestBlankRow.toString()) || strBuffEmpty.toString().equals(strBuffTestBlankRow.toString()))
                {
                    
                    if (intRowCtr == intNoOfRows)
                    {
                        arrlstBuffs.add(strBuffEachElement);
                        strBuffEachElement = null;
                        strBuffEachElement = new StringBuffer();
                    }
                }
                else
                {
                    /* Start : milind on 5 November */
                    // these are validations for each column
                    
                    /*
					 * Patni 23-Aug-2006 - Checking Maxlength for the Module
					 * Name - Begin
					 */
                    strModuleName  = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 0), 20, "Module Name", "" + (intRowCtr + 1));
                    /*
					 * Patni 23-Aug-2006 - Checking Maxlength for the Module
					 * Name - End
					 */
                    
                    /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * Begin
					 */
                    // strCompDesc =
					// isGreaterThanMaxLength(returnArrValue(strArrEachRow, 0),
					// 200, "Component Description", "" + (intRowCtr + 1));
                    strCompDesc  = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 1), 200, "Component Description", "" + (intRowCtr + 1));
                    /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * End
					 */
                   
                    /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * Begin
					 */ 
                    // strCompCode =
					// isGreaterThanMaxLength(returnArrValue(strArrEachRow, 1),
					// 20, "Component Code", "" + (intRowCtr + 1));
                    strCompCode  = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 2), 20, "Component Code", "" + (intRowCtr + 1));
                    /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * End
					 */
                    
                    /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * Begin
					 */
                    // strATAChpt =
					// isGreaterThanMaxLength(returnArrValue(strArrEachRow, 2),
					// 20, "ATA Chapter", "" + (intRowCtr + 1));
                    strATAChpt   = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 3), 20, "ATA Chapter", "" + (intRowCtr + 1));
                    /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * End
					 */
                    
                   // 08-05-2006 Patni Addded repair seq id validation Begin
                    
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * Begin
					 */
                   // strRepairSeqId
					// =isGreaterThanMaxLength(returnArrValue(strArrEachRow, 3),
					// 20, "Repair Seq Id", "" + (intRowCtr + 1));
                   strRepairSeqId =isGreaterThanMaxLength(returnArrValue(strArrEachRow, 4), 20, "Repair Seq Id", "" + (intRowCtr + 1));
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * End
					 */                   
                   
                   // 08-05-2006 Patni Addded repair seq id validation End
                   
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * Begin
					 */
                   // strRepairRef =
					// isGreaterThanMaxLength(returnArrValue(strArrEachRow, 4),
					// 100, "Repair Reference", "" + (intRowCtr + 1));
                   strRepairRef = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 5), 100, "Repair Reference", "" + (intRowCtr + 1));
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * End
					 */
                   
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * Begin
					 */
                   // strRPRDesc =
					// isGreaterThanMaxLength(returnArrValue(strArrEachRow, 5),
					// 255, "Rpr Description", "" + (intRowCtr + 1));
                   strRPRDesc   = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 6), 255, "Rpr Description", "" + (intRowCtr + 1));
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * End
					 */
                   
                   // 08-05-2006 Patni Addded Repair Effective date Begin
              // strRepairEffectiveDate= returnArrValue(strArrEachRow, 6);
                   // 08-05-2006 Patni Addded Repair Effective date End
               
                    /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * Begin
					 */
                    // strPriceType =
					// isGreaterThanMaxLength(returnArrValue(strArrEachRow, 6),
					// 10, "Price Type", "" + (intRowCtr + 1));
                    strPriceType = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 7), 10, "Price Type", "" + (intRowCtr + 1));
                    /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * End
					 */
                    
                    if(!(hmPriceTypes.containsValue(strPriceType)|| hmPriceTypes.containsKey(strPriceType)))
                    {
                        arrLstError.add("Please Enter a valid Price Type at Row " + (intRowCtr + 1) + " ");
                        blnValidRow = false;
                    }
                    
                    /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * Begin
					 */
                    // strRprTat =
					// isGreaterThanMaxLength(returnArrValue(strArrEachRow, 7),
					// 11, "Rpr TAT", "" + (intRowCtr + 1));
                    strRprTat = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 8), 11, "Rpr TAT", "" + (intRowCtr + 1));
                    /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * End
					 */
                    
                   // 08-05-2006 Patni Addded Incremental TAT Indicator Begin
                   
                    /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * Begin
					 */
                   // strIncrTATind =
					// isGreaterThanMaxLength(returnArrValue(strArrEachRow,8),
					// 1, "Incremental TAT Indicator", "" + (intRowCtr + 1));
                   strIncrTATind = isGreaterThanMaxLength(returnArrValue(strArrEachRow,9), 1, "Incremental TAT Indicator", "" + (intRowCtr + 1));
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * End
					 */

                   // 08-05-2006 Patni Addded Incremental TAT Indicator ENd
                   
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * Begin
					 */
                   // strRprPrice =
					// isGreaterThanMaxLength(returnArrValue(strArrEachRow,9),
					// 15, "Rpr Price", "" + (intRowCtr + 1));
                   strRprPrice = isGreaterThanMaxLength(returnArrValue(strArrEachRow,10), 15, "Rpr Price", "" + (intRowCtr + 1));
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * End
					 */
                   
                   // 08-05-2006 Patni Addded Incremental Price Indicator Begin
                   
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * Begin
					 */
                   // strIncrPriceind =
					// isGreaterThanMaxLength(returnArrValue(strArrEachRow, 10),
					// 1, "Incremental Price Indicator", "" + (intRowCtr + 1));
                   strIncrPriceind = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 11), 1, "Incremental Price Indicator", "" + (intRowCtr + 1));
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * End
					 */
                   
                   // 08-05-2006 Patni Addded Incremental Price Indicator End
                  
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * Begin
					 */
                   // strFutTat =
					// isGreaterThanMaxLength(returnArrValue(strArrEachRow, 11),
					// 7, "Future TAT", "" + (intRowCtr + 1));
                   strFutTat = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 12), 7, "Future TAT", "" + (intRowCtr + 1));
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * End
					 */
                   
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * Begin
					 */
                   // strFutPrice =
					// isGreaterThanMaxLength(returnArrValue(strArrEachRow, 12),
					// 15, "Future Price", "" + (intRowCtr + 1));
                   strFutPrice = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 13), 15, "Future Price", "" + (intRowCtr + 1));
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * End
					 */
                   
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * Begin
					 */
                   // strEffDate = returnArrValue(strArrEachRow, 13);
                   strEffDate = returnArrValue(strArrEachRow, 14);
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * End
					 */
                   
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * Begin
					 */
                   // strLaborHr =
					// isGreaterThanMaxLength(returnArrValue(strArrEachRow, 14),
					// 15, "Labor Hours", "" + (intRowCtr + 1));
                   strLaborHr = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 15), 15, "Labor Hours", "" + (intRowCtr + 1));
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * End
					 */
                   
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * Begin
					 */
                   // strMatCost =
					// isGreaterThanMaxLength(returnArrValue(strArrEachRow, 15),
					// 15, "Material Cost", "" + (intRowCtr + 1));
                   strMatCost = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 16), 15, "Material Cost", "" + (intRowCtr + 1));
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * End
					 */
                   
                    // 26-06-2006 Added retain value indicator Begin
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * Begin
					 */
                   // strRetainValueind =
					// isGreaterThanMaxLength(returnArrValue(strArrEachRow,16),
					// 1, "Retain Value Indicator", "" + (intRowCtr + 1));
                   strRetainValueind = isGreaterThanMaxLength(returnArrValue(strArrEachRow,17), 1, "Retain Value Indicator", "" + (intRowCtr + 1));
                   /*
					 * Patni 23-Aug-2006 - Rearranged the excel cell number -
					 * End
					 */
                   // 26-06-2006 Added retain value indicator End
                   
                    blnValidRow = true;
                    /*
					 * Start : Future Effective Date Validations :
					 * 
					 * Assumptions 1] If future TAT is present, then Effective
					 * date should be present 2] If future price is present,
					 * then Effective date should be present 3] If effective
					 * date is present, then either future Tat or future price
					 * should be present 4] Future TAT, Future Price and
					 * Effective date can by blank(null)
					 */
                    if (!strEffDate.trim().equals("") )
                    {
                        Date tempDate = new Date();

                        if (tempDate.after(new Date(strEffDate.trim())))
                        {
                            arrLstError.add("Future Effective Date should be greater than today at Row " + (intRowCtr + 1) + " ");
                            blnValidRow = false;
                        }

                        if (!strFutTat.trim().equals(""))
                        {
                            if(strFutTat.startsWith("+"))
                            {
                                isValidFutTAT =false;
                                arrLstError.add("Incremental TAT cannot be entered for Future TAT at Row " + (intRowCtr + 1) + " ");
                            }
                            isValidFutTAT = isValidNumberZeroValid(strFutTat, "9999999", "Future TAT", "" + (intRowCtr + 1), false, "");
                            if (!isValidFutTAT)
                            {
                                blnValidRow = false;
                            }
                        }

                        if (!strFutPrice.trim().equals(""))
                        {
                            if(strFutPrice.startsWith("+"))
                            {
                                isValidFutPrice =false;
                                arrLstError.add("Incremental Price cannot be entered for Future Price at Row " + (intRowCtr + 1) + " ");
                            }
                            isValidFutPrice = isValidNumberZeroValid(strFutPrice, "99999999999.99", "Future Price", "" + (intRowCtr + 1), true, "QUOTE");
                            if (!isValidFutPrice)
                            {
                                blnValidRow = false;
                            }
                        }

                    }
                    /*
					 * if (!strEffDate.trim().equals("")) { if
					 * (strFutTat.trim().equals("") &&
					 * strFutPrice.trim().equals("")) { arrLstError.add("Invalid
					 * Future TAT, Future Price and Future effective date at Row " +
					 * (intRowCtr + 1)); blnValidRow = false; } }
					 */
                    if(!strFutTat.trim().equals("") || !strFutPrice.trim().equals(""))
                    {
                        if(strEffDate.trim().equals(""))
                        {
                            arrLstError.add("Please Enter Future effective date at Row " + (intRowCtr + 1));
                            blnValidRow = false;
                        }
                    }
                    /* End : Date Validations : */

                    // Validation Starts
                    /* Patni 23-Aug-2006 - Validation for Module Name - Begin */
                    if ("".equals(strModuleName.trim()))
                    {
                        arrLstError.add("Module Name not found at Row " + (intRowCtr + 1));
                        blnValidRow = false;
                    }
                    /* Patni 23-Aug-2006 - Validation for Module Name - End */
                    
                    if ("".equals(strCompCode.trim()))
                    {
                        arrLstError.add("Component Code not found at Row " + (intRowCtr + 1));
                        blnValidRow = false;
                    }

                    if ("".equals(strCompDesc.trim()))
                    {
                        arrLstError.add("Component Description not found for " + strCompCode + " at Row " + (intRowCtr + 1));
                        blnValidRow = false;
                    }

                    if ("".equals(strATAChpt.trim()))
                    {
                        arrLstError.add("ATA not found at Row " + (intRowCtr + 1));
                        blnValidRow = false;

                    }
                    else
                    {
                        if (strATAChpt.length() > 20)
                        {
                            arrLstError.add("ATA : " + strATAChpt + " Exceeds Max Allowed length 20 ");
                            blnValidRow = false;
                        }
                        else
                        {
                            isInvalidATA = validateATA(strATAChpt);
                            if (isInvalidATA)
                            {
                                arrLstError.add("ATA : " + strATAChpt + " not in corect format at Row " + (intRowCtr + 1) + " Expected Format NN-NN-NN or GEK * or TO * ");
                                blnValidRow = false;
                            }
                        }
                    }
                    /*
					 * if ("".equals(strRepairRef.trim())) {
					 * arrLstError.add("Repair Reference not found at Row " +
					 * (intRowCtr + 1)); blnValidRow = false; }
					 */
                    if ("".equals(strRPRDesc.trim()))
                    {
                        arrLstError.add("Repair Description not found at Row " + (intRowCtr + 1));
                        blnValidRow = false;
                    }
                    if ("".equals(strPriceType.trim()))
                    {
                        arrLstError.add("Price Type not found at Row " + (intRowCtr + 1));
                        blnValidRow = false;
                    }
                    if("QUOTE".equals(strPriceType.trim()))
                    {
                        if(!strFutPrice.trim().equals(""))
                        {
                            arrLstError.add("Future Repair Price Cannot be entered for Price type QUOTE at Row " + (intRowCtr + 1));
                            blnValidRow = false;    
                        }
                        if(!("".equals(strRprPrice)||" ".equals(strRprPrice) ))
                        {
                            arrLstError.add("Repair Price Cannot be entered for repair type QUOTE at Row No." + (intRowCtr + 1));
                            isValidRprPrice = false;
                        }
                    }
                    else
                    {
                       
                        if(!"+".equals(strRprPrice))
                        {
                          
                            isValidRprPrice = isValidNumberZeroValid(strRprPrice, "99999999999.99", "Repair Price", "" + (intRowCtr + 1), false, "");
                        }
                        
                        if("".equals(strRprPrice)||" ".equals(strRprPrice) )
                        {
                            /*
							 * arrLstError.add("Repair Price not found for
							 * repair at Row No." + (intRowCtr + 1));
							 * isValidRprPrice = false;
							 */
                            strRprPrice = "";
                        }
                    }
                    if(!"+".equals(strRprTat))
                    {
                        
                       isValidTAT = isValidNumberZeroValid(strRprTat, "99999999999", "Repair TAT", "" + (intRowCtr + 1), false, "");
                    }
                    if("".equals(strRprTat)||" ".equals(strRprTat) )
                    {
                        /*
						 * arrLstError.add("Repair TAT not found for repair at
						 * Row No." + (intRowCtr + 1)); isValidTAT = false;
						 */
                        strRprTat = "";
                    }

                    isValidLaborHr = isValidNumberZeroValid(strLaborHr, "99999999999.99", "Labor Hour", "" + (intRowCtr + 1), false, "");
                    isValidMatCost = isValidNumberZeroValid(strMatCost, "99999999999.99", "Material Cost", "" + (intRowCtr + 1), false, "");

                    if (!isValidTAT || !isValidRprPrice || !isValidLaborHr || !isValidMatCost)
                    {
                        blnValidRow = false;
                    }
                  // 10-05-2006 Patni Checking Incremental TAT Indicator/
					// Price Indicator Begin
                  
                  
                   if ("".equals(strIncrTATind))
                   {
                       arrLstError.add("Incremental TAT Indicator not found at Row " + (intRowCtr + 1));
                       blnValidRow = false;
                   }
               
                   if(!"Y".equals(strIncrTATind) && !"N".equals(strIncrTATind) )
                   {
                       arrLstError.add("Incremental TAT Indicator should match with Y/N " + (intRowCtr + 1));
                       blnValidRow = false;
                    }
                  // Incremental Price Indicator
                   if ("".equals(strIncrPriceind))
                   {
                       arrLstError.add("Incremental Price Indicator not found at Row " + (intRowCtr + 1));
                       blnValidRow = false;
                   }

                   if(!"Y".equals(strIncrPriceind) && !"N".equals(strIncrPriceind) )
                   {
                       arrLstError.add("Incremental Price Indicator should match with Y/N " + (intRowCtr + 1));
                       blnValidRow = false;
                    }
                   // 10-05-2006 Patni Checking Incremental TAT Indicator/
					// Price Indicator End
                   // 26-06-2006 Patni Added Retain Value Indicator Validations
					// begin
                   if("".equals(strRetainValueind) && !strSiteName.equals("ALL"))
                   {
                     arrLstError.add("Retain Value Indicator not found at Row " + (intRowCtr + 1));
                     blnValidRow = false;
                   }
                   if(!"N".equals(strRetainValueind) && !"Y".equals(strRetainValueind)&& !strSiteName.equals("ALL") )
                   {
                     arrLstError.add("Retain Value Indicator should match with (Y/N) at Row " + (intRowCtr + 1));
                     blnValidRow = false;
                   }
                   // 26-06-2006 Patni Added Retain Value Indicator Validations
					// end
                    // After Validating all fields..append it to String buffer
                    strBuffEachRow.append((intRowCtr + 1) + "^");
                    
                    /*
					 * Patni 23-Aug-2006 - Included Module Name to the Buffer
					 * String - Begin
					 */
                    strBuffEachRow.append(strModuleName + "^");
                    /*
					 * Patni 23-Aug-2006 - Included Module Name to the Buffer
					 * String - End
					 */
                    
                    strBuffEachRow.append(strCompDesc + "^");
                    strBuffEachRow.append(strCompCode + "^");
                    strBuffEachRow.append(strATAChpt + "^");
                   // 08-05-2006 Added repair seq id into string Buffer Begin
                   strBuffEachRow.append(strRepairSeqId+ "^");
                   // 08-05-2006 Added repair seq id into string Buffer End
                   strBuffEachRow.append(strRepairRef + "^");
                    strBuffEachRow.append(strRPRDesc + "^");
                  // 08-05-2006 Patni Addded Repair Effective date Begin
                // strBuffEachRow.append(strRepairEffectiveDate + "^");
                    // 08-05-2006 Patni Addded Repair Effective date End
                    strBuffEachRow.append(strPriceType + "^");
                    strBuffEachRow.append(strRprTat + "^");
// 08-05-2006 Patni Addded Incremental TAT Indicator Begin
                   strBuffEachRow.append(strIncrTATind + "^");
// 08-05-2006 Patni Addded Incremental TAT Indicator End
                    
                   strBuffEachRow.append(strRprPrice + "^");
                   
// 08-05-2006 Patni Addded Incremental Price Indicator Begin
                   strBuffEachRow.append(strIncrPriceind + "^");
// 08-05-2006 Patni Addded Incremental Price Indicator End
                   
                    strBuffEachRow.append(strFutTat + "^");
                    strBuffEachRow.append(strFutPrice + "^");
                    strBuffEachRow.append(strEffDate + "^");
// 26-06-2006 Patni Added Retain Value Indicator begin
                   strBuffEachRow.append(strRetainValueind + "^");
// 26-06-2006 Patni Added Retain Value Indicator end
                    strBuffEachRow.append(strLaborHr + "^");
                    strBuffEachRow.append(strMatCost + "^");
                    strBuffEachRow.append("^|"); // for next row
                    
                    /*
					 * Patni 23-Aug-2006 - Set Module Name variable to null -
					 * Begin
					 */
                    strModuleName = null; 
                    /*
					 * Patni 23-Aug-2006 - Set Module Name variable to null -
					 * End
					 */
                    
                    strCompDesc = null;
                    strCompCode = null;
                    strATAChpt = null;
                    strRepairRef = null;
                    strRPRDesc = null;
                    strPriceType = null;
                    strRprTat = null;
                    strRprPrice =null;

                    strFutTat = null;
                    strFutPrice = null;
                    strEffDate = null;

                    strLaborHr = null;
                    strMatCost = null;
                   // 08-05-2006 Patni Making null all the values Begin
                    strRepairSeqId = null;
                // strRepairEffectiveDate =null;
                   strIncrTATind = null;
                   strIncrPriceind = null;
                   // 08-05-2006 Patni Making null all the values end
                   // 26-06-2006 Patni Added Making Retain Value Indicator as null Begin
                   strRetainValueind = null;
                   // 26-06-2006 Patni Added Making Retain Value Indicator as null End
                    // Check for buffer size
                    if (strBuffEachElement.length() + strBuffEachRow.length() > 4000)
                    {
                        arrlstBuffs.add(strBuffEachElement);
                        strBuffEachElement = null;
                        strBuffEachElement = new StringBuffer();
                    }

                    /*
					 * If row do not have any errors then add row to element
					 * else do not add that row
					 */

                    if (blnValidRow)
                    {
                        strBuffEachElement.append(strBuffEachRow.toString());
                        strBuffEachRow =  null;
                        strBuffEachRow = new StringBuffer();
                    }

                    // if its a last row then append Buffer to array
                    if (intRowCtr == intNoOfRows)
                    {
                        arrlstBuffs.add(strBuffEachElement);
                        strBuffEachElement = null;
                        strBuffEachElement = new StringBuffer();
                    }
                }
                /* End : milind on 5 November */
            }  
        }
        finally
        {
            strBuffEachRow = null;
            // strBuffEachComp = null;
            strBuffEachElement = null;
        }
        System.out.println("Read Sheet2010 method ends here--");
        return arrlstBuffs;
    }
  //Changes made for Office 2010.End
    
    /**
	 * Method name: readComponentSheet Brief logic: This Read all columns
	 * uploaded with component details and validates .
	 * 
	 * @author Patni Team
	 * @version 1.0
	 * @param
	 * @return
	 * @since JDK1.4
	 */
    
    private ArrayList readComponentSheet(GEAESheet sheet,String strSiteName) throws Exception
    {	System.out.println("Inside read component sheet method---");
        int intNoOfRows = 0;
        int intNoOfCols = 0;
        int intLocSequence = 0;
        GEAERow row = null;
        GEAEExcelCell cell = null;
        ArrayList arrlstBuffs = null;
        HashMap hmPrimesiteChecker  = null;
        HashMap hmDupLocChecker = null;
        StringBuffer strBuffEachRow = null;
        StringBuffer strBuffEachElement = null;
        StringBuffer strBuffTestBlankRow = null;
        StringBuffer strBuffBlanks = null;
        StringBuffer strBuffEmpty = null;
        StringTokenizer strtkn = null;
        String[] strArrEachRow = null;
        String strEachCellValue = "";

        boolean blnValidRow = true;

        String strModuleNameSeqId   = "";   // Module Seq ID
        String strModuleName        = "";   // Module Name
        String strCompCode          = "";   // Component Code
        String strCompDesc          = "";   // Component Description
        String strLocationID        = "";   // Location Id
        String strLocationName      = "";   // Location Name
        String strPrimaryInd        = "";   // Primary Site Ind
        String strHiddenInd         = "";   // Hidden Site Ind
        String strDeleteInd         = "";   // Delete Site Ind
        
        StringTokenizer strtknModelDesc = null;
        
        int intDecimalInd = 0;
        int intIndexOfYear = 0;
        try
        {
            intNoOfRows = sheet.getLastRowNum();
           if (!verifySheetCompHeaders(sheet.getRow((short) 0),strSiteName))
            {
                arrLstError.add("Excel Sheet has Invalid headers");
                return new ArrayList();
            }
            
           arrlstBuffs = new ArrayList();
           hmPrimesiteChecker = new HashMap();
           hmDupLocChecker = new HashMap();
           strBuffEachElement = new StringBuffer();
           
            // Loop to fetch records from Each excel row
            for (int intRowCtr = 1; intRowCtr <= intNoOfRows; intRowCtr++)
            {
                strBuffEachRow = new StringBuffer();
                row = sheet.getRow((short) intRowCtr);
                try
                {
                    intNoOfCols = (int) row.getLastCellNum();
                }
                catch (NullPointerException nullptrExp)
                {
                    intNoOfCols = 0;
                }
                if (intNoOfCols < 0)
                {
                    strArrEachRow = new String[1];
                }
                else
                {
                    strArrEachRow = new String[intNoOfCols];
                }
                strBuffTestBlankRow = new StringBuffer();
                strBuffBlanks = new StringBuffer();
                strBuffEmpty = new StringBuffer();

                // Start :: loop to fetch cell values from each column
                for (int intColCtr = 0; intColCtr < intNoOfCols; intColCtr++)
                {   
                    try
                    {
                        strEachCellValue = "";
                        cell = (GEAEExcelCell) row.getCell((short) intColCtr);
                        strEachCellValue = cell.getStringCellValue();
                    }
                    catch (NumberFormatException numformExp)
                    {
                        int intCellValue = 0;
                        intCellValue = (int)cell.getNumericCellValue();
                        strEachCellValue = intCellValue+"";
                    }
                    catch (NullPointerException nullptrExp)
                    {
                        strEachCellValue = "";
                    }
                    finally
                    {
                        // store each cell value in String array
                        strArrEachRow[intColCtr] = strEachCellValue;
                        strBuffTestBlankRow.append(strEachCellValue + "^");
                        strBuffBlanks.append(" ^");
                        strBuffEmpty.append("^");
                    }
                } 
                // End :: loop to fetch cell values from each column
                if (strBuffBlanks.toString().equals(strBuffTestBlankRow.toString()) || strBuffEmpty.toString().equals(strBuffTestBlankRow.toString()))
                {
                    
                    if (intRowCtr == intNoOfRows)
                    {
                        arrlstBuffs.add(strBuffEachElement);
                        strBuffEachElement = null;
                        strBuffEachElement = new StringBuffer();
                    }
                }
                else
                {
                    strModuleNameSeqId = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 0), 20, eCRDConstants.STRMODULESEQID, "" + (intRowCtr + 1));
                    strModuleName      = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 1), 20, eCRDConstants.STRMODULENAME, "" + (intRowCtr + 1));
                    strCompCode        = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 2), 20, eCRDConstants.STRCOMPCODE, "" + (intRowCtr + 1));
                    strCompDesc        = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 3), 200,eCRDConstants.STRCOMPDESC, "" + (intRowCtr + 1));
                    strLocationID      = isGreaterThanMaxLength(returnArrValue(strArrEachRow,4), 4, eCRDConstants.STRLOCATIONID, "" + (intRowCtr + 1));
                    strLocationName    = isGreaterThanMaxLength(returnArrValue(strArrEachRow,5), 30, eCRDConstants.STRLOCATIONNAME, "" + (intRowCtr + 1));   
                    strPrimaryInd      = isGreaterThanMaxLength(returnArrValue(strArrEachRow,6), 1, eCRDConstants.STRPRIMARYSITE, "" + (intRowCtr + 1));
                    strHiddenInd       = isGreaterThanMaxLength(returnArrValue(strArrEachRow,7), 1, eCRDConstants.STRHIDDENSITE, "" + (intRowCtr + 1));
                    strDeleteInd       = isGreaterThanMaxLength(returnArrValue(strArrEachRow,8), 1, eCRDConstants.STRDELETESITE, "" + (intRowCtr + 1));
                    blnValidRow = true;
                    
                    /*
					 * Start : Validations :
					 * 
					 * Assumptions 1] If Primary site is "Y", then Hidden Site
					 * can't be "Y" 2] If Primary site is "Y", then Delete Site
					 * can't be "Y"
					 */
                    
                    if (strPrimaryInd.trim().equalsIgnoreCase("Y") )
                    {
                        if (strHiddenInd.trim().equalsIgnoreCase("Y"))
                        {
                            arrLstError.add("Primary site and Hidden Site cannot be 'Y' at Row " + (intRowCtr + 1) + " ");
                            blnValidRow = false;
                        }
                        if (strDeleteInd.trim().equalsIgnoreCase("Y"))
                        {
                            arrLstError.add("Primary site and Delete Site cannot be 'Y' at Row " + (intRowCtr + 1) + " ");
                            blnValidRow = false;
                        }

                    }
                    
                    // Validation Starts
                    if ("".equals(strModuleNameSeqId.trim()))
                    {
                        arrLstError.add("Engine Module Seq Id not found at Row " + (intRowCtr + 1));
                        blnValidRow = false;
                    }
                    if ("".equals(strModuleName.trim()))
                    {
                        arrLstError.add("Engine Module not found at Row " + (intRowCtr + 1));
                        blnValidRow = false;
                    }
                    if ("".equals(strCompCode.trim()))
                    {
                        arrLstError.add("Component Code not found at Row " + (intRowCtr + 1));
                        blnValidRow = false;
                    }
                    if ("".equals(strCompDesc.trim()))
                    {
                        arrLstError.add("Component Description not found for " + strCompCode + " at Row " + (intRowCtr + 1));
                        blnValidRow = false;
                    }
                    if ("".equals(strLocationID.trim()))
                    {
                        arrLstError.add("Location ID not found at Row " + (intRowCtr + 1));
                        blnValidRow = false;
                    }
                    if ("".equals(strLocationName.trim()))
                    {
                        arrLstError.add("Location Name not found at Row " + (intRowCtr + 1));
                        blnValidRow = false;
                    }
                    if ("".equals(strPrimaryInd.trim()))
                    {
                        arrLstError.add("Primary Site not found at Row " + (intRowCtr + 1));
                        blnValidRow = false;
                    }
                    if ("Y".equalsIgnoreCase(strPrimaryInd.trim()) || "N".equalsIgnoreCase(strPrimaryInd.trim()) )
                    {
                    }
                    else {
                        arrLstError.add("Primary Site has Invalid Character at Row " + (intRowCtr + 1)+". (Y/N) only allowed Character");
                        blnValidRow = false;
                    }
                    
                    if ("".equals(strHiddenInd.trim()))
                    {
                        arrLstError.add("Hidden Site not found at Row " + (intRowCtr + 1));
                        blnValidRow = false;
                    }
                    if ("Y".equalsIgnoreCase(strHiddenInd.trim()) || "N".equalsIgnoreCase(strHiddenInd.trim()) )
                    {
                    }
                    else {
                        arrLstError.add("Hidden Site has Invalid Character at Row " + (intRowCtr + 1)+". (Y/N) only allowed Character");
                        blnValidRow = false;
                    }
                    
                    if ("".equals(strDeleteInd.trim()))
                    {
                        arrLstError.add("Delete Site not found at Row " + (intRowCtr + 1));
                        blnValidRow = false;
                    }
                    if ("Y".equalsIgnoreCase(strDeleteInd.trim()) || "N".equalsIgnoreCase(strDeleteInd.trim()) )
                    {
                    }
                    else {
                        arrLstError.add("Delete Site has Invalid Character at Row " + (intRowCtr + 1)+". (Y/N) only allowed Character");
                        blnValidRow = false;
                    }
                    
                    
                    /**
					 * This Loop will try to check whether for a perticular
					 * Module SeqID and Component Code and Location Id
					 * Combination is present for multiple sites
					 * 
					 */
                    if(hmDupLocChecker.containsValue(strModuleNameSeqId+strModuleName+strCompCode+strCompDesc+strLocationID)) {
                        arrLstError.add("Component Code "+strCompCode+" has duplicate Locations at Row Number " + (intRowCtr + 1));
                    }
                    else {
                        hmDupLocChecker.put((++intLocSequence)+strModuleNameSeqId+strModuleName+strCompCode,
                                strModuleNameSeqId+strModuleName+strCompCode+strCompDesc+strLocationID);
                    }
                  
                    /**
					 * This Loop will try to check whether for a perticular
					 * Module SeqID and Component Code Combination is multiple
					 * Primary Site Ind Set to = 'Y' if so then raise Error
					 */
                    
                    if("Y".equalsIgnoreCase(strPrimaryInd)) {
                        if(hmPrimesiteChecker.containsValue(strModuleNameSeqId+strModuleName+strCompCode+strCompDesc+strPrimaryInd)) {
                            arrLstError.add("Component Code "+strCompCode+" has multiple Primary Sites at Row Number " + (intRowCtr + 1));
                        }
                        else {
                            hmPrimesiteChecker.put(strModuleNameSeqId+strModuleName+strCompCode,
                                    strModuleNameSeqId+strModuleName+strCompCode+strCompDesc+strPrimaryInd);
                        }
                    }

                    // After Validating all fields..append it to String buffer
                    // Each column is appened with "^"
                    strBuffEachRow.append((intRowCtr + 1) + "^");
                    strBuffEachRow.append(strModuleNameSeqId + "^"); 
                    strBuffEachRow.append(strModuleName + "^");
                    strBuffEachRow.append(strCompCode + "^");
                    strBuffEachRow.append(strCompDesc + "^");
                    strBuffEachRow.append(strLocationID + "^");
                    strBuffEachRow.append(strLocationName + "^");
                    strBuffEachRow.append(strPrimaryInd + "^");
                    strBuffEachRow.append(strHiddenInd + "^");
                    strBuffEachRow.append(strDeleteInd + "^");
                    strBuffEachRow.append("^|"); // After end of a Row "|" is appended
                    
                    strModuleNameSeqId  = null; 
                    strModuleName       = null; 
                    strCompCode         = null; 
                    strCompDesc         = null;
                    strLocationID       = null;
                    strLocationName     = null;
                    strPrimaryInd       = null;
                    strHiddenInd        = null;
                    strDeleteInd        = null;
                                       
                    // Check for buffer size
                    if (strBuffEachElement.length() + strBuffEachRow.length() > 4000)
                    {
                        arrlstBuffs.add(strBuffEachElement);
                        strBuffEachElement = null;
                        strBuffEachElement = new StringBuffer();
                    }

                    /*
					 * If row do not have any errors then add row to element
					 * else do not add that row
					 */
                    if (blnValidRow)
                    {
                        strBuffEachElement.append(strBuffEachRow.toString());
                        strBuffEachRow =  null;
                        strBuffEachRow = new StringBuffer();
                    }

                    // if its a last row then append Buffer to array
                    if (intRowCtr == intNoOfRows)
                    {
                        arrlstBuffs.add(strBuffEachElement);
                        strBuffEachElement = null;
                        strBuffEachElement = new StringBuffer();
                    }
                }
            }
        }
        finally
        {
            strBuffEachRow = null;
            // strBuffEachComp = null;
            strBuffEachElement = null;
        }
        return arrlstBuffs;
    }
 /* END readComponentSheet() */   

    /**
	 * Method name: readComponentSheet2010 Brief logic: This Read all columns
	 * uploaded with component details and validates for XLSX files.
	 * 
	 * @author Patni Team
	 * @version 1.0
	 * @param
	 * @return
	 * @since JDK1.4
	 */
    
  //Changes made for Office 2010.Start
    
    private ArrayList readComponentSheet2010(GEAESheet2010 sheet2010,String strSiteName) throws Exception
    {	System.out.println("Inside read component sheet 2010 method---");
        int intNoOfRows = 0;
        int intNoOfCols = 0;
        int intLocSequence = 0;
        GEAERow2010 row = null;
        GEAEExcelCell2010 cell = null;
        ArrayList arrlstBuffs = null;
        HashMap hmPrimesiteChecker  = null;
        HashMap hmDupLocChecker = null;
        StringBuffer strBuffEachRow = null;
        StringBuffer strBuffEachElement = null;
        StringBuffer strBuffTestBlankRow = null;
        StringBuffer strBuffBlanks = null;
        StringBuffer strBuffEmpty = null;
        StringTokenizer strtkn = null;
        String[] strArrEachRow = null;
        String strEachCellValue = "";

        boolean blnValidRow = true;

        String strModuleNameSeqId   = "";   // Module Seq ID
        String strModuleName        = "";   // Module Name
        String strCompCode          = "";   // Component Code
        String strCompDesc          = "";   // Component Description
        String strLocationID        = "";   // Location Id
        String strLocationName      = "";   // Location Name
        String strPrimaryInd        = "";   // Primary Site Ind
        String strHiddenInd         = "";   // Hidden Site Ind
        String strDeleteInd         = "";   // Delete Site Ind
        
        StringTokenizer strtknModelDesc = null;
        
        int intDecimalInd = 0;
        int intIndexOfYear = 0;
        try
        {
            intNoOfRows = sheet2010.getLastRowNum();
           if (!verifySheetCompHeaders2010(sheet2010.getRow((short) 0),strSiteName))
            {
                arrLstError.add("Excel Sheet has Invalid headers");
                return new ArrayList();
            }
            
           arrlstBuffs = new ArrayList();
           hmPrimesiteChecker = new HashMap();
           hmDupLocChecker = new HashMap();
           strBuffEachElement = new StringBuffer();
           
            // Loop to fetch records from Each excel row
            for (int intRowCtr = 1; intRowCtr <= intNoOfRows; intRowCtr++)
            {
                strBuffEachRow = new StringBuffer();
                row = sheet2010.getRow((short) intRowCtr);
                try
                {
                    intNoOfCols = (int) row.getLastCellNum();
                }
                catch (NullPointerException nullptrExp)
                {
                    intNoOfCols = 0;
                }
                if (intNoOfCols < 0)
                {
                    strArrEachRow = new String[1];
                }
                else
                {
                    strArrEachRow = new String[intNoOfCols];
                }
                strBuffTestBlankRow = new StringBuffer();
                strBuffBlanks = new StringBuffer();
                strBuffEmpty = new StringBuffer();

                // Start :: loop to fetch cell values from each column
                for (int intColCtr = 0; intColCtr < intNoOfCols; intColCtr++)
                {   
                    try
                    {
                        strEachCellValue = "";
                        cell = (GEAEExcelCell2010) row.getCell((short) intColCtr);
                        strEachCellValue = cell.getStringCellValue();
                    }
                    catch (NumberFormatException numformExp)
                    {
                        int intCellValue = 0;
                        intCellValue = (int)cell.getNumericCellValue();
                        strEachCellValue = intCellValue+"";
                    }
                    catch (NullPointerException nullptrExp)
                    {
                        strEachCellValue = "";
                    }
                    finally
                    {
                        // store each cell value in String array
                        strArrEachRow[intColCtr] = strEachCellValue;
                        strBuffTestBlankRow.append(strEachCellValue + "^");
                        strBuffBlanks.append(" ^");
                        strBuffEmpty.append("^");
                    }
                } 
                // End :: loop to fetch cell values from each column
                if (strBuffBlanks.toString().equals(strBuffTestBlankRow.toString()) || strBuffEmpty.toString().equals(strBuffTestBlankRow.toString()))
                {
                    
                    if (intRowCtr == intNoOfRows)
                    {
                        arrlstBuffs.add(strBuffEachElement);
                        strBuffEachElement = null;
                        strBuffEachElement = new StringBuffer();
                    }
                }
                else
                {
                    strModuleNameSeqId = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 0), 20, eCRDConstants.STRMODULESEQID, "" + (intRowCtr + 1));
                    strModuleName      = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 1), 20, eCRDConstants.STRMODULENAME, "" + (intRowCtr + 1));
                    strCompCode        = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 2), 20, eCRDConstants.STRCOMPCODE, "" + (intRowCtr + 1));
                    strCompDesc        = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 3), 200,eCRDConstants.STRCOMPDESC, "" + (intRowCtr + 1));
                    strLocationID      = isGreaterThanMaxLength(returnArrValue(strArrEachRow,4), 4, eCRDConstants.STRLOCATIONID, "" + (intRowCtr + 1));
                    strLocationName    = isGreaterThanMaxLength(returnArrValue(strArrEachRow,5), 30, eCRDConstants.STRLOCATIONNAME, "" + (intRowCtr + 1));   
                    strPrimaryInd      = isGreaterThanMaxLength(returnArrValue(strArrEachRow,6), 1, eCRDConstants.STRPRIMARYSITE, "" + (intRowCtr + 1));
                    strHiddenInd       = isGreaterThanMaxLength(returnArrValue(strArrEachRow,7), 1, eCRDConstants.STRHIDDENSITE, "" + (intRowCtr + 1));
                    strDeleteInd       = isGreaterThanMaxLength(returnArrValue(strArrEachRow,8), 1, eCRDConstants.STRDELETESITE, "" + (intRowCtr + 1));
                    blnValidRow = true;
                    
                    /*
					 * Start : Validations :
					 * 
					 * Assumptions 1] If Primary site is "Y", then Hidden Site
					 * can't be "Y" 2] If Primary site is "Y", then Delete Site
					 * can't be "Y"
					 */
                    
                    if (strPrimaryInd.trim().equalsIgnoreCase("Y") )
                    {
                        if (strHiddenInd.trim().equalsIgnoreCase("Y"))
                        {
                            arrLstError.add("Primary site and Hidden Site cannot be 'Y' at Row " + (intRowCtr + 1) + " ");
                            blnValidRow = false;
                        }
                        if (strDeleteInd.trim().equalsIgnoreCase("Y"))
                        {
                            arrLstError.add("Primary site and Delete Site cannot be 'Y' at Row " + (intRowCtr + 1) + " ");
                            blnValidRow = false;
                        }

                    }
                    
                    // Validation Starts
                    if ("".equals(strModuleNameSeqId.trim()))
                    {
                        arrLstError.add("Engine Module Seq Id not found at Row " + (intRowCtr + 1));
                        blnValidRow = false;
                    }
                    if ("".equals(strModuleName.trim()))
                    {
                        arrLstError.add("Engine Module not found at Row " + (intRowCtr + 1));
                        blnValidRow = false;
                    }
                    if ("".equals(strCompCode.trim()))
                    {
                        arrLstError.add("Component Code not found at Row " + (intRowCtr + 1));
                        blnValidRow = false;
                    }
                    if ("".equals(strCompDesc.trim()))
                    {
                        arrLstError.add("Component Description not found for " + strCompCode + " at Row " + (intRowCtr + 1));
                        blnValidRow = false;
                    }
                    if ("".equals(strLocationID.trim()))
                    {
                        arrLstError.add("Location ID not found at Row " + (intRowCtr + 1));
                        blnValidRow = false;
                    }
                    if ("".equals(strLocationName.trim()))
                    {
                        arrLstError.add("Location Name not found at Row " + (intRowCtr + 1));
                        blnValidRow = false;
                    }
                    if ("".equals(strPrimaryInd.trim()))
                    {
                        arrLstError.add("Primary Site not found at Row " + (intRowCtr + 1));
                        blnValidRow = false;
                    }
                    if ("Y".equalsIgnoreCase(strPrimaryInd.trim()) || "N".equalsIgnoreCase(strPrimaryInd.trim()) )
                    {
                    }
                    else {
                        arrLstError.add("Primary Site has Invalid Character at Row " + (intRowCtr + 1)+". (Y/N) only allowed Character");
                        blnValidRow = false;
                    }
                    
                    if ("".equals(strHiddenInd.trim()))
                    {
                        arrLstError.add("Hidden Site not found at Row " + (intRowCtr + 1));
                        blnValidRow = false;
                    }
                    if ("Y".equalsIgnoreCase(strHiddenInd.trim()) || "N".equalsIgnoreCase(strHiddenInd.trim()) )
                    {
                    }
                    else {
                        arrLstError.add("Hidden Site has Invalid Character at Row " + (intRowCtr + 1)+". (Y/N) only allowed Character");
                        blnValidRow = false;
                    }
                    
                    if ("".equals(strDeleteInd.trim()))
                    {
                        arrLstError.add("Delete Site not found at Row " + (intRowCtr + 1));
                        blnValidRow = false;
                    }
                    if ("Y".equalsIgnoreCase(strDeleteInd.trim()) || "N".equalsIgnoreCase(strDeleteInd.trim()) )
                    {
                    }
                    else {
                        arrLstError.add("Delete Site has Invalid Character at Row " + (intRowCtr + 1)+". (Y/N) only allowed Character");
                        blnValidRow = false;
                    }
                    
                    
                    /**
					 * This Loop will try to check whether for a perticular
					 * Module SeqID and Component Code and Location Id
					 * Combination is present for multiple sites
					 * 
					 */
                    if(hmDupLocChecker.containsValue(strModuleNameSeqId+strModuleName+strCompCode+strCompDesc+strLocationID)) {
                        arrLstError.add("Component Code "+strCompCode+" has duplicate Locations at Row Number " + (intRowCtr + 1));
                    }
                    else {
                        hmDupLocChecker.put((++intLocSequence)+strModuleNameSeqId+strModuleName+strCompCode,
                                strModuleNameSeqId+strModuleName+strCompCode+strCompDesc+strLocationID);
                    }
                  
                    /**
					 * This Loop will try to check whether for a perticular
					 * Module SeqID and Component Code Combination is multiple
					 * Primary Site Ind Set to = 'Y' if so then raise Error
					 */
                    
                    if("Y".equalsIgnoreCase(strPrimaryInd)) {
                        if(hmPrimesiteChecker.containsValue(strModuleNameSeqId+strModuleName+strCompCode+strCompDesc+strPrimaryInd)) {
                            arrLstError.add("Component Code "+strCompCode+" has multiple Primary Sites at Row Number " + (intRowCtr + 1));
                        }
                        else {
                            hmPrimesiteChecker.put(strModuleNameSeqId+strModuleName+strCompCode,
                                    strModuleNameSeqId+strModuleName+strCompCode+strCompDesc+strPrimaryInd);
                        }
                    }

                    // After Validating all fields..append it to String buffer
                    // Each column is appened with "^"
                    strBuffEachRow.append((intRowCtr + 1) + "^");
                    strBuffEachRow.append(strModuleNameSeqId + "^"); 
                    strBuffEachRow.append(strModuleName + "^");
                    strBuffEachRow.append(strCompCode + "^");
                    strBuffEachRow.append(strCompDesc + "^");
                    strBuffEachRow.append(strLocationID + "^");
                    strBuffEachRow.append(strLocationName + "^");
                    strBuffEachRow.append(strPrimaryInd + "^");
                    strBuffEachRow.append(strHiddenInd + "^");
                    strBuffEachRow.append(strDeleteInd + "^");
                    strBuffEachRow.append("^|"); // After end of a Row "|" is appended
                    
                    strModuleNameSeqId  = null; 
                    strModuleName       = null; 
                    strCompCode         = null; 
                    strCompDesc         = null;
                    strLocationID       = null;
                    strLocationName     = null;
                    strPrimaryInd       = null;
                    strHiddenInd        = null;
                    strDeleteInd        = null;
                                       
                    // Check for buffer size
                    if (strBuffEachElement.length() + strBuffEachRow.length() > 4000)
                    {
                        arrlstBuffs.add(strBuffEachElement);
                        strBuffEachElement = null;
                        strBuffEachElement = new StringBuffer();
                    }

                    /*
					 * If row do not have any errors then add row to element
					 * else do not add that row
					 */
                    if (blnValidRow)
                    {
                        strBuffEachElement.append(strBuffEachRow.toString());
                        strBuffEachRow =  null;
                        strBuffEachRow = new StringBuffer();
                    }

                    // if its a last row then append Buffer to array
                    if (intRowCtr == intNoOfRows)
                    {
                        arrlstBuffs.add(strBuffEachElement);
                        strBuffEachElement = null;
                        strBuffEachElement = new StringBuffer();
                    }
                }
            }
        }
        finally
        {
            strBuffEachRow = null;
            // strBuffEachComp = null;
            strBuffEachElement = null;
        }
        return arrlstBuffs;
    }
 
  //Changes made for Office 2010.End
    /* END readComponentSheet2010() */   

    
    
    /**
	 * Method name: readMappingSheet 
	 * Brief logic: This Read all columns uploaded with component details and validates. 
	 * 				Used for upload functionality of eCRDBatchDownloadUploadMapping.
	 * @author	: Patni Team
	 * @version : 1.0
	 * @param 	: GEAESheet sheet,String strSiteName
	 * @return  : ArrayList
	 * @since JDK1.4
	 */
    private ArrayList readMappingSheet(GEAESheet sheet,String strSiteName) throws Exception
    {	System.out.println("Inside read mapping sheet method---");
    	int intNoOfRows = 0;
        int intNoOfCols = 0;
        int intCellDataType;					//Changes made for Office 2010.
        GEAERow row = null;
        GEAEExcelCell cell = null;
        ArrayList arrlstBuffs = null;
     
        
        StringBuffer strBuffEachRow = null;
        StringBuffer strBuffEachElement = null;
        StringBuffer strBuffTestBlankRow = null;
       
        String[] strArrEachRow = null;
        String strEachCellValue = "";

        boolean blnValidRow = true;

        String strModelName   		= "";   //  Model Name
        String strModuleName        = "";   //  Module Name
        String strCompCode          = "";   //  Component Code
        String strCompDesc          = "";   //  Component Description
        String strSite 		        = "";   //  Location Name
        String strOSBCode           = "";   //  OSB Component Code
        String strMappingDate    	= "";   //	Mapping Last Update Date
        String strActiveInd         = "";   //  Mapping Active Ind 
                
        try
        {
           intNoOfRows = sheet.getLastRowNum();
                       
           if (!verifySheetMappingHeaders(sheet.getRow((short) 0),strSiteName))
            {
        	   arrLstError.add("Excel Sheet has Invalid headers");
                return new ArrayList();
            }
           
           if(intNoOfRows == 0)
           {
        	   arrLstError.add("Excel Sheet does not have proper data to upload");
               return new ArrayList();
           }
           
          // if(intNoOfRows >=5000)
           if(intNoOfRows >=3000)
           {
        	   arrLstError.add("Exceeded the maximum number of row limit.");
               return new ArrayList();
           }
           
           arrlstBuffs = new ArrayList();
           strBuffEachElement = new StringBuffer();
           
            //Loop to fetch records from Each excel row    
            for (int intRowCtr = 1; intRowCtr <= intNoOfRows; intRowCtr++)
            {
            	strBuffEachRow = new StringBuffer();
                row = sheet.getRow((short) intRowCtr);
                try
                {
                    intNoOfCols = (int) row.getLastCellNum();
                }
                catch (NullPointerException nullptrExp)
                {
                    intNoOfCols = 0;
                }
                if (intNoOfCols < 0)
                {
                    strArrEachRow = new String[1];
                }
                else
                {
                    strArrEachRow = new String[intNoOfCols];
                }
                strBuffTestBlankRow = new StringBuffer();
 
                // Start :: loop to fetch cell values from each column  
                for (int intColCtr = 0; intColCtr < intNoOfCols; intColCtr++)
                {   
               		try
	                    {
               				strEachCellValue = "";
               				cell = (GEAEExcelCell) row.getCell((short) intColCtr);
               				System.out.println("value is"+cell.getCellType());
	                        if(cell.getCellType() == 1)
	                        {	
		                        strEachCellValue = cell.getStringCellValue();
		                        System.out.println("In If 1"+strEachCellValue);
	                        }
	                        if(cell.getCellType() == 0)
	                        {	
		                        strEachCellValue = cell.getNumericCellValue() + "";
		                        System.out.println("In If 0"+strEachCellValue);
	                        }
	                    }
	                    catch (NumberFormatException numformExp)
	                    {
	                        int intCellValue = 0;
	                        intCellValue = (int)cell.getNumericCellValue();
	                        strEachCellValue = intCellValue+"";
	                        System.out.println("In catch for Cell data type 0"+strEachCellValue);
	                    }
	                    catch (NullPointerException nullptrExp)
	                    {
	                        strEachCellValue = "";
	                    }
	                    finally
	                    {
	                        // store each cell value in String array
	                        strArrEachRow[intColCtr] = strEachCellValue;
	                        strBuffTestBlankRow.append(strEachCellValue + "^");
	                    }
              } 
                
                strModelName	   = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 0), 20,eCRDConstants.STRMODEL, "" + (intRowCtr + 1));
                strModuleName      = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 1), 20,eCRDConstants.STRMODULE, "" + (intRowCtr + 1));
                strCompCode        = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 2), 20, eCRDConstants.STRCOMCODE, "" + (intRowCtr + 1));
                strCompDesc        = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 3), 200,eCRDConstants.STRCOMDESC, "" + (intRowCtr + 1));
                strSite		       = isGreaterThanMaxLength(returnArrValue(strArrEachRow,4), 30, eCRDConstants.STRCSITE, "" + (intRowCtr + 1));
                strOSBCode         = isGreaterThanMaxLength(returnArrValue(strArrEachRow,5), 4,eCRDConstants.STROSBCODE, "" + (intRowCtr + 1));
                strMappingDate     = isGreaterThanMaxLength(returnArrValue(strArrEachRow,6), 10,eCRDConstants.STRLASTUPDATE, "" + (intRowCtr + 1));
                strActiveInd       = isGreaterThanMaxLength(returnArrValue(strArrEachRow,7), 5, eCRDConstants.STRACTIVEID, "" + (intRowCtr + 1));

                blnValidRow = true;
                    
                    
                // Validation Starts
                /* If OSB_Component and Active_Indicator are blank, then blocking such records from front end. */
                if ("".equals(strOSBCode.trim())&& "".equals(strActiveInd.trim())){
                	blnValidRow = false;
                }
                 
                  /* If OSB_Component has a value, but Active_Indicator is blank, then assigning "Y" value in Active_Indicator field.*/ 
                   if (!"".equals(strOSBCode.trim()))
                   {
                	   if("".equals(strActiveInd.trim()))
                       {
                		   strActiveInd = "Y";
                           blnValidRow = true;
                       }
                   } 
                    
                    /* After Validating all fields..append it to String buffer.
                     * Each column is appened with "^" */
                    strBuffEachRow.append((intRowCtr + 1) + "^");
                    strBuffEachRow.append(strModelName + "^"); 
                    strBuffEachRow.append(strModuleName + "^");
                    strBuffEachRow.append(strCompCode + "^");
                    strBuffEachRow.append(strCompDesc + "^");
                    strBuffEachRow.append(strSite + "^");
                    strBuffEachRow.append(strOSBCode + "^");
                    strBuffEachRow.append(strMappingDate + "^");
                    strBuffEachRow.append(strActiveInd + "^");
                    strBuffEachRow.append("|"); // After end of a Row "|" is appended
                    
                   /* Clearing the variables */
                    strModelName = null; 
                    strModuleName = null;
                    strCompCode = null; 
                    strCompDesc = null;
                    strSite = null;
                    strOSBCode = null;
                    strMappingDate = null;
                    strActiveInd = null;
                                       
                    //Check for buffer size
                    /*if (strBuffEachElement.length() + strBuffEachRow.length() > 6000)
                    {
                        arrlstBuffs.add(strBuffEachElement);
                        System.out.println("strBuffEachElement--->" + strBuffEachElement);
                        strBuffEachElement = null;
                        strBuffEachElement = new StringBuffer();
                    }*/

                    /*If row do not have any errors then add row to element else do not add that row */
                    if (blnValidRow)
                    {
                        strBuffEachElement.append(strBuffEachRow.toString());
                        strBuffEachRow =  null;
                        strBuffEachRow = new StringBuffer();
                    }

                    // if its a last row then append Buffer to array
                     if (intRowCtr == intNoOfRows)
                    {
                        arrlstBuffs.add(strBuffEachElement);
                        strBuffEachElement = null;
                        strBuffEachElement = new StringBuffer();
                    }
                }
        }
        finally
        {
            strBuffEachRow = null;
            strBuffEachElement = null;
            sheet = null;
        }
        return arrlstBuffs;
    }
/* END readMappingSheet() */

    
    /**
	 * Method name: readMappingSheet2010
	 * Brief logic: This Read all columns uploaded with component details and validates. 
	 * 				Used for upload functionality of eCRDBatchDownloadUploadMapping for XLSX files.
	 * @author	: Patni Team
	 * @version : 1.0
	 * @param 	: GEAESheet sheet,String strSiteName
	 * @return  : ArrayList
	 * @since JDK1.4
	 */
    
  //Changes made for Office 2010.Start
    
    private ArrayList readMappingSheet2010(GEAESheet2010 sheet2010,String strSiteName) throws Exception
    {	System.out.println("Inside read mapping sheet 2010 method---");
    	int intNoOfRows = 0;
        int intNoOfCols = 0;
        int intCellDataType;					//Changes made for Office 2010.

        GEAERow2010 row = null;
        GEAEExcelCell2010 cell = null;
        ArrayList arrlstBuffs = null;
     
        
        StringBuffer strBuffEachRow = null;
        StringBuffer strBuffEachElement = null;
        StringBuffer strBuffTestBlankRow = null;
       
        String[] strArrEachRow = null;
        String strEachCellValue = "";

        boolean blnValidRow = true;

        String strModelName   		= "";   //  Model Name
        String strModuleName        = "";   //  Module Name
        String strCompCode          = "";   //  Component Code
        String strCompDesc          = "";   //  Component Description
        String strSite 		        = "";   //  Location Name
        String strOSBCode           = "";   //  OSB Component Code
        String strMappingDate    	= "";   //	Mapping Last Update Date
        String strActiveInd         = "";   //  Mapping Active Ind 
                
        try
        {
           intNoOfRows = sheet2010.getLastRowNum();
           System.out.println("I am here 1");      
           if (!verifySheetMappingHeaders2010(sheet2010.getRow((short) 0),strSiteName))
            {System.out.println("I am here 2");  
        	   arrLstError.add("Excel Sheet has Invalid headers");
                return new ArrayList();
            }
           System.out.println("I am here 3");  
           if(intNoOfRows == 0)
           {
        	   arrLstError.add("Excel Sheet does not have proper data to upload");
               return new ArrayList();
           }
           System.out.println("I am here 4");  
          // if(intNoOfRows >=5000)
           if(intNoOfRows >=3000)
           {
        	   arrLstError.add("Exceeded the maximum number of row limit.");
               return new ArrayList();
           }
           
           arrlstBuffs = new ArrayList();
           strBuffEachElement = new StringBuffer();
           System.out.println("I am here 5");  
            //Loop to fetch records from Each excel row    
            for (int intRowCtr = 1; intRowCtr <= intNoOfRows; intRowCtr++)
            {
            	strBuffEachRow = new StringBuffer();
                row = sheet2010.getRow((short) intRowCtr);
                try
                {System.out.println("I am here 6");  
                    intNoOfCols = (int) row.getLastCellNum();
                    System.out.println("I am here 7, no of columns = "+intNoOfCols);   
                }
                catch (NullPointerException nullptrExp)
                { 
                    intNoOfCols = 0;
                }
                if (intNoOfCols < 0)
                {
                    strArrEachRow = new String[1];
                }
                else
                {System.out.println("I am here 8- In else"); 
                    strArrEachRow = new String[intNoOfCols];
                }
                strBuffTestBlankRow = new StringBuffer();
                                
                // Start :: loop to fetch cell values from each column  
                for (int intColCtr = 0; intColCtr < intNoOfCols; intColCtr++)
                {   
                    	try
                        {
 	                    		strEachCellValue = "";
		                        cell = (GEAEExcelCell2010) row.getCell((short) intColCtr);
		                        System.out.println("value is"+cell.getCellType());
		                        
		                        if(cell.getCellType() == 1)
		                        {
		                        	strEachCellValue = cell.getStringCellValue();
		                        	System.out.println("In If for 1---"+strEachCellValue);
		                        }
		                        if(cell.getCellType() == 0)
		                        {
		                        	strEachCellValue = cell.getNumericCellValue() + "";
		                        	System.out.println("In If for 0---"+strEachCellValue);
		                        }
                        }
	                    catch (NumberFormatException numformExp)
	                    {
	                        int intCellValue = 0;
	                        intCellValue = (int)cell.getNumericCellValue();
	                        strEachCellValue = intCellValue+"";
	                        System.out.println("In catch for Cell data type 0"+strEachCellValue);
	                    }
	                    catch (NullPointerException nullptrExp)
	                    {
	                        strEachCellValue = "";
	                    }
	                    finally
	                    {
	                        // store each cell value in String array
	                        strArrEachRow[intColCtr] = strEachCellValue;
	                        strBuffTestBlankRow.append(strEachCellValue + "^");
	                    }      
                }
                
                strModelName	   = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 0), 20,eCRDConstants.STRMODEL, "" + (intRowCtr + 1));
                strModuleName      = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 1), 20,eCRDConstants.STRMODULE, "" + (intRowCtr + 1));
                strCompCode        = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 2), 20, eCRDConstants.STRCOMCODE, "" + (intRowCtr + 1));
                strCompDesc        = isGreaterThanMaxLength(returnArrValue(strArrEachRow, 3), 200,eCRDConstants.STRCOMDESC, "" + (intRowCtr + 1));
                strSite		       = isGreaterThanMaxLength(returnArrValue(strArrEachRow,4), 30, eCRDConstants.STRCSITE, "" + (intRowCtr + 1));
                strOSBCode         = isGreaterThanMaxLength(returnArrValue(strArrEachRow,5), 4,eCRDConstants.STROSBCODE, "" + (intRowCtr + 1));
                strMappingDate     = isGreaterThanMaxLength(returnArrValue(strArrEachRow,6), 10,eCRDConstants.STRLASTUPDATE, "" + (intRowCtr + 1));
                strActiveInd       = isGreaterThanMaxLength(returnArrValue(strArrEachRow,7), 5, eCRDConstants.STRACTIVEID, "" + (intRowCtr + 1));

                blnValidRow = true;
                    
                    
                // Validation Starts
                /* If OSB_Component and Active_Indicator are blank, then blocking such records from front end. */
                if ("".equals(strOSBCode.trim())&& "".equals(strActiveInd.trim())){
                	blnValidRow = false;
                }
                 
                  /* If OSB_Component has a value, but Active_Indicator is blank, then assigning "Y" value in Active_Indicator field.*/ 
                   if (!"".equals(strOSBCode.trim()))
                   {
                	   if("".equals(strActiveInd.trim()))
                       {
                		   strActiveInd = "Y";
                           blnValidRow = true;
                       }
                   } 
                    
                    /* After Validating all fields..append it to String buffer.
                     * Each column is appened with "^" */
                    strBuffEachRow.append((intRowCtr + 1) + "^");
                    strBuffEachRow.append(strModelName + "^"); 
                    strBuffEachRow.append(strModuleName + "^");
                    strBuffEachRow.append(strCompCode + "^");
                    strBuffEachRow.append(strCompDesc + "^");
                    strBuffEachRow.append(strSite + "^");
                    strBuffEachRow.append(strOSBCode + "^");
                    strBuffEachRow.append(strMappingDate + "^");
                    strBuffEachRow.append(strActiveInd + "^");
                    strBuffEachRow.append("|"); // After end of a Row "|" is appended
                    
                   /* Clearing the variables */
                    strModelName = null; 
                    strModuleName = null;
                    strCompCode = null; 
                    strCompDesc = null;
                    strSite = null;
                    strOSBCode = null;
                    strMappingDate = null;
                    strActiveInd = null;
                                       
                    //Check for buffer size
                    /*if (strBuffEachElement.length() + strBuffEachRow.length() > 6000)
                    {
                        arrlstBuffs.add(strBuffEachElement);
                        System.out.println("strBuffEachElement--->" + strBuffEachElement);
                        strBuffEachElement = null;
                        strBuffEachElement = new StringBuffer();
                    }*/

                    /*If row do not have any errors then add row to element else do not add that row */
                    if (blnValidRow)
                    {
                        strBuffEachElement.append(strBuffEachRow.toString());
                        strBuffEachRow =  null;
                        strBuffEachRow = new StringBuffer();
                    }

                    // if its a last row then append Buffer to array
                     if (intRowCtr == intNoOfRows)
                    {
                        arrlstBuffs.add(strBuffEachElement);
                        strBuffEachElement = null;
                        strBuffEachElement = new StringBuffer();
                    }
                }
        }
        finally
        {
            strBuffEachRow = null;
            strBuffEachElement = null;
            sheet2010 = null;
        }
        return arrlstBuffs;
    }
  //Changes made for Office 2010.End
    /* END readMappingSheet2010() */

    public static String getDateTimeFolder() throws Exception
    {
        Date dtToday = null;
        Date date = null;
        String strUploadDate = "";
        String strTime = "";
        String strOutHour = "";
        String strOutYear = "";
        String strOutMonth = "";
        String strOutDay = "";
        String strOutMinute = "";
        String strOutSecond = "";
        SimpleDateFormat sdtFormatDB = null;

        try
        {
            dtToday = new Date();
            strUploadDate = "" + dtToday;
            SimpleDateFormat sdtFormat = new SimpleDateFormat("EEE MMM dd hh:mm:ss z yyyy");

            date = sdtFormat.parse(strUploadDate);
            sdtFormatDB = new SimpleDateFormat("dd");
            strOutDay = sdtFormatDB.format(date);

            sdtFormatDB = new SimpleDateFormat("MM");
            strOutMonth = sdtFormatDB.format(date);

            sdtFormatDB = new SimpleDateFormat("yyyy");
            strOutYear = sdtFormatDB.format(date);

            sdtFormatDB = new SimpleDateFormat("hh");
            strOutHour = sdtFormatDB.format(date);

            sdtFormatDB = new SimpleDateFormat("mm");
            strOutMinute = sdtFormatDB.format(date);

            sdtFormatDB = new SimpleDateFormat("ss");
            strOutSecond = sdtFormatDB.format(date);

            strTime = strOutDay + "_" + strOutMonth + "_" + strOutYear + "_" + strOutHour + "_" + strOutMinute + "_" + strOutSecond;

            return strTime;
        }
        finally
        {
            dtToday = null;
            date = null;
            strUploadDate = null;
            strTime = null;
            strOutHour = null;
            strOutYear = null;
            strOutMonth = null;
            strOutDay = null;
            strOutMinute = null;
            strOutSecond = null;
            sdtFormatDB = null;
        }
    }
    /**
	 * Method name: verifySheetCompHeaders Brief logic: This method will Upload
	 * Excel sheet with Component details.
	 * 
	 * @author Patni Team
	 * @version 1.0
	 * @param
	 * @return
	 * @since JDK1.4
	 */
    private boolean verifySheetCompHeaders(GEAERow row,String strSiteName) throws Exception
    {   System.out.println("Inside verify sheet comp headers method---");
        GEAEExcelCell cell = null;
        int colNo = 0;
        boolean blnCorrectFormat = true;
        
       try
        {
           // To Validate First Column Engine Module Seq Id
           cell = null;
           cell = (GEAEExcelCell) row.getCell((short) 0);
           
           if (!(eCRDConstants.STRMODULESEQID).equalsIgnoreCase(cell.getStringCellValue().trim()))
           {
               blnCorrectFormat = false;
           }
           // To Validate Second Column Engine Module
           cell = null;
           cell = (GEAEExcelCell) row.getCell((short) 1);
            if (!(eCRDConstants.STRMODULENAME).equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
                
                blnCorrectFormat = false;
            }
            // To Validate Third Column Component Code
            cell = null;
            cell = (GEAEExcelCell) row.getCell((short) 2);
            if (!(eCRDConstants.STRCOMPCODE).equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
                blnCorrectFormat = false;
            }
            // To Validate Fourth Column Component Description
            cell = null;
            cell = (GEAEExcelCell) row.getCell((short) 3);
            if (!(eCRDConstants.STRCOMPDESC).equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
                
                blnCorrectFormat = false;
            }  
           // To Validate Fifth Column Location Id
           cell = null;
           cell = (GEAEExcelCell) row.getCell((short) 4);
           if (!(eCRDConstants.STRLOCATIONID).equalsIgnoreCase(cell.getStringCellValue().trim()))
           {
               blnCorrectFormat = false;
           }
           // To Validate Sixth Column Location Name
           cell = null;
           cell = (GEAEExcelCell) row.getCell((short) 5);
           if (!(eCRDConstants.STRLOCATIONNAME).equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
               
                blnCorrectFormat = false;
            }
           // To Validate Seventh Column Primary Site (Y/N)
            cell = null;
            cell = (GEAEExcelCell) row.getCell((short) 6);
            if (!(eCRDConstants.STRPRIMARYSITE).equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
               
                blnCorrectFormat = false;
            }
            // To Validate Eigth Column Hidden Site (Y/N)
            cell = null;
            cell = (GEAEExcelCell) row.getCell((short) 7);
            if (!(eCRDConstants.STRHIDDENSITE).equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
               
                blnCorrectFormat = false;
            }
            // To Validate Nineth Column Delete Site (Y/N)
            cell = null;
            cell = (GEAEExcelCell) row.getCell((short) 8);
            if (!(eCRDConstants.STRDELETESITE).equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
               
                blnCorrectFormat = false;
            }
       }
        catch (NumberFormatException numforExp)
        {

            
           blnCorrectFormat = false;
        }
        catch (NullPointerException nullptrExp)
        {
           
            blnCorrectFormat = false;
        }
        catch (GEAEOfficeException geaeOfficeExp)
        {
           
            blnCorrectFormat = false;
        }
        finally
        {
            cell = null;
        }
        

        return blnCorrectFormat;
    }

    /**
	 * Method name: verifySheetCompHeaders2010 Brief logic: This method will Upload
	 * Excel sheet with Component details for XLSX files.
	 * 
	 * @author Patni Team
	 * @version 1.0
	 * @param
	 * @return
	 * @since JDK1.4
	 */
    
  //Changes made for Office 2010.Start
    
    private boolean verifySheetCompHeaders2010(GEAERow2010 row,String strSiteName) throws Exception
    {   System.out.println("Inside verify sheet comp headers 2010 method---");
        GEAEExcelCell2010 cell = null;
        int colNo = 0;
        boolean blnCorrectFormat = true;
        
       try
        {
           // To Validate First Column Engine Module Seq Id
           cell = null;
           cell = (GEAEExcelCell2010) row.getCell((short) 0);
           
           if (!(eCRDConstants.STRMODULESEQID).equalsIgnoreCase(cell.getStringCellValue().trim()))
           {
               blnCorrectFormat = false;
           }
           // To Validate Second Column Engine Module
           cell = null;
           cell = (GEAEExcelCell2010) row.getCell((short) 1);
            if (!(eCRDConstants.STRMODULENAME).equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
                
                blnCorrectFormat = false;
            }
            // To Validate Third Column Component Code
            cell = null;
            cell = (GEAEExcelCell2010) row.getCell((short) 2);
            if (!(eCRDConstants.STRCOMPCODE).equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
                blnCorrectFormat = false;
            }
            // To Validate Fourth Column Component Description
            cell = null;
            cell = (GEAEExcelCell2010) row.getCell((short) 3);
            if (!(eCRDConstants.STRCOMPDESC).equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
                
                blnCorrectFormat = false;
            }  
           // To Validate Fifth Column Location Id
           cell = null;
           cell = (GEAEExcelCell2010) row.getCell((short) 4);
           if (!(eCRDConstants.STRLOCATIONID).equalsIgnoreCase(cell.getStringCellValue().trim()))
           {
               blnCorrectFormat = false;
           }
           // To Validate Sixth Column Location Name
           cell = null;
           cell = (GEAEExcelCell2010) row.getCell((short) 5);
           if (!(eCRDConstants.STRLOCATIONNAME).equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
               
                blnCorrectFormat = false;
            }
           // To Validate Seventh Column Primary Site (Y/N)
            cell = null;
            cell = (GEAEExcelCell2010) row.getCell((short) 6);
            if (!(eCRDConstants.STRPRIMARYSITE).equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
               
                blnCorrectFormat = false;
            }
            // To Validate Eigth Column Hidden Site (Y/N)
            cell = null;
            cell = (GEAEExcelCell2010) row.getCell((short) 7);
            if (!(eCRDConstants.STRHIDDENSITE).equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
               
                blnCorrectFormat = false;
            }
            // To Validate Nineth Column Delete Site (Y/N)
            cell = null;
            cell = (GEAEExcelCell2010) row.getCell((short) 8);
            if (!(eCRDConstants.STRDELETESITE).equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
               
                blnCorrectFormat = false;
            }
       }
        catch (NumberFormatException numforExp)
        {

            
           blnCorrectFormat = false;
        }
        catch (NullPointerException nullptrExp)
        {
           
            blnCorrectFormat = false;
        }
        catch (GEAEOfficeException geaeOfficeExp)
        {
           
            blnCorrectFormat = false;
        }
        finally
        {
            cell = null;
        }
        

        return blnCorrectFormat;
    }
  //Changes made for Office 2010.End
    
    // 9292 eCRDBatchDownloadUploadMapping on Feb 2008
    /**
	 * Method name: verifySheetMappingHeaders 
	 * Brief logic: This method will Upload Excel sheet with Component Mapping details.
	 * 
	 * @author	:  Patni Team
	 * @version	:  1.0
	 * @param   :  GEAERow row,String strSiteName
	 * @return  :  boolean
	 * @since JDK1.4
	 */
    private boolean verifySheetMappingHeaders(GEAERow row,String strSiteName) throws Exception
    {  System.out.println("Inside verify sheet mapping headers method---");      
       GEAEExcelCell cell = null;
       boolean blnCorrectFormat = true;
       
       try
        {
    	   // To Validate First Column Engine Model
           cell = null;
           cell = (GEAEExcelCell) row.getCell((short) 0);
           if (!(eCRDConstants.STRMODEL).equalsIgnoreCase(cell.getStringCellValue().trim()))
           {
               blnCorrectFormat = false;
           }
           // To Validate Second Column Engine Module
           cell = null;
           cell = (GEAEExcelCell) row.getCell((short) 1);
            if (!(eCRDConstants.STRMODULE).equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
                blnCorrectFormat = false;
            }
            // To Validate Third Column Component Code
            cell = null;
            cell = (GEAEExcelCell) row.getCell((short) 2);
            if (!(eCRDConstants.STRCOMCODE).equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
                blnCorrectFormat = false;
            }
            // To Validate Fourth Column Component Description
            cell = null;
            cell = (GEAEExcelCell) row.getCell((short) 3);
            if (!(eCRDConstants.STRCOMDESC).equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
                blnCorrectFormat = false;
            }  
            
            // To Validate Sixth Column Site
            cell = null;
            cell = (GEAEExcelCell) row.getCell((short) 4);
            if (!(eCRDConstants.STRCSITE).equalsIgnoreCase(cell.getStringCellValue().trim()))
             {
                 blnCorrectFormat = false;
             }
            
           // To Validate Fifth Column OSB COmponent
           cell = null;
           cell = (GEAEExcelCell) row.getCell((short) 5);
           if (!(eCRDConstants.STROSBCODE).equalsIgnoreCase(cell.getStringCellValue().trim()))
           {
               blnCorrectFormat = false;
           }
           
           // To Validate Seventh Column Last updated Date
            cell = null;
            cell = (GEAEExcelCell) row.getCell((short) 6);
            if (!(eCRDConstants.STRLASTUPDATE).equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
                blnCorrectFormat = false;
            }
            // To Validate Eigth Column Active indicator
            cell = null;
            cell = (GEAEExcelCell) row.getCell((short) 7);
            if (!(eCRDConstants.STRACTIVEID).equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
                blnCorrectFormat = false;
            }
            
            /* Excel contains No Data Found for the Search Criteria */
            cell = null;
            cell = (GEAEExcelCell) row.getCell((short) 0);
            if("No Data Found for the Search Criteria".equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
            	 blnCorrectFormat = true;
            }
       }
        catch (NumberFormatException numforExp)
        {
           blnCorrectFormat = false;
        }
        catch (NullPointerException nullptrExp)
        {
            blnCorrectFormat = false;
        }
        catch (GEAEOfficeException geaeOfficeExp)
        {
            blnCorrectFormat = false;
        }
        finally
        {
            cell = null;
        }
        return blnCorrectFormat;
    }
 /* END verifySheetMappingHeaders() */  
    
    /**
	 * Method name: verifySheetMappingHeaders2010
	 * Brief logic: This method will Upload Excel sheet with Component Mapping details for XLSX files.
	 * 
	 * @author	:  Patni Team
	 * @version	:  1.0
	 * @param   :  GEAERow row,String strSiteName
	 * @return  :  boolean
	 * @since JDK1.4
	 */
    
  //Changes made for Office 2010.Start
    
    private boolean verifySheetMappingHeaders2010(GEAERow2010 row,String strSiteName) throws Exception
    {  System.out.println("Inside verify sheet mapping headers 2010 method---");      
       GEAEExcelCell2010 cell = null;
       boolean blnCorrectFormat = true;
       
       try
        {	System.out.println("Here 1----");
    	   // To Validate First Column Engine Model
           cell = null;
           cell = (GEAEExcelCell2010) row.getCell((short) 0);
           if (!(eCRDConstants.STRMODEL).equalsIgnoreCase(cell.getStringCellValue().trim()))
           {
               blnCorrectFormat = false;
           }
           // To Validate Second Column Engine Module
           System.out.println("Here 2----");
           cell = null;
           cell = (GEAEExcelCell2010) row.getCell((short) 1);
            if (!(eCRDConstants.STRMODULE).equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
                blnCorrectFormat = false;
            }
            // To Validate Third Column Component Code
            System.out.println("Here 3----");
            cell = null;
            cell = (GEAEExcelCell2010) row.getCell((short) 2);
            if (!(eCRDConstants.STRCOMCODE).equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
                blnCorrectFormat = false;
            }
            // To Validate Fourth Column Component Description
            System.out.println("Here 4----");
            cell = null;
            cell = (GEAEExcelCell2010) row.getCell((short) 3);
            if (!(eCRDConstants.STRCOMDESC).equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
                blnCorrectFormat = false;
            }  
            
            // To Validate Sixth Column Site
            System.out.println("Here 5----");
            cell = null;
            cell = (GEAEExcelCell2010) row.getCell((short) 4);
            if (!(eCRDConstants.STRCSITE).equalsIgnoreCase(cell.getStringCellValue().trim()))
             {
                 blnCorrectFormat = false;
             }
            
           // To Validate Fifth Column OSB COmponent
            System.out.println("Here 6----");
           cell = null;
           cell = (GEAEExcelCell2010) row.getCell((short) 5);
           if (!(eCRDConstants.STROSBCODE).equalsIgnoreCase(cell.getStringCellValue().trim()))
           {
               blnCorrectFormat = false;
           }
           
           // To Validate Seventh Column Last updated Date
           System.out.println("Here 7----"); 
           cell = null;
            cell = (GEAEExcelCell2010) row.getCell((short) 6);
            if (!(eCRDConstants.STRLASTUPDATE).equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
                blnCorrectFormat = false;
            }
            // To Validate Eigth Column Active indicator
            System.out.println("Here 8----");
            cell = null;
            cell = (GEAEExcelCell2010) row.getCell((short) 7);
            if (!(eCRDConstants.STRACTIVEID).equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
                blnCorrectFormat = false;
            }
            
            /* Excel contains No Data Found for the Search Criteria */
            System.out.println("Here 9----");
            cell = null;
            cell = (GEAEExcelCell2010) row.getCell((short) 0);
            if("No Data Found for the Search Criteria".equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
            	 blnCorrectFormat = true;
            }
       }
        catch (NumberFormatException numforExp)
        {
           blnCorrectFormat = false;
        }
        catch (NullPointerException nullptrExp)
        {
            blnCorrectFormat = false;
        }
        catch (GEAEOfficeException geaeOfficeExp)
        {
            blnCorrectFormat = false;
        }
        finally
        {System.out.println("In Finally");
            cell = null;
        }
        return blnCorrectFormat;
    }
 
  //Changes made for Office 2010.End
    /* END verifySheetMappingHeaders2010() */  
    
    /*
	 * Start : Code added by milind on 5 Nov 2004 Function is used to validate
	 * Headers of Excel sheet uploaded
	 */

    private boolean verifySheetHeaders(GEAERow row,String strSiteName) throws Exception
    {  System.out.println("Inside verify sheet headers method---");        
       GEAEExcelCell cell = null;
       int colNo = 0;
       boolean blnCorrectFormat = true;
       try
        {
           /*
			 * Patni 23-Aug-2006 - Included verification for Module Name header -
			 * Begin
			 */
           cell = null;
           cell = (GEAEExcelCell) row.getCell((short) 0);

           if (!"Module Name".equalsIgnoreCase(cell.getStringCellValue().trim()))
           {
               
               blnCorrectFormat = false;
           }
           /*
			 * Patni 23-Aug-2006 - Included verification for Module Name header -
			 * End
			 */
           
           cell = null;
           
           /* Patni 23-Aug-2006 - Rearranged the excel cell number - Begin */
           // cell = (GEAEExcelCell) row.getCell((short) 0);
           cell = (GEAEExcelCell) row.getCell((short) 1);
           /* Patni 23-Aug-2006 - Rearranged the excel cell number - End */

            if (!"Component Description".equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
                
                blnCorrectFormat = false;
            }
            cell = null;
           
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - Begin */
            // cell = (GEAEExcelCell) row.getCell((short) 1);
            cell = (GEAEExcelCell) row.getCell((short) 2);
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - End */
            
            if (!"Component Code".equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
               
                blnCorrectFormat = false;
            }

            cell = null;
            
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - Begin */
            // cell = (GEAEExcelCell) row.getCell((short) 2);
            cell = (GEAEExcelCell) row.getCell((short) 3);
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - End */
            
            if (!"ATA Chapter".equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
                
                blnCorrectFormat = false;
            }
// 08-05-2007 Patni Validating Repair Seq id Header from Excel Begin
           cell = null;
           
           /* Patni 23-Aug-2006 - Rearranged the excel cell number - Begin */
           // cell = (GEAEExcelCell) row.getCell((short) 3);
           cell = (GEAEExcelCell) row.getCell((short) 4);
           /* Patni 23-Aug-2006 - Rearranged the excel cell number - End */
                          
           if (!"Repair Seq id".equalsIgnoreCase(cell.getStringCellValue().trim()))
           {
               
               blnCorrectFormat = false;
           }
// 08-05-2007 Patni Validating Repair Seq id Header from Excel End
           
            cell = null;
            
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - Begin */
            // cell = (GEAEExcelCell) row.getCell((short) 4);
            cell = (GEAEExcelCell) row.getCell((short) 5);
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - End */
                           
            if (!"Repair Reference".equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
               
                blnCorrectFormat = false;
            }

            cell = null;
        
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - Begin */
            // cell = (GEAEExcelCell) row.getCell((short) 5);
            cell = (GEAEExcelCell) row.getCell((short) 6);
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - End */
            
            if (!"Rpr Description".equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
               
                blnCorrectFormat = false;
            }
           
/*
 * cell = null; cell = (GEAEExcelCell) row.getCell((short) 6); if (!"Repair
 * Effective Date".equalsIgnoreCase(cell.getStringCellValue().trim())) {
 * 
 * blnCorrectFormat = false; }
 */
           

           
           
            cell = null;
            
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - Begin */
            // cell = (GEAEExcelCell) row.getCell((short) 6);
            cell = (GEAEExcelCell) row.getCell((short) 7);
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - End */
            
            if (!"Price Type".equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
           
                blnCorrectFormat = false;
            }

            cell = null;
            
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - Begin */
            // cell = (GEAEExcelCell) row.getCell((short) 7);
            cell = (GEAEExcelCell) row.getCell((short) 8);
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - End */
            
            if (!"Rpr Tat".equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
           
                blnCorrectFormat = false;
            }

// 08-05-2007 Patni Validating Incremental TAT indicator Header from Excel Begin
           cell = null;
           
           /* Patni 23-Aug-2006 - Rearranged the excel cell number - Begin */
           // cell = (GEAEExcelCell) row.getCell((short) 8);
           cell = (GEAEExcelCell) row.getCell((short) 9);
           /* Patni 23-Aug-2006 - Rearranged the excel cell number - End */
                           
           if (!"Incremental TAT indicator".equalsIgnoreCase(cell.getStringCellValue().trim()))
           {
           
               blnCorrectFormat = false;
           }
// 08-05-2007 Patni Validating Incremental TAT indicator from Excel End

           
            cell = null;
            
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - Begin */
            // cell = (GEAEExcelCell) row.getCell((short) 9);
            cell = (GEAEExcelCell) row.getCell((short) 10);
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - End */
            
            if (!"Rpr Price".equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
           
                blnCorrectFormat = false;
            }

// 08-05-2007 Patni Validating Incremental Price indicator Header from Excel
// Begin
           cell = null;
           
           /* Patni 23-Aug-2006 - Rearranged the excel cell number - Begin */
           // cell = (GEAEExcelCell) row.getCell((short) 10);
           cell = (GEAEExcelCell) row.getCell((short) 11);
           /* Patni 23-Aug-2006 - Rearranged the excel cell number - End */
                   
           if (!"Incremental Price indicator".equalsIgnoreCase(cell.getStringCellValue().trim()))
           {
           
               blnCorrectFormat = false;
           }
// 08-05-2007 Patni Validating Incremental Price indicator Header from Excel End
           
            cell = null;
            
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - Begin */
            // cell = (GEAEExcelCell) row.getCell((short) 11);
            cell = (GEAEExcelCell) row.getCell((short) 12);
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - End */
            
            if (!"Future TAT".equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
           
                blnCorrectFormat = false;
            }

            cell = null;
            
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - Begin */
            // cell = (GEAEExcelCell) row.getCell((short) 12);
            cell = (GEAEExcelCell) row.getCell((short) 13);
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - End */
            
            if (!"Future Price".equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
           
                blnCorrectFormat = false;
            }

            cell = null;
            
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - Begin */
            // cell = (GEAEExcelCell) row.getCell((short) 13);
            cell = (GEAEExcelCell) row.getCell((short) 14);
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - End */
            
            if (!"Future Effective date".equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
           
                blnCorrectFormat = false;
            }
           
           if(!"ALL".equals(strSiteName))
           {
            cell = null;
            
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - Begin */
            // cell = (GEAEExcelCell) row.getCell((short) 14);
            cell = (GEAEExcelCell) row.getCell((short) 15);
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - End */
                      
           if (!"Labor Hours".equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
            
            
               blnCorrectFormat = false;
            }

           /* Patni 23-Aug-2006 - Commented the below code - Begin */
           // if ("Labor
			// Hours".equalsIgnoreCase(cell.getStringCellValue().trim()) &&
			// strSiteName.equals("ALL"))
           // {
           // blnCorrectFormat = false;
           // }
           /* Patni 23-Aug-2006 - Commented the below code - End */
           
            cell = null;
            
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - Begin */
            // cell = (GEAEExcelCell) row.getCell((short) 15);
            cell = (GEAEExcelCell) row.getCell((short) 16);
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - End */
            
           if (!"Material Cost".equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
           
                blnCorrectFormat = false;
            }
           
           /* Patni 23-Aug-2006 - Commented the below code - Begin */
           // if ("Material
			// Cost".equalsIgnoreCase(cell.getStringCellValue().trim()) &&
			// strSiteName.equals("ALL") )
           // {
           // blnCorrectFormat = false;
           // }
           /* Patni 23-Aug-2006 - Commented the below code - End */
           
      // 07-07-2006 Patni checking retain valueindicator begin
           cell = null;
           
           /* Patni 23-Aug-2006 - Rearranged the excel cell number - Begin */
           // cell = (GEAEExcelCell) row.getCell((short) 16);
           cell = (GEAEExcelCell) row.getCell((short) 17);
           /* Patni 23-Aug-2006 - Rearranged the excel cell number - End */
           
           if (!"Retain Value Indicator".equalsIgnoreCase(cell.getStringCellValue().trim()))
           {
               
               blnCorrectFormat = false;
           }
           
// 07-07-2006 Patni checking retain valueindicator end
        
                      
           /* Patni 25-Aug-2006 - Verifying the header name - Begin */
           cell = (GEAEExcelCell) row.getCell((short) 18);
          
           if (!"Cost Updation Required".equalsIgnoreCase(cell.getStringCellValue().trim()))
           {               
               blnCorrectFormat = false;
           }
           /* Patni 25-Aug-2006 - Verifying the header name - End */
           }
       }
        catch (NumberFormatException numforExp)
        {

            
           blnCorrectFormat = false;
        }
        catch (NullPointerException nullptrExp)
        {
           
            blnCorrectFormat = false;
        }
        catch (GEAEOfficeException geaeOfficeExp)
        {
           
            blnCorrectFormat = false;
        }
        finally
        {
            cell = null;
        }
        

        return blnCorrectFormat;
    }

    
  //Changes made for Office 2010.Start
    
    private boolean verifySheetHeaders2010(GEAERow2010 row,String strSiteName) throws Exception
    {   System.out.println("Inside verify sheet headers 2010 method---");     
       GEAEExcelCell2010 cell = null;
       int colNo = 0;
       boolean blnCorrectFormat = true;
       try
        {
           /*
			 * Patni 23-Aug-2006 - Included verification for Module Name header -
			 * Begin
			 */
           cell = null;
           cell = (GEAEExcelCell2010) row.getCell((short) 0);

           if (!"Module Name".equalsIgnoreCase(cell.getStringCellValue().trim()))
           {
               
               blnCorrectFormat = false;
           }
           /*
			 * Patni 23-Aug-2006 - Included verification for Module Name header -
			 * End
			 */
           
           cell = null;
           
           /* Patni 23-Aug-2006 - Rearranged the excel cell number - Begin */
           // cell = (GEAEExcelCell) row.getCell((short) 0);
           cell = (GEAEExcelCell2010) row.getCell((short) 1);
           /* Patni 23-Aug-2006 - Rearranged the excel cell number - End */

            if (!"Component Description".equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
                
                blnCorrectFormat = false;
            }
            cell = null;
           
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - Begin */
            // cell = (GEAEExcelCell) row.getCell((short) 1);
            cell = (GEAEExcelCell2010) row.getCell((short) 2);
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - End */
            
            if (!"Component Code".equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
               
                blnCorrectFormat = false;
            }

            cell = null;
            
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - Begin */
            // cell = (GEAEExcelCell) row.getCell((short) 2);
            cell = (GEAEExcelCell2010) row.getCell((short) 3);
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - End */
            
            if (!"ATA Chapter".equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
                
                blnCorrectFormat = false;
            }
// 08-05-2007 Patni Validating Repair Seq id Header from Excel Begin
           cell = null;
           
           /* Patni 23-Aug-2006 - Rearranged the excel cell number - Begin */
           // cell = (GEAEExcelCell) row.getCell((short) 3);
           cell = (GEAEExcelCell2010) row.getCell((short) 4);
           /* Patni 23-Aug-2006 - Rearranged the excel cell number - End */
                          
           if (!"Repair Seq id".equalsIgnoreCase(cell.getStringCellValue().trim()))
           {
               
               blnCorrectFormat = false;
           }
// 08-05-2007 Patni Validating Repair Seq id Header from Excel End
           
            cell = null;
            
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - Begin */
            // cell = (GEAEExcelCell) row.getCell((short) 4);
            cell = (GEAEExcelCell2010) row.getCell((short) 5);
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - End */
                           
            if (!"Repair Reference".equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
               
                blnCorrectFormat = false;
            }

            cell = null;
        
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - Begin */
            // cell = (GEAEExcelCell) row.getCell((short) 5);
            cell = (GEAEExcelCell2010) row.getCell((short) 6);
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - End */
            
            if (!"Rpr Description".equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
               
                blnCorrectFormat = false;
            }
           
/*
 * cell = null; cell = (GEAEExcelCell) row.getCell((short) 6); if (!"Repair
 * Effective Date".equalsIgnoreCase(cell.getStringCellValue().trim())) {
 * 
 * blnCorrectFormat = false; }
 */
           

           
           
            cell = null;
            
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - Begin */
            // cell = (GEAEExcelCell) row.getCell((short) 6);
            cell = (GEAEExcelCell2010) row.getCell((short) 7);
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - End */
            
            if (!"Price Type".equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
           
                blnCorrectFormat = false;
            }

            cell = null;
            
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - Begin */
            // cell = (GEAEExcelCell) row.getCell((short) 7);
            cell = (GEAEExcelCell2010) row.getCell((short) 8);
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - End */
            
            if (!"Rpr Tat".equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
           
                blnCorrectFormat = false;
            }

// 08-05-2007 Patni Validating Incremental TAT indicator Header from Excel Begin
           cell = null;
           
           /* Patni 23-Aug-2006 - Rearranged the excel cell number - Begin */
           // cell = (GEAEExcelCell) row.getCell((short) 8);
           cell = (GEAEExcelCell2010) row.getCell((short) 9);
           /* Patni 23-Aug-2006 - Rearranged the excel cell number - End */
                           
           if (!"Incremental TAT indicator".equalsIgnoreCase(cell.getStringCellValue().trim()))
           {
           
               blnCorrectFormat = false;
           }
// 08-05-2007 Patni Validating Incremental TAT indicator from Excel End

           
            cell = null;
            
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - Begin */
            // cell = (GEAEExcelCell) row.getCell((short) 9);
            cell = (GEAEExcelCell2010) row.getCell((short) 10);
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - End */
            
            if (!"Rpr Price".equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
           
                blnCorrectFormat = false;
            }

// 08-05-2007 Patni Validating Incremental Price indicator Header from Excel
// Begin
           cell = null;
           
           /* Patni 23-Aug-2006 - Rearranged the excel cell number - Begin */
           // cell = (GEAEExcelCell) row.getCell((short) 10);
           cell = (GEAEExcelCell2010) row.getCell((short) 11);
           /* Patni 23-Aug-2006 - Rearranged the excel cell number - End */
                   
           if (!"Incremental Price indicator".equalsIgnoreCase(cell.getStringCellValue().trim()))
           {
           
               blnCorrectFormat = false;
           }
// 08-05-2007 Patni Validating Incremental Price indicator Header from Excel End
           
            cell = null;
            
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - Begin */
            // cell = (GEAEExcelCell) row.getCell((short) 11);
            cell = (GEAEExcelCell2010) row.getCell((short) 12);
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - End */
            
            if (!"Future TAT".equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
           
                blnCorrectFormat = false;
            }

            cell = null;
            
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - Begin */
            // cell = (GEAEExcelCell) row.getCell((short) 12);
            cell = (GEAEExcelCell2010) row.getCell((short) 13);
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - End */
            
            if (!"Future Price".equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
           
                blnCorrectFormat = false;
            }

            cell = null;
            
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - Begin */
            // cell = (GEAEExcelCell) row.getCell((short) 13);
            cell = (GEAEExcelCell2010) row.getCell((short) 14);
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - End */
            
            if (!"Future Effective date".equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
           
                blnCorrectFormat = false;
            }
           
           if(!"ALL".equals(strSiteName))
           {
            cell = null;
            
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - Begin */
            // cell = (GEAEExcelCell) row.getCell((short) 14);
            cell = (GEAEExcelCell2010) row.getCell((short) 15);
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - End */
                      
           if (!"Labor Hours".equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
            
            
               blnCorrectFormat = false;
            }

           /* Patni 23-Aug-2006 - Commented the below code - Begin */
           // if ("Labor
			// Hours".equalsIgnoreCase(cell.getStringCellValue().trim()) &&
			// strSiteName.equals("ALL"))
           // {
           // blnCorrectFormat = false;
           // }
           /* Patni 23-Aug-2006 - Commented the below code - End */
           
            cell = null;
            
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - Begin */
            // cell = (GEAEExcelCell) row.getCell((short) 15);
            cell = (GEAEExcelCell2010) row.getCell((short) 16);
            /* Patni 23-Aug-2006 - Rearranged the excel cell number - End */
            
           if (!"Material Cost".equalsIgnoreCase(cell.getStringCellValue().trim()))
            {
           
                blnCorrectFormat = false;
            }
           
           /* Patni 23-Aug-2006 - Commented the below code - Begin */
           // if ("Material
			// Cost".equalsIgnoreCase(cell.getStringCellValue().trim()) &&
			// strSiteName.equals("ALL") )
           // {
           // blnCorrectFormat = false;
           // }
           /* Patni 23-Aug-2006 - Commented the below code - End */
           
      // 07-07-2006 Patni checking retain valueindicator begin
           cell = null;
           
           /* Patni 23-Aug-2006 - Rearranged the excel cell number - Begin */
           // cell = (GEAEExcelCell) row.getCell((short) 16);
           cell = (GEAEExcelCell2010) row.getCell((short) 17);
           /* Patni 23-Aug-2006 - Rearranged the excel cell number - End */
           
           if (!"Retain Value Indicator".equalsIgnoreCase(cell.getStringCellValue().trim()))
           {
               
               blnCorrectFormat = false;
           }
           
// 07-07-2006 Patni checking retain valueindicator end
        
                      
           /* Patni 25-Aug-2006 - Verifying the header name - Begin */
           cell = (GEAEExcelCell2010) row.getCell((short) 18);
          
           if (!"Cost Updation Required".equalsIgnoreCase(cell.getStringCellValue().trim()))
           {               
               blnCorrectFormat = false;
           }
           /* Patni 25-Aug-2006 - Verifying the header name - End */
           }
       }
        catch (NumberFormatException numforExp)
        {

            
           blnCorrectFormat = false;
        }
        catch (NullPointerException nullptrExp)
        {
           
            blnCorrectFormat = false;
        }
        catch (GEAEOfficeException geaeOfficeExp)
        {
           
            blnCorrectFormat = false;
        }
        finally
        {
            cell = null;
        }
        

        return blnCorrectFormat;
    }
  //Changes made for Office 2010.End
    
    /*
	 * End : Code added by milind on 5 Nov 2004 Function is used to validate
	 * Headers of Excel sheet2010 uploaded
	 */
    /**
	 * Method name: saveComponentSheetData Brief logic: This Save sheet details
	 * and upload component details through DB hit.
	 * 
	 * @author Patni Team
	 * @version 1.0
	 * @param
	 * @return
	 * @since JDK1.4
	 */

    private void saveComponentSheetData(ArrayList arrlstBuffs, String strActionID, String strLoggedUser, String strRoleIndicator, String strEngineModel, String strSheetName) throws Exception
    {
        ArrayList arrInParam = new ArrayList();
        ArrayList arrOutParam = new ArrayList();

        // error of each row
        String strError = "";

        String strErrors[] = null;
        StringBuffer strBuff = null;
        // size of buffer array
        int intArrlstSize = 0;

        int intToCompleteDec = 0;
        int intNewSize = 0;
        int intArrIndex = 0;
        int intCount = 0;

        try
        {
            strErrors = new String[15];
            intArrlstSize = arrlstBuffs.size();
            intToCompleteDec = 10 - (intArrlstSize % 10);
            intNewSize = intArrlstSize + intToCompleteDec;
            for (int intCtr = intArrlstSize; intCtr < intNewSize; intCtr++){
                arrlstBuffs.add(new StringBuffer());
            }
            for (int intCtr = 0; intCtr < intNewSize; intCtr++)
            {
                if ((intCtr + 1) % 10 == 0)
                {
                    arrInParam = new ArrayList();
                    arrOutParam = new ArrayList();

                    arrInParam.add(strEngineModel);
                    arrInParam.add(strLoggedUser);
                    //arrInParam.add(strRoleIndicator);
                    arrInParam.add(strSheetName);
                    for (; intCount <= intCtr; intCount++){
                        arrInParam.add((arrlstBuffs.get(intCount)).toString());
                    }
                    intCount = intCtr + 1;
                    arrOutParam = eCRDDBMediator.doDBOperation(strActionID, arrInParam);
                    
                    // collecting the output cursors here.
                    for (int intoutCtr = 0; intoutCtr < 15; intoutCtr++)
                    {
                        strError = (String) arrOutParam.get(intoutCtr);

                        if (strError != null && !"".equals(strError))
                        {
                            strErrors[intArrIndex++] = strError;
                        }
                    }
                    logErrorToObject(strErrors);
                }
            }
        }
        finally{
            strErrors = null;
        }
    }
/* END saveComponentSheetData()  */
    
    
    /**
	 * Method name: saveMappingSheetData 
	 * Brief logic: This Save sheet details  and upload component details through DB hit.
	 * 
	 * @author 	:	Patni Team
	 * @version :	1.0
	 * @param	:	ArrayList arrlstBuffs, String strActionID,String strSite, String strLoggedUser, String userRole, String strEngineModel, String strSheetName
	 * @return	: 	void
	 * @since JDK1.4
	 */

    private void saveMappingSheetData(ArrayList arrlstBuffs, String strActionID,String strSite, String strLoggedUser, String userRole, String strEngineModel, String strSheetName) throws Exception
    {
    	
    	    	
    	ArrayList arrInParam = new ArrayList();
        ArrayList arrOutParam = new ArrayList();
        // error of each row
        String strError = "";
        String strStatusMsg = "";
        String strColDelim = "^";
        String strRowDelim ="|";
        String strErrors[] = null;
        //StringBuffer strErrors = null;
        StringTokenizer strTokError = null;
               
        // size of buffer array
        int intArrlstSize = 0;
        int intArrIndex = 0;
        int intCount = 0;
      
        try {
            strErrors = new String[1600];
            intArrlstSize = arrlstBuffs.size();
       		arrInParam = new ArrayList();
            arrOutParam = new ArrayList();
            String strInput = "";
            //int recCount = 499;
            int recCount = 299;
            
            String inParams = arrlstBuffs.get(0).toString();

            ArrayList arrParams  = new ArrayList();
            int paramIndex = 0;
            
        	if (inParams != null) {// If input is not null.
    			// Seperate values by separator
    			StringTokenizer stringTokens = new StringTokenizer(inParams,"|");

    			while (stringTokens.hasMoreTokens()) { // Looping through tokens
    				arrParams.add(stringTokens.nextToken()); // Add value.
    			}
    		}
        	 
          //  if(arrParams.size()<= 5000){
        	 if(arrParams.size()<= 3000){
	           // if(arrParams.size()<= 500){
        		 if(arrParams.size()<= 300){
	            	for(int count = 0; count < arrParams.size(); count++){
	                	strInput = strInput + arrParams.get(count)+ "|" ;
	            	}
	            	arrInParam.add(strInput);
	            }
	            else{
	            	for(int count = 0; count < arrParams.size(); count++){
	            		strInput = strInput + arrParams.get(count)+ "|" ;
	            		if(count == recCount ){
	            			arrInParam.add(strInput); 
	            			strInput = "";
	            			//recCount = recCount + 500;
	            			recCount = recCount + 300;
	            		}
	            	}
	            }
           int arrParamCount = 10 - arrInParam.size();
            if(arrInParam.size()<10){
            	//for (int i  = 1; i<(10-arrInParam.size());i++){
            	for (int i  = 1; i<= arrParamCount;i++){
            		arrInParam.add("NO DATA");
            	}
            }
            arrInParam.add(strRowDelim.trim());
            arrInParam.add(strColDelim.trim());
            arrInParam.add(strSite.toUpperCase().trim());
            arrInParam.add(strLoggedUser.toUpperCase().trim()); 
            arrInParam.add(userRole.trim());
           

            arrOutParam = eCRDDBMediator.doDBOperation(strActionID, arrInParam);
            intCount = arrInParam.size();
            
            for(int pCount = 0; pCount < 20; pCount++){
            	if(arrOutParam.get(pCount)!= null && !"".equals(arrOutParam.get(pCount)) && !"null".equals(arrOutParam.get(pCount))){
            		strError = strError+(String) arrOutParam.get(pCount);
            	}
            }
            strStatusMsg = (String)arrOutParam.get(20);
            
	           /* Errr msgs */
	            if (strError != null && !"".equals(strError)) {
	            	try{
	            		strTokError = new StringTokenizer(strError,"^");
		            	while (strTokError.hasMoreTokens()) {// Looping through tokens of error
		            		strErrors[intArrIndex++] = strTokError.nextToken(); // Add value to String Array to strErrors
		            		//strErrors.append(strTokError.nextToken()); // Add value.
		        		}
		            	logErrorToObject(strErrors);
	            	}catch(Exception exp){
	            		System.out.println("exp.printStackTrace();");
	            		exp.printStackTrace();
	            		
	            	}
	            }
	            else if (strStatusMsg != null && !"".equals(strStatusMsg)){
	            	try{
	            		/* Status msgs(Success /Unsuccess) */
	            		for(int count = 0; count<= strStatusMsg.length(); count++){ 
	            			strErrors[count] = strStatusMsg;  //(String)arrOutParam.get(1);
	            		}
	            		logErrorToObject(strErrors);
	            	}catch(Exception exp){
	            		System.out.println("exp.printStackTrace();");
	            	}
	            }
            }	//END IF which chechks row size
            else{
            	
            	strErrors[0]="EXCEEDED THE MAXIMUM NUMBER OF ROW LIMIT";
            	logErrorToObject(strErrors);
        	}
            
        }
        finally {
            strErrors = null;
            strStatusMsg = null;
            strTokError = null;
            
        }
    }
/* END saveMappingSheetData() */    
    
/* Starts saveSheetData() */ 
private void saveSheetData(ArrayList arrlstBuffs,String strActionID,String strLoggedUser,String strSiteName,String strSheetName,String strCatSeqID,String strEngModelCD,String strRoleIndicator) throws Exception
    {
        ArrayList arrInParam = new ArrayList();
        ArrayList arrOutParam = new ArrayList();
        // error of each row
        String strError = "";
        String strErrors[] = null;
        StringBuffer strBuff = null;
        // size of buffer array
        int intArrlstSize = 0;
        int intToCompleteDec = 0;
        int intNewSize = 0;
        int intLongIndex = 0;
        int intArrIndex = 0;
        int intCount = 0;

        try
        {
            strErrors = new String[15];
            intArrlstSize = arrlstBuffs.size();
            intToCompleteDec = 10 - (intArrlstSize % 10);
            intNewSize = intArrlstSize + intToCompleteDec;
            for (int intCtr = intArrlstSize; intCtr < intNewSize; intCtr++)
            {
                arrlstBuffs.add(new StringBuffer());
            }
            /* Milind 13Th November 2004 */
            
            for (int intCtr = 0; intCtr < intNewSize; intCtr++)
            {
                if ((intCtr + 1) % 10 == 0)
                {
                    arrInParam = new ArrayList();
                    arrOutParam = new ArrayList();
                    arrInParam.add(strEngModelCD);
                    
                    /*
					 * Patni 23-Aug-2006 - Removed Module Name from the input
					 * parameter list - Begin
					 */
                    // arrInParam.add(strSheetName);
                    /*
					 * Patni 23-Aug-2006 - Removed Module Name from the input
					 * parameter list - End
					 */
                                        
                    arrInParam.add(strSiteName);   
                    arrInParam.add(strLoggedUser);
                    arrInParam.add(strCatSeqID);
                    arrInParam.add(strRoleIndicator);

                    for (; intCount <= intCtr; intCount++)
                    {
                    	arrInParam.add((arrlstBuffs.get(intCount)).toString());
                    }

                    intCount = intCtr + 1;
                    arrOutParam = eCRDDBMediator.doDBOperation(strActionID, arrInParam);
                    for (int intoutCtr = 0; intoutCtr < 15; intoutCtr++)
                    {
                        strError = (String) arrOutParam.get(intoutCtr);
                        if (strError != null && !"".equals(strError))
                        {
                            strErrors[intArrIndex++] = strError;
                        }
                    }
                    logErrorToObject(strErrors);
                }
            }

            /* Milind 13Th November 2004 */
        }
        finally
        {
            // cstmt = null;
            strErrors = null;
        }
    }
/* END saveSheetData() */ 
    private void logErrorToObject(String[] strErrors) throws Exception
    {
        StringTokenizer strtkn = null;
        String strError = "";

        /*
		 * Patni 05-Sep-2006 - Variable added to check repetition of Error
		 * Message - Begin
		 */
        String strTemp = ""; 
        /*
		 * Patni 05-Sep-2006 - Variable added to check repetition of Error
		 * Message - End
		 */

        try
        {
            for (int intCtr = 0; intCtr < strErrors.length; intCtr++)
            {
                strError = strErrors[intCtr];
                if (strError != null && !"".equals(strError))
                {
                    strtkn = new StringTokenizer(strError, "^");
                    while (strtkn.hasMoreTokens())
                    {
                        /*
						 * Patni 05-Sep-2006 - Repetition of Error Message is
						 * checked before adding to Arraylist- Begin
						 */
                        strTemp = strtkn.nextToken();

                        if(!arrLstError.contains(strTemp))
                        {
                          arrLstError.add(strTemp);
                        }
                        /*
						 * Patni 05-Sep-2006 - Repeatition of Error Message is
						 * checked before adding to Arraylist- End
						 */
                    }
                }
            }
        }
        finally
        {
            strtkn = null;
        }
    }
    private String isGreaterThanMaxLength(String strCellValue, int intMaxLength, String strColName, String strRowCnt)
    {
        try
        {
            if (strCellValue.length() > intMaxLength)
            {
                arrLstError.add(strColName + " Exceeds Max Length allowed " + intMaxLength + " at Row " + strRowCnt);
                return "";
            }
            return strCellValue;
        }
        finally
        {
            strCellValue = null;
        }
    }
    private String returnArrValue(String strArr[], int intArrIndex) throws Exception
    {
        String strReturn = "";
        try
        {
            strReturn = strArr[intArrIndex];
            return strReturn.trim();
        }
        catch (ArrayIndexOutOfBoundsException e)
        {
            strReturn = "";
            return strReturn;
        }
        finally
        {
            strReturn = null;
        }
    }
    private boolean validateATA(String strATA) throws Exception
    {
        StringTokenizer strtknATA = null;
        boolean isValidNumber = true;
        boolean isInvalidATA = false;
        String strEachToken = "";
        String strUpperCaseATA = "";
        try
        {
            strATA = strATA.trim();
            strUpperCaseATA = strATA.toUpperCase();
            if (strUpperCaseATA.indexOf("GEK ") == 0)
            {
                return false;
            }
            else if (strUpperCaseATA.indexOf("TO ") == 0)
            {
                return false;
            }
            strtknATA = new StringTokenizer(strATA, "-");
            if (strATA.length() < 9 && strATA.length() > 4)
            {
                if (strtknATA.countTokens() == 3)
                {
                    while (strtknATA.hasMoreTokens() && isValidNumber)
                    {
                        try
                        {
                            strEachToken = strtknATA.nextToken().trim();
                            if (strEachToken.length() == 2)
                            {
                                Integer.parseInt(strEachToken);
                            }
                            else
                            {
                                isValidNumber = false;
                            }
                        }
                        catch (Exception e)
                        {
                            isValidNumber = false;
                        }
                    }
                    if (!isValidNumber)
                    {
                        isInvalidATA = true;
                    }
                }
                else
                {
                    isInvalidATA = true;
                }
            }
            else
            {
                isInvalidATA = true;
            }
            return isInvalidATA;
        }
        finally
        {
            strtknATA = null;
            strEachToken = null;
        }
    }
    private boolean isValidNumber(String strNum, String strMaxValue, String strColName, String strRowCnt, boolean blnIsStringPoss, String strPossStringVal) throws Exception
    {
        boolean blnIsValidNumber = true;
        int inLengthOfNumber = 0;
        StringTokenizer strtkn = null;
        String strNumWoPlusComma = "";
        StringBuffer strBuff = null;
        double dblNumValue = 0;
        double dblMaxValue = 0;
        try
        {
            dblMaxValue = Double.parseDouble(strMaxValue);

            if ("".equals(strNum) || " ".equals(strNum))
            {
                return true;
            }
            inLengthOfNumber = strNum.length();
            if (strNum.indexOf("+") == 0)
            {
                strNum.substring(1);
            }

            if (strNum.charAt(0) == ',' || strNum.charAt(inLengthOfNumber - 1) == ',')
            {
                blnIsValidNumber = false;
                arrLstError.add(strColName + " Found Non Numeric at Row No." + strRowCnt);
            }
            else
            {
                strBuff = new StringBuffer();
                strtkn = new StringTokenizer(strNum, ",");
                while (strtkn.hasMoreTokens())
                {
                    strBuff.append(strtkn.nextToken());
                }
                strNumWoPlusComma = strBuff.toString();
                dblNumValue = Double.parseDouble(strNumWoPlusComma);
                if (dblNumValue > dblMaxValue)
                {
                    blnIsValidNumber = false;
                    arrLstError.add(strColName + " Found greater than Max Value (" + strMaxValue + ")  allowed at Row No." + strRowCnt);
                }
                else
                {
                    if (dblNumValue <= 0)
                    {
                        blnIsValidNumber = false;
                        arrLstError.add(strColName + " Found less than or equals to 0 at Row No." + strRowCnt);
                    }
                }

            }
        }
        catch (NumberFormatException numFormExp)
        {
            if (blnIsStringPoss)
            {
                if ((strNum.equalsIgnoreCase(strPossStringVal)))
                {
                    blnIsValidNumber = true;
                }
                else
                {
                    arrLstError.add(strColName + " Found Non Numeric at Row No." + strRowCnt);
                    blnIsValidNumber = false;
                }
            }
            else
            {
                arrLstError.add(strColName + " Found Non Numeric at Row No." + strRowCnt);
                blnIsValidNumber = false;
            }

        }
        finally
        {
            strtkn = null;
            strNumWoPlusComma = null;
            strBuff = null;
        }
        return blnIsValidNumber;
    }
    /*
	 * 
	 * Method with 0 as valid value for compare
	 */
    private boolean isValidNumberZeroValid(String strNum, String strMaxValue, String strColName, String strRowCnt, boolean blnIsStringPoss, String strPossStringVal) throws Exception
        {
            boolean blnIsValidNumber = true;
            int inLengthOfNumber = 0;
            StringTokenizer strtkn = null;
            String strNumWoPlusComma = "";
            StringBuffer strBuff = null;
            double dblNumValue = 0;
            double dblMaxValue = 0;
            try
            {
                dblMaxValue = Double.parseDouble(strMaxValue);

                if ("".equals(strNum) || " ".equals(strNum))
                {
                    return true;
                }
                inLengthOfNumber = strNum.length();
                if (strNum.indexOf("+") == 0)
                {
                    strNum.substring(1);
                }

                if (strNum.charAt(0) == ',' || strNum.charAt(inLengthOfNumber - 1) == ',')
                {
                    blnIsValidNumber = false;
                    arrLstError.add(strColName + " Found Non Numeric at Row No." + strRowCnt);
                }
                else
                {
                    strBuff = new StringBuffer();
                    strtkn = new StringTokenizer(strNum, ",");
                    while (strtkn.hasMoreTokens())
                    {
                        strBuff.append(strtkn.nextToken());
                    }
                    strNumWoPlusComma = strBuff.toString();

                    dblNumValue = Double.parseDouble(strNumWoPlusComma);

                    if (dblNumValue > dblMaxValue)
                    {
                        blnIsValidNumber = false;
                        arrLstError.add(strColName + " Found greater than Max Value (" + strMaxValue + ")  allowed at Row No." + strRowCnt);
                    }
                    else
                    {
                        if (dblNumValue < 0)
                        {
                            blnIsValidNumber = false;
                            arrLstError.add(strColName + " Found less than 0 at Row No." + strRowCnt);
                        }
                    }

                }
            }
            catch (NumberFormatException numFormExp)
            {
                if (blnIsStringPoss)
                {
                    if ((strNum.equalsIgnoreCase(strPossStringVal)))
                    {
                        blnIsValidNumber = true;
                    }
                    else
                    {
                        arrLstError.add(strColName + " Found Non Numeric at Row No." + strRowCnt);
                        blnIsValidNumber = false;
                    }
                }
                else
                {
                    arrLstError.add(strColName + " Found Non Numeric at Row No." + strRowCnt);
                    blnIsValidNumber = false;
                }

            }
            finally
            {
                strtkn = null;
                strNumWoPlusComma = null;
                strBuff = null;
            }
            return blnIsValidNumber;
        }
    /* Function added by milind on 14 November 2004 */
    /* Set errors in resultset for display in RC tag */

    private GEAEResultSet setErrors(GEAEResultSet rseCRDBatchUploadErr, String strEachSheet, ArrayList arrLstError) throws Exception
    {
        GEAEResultSet rsFormatted = rseCRDBatchUploadErr;
        if (rsFormatted == null)
        {
            rsFormatted = new GEAEResultSet();
        }
        ArrayList arrRow = null;
        if (arrLstError != null)
        {
            int arrSize = arrLstError.size();
            try
            {
            	for (int arrCnt = 0; arrCnt < arrSize; arrCnt++)
                {
                    arrRow = new ArrayList();
                    arrRow.add(strEachSheet);
                    if(null!=arrLstError.get(arrCnt)){
                      arrRow.add(arrLstError.get(arrCnt));
                    }else{
                    	arrRow.add("");
                    }
                    rsFormatted.addRow(arrRow);
                }
                rsFormatted.setColumnHeading(1, "Sheet Name");
                rsFormatted.setColumnHeading(2, "Error Description");
            }
            finally
            {
            }
        }
        return rsFormatted;
    }


}

