//Source file: D:\\ECRD\\SOURCE CODE\\ecrd\\biz\\eCRDUser.java
/*
* Module    	    : eCRDUser.java
* Author      	    : PATNI-Offshore
* Project	        : eCRD
* Date Written		: October 2004
* Security	        : Unclassified
* Restrictions		: GE PROPRIETARY INFORMATION, FOR GE USE ONLY
*
*     ****************************************************
*     *  Copyright (2000) with all rights reserved       *
*     *          General Electric Company                *
*     ****************************************************
*
* Description: eCRDUser is used for creating updating user entity.
*
* Revision Log  (mm/dd/yy initials description)
* --------------------------------------------------------------
*/
package ecrd.biz;
import java.util.ArrayList;
import java.io.Serializable;
import ecrd.util.eCRDConstants;
import ecrd.common.eCRDDBMediator;
import ecrd.exception.eCRDException;
import geae.dao.GEAEResultSet;
import ecrd.util.eCRDUtil;
/**
 * This class stores application user related information
 */
public class eCRDUser implements Serializable
{
	/**
	* Stores User Id for the user. Retrieved from LDAP.
	*/
	private String strUserId = null;

	/**
	 * Stores first name of the user. Retrieved from LDAP.
	 */
	private String strFirstName = null;

	/**
		* Stores Last Name of the user. Retrieved from LDAP.
		*/
	private String strLastName = null;

	/**
	 * Stores e-Mail addrss for the user
	 */
	private String strEMailId = null;

	/**
		* Stores Status of the user. Active/Inactive.
		*/
	private String strStatus = null;

	/**
		* Stores Role of the user. e.g.Admin/TC/CSM
		*/
	private String strRole = null;

	/**
		* Stores reference to eCRDsite object which is site assigne to the user.
		*/
	private eCRDSite objeCRDSite = null;

	//private String strCreatedByRole = null;		

	/**
	* Stores Dual Role Indicator of the user. Y/N (Yes/No).
	*/
	private String strDualRoleIndValue = null;

	/**
	 * Retrieves User details. User Id, First Name, Last Name and e-Mail id are 
	 * retrieved from LDAP site role and active indicator are retrieved from database. 
	 * If there are no records in the database then this method should throw an 
	 * exception that user details can't be loaded
	 * @param strUserId
	 */
	public eCRDUser(String strUserId) throws Exception
	{
		ArrayList arrlstInpParam = null;
		ArrayList arrlstOutParam = null;
		//		GEAEResultSet rsDataOwners = null;
		String strActionId = null;
		String strErrorMsg = null;
		eCRDSite objSite = null;
		eCRDException objException = null;
		try
		{
			if (strUserId == null)
			{
				objException = new eCRDException();
				objException.setExcpId("USER_ID_NULL");
				throw objException;
			}
			//Set the action id to call procedure to load user details
			strActionId = eCRDConstants.getActionId("eCRD_LOAD_USER");

			//ArrayList of Input Parameters
			arrlstInpParam = new ArrayList();
			//ArrayList of Output Parameters
			arrlstOutParam = new ArrayList();
			//ArrayList would be User Id
			arrlstInpParam.add(strUserId);

			// Call this function to retrieve details of the user from database
			arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);

			//Set all parameters as retrieved from the database
			this.setUserId(strUserId);
			this.setFirstName((String) arrlstOutParam.get(0));
			this.setLastName((String) arrlstOutParam.get(1));
			this.setEMailId((String) arrlstOutParam.get(2));
			this.setStatus((String) arrlstOutParam.get(3));
			this.setRole((String) arrlstOutParam.get(4));
			//Create object of eCRDSite class for associatng it with user		
			objSite = new eCRDSite();
			objSite.setSiteCode((String) arrlstOutParam.get(5));
			objSite.setSiteDescription((String) arrlstOutParam.get(6));
			this.objeCRDSite = objSite;
			this.setDualRoleIndValue((String) arrlstOutParam.get(7));
		}
		finally
		{
			arrlstInpParam = null;
			arrlstOutParam = null;
			strActionId = null;
			strErrorMsg = null;
			objSite = null;
		}
	}

	/**
	 * Deafult Constructor
	 */
	public eCRDUser()
	{

	}

	/**
	 * Inserts user to the database
	 * @return Success/Failure Message. Values : USER_ALREADY_EXISTS, USER_SUCESSFULLY_CREATED
	 * @param Created By
	 * @param Role of the user who is creating this user
	 */
	public String create(String strCreatedBy, String strCreatedByRole) throws Exception
	{
		ArrayList arrlstInpParam = null;
		ArrayList arrlstOutParam = null;
		String strActionId = null;
		String strErrorMsg = null;
		eCRDException objException = null;

		try
		{
			if (this.strUserId == null || this.strUserId.trim().equals("") || strCreatedBy == null || strCreatedBy.trim().equals("") || this.strStatus == null || this.strStatus.trim().equals(""))
			{
				objException = new eCRDException();
				objException.setExcpId("SET_PARAMETERS_NULL");
				throw objException;
			}
			//Set the action I to call procedure to create user details
			strActionId = eCRDConstants.getActionId("eCRD_CREATE_USER");

			//ArrayList of Input Parameters
			arrlstInpParam = new ArrayList();
			//ArrayList of Output Parameters
			arrlstOutParam = new ArrayList();
			//Pass all parameters to be inserted to the procedure
			arrlstInpParam.add(this.strUserId);
			arrlstInpParam.add(this.strFirstName);
			arrlstInpParam.add(this.strLastName);
			arrlstInpParam.add(this.strEMailId);
			arrlstInpParam.add(this.strStatus);
			arrlstInpParam.add(this.strRole);
			arrlstInpParam.add(this.objeCRDSite.getSiteCode());
			arrlstInpParam.add(strCreatedBy);
			arrlstInpParam.add(strCreatedByRole);
			arrlstInpParam.add(this.strDualRoleIndValue);

			// Call this function to retrieve details of the user from database
			arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);

			//Return the message code retrieved from the parameter
			return (String) arrlstOutParam.get(0);
		}
		finally
		{
			arrlstInpParam = null;
			arrlstOutParam = null;
			strActionId = null;
			strErrorMsg = null;
			strCreatedBy = null;
			strCreatedByRole = null;
		}
	}

	/**
	 * Removes a user from the databse
	 * @return Success/Failure Message
	 */
	/*  public String remove() throws Exception
	  {
		ArrayList arrlstInpParam = null;
		ArrayList arrlstOutParam = null;	
		String strActionId = null;
		String strErrorMsg = null;	
		
		try
		{	
			//Set the action id to call procedure to remove users
			strActionId = eCRDConstants.getActionId("eCRD_REMOVE_USER");
			
			//ArrayList of Input Parameters
			arrlstInpParam = new ArrayList();
			//ArrayList of Output Parameters
			arrlstOutParam = new ArrayList();		
			
			//Pass User Id of the user to be removed
			arrlstInpParam.add(strUserId);
			
			// Call this function to remove user from the database
			arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);
			
			//Return the message code retrieved from the parameter
			return (String)arrlstOutParam.get(0);		
		}
		finally
		{
			arrlstInpParam = null;
			arrlstOutParam = null;
			strActionId = null;
			strErrorMsg = null;		
		}    
	  }
	  */
	/**
	 * Updates User details.
	 * @return Success/Failure Message. Values: USER_SUCESSFULLY_UPDATED
	 * @param Updated By
	 * @param Role of the user who is updated this user  
	 */
	public String update(String strUpdatedBy, String strUpdatedByRole) throws Exception
	{
		ArrayList arrlstInpParam = null;
		ArrayList arrlstOutParam = null;
		String strActionId = null;
		String strErrorMsg = null;
		eCRDException objException = null;

		try
		{
			if (this.strUserId == null || this.strUserId.trim().equals("") || strUpdatedBy == null || strUpdatedBy.trim().equals("") || this.strStatus == null || this.strStatus.trim().equals(""))
			{
				objException = new eCRDException();
				objException.setExcpId("SET_PARAMETERS_NULL");
				throw objException;
			}

			//Set the action id to call procedure to update users
			strActionId = eCRDConstants.getActionId("eCRD_UPDATE_USER");

			//ArrayList of Input Parameters
			arrlstInpParam = new ArrayList();
			//ArrayList of Output Parameters
			arrlstOutParam = new ArrayList();

			//add attributes of the current object as input to the procedure 
			arrlstInpParam.add(this.strUserId);
			arrlstInpParam.add(this.strFirstName);
			arrlstInpParam.add(this.strLastName);
			arrlstInpParam.add(this.strEMailId);
			arrlstInpParam.add(this.strStatus);
			arrlstInpParam.add(this.strRole);
			arrlstInpParam.add(this.objeCRDSite.getSiteCode());
			arrlstInpParam.add(strUpdatedBy);
			arrlstInpParam.add(strUpdatedByRole);
			arrlstInpParam.add(this.strDualRoleIndValue);

			// Call this function to update details of current user to the database
			arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);

			//Return the message code retrieved from the parameter
			return (String) arrlstOutParam.get(0);
		}
		finally
		{
			arrlstInpParam = null;
			arrlstOutParam = null;
			strActionId = null;
			strErrorMsg = null;
			strUpdatedBy = null;
			strUpdatedByRole = null;
		}

	}

	/**
	 * Returns User Id for the user
	 * @return String
	 */
	public String getUserId()
	{
		return strUserId;
	}

	/**
	 * Returns First Name for the User
	 * @return String
	 */
	public String getFirstName()
	{
		return strFirstName;
	}

	/**
	 * Returns Last Name for the User
	 * @return String
	 */
	public String getLastName()
	{
		return strLastName;
	}

	/**
	 * Returns EMail Id for the user
	 * @return String
	 */
	public String getEMailId()
	{
		return strEMailId;
	}

	/**
	 * Returns EMail id for the user
	 * @return String
	 */
	public String getStatus()
	{
		return strStatus;
	}

	/**
	 * Returns Role for the user
	 * @return String
	 */
	public String getRole()
	{
		return strRole;
	}

	/**
	 * Returns Site for the user
	 * @return ecrd.biz.eCRDSite
	 */
	public eCRDSite getSite()
	{
		return objeCRDSite;
	}

	/**
		* Set User Id
		* @param setUserId
		*/
	public void setUserId(String streCRDUserId)
	{
		strUserId = streCRDUserId;
	}

	/**
	 * Set First for the User
	 * @param strFirstName
	 */
	public void setFirstName(String strUserFirstName)
	{
		strFirstName = strUserFirstName;
	}

	/**
	 * Set Last Name for the User
	 * @param strLastName
	 */
	public void setLastName(String strUserLastName)
	{
		strLastName = strUserLastName;
	}

	/**
	 * Set Role for the User
		* @param strRoleId
		*/
	public void setRole(String strRoleId)
	{
		strRole = strRoleId;
	}

	/**
	 * Set EMail Id for the user. 
	 * @param strEMailId
	 */
	public void setEMailId(String strUserEMailId)
	{
		strEMailId = strUserEMailId;
	}

	/**
	 * Set Active Status for the user. Status : A= Active, I=Inactive
		* @param streCRDStatus
		*/
	public void setStatus(String streCRDStatus)
	{
		strStatus = eCRDUtil.verifyNull(streCRDStatus);
	}

	/**
	 * Set Site for the User
	 * @param objSite
	 */
	public void setSite(eCRDSite objSite)
	{
		objeCRDSite = objSite;
	}

	/**
		 * This method calls the procedure for inserting a new email group  in to the database 
			* @param strAction,arrLstInParam
			*/
	public ArrayList insertEmailGroup(String strAction, ArrayList arrLstInParam) throws Exception
	{
		ArrayList arrlstOutParam = null;
		try
		{
			arrlstOutParam = new ArrayList();
			arrlstOutParam = eCRDDBMediator.doDBOperation(strAction, arrLstInParam);
			return arrlstOutParam;
		}
		finally
		{
			arrlstOutParam = null;

		}
	}

	/**
	 * This method calls the procedure for adding  particular email id in to the database 
		* @param strAction,arrLstInParam
		*/

	public ArrayList addEmailInGroup(String strAction, ArrayList arrLstInParam) throws Exception
	{
		ArrayList arrlstOutParam = null;
		//GEAEResultSet geaersetUserList = null;
		try
		{
			arrlstOutParam = new ArrayList();
			arrlstOutParam = eCRDDBMediator.doDBOperation(strAction, arrLstInParam);
			//geaersetUserList = (GEAEResultSet) arrlstOutParam.get(0);
			return arrlstOutParam;
		}
		finally
		{
			arrlstOutParam = null;
		}
	}

	/**
	 * This method calls the procedure for deleting particular email id in to the database 
		* @param strAction,arrLstInParam
		*/

	public ArrayList deleteEmailFromGroup(String strAction, ArrayList arrLstInParam) throws Exception
	{
		ArrayList arrlstOutParam = null;
		//		GEAEResultSet geaersetUserList = null;

		try
		{

			arrlstOutParam = new ArrayList();
			arrlstOutParam = eCRDDBMediator.doDBOperation(strAction, arrLstInParam);
			//geaersetUserList = (GEAEResultSet) arrlstOutParam.get(0);
			return arrlstOutParam;

		}
		finally
		{
			arrlstOutParam = null;
			//geaersetUserList = null;

		}
	}

	/**
	 * This method returns resultset containing list of all email addresses 
	 * in a particular group
		* @param strAction,arrLstInParam
		*/
	public GEAEResultSet listEmailForGroup(String strAction, ArrayList arrLstInParam) throws Exception
	{
		ArrayList arrlstOutParam = null;
		GEAEResultSet geaersetUserList = null;

		try
		{

			arrlstOutParam = new ArrayList();
			arrlstOutParam = eCRDDBMediator.doDBOperation(strAction, arrLstInParam);
			geaersetUserList = (GEAEResultSet) arrlstOutParam.get(0);
			return geaersetUserList;

		}
		finally
		{
			arrlstOutParam = null;
			geaersetUserList = null;

		}
	}

	/**
	 * This method returns a message if the events are associated wih
	 * a particular group
		* @param strAction,arrLstInParam
		*/

	public String attachEventToGroup(String strActionId, ArrayList arrLstInParam) throws Exception
	{
		ArrayList arrLstOutParam = null;
		try
		{

			arrLstOutParam = new ArrayList();
			arrLstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrLstInParam);
			return (String) arrLstOutParam.get(0);
		}
		finally
		{
			arrLstOutParam = null;
		}
	}
	
	public ArrayList deleteGroup(String strAction, ArrayList arrLstInParam) throws Exception
		{
			ArrayList arrlstOutParam = null;
			try
			{

				arrlstOutParam = new ArrayList();
				arrlstOutParam = eCRDDBMediator.doDBOperation(strAction, arrLstInParam);
				return arrlstOutParam;

			}
			finally
			{
				arrlstOutParam = null;
			}
		}

	/**
	 * @return Returns the dualRoleIndValue.
	 */
	public String getDualRoleIndValue() {
		return strDualRoleIndValue;
	}
	/**
	 * @param dualRoleIndValue The dualRoleIndValue to set.
	 */
	public void setDualRoleIndValue(String dualRoleIndValue) {
		strDualRoleIndValue = dualRoleIndValue;
	}
}
