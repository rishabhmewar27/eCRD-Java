package ecrd.common;

public abstract class ECRDPricingCommon
{
	public abstract void resize();

	}
