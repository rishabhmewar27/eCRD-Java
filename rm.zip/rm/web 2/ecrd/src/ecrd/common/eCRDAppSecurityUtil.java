/**
 * 
 */
package ecrd.common;

import java.util.StringTokenizer;

import org.owasp.esapi.ESAPI;

/**
 * @author 226855
 *
 */
public class eCRDAppSecurityUtil {

	/**
	 * 
	 */
	public eCRDAppSecurityUtil() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public static String encodeTextAsHTML(String pText) 
	{
		  System.out.println("pText --> " + pText);	
		  StringTokenizer tokenizer = new StringTokenizer(pText, "&<>\"", true);
		  int tokenCount = tokenizer.countTokens();

		  /* no encoding's needed */
		  if (tokenCount == 1)
			  return pText;

		  /* text.length + (tokenCount * 6) gives buffer large
		  * enough so no addition memory would be needed and no
		  * costly copy operations would occur */
		  StringBuffer buffer = new StringBuffer(pText.length() + tokenCount * 6);
		  
		  while (tokenizer.hasMoreTokens()) 
		{
			  String token = tokenizer.nextToken();
			  if (token.length() == 1) 
			  {
				  switch (token.charAt(0)) 
				  {
				  	case '&':
				  				buffer.append("&amp;");
				  				break;
				  	case '<':
							  	buffer.append("<");
							  	break;
				  	case '>':
				  				buffer.append(">");
				  				break;
				  	case '"':
				  				buffer.append("&quot;");
				  				break;
				  	case '\'':
				  				buffer.append("&#39;");
				  				break;
				  	case '%':
				  				buffer.append("&#37;");
				  				break;
				  	default:
				  				buffer.append(token);
				  }
			  } else {
				  	buffer.append(token);
			  }
		}

		  return buffer.toString();
}
	
	public static String encodeHidden(String strHidden) throws Exception 
	{
		try {
				strHidden = strHidden.replaceAll("<", "<");
				strHidden = strHidden.replaceAll(">", "&gt");
				strHidden = strHidden.replaceAll("&", "&amp;");
				strHidden = strHidden.replaceAll("\"", "&quot;");
				strHidden = strHidden.replaceAll("#", "&#35;");
				strHidden = strHidden.replaceAll("%", "&#37;");
				strHidden = strHidden.replaceAll(";", "&#59;");
				strHidden = strHidden.replaceAll("'", "&#39;");
			} catch (Exception e) {
				e.printStackTrace();
			
			}
			return strHidden;
	}
	
	public static String deleteSplChars(String pText) 
	{
		  System.out.println("pText --> " + pText);
		  pText = ESAPI.encoder().encodeForHTML(pText);
		  System.out.println("pText --> " + pText);
		  return pText;
	}
}
