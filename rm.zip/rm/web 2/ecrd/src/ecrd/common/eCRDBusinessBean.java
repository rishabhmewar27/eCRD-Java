/*
* Module    	    : eCRDBusinessBean.java
* Author      	    : PATNI-Offshore
* Project	        : eCRD
* Date Written		: October 2004
* Security	        : Unclassified
* Restrictions		: GE PROPRIETARY INFORMATION, FOR GE USE ONLY
*
*     ****************************************************
*     *  Copyright (2000) with all rights reserved       *
*     *          General Electric Company                *
*     ****************************************************
*
* Description: eCRDBusinessBean is used for getting the GEAE Row Cache Tag
*
* Revision Log  (mm/dd/yy initials description)
* --------------------------------------------------------------
*/
package ecrd.common;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDUtil;
import geae.dao.GEAEBusinessManagerInt;
import javax.servlet.jsp.PageContext;
import geae.dao.GEAEResultSet;

import java.io.Serializable;
import java.util.ArrayList;
/**
 *eCRDBusinessBean is used for getting the GEAE Row Cache Tag
 */
//Added during migration the class was made Serializable
public class eCRDBusinessBean implements GEAEBusinessManagerInt,Serializable
//The changes during migration ends
{
	/**
	 * Default Constructor
	 */
	public eCRDBusinessBean()
	{
	}
	public void populateData(PageContext pagecontext, String s)
	{
	}
	/**
		* Populate list of components from the database based on the search criteria (do
		* not populate repirs for the components). Search Criteria would be passed to
		* this method through request.
		* @param pagecontext
		* @param s
		* @return void
		*/
	public GEAEResultSet populateComponentList(String strAction, ArrayList arrLstInParam) throws Exception
	{
		ArrayList arrLstOutParam = null;
		arrLstOutParam = new ArrayList();
		GEAEResultSet rsComponentList = null;
		try
		{
			rsComponentList = new GEAEResultSet();

			//Ankur 
			System.out.println("inside populateComponentList. arrLstInParam = " + arrLstInParam);

			arrLstOutParam = eCRDDBMediator.doDBOperation(strAction, arrLstInParam);

			//Ankur
			System.out.println("arrLstOutParam = " + arrLstOutParam);

			rsComponentList = (GEAEResultSet) arrLstOutParam.get(0);

			//Ankur
			System.out.println("rsComponentList = " + rsComponentList);
			System.out.println("rsComponentList.size() = " + rsComponentList.size());

			return rsComponentList;
		}
		finally
		{
			arrLstOutParam = null;
			rsComponentList = null;
		}
	}
    /**
    * Populate list of components from the database based on the search criteria (do
    * not populate repirs for the components). Search Criteria would be passed to
    * this method through request.
    * @param pagecontext
    * @param s
    * @return void
    */
	
	/*Cust Adhoc changes �Prathima*/
    public GEAEResultSet populateCustomerCatalogList (String strAction, ArrayList arrLstInParam) throws Exception
		{
			ArrayList arrLstOutParam = null;
			arrLstOutParam = new ArrayList();
			GEAEResultSet rsCustomerList = null;
			try
			{
				rsCustomerList = new GEAEResultSet();

				//Ankur 
				System.out.println(" SANTOSH IN TEST inside populateCustomerCatalogList. arrLstInParam = " + arrLstInParam);

				arrLstOutParam = eCRDDBMediator.doDBOperation(strAction, arrLstInParam);

				//Ankur
				System.out.println("arrLstOutParam = " + arrLstOutParam.size());

				rsCustomerList = (GEAEResultSet)arrLstOutParam.get(0);

				//Ankur
				System.out.println("SANTOSH IN TEST rsCustomerList = " + rsCustomerList);
				System.out.println(" SANTOSH IN TEST rsCustomerList.size() = " + rsCustomerList.size());

				return rsCustomerList;
			}
			finally
			{
				arrLstOutParam = null;
				rsCustomerList = null;
			}
		}


	/*Cust Adhoc changes end  -Prathima*/
    public GEAEResultSet populateRDList(String strAction, ArrayList arrLstInParam) throws Exception
    {
        ArrayList arrLstOutParam = null;
        arrLstOutParam = new ArrayList();
        GEAEResultSet rsRDList = null;
        try
        {
            rsRDList = new GEAEResultSet();
            arrLstOutParam = eCRDDBMediator.doDBOperation(strAction, arrLstInParam);
            rsRDList = (GEAEResultSet) arrLstOutParam.get(0);
            return rsRDList;
        }
        finally
        {
            arrLstOutParam = null;
            rsRDList = null;
        }
    }
    /**
		* Populate list of repairs from the database based on the search criteria
		* (populate child repairs as well). Search Criteria would be passed to this
		* method through request.
		* @param pagecontext
		* @param s
		* @return void
		*/
	public void populateRepairList(PageContext pagecontext, String s)
	{
	}
	/**
		* Populate list of users from the database based on the search criteria. Search
		* Criteria would be passed to this method through request.
		* @param pagecontext
		* @param s
		* @return void
		*/
	public GEAEResultSet populateUserList(String strAction, ArrayList arrlstInpParam) throws Exception
	{
		ArrayList arrlstOutParam = null;
		GEAEResultSet geaersetUserList = null;
		try
		{
			arrlstOutParam = new ArrayList();
			arrlstOutParam = eCRDDBMediator.doDBOperation(strAction, arrlstInpParam);
			geaersetUserList = (GEAEResultSet) arrlstOutParam.get(0);
			return geaersetUserList;
		}
		finally
		{
			arrlstOutParam = null;
			geaersetUserList = null;
		}
	}
	/**
		* Populate "Price Listing Changes Report" based on the search criteria. Search
		* Criteria would be passed to this method through request.
		* @param pagecontext
		* @param s
		* @return void
		*/
	public void populateReportPriceChgList(PageContext pagecontext, String s)
	{
	}
	/**
		* Populate catalog list based on the search criteria. Search Criteria would be
		* passed to this method through request.
		* @param pagecontext
		* @param s
		* @return GEAEResultSet
		*/
	public GEAEResultSet populateCatalogList(String strActionId, ArrayList arrLstInParam) throws Exception
	{
		GEAEResultSet rsEngineCatalog = null;
		ArrayList arrLstOutParam = null;
		try
		{
			rsEngineCatalog = new GEAEResultSet();
			arrLstOutParam = new ArrayList();
			arrLstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrLstInParam);
			rsEngineCatalog = (GEAEResultSet) arrLstOutParam.get(0);
			return rsEngineCatalog;
		}
		finally
		{
			arrLstInParam = null;
			arrLstOutParam = null;
		}
	}
	/**
		 * Populate ApproveCompSite
		 * @param pagecontext
		 * @param s
		 * @return GEAEResultSet
		 */
	public GEAEResultSet populateApproveCompSite(String strActionId, ArrayList arrLstInParam) throws Exception
	{
		GEAEResultSet rsApproveCompSite = null;
		ArrayList arrLstOutParam = null;
		try
		{
			rsApproveCompSite = new GEAEResultSet();
			arrLstOutParam = new ArrayList();
			arrLstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrLstInParam);
			rsApproveCompSite = (GEAEResultSet) arrLstOutParam.get(0);
			return rsApproveCompSite;
		}
		finally
		{
			rsApproveCompSite = null;
			arrLstOutParam = null;
		}
	}
	public GEAEResultSet populateExistingCatalogList(String strAction, ArrayList arrLstInParam) throws Exception
	{
		ArrayList arrLstOutParam = null;
		GEAEResultSet geaerCatalogList = null;
		try
		{
			arrLstOutParam = new ArrayList();

			arrLstOutParam = eCRDDBMediator.doDBOperation(strAction, arrLstInParam);

			geaerCatalogList = (GEAEResultSet) arrLstOutParam.get(0);
		}
		finally
		{
			arrLstOutParam = null;
		}
		return geaerCatalogList;
	}
	/**
		* Populate "Price Listing Changes Yearly Report" based on the search criteria.
		* Search Criteria would be passed to this method through request.
		* @param pagecontext
		* @param s
		* @return void
		*/
	public void populateReportPriceChgYearlyList(PageContext pagecontext, String s)
	{
	}
	/**
		* Populate 'Component Repair Yearly Catalog' report based on the search criteria.
		* Search Criteria would be passed to this method through request.
		* @param pagecontext
		* @param s
		* @return void
		*/
	public void populateReportComponentRepairYearlyCatalog(PageContext pagecontext, String s)
	{
	}
	/**
		* Populate list of notification groups from the database based on the search
		* criteria. Search Criteria would be passed to this method through request.
		* @param pagecontext
		* @param s
		*/
	public void populateNotificationGroupList(PageContext pagecontext, String s)
	{
	}
	/**
		* Populate list of approvals from the database based on the search criteria.
		* Search Criteria would be passed to this method through request. One of the
		* search criteria would be based on whether the list is for 'Component', 'Repair'
		* or 'site' appoval.
		* @param pagecontext
		* @param s
		*/
	public void populateApprovalReq(PageContext pagecontext, String s)
	{
	}
	/**
		  * Deletes components from the component table.comp_seq_id and module_code
		  * @param pagecontext
		  * @param s
		  */
	public String removeComponent(String strActionId, ArrayList arrLstInParam) throws Exception
	{
		ArrayList arrLstOutParam = null;
		try
		{
			arrLstOutParam = new ArrayList();
			arrLstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrLstInParam);
			return (String) arrLstOutParam.get(0);
		}
		finally
		{
			arrLstOutParam = null;
		}
	}
	/**
			  * Populate  Repairs from the module table.
			  * @param strEngModelCode
			  * @param s
			  */

	public GEAEResultSet populateRepair(String strCopiedCatSeqId
									  , String strEngModel
									  , String strEngModule
									  , String strRepairType
									  , String strComponent
									  , String strCustCatSeqId) throws Exception
	{
		String strScreenAction = "";
		ArrayList arrLstInParam = null;
		ArrayList arrLstOutParam = null;
		arrLstInParam = new ArrayList();
		arrLstOutParam = new ArrayList();
		GEAEResultSet geaersetModules = null;
		try
		{


			strScreenAction = eCRDConstants.getActionId("eCRD_MERGE_REPAIR_TABLE");

			arrLstInParam.add(strCopiedCatSeqId);
			arrLstInParam.add(strEngModel.toUpperCase());
			arrLstInParam.add(strEngModule);
			arrLstInParam.add(strRepairType);
			arrLstInParam.add(strComponent);
			arrLstInParam.add(strCustCatSeqId);


			arrLstOutParam = eCRDDBMediator.doDBOperation(strScreenAction, arrLstInParam);

			geaersetModules = (GEAEResultSet) arrLstOutParam.get(0);
			return geaersetModules;
		}
		finally
		{
			arrLstInParam = null;
			arrLstOutParam = null;
			geaersetModules = null;
		}

	}
	/**
				  * Populate  modules from the module table.
				  * @param strEngModelCode
				  * @param s
				  */

	public GEAEResultSet populateModule(String strEngModelCode) throws Exception
	{
		String strScreenAction = "";
		ArrayList arrLstInParam = null;
		ArrayList arrLstOutParam = null;
		arrLstInParam = new ArrayList();
		arrLstOutParam = new ArrayList();
		GEAEResultSet geaersetModules = null;
		try
		{
			strScreenAction = eCRDConstants.getActionId("eCRD_LIST_ENGMODULE");
			arrLstInParam.add(strEngModelCode.toUpperCase());
			arrLstInParam.add("n");
			arrLstOutParam = eCRDDBMediator.doDBOperation(strScreenAction, arrLstInParam);
			geaersetModules = (GEAEResultSet) arrLstOutParam.get(0);
			return geaersetModules;
		}
		finally
		{
			arrLstInParam = null;
			arrLstOutParam = null;
			geaersetModules = null;
		}
	}
	public ArrayList ApproveCompSite(String strActionId, ArrayList arrLstInParam) throws Exception
	{
		ArrayList arrLstOutParam = null;
		try
		{
			arrLstOutParam = new ArrayList();
			arrLstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrLstInParam);
			return arrLstOutParam;
		}
		finally
		{
			arrLstOutParam = null;
		}
	}
	public ArrayList SaveCatalog(String strActionId, ArrayList arrLstInParam) throws Exception
	{
		ArrayList arrLstOutParam = null;
		try
		{
			arrLstOutParam = new ArrayList();
			
            arrLstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrLstInParam);
			/* Patni 22-May-2006 Begin Add Contract Start and End Date */
			return arrLstOutParam;
            /* Patni 22-May-2006 End Add Contract Start and End Date */
		}
		finally
		{
			arrLstOutParam = null;
		}
	}
	public ArrayList populateCatalogs(ArrayList arrlstInParam) throws Exception
	{
		GEAEResultSet rsOutResults = null;
		ArrayList arrlstOutParam = null;
		String strActionId = "";
		try
		{
			arrlstOutParam = new ArrayList();

			strActionId = eCRDConstants.getActionId("eCRD_SEARCH_CATALOG");
			arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId,arrlstInParam);

			//rsOutResults = (GEAEResultSet)arrlstOutParam.get(0);
			//return rsOutResults;
            return arrlstOutParam;
		}
		finally
		{
		}

	}

	/**
	  * Returns populated resultset of the list of email adresses
	  * @return GEAEResultSet
	  */
	public GEAEResultSet populateEmailList(String strAction, ArrayList arrlstInpParam) throws Exception
	{
		ArrayList arrlstOutParam = null;
		GEAEResultSet geaersetUserList = null;
		try
		{
			arrlstOutParam = new ArrayList();
			arrlstOutParam = eCRDDBMediator.doDBOperation(strAction, arrlstInpParam);
			geaersetUserList = (GEAEResultSet) arrlstOutParam.get(0);
			return geaersetUserList;
		}
		finally
		{
			arrlstOutParam = null;
			geaersetUserList = null;
		}
	}

}
