/*
 *  Project     :   eCRD
 *  Program     :   eCRDCommand.java
 *  Author      :   Patni Team
 *  Date        :   October 2004
 *  Security    :   Classified/Unclassified
 *  Restrictions:   GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 *
 *  ****************************************************
 *  *  Copyright(Year) with all rights reserved        *
 *  *          General Electric Company                *
 *  ****************************************************
 *  Description:   This class is an interface which is implemented by all the Helpers
 *
 *
 *  Revision Log  (mm/dd/yy initials description)
 *  --------------------------------------------------------
 *  Patni Team    October 2004  Created
 *
 */

package ecrd.common;
import java.io.Serializable;

import javax.servlet.http.HttpServletRequest;

/**
 *  <pre>
 * This class is an interface which is implemented by all the Helpers
 * </pre>
 *
 * @author     Patni Team
 * @created    May 20, 2003
 */
public interface eCRDCommand extends Serializable
{
	/**
	 *  <pre>
	 * This method involes the logic needed to populate the
	 * data that are needed by the screen.
	  * @param  request     Description of the Parameter
	 * @return             String
	 * @throws  Exception  </pre>
	 *
	 */

	public String perform(HttpServletRequest request) throws Exception;

}
