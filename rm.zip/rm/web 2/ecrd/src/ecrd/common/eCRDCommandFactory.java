/*
 *  Project     :   eCRD
 *  Program     :   eCRDCommandFactory.java
 *  Author      :   Patni Team
 *  Date        :   October 2004
 *  Security    :   Classified/Unclassified
 *  Restrictions:   GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 *
 *  ****************************************************
 *  *  Copyright(Year) with all rights reserved        *
 *  *          General Electric Company                *
 *  ****************************************************
 *  Description:   This class is used to retrieve the helper class for the screen.
 *
 *
 *  Revision Log  (mm/dd/yy initials description)
 *  --------------------------------------------------------
 *  Patni Team    October 2004  Created
 *
 */
package ecrd.common;

import java.util.HashMap;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDUtil;

/**
 *  <pre>
 * This class is used to retrieve the helper class for the screen.
 * </pre>
 *
 * @author     Patni Team
 * @created    December 15, 2003
 */
public class eCRDCommandFactory
{
	private static eCRDCommandFactory objeCRDCommandFactory = null;
	private HashMap hmCommandFactory = null;

	/**
	 *  <pre>
	 * private constructor
	 * </pre>
	 *
	 * @exception  Exception  Description of the Exception
	 */
	private eCRDCommandFactory() throws Exception
	{
		eCRDCommandParser objParser = null;

		try
		{
			
			objParser = new eCRDCommandParser(eCRDUtil.getAFSPath() + eCRDConstants.STRCOMDXML);
			objParser.parse();
			hmCommandFactory = objParser.getCommandClasses();
		}
		catch (Exception objExp)
		{
			throw new Exception("eCRDCommandFactory::eCRDCommandFactory() " + objExp.getMessage());
		}
	}

	/**
	 *  <pre>
	 * This method returns the eCRDCommandFactory object
	 * @return                eCRDCommandFactory </pre>
	 * @exception  Exception  Description of the Exception
	 */
	public static eCRDCommandFactory getInstance() throws Exception
	{
		if (objeCRDCommandFactory == null)
		{
			objeCRDCommandFactory = new eCRDCommandFactory();
		}
		return objeCRDCommandFactory;
	}

	/**
	 *  <pre>
	 * This class returns the eCRDCommand for the given screen name
	* @param  strPageID      Description of the Parameter
	 * @return                eCRDCommand </pre>
	 * @exception  Exception  Description of the Exception
	 */
	public eCRDCommand getValue(String strPageID) throws Exception
	{
		Class clsCommand = null;
		eCRDCommand objCommand = null;

		try
		{

			clsCommand = Class.forName((String) hmCommandFactory.get(strPageID));
			objCommand = (eCRDCommand) clsCommand.newInstance();
			return objCommand;
		}
		catch (Exception objExp)
		{
			clsCommand = null;
			throw new Exception("eCRDCommandFactory::getValue():" + objExp);
		}
		finally
		{
			clsCommand = null;
		}
	}

}
