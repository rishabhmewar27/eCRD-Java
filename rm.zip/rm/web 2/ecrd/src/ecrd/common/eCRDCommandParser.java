/*
 *  Project     :   eCRD
 *  Program     :   eCRDCommandParser.java
 *  Author      :   Patni Team
 *  Date        :   October 2004
 *  Security    :   Classified/Unclassified
 *  Restrictions:   GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 *
 *  ****************************************************
 *  *  Copyright(Year) with all rights reserved        *
 *  *          General Electric Company                *
 *  ****************************************************
 *  Description:   This class is used to parse the command.xml
 *
 *
 *  Revision Log  (mm/dd/yy initials description)
 *  --------------------------------------------------------
 *  Patni Team    October 2004  Created
 *
 */
package ecrd.common;
import java.io.FileInputStream;

import java.util.HashMap;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.AttributeList;
import org.xml.sax.HandlerBase;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 *  <pre>
 * This class is used to parse the command.xml
 * </pre>
 *
 * @author     Patni Team
 * @created    May 20, 2004
 */
public class eCRDCommandParser extends HandlerBase
{
	private static String TAG_NAME = "command_info";
	private static String TAG_PAGE_ID = "page_id";
	private static String TAG_CLASS_NAME = "class_name";

	private HashMap hmCommandClasses = null;

	private String strPageID = "";
	private String strClassName = "";
	private String strCurElement = "";
	private String strXmlFile = "";

	//Addition for the portal migration starts 
	private StringBuffer strTempBuffer = null;
	//Addition for the portal migration ends 
	/**
	 *  <pre>
	 * contstructor to instantiate the parser
	 * @param  strXmlFile  Description of the Parameter
	 */
	public eCRDCommandParser(String strXmlFile)
	{
		this.strXmlFile = strXmlFile;
		hmCommandClasses = new HashMap();
	}

	/**
	 *  <pre>
	 * This method is called to parse the file
	 * @throws  Exception  </pre>
	 */
	public void parse() throws Exception
	{
		SAXParserFactory factory = SAXParserFactory.newInstance();
		SAXParser parser = factory.newSAXParser();
		InputSource inputSource = new InputSource(new FileInputStream(strXmlFile));

		parser.parse(inputSource, this);
	}

	/**
	 *  <pre>
	 * This method is called by parser when an element starts
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 * @param  strName           Description of the Parameter
	 * @param  attrList          Description of the Parameter
	 * @exception  SAXException  Description of the Exception
	 * @throws  Exception        </pre>
	 */
	public void startElement(String strName, AttributeList attrList) throws SAXException
	{
		//Addition for the portal migration starts 
		strTempBuffer = new StringBuffer();
		//Addition for the portal migration ends 
		strCurElement = strName;
	}

	/**
	 *  <pre>
	 * This method is called by parser it provies the value for the tag
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 * @param  chData            Description of the Parameter
	 * @param  intStart          Description of the Parameter
	 * @param  intEnd            Description of the Parameter
	 * @exception  SAXException  Description of the Exception
	 * @throws  Exception        </pre>
	 */
	public void characters(char[] chData, int intStart, int intEnd) throws SAXException
	{
		String strValue = new String(chData, intStart, intEnd);

		strValue = strValue.trim();
		//Required as per migration change for parsing character data start
		strTempBuffer.append(strValue);
		//Commented code is written in the endElement method
		/*
		if (TAG_PAGE_ID.equals(strCurElement) && !strValue.equals(""))
		{
			strPageID = strValue;
		}
		else
			if (TAG_CLASS_NAME.equals(strCurElement) && !strValue.equals(""))
			{
				strClassName = strValue;
			}
		*/
	}

	/**
	 *  <pre>
	 * This method is called by parser when an end of the element occured
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 * @param  strName           Description of the Parameter
	 * @exception  SAXException  Description of the Exception
	 * @throws  Exception        </pre>
	 */
	public void endElement(String strName) throws SAXException
	{
		//Addition for the portal migration starts 
		String strTempValue = strTempBuffer.toString();
		strTempBuffer.setLength(0);
		//Writting the commented code of the characters() method

		if (TAG_PAGE_ID.equals(strCurElement) && !strTempValue.equals(""))
		{
			strPageID = strTempValue;
		}
		else 
		{
			if (TAG_CLASS_NAME.equals(strCurElement) && !strTempValue.equals(""))
			{
				strClassName = strTempValue;
			}

			else if (TAG_NAME.equals(strName))
		{
			hmCommandClasses.put(strPageID, strClassName);
			strPageID = "";
			strClassName = "";
		}
	}
		//Making the strTempValue variable null
		strTempValue = null;
		//Addition for the portal migration ends
	}

	/**
	 *  Gets the commandClasses attribute of the eCRDCommandParser object
	 *
	 * @return    The commandClasses value
	 */
	public HashMap getCommandClasses()
	{
		return hmCommandClasses;
	}
}
