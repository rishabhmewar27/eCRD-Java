/*
 *  Project     :   eCRD
 *  Program     :   eCRDDBMediator.java
 *  Author      :   Patni Team
 *  Date        :   October 2004
 *  Security    :   Classified/Unclassified
 *  Restrictions:   GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 *  ****************************************************
 *  *  Copyright(Year) with all rights reserved        *
 *  *          General Electric Company                *
 *  ****************************************************
 *  Description: This class is the Data Access Object for eCRD application
 * 				 All the database calls are made using this class.
 *  Revision Log  (mm/dd/yy initials description)
 *  --------------------------------------------------------
 *  Patni Team    October 2004 Created
 */
package ecrd.common;

import java.util.HashMap;
import java.util.ArrayList;

import geae.dao.GEAECallableParameter;
import geae.dao.GEAECallableStatement;
import geae.dao.GEAEDataAccessObject;

import oracle.jdbc.driver.OracleTypes;

import ecrd.util.eCRDConstants;

/**
 *  <pre>
 * This class is the Data Access Object for eCRD application
 * All the database calls are made using this class.
 * </pre>
 *
 * @author     Patni Computer Systems
 * @created    December 15, 2003
 */

public class eCRDDBMediator
{
	/**
	 *  <pre>
	 * This method is used to make database calls in the application
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 * @param  arrlstInParam  ArrayList of the Input parameters.
	 * @param  strActionId    Description of the Parameter
	 * @return                ArrayList
	 * @throws  Exception     </pre>
	 */

	/**
	 *  <pre>
	 * private constructor
	 * </pre>
	 *
	 * @exception  Exception  Description of the Exception
	 */
	private eCRDDBMediator() throws Exception
	{

	}

	/**
	* This method performs the DB operation and returns results in an arraylist
	* @param  strActionId    ActionId indicating the procedure to be executed
	* @param  arrlstInParam  ArrayList of the Input parameters.
	* @return                ArrayList of output parameters
	* @throws  Exception     </pre>
	*/

	public static ArrayList doDBOperation(String strActionId, ArrayList arrlstInParam) throws Exception
	{

		ArrayList arrLstResult = new ArrayList();
		GEAECallableParameter objCP = new GEAECallableParameter();
		GEAECallableStatement cs = new GEAECallableStatement();
		StringBuffer strbufParams = new StringBuffer();
		String strQueryString = "";
		int intOutParam = 0;
		int intOutParamVarchar = 0;
		int intInParamLength = 0;
		int totalOutParam = 0;
		HashMap hmProcInfo = new HashMap();
		String strProcedureName = "";
		eCRDProcedureNames objProcNames = null;
		try
		{
			intInParamLength = (arrlstInParam == null ? 0 : arrlstInParam.size());
			objProcNames = eCRDProcedureNames.getInstance();
			hmProcInfo = (HashMap) objProcNames.getValue(strActionId);
			strProcedureName = (String) hmProcInfo.get("PROCNAME");
			intOutParam = Integer.parseInt((String) hmProcInfo.get("OUTCURSOR"));
			intOutParamVarchar = Integer.parseInt((String) hmProcInfo.get("OUTVARCHAR"));
			totalOutParam = intOutParam + intOutParamVarchar;
			if (strProcedureName == null || strProcedureName.length() == 0)
			{
				throw new Exception("Procedure Name not specified");
			}
			else
			{
				
				/**beginning changes by rishabh mewar **/
				
					System.out.println(" Procedure Name "+strProcedureName);
					System.out.println(" Procedure Inputs "+arrlstInParam);
				
				/**end of changes by rishabh mewar **/
				
				// Form the parameters and set/register the i/o params
				strQueryString = "{call " + strProcedureName + "(";
				for (int intCntr = 1; intCntr <= (intInParamLength + intOutParam + intOutParamVarchar); intCntr++)
				{
					strbufParams.append("?,");
					if (intCntr <= intInParamLength)
					{
						objCP.setString(intCntr, (String) arrlstInParam.get(intCntr - 1));
					}
					else
						if (intCntr <= (intInParamLength + intOutParam))
						{
							objCP.registerOutParameter(intCntr, OracleTypes.CURSOR);
						}
						else
							if (intCntr <= (intInParamLength + intOutParam + intOutParamVarchar))
							{
								objCP.registerOutParameter(intCntr, OracleTypes.VARCHAR);
							}
				}
				strQueryString = strQueryString + strbufParams.substring(0, strbufParams.length() - 1) + ")}";
				
				// call the getdata method
				cs = GEAEDataAccessObject.getData(eCRDConstants.eCRD_DS_ID, strQueryString, objCP);
				//get the ResultSet
				for (int intCntr = 0; intCntr < totalOutParam; intCntr++)
				{
					arrLstResult.add(cs.getObject(intCntr + 1));
				}
				
			}

		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw new Exception("eCRD002 : Error in Data Access eCRDDBMediator.doDBOperation() " + e.getMessage());
		}
		return arrLstResult;
	}

}
