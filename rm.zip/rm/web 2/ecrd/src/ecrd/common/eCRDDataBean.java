/*
* Module    	    : eCRDBusinessBean.java
* Author      	    : PATNI-Offshore
* Project	        : eCRD
* Date Written		: October 2004
* Security	        : Unclassified
* Restrictions		: GE PROPRIETARY INFORMATION, FOR GE USE ONLY
*
*     ****************************************************
*     *  Copyright (2000) with all rights reserved       *
*     *          General Electric Company                *
*     ****************************************************
*
* Description:  eCRDDataBean is used for storing the data in ROW cache
*
* Revision Log  (mm/dd/yy initials description)
* --------------------------------------------------------------
*/
package ecrd.common;

import java.io.Serializable;

import geae.dao.GEAEDataBean;


/**
 * eCRDDataBean is used for storing the data in ROW cache
 */
//Added during migration the class was made Serializable
public class eCRDDataBean extends GEAEDataBean implements Serializable
//The changes during migration ends
{
	/**
	 * Default Constructor
	 */

	public eCRDDataBean()
	{
	}
}
