/*
 *  Project     :   eCRD
 *  Program     :   eCRDHTMLTableRS.java
 *  Author      :   Patni Team
 *  Date        :   October 2004
 *  Security    :   Classified/Unclassified
 *  Restrictions:   GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 *
 *  ****************************************************
 *  *  Copyright(Year) with all rights reserved        *
 *  *          General Electric Company                *
 *  ****************************************************
 *  Description:   This is a class to format the result set for the Breakdown and
 *				   Factor Input	charts
 *
 *
 *  Revision Log  (mm/dd/yy initials description)
 *  --------------------------------------------------------
 *  Patni Team   October 2004  Created
 *
 */

package ecrd.common;
/*import java.util.ArrayList;
import ecrd.util.eCRDUtil;
import geae.dao.*;
import java.util.HashMap;
import java.util.Iterator;
import ecrd.util.eCRDConstants;
*/
public class eCRDHTMLTableRS
{


}// class ends