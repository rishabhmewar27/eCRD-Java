/*
 *  Project     :   eCRD
 *  Program     :   eCRDProcParser.java
 *  Author      :   Patni Team
 *  Date        :   October 2004
 *  Security    :   Classified/Unclassified
 *  Restrictions:   GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 *  ****************************************************
 *  *  Copyright(Year) with all rights reserved        *
 *  *          General Electric Company                *
 *  ****************************************************
 *  Description:   Description of the class
 *  Revision Log  (mm/dd/yy initials description)
 *  --------------------------------------------------------
 *  Patni Team   October 2004  Created
 */
package ecrd.common;
import java.io.FileInputStream;

import java.util.HashMap;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.AttributeList;

import org.xml.sax.HandlerBase;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 *  <pre>
 * This class is used to parse the procedure.xml
 * </pre>
 *
 * @author     Patni Team
 * @created    May 20, 2004
 */
public class eCRDProcParser extends HandlerBase
{
	private static String TAG_NAME = "proc_info";
	private static String TAG_ACTION_ID = "action_id";
	private static String TAG_PROC_NAME = "proc_name";
	private static String TAG_OUT_CUR = "out_cursor";
	private static String TAG_OUT_VAR = "out_varchar";

	private HashMap hmProcNames = null;
	private HashMap hmProcInfo = null;

	private String strActionID = "";
	private String strProcName = "call ";
	private String strCurElement = "";
	private String strOutCursor = "";
	private String strOutVarchar = "";
//Required as per migration change for parsing character data start
	private StringBuffer strTempBuffer = null;
//Required as per migration change for parsing character data end

	/**
	 *  <pre>
	 * contstructor to instantiate the parser
	 * @param  strXmlFile     Description of the Parameter
	 * @exception  Exception  Description of the Exception
	 */
	public eCRDProcParser(String strXmlFile) throws Exception
	{
		hmProcNames = new HashMap();
		hmProcInfo = new HashMap();

		SAXParserFactory factory = SAXParserFactory.newInstance();
		SAXParser parser = factory.newSAXParser();
		InputSource inputSource = new InputSource(new FileInputStream(strXmlFile));

		parser.parse(inputSource, this);
	}

	/**
	 *  <pre>
	 * This method is called by parser when an element starts
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 * @param  strName           Description of the Parameter
	 * @param  attrList          Description of the Parameter
	 * @exception  SAXException  Description of the Exception
	 * @throws  Exception        </pre>
	 */
	public void startElement(String strName, AttributeList attrList) throws SAXException
	{
		//Required as per migration change for parsing character data start
		strTempBuffer = new StringBuffer();
		//Required as per migration change for parsing character data end

		strCurElement = strName;
	}

	/**
	 *  <pre>
	 * This method is called by parser it provies the value for the tag
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 * @param  chData            Description of the Parameter
	 * @param  intStart          Description of the Parameter
	 * @param  intEnd            Description of the Parameter
	 * @exception  SAXException  Description of the Exception
	 * @throws  Exception        </pre>
	 */
	public void characters(char[] chData, int intStart, int intEnd) throws SAXException
	{
		String strValue = new String(chData, intStart, intEnd);

		strValue = strValue.trim();

//Required as per migration change for parsing character data start
		strTempBuffer.append(strValue);
	//Required as per migration change for parsing character data end
	
	/*	if (TAG_ACTION_ID.equals(strCurElement) && !strValue.equals(""))
		{
			strActionID = strValue;
		}
		else
			if (TAG_PROC_NAME.equals(strCurElement) && !strValue.equals(""))
			{
				strProcName = strValue;
			}
			else
				if (TAG_OUT_CUR.equals(strCurElement) && !strValue.equals(""))
				{
					strOutCursor = strValue;
				}
				else
					if (TAG_OUT_VAR.equals(strCurElement) && !strValue.equals(""))
					{
						strOutVarchar = strValue;
					}
*/	

	}

	/**
	 *  <pre>
	 * This method is called by parser when an end of the element occured
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 * @param  strName           Description of the Parameter
	 * @exception  SAXException  Description of the Exception
	 * @throws  Exception        </pre>
	 */
	public void endElement(String strName) throws SAXException
	{
		//Required as per migration change for parsing character data end
		String strTempValue = strTempBuffer.toString();
		strTempBuffer.setLength(0);
		
		if (TAG_ACTION_ID.equals(strName))//if (TAG_NAME.equals(strName))
		{
			strActionID = strTempValue;
		//	hmProcNames.put(strTempValue, hmProcInfo);
		//	strTempValue = strActionID;
		//	strActionID = "";
		//	hmProcInfo = new HashMap();
		}
		if (TAG_NAME.equals(strName))
		{
		//	strActionID = strTempValue;
			hmProcNames.put(strActionID, hmProcInfo);
		//	strTempValue = strActionID;
			strActionID = "";
			hmProcInfo = new HashMap();
		}

		//Required as per migration change for parsing character data end
		if (TAG_PROC_NAME.equals(strName)) {
			hmProcInfo.put("PROCNAME", strTempValue);

		}
		else if (TAG_OUT_CUR.equals(strName)) {
			hmProcInfo.put("OUTCURSOR", strTempValue);

			}
		else if (TAG_OUT_VAR.equals(strName)) {
			hmProcInfo.put("OUTVARCHAR", strTempValue);
		}

			strTempValue = null;

				}

	/**
	 *  Gets the procNames attribute of the eCRDProcParser object
	 *
	 * @return    The procNames value
	 */
	public HashMap getProcNames()
	{
		return hmProcNames;
	}
}
