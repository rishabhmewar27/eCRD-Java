/*
 *  Project     :   eCRD
 *  Program     :   eCRDProcedureNames.java
 *  Author      :   Patni Team
 *  Date        :   October 2004
 *  Security    :   Classified/Unclassified
 *  Restrictions:   GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 *  ****************************************************
 *  *  Copyright(Year) with all rights reserved        *
 *  *          General Electric Company                *
 *  ****************************************************
 *  Description:   Description of the class
 *  Revision Log  (mm/dd/yy initials description)
 *  --------------------------------------------------------
 *  Patni Team   October 2004  Created
 */

/**
 	eCRDProcedureNames is used by eCRDProcParser in parsing the procedure.xml
 */

package ecrd.common;
import java.util.HashMap;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDUtil;

/**
 *  Description of the Class
 *
 * @author     Patni Team
 * @created    May 20, 2003
 */
public class eCRDProcedureNames
{
	private static eCRDProcedureNames objeCRDProcedureNames = null;
	private HashMap hmProcedureNames = null;

	/**
	 *  <pre>
	 * private constructor
	 * </pre>
	 * @exception  Exception  Description of the Exception
	 */
	private eCRDProcedureNames() throws Exception
	{
		eCRDProcParser objParser = null;

		try
		{
			hmProcedureNames = new HashMap();
			objParser = new eCRDProcParser(eCRDUtil.getAFSPath() + "" + eCRDConstants.STRPROCXML);
			hmProcedureNames = objParser.getProcNames();
		}
		catch (Exception objExp)
		{
			throw new Exception("eCRDActionNames::eCRDActionNames() " + objExp);
		}
	}

	/**
	 *  <pre>
	 * This method returns the eCRDProcedureNames object
	 * @return                eCRDProceduerNames </pre>
	 * @exception  Exception  Description of the Exception
	 */
	public static eCRDProcedureNames getInstance() throws Exception
	{
		if (objeCRDProcedureNames == null)
		{
			objeCRDProcedureNames = new eCRDProcedureNames();
		}
		return objeCRDProcedureNames;
	}

	/**
	 *  <pre>
	 * This method returns the procedure name for the given action id
	 * @param  strActionID  Description of the Parameter
	 * @return              String </pre>
	 */
	public HashMap getValue(String strActionID)
	{
		return (HashMap) hmProcedureNames.get(strActionID);
	}
}
