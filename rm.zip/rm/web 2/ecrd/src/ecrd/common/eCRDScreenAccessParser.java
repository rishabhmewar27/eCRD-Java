
/**
 *  Project     :   eCRD
 *  Program     :   eCRDScreenAccessParser
 *  Author      :   Patni Team
 *  Date        :   October 2004
 *  Security    :   Classified/Unclassified
 *  Restrictions:   GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 *
 *  ****************************************************
 *  *  Copyright(Year) with all rights reserved        *
 *  *          General Electric Company                *
 *  ****************************************************
 *  Description:   This class is a data bean class for Engine Model.
 *
 *
 *  Revision Log  (mm/dd/yy initials description)
 *  --------------------------------------------------------
 *  Patni Team    October 2004  Created
 *
 */

package ecrd.common;

import java.util.ArrayList;
import java.util.HashMap;

import org.w3c.dom.Document;
import geae.xml.xmlreader.GEAEXMLProcessor;
import org.xml.sax.InputSource;

import ecrd.util.eCRDConstants;
import ecrd.util.eCRDUtil;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;


public class eCRDScreenAccessParser extends Object
{
	public eCRDScreenAccessParser()
	{

	}

	public static HashMap parseeCRDScreenAccess() throws Exception
	{
		GEAEXMLProcessor xmlp = null;
		Document doc = null;
		InputSource inpt = null;
		Element root = null;
		Element cont = null;
		NodeList nodeList = null;
		int i = 0;
		String strAttribute = "";
		String strText = "";
		ArrayList arrlstRoles = null;
		HashMap hmRoles = null;

		try
		{

			xmlp = new GEAEXMLProcessor();
			hmRoles = new HashMap();
			inpt = new InputSource(eCRDUtil.getAFSPath() + eCRDConstants.STRSCREENACCESSXML);
			doc = xmlp.getDomDocument(inpt,false);

			root = doc.getDocumentElement();
			nodeList = xmlp.grabChildren(root,"CONT");

			for(i = 0; i < nodeList.getLength(); i++)
			{
				cont = (Element)nodeList.item(i);
				strAttribute = xmlp.getAttribute(cont,"value");
				strText = xmlp.grabText(cont);
				arrlstRoles = eCRDUtil.convertToAL(strText,"^");
				
				hmRoles.put(strAttribute,arrlstRoles);
				arrlstRoles = null;
			}

			return hmRoles;
		}
		catch(Exception e)
		{
			throw new Exception("eCRD_USER" + e.getMessage());
		}
		finally
		{
			xmlp = null;
			doc = null;
			inpt = null;
			root = null;
			cont = null;
			nodeList = null;
			strAttribute = null;
			strText = null;
			arrlstRoles = null;
			hmRoles = null;

		}
	}


}