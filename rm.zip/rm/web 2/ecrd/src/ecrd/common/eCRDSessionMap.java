/*
 *  Project     :   eCRD
 *  Program     :   eCRDSessionMap.java
 *  Author      :   Patni Team
 *  Date        :   October 2004
 *  Security    :   Classified/Unclassified
 *  Restrictions:   GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 *
 *  ****************************************************
 *  *  Copyright(Year) with all rights reserved        *
 *  *          General Electric Company                *
 *  ****************************************************
 *  Description:   Description of Class
 *
 *
 *  Revision Log  (mm/dd/yy initials description)
 *  --------------------------------------------------------
 *  Patni Team    October 2004  Created
 *
 */
package ecrd.common;

import java.io.Serializable;
import java.util.Hashtable;
//Added during migration the class was made Serializable
public class eCRDSessionMap implements Serializable
//The changes during migration ends
{
	//hashmap to hold the objects to be stored in session
	private Hashtable dataHash = new Hashtable();

	/*
	 * Constructor
	 */
	public eCRDSessionMap()
	{
	}

	public void resetCache()
	{
		dataHash = new Hashtable();
	}

	public void setData(String key, Object value)
	{
		if (key != null && value != null)
		{
			this.dataHash.put(key, value);
		}

	}

	public Object getData(String key)
	{
		if (this.dataHash.containsKey(key))
		{
			return this.dataHash.get(key);
		}
		else
		{
			return null;
		}
	}

	public void removeData(String key)
	{
			if (this.dataHash.containsKey(key))
			{
				this.dataHash.remove(key);
			}

	}
}
