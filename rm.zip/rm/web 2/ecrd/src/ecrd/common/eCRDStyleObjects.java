/*
 *  Project     :   eCRD
 *  Program     :   eCRDStyleObjects.java
 *  Author      :   Patni Team
 *  Date        :   October 2004
 *  Security    :   Classified/Unclassified
 *  Restrictions:   GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 *
 *  ****************************************************
 *  *  Copyright(Year) with all rights reserved        *
 *  *          General Electric Company                *
 *  ****************************************************
 *  Description:   This class will download the excel sheet.
 *
 *
 *  Revision Log  (mm/dd/yy initials description)
 *  --------------------------------------------------------
 *  Patni Team    October 07, 2004  Created
 *
 */
package ecrd.common;

import geae.office.GEAEOfficeException;
import geae.office.spreadsheet.excel.GEAEExcelCellStyle;
import geae.office.spreadsheet.excel.GEAEExcelConstants;
import geae.office.spreadsheet.excel.GEAEExcelDataFormat;
import geae.office.spreadsheet.excel.GEAEExcelFont;
import geae.office.spreadsheet.excel.GEAEExcelWorkbook;

/**
 * The <code>eCRDStyleObjects</code>
 * This class will provide the style sheet objects for the excel sheet.
 */
public class eCRDStyleObjects {
	/**
	 * Method name:	getLeftAlignStyleObject
	 * Brief logic:	 This method will set the style object to left alignment.
	 * @author	01/28/2004
	 * @version 1.0
	 * @param	wb (GEAEExcelWorkbook)
	 * @return	GEAEExcelCellStyle
	 * @since   JDK1.0
	 */
	public static GEAEExcelCellStyle getLeftAlignStyleObject(GEAEExcelWorkbook wb)
		throws GEAEOfficeException {
		GEAEExcelCellStyle style = wb.createCellStyle();
		//setting it to left alignment.
		style.setAlignment(GEAEExcelConstants.ALIGN_LEFT);
		style.setVerticalAlignment(GEAEExcelConstants.VERTICAL_TOP);
		return style;
	} //end of getLeftAlignStyleObject method

	/**
	 * Method name:	getRightAlignStyleObject
	 * Brief logic:	 This method will set the style object to left alignment.
	 * @author	01/28/2004
	 * @version 1.0
	 * @param	wb (GEAEExcelWorkbook)
	 * @return	GEAEExcelCellStyle
	 * @since   JDK1.0
	 */
	public static GEAEExcelCellStyle getRightAlignStyleObject(GEAEExcelWorkbook wb)
		throws GEAEOfficeException {
		GEAEExcelCellStyle style = wb.createCellStyle();
		//setting it to left alignment.
		style.setAlignment(GEAEExcelConstants.ALIGN_RIGHT);
		return style;
	} //end of getRightAlignStyleObject method

	/**
	 * Method name:	getBoldFontArial12
	 * Brief logic:	 This method will set the font style object to bold and arial type and
	 * size of 12.
	 * @author	01/28/2004
	 * @version 1.0
	 * @param	wb (GEAEExcelWorkbook)
	 * @return	GEAEExcelFont
	 * @since   JDK1.0
	 */
	public static GEAEExcelFont getBoldFontArial12(GEAEExcelWorkbook wb)
		throws GEAEOfficeException {
		GEAEExcelFont font = wb.createFont();
		//setting it to arial font.
		font.setFontName(GEAEExcelConstants.FONT_ARIAL);
		//setting it to bold font.
		font.setBoldweight(GEAEExcelConstants.BOLDWEIGHT_BOLD);
		//setting the height of the font to 12.
		font.setFontHeight((short) 12);
		return font;
	} //end of getBoldFontArial12 method

	/**
	 * Method name:	getBoldFontArial14
	 * Brief logic:	 This method will set the font style object to bold and arial type and
	 * size of 12.
	 * @author	01/28/2004
	 * @version 1.0
	 * @param	wb (GEAEExcelWorkbook)
	 * @return	GEAEExcelFont
	 * @since   JDK1.0
	 */
	public static GEAEExcelFont getBoldFontArial14(GEAEExcelWorkbook wb)
		throws GEAEOfficeException {
		GEAEExcelFont font = wb.createFont();
		//setting it to arial font.
		font.setFontName(GEAEExcelConstants.FONT_ARIAL);
		//setting it to bold font.
		font.setBoldweight(GEAEExcelConstants.BOLDWEIGHT_BOLD);
		//setting the height of the font to 14.
		font.setFontHeight((short) 14);
		return font;
	} //end of getBoldFontArial14 method.

	/**
	 * Method name:	getNormalFontArial9
	 * Brief logic:	 This method will set the font style object to normal and arial type and
	 * size of 9.
	 * @author	01/28/2004
	 * @version 1.0
	 * @param	wb (GEAEExcelWorkbook)
	 * @return	GEAEExcelFont
	 * @since   JDK1.0
	 */
	public static GEAEExcelFont getNormalFontArial9(GEAEExcelWorkbook wb)
		throws GEAEOfficeException {

		GEAEExcelFont font = wb.createFont();
		//setting it to arial font.
		font.setFontName(GEAEExcelConstants.FONT_ARIAL);
		//setting it to normal font.
		font.setBoldweight(GEAEExcelConstants.BOLDWEIGHT_NORMAL);
		//setting the height of the font to 9.
		font.setFontHeight((short) 9);
		return font;
	} //end of getNormalFontArial9 method

	/**
	 * Method name:	getBoldFontArial9
	 * Brief logic:	 This method will set the font style object to bold and arial type and
	 * size of 9.
	 * @author	01/28/2004
	 * @version 1.0
	 * @param	wb (GEAEExcelWorkbook)
	 * @return	GEAEExcelFont
	 * @since   JDK1.0
	 */
	public static GEAEExcelFont getBoldFontArial9(GEAEExcelWorkbook wb)
		throws GEAEOfficeException {
		GEAEExcelFont font = wb.createFont();
		//setting it to arial font.
		font.setFontName(GEAEExcelConstants.FONT_ARIAL);
		//setting it to normal font.
		font.setBoldweight(GEAEExcelConstants.BOLDWEIGHT_BOLD);
		//setting the height of the font to 9.
		font.setFontHeight((short) 9);
		return font;
	} //end of getBoldFontArial9 method

	/**
	 * Method name:	getBoldFontArial10
	 * Brief logic:	 This method will set the font style object to bold and arial type and
	 * size of 9.
	 * @author	02/17/2004
	 * @version 1.0
	 * @param	wb (GEAEExcelWorkbook)
	 * @return	GEAEExcelFont
	 * @since   JDK1.0
	 */
	public static GEAEExcelFont getBoldFontArial10(GEAEExcelWorkbook wb)
		throws GEAEOfficeException {
		GEAEExcelFont font = wb.createFont();
		//setting it to arial font.
		font.setFontName(GEAEExcelConstants.FONT_ARIAL);
		//setting it to normal font.
		font.setBoldweight(GEAEExcelConstants.BOLDWEIGHT_BOLD);
		//setting the height of the font to 9.
		font.setFontHeight((short) 10);
		return font;
	} //end of getBoldFontArial10 method

	/**
	 * Method name:	getStyleObjLeftBold10
	 * Brief logic:	 This method will return the excel cell style object with bold font
	 * and size 10 and left align
	 * @author	02/19/2004
	 * @version 1.0
	 * @param	workBook (GEAEExcelWorkbook)
	 * @return	GEAEExcelCellStyle
	 * @since   JDK1.0
	 */
	public static GEAEExcelCellStyle getStyleObjLeftBold10(GEAEExcelWorkbook workBook)
		throws Exception {
		GEAEExcelFont fontObj;
		GEAEExcelCellStyle styleObj;

		fontObj = getBoldFontArial10(workBook);
		styleObj = getLeftAlignStyleObject(workBook);
		styleObj.setFont(fontObj);

		return styleObj;
	} //end of the method getStyleObjLeftBold10

	/**
	 * Method name:	getStyleObjLeftNormal9
	 * Brief logic:	 This method will return the excel cell style object with normal font
	 * size 9 and left align
	 * @author	02/19/2004
	 * @version 1.0
	 * @param	workBook (GEAEExcelWorkbook)
	 * @return	GEAEExcelCellStyle
	 * @since   JDK1.0
	 */
	public static GEAEExcelCellStyle getStyleObjLeftNormal9(GEAEExcelWorkbook workBook)
		throws Exception {
		GEAEExcelFont fontObj;
		GEAEExcelCellStyle styleObj;
		fontObj = getNormalFontArial9(workBook);
		styleObj = getLeftAlignStyleObject(workBook);
		styleObj.setFont(fontObj);
		return styleObj;
	} //end of  method getStyleObjLeftNormal9

	/**
	 * Method name:	getStyleObjRightNormal9
	 * Brief logic:	 This method will return the excel cell style object with normal font
	 * size 9 and right align
	 * @author	02/19/2004
	 * @version 1.0
	 * @param	workBook (GEAEExcelWorkbook)
	 * @return	GEAEExcelCellStyle
	 * @since   JDK1.0
	 */
	public static GEAEExcelCellStyle getStyleObjRightNormal9(GEAEExcelWorkbook workBook)
		throws Exception {
		GEAEExcelFont fontObj;
		GEAEExcelCellStyle styleObj;

		fontObj = getNormalFontArial9(workBook);
		styleObj = getRightAlignStyleObject(workBook);
		styleObj.setFont(fontObj);

		return styleObj;
	} //end of  method getStyleObjRightNormal9

	/**
	 * Method name:	getStyleObjLeftBold9
	 * Brief logic:	 This method will return the excel cell style object with bold font
	 * size 9 and left align
	 * @author	02/19/2004
	 * @version 1.0
	 * @param	workBook (GEAEExcelWorkbook)
	 * @return	GEAEExcelCellStyle
	 * @since   JDK1.0
	 */
	public static GEAEExcelCellStyle getStyleObjLeftBold9(GEAEExcelWorkbook workBook)
		throws Exception {
		GEAEExcelFont fontObj;
		GEAEExcelCellStyle styleObj;

		fontObj = getBoldFontArial9(workBook);
		styleObj = getLeftAlignStyleObject(workBook);
		styleObj.setFont(fontObj);

		return styleObj;
	} //end of  method getStyleObjLeftBold9

	/**
	 * Method name:	getStyleObjRightBold9
	 * Brief logic:	 This method will return the excel cell style object with bold font
	 * size 9 and right align
	 * @author	02/19/2004
	 * @version 1.0
	 * @param	workBook (GEAEExcelWorkbook)
	 * @return	GEAEExcelCellStyle
	 * @since   JDK1.0
	 */
	public static GEAEExcelCellStyle getStyleObjRightBold9(GEAEExcelWorkbook workBook)
		throws Exception {
		GEAEExcelFont fontObj;
		GEAEExcelCellStyle styleObj;

		fontObj = getBoldFontArial9(workBook);
		styleObj = getRightAlignStyleObject(workBook);
		styleObj.setFont(fontObj);

		return styleObj;
	} //end of  method getStyleObjRightBold9

	/**
	 * Method name:	getStyleObjRightBold10
	 * Brief logic:	 This method will return the excel cell style object with bold font
	 * size 9 and right align
	 * @author	02/19/2004
	 * @version 1.0
	 * @param	workBook (GEAEExcelWorkbook)
	 * @return	GEAEExcelCellStyle
	 * @since   JDK1.0
	 */
	public static GEAEExcelCellStyle getStyleObjRightBold10(GEAEExcelWorkbook workBook)
		throws Exception {
		GEAEExcelFont fontObj;
		GEAEExcelCellStyle styleObj;

		fontObj = getBoldFontArial10(workBook);
		styleObj = getRightAlignStyleObject(workBook);
		styleObj.setFont(fontObj);

		return styleObj;
	} //end of  method getStyleObjRightBold10

	/**
	 * Method name:	getStyleObjRightBold9Num
	 * Brief logic:	 This method will return the excel cell style object with bold font
	 * size 9 and right align with number format.
	 * @author	02/19/2004
	 * @version 1.0
	 * @param	workBook (GEAEExcelWorkbook)
	 * @return	GEAEExcelCellStyle
	 * @since   JDK1.0
	 */
	public static GEAEExcelCellStyle getStyleObjRightBold9Num(GEAEExcelWorkbook workBook)
		throws Exception {
		GEAEExcelFont fontObj;
		GEAEExcelCellStyle styleObj;

		fontObj = getBoldFontArial9(workBook);
		styleObj = getRightAlignStyleObject(workBook);
		styleObj.setFont(fontObj);
		styleObj.setDataFormat(GEAEExcelDataFormat.getFormatIndex("0.00"));

		return styleObj;
	} //end of  method getStyleObjRightBold9Num

	/**
	 * Method name:	getStyleObjRightNormal9Num
	 * Brief logic:	 This method will return the excel cell style object with normal font
	 * size 9 and right align with number format.
	 * @author	02/19/2004
	 * @version 1.0
	 * @param	workBook (GEAEExcelWorkbook)
	 * @return	GEAEExcelCellStyle
	 * @since   JDK1.0
	 */
	public static GEAEExcelCellStyle getStyleObjRightNormal9Num(GEAEExcelWorkbook workBook)
		throws Exception {
		GEAEExcelFont fontObj;
		GEAEExcelCellStyle styleObj;

		fontObj = getNormalFontArial9(workBook);
		styleObj = getRightAlignStyleObject(workBook);
		styleObj.setFont(fontObj);
		styleObj.setDataFormat(GEAEExcelDataFormat.getFormatIndex("0.00"));
		return styleObj;
	} //end of  method getStyleObjRightNormal9Num

	/**
	 * Method name:	getStyleObjLeftNormal10
	 * Brief logic:	 This method will return the excel cell style object with normal font
	 * size 10 and left align
	 * @author	02/19/2004
	 * @version 1.0
	 * @param	workBook (GEAEExcelWorkbook)
	 * @return	GEAEExcelCellStyle
	 * @since   JDK1.0
	 */
	public static GEAEExcelCellStyle getStyleObjLeftNormal10(GEAEExcelWorkbook workBook)
		throws Exception {
		GEAEExcelFont fontObj;
		GEAEExcelCellStyle styleObj;

		fontObj = getNormalFontArial10(workBook);
		styleObj = getLeftAlignStyleObject(workBook);
		styleObj.setFont(fontObj);

		return styleObj;
	} //end of  method getStyleObjLeftNormal10 getStyleObjRightNormal10

	/**
	 * Method name:	getNormalFontArial10
	 * Brief logic:	 This method will set the font style object to normal and arial type and
	 * size of 10.
	 * @author	02/11/2004
	 * @version 1.0
	 * @param	wb (GEAEExcelWorkbook)
	 * @return	GEAEExcelFont
	 * @since   JDK1.0
	 */
	public static GEAEExcelFont getNormalFontArial10(GEAEExcelWorkbook wb)
		throws GEAEOfficeException {
		GEAEExcelFont font = wb.createFont();
		//setting it to arial font.
		font.setFontName(GEAEExcelConstants.FONT_ARIAL);
		//setting it to normal font.
		font.setBoldweight(GEAEExcelConstants.BOLDWEIGHT_NORMAL);
		//setting the height of the font to 9.
		font.setFontHeight((short) 10);
		return font;
	} //end of getNormalFontArial10 method

	/**
	 * Method name:	getStyleObjRightNormal10
	 * Brief logic:	 This method will return the excel cell style object with normal font
	 * size 10 and right align
	 * @author	02/19/2004
	 * @version 1.0
	 * @param	workBook (GEAEExcelWorkbook)
	 * @return	GEAEExcelCellStyle
	 * @since   JDK1.0
	 */
	public static GEAEExcelCellStyle getStyleObjRightNormal10(GEAEExcelWorkbook workBook)
		throws Exception {
		GEAEExcelFont fontObj;
		GEAEExcelCellStyle styleObj;

		fontObj = getNormalFontArial10(workBook);
		styleObj = getRightAlignStyleObject(workBook);
		styleObj.setFont(fontObj);

		return styleObj;
	} //end of  method getStyleObjRightNormal10

	/**
	 * Method name:	getStyleObjRightNormal9Per
	 * Brief logic:	 This method will return the excel cell style object with normal font
	 * size 9 and right align
	 * @author	02/19/2004
	 * @version 1.0
	 * @param	workBook (GEAEExcelWorkbook)
	 * @return	GEAEExcelCellStyle
	 * @since   JDK1.0
	 */
	public static GEAEExcelCellStyle getStyleObjRightNormal9Per(GEAEExcelWorkbook workBook)
		throws Exception {
		GEAEExcelFont fontObj;
		GEAEExcelCellStyle styleObj;

		fontObj = getNormalFontArial9(workBook);
		styleObj = getRightAlignStyleObject(workBook);
		styleObj.setFont(fontObj);
		styleObj.setDataFormat((short) 10);

		return styleObj;
	} //end of  method getStyleObjRightNormal9
	/**
	 * Method name:	getStyleObjLeftNormal9Per
	 * Brief logic:	 This method will return the excel cell style object with normal font
	 * size 10 and right align
	 * @author	02/19/2004
	 * @version 1.0
	 * @param	workBook (GEAEExcelWorkbook)
	 * @return	GEAEExcelCellStyle
	 * @since   JDK1.0
	 */
	public static GEAEExcelCellStyle getStyleObjLeftNormal10Per(GEAEExcelWorkbook workBook)
		throws Exception {
		GEAEExcelFont fontObj;
		GEAEExcelCellStyle styleObj;

		fontObj = getNormalFontArial10(workBook);
		styleObj = getLeftAlignStyleObject(workBook);
		styleObj.setFont(fontObj);
		styleObj.setDataFormat((short) 10);

		return styleObj;
	} //end of  method getStyleObjRightNormal10
	/**
	 * Method name:	getStyleObjLeftNormal9Per
	 * Brief logic:	 This method will return the excel cell style object with normal font
	 * size 9 and right align
	 * @author	02/19/2004
	 * @version 1.0
	 * @param	workBook (GEAEExcelWorkbook)
	 * @return	GEAEExcelCellStyle
	 * @since   JDK1.0
	 */
	public static GEAEExcelCellStyle getStyleObjLeftNormal9Per(GEAEExcelWorkbook workBook)
		throws Exception {
		GEAEExcelFont fontObj;
		GEAEExcelCellStyle styleObj;

		fontObj = getNormalFontArial9(workBook);
		styleObj = getLeftAlignStyleObject(workBook);
		styleObj.setFont(fontObj);
		styleObj.setDataFormat((short) 10);

		return styleObj;
	} //end of  method getStyleObjRightNormal9
	/**
	 * Method name:	getStyleObjRightNormal10Cur
	 * Brief logic:	 This method will return the excel cell style object with normal font
	 * size 10 and right align
	 * @author	02/19/2004
	 * @version 1.0
	 * @param	workBook (GEAEExcelWorkbook)
	 * @return	GEAEExcelCellStyle
	 * @since   JDK1.0
	 */
	public static GEAEExcelCellStyle getStyleObjLeftNormal10Cur(GEAEExcelWorkbook workBook)
		throws Exception {
		GEAEExcelFont fontObj;
		GEAEExcelCellStyle styleObj;

		fontObj = getNormalFontArial10(workBook);
		styleObj = getLeftAlignStyleObject(workBook);
		styleObj.setFont(fontObj);
		styleObj.setDataFormat((short) 8);

		return styleObj;
	} //end of  method getStyleObjRightNormal9

	/**
	 * Method name:	getStyleObjRightNormal9Cur
	 * Brief logic:	 This method will return the excel cell style object with normal font
	 * size 9 and right align
	 * @author	02/19/2004
	 * @version 1.0
	 * @param	workBook (GEAEExcelWorkbook)
	 * @return	GEAEExcelCellStyle
	 * @since   JDK1.0
	 */
	public static GEAEExcelCellStyle getStyleObjRightNormal9Cur(GEAEExcelWorkbook workBook)
		throws Exception {
		GEAEExcelFont fontObj;
		GEAEExcelCellStyle styleObj;

		fontObj = getNormalFontArial9(workBook);
		styleObj = getRightAlignStyleObject(workBook);
		styleObj.setFont(fontObj);
		styleObj.setDataFormat((short) 8);

		return styleObj;
	} //end of  method getStyleObjRightNormal9
	/**
	 * Method name:	getStyleObjLeftNormal9Cur
	 * Brief logic:	 This method will return the excel cell style object with normal font
	 * size 9 and left align with currency format
	 * @author	02/19/2004
	 * @version 1.0
	 * @param	workBook (GEAEExcelWorkbook)
	 * @return	GEAEExcelCellStyle
	 * @since   JDK1.0
	 */
	public static GEAEExcelCellStyle getStyleObjLeftNormal9Cur(GEAEExcelWorkbook workBook)
		throws Exception {
		GEAEExcelFont fontObj;
		GEAEExcelCellStyle styleObj;

		fontObj = getNormalFontArial9(workBook);
		styleObj = getLeftAlignStyleObject(workBook);
		styleObj.setFont(fontObj);
		styleObj.setDataFormat((short) 8);

		return styleObj;
	} //end of  method getStyleObjRightNormal9

	/**
		 * Method name:	getStyleObjRightNormal9Per
		 * Brief logic:	 This method will return the excel cell style object with normal font
		 * size 9 and right align
		 * @author	02/19/2004
		 * @version 1.0
		 * @param	workBook (GEAEExcelWorkbook)
		 * @return	GEAEExcelCellStyle
		 * @since   JDK1.0
		 */
	public static GEAEExcelCellStyle getStyleObjRightBold9Per(GEAEExcelWorkbook workBook)
		throws Exception {
		GEAEExcelFont fontObj;
		GEAEExcelCellStyle styleObj;

		fontObj = getBoldFontArial9(workBook);
		styleObj = getRightAlignStyleObject(workBook);
		styleObj.setFont(fontObj);
		styleObj.setDataFormat((short) 10);

		return styleObj;
	} //end of  method getStyleObjRightNormal9

	/**
	 * Method name:	getStyleObjRightNormal9Cur
	 * Brief logic:	 This method will return the excel cell style object with normal font
	 * size 9 and right align
	 * @author	02/19/2004
	 * @version 1.0
	 * @param	workBook (GEAEExcelWorkbook)
	 * @return	GEAEExcelCellStyle
	 * @since   JDK1.0
	 */
	public static GEAEExcelCellStyle getStyleObjRightBold9Cur(GEAEExcelWorkbook workBook)
		throws Exception {
		GEAEExcelFont fontObj;
		GEAEExcelCellStyle styleObj;

		fontObj = getBoldFontArial9(workBook);
		styleObj = getRightAlignStyleObject(workBook);
		styleObj.setFont(fontObj);
		styleObj.setDataFormat((short) 8);

		return styleObj;
	} //end of  method getStyleObjRightNormal9
	/**
	 * Method name:	getStyleObjRightNormal9Abs
	 * Brief logic:	 This method will return the excel cell style object with normal font
	 * size 9 and right align with number format with absolute value ie without any decimals.
	 * @author	02/19/2004
	 * @version 1.0
	 * @param	workBook (GEAEExcelWorkbook)
	 * @return	GEAEExcelCellStyle
	 * @since   JDK1.0
	 */
	public static GEAEExcelCellStyle getStyleObjRightNormal9Abs(GEAEExcelWorkbook workBook)
		throws Exception {
		GEAEExcelFont fontObj;
		GEAEExcelCellStyle styleObj;

		fontObj = getNormalFontArial9(workBook);
		styleObj = getRightAlignStyleObject(workBook);
		styleObj.setFont(fontObj);
		styleObj.setDataFormat(GEAEExcelDataFormat.getFormatIndex("0"));
		return styleObj;
	} //end of  method getStyleObjRightNormal9Num

	/**
	 * Method name:	getStyleObjRightBold9Abs
	 * Brief logic:	 This method will return the excel cell style object with normal font
	 * size 9 and right align with number format with absolute value ie without any decimals.
	 * @author	02/19/2004
	 * @version 1.0
	 * @param	workBook (GEAEExcelWorkbook)
	 * @return	GEAEExcelCellStyle
	 * @since   JDK1.0
	 */
	public static GEAEExcelCellStyle getStyleObjRightBold9Abs(GEAEExcelWorkbook workBook)
		throws Exception {
		GEAEExcelFont fontObj;
		GEAEExcelCellStyle styleObj;

		fontObj = getBoldFontArial9(workBook);
		styleObj = getRightAlignStyleObject(workBook);
		styleObj.setFont(fontObj);
		styleObj.setDataFormat(GEAEExcelDataFormat.getFormatIndex("0"));
		return styleObj;
	} //end of  method getStyleObjRightNormal9Num

	/**
	 * Method name:	getStyleObjLeftNormal9Abs
	 * Brief logic:	 This method will return the excel cell style object with normal font
	 * size 9 and left align with number format with absolute value ie without any decimals.
	 * @author	02/19/2004
	 * @version 1.0
	 * @param	workBook (GEAEExcelWorkbook)
	 * @return	GEAEExcelCellStyle
	 * @since   JDK1.0
	 */
	public static GEAEExcelCellStyle getStyleObjLeftNormal9Abs(GEAEExcelWorkbook workBook)
		throws Exception {
		GEAEExcelFont fontObj;
		GEAEExcelCellStyle styleObj;

		fontObj = getNormalFontArial9(workBook);
		styleObj = getLeftAlignStyleObject(workBook);
		styleObj.setFont(fontObj);
		styleObj.setDataFormat(GEAEExcelDataFormat.getFormatIndex("0"));
		return styleObj;
	} //end of  method getStyleObjRightNormal9Num
	/**
	 * Method name:	getStyleObjLeftNormal9Num
	 * Brief logic:	 This method will return the excel cell style object with normal font
	 * size 9 and left align with number format with two decimals.
	 * @author	02/19/2004
	 * @version 1.0
	 * @param	workBook (GEAEExcelWorkbook)
	 * @return	GEAEExcelCellStyle
	 * @since   JDK1.0
	 */
	public static GEAEExcelCellStyle getStyleObjLeftNormal9Num(GEAEExcelWorkbook workBook)
		throws Exception {
		GEAEExcelFont fontObj;
		GEAEExcelCellStyle styleObj;

		fontObj = getNormalFontArial9(workBook);
		styleObj = getLeftAlignStyleObject(workBook);
		styleObj.setFont(fontObj);
		styleObj.setDataFormat(GEAEExcelDataFormat.getFormatIndex("0.00"));
		return styleObj;
	} //end of  method getStyleObjRightNormal9Num
}
