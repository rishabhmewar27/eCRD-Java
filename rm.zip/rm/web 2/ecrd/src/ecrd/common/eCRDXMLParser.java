/*
* Module    	    : eCRDXMLParser.java
* Author      	    : PATNI-Offshore
* Project	        : eCRD
* Date Written		: October 2004
* Security	        : Unclassified
* Restrictions		: GE PROPRIETARY INFORMATION, FOR GE USE ONLY
*
*     ****************************************************
*     *  Copyright (2000) with all rights reserved       *
*     *          General Electric Company                *
*     ****************************************************
*
* Description:  This class is used by CAMConstants for reading the CAM
* application XML and setting all the application constants.
*
* Revision Log  (mm/dd/yy initials description)
* --------------------------------------------------------------
*/

package ecrd.common;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public final class eCRDXMLParser
{
	private String strXMLPath = "";
	private Document doc = null;
	private ArrayList arrAttributes = null;
	private HashMap hmElement = null;
	private HashMap hmAttr = null;

	/** Parses the XML file and creates DOM for it.
	 * @param is InputSource pointing to the XML file.
	 * @param blnValidate If true then XML will be checked against DTD else not.
	 * @throws SAXException
	 * @throws Exception
	 */
	public eCRDXMLParser(InputSource is, boolean blnValidate) throws Exception, SAXException
	{
		// Create the factory and builder
		try
		{
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			factory.setValidating(blnValidate);
			DocumentBuilder builder = factory.newDocumentBuilder();
			//If Validation is required set Error Handler

			// Parse the document
			doc = builder.parse(is);
			org.w3c.dom.Element root = doc.getDocumentElement();
		}
		catch (SAXException e)
		{
			throw new SAXException("eCRDXMLParser:eCRDXMLParser(): " + e.toString());
		}
		catch (Exception e)
		{
			throw new Exception("eCRDXMLParser:constructor: " + e.toString());
		}

	}

	/** Parses the XML file and creates DOM for it.
	 * @param strXMLPath path of the XML file.
	 * @param blnValidate If true then XML will be checked against DTD else not.
	 * @throws SAXException
	 * @throws Exception
	 */
	public eCRDXMLParser(String strXMLPath, boolean blnValidate) throws Exception, SAXException
	{
		try
		{
			this.strXMLPath = strXMLPath;
			// Create the factory and builder
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			factory.setValidating(blnValidate);
			DocumentBuilder builder = factory.newDocumentBuilder();
			// Parse the document
			//doc = builder.parse(strXMLPath);
			doc = builder.parse(new InputSource(new FileReader(strXMLPath)));
		}
		catch (SAXException e)
		{
			throw new SAXException("eCRDXMLParser:eCRDXMLParser(): " + e.toString());
		}
		catch (Exception e)
		{
			throw new Exception("eCRDXMLParser:constructor: " + e.toString());
		}
	}

	/** Method returns HashMap containing Key as element name and the value of
	 * text node.as its value.
	 * @param strElement root element containing these text
	 * nodes. All the elements under these node should have unique name since
	 * element name is being used as Key for putting in HashMap.
	 * @return ArrayList containing the values of text node.
	 * @throws Exception
	 */
	public final HashMap performParse(String strElement) throws Exception
	{
		HashMap hmValue = new HashMap();
		Node nodeTemp = null;
		String strTemp = "";
		String strNodeValue = "";

		try
		{
			NodeList node = doc.getElementsByTagName(strElement);
			Node root = node.item(0);

			//root.normalize();

			if (root.hasChildNodes())
			{
				NodeList child = root.getChildNodes();
				int intLen = child.getLength();
				if (intLen == 1)
				{
					strNodeValue = (child.item(0)).getNodeValue();
					hmValue.put(strElement, strNodeValue);
				}
				int inti;
				for (inti = 1; inti < intLen; inti++)
				{
					nodeTemp = child.item(inti);

					if (Node.ELEMENT_NODE == nodeTemp.getNodeType())
					{
						strTemp = nodeTemp.getNodeName();
					}
					if (!(((nodeTemp).getNodeName()).startsWith("#")))
					{
						strNodeValue = getTextFromNode(child.item(inti));
						if (!hmValue.containsKey(strTemp))
						{
							hmValue.put(strTemp, strNodeValue);
						}
					}
				}
			}
		}
		catch (Exception e)
		{
			throw new Exception("eCRDXMLParser:parse(): " + e.toString());
		}
		finally
		{
			nodeTemp = null;
			strTemp = null;
			strNodeValue = null;
		}
		return hmValue;
	}

	/**
	* Method returns the String contained by the text Node.
	* @param node <code> Node </code> text Node.
	*/
	private final String getTextFromNode(Node node)
	{
		StringBuffer strBuffValue = new StringBuffer();
		NodeList kidNodes = node.getChildNodes();
		if (null != kidNodes && kidNodes.getLength() >= 0)
		{
			try
			{
				if (kidNodes.item(0).getNodeType() == Node.TEXT_NODE)
				{
					strBuffValue.append(kidNodes.item(0).getNodeValue());
				}
			}
			catch (Exception e)
			{
				strBuffValue.setLength(0);
			}
			finally
			{
				kidNodes = null;
			}
		}
		return new String(strBuffValue);
	}

	public String getConstantValue(String strParentNode, String strChildNode) throws Exception
	{
		HashMap hmValue = null;

		hmValue = performParse(strParentNode);
		return (String) hmValue.get(strChildNode);

	}

}
