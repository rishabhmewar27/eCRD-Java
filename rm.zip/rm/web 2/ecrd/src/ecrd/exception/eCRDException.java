/**
 * Module       : eCRDException.java
 * Author       : Patni Offshore
 * Project      : eCRD
 * Date Written : October 2004
 * Security     : Classified/Unclassified
 * Restrictions : GE PROPRIETORY INFORMATION, FOR GE USE ONLY
 *
 *     ***************************************************************
 *     *          Copyright (2000) with all rights reserved          *
 *     *                  General Electric Company                   *
 *     ***************************************************************
 * Description  :  This class has methods to get the Master Tables Data.
 * Revision Log  (mm/dd/yyyy     Initials    description)
 * -------------------------------------------------------------------
 * mm/dd/yyyy     Initials     Description
 * -------------------------------------------------------------------
 *
 */

package ecrd.exception;
import java.util.Iterator;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDUtil;


/**
This is the exception class customized for eCRD. When a new exception is caught, we will have to throw a new eCRDException(strPackageName, strClassName, strMethodName, e.toString()). The constructor will have logic to update the streCRDErrorDesc. as shown below -
streCRDErrorDesc = new String("\nAn Exception has occurred in : " +"\nPackage : " + strPackageName + "\nClass :" +strClassName  +"\nMethod :" +strMethodName +"\nDescription :" +strExceptionDescription);
Later the getErrorDesc() method needs to be called to get the details of the exception.
*/
public class eCRDException extends Exception
{
   private String streCRDErrorDesc = "";
   private String streCRDRExcpId = "";
   private Exception objExp = null;

   public eCRDException()
   {
   }


   /**
   @roseuid 3FC24EA40027
   */
   public String getErrorDesc()
   {
	   return streCRDErrorDesc;
   }

   /**
   @roseuid 4068531F01D7
   */
   public String getErrorIdentifer()
   {
	   return streCRDRExcpId;
   }

   /**
   @roseuid 406DD28C02CD
   */
    public void setExcpId(String strExcpId)
      {
   	   Iterator  itrKeys = null;
   	   boolean blnSuccess = false;
   	   String strException = "";

	   itrKeys = eCRDConstants.hmException.keySet().iterator();
	   if(!"".equals(eCRDUtil.verifyNull(strExcpId)))
	   {
   		   while (itrKeys.hasNext() && blnSuccess == false)
   		   {
   			   strException = (String)itrKeys.next();
   			   if(strExcpId.indexOf(strException)!= -1)
   			   {

   					this.streCRDRExcpId = strException;
   					this.streCRDErrorDesc = (String)eCRDConstants.hmException.get(streCRDRExcpId);
   					blnSuccess = true;
   				}
   		   }
	   }
	   if(blnSuccess == false)
 	   {
			this.streCRDRExcpId = "eCRD_FATAL";
			this.streCRDErrorDesc = (String)eCRDConstants.hmException.get("eCRD_FATAL");
	   }


  }


/**
 * @return
 */
public Exception getObjExp()
{
	return objExp;
}

/**
 * @param exception
 */
public void setObjExp(Exception exception)
{
	objExp = exception;
}

}//end of exception class
