//Source file: D:\\ECRD\\SOURCE CODE\\ecrd\\helper\\eCRDMaintenanceHelper.java
/**
 * Module       : eCRDBatchDownloadUploadHelper.java
 * Author       : Patni Offshore
 * Project      : eCRD
 * Date Written : October 2004
 * Security     : Classified/Unclassified
 * Restrictions : GE PROPRIETORY INFORMATION, FOR GE USE ONLY
 *
 *     ***************************************************************
 *     *          Copyright (2000) with all rights reserved          *
 *     *                  General Electric Company                   *
 *     ***************************************************************
 * Description  :  This class has methods to get the Master Tables Data.
 * Revision Log  (mm/dd/yyyy     Initials    description)
 * -------------------------------------------------------------------
 * mm/dd/yyyy     Initials     Description
 * -------------------------------------------------------------------
  *   31/15/2005     patni  Phase 1 requirement updations 
  *   07/07/2006     patni  Phase 2 requirement updations   
 */
package ecrd.helper;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import ecrd.biz.eCRDCatalog;
import ecrd.biz.eCRDCustomerCatalog;
import ecrd.biz.eCRDDefaultCatalog;
import ecrd.biz.eCRDEngineModel;
import ecrd.biz.eCRDUploadBiz;
import ecrd.biz.eCRDUser;
import ecrd.common.eCRDCommand;
import ecrd.common.eCRDDataBean;
import ecrd.exception.eCRDException;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDUtil;
import geae.dao.GEAEResultSet;

public class eCRDBatchDownloadUploadHelper implements eCRDCommand
{
    /**
	 * Added serial version.
	 */
	private static final long serialVersionUID = 1L;
	private HttpServletRequest request = null;

    public eCRDBatchDownloadUploadHelper()
    {

    }

    /**
     * This method will identify the method to be invoked and also the subsequent
     * screen to be displayed depending on the functionality.
     * Also sets the received request to member variable.
     * @param request
     */
    public String perform(HttpServletRequest request) throws Exception
    {
        String strActionID = null;
        String strCont = null;
        eCRDUploadBiz objUploadBiz = null;
        String strPath = null;
        String strLoggedInUser = null;
        String strSiteName = null;
        eCRDDefaultCatalog objeCRDDefaultCatalog = null;
        eCRDEngineModel objeCRDEngineModel = null;
        eCRDException objeCRDException = null;
        String strCatSeqID = null;
        String strEngModelDesc = null;
        //HashMap hmSheetWiseError = null;
        GEAEResultSet rseCRDBatchUploadErr = null;
        HttpSession session = null;
        /* */
        eCRDDataBean objeCRDDataBean = null;
        eCRDUser objUser = null;
        String strUserRole = null;
        String strRoleIndicator = null;
        /* */
//      18-05-2006 Patni Checking for catalog type Begin  
        eCRDCatalog objCRDCatalog = null;
        String strCatTpye = "";
        eCRDCustomerCatalog objeCRDCustomerCatalog = null;
//      18-05-2006 Patni Checking for catalog type End         
//      27-06-2006 patni added for all sites Begin 
        //String strAllSites ="";
//      27-06-2006 patni added for all sites End  
        
        System.out.print("++++++++++++++++++++++CODE TESTING START+++++++++++++++++++++++++++++++++++++++++++++++++");
        try
        {
            session = (HttpSession)request.getSession();
            strCont = eCRDUtil.verifyNull(request.getParameter("cont"));
            strActionID = eCRDUtil.verifyNull(request.getParameter("hdnScreenAction"));
            objUploadBiz = new eCRDUploadBiz();
            if (strActionID.equals(eCRDConstants.getActionId("eCRD_BATCH_UPLOAD_OP")))
            {
            	strCont = eCRDConstants.STRCONTJSP + "ecrd-batchUploadOperation"; //upload catalog screen
            }

            else if (strActionID.equals(eCRDConstants.getActionId("eCRD_BATCH_UPLOAD")))
            {
            	/*Code to fetch User details*/
                objUser = (eCRDUser)eCRDUtil.getFromSessionApp(request, "objeCRDUser");
                strUserRole = objUser.getRole();
				// 10-08-2007 Patni Checking for CSM Access
                if (eCRDConstants.ROLE_TECH_COORD.equalsIgnoreCase(strUserRole) ||
					eCRDConstants.ROLE_CSM.equalsIgnoreCase(strUserRole))
                {
                    strRoleIndicator = "N";
                }
                if (eCRDConstants.ROLE_ADMINISTRATOR.equalsIgnoreCase(strUserRole))
                {
                    strRoleIndicator = "Y";
                }
                /* Code to fetch Catalog details and Engine model code details*/
//              18-05-2006 Patni Checking for catalog type Begin
                objCRDCatalog = (eCRDCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);     
                
                strCatTpye = objCRDCatalog.getCatalogType();

                if("D".equals(strCatTpye))
                {
                    objeCRDDefaultCatalog =(eCRDDefaultCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG); 
                }
                else
                {
                    objeCRDCustomerCatalog = (eCRDCustomerCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
                }
                
                if (objeCRDDefaultCatalog !=null)
                {
                 objeCRDEngineModel = objeCRDDefaultCatalog.getEngineModel();
                 strCatSeqID = objeCRDDefaultCatalog.getCatalogSeqId();
                }
                else
                {
                    objeCRDEngineModel = objeCRDCustomerCatalog.getEngineModel();
                    strCatSeqID = objeCRDCustomerCatalog.getCatalogSeqId();
                }

                if (objeCRDEngineModel == null)
                {
                    objeCRDException = new eCRDException();
                    objeCRDException.setExcpId("ENGINE_MODEL_NULL");
                    throw objeCRDException;
                }
                
                
                //   objeCRDDefaultCatalog = (eCRDDefaultCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
                
            /*    if (objeCRDDefaultCatalog == null)
                {
                    objeCRDException = new eCRDException();
                    objeCRDException.setExcpId("CATALOG_NOT_SET");
                    throw objeCRDException;
                }*/
               // strCatSeqID = objeCRDDefaultCatalog.getCatalogSeqId();
              //  objeCRDEngineModel = objeCRDDefaultCatalog.getEngineModel();
//              18-05-2006 Patni Checking for catalog type End               
                
                if (objeCRDEngineModel == null)
                {
                    objeCRDException = new eCRDException();
                    objeCRDException.setExcpId("MODEL_NOT_SET");
                    throw objeCRDException;

                }
                strEngModelDesc = objeCRDEngineModel.getEngineModelDesc();

                strPath = (String)request.getParameter("hdnFile");
                strLoggedInUser = (String)request.getRemoteUser();
                strSiteName = (String)request.getParameter("hdnSite");
                            
        
                rseCRDBatchUploadErr = (GEAEResultSet)objUploadBiz.uploadExcel(strActionID, strPath, strLoggedInUser, strSiteName, strCatSeqID, strEngModelDesc, strRoleIndicator);//, strAllSites);
                //delete file after upload
				eCRDUtil.deleteFile(strPath);
                if (rseCRDBatchUploadErr != null && rseCRDBatchUploadErr.size() > 0)
                {
                	session.setAttribute("rseCRDBatchUploadErr", rseCRDBatchUploadErr);
                    objeCRDDataBean = new eCRDDataBean();
                    objeCRDDataBean.setCache(rseCRDBatchUploadErr);
                    eCRDUtil.loadInSession(request, "eCRDBatchUploadErr", objeCRDDataBean);
                    strCont = eCRDConstants.STRCONTJSP + "ecrd-batchUpload"; // new container entry added
                }
                else
                {
                    request.setAttribute("strAlertCode", "UPLOAD_BATCH_SUCCESS");
                    strCont = eCRDConstants.STRCONTJSP + "ecrd-ModifyCatalog"; // Success msg will get displayed

                }
            }
            else if (strActionID.equals(eCRDConstants.getActionId("eCRD_BATCH_UPLOAD_BACK")))
            {
            	strCont = eCRDConstants.STRCONTJSP + "ecrd-batchUploadDownLoad"; //upload catalog screen
            }
            else if (strActionID.equals(eCRDConstants.getActionId("eCRD_COMPONENT_UPLOAD_OP")))
            {
            	strCont = eCRDConstants.STRCONTJSP + "ecrd-ComponentUploadOperation"; //upload catalog screen
            }
            else if (strActionID.equals(eCRDConstants.getActionId("eCRD_COMPONENT_UPLOAD")))
            {
            	strPath  = eCRDUtil.verifyNull(request.getParameter("hdnFile")) ;
                rseCRDBatchUploadErr = (GEAEResultSet)objUploadBiz.uploadComponentExcel(request);
                //delete file after upload
                eCRDUtil.deleteFile(strPath);
                if (rseCRDBatchUploadErr != null && rseCRDBatchUploadErr.size() > 0)
                {
                    session.setAttribute("rseCRDBatchUploadErr", rseCRDBatchUploadErr);
                    objeCRDDataBean = new eCRDDataBean();
                    objeCRDDataBean.setCache(rseCRDBatchUploadErr);
                    eCRDUtil.loadInSession(request, "eCRDBatchUploadErr", objeCRDDataBean);
                    strCont = eCRDConstants.STRCONTJSP + "ecrd-batchComponentUpload"; // new container entry added
                }
                else
                {
                    request.setAttribute("strAlertCode", "UPLOAD_COMPONENT_SUCCESS");
                    strCont = eCRDConstants.STRCONTJSP + "ecrd-viewmodifyComponent"; // Success msg will get displayed
                    
                }
            }
/* 9292 upload functionality of eCRDBatchDownloadUploadMapping  on Feb 2008  */
           else if(strActionID.equals(eCRDConstants.getActionId("eCRD_BATCH_UPLOAD_MAPPING_OP")))
           {
        	   strCont = eCRDConstants.STRCONTJSP + "ecrd-batchUploadMappingOperation"; //upload Batch Component screen
           }
            
           else if(strActionID.equals(eCRDConstants.getActionId("eCRD_BATCH_UPLOAD_MAPPING")))
           {
        	   strPath  = eCRDUtil.verifyNull(request.getParameter("hdnFile")) ;
               rseCRDBatchUploadErr = (GEAEResultSet)objUploadBiz.uploadMappingExcel(request);
              
              //delete file after upload
               eCRDUtil.deleteFile(strPath);
               String result ="";    
               //request.setAttribute("result","");
               session.setAttribute("rseCRDBatchUploadErr","");
               if(rseCRDBatchUploadErr!= null && rseCRDBatchUploadErr.size() > 0){
            	   while(rseCRDBatchUploadErr.next()){
            		   if(rseCRDBatchUploadErr.getString(2).equalsIgnoreCase("COMPONENT MAPPING DATA UPLOADED SUCCESSFULLY")){
            			   result  = "COMPONENT MAPPING DATA UPLOADED SUCCESSFULLY" ;//rseCRDBatchUploadErr.getString(2);
            			   //request.setAttribute("result",result);
            		   }	
            		   else if(rseCRDBatchUploadErr.getString(2).equalsIgnoreCase("EXCEL HAS NO MAPPING DATA TO UPLOAD")){
            			   result  = "EXCEL HAS NO MAPPING DATA TO UPLOAD" ;//rseCRDBatchUploadErr.getString(2);
            			   //request.setAttribute("result",result);
            		   }
            		   else if(rseCRDBatchUploadErr.getString(2).equalsIgnoreCase("Exceeded the maximum number of row limit.")){
            			   result  = "EXCEEDED THE MAXIMUM NUMBER OF ROW LIMIT" ;//rseCRDBatchUploadErr.getString(2);
            			   //request.setAttribute("result",result);
            		   }
            		   else{
            			   result  = rseCRDBatchUploadErr.getString(2);
             			  // request.setAttribute("result",result);
            		   }
            	   }
            	   request.setAttribute("result",result);

               }
               if (rseCRDBatchUploadErr != null && rseCRDBatchUploadErr.size() > 0)
               {
            	   session.setAttribute("rseCRDBatchUploadErr", rseCRDBatchUploadErr);
                   objeCRDDataBean = new eCRDDataBean();
            	   objeCRDDataBean.setCache(rseCRDBatchUploadErr);
            	   eCRDUtil.loadInSession(request, "eCRDBatchUploadErr", objeCRDDataBean);
            	   strCont = eCRDConstants.STRCONTJSP + "ecrd-batchUploadMapping"; // new container entry added
               }
               else
               {
            	   request.setAttribute("strAlertCode", "MAPPING_DATA_UPLOAD_SUCCESSFULL");//Make eCRDConstants entry
            	   strCont = eCRDConstants.STRCONTJSP + "ecrd-batchUploadDownLoadMapping"; // Success msg will get displayed
               }
           }
           else if (strActionID.equals(eCRDConstants.getActionId("eCRD_BATCH_UPLOAD_MAPPING_BACK")))
           {	
        	   strCont = eCRDConstants.STRCONTJSP + "ecrd-batchUploadDownLoadMapping"; //Batch Download Upload Mapping screen
           }
/* End */           
        }
        finally
        {
            strActionID = null;
            objUploadBiz = null;
            strPath = null;
            strLoggedInUser = null;
            strSiteName = null;
            objeCRDDefaultCatalog = null;
            objeCRDEngineModel = null;
            objeCRDException = null;
            strCatSeqID = null;
            strEngModelDesc = null;
            rseCRDBatchUploadErr = null;
            session = null;
            objeCRDDataBean = null;
            objUser = null;
            strUserRole = null;
            strRoleIndicator = null;
        }
        return strCont;
    }

    /**
     * request: action=loadlaborrate
     * loads the labor rates.
     */
    private void loadLaborRateConfig()
    {

    }

    /**
     * request: action=savelaborrate
     * Stores Labor Rate configuration.
     */
    private void saveLaborRateConfig()
    {

    }

    /**
     * request: action=loadcycvalconfig
     * Load Cycle Validation class configuration.
     */
    private void loadCycleValidationConfig()
    {

    }

    /**
     * request: action=savecycvalconfig
     * Save Cycle Validation class configuration.
     */
    private void saveCycleValidationConfig()
    {

    }

}
