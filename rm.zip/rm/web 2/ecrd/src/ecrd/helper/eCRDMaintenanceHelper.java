//Source file: D:\\ECRD\\SOURCE CODE\\ecrd\\helper\\eCRDMaintenanceHelper.java

/**
 * Module       : eCRDMaintenanceHelper.java
 * Author       : Patni Offshore
 * Project      : eCRD
 * Date Written : October 2004
 * Security     : Classified/Unclassified
 * Restrictions : GE PROPRIETORY INFORMATION, FOR GE USE ONLY
 *
 *     ***************************************************************
 *     *          Copyright (2000) with all rights reserved          *
 *     *                  General Electric Company                   *
 *     ***************************************************************
 * Description  :  This class has methods to get the Master Tables Data.
 * Revision Log  (mm/dd/yyyy     Initials    description)
 * -------------------------------------------------------------------
 * mm/dd/yyyy     Initials     Description
 * -------------------------------------------------------------------
 */

package ecrd.helper;

import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import ecrd.biz.eCRDCatalog;
import ecrd.biz.eCRDComponent;
import ecrd.biz.eCRDDefaultCatalog;
import ecrd.biz.eCRDEngineModel;
import ecrd.biz.eCRDModule;
import ecrd.biz.eCRDUser;
import ecrd.common.eCRDBusinessBean;
import ecrd.common.eCRDCommand;
import ecrd.common.eCRDDBMediator;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDLoadMaster;
import ecrd.util.eCRDUtil;
import geae.dao.GEAEResultSet;

public class eCRDMaintenanceHelper implements eCRDCommand
{
	private HttpServletRequest request = null;

	public eCRDMaintenanceHelper()
	{

	}

	/**
	 * This method will identify the method to be invoked and also the subsequent 
	 * screen to be displayed depending on the functionality.
	 * Also sets the received request to member variable.
	 * @param request
	 */
	public String perform(HttpServletRequest request) throws Exception
	{
		String strForwardURL = null;
		String strScreenAction = "";
		try
		{
			strScreenAction = eCRDUtil.verifyNull(request.getParameter("hdnScreenAction"));
			if ((eCRDConstants.getActionId("eCRD_VIEW_LABOR_RATES")).equals(strScreenAction))
			{
				// To get the list of sites and corresponding labor rate
				loadLaborRateConfig(request);
				strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-maintLaborRates";
			}
			else if ((eCRDConstants.getActionId("eCRD_SAVE_LABOR_RATES")).equals(strScreenAction))
			{
				// To save the changed labor rate for corresponding sites
				saveLaborRateConfig(request,strScreenAction);
				strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-maintLaborRates";
			}
			else if ((eCRDConstants.getActionId("eCRD_FIND_COMP")).equals(strScreenAction))
			{
				strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-successRepair";
			}
			else if ((eCRDConstants.getActionId("eCRD_PRICE_ADJUSTMENT_LINK")).equals(strScreenAction))
			{
				eCRDUtil.clearSession(request);
				strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-priceAdjustment";
			}
			else if ((eCRDConstants.getActionId("eCRD_PRICE_ADJUSTMENT")).equals(strScreenAction))
			{
				showEngineModuleList(request);
				strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-priceAdjustment";
			}
			else if ((eCRDConstants.getActionId("eCRD_SAVE_PRICE_ADJUSTMENT")).equals(strScreenAction))
			{
				savePriceAdjustment(request);
				strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-priceAdjustment";
			}
			// Maintain Cycle Validation Frequency
			else if ((eCRDConstants.getActionId("eCRD_MAINTAIN_CYCLE_VALIDATION_FREQ")).equals(strScreenAction))
			{
				// To get the list of cycle class and notification period
				loadCycleValidationConfig(request);
				strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-maintCycleValdFreq";
			}
			// Save Changed Class Notification Period
			else if ((eCRDConstants.getActionId("eCRD_SAVE_NOTIFICATION_PERIOD")).equals(strScreenAction))
			{
				// To get the list of cycle class and notification period
				saveCycleValidationConfig(request,strScreenAction);
				strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-maintCycleValdFreq";
			}
			return strForwardURL;
		}
		finally
		{
			strForwardURL = null;
			strScreenAction = "";
		}
	}
	/**
	 * request: action=loadlaborrate
	 * loads the labor rates.
	 */
	private void loadLaborRateConfig(HttpServletRequest request) throws Exception
	{
		ArrayList arrlstInpParam = null;
		String strActionId = null;
		eCRDBusinessBean objeCRDBusinessBean = null;
		GEAEResultSet rsLaborRate = null;
		try
		{
			objeCRDBusinessBean = new eCRDBusinessBean();
			//Set the action id to call procedure to list repairs for the selected component
			strActionId = eCRDConstants.getActionId("eCRD_VIEW_LABOR_RATES");
			//ArrayList of Input Parameters
			arrlstInpParam = new ArrayList();
			// Call this function to retrieve details of repairs from database
			rsLaborRate = objeCRDBusinessBean.populateComponentList(strActionId,arrlstInpParam);
			//Set all parameters as retrieved from the database
			rsLaborRate.setCurrentRow(0);
			request.setAttribute("rsLaborRate",rsLaborRate);
		}
		finally
		{
			arrlstInpParam = null;
			strActionId = null;
			rsLaborRate = null;
			objeCRDBusinessBean = null;
		}
	}
	/**
		 * request: action=eCRDSavePriceAdjustment
		 * Updates Price for All the repairs under that component.
		 */
	private void savePriceAdjustment(HttpServletRequest request) throws Exception
	{
		String strMessage = null;
		eCRDComponent objeCRDComponent = null;
		String strEngineModel = null;
		String strEngineModule = null;
		String strPriceValue = null;
		String strEffectiveDate = null;
		String strEngineModuleDesc = null;

		String strPriceType = null;
		String struserId = null;
		String strComponent = null;
		String strComponentCode = null;
		ArrayList arrlstInpParam = null;
		eCRDUser objeCRDUser = null;
		String strActionId = null;
		eCRDModule objeCRDModule = null;
		eCRDEngineModel objeCRDEngineModel = null;
		eCRDDefaultCatalog objeCRDDefaultCatalog = null;

		try
		{
			arrlstInpParam = new ArrayList();
			objeCRDUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser");
			strEngineModel = eCRDUtil.verifyNull(request.getParameter("hdnEngineModelDesc"));
			strEngineModule = eCRDUtil.verifyNull(request.getParameter("lstEngineModule"));
			strEngineModuleDesc = eCRDUtil.verifyNull(request.getParameter("hdnEngineModuleDesc"));
			strPriceValue = eCRDUtil.verifyNull(request.getParameter("txtPriceVal"));
			strEffectiveDate = eCRDUtil.verifyNull(request.getParameter("hdnEffectiveDate"));
			strPriceType = eCRDUtil.verifyNull(request.getParameter("rdIncDec"));
			strComponent = eCRDUtil.verifyNull(request.getParameter("hdnComponent"));
			strActionId = eCRDUtil.verifyNull(request.getParameter("hdnScreenAction"));
			strComponentCode = eCRDUtil.verifyNull(request.getParameter("txtComponent"));
			struserId = objeCRDUser.getUserId();

			objeCRDDefaultCatalog = (eCRDDefaultCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
			objeCRDEngineModel = objeCRDDefaultCatalog.getEngineModel();
			objeCRDModule = objeCRDEngineModel.addModule();
			objeCRDModule.setModuleCode(strEngineModule);
			objeCRDModule.setModuleDesc(strEngineModuleDesc);
			objeCRDComponent = objeCRDModule.getComponent(strComponentCode);

			arrlstInpParam.add(strEngineModel);
			arrlstInpParam.add(strEngineModule);
			arrlstInpParam.add(strComponent);
			arrlstInpParam.add(strComponentCode);
			arrlstInpParam.add(strPriceType);
			arrlstInpParam.add(strPriceValue);
			arrlstInpParam.add(strEffectiveDate);
			arrlstInpParam.add(struserId);

			strMessage = objeCRDComponent.savePriceAdjusment(strActionId, arrlstInpParam);
			request.setAttribute("strMessage", strMessage);
			objeCRDComponent.setModule(objeCRDModule);
			objeCRDModule.setEngineModel(objeCRDEngineModel);
			objeCRDEngineModel.setCatalog(objeCRDDefaultCatalog);
			eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDDefaultCatalog);
		}
		finally
		{
			strMessage = null;
			objeCRDComponent = null;
			strEngineModel = null;
			strEngineModule = null;
			strPriceValue = null;
			strEffectiveDate = null;
			strEngineModuleDesc = null;

			strPriceType = null;
			struserId = null;
			strComponent = null;
			strComponentCode = null;
			arrlstInpParam = null;
			objeCRDUser = null;
			strActionId = null;
			objeCRDModule = null;
			objeCRDEngineModel = null;
			objeCRDDefaultCatalog = null;
		}
	}
	/**
		 * request: action=savelaborrate
		 * Stores Labor Rate configuration.
		 */

	private void saveLaborRateConfig(HttpServletRequest request,String strActionId) throws Exception
	{
		ArrayList arrlstInpParam = null;
		ArrayList arrlstOutParam = null;
		eCRDUser objeCRDUser = null;
		try
		{
			//ArrayList of Input Parameters
			arrlstInpParam = new ArrayList();
			//ArrayList of Output Parameters
			arrlstOutParam = new ArrayList();
			// Get the user object from the session
			objeCRDUser = (eCRDUser)eCRDUtil.getFromSessionApp(request, "objeCRDUser");
			arrlstInpParam.add(objeCRDUser.getUserId());
			arrlstInpParam.add(eCRDUtil.verifyNull(request.getParameter("hdnSiteLaborRateList")));
			arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);
			// Set the output message in request.
			request.setAttribute("rsLaborRate",(GEAEResultSet)arrlstOutParam.get(0));
			request.setAttribute("strMessage",arrlstOutParam.get(1));
		}
		finally
		{
			arrlstInpParam = null;
			arrlstOutParam = null;
			objeCRDUser = null;
		}
	}
	/**
	 * request: action=loadcycvalconfig
	 * Load Cycle Validation class configuration.
	 */
	private void loadCycleValidationConfig(HttpServletRequest request) throws Exception
	{
		ArrayList arrlstInpParam = null;
		eCRDBusinessBean objeCRDBusinessBean = null; 
		String strActionId = null;
		GEAEResultSet rsClassList = null;
		try
		{
			objeCRDBusinessBean = new eCRDBusinessBean();
			//Set the action id to call procedure to list repairs for the selected component
			strActionId = eCRDConstants.getActionId("eCRD_MAINTAIN_CYCLE_VALIDATION_FREQ");
			//ArrayList of Input Parameters
			arrlstInpParam = new ArrayList();
			//ArrayList of Output Parameters
			// Call this function to retrieve details of repairs from database
			rsClassList = objeCRDBusinessBean.populateComponentList(strActionId,arrlstInpParam);
			rsClassList.setCurrentRow(0);
			request.setAttribute("rsClassList",rsClassList);			
		}
		finally
		{
			arrlstInpParam = null;
			strActionId = null;
			rsClassList = null;
			objeCRDBusinessBean = null;
		}
	}
	/**
	 * request: action=savecycvalconfig
	 * Save Cycle Validation class configuration.
	 */
	private void saveCycleValidationConfig(HttpServletRequest request,String strActionId) throws Exception
	{
		ArrayList arrlstInpParam = null;
		ArrayList arrlstOutParam = null;
		eCRDUser objeCRDUser = null;
		try
		{
			//ArrayList of Input Parameters
			arrlstInpParam = new ArrayList();
			//ArrayList of Output Parameters
			arrlstOutParam = new ArrayList();
			// Get the user object from the session
			objeCRDUser = (eCRDUser)eCRDUtil.getFromSessionApp(request, "objeCRDUser");
			// Adding parameters to input arraylist
			arrlstInpParam.add(objeCRDUser.getUserId());
			arrlstInpParam.add(eCRDUtil.verifyNull(request.getParameter("hdnClassPeriodList")));
			arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);
			// Set the output message in request.
			request.setAttribute("rsClassList",(GEAEResultSet)arrlstOutParam.get(0));
			request.setAttribute("strMessage",arrlstOutParam.get(1));
		}
		finally
		{
			arrlstInpParam = null;
			arrlstOutParam = null;
			objeCRDUser = null;
		}
	}
	private void showEngineModuleList(HttpServletRequest request) throws Exception
	{
		GEAEResultSet rsEngineModule = null;
		String strEngineModel = null;
		String strEngineModelDesc = null;
		eCRDDefaultCatalog objeCRDDefaultCatalog = null;
		eCRDEngineModel objeCRDEngineModel = null;
		try
		{
			strEngineModel = eCRDUtil.verifyNull(request.getParameter("hdnEngineModelDesc"));
			strEngineModelDesc = eCRDUtil.verifyNull(request.getParameter("hdnEngineModelDescription"));
			objeCRDDefaultCatalog = (eCRDDefaultCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
			if (objeCRDDefaultCatalog == null)
			{
				objeCRDDefaultCatalog = new eCRDDefaultCatalog(eCRDCatalog.getCurrentDefaultSeqId(strEngineModel));
			}
			/*added new */
			objeCRDEngineModel = objeCRDDefaultCatalog.getEngineModel();
			if (objeCRDEngineModel == null)
			{
				objeCRDEngineModel = new eCRDEngineModel();
				objeCRDDefaultCatalog.setEngineModel(objeCRDEngineModel);
				objeCRDEngineModel.setEngineModelCode(strEngineModel);
				objeCRDEngineModel.setEngineModelDesc(strEngineModelDesc);
			}
			if (!strEngineModel.equals(""))
			{
				rsEngineModule = eCRDLoadMaster.getMasterModuleList(strEngineModel);
				eCRDUtil.loadInSession(request, "rsEngineModule", rsEngineModule);
			}
			objeCRDDefaultCatalog.setEngineModel(objeCRDEngineModel);
			eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDDefaultCatalog);
			eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODELCODE, strEngineModel);
		}
		finally
		{
			rsEngineModule = null;
			strEngineModel = null;
		}
	}
}