//Source file: D:\\ECRD\\SOURCE CODE\\ecrd\\helper\\eCRDManageApprovalsHelper.java
/**
 * Module       : eCRDManageApprovalsHelper.java
 * Author       : Patni Offshore
 * Project      : eCRD
 * Date Written : October 2004
 * Security     : Classified/Unclassified
 * Restrictions : GE PROPRIETORY INFORMATION, FOR GE USE ONLY
 *
 *     ***************************************************************
 *     *          Copyright (2000) with all rights reserved          *
 *     *                  General Electric Company                   *
 *     ***************************************************************
 * Description  :  This class has methods to get the Master Tables Data.
 * Revision Log  (mm/dd/yyyy     Initials    description)
 * -------------------------------------------------------------------
 * mm/dd/yyyy     Initials     Description
 * -------------------------------------------------------------------
 *   31/15/2005     patni  Phase 1 requirement updations
 */

package ecrd.helper;

import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import ecrd.util.eCRDSearchBean;
import ecrd.biz.eCRDComponent;
import ecrd.biz.eCRDComponentApproval;
import ecrd.biz.eCRDDefaultCatalog;
import ecrd.biz.eCRDEngineModel;
import ecrd.biz.eCRDModule;
import ecrd.biz.eCRDRepair;
import ecrd.biz.eCRDRepairApproval;
import ecrd.biz.eCRDRepairPricing;
import ecrd.biz.eCRDUser;
import ecrd.common.eCRDCommand;
import ecrd.common.eCRDDataBean;
import ecrd.common.eCRDSessionMap;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDUtil;
import geae.dao.GEAEResultSet;
import geae.util.format.GEAETag;

public class eCRDManageApprovalsHelper implements eCRDCommand
{
	//private HttpServletRequest request = null;

	GEAEResultSet rsFormatted = null;
	GEAEResultSet rsFormattedRS = null;
	public eCRDManageApprovalsHelper()
	{

	}

	/**
	 * Based "action" attribute from the request, this function calls the appropriate
	 * private functions in this class.
	 * Also sets the received request to member variable.
	 * @param request
	 */
	public String perform(HttpServletRequest request) throws Exception
	{
		String strActionID = "";
		String strCont = "";
		String strFlag = "";
		String strMessage = "";
		String strRepairModfy = "";
		String strFrom = "";
		try
		{

			strCont = eCRDUtil.verifyNull(request.getParameter("cont"));
			strActionID = eCRDUtil.verifyNull(request.getParameter("hdnScreenAction"));
			if (strActionID.equals(eCRDConstants.getActionId("eCRD_GET_APPROVAL_COMPONENTS")))
			{
				eCRDUtil.clearSession(request);
				listComponentApprovals(strActionID, request);
				strCont = eCRDConstants.STRCONTJSP + "ecrd-approveComponent";
			}
			else if (strActionID.equals(eCRDConstants.getActionId("eCRD_SHOW_COMP_APPR_DETAILS")))
			{
				strFlag = eCRDUtil.verifyNull(request.getParameter("flag"));
				strFrom = (String) eCRDUtil.getFromSession(request, "strFrom");
				loadComponentApprovalDetails(request);
				if (strFlag.equals(""))
				{
					if (strFrom.equals("Approval"))
					{
						strFlag = "N";
					}
					else if (strFrom.equals("ModifyCompApproval"))
					{
						strFlag = "M";
					}
				}
				if (strFlag.equals("M"))
				{
					strCont = eCRDConstants.STRCONTJSP + "ecrd-showOldCompApprDet";
				}
				else
				{
					strCont = eCRDConstants.STRCONTJSP + "ecrd-showNewCompApprDet";
				}
			}
			else if (strActionID.equals(eCRDConstants.getActionId("eCRD_INSERT_COMP_APPROVAL_DET")))
			{
				strMessage = approveComponent(request);
				if("NOTUNIQUEDESC".equals(strMessage))
				{
					strCont = eCRDConstants.STRCONTJSP + "ecrd-showOldCompApprDet";
				}
				else
				{
		    			listComponentApprovals(eCRDConstants.getActionId("eCRD_GET_APPROVAL_COMPONENTS"), request);
					strCont = eCRDConstants.STRCONTJSP + "ecrd-approveComponent";
				}
			}
			else if (strActionID.equals(eCRDConstants.getActionId("eCRD_REJECT_COMP_APPROVAL_DET")))
			{
				strMessage = rejectComponent(request);
				listComponentApprovals(eCRDConstants.getActionId("eCRD_GET_APPROVAL_COMPONENTS"), request);
				strCont = eCRDConstants.STRCONTJSP + "ecrd-approveComponent";
			}
			else if (strActionID.equals(eCRDConstants.getActionId("eCRD_GET_APPROVAL_REPAIR_LIST")))
			{
				eCRDUtil.clearSession(request);
				listRepairApprovals(strActionID, request);
				strCont = eCRDConstants.STRCONTJSP + "ecrd-approveRepair";
			}
			else if (strActionID.equals(eCRDConstants.getActionId("eCRD_LOAD_APPROVAL_REPAIR_DET")))
			{

				strRepairModfy = request.getParameter("hdnFlag");

                strFrom = (String) eCRDUtil.getFromSession(request, "strFrom");

                loadRepairsApprovals(request);

                if (strRepairModfy == null || strRepairModfy.equals(""))
				{
					if (strFrom.equals("ModRepairApproval"))
					{
						strRepairModfy = "M";
					}
					else
					{
						strRepairModfy = "N";
					}
				}
				if (strRepairModfy.equals("M"))
				{
					strCont = eCRDConstants.STRCONTJSP + "ecrd-showOldRepairApprDet";
				}
				else
				{
					strCont = eCRDConstants.STRCONTJSP + "ecrd-showNewRepairApprDet";
				}
			}
			else if (strActionID.equals(eCRDConstants.getActionId("eCRD_APPROVE_IND_REPAIR")))
			{
				ApproveRepair(request);


                //Patni 16-06-2006 Clearing the session values Begin
                eCRDUtil.clearSession(request);
                //Patni 16-06-2006 Clearing the session values End
				listRepairApprovals(eCRDConstants.getActionId("eCRD_GET_APPROVAL_REPAIR_LIST"), request);
				strCont = eCRDConstants.STRCONTJSP + "ecrd-approveRepair";
			}
			else if (strActionID.equals(eCRDConstants.getActionId("eCRD_APPRV_GRP_REPAIR")))
			{
				ApproveRepair(request);


                //Patni 16-06-2006 Clearing the session values Begin
                eCRDUtil.clearSession(request);
               //Patni 16-06-2006 Clearing the session values End

				listRepairApprovals(eCRDConstants.getActionId("eCRD_GET_APPROVAL_REPAIR_LIST"), request);
				strCont = eCRDConstants.STRCONTJSP + "ecrd-approveRepair";
			}
			else if (strActionID.equals(eCRDConstants.getActionId("eCRD_REJECT_REPAIR")))
			{
				rejectRepair(request);

                //
                //Patni 16-06-2006 Clearing the session values Begin
                eCRDUtil.clearSession(request);
                //Patni 16-06-2006 Clearing the session values End
				listRepairApprovals(eCRDConstants.getActionId("eCRD_GET_APPROVAL_REPAIR_LIST"), request);
				strCont = eCRDConstants.STRCONTJSP + "ecrd-approveRepair";
			}
			else if (strActionID.equals(eCRDConstants.getActionId("eCRD_SHOW_COMPONENT_APPR_HIST")))
			{
				listComponentApprovalsHist(strActionID, request);
				strCont = eCRDConstants.STRCONTJSP + "ecrd-showComponentApprHist";
			}
			else if (strActionID.equals(eCRDConstants.getActionId("eCRD_SHOW_REPAIR_APPR_HIST")))
			{
				listRepairApprovalsHist(strActionID, request);
				strCont = eCRDConstants.STRCONTJSP + "ecrd-showRepairApprHist";
			}
			/*   else if(strActionID.equals("getCompSites")){

			}
			else if(strActionID.equals("getRepairApprovals")){

			}
			else if(strActionID.equals("")){
			}*/

		}
		finally
		{

		}
		return strCont;
	}

	/**
	 * This method gets the list of Components pending for Approval
	 * @param None
	 * @return void
	 */
	private void listComponentApprovals(String strActionID, HttpServletRequest request) throws Exception
	{
		ArrayList arrLstOutParam = new ArrayList();
		HttpSession session = request.getSession();
		eCRDComponentApproval objCompApprv = null;
		GEAEResultSet rsApprvComp = null;
		eCRDDataBean objeCRDDataBean = null;
		eCRDUser objeCRDUser = null;
		String strRole = null;
		String strUserId = null;
		try
		{
			objeCRDDataBean = (eCRDDataBean) session.getAttribute("objeCRDDataBean");
			if (objeCRDDataBean == null)
			{
				objeCRDDataBean = new eCRDDataBean();
				session.setAttribute("objeCRDDataBean", objeCRDDataBean);
			}
			objeCRDUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser");
			strRole = objeCRDUser.getRole();
			strUserId = objeCRDUser.getUserId();
			//method to be called to perform doDBoperation from bean
			objCompApprv = new eCRDComponentApproval();
			arrLstOutParam = objCompApprv.getApprovalComp(strActionID, strRole, strUserId);
			//formating of the resultset obtained
			rsApprvComp = (GEAEResultSet) arrLstOutParam.get(0);
			if (eCRDConstants.ROLE_TECH_COORD.equals(strRole))
			{
				rsFormatted = formatTCResultSet(rsApprvComp);
			}
			else if (eCRDConstants.ROLE_ADMINISTRATOR.equals(strRole))
			{
				rsFormatted = formatResultSet(rsApprvComp);
			}

			//Setting the formatted result set in the Data Bean
			objeCRDDataBean.setCache(rsFormatted);
			eCRDUtil.loadInSession(request, "objeCRDDataBean", objeCRDDataBean);
			//session.setAttribute("objeCRDDataBean",objeCRDDataBean);
		}
		finally
		{
			arrLstOutParam = new ArrayList();
			session = request.getSession();
			objCompApprv = null;
			rsApprvComp = null;
			objeCRDDataBean = null;
			objeCRDUser = null;
			strRole = null;
			strUserId = null;
		}

	}

	public GEAEResultSet formatResultSet(GEAEResultSet rsSearchResults) throws Exception
	{
		String strCompCode = "";
		String strCompDesc = "";
		String strEngModelCode = "";
		String strEngModelDesc = "";
		String strEngModuleCode = "";
		String strEngModuleDesc = "";
		String strRequestedBy = "";
		String strRequesedDate = "";
		String strFlg = "";
		String strUrlAdditionChange = "";
		String strNoTagChange = "";
		String strSortableRequesedDate = null;
		rsFormattedRS = new GEAEResultSet();
		ArrayList arrlstTemp = null;
		GEAETag geAETag = null;
		GEAETag geNoTag = null;
		try
		{
			rsFormattedRS = new GEAEResultSet();
			rsSearchResults.setCurrentRow(0);
//        19-05-2006 patni checking null value Begin
            if (rsSearchResults != null )
            {
//              19-05-2006 patni checking null value End
            while (rsSearchResults.next())
			{
				strCompCode = eCRDUtil.verifyNull(rsSearchResults.getString("COMP_CODE"));
				strCompDesc = eCRDUtil.verifyNull(rsSearchResults.getString("COMP_DESC"));
				strEngModelCode = eCRDUtil.verifyNull(rsSearchResults.getString("MODEL_CODE"));
				strEngModelDesc = eCRDUtil.verifyNull(rsSearchResults.getString("MODEL_DESC"));
				strEngModuleCode = eCRDUtil.verifyNull(rsSearchResults.getString("MODULE_CODE"));
				strEngModuleDesc = eCRDUtil.verifyNull(rsSearchResults.getString("MODULE_DESC"));
				strFlg = eCRDUtil.verifyNull(rsSearchResults.getString("FLG"));
				strRequestedBy = eCRDUtil.verifyNull(rsSearchResults.getString("USER_NAME"));
				strRequesedDate = eCRDUtil.verifyNull(rsSearchResults.getString("REQ_DATE"));
				strSortableRequesedDate = eCRDUtil.verifyNull(rsSearchResults.getString("SORTABLE_REQ_DATE"));
				arrlstTemp = new ArrayList();
				strUrlAdditionChange =
					eCRDConstants.STRCTRL
						+ "?hdnCompCode="
						+ strCompCode
						+ "&hdnModelCode="
						+ strEngModelCode
						+ "&hdnModuleCode="
						+ strEngModuleCode
                  //  06-06-06 Patni Added model desc to pass jsp Begin
                        +"&hdnEngModleDesc="
                        + strEngModelDesc
                        //   06-06-06 Patni Added model desc to pass jsp End
						+ "&hdnScreenName=ApprCompDet&hdnScreenAction="
                        + eCRDConstants.getActionId("eCRD_SHOW_COMP_APPR_DETAILS")
						+ "&flag="
						+ strFlg;
				geAETag = new GEAETag(strCompCode, "<A href='" + eCRDUtil.getBasePath() + "" + strUrlAdditionChange + "'>" + strCompCode + "</A>");
				arrlstTemp.add(geAETag);
				arrlstTemp.add(strCompDesc);
				arrlstTemp.add(strEngModelDesc);
				arrlstTemp.add(strEngModuleDesc);
				arrlstTemp.add(strRequestedBy);
				//arrlstTemp.add(strRequesedDate);
				geAETag = new GEAETag(strSortableRequesedDate,strRequesedDate);
				arrlstTemp.add(geAETag);

				//Adding the image depending upon whether the component is new or not
				if (strFlg.equals("N"))
				{
					strNoTagChange = "<IMG src='" + eCRDUtil.getBasePath() + eCRDConstants.STRCTRL + "/img/icon_checkmark.gif' ALT='' width='20' height='20'></IMG>";
					geNoTag = new GEAETag("", strNoTagChange);
				}
				else
				{
					geNoTag = new GEAETag("", "");
				}
				arrlstTemp.add(geNoTag);
				rsFormattedRS.addRow(arrlstTemp);
			}
//          19-05-2006 patni checking null value Begin
            } //End if
//          19-05-2006 patni checking null value End
			rsFormattedRS.setColumnHeading(1, "Component Code");
			rsFormattedRS.setColumnHeading(2, "Component Description");
			rsFormattedRS.setColumnHeading(3, "Engine Model");
			rsFormattedRS.setColumnHeading(4, "Engine Module");
			rsFormattedRS.setColumnHeading(5, "Requested By");
			rsFormattedRS.setColumnHeading(6, "Requested Date");
			rsFormattedRS.setColumnHeading(7, "New");
			rsFormattedRS.sort(1, true);
		}
		finally
		{
			strSortableRequesedDate = null;
		}
		return rsFormattedRS;
	}

	public GEAEResultSet formatTCResultSet(GEAEResultSet rsSearchResults) throws Exception
	{
		String strCompCode = null;
		String strCompDesc = null;
		String strEngModelDesc = null;
		String strEngModuleDesc = null;
		String strRequestedBy = null;
		String strRequesedDate = null;
		String strFlg = null;
		String strNoTagChange = null;
		String strSortableRequesedDate = null;
		ArrayList arrlstTemp = null;
		GEAEResultSet rsFormattedRS = null;
		GEAETag geAETag = null;
		GEAETag geNoTag = null;
		try
		{
			rsFormattedRS = new GEAEResultSet();

            rsSearchResults.setCurrentRow(0);
			// 19-05-2006 Patni checking result set null value Begin
            if(rsSearchResults!=null)
            {
//         19-05-2006 Patni checking result set null value End
            while (rsSearchResults.next())
			{
				strCompCode = eCRDUtil.verifyNull(rsSearchResults.getString("COMP_CODE"));
				strCompDesc = eCRDUtil.verifyNull(rsSearchResults.getString("COMP_DESC"));
				strEngModelDesc = eCRDUtil.verifyNull(rsSearchResults.getString("MODEL_DESC"));
				strEngModuleDesc = eCRDUtil.verifyNull(rsSearchResults.getString("MODULE_DESC"));
				strFlg = eCRDUtil.verifyNull(rsSearchResults.getString("FLG"));
				strRequestedBy = eCRDUtil.verifyNull(rsSearchResults.getString("USER_NAME"));
				strRequesedDate = eCRDUtil.verifyNull(rsSearchResults.getString("REQ_DATE"));
				strSortableRequesedDate = eCRDUtil.verifyNull(rsSearchResults.getString("SORTABLE_REQ_DATE"));
				arrlstTemp = new ArrayList();
				arrlstTemp.add(strCompCode);
				arrlstTemp.add(strCompDesc);
				arrlstTemp.add(strEngModelDesc);
				arrlstTemp.add(strEngModuleDesc);
				arrlstTemp.add(strRequestedBy);
				//arrlstTemp.add(strRequesedDate);
				geAETag = new GEAETag(strSortableRequesedDate,strRequesedDate);
				arrlstTemp.add(geAETag);

				if (strFlg.equals("N"))
				{
					strNoTagChange = "<IMG src='" + eCRDUtil.getBasePath() + eCRDConstants.STRCTRL + "/img/icon_checkmark.gif' ALT='' width='20' height='20'></IMG>";
					geNoTag = new GEAETag("", strNoTagChange);
				}
				else
				{
					geNoTag = new GEAETag("", "");
				}
				arrlstTemp.add(geNoTag);
				rsFormattedRS.addRow(arrlstTemp);
			}
//          19-05-2006 Patni checking result set null value Begin
            } // End if
//          19-05-2006 Patni checking result set null value End
			rsFormattedRS.setColumnHeading(1, "Component Code");
			rsFormattedRS.setColumnHeading(2, "Component Description");
			rsFormattedRS.setColumnHeading(3, "Engine Model");
			rsFormattedRS.setColumnHeading(4, "Engine Module");
			rsFormattedRS.setColumnHeading(5, "Requested By");
			rsFormattedRS.setColumnHeading(6, "Requested Date");
			rsFormattedRS.setColumnHeading(7, "New");
			rsFormattedRS.sort(1, true);
		}
		finally
		{
			strCompCode = null;
			strCompDesc = null;
			strEngModelDesc = null;
			strEngModuleDesc = null;
			strRequestedBy = null;
			strRequesedDate = null;
			strFlg = null;
			strNoTagChange = null;
			arrlstTemp = null;
			geNoTag = null;
		}
		return rsFormattedRS;
	}

	/**
	 * request: action=load
	 * Load approval details including details of the entity (Component, Site,
	 * Request) that needs to be approved..
	 */
	private void loadComponentApprovalDetails(HttpServletRequest request) throws Exception
	{
		String strSeqId = "";
		String strModelCode = "";
		String strModuleCode = "";
		String strCompSeqId = "";
		HttpSession session = null;
		eCRDDefaultCatalog objCatalog = null;
		eCRDEngineModel objModel = null;
		eCRDModule objModule = null;
		eCRDComponent objComponent = null;
		eCRDSessionMap objSessionMap = null;
		String strCompType = "";
		String strFrom = "";
		try
		{
			session = request.getSession();
			objSessionMap = (eCRDSessionMap) session.getAttribute("eCRDSessionMap");
			if (objSessionMap == null)
			{
				objSessionMap = new eCRDSessionMap();
				session.setAttribute("eCRDSessionMap", objSessionMap);
			}
			//Getting the parameters from the request
			strCompType = eCRDUtil.checkNull(request.getParameter("flag"));
			if (strCompType.equals(""))
			{
				strModelCode = eCRDUtil.checkNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODELCODE));
				strModuleCode = eCRDUtil.checkNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE));
				strCompSeqId = eCRDUtil.checkNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRCOMPONENTCODE));
				strFrom = eCRDUtil.checkNull((String) eCRDUtil.getFromSession(request, "strFrom"));
				if (strFrom.equals("Approval"))
				{
					strCompType = "N";
				}
				else
				{
					strCompType = "M";
				}
			}
			else
			{
				strModelCode = eCRDUtil.checkNull(request.getParameter("hdnModelCode"));
				strModuleCode = eCRDUtil.checkNull(request.getParameter("hdnModuleCode"));
				strCompSeqId = eCRDUtil.checkNull(request.getParameter("hdnCompCode"));
			}
			//Gets the existing Component from the main table
			objCatalog = (eCRDDefaultCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
			if (objCatalog == null)
			{
				objCatalog = new eCRDDefaultCatalog(strModelCode,eCRDConstants.STRENGMODELCONST);//Changed the constructor called to get loaded catalog object

				strSeqId = eCRDDefaultCatalog.getCurrentDefaultSeqId(strModelCode);
				objCatalog.setCatalogSeqId(strSeqId);
			}
			if (objCatalog.getEngineModel() == null)
			{
				objModel = new eCRDEngineModel(strModelCode);
				//	objModel.setEngineModelCode(strModelCode);
				objCatalog.setEngineModel(objModel);
			}
			else
			{
				objModel = objCatalog.getEngineModel();
			}
			//intSeqId = Integer.parseInt(strSeqId);
			objModule = objModel.getModule(strModuleCode);
			objModule.setEngineModel(objModel);
			//Getting the component object from the Module
			if (strCompType.equals("M"))
			{
				objComponent = objModule.getComponent(strCompSeqId);
				if (strFrom.equals(""))
				{
					eCRDUtil.loadInSession(request, "strFrom", "ModifyCompApproval");
				}
			}
			else
			{

				objComponent = objModule.getComponent(strCompSeqId);
				objComponent.setModule(objModule);
				objModule.setEngineModel(objModel);
				objModel.setCatalog(objCatalog);
				//Setting the variable to identify at the jsp that the request is coming for the approval
				request.setAttribute("hdnCheckOperation", "Modify");
				//	if(strFrom ==null && strFrom.equals(""))
				//	{
				eCRDUtil.loadInSession(request, "strFrom", "Approval");
				//	}
			}
			//Puts the Component objects in the Sesion

			eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objCatalog);
			eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODELCODE, objModel.getEngineModelCode());
			eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODULECODE, objModule.getModuleCode());
			eCRDUtil.loadInSession(request, eCRDConstants.STRCOMPONENTCODE, objComponent.getComponentCode());
			if ("".equals(eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, "strChkSrc"))))
			{
				eCRDUtil.loadInSession(request, "strChkSrc", "Component");
			}

			eCRDUtil.loadInSession(request, "ComponentType", strCompType);

		}
		finally
		{
			objCatalog = null;
			objModel = null;
			objModule = null;
			objComponent = null;
		}
	}

	private void listRepairApprovals(String strActionID, HttpServletRequest request) throws Exception
	{

		eCRDRepairApproval objRepApprv = null;
		GEAEResultSet rsApprvRep = null;
		eCRDDataBean objeCRDDataBean = null;
		eCRDUser objeCRDUser = null;
		String strRole = null;
		String strUserId = null;

		try
		{
			objeCRDDataBean = (eCRDDataBean) eCRDUtil.getFromSession(request, "objeCRDDataBean");
			ArrayList arrLstOutParam = new ArrayList();
			if (objeCRDDataBean == null)
			{
				objeCRDDataBean = new eCRDDataBean();
				eCRDUtil.loadInSession(request, "objeCRDDataBean", objeCRDDataBean);
			}

			//method to be called to perform doDBoperation from bean
			objRepApprv = new eCRDRepairApproval();
			objeCRDUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser");
			strRole = objeCRDUser.getRole();
			strUserId = objeCRDUser.getUserId();
			arrLstOutParam = objRepApprv.getApprovalRepair(strActionID, strRole, strUserId);
			//formating of the resultset obtained
			rsApprvRep = (GEAEResultSet) arrLstOutParam.get(0);
			if (eCRDConstants.ROLE_TECH_COORD.equals(strRole))
			{
				rsFormatted = formatTCRepResultSet(rsApprvRep);
			}
			else if (eCRDConstants.ROLE_ADMINISTRATOR.equals(strRole))
			{
				rsFormatted = formatRepResultSet(rsApprvRep);
			}

			objeCRDDataBean.setCache(rsFormatted);
			eCRDUtil.loadInSession(request, "objeCRDDataBean", objeCRDDataBean);
		}
		finally
		{
			objRepApprv = null;
			rsApprvRep = null;
			objeCRDDataBean = null;
			objeCRDUser = null;
			strRole = null;
			strUserId = null;
		}

	}

	public GEAEResultSet formatRepResultSet(GEAEResultSet rsSearchResults) throws Exception
	{
		String strCompCode = "";
		String strCompDesc = "";
		String strEngModelCode = "";
		String strEngModuleCode = "";
		String strEngModuleDesc = "";
		String strRequestedBy = "";
		String strRequesedDate = "";
		String strFlg = "";
		String strNoTagChange = "";
		String strRepairDesc = "";
		String strRepairCode = "";
		String strRepairType = "";
		String strSortableRequesedDate = null;
		String strEngModelDesc = null;
		rsFormattedRS = new GEAEResultSet();
		ArrayList arrlstTemp = null;
		GEAETag geAERepairTag = null;
		GEAETag geAETag = null;
		GEAETag geNoTag = null;
		try
		{
			rsFormattedRS = new GEAEResultSet();
			rsSearchResults.setCurrentRow(0);
//        19-05-2006 patni checking null value Begin
            if (rsSearchResults != null )
            {
//        19-05-2006 patni checking null value End
			while (rsSearchResults.next())
			{
				strEngModelCode = eCRDUtil.verifyNull(rsSearchResults.getString("mdl_number"));
				strEngModelDesc = eCRDUtil.verifyNull(rsSearchResults.getString("mdl_description"));
				strEngModuleDesc = eCRDUtil.verifyNull(rsSearchResults.getString("module_desc"));
				strCompDesc = eCRDUtil.verifyNull(rsSearchResults.getString("comp_desc"));
				strRepairDesc = eCRDUtil.verifyNull(rsSearchResults.getString("repair_desc"));
				strRequestedBy = eCRDUtil.verifyNull(rsSearchResults.getString("user_name"));
				strRequesedDate = eCRDUtil.verifyNull(rsSearchResults.getString("req_date"));
				strSortableRequesedDate = eCRDUtil.verifyNull(rsSearchResults.getString("sortable_req_date"));
				strFlg = eCRDUtil.verifyNull(rsSearchResults.getString("flg"));
				strCompCode = eCRDUtil.verifyNull(rsSearchResults.getString("comp_code"));
				strEngModuleCode = eCRDUtil.verifyNull(rsSearchResults.getString("module_code"));
				strRepairCode = eCRDUtil.verifyNull(rsSearchResults.getString("repair_code"));
				strRepairType = eCRDUtil.verifyNull(rsSearchResults.getString("repair_type"));
				arrlstTemp = new ArrayList();

				arrlstTemp.add(strEngModelDesc);
				arrlstTemp.add(strEngModuleDesc);
				arrlstTemp.add(strCompDesc);
				//Making the link to the Repair description to take to the page showing the details about the repair
				String strLink =
					"<A href=javascript:fnGetRepairDetails('"
						+ strEngModelCode
						+ "',"
						+ strEngModuleCode
						+ ",'"
						+ strCompCode
						+ "',"
						+ strRepairCode
						+ ",'"
						+ strFlg
						+ "','"
						+ strRepairType
						+ "')>"
						+ strRepairDesc
						+ "</A>";
				geAERepairTag = new GEAETag(strRepairDesc, strLink);
				arrlstTemp.add(geAERepairTag);

				arrlstTemp.add(strRequestedBy);
				//arrlstTemp.add(strRequesedDate);
				geAETag = new GEAETag(strSortableRequesedDate,strRequesedDate);
				arrlstTemp.add(geAETag);

				//The image will be shown depending on whether the repair is new or old
				if (strFlg.equals("N"))
				{
					strNoTagChange = "<IMG src='" + eCRDUtil.getBasePath() + eCRDConstants.STRCTRL + "/img/icon_checkmark.gif' ALT='Can not display image' width='20' height='20'></IMG>";
					geNoTag = new GEAETag("", strNoTagChange);
				}
				else
				{
					geNoTag = new GEAETag("", "");
				}
				arrlstTemp.add(geNoTag);
				rsFormattedRS.addRow(arrlstTemp);
			}
			rsFormattedRS.setColumnHeading(1, "Engine Model");
			rsFormattedRS.setColumnHeading(2, "Engine Module");
			rsFormattedRS.setColumnHeading(3, "Component");
			rsFormattedRS.setColumnHeading(4, "Repair Description");
			rsFormattedRS.setColumnHeading(5, "Requested By");
			rsFormattedRS.setColumnHeading(6, "Requested Date");
			rsFormattedRS.setColumnHeading(7, "New");
			rsFormattedRS.sort(1, true);
		} //end if
//          19-05-2006 patni checking null value Begin
        } //
//    19-05-2006 patni checking null value End
		finally
		{
		}
		return rsFormattedRS;
	}

	public GEAEResultSet formatTCRepResultSet(GEAEResultSet rsSearchResults) throws Exception
	{

		String strCompDesc = null;
		String strEngModuleDesc = null;
		String strRequestedBy = null;
		String strRequesedDate = null;
		String strFlg = null;
		String strNoTagChange = null;
		String strRepairDesc = null;
		String strEngModelDesc = null;
		String strSortableRequesedDate= null;
		GEAEResultSet rsFormattedRS = null;
		ArrayList arrlstTemp = null;
		GEAETag geAETag = null;
		GEAETag geNoTag = null;

		try
		{
			rsFormattedRS = new GEAEResultSet();
			rsSearchResults.setCurrentRow(0);
 // 10-05-2006 Patni checking result set null value Begin
            if(rsSearchResults!=null)
            {
 // 10-05-2006 Patni checking result set null value End
			while (rsSearchResults.next())
			{
				strEngModelDesc = eCRDUtil.verifyNull(rsSearchResults.getString("mdl_description"));
				strEngModuleDesc = eCRDUtil.verifyNull(rsSearchResults.getString("module_desc"));
				strCompDesc = eCRDUtil.verifyNull(rsSearchResults.getString("comp_desc"));
				strRepairDesc = eCRDUtil.verifyNull(rsSearchResults.getString("repair_desc"));
				strRequestedBy = eCRDUtil.verifyNull(rsSearchResults.getString("user_name"));
				strRequesedDate = eCRDUtil.verifyNull(rsSearchResults.getString("req_date"));
				strSortableRequesedDate = eCRDUtil.verifyNull(rsSearchResults.getString("sortable_req_date"));
				strFlg = eCRDUtil.verifyNull(rsSearchResults.getString("flg"));
				arrlstTemp = new ArrayList();

				arrlstTemp.add(strEngModelDesc);
				arrlstTemp.add(strEngModuleDesc);
				arrlstTemp.add(strCompDesc);
				arrlstTemp.add(strRepairDesc);

				arrlstTemp.add(strRequestedBy);
				//arrlstTemp.add(strRequesedDate);
				geAETag = new GEAETag(strSortableRequesedDate,strRequesedDate);
				arrlstTemp.add(geAETag);

				//The image will be shown depending on whether the repair is new or old
				if (strFlg.equals("N"))
				{
					strNoTagChange = "<IMG src='" + eCRDUtil.getBasePath() + eCRDConstants.STRCTRL + "/img/icon_checkmark.gif' ALT='Can not display image' width='20' height='20'></IMG>";
					geNoTag = new GEAETag("", strNoTagChange);
				}
				else
				{
					geNoTag = new GEAETag("", "");
				}
				arrlstTemp.add(geNoTag);
				rsFormattedRS.addRow(arrlstTemp);
			}
  // 19-05-2006 Patni checking null value Begin
            }//endif
  // 19-05-2006 Patni checking null value End

			rsFormattedRS.setColumnHeading(1, "Engine Model");
			rsFormattedRS.setColumnHeading(2, "Engine Module");
			rsFormattedRS.setColumnHeading(3, "Component");
			rsFormattedRS.setColumnHeading(4, "Repair Description");
			rsFormattedRS.setColumnHeading(5, "Requested By");
			rsFormattedRS.setColumnHeading(6, "Requested Date");
			rsFormattedRS.setColumnHeading(7, "New");
			rsFormattedRS.sort(1, true);
			return rsFormattedRS;
		}
		finally
		{

			strCompDesc = null;
			strEngModuleDesc = null;
			strRequestedBy = null;
			strRequesedDate = null;
			strFlg = null;
			strNoTagChange = null;
			strRepairDesc = null;
			rsFormattedRS = null;
			arrlstTemp = null;
			geNoTag = null;
		}

	}

	private void loadRepairsApprovals(HttpServletRequest request) throws Exception
	{
		String strSeqId = "";
		String strModelCode = "";
		String strModuleCode = "";
		String strCompSeqId = "";
		String strRepairType = "";
		String strRepairCode = "";
		String flgRepairModfy = "";
		eCRDDefaultCatalog objCatalog = null;
		eCRDEngineModel objModel = null;
		eCRDModule objModule = null;
		eCRDComponent objComponent = null;
		eCRDRepair objRepair = null;
		String strFrom = "";
		try
		{
			flgRepairModfy = request.getParameter("hdnFlag");

			if (flgRepairModfy == null || flgRepairModfy == "")
			{

				strFrom = (String) eCRDUtil.getFromSession(request, "strFrom");
				strModelCode = (String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODELCODE);
				strModuleCode = (String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE);
				strCompSeqId = (String) eCRDUtil.getFromSession(request, eCRDConstants.STRCOMPONENTCODE);
				// Uncommented and changed by Mallika for Phase 2 enhancements Req 4 
					strRepairCode = (String)eCRDUtil.getFromSession(request,eCRDConstants.STRREPAIRSEQID);
					strRepairType =(String)eCRDUtil.getFromSession(request,"strRepairType");
				if (strFrom.equals("ModRepairApproval"))
				{
					flgRepairModfy = "M";
				}
				else
				{
					flgRepairModfy = "N";
				}
			}
			else
			{
				strModelCode = eCRDUtil.checkNull(request.getParameter("hdnModelCode"));
				strModuleCode = eCRDUtil.checkNull(request.getParameter("hdnModuleCode"));
				strCompSeqId = eCRDUtil.checkNull(request.getParameter("hdnCompCode"));
				// Uncommented by Mallika for Phase 2 enhancements Req 4 
					strRepairCode = eCRDUtil.checkNull(request.getParameter("hdnRepairCode"));
					strRepairType = eCRDUtil.checkNull(request.getParameter("hdnRepairType"));
			}
			 //Commented by Mallika for Phase 2 enhancements Req 4 
			//strRepairCode = eCRDUtil.checkNull(request.getParameter("hdnRepairCode"));
			//strRepairType = eCRDUtil.checkNull(request.getParameter("hdnRepairType"));

			objCatalog = (eCRDDefaultCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
			if (objCatalog == null)
			{
				objCatalog = new eCRDDefaultCatalog(strModelCode,eCRDConstants.STRENGMODELCONST);//Changed the constructor called to get loaded catalog object
				strSeqId = eCRDDefaultCatalog.getCurrentDefaultSeqId(strModelCode);
				objCatalog.setCatalogSeqId(strSeqId);
			}
			if (objCatalog.getEngineModel() == null)
			{
				objModel = new eCRDEngineModel(strModelCode);
				//objModel.setEngineModelCode();
				objCatalog.setEngineModel(objModel);
			}
			else
			{
				objModel = objCatalog.getEngineModel();
			}
			objModel.setCatalog(objCatalog);
			objModule = objModel.getModule(strModuleCode);
			objModule.setEngineModel(objModel);
			objComponent = objModule.getComponent(strCompSeqId);
			objComponent.setModule(objModule);
			if (flgRepairModfy.equals("M"))
			{
				if (strRepairType.equals("IR"))
				{
					objRepair = objComponent.getRepair(strRepairCode, strRepairType);
					objRepair.setECRDComponent(objComponent);
					//Gets the Repair Details from the staging table.
				}
				else
				{
					//	Gets the Repair Details from the staging table and load the repair object with it
					objRepair = objComponent.getRepair(strRepairCode, strRepairType);
					//Setting the reference of the component object in the repair object
					objRepair.setECRDComponent(objComponent);
				}
				eCRDUtil.loadInSession(request, "strFrom", "ModRepairApproval");
			}
			else
			{
				if (strRepairType.equals("IR"))
				{
					objRepair = objComponent.getRepair(strRepairCode, strRepairType);
					objRepair.setECRDComponent(objComponent);
				}
				else
				{
					objRepair = objComponent.getRepair(strRepairCode, strRepairType);
					objRepair.setECRDComponent(objComponent);
				}
				objRepair.setECRDComponent(objComponent);
				objComponent.setModule(objModule);
				objModule.setEngineModel(objModel);
				objModel.setCatalog(objCatalog);   
				eCRDUtil.loadInSession(request, "strFrom", "NewRepairApproval");
			}
			//Puts the  objects in the Sesion
			eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objCatalog);
			eCRDUtil.loadInSession(request, eCRDConstants.STRCOMPONENTCODE, strCompSeqId);
			eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODULECODE, strModuleCode);
			eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODELCODE, strModelCode);
			eCRDUtil.loadInSession(request, eCRDConstants.STRREPAIRSEQID, strRepairCode);
			eCRDUtil.loadInSession(request, "strRepairType", strRepairType);
			eCRDUtil.loadInSession(request, "strChkSrc", "Repair");
			//request.setAttribute("strFrom","Approval");

		}
		finally
		{
			strSeqId = "";
		}
	}

	/**
	 * request: action=approve
	 * updates approval request.
	 */
	private String approveComponent(HttpServletRequest request) throws Exception
	{

		String strCompCode = "";
		String strCompDesc = "";
		String strModuleId = "";
		String strModelCode = "";
		String strAtaRef = "";
		String strCompEffDate = "";
		String strBaseTat = "";
		String strQtySet = "";
		String strSVExpRate = "";
		String strScrapExpRate = "";
		String strServExpRate = "";
		String strRepairYield = "";
		String strClass = "";
		String strTechLvl = "";
		String strMessage = "";
		String strCompType = "";
		String strDefSeqId = "";
		String strStartDay = "";
		String strStartMonth = "";
		String strStartYear = "";
		//Patni 25-May-2006 Defect #25 & 30 Begin Repair Effective Date of the Repair should not be updatable.
        String strDay = "";
        String strMonth = "";
        String strYear = "";
        String strBlEffDate = "";
        String strEffectiveDate = "";
        // Patni 25-May-2006 Defect #25 & 30 End Repair Effective Date of the Repair should not be updatable.
		eCRDDefaultCatalog objDefCatalog = null;
		eCRDComponent objComponent = null;
		eCRDComponent objNewComponent = null;
		eCRDModule objModule = null;
		eCRDEngineModel objModel = null;
		eCRDComponentApproval objCompApproval = null;
		eCRDUser objeCRDUser = null;
		ArrayList arlstRepairId = null;

		ArrayList arrlstInParam = null;
		String strAction = "";
		eCRDSearchBean objeCRDSearchBean = null;

		try
		{
			objeCRDUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser");
			if (objeCRDUser == null)
			{
				throw new Exception("User Not Found");
			}
			strCompCode = (String) eCRDUtil.getFromSession(request, eCRDConstants.STRCOMPONENTCODE);
			strModelCode = (String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODELCODE);
			strModuleId = (String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE);
			strCompType = (String) eCRDUtil.getFromSession(request, "ComponentType");

			// Check if component description is unique or not
			strAction = eCRDConstants.getActionId("eCRD_CHECK_UNIQUE_COMPDESC");
			arrlstInParam = new ArrayList();
			objeCRDSearchBean = new eCRDSearchBean();
			arrlstInParam.clear();
			arrlstInParam.add(strModuleId);
			arrlstInParam.add(eCRDUtil.verifyNull(request.getParameter("txtCompDesc")));
			arrlstInParam.add(strCompCode);
			strMessage = objeCRDSearchBean.checkForUniqueComponentCodeDesc(strAction, arrlstInParam);
			if ("".equals(strMessage)) // Unique desc
			{
				objDefCatalog = (eCRDDefaultCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);

				if (objDefCatalog == null)
				{
					objDefCatalog = new eCRDDefaultCatalog(strModelCode,eCRDConstants.STRENGMODELCONST);//Changed the constructor called to get loaded catalog object
					strDefSeqId = eCRDDefaultCatalog.getCurrentDefaultSeqId(strModelCode);
					objDefCatalog.setCatalogSeqId(strDefSeqId);
				}
				if (objDefCatalog.getEngineModel() == null)
				{
					objModel = new eCRDEngineModel();
					objModel.setEngineModelCode(strModelCode);
					objDefCatalog.setEngineModel(objModel);
					objModel.setCatalog(objDefCatalog);
				}
				else
				{
					objModel = objDefCatalog.getEngineModel();
					objModel.setCatalog(objDefCatalog);
				}
				if (objModel.getModule(strModuleId) == null)
				{
					objModule = objModel.addModule();
					objModule.setModuleCode(strModuleId);
				}
				else
				{
					objModule = objModel.getModule(strModuleId);
				}
				//Depending upon whether the component is new or already existin in the main table the object is loaded
				if (strCompType.equals("M"))
				{
					strCompDesc = eCRDUtil.checkNull(request.getParameter("txtCompDesc"));
					strAtaRef = eCRDUtil.checkNull(request.getParameter("txtAtaRef"));
              /* Patni 25-May-2006 Defect#25&30 Begin Repair Effective Date of the Repair should not be updatable.*/
                    strBlEffDate = eCRDUtil.verifyNull(request.getParameter("hdnBoolEffDate"));
                    strEffectiveDate = eCRDUtil.verifyNull(request.getParameter("hdnRepairDate"));
                    if(strBlEffDate.equals("true"))
                    {
                      strDay = eCRDUtil.getDay(strEffectiveDate);
                      strMonth =eCRDUtil.getMonth(strEffectiveDate);
                      strYear=eCRDUtil.getYear(strEffectiveDate);
                    }
                  else
                  {
                    strDay = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_DD"));
                    strMonth = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_MM"));
                    strYear = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_YYYY"));
                  }
               /* Patni 25-May-2006 Defect#25&30 Begin Repair Effective Date of the Repair should not be updatable.*/
					//Formating the date so that it could be entered in the object
					strCompEffDate = eCRDUtil.formatDate(strStartDay, strStartMonth, strStartYear);
					strBaseTat = eCRDUtil.checkNull(request.getParameter("txtBaseTat"));
					strQtySet = eCRDUtil.checkNull(request.getParameter("txtQtySet"));
					strSVExpRate = eCRDUtil.checkNull(request.getParameter("txtSvRate"));
					strScrapExpRate = eCRDUtil.checkNull(request.getParameter("txtScrapRate"));
					strServExpRate = eCRDUtil.checkNull(request.getParameter("txtServRate"));
					strRepairYield = eCRDUtil.checkNull(request.getParameter("txtAgeYield"));
					strClass = eCRDUtil.checkNull(request.getParameter("hdnClass"));
					strTechLvl = eCRDUtil.checkNull(request.getParameter("hdnTechLvl"));

					//Getting all the parameters from the request that are needed
					objComponent = objModule.getComponent(strCompCode);
					objComponent.setModule(objModule);
					//Gets the Component Details from the staging table.
					objCompApproval = (eCRDComponentApproval) objComponent.getApprovalRequestDetails();
					objNewComponent = objCompApproval.getStagingData();
					objNewComponent.setModule(objModule);
					objNewComponent.setComponentCode(strCompCode);
					objNewComponent.setComponentDesc(strCompDesc);
					objNewComponent.setATARefNo(strAtaRef);
					objNewComponent.setCycValClass(strClass);
					objNewComponent.setTechLvl(strTechLvl);
					objNewComponent.setBaseLineTAT(strBaseTat);
					objNewComponent.setComponentEffDt(strCompEffDate);
					objNewComponent.setQtyCompPerEngine(strQtySet);
					objNewComponent.setShopVisitExposureRate(strSVExpRate);
					objNewComponent.setScrapRateAtExposure(strScrapExpRate);
					objNewComponent.setServicableAtExposure(strServExpRate);
					objNewComponent.setPercentageYield(strRepairYield);
					//objCompApproval =(eCRDComponentApproval)objComponent.getApprovalRequestDetails();
				}
				else
				{
					objComponent = objModule.getComponent(strCompCode);
					objComponent.setModule(objModule);

					arlstRepairId = (ArrayList) eCRDUtil.getFromSession(request, "ComponentRepairId");
					for (int intRsRepairSize = 0; intRsRepairSize < arlstRepairId.size(); intRsRepairSize += 2)
					{
						objComponent.getRepair((String) arlstRepairId.get(intRsRepairSize), (String) arlstRepairId.get(intRsRepairSize + 1));

					}
					objCompApproval = (eCRDComponentApproval) objComponent.getApprovalRequestDetails();
					objCompApproval.setStgComponent(objComponent);

				}
				//objNewComponent= objCompApproval.getStagingData();
				objCompApproval.setApprovedBy(objeCRDUser.getUserId());
				objCompApproval.setChgType(strCompType);
				if (strCompType.equals("M"))
				{
					strMessage = objCompApproval.approve();
				}
				else
				{
					strMessage = objCompApproval.approve(arlstRepairId);
				}
				//Setting the objects in the session
				eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objDefCatalog);
			}
			else
			{
				request.setAttribute("Message", strMessage);
			}
		}
		finally
		{
			objNewComponent = null;
			objCompApproval = null;
			objComponent = null;
			objModel = null;
			objModule = null;
			objDefCatalog = null;
		}
		return strMessage;
	}

	/**
	 * request: action=reject
	 * updates approval request.
	 */
	private String rejectComponent(HttpServletRequest request) throws Exception
	{
		String strCompCode = "";
		String strMessage = "";
		String strCompType = "";
		String strModuleId = "";
		eCRDDefaultCatalog objDefCatalog = null;
		eCRDComponent objNewComponent = null;
		eCRDModule objModule = null;
		eCRDEngineModel objModel = null;
		eCRDComponentApproval objCompApproval = null;
		eCRDUser objeCRDUser = null;
		String strDefSeqId = "";
		String strModelCode = "";
		String strRejComments = "";
		try
		{
			objeCRDUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser");
			if (objeCRDUser == null)
			{
				throw new Exception("User Not Found");
			}
			strCompCode = (String) eCRDUtil.getFromSession(request, eCRDConstants.STRCOMPONENTCODE);
			strModelCode = (String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODELCODE);
			strModuleId = (String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE);

			//objDefCatalog = (eCRDDefaultCatalog)objSessionMap.getData("STRCATALOG");
			objDefCatalog = (eCRDDefaultCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
			strCompType = eCRDUtil.checkNull(request.getParameter("strCompType"));
			strRejComments = eCRDUtil.checkNull(request.getParameter("txtArRejCom"));
			strRejComments = eCRDUtil.replaceString(strRejComments, "\r\n", " ");

			if (objDefCatalog == null)
			{
				objDefCatalog = new eCRDDefaultCatalog(strModelCode,eCRDConstants.STRENGMODELCONST);//Changed the constructor called to get loaded catalog object
				strDefSeqId = eCRDDefaultCatalog.getCurrentDefaultSeqId(strModelCode);
				objDefCatalog.setCatalogSeqId(strDefSeqId);
			}
			if (objDefCatalog.getEngineModel() == null)
			{
				objModel = new eCRDEngineModel();
				objModel.setEngineModelCode(strModelCode);
				objDefCatalog.setEngineModel(objModel);
			}
			else
			{
				objModel = objDefCatalog.getEngineModel();
			}
			if (objModel.getModule(strModuleId) == null)
			{
				objModule = objModel.addModule();
				objModule.setModuleCode(strModuleId);
			}
			else
			{
				objModule = objModel.getModule(strModuleId);
			}
			objModel.setCatalog(objDefCatalog);
			objModule.setEngineModel(objModel);
			strCompType = (String) eCRDUtil.getFromSession(request, "ComponentType");
			if (strCompType.equals("M"))
			{

				objNewComponent = objModule.getComponent(strCompCode);
				objNewComponent.setModule(objModule);
				//Gets the Component Details from the staging table.
				objCompApproval = (eCRDComponentApproval) objNewComponent.getApprovalRequestDetails();
			}
			else
			{
				objNewComponent = objModule.getComponent(strCompCode);
				objNewComponent.setModule(objModule);
				//Gets the Component Details from the staging table.
				objCompApproval = (eCRDComponentApproval) objNewComponent.getApprovalRequestDetails();

			}
			objNewComponent.setModule(objModule);
			objCompApproval.setStgComponent(objNewComponent);
			objCompApproval.setApprovedBy(objeCRDUser.getUserId());
			objCompApproval.setApprovalMailId(objeCRDUser.getEMailId());
			if(objeCRDUser.getEMailId()!=null)
				System.out.println("objeCRDUser.getEMailId()" + objeCRDUser.getEMailId());
			else
				System.out.println("objeCRDUser.getEMailId() is  null" );
			objCompApproval.setRejectionComments(strRejComments);
			//Calling the function in the repair approval object to reject the repair
			strMessage = objCompApproval.reject();
			/*	objModule.removeComponent(strCompCode,objeCRDUser.getUserId(),objeCRDUser.getRole());
				objModule.setEngineModel(objModel);
				objModel.setCatalog(objDefCatalog);*/
			eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objDefCatalog);

			return strMessage;
		}
		finally
		{
			objCompApproval = null;
			objDefCatalog = null;
			objModel = null;
			objModule = null;
			objNewComponent = null;
		}

	}

	public String ApproveRepair(HttpServletRequest request) throws Exception
	{
		String strCompCode = "";
		String strRepairCode = "";
		String strMessage = "";
		String strModuleId = "";
		String strDefSeqId = "";
		String strModelCode = "";
		String strTAT = "";
		String strPr = "";
		String strPrType = "";
		String strFutTat = "";
		String strFutPr = "";
		String flgRepairModfy = "";
		String strIncTAT = "";
		String strIncPr = "";
		String strRepairType = "";

		String strFutDay = "";
		String strFutMonth = "";
		String strFutYear = "";
		String strFutEffDt = "";

		eCRDDefaultCatalog objDefCatalog = null;
		eCRDComponent objComponent = null;
		eCRDModule objModule = null;
		eCRDEngineModel objModel = null;
		eCRDRepairApproval objRepairApprRequest = null;
		eCRDUser objeCRDUser = null;
		eCRDRepair objNewRepair = null;
		eCRDRepair objRepair = null;
		eCRDRepairPricing objRepPricing = null;
        Integer intTat;
        Integer intFutTat;
        Double dblFutPr;
        Double dblPr;
		HashMap hmPriceTypes = null;
		try
		{
			hmPriceTypes = new HashMap();
			hmPriceTypes = eCRDConstants.getPriceTypes();

			objeCRDUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser");
			if (objeCRDUser == null)
			{
				throw new Exception("User Not Found");
			}
			strCompCode = eCRDUtil.checkNull(request.getParameter("hdnCompCode"));
			strRepairCode = eCRDUtil.checkNull(request.getParameter("hdnRepCode"));
			strModuleId = eCRDUtil.checkNull(request.getParameter("hdnModuleId"));
			strModelCode = eCRDUtil.checkNull(request.getParameter("hdnModelCode"));

			flgRepairModfy = eCRDUtil.checkNull(request.getParameter("hdnFlgNewModRep"));
			//	intSize=Integer.parseInt(strSize);

			objDefCatalog = (eCRDDefaultCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
			if (objDefCatalog == null)
			{
				objDefCatalog = new eCRDDefaultCatalog(strModelCode,eCRDConstants.STRENGMODELCONST);//Changed the constructor called to get loaded catalog object
				strDefSeqId = eCRDDefaultCatalog.getCurrentDefaultSeqId(strModelCode);
				objDefCatalog.setCatalogSeqId(strDefSeqId);
			}
			if (objDefCatalog.getEngineModel() == null)
			{
				objModel = new eCRDEngineModel();
				objModel.setEngineModelCode(strModelCode);
				objModel.setCatalog(objDefCatalog);
				objDefCatalog.setEngineModel(objModel);
				objModel.setCatalog(objDefCatalog);
			}
			else
			{
				objModel = objDefCatalog.getEngineModel();
				objModel.setCatalog(objDefCatalog);
			}
			if (objModel.getModule(strModuleId) == null)
			{
				objModule = objModel.addModule();
				objModule.setModuleCode(strModuleId);
			}
			else
			{
				objModule = objModel.getModule(strModuleId);
			}
			if (objModule.getComponent(strCompCode) == null)
			{
				objComponent = objModule.addComponent();
				objComponent.setComponentCode(strCompCode);
			}
			else
			{
				objComponent = objModule.getComponent(strCompCode);
			}

			if (flgRepairModfy.equals("M"))
			{
				strIncTAT = eCRDUtil.checkNull(request.getParameter("hdnIncTat"));
				strTAT = eCRDUtil.checkNull(request.getParameter("txtTAT"));
				strIncPr = eCRDUtil.checkNull(request.getParameter("hdnIncPr"));
				strPr = eCRDUtil.checkNull(request.getParameter("txtPr"));
				strPrType = eCRDUtil.checkNull(request.getParameter("hdnPrType"));
				strPrType = (String) hmPriceTypes.get(strPrType);
				strFutTat = eCRDUtil.checkNull(request.getParameter("txtFutTat"));
				strFutPr = eCRDUtil.checkNull(request.getParameter("txtFutPr"));
				strFutDay = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_DD_FUT"));
				strFutMonth = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_MM_FUT"));
				strFutYear = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_YYYY_FUT"));
				strFutEffDt = eCRDUtil.formatDate(strFutDay, strFutMonth, strFutYear);
				strRepairType = eCRDUtil.checkNull(request.getParameter("hdnRepairType"));
				dblPr=eCRDUtil.verifyDoubleObj(strPr);
				dblFutPr=eCRDUtil.verifyDoubleObj(strFutPr);
				intTat=eCRDUtil.verifyIntObj(strTAT);
				intFutTat=eCRDUtil.verifyIntObj(strFutTat);

				if (strRepairType.equals("IR"))
				{
					objRepair = objComponent.getRepair(strRepairCode, strRepairType);
					objRepair.setECRDComponent(objComponent);
					//Gets the Repair Details from the staging table.
					objRepairApprRequest = (eCRDRepairApproval) objRepair.getApproveRepairdetails();
					objRepairApprRequest.setMainRepair(objRepair);
				}
				else
				{
					objRepair = objComponent.getRepair(strRepairCode, strRepairType);
					objRepair.setECRDComponent(objComponent);
					//Gets the Repair Details from the staging table.
					objRepairApprRequest = (eCRDRepairApproval) objRepair.getApproveRepairdetails();
					objRepairApprRequest.setMainRepair(objRepair);
				}
				objNewRepair = objRepairApprRequest.getStagingData();
				objNewRepair.setECRDComponent(objComponent);

				objRepPricing = objNewRepair.addRepairPricing();
				objRepPricing.setObjCRDRepair(objNewRepair);
				objRepPricing.setDblFuturePrice(dblFutPr);
				objRepPricing.setIntTAT(intTat);
				objRepPricing.setDblPrice(dblPr);
				objRepPricing.setIntFutureTAT(intFutTat);
				objRepPricing.setStrPriceType(strPrType);
				objRepPricing.setDtFuturePriceTATEffDt(strFutEffDt);
				if (strIncTAT.equalsIgnoreCase(eCRDConstants.STRTRUE))
				{
					objRepPricing.setFlgIncrTAT(true);
				}
				else
				{
					objRepPricing.setFlgIncrTAT(false);
				}
				if (strIncPr.equals(eCRDConstants.STRTRUE))
				{
					objRepPricing.setFlgIncrPrice(true);
				}
				else
				{
					objRepPricing.setFlgIncrPrice(false);
				}
			}
			else
			{
				if (strRepairType.equals("IR"))
				{
					objNewRepair = objComponent.addRepair(strRepairType);
					objNewRepair.setStrRepairCode(strRepairCode);
					//Gets the Repair Details from the staging table.
					objRepairApprRequest = (eCRDRepairApproval) objRepair.getApproveRepairdetails();
				}
				else
				{
					objNewRepair = objComponent.addRepair(strRepairType);
					objNewRepair.setStrRepairCode(strRepairCode);
					//Gets the Repair Details from the staging table.
					objRepairApprRequest = (eCRDRepairApproval) objRepair.getApproveRepairdetails();
				}
				objRepairApprRequest.setStgApprovalRepair(objNewRepair);
				//This method will return the eCRDRepair object populated with Staging data.
			}
			objRepairApprRequest.setApprovedBy(objeCRDUser.getUserId());
			objRepairApprRequest.setChgType(flgRepairModfy);
			strMessage = objRepairApprRequest.approve();
			eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objDefCatalog);
		}
		finally
		{
			strCompCode= null;
			strRepairCode = null;
			strMessage= null;
			strModuleId= null;
			strDefSeqId = null;
			strModelCode = null;
			strTAT = null;
			strPr = null;
			strPrType = null;
			strFutTat = null;
			strFutPr= null;
			flgRepairModfy= null;
			strIncTAT= null;
			strIncPr = null;
			strRepairType = null;
			objModel = null;
			objModule = null;
			objComponent = null;

		}
		return strMessage;
	}

	private String rejectRepair(HttpServletRequest request) throws Exception
	{
		HttpSession session = request.getSession();
		String strCompCode = "";
		String strDefSeqId = "";
		String strRepairCode = "";
		String strMessage = "";
		String strModuleId = "";
		String strRepairType = "";
		String flgRepairModfy = "";
		String strModelCode = "";
		String strRejectionComm = "";
		eCRDSessionMap objSessionMap = null;
		eCRDDefaultCatalog objDefCatalog = null;
		eCRDComponent objComponent = null;
		eCRDModule objModule = null;
		eCRDEngineModel objModel = null;
		eCRDRepairApproval objRepairApprRequest = null;
		eCRDUser objeCRDUser = null;
		eCRDRepair objNewRepair = null;
		eCRDRepair objRepair = null;

		try
		{
			objeCRDUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser");
			if (objeCRDUser == null)
			{
				throw new Exception("User Not Found");
			}
			objSessionMap = (eCRDSessionMap) session.getAttribute("eCRDSessionMap");
			if (objSessionMap == null)
			{
				objSessionMap = new eCRDSessionMap();
				session.setAttribute("eCRDSessionMap", objSessionMap);
			}
			/*	strCompCode = eCRDUtil.checkNull(request.getParameter("hdnCompCode"));
				strRepairCode=eCRDUtil.checkNull(request.getParameter("hdnRepCode"));
				strModuleId = eCRDUtil.checkNull(request.getParameter("hdnModuleId"));
				strModelCode = eCRDUtil.checkNull(request.getParameter("hdnModelCode"));
				strRepairType= eCRDUtil.checkNull(request.getParameter("hdnRepType"));*/
			strRepairType = (String) eCRDUtil.getFromSession(request, "strRepairType");
			strCompCode = (String) eCRDUtil.getFromSession(request, eCRDConstants.STRCOMPONENTCODE);
			strModuleId = (String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE);

			strModelCode = (String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODELCODE);
			strRepairCode = (String) eCRDUtil.getFromSession(request, eCRDConstants.STRREPAIRSEQID);

			//strSize=eCRDUtil.checkNull(request.getParameter("ChldRepSize"));
			flgRepairModfy = eCRDUtil.checkNull(request.getParameter("hdnFlgNewModRep"));
			strRejectionComm = eCRDUtil.checkNull(request.getParameter("txtRejectComm"));
			strRejectionComm = eCRDUtil.replaceString(strRejectionComm, "\r\n", " ");

			//		intSize=Integer.parseInt(strSize);

			objDefCatalog = (eCRDDefaultCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
			if (objDefCatalog == null)
			{
				objDefCatalog = new eCRDDefaultCatalog(strModelCode,eCRDConstants.STRENGMODELCONST);//Changed the constructor called to get loaded catalog object
				strDefSeqId = eCRDDefaultCatalog.getCurrentDefaultSeqId(strModelCode);
				objDefCatalog.setCatalogSeqId(strDefSeqId);
			}
			if (objDefCatalog.getEngineModel() == null)
			{
				objModel = new eCRDEngineModel();
				objModel.setEngineModelCode(strModelCode);
				objModel.setCatalog(objDefCatalog);
				objDefCatalog.setEngineModel(objModel);

			}
			else
			{
				objModel = objDefCatalog.getEngineModel();
				objModel.setCatalog(objDefCatalog);
			}
			if (objModel.getModule(strModuleId) == null)
			{
				objModule = objModel.addModule();
				objModule.setModuleCode(strModuleId);
			}
			else
			{
				objModule = objModel.getModule(strModuleId);
			}
			objModule.setEngineModel(objModel);
			if (objModule.getComponent(strCompCode) == null)
			{
				objComponent = objModule.addComponent();
				objComponent.setComponentCode(strCompCode);
			}
			else
			{
				objComponent = objModule.getComponent(strCompCode);
			}
			objComponent.setModule(objModule);
			if (flgRepairModfy.equals("M"))
			{
				if (strRepairType.equals("IR"))
				{
				
					objRepair = objComponent.getRepair(strRepairCode, strRepairType);
					//Gets the Repair Details from the staging table.
					objRepair.setECRDComponent(objComponent);
					objRepairApprRequest = (eCRDRepairApproval) objRepair.getApproveRepairdetails();
					objRepairApprRequest.setMainRepair(objRepair);
					objRepairApprRequest.setStgApprovalRepair(objRepair);
					objNewRepair = objRepairApprRequest.getStagingData();
					objNewRepair.setECRDComponent(objComponent);
				}
				else
				{
					objRepair = objComponent.getRepair(strRepairCode, strRepairType);
					//Gets the Repair Details from the staging table.
					objRepair.setECRDComponent(objComponent);
					objRepairApprRequest = (eCRDRepairApproval) objRepair.getApproveRepairdetails();
					objRepairApprRequest.setMainRepair(objRepair);
					objRepairApprRequest.setStgApprovalRepair(objRepair);
					objNewRepair = objRepairApprRequest.getStagingData();
					objNewRepair.setECRDComponent(objComponent);
				}

			}
			else
			{
				if (strRepairType.equals("IR"))
				{
					objNewRepair = objComponent.getRepair(strRepairCode, strRepairType);

					objNewRepair.setECRDComponent(objComponent);
					
					//Gets the Repair Details from the staging table.
					objRepairApprRequest = (eCRDRepairApproval) objNewRepair.getApproveRepairdetails();
					objRepairApprRequest.setStgApprovalRepair(objNewRepair);
				}
				else
				{
					objNewRepair = objComponent.getRepair(strRepairCode, strRepairType);

					objNewRepair.setECRDComponent(objComponent);
					//Gets the Repair Details from the staging table.
					objRepairApprRequest = (eCRDRepairApproval) objNewRepair.getApproveRepairdetails();
					objRepairApprRequest.setStgApprovalRepair(objNewRepair);
				}
				//This method will return the eCRDRepair object populated with Staging data.

			}
			objRepairApprRequest.setApprovedBy(objeCRDUser.getUserId());
			objRepairApprRequest.setRejectionComments(strRejectionComm);
			objRepairApprRequest.setStgApprovalRepair(objNewRepair);
			objRepairApprRequest.setApprovalMailId(objeCRDUser.getEMailId());
			strMessage = objRepairApprRequest.reject();

			/*	objComponent.removeRepair(strRepairCode,objeCRDUser.getUserId(),objeCRDUser.getRole());
				objComponent.setModule(objModule);
				objModule.setEngineModel(objModel);*/
			objModel.setCatalog(objDefCatalog);
			eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objDefCatalog);
			
			return strMessage;
		}
		finally
		{
			objModel = null;
			objModule = null;
		}

	}
	private void listComponentApprovalsHist(String strActionID, HttpServletRequest request) throws Exception
	{
		String strComponentCode = "";
		String strModuleCode = "";
		ArrayList arrLstOutParam = new ArrayList();
		HttpSession session = request.getSession();
		eCRDComponentApproval objCompApprv = null;
		GEAEResultSet rsApprvCompHist = null;
		eCRDDataBean objeCRDDataBean = null;
		try
		{
			objeCRDDataBean = (eCRDDataBean) session.getAttribute("objeCRDDataBean");
			if (objeCRDDataBean == null)
			{
				objeCRDDataBean = new eCRDDataBean();
				session.setAttribute("objeCRDDataBean", objeCRDDataBean);
			}
			strComponentCode = request.getParameter("hdnCompCode");
			strModuleCode = request.getParameter("hdnModuleCode");
			//method to be called to perform doDBoperation from bean
			objCompApprv = new eCRDComponentApproval();
			arrLstOutParam = objCompApprv.getApprovalHist(strActionID, strComponentCode, strModuleCode);
			//formating of the resultset obtained
			rsApprvCompHist = (GEAEResultSet) arrLstOutParam.get(0);
			rsFormatted = formatCompHistResultSet(rsApprvCompHist);
			objeCRDDataBean.setCache(rsFormatted);
			eCRDUtil.loadInSession(request, "objeCRDDataBean", objeCRDDataBean);
		}
		finally
		{
		}

	}
	public GEAEResultSet formatCompHistResultSet(GEAEResultSet rsSearchResults) throws Exception
	{
		String strApprBy = "";
		String strApprDate = "";
		String strApprStatus = "";
		String strRejectionComm = "";
		String strRequestedBy = "";
		rsFormattedRS = new GEAEResultSet();
		ArrayList arrlstTemp = null;
		try
		{
			rsFormattedRS = new GEAEResultSet();
			rsSearchResults.setCurrentRow(0);
//        19-05-2006 patni checking null value Begin
            if (rsSearchResults!=null )
            {
//              19-05-2006 patni checking null value End
            while (rsSearchResults.next())
			{
				strRequestedBy = eCRDUtil.verifyNull(rsSearchResults.getString("Requested_by"));
				strApprBy = eCRDUtil.verifyNull(rsSearchResults.getString("Approve_Reject_By"));
				strApprDate = eCRDUtil.verifyNull(rsSearchResults.getString("Approve_Reject_Date"));
				strApprStatus = eCRDUtil.verifyNull(rsSearchResults.getString("Approve_Reject_Status"));
				;
				strRejectionComm = eCRDUtil.verifyNull(rsSearchResults.getString("Rejection_Comments"));
				arrlstTemp = new ArrayList();

				arrlstTemp.add(strRequestedBy);
				arrlstTemp.add(strApprBy);
				arrlstTemp.add(strApprDate);
				arrlstTemp.add(strApprStatus);
				arrlstTemp.add(strRejectionComm);
				rsFormattedRS.addRow(arrlstTemp);
			}
//          19-05-2006 patni checking null value Begin
            } //endif
//          19-05-2006 patni checking null value End
			rsFormattedRS.setColumnHeading(1, "Requested By");
			rsFormattedRS.setColumnHeading(2, "Approve Reject By");
			rsFormattedRS.setColumnHeading(3, "Approve Reject Date");
			rsFormattedRS.setColumnHeading(4, "Approve Reject Status");
			rsFormattedRS.setColumnHeading(5, "Rejection Comments");
			rsFormattedRS.sort(1, true);
		}
		finally
		{
		}
		return rsFormattedRS;
	}
	private void listRepairApprovalsHist(String strActionID, HttpServletRequest request) throws Exception
	{
		String strPOPRepairCode = "";
		String strPOPCatalogSeqId = "";
		ArrayList arrLstOutParam = new ArrayList();
		HttpSession session = request.getSession();
		eCRDRepairApproval objRepApprv = null;
		GEAEResultSet rsApprvRepairHist = null;
		eCRDDataBean objeCRDDataBean = null;
		try
		{
			objeCRDDataBean = (eCRDDataBean) session.getAttribute("objeCRDDataBean");
			if (objeCRDDataBean == null)
			{
				objeCRDDataBean = new eCRDDataBean();
				session.setAttribute("objeCRDDataBean", objeCRDDataBean);
			}
			strPOPRepairCode = request.getParameter("hdn_POP_RepairCode");
			strPOPCatalogSeqId = request.getParameter("hdn_POP_CatalogSeqId");
			//method to be called to perform doDBoperation from bean
			objRepApprv = new eCRDRepairApproval();
			arrLstOutParam = objRepApprv.getApprovalHist(strActionID, strPOPRepairCode, strPOPCatalogSeqId);
			//formating of the resultset obtained
			rsApprvRepairHist = (GEAEResultSet) arrLstOutParam.get(0);
			rsFormatted = formatRepairHistResultSet(rsApprvRepairHist);
			objeCRDDataBean.setCache(rsFormatted);
			eCRDUtil.loadInSession(request, "objRepairApprHist", objeCRDDataBean);
		}
		finally
		{
		}

	}
	public GEAEResultSet formatRepairHistResultSet(GEAEResultSet rsSearchResults) throws Exception
	{
		String strApprvBy = "";
		String strApprDate = "";
		String strApprStatus = "";
		String strRequestedBy = "";
		String strRejectComm = "";
		rsFormattedRS = new GEAEResultSet();
		ArrayList arrlstTemp = null;
		try
		{
			rsFormattedRS = new GEAEResultSet();
			rsSearchResults.setCurrentRow(0);
//        19-05-2006 patni checking null value Begin
            if ( rsSearchResults !=null)
            {
//              19-05-2006 patni checking null value End
			while (rsSearchResults.next())
			{
				strRequestedBy = eCRDUtil.verifyNull(rsSearchResults.getString("Requested_By"));
				strApprvBy = eCRDUtil.verifyNull(rsSearchResults.getString("Approve_Reject_By"));
				strApprDate = eCRDUtil.verifyNull(rsSearchResults.getString("Apprv_Reject_Date"));

				strApprStatus = eCRDUtil.verifyNull(rsSearchResults.getString("Apprv_Reject_Status"));
				strRejectComm = eCRDUtil.verifyNull(rsSearchResults.getString("Rejection_Comments"));
				arrlstTemp = new ArrayList();

				arrlstTemp.add(strRequestedBy);
				arrlstTemp.add(strApprvBy);
				arrlstTemp.add(strApprDate);
				arrlstTemp.add(strApprStatus);
				arrlstTemp.add(strRejectComm);
				rsFormattedRS.addRow(arrlstTemp);
			}
//        19-05-2006 patni checking null value Begin
            } // End if
//          19-05-2006 patni checking null value End
			rsFormattedRS.setColumnHeading(1, "Requested By");
			rsFormattedRS.setColumnHeading(2, "Approved/Rejected By");
			rsFormattedRS.setColumnHeading(3, "Approve/Reject Date");
			rsFormattedRS.setColumnHeading(4, "Approve/Reject Status");
			rsFormattedRS.setColumnHeading(5, "Reject Comments");
			rsFormattedRS.sort(1, true);
		}
		finally
		{
		}
		return rsFormattedRS;
	}

}
