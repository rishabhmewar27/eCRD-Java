//CODE\\ecrd\\helper\\eCRDManageComponentHelper.java

/**
* Module       : eCRDManageComponentHelper.java
* Author       : Patni Offshore
* Project      : eCRD
* Date Written : October 2004
* Security     : Classified/Unclassified
* Restrictions : GE PROPRIETORY INFORMATION, FOR GE USE ONLY
*
*     ***************************************************************
*     *          Copyright (2000) with all rights reserved          *
*     *                  General Electric Company                   *
*     ***************************************************************
* Description  :  This class has methods to get the Master Tables Data.
* Revision Log  (mm/dd/yyyy     Initials    description)
* -------------------------------------------------------------------
* mm/dd/yyyy     Initials     Description
* -------------------------------------------------------------------
* 10/19/2004      Patni Offshore  Coded
*   31/15/2005     patni  Phase 1 requirement updations 
*/

package ecrd.helper;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import ecrd.biz.eCRDCatalog;
import ecrd.biz.eCRDComponent;
import ecrd.biz.eCRDDefaultCatalog;
import ecrd.biz.eCRDEngineModel;
import ecrd.biz.eCRDModule;
import ecrd.biz.eCRDUser;
import ecrd.biz.eCRDSite;
import ecrd.common.eCRDBusinessBean;
import ecrd.common.eCRDCommand;
import ecrd.common.eCRDDataBean;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDLoadMaster;
import ecrd.util.eCRDSearchBean;
import ecrd.util.eCRDUtil;
import geae.dao.GEAEResultSet;
import geae.util.format.GEAETag;
import geae.util.format.GEAETagNoData;


public class eCRDManageComponentHelper implements eCRDCommand
{
private HttpServletRequest request = null;
//String strEngineModuleDescription  = "";


public eCRDManageComponentHelper()
{

}
/**
* Based on the "action" passed in request this function redirects request to
* appropriate private function from this class.
* Also sets the received request to member variable.
* @param request
*/
public String perform(HttpServletRequest request) throws Exception
{
  //    To store Cont value depending upon ScreenAction
  String strCont = "";
  //    To store Screen Action
  String strAction = "";
  String strMessage = "";
         
  // To check if component with given details is present in DB in modify component
  int intcheckComponentDetailOption = 0;
  int intcheckIfUniqueComponent = 0;
  try
  {

      strAction = eCRDUtil.verifyNull(request.getParameter("hdnScreenAction"));
      // When Add Component Link is Clicked - To display Add Component Page
      if ("".equals(strAction))
      {
          // To populate the Engine Module List
          eCRDUtil.clearSession(request);
          showEngineModuleList(request);
          strCont = eCRDConstants.STRCONTJSP + "ecrd-addComponent";
      }
      if ((eCRDConstants.getActionId("eCRD_ADD_COMPONENT_DETAILS")).equals(strAction))
      {
          // Checking if component with given details is present in DB
          intcheckComponentDetailOption = showComponentDetails(request);
          if (intcheckComponentDetailOption == -1) // Modify Component Details
          {
              // To show modify component page again because selected component not found
              showEngineModuleList(request);
              strCont = eCRDConstants.STRCONTJSP + "ecrd-modifyComponent";
          }
          else
          {
              if (intcheckComponentDetailOption == 0) // Add Component Details
              {
                  addComponent(request);
              }
              else
              {
                  eCRDUtil.loadInSession(request, "strFrom", "Modify");
                  eCRDUtil.loadInSession(request, "strCheckOperation", "Modify");
              }
              // To display component details page
              strCont = eCRDConstants.STRCONTJSP + "ecrd-addComponentDetails";
          }
      }
      if ((eCRDConstants.getActionId("eCRD_ADD_COMPONENT_DETAILS_TAB")).equals(strAction))
      {
          strCont = eCRDConstants.STRCONTJSP + "ecrd-addComponentDetails";
      }
      // To display modify component page
      if ((eCRDConstants.getActionId("eCRD_MODIFY_COMPONENT")).equals(strAction))
      {
          // To populate the Engine Model List
          eCRDUtil.clearSession(request);
          showEngineModuleList(request);
          strCont = eCRDConstants.STRCONTJSP + "ecrd-modifyComponent";
      }
      if ((eCRDConstants.getActionId("eCRD_ADD_REPAIR")).equals(strAction))
      {
          // To create the component object before adding repair
          intcheckIfUniqueComponent = createComponent(request, "1");
          if (intcheckIfUniqueComponent == -1) // Not unique
          {
              strCont = eCRDConstants.STRCONTJSP + "ecrd-addComponentDetails";
          }
          else
          {
              strCont = eCRDConstants.STRCONTJSP + "ecrd-detRepair";
          }
      }
      // To display table of components which pops up for 'Find' on modify component page
      if ((eCRDConstants.getActionId("eCRD_COMPONENT_TABLE")).equals(strAction))
      {
          // To get the list of components for the given values of model,module,
          // ATANo,Component Code,Component description
          getComponentList(request, strAction);
          strCont = eCRDConstants.STRCONTJSP + "ecrd-showComponentTable";
      }
//    To display table of components which pops up for 'Find' on view/modify component page
      if ((eCRDConstants.getActionId("eCRD_VIEWMODIFY_COMPONENT_TABLE")).equals(strAction))
      {
          // To get the list of components for the given values of model,module,
          // ATANo,Component Code,Component description
          getViewModifyComponentList(request, strAction);
          strCont = eCRDConstants.STRCONTJSP + "ecrd-showComponentTable";
      }
      
      // To delete the selected component
      if ((eCRDConstants.getActionId("eCRD_DELETE_COMPONENT")).equals(strAction))
      {
          deleteComponent(request);
          strCont = eCRDConstants.STRCONTJSP + "ecrd-deleteComponent";
      }
      // To update details of the component
      if ((eCRDConstants.getActionId("eCRD_UPDATE_COMPONENT")).equals(strAction))
      {
          updateComponent(request);
          strCont = eCRDConstants.STRCONTJSP + "ecrd-addComponentDetails";
      }
      // To update only site details of component
      if ((eCRDConstants.getActionId("eCRD_UPDATE_COMPONENT_SITE")).equals(strAction))
      {
          updateComponentSite(request);
          strCont = eCRDConstants.STRCONTJSP + "ecrd-addComponentDetails";
      }
      if ((eCRDConstants.getActionId("eCRD_SHOW_APPRV_COMP_REPAIR_LIST")).equals(strAction))
      {
        // Added new To check if the Component information which
        // is updated is having unique component description
          if(showApprvComponentRepairList(request)!=-1)
          {
            strCont = eCRDConstants.STRCONTJSP + "ecrd-showApprComponentRepairList";
          }
          else
          {
                strCont = eCRDConstants.STRCONTJSP + "ecrd-showNewCompApprDet";
          }
      }
      // To show page for selecting engine model and module for Classify Component
        if ((eCRDConstants.getActionId("eCRD_CLASSIFY_COMPONENT")).equals(strAction))
        {
            eCRDUtil.clearSession(request);
            // To get the Module List for Selected Engine Model
            showEngineModuleListForClassifyComponent(request);
            strCont = eCRDConstants.STRCONTJSP + "ecrd-classifyComponent";
        }
        // To get the component list in case of classify component
        if ((eCRDConstants.getActionId("eCRD_CLASSIFY_COMPONENT_DETAILS")).equals(strAction))
        {
            // To get the list of component with corresponding class
            getClassifyComponentList(request);
            showEngineModuleListForClassifyComponent(request);
            if(!"".equals(eCRDUtil.verifyNull((String)
                   eCRDUtil.getFromSession(request,eCRDConstants.STRENGINEMODELCODE))))
            {
                saveCatalogObjectInSession(request);
            }
            strCont = eCRDConstants.STRCONTJSP + "ecrd-classifyComponent";
        }
        // To save the classify component list after changing the class of component
        if ((eCRDConstants.getActionId("eCRD_SAVE_CLASSIFY_COMP_LIST")).equals(strAction))
        {
            // To save the changed class for the component
            saveClassifyComponentList(request,strAction);
            showEngineModuleListForClassifyComponent(request);
            // Get the changed information of Component and Class
            getClassifyComponentList(request);
            strCont = eCRDConstants.STRCONTJSP + "ecrd-classifyComponent";
        }
        //To show page for selecting engine model, module, eCRD Component Code and OSB Component Code for Component Mapping
      if ((eCRDConstants.getActionId("eCRD_MAP_COMPONENT")).equals(strAction))
      {
          //eCRDUtil.clearSession(request);
          // To get the Module List for Selected Engine Model

//9292_eCRD_SiteMapping_Shyamala Radhakrishnan	         
    	  eCRDUtil.removeFromSession(request,"strModuleDropDown");
          eCRDUtil.removeFromSession(request, eCRDConstants.STRENGINEMODELCODE);
          eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODELCODE, eCRDUtil.verifyNull(request.getParameter("hdnEngineModelDesc")));
          eCRDUtil.removeFromSession(request, "objeCRDMappedCompList");
//end
          eCRDUtil.removeFromSession(request,"strModuleDropDown");
          eCRDUtil.removeFromSession(request, eCRDConstants.STRENGINEMODULECODE);
          eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODULECODE, eCRDUtil.verifyNull(request.getParameter("hdnEngineModuleDesc")));
          eCRDUtil.removeFromSession(request, "objeCRDMappedCompList");
//9292_eCRD_SiteMapping_Shyamala Radhakrishnan	          
          eCRDUtil.removeFromSession(request, eCRDConstants.STRLOCATIONNAME);
          eCRDUtil.loadInSession(request, eCRDConstants.STRLOCATIONNAME, eCRDUtil.verifyNull(request.getParameter("hdnSiteDesc")));
          eCRDUtil.removeFromSession(request, "objeCRDMappedCompList");
          
/*          eCRDUtil.removeFromSession(request,"strSiteDropDown");
          eCRDUtil.loadInSession(request, eCRDConstants.STRCOMPONENTCODE, eCRDUtil.verifyNull(request.getParameter("hdnComponentCode")));
          eCRDUtil.removeFromSession(request, "objeCRDMappedCompList");*/

          eCRDUtil.loadInSession(request, eCRDConstants.STRCOMPONENTDESC, eCRDUtil.verifyNull(request.getParameter("hdnComponentDesc")));
          eCRDUtil.removeFromSession(request, "objeCRDMappedCompList"); 
//end   
          showEngineModuleListForClassifyComponent(request);
          strCont = eCRDConstants.STRCONTJSP + "ecrd-compMapping";
      }
      if ((eCRDConstants.getActionId("eCRD_GET_MAP_OSB_COMPONENT")).equals(strAction))
      {
          eCRDUtil.removeFromSession(request, "objeCRDMappedCompList");
          getmapComponent(request);

          eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODELCODE, eCRDUtil.verifyNull(request.getParameter("hdnEngineModelDesc")));

          showEngineModuleListForClassifyComponent(request);
          strCont = eCRDConstants.STRCONTJSP + "ecrd-compMappingDetail";
      }
      if ((eCRDConstants.getActionId("eCRD_EDIT_MAPPING")).equals(strAction))
      {
          //eCRDUtil.clearSession(request);
          // To get the Module List for Selected Engine Model


          if(((request.getParameter("hdnEngineModelDesc") != null)&&(request.getParameter("lstEngineModule")) != null) &&
                  ("".equals(eCRDUtil.verifyNull(request.getParameter("hdnEngineModelDesc"))) && "".equals(eCRDUtil.verifyNull(request.getParameter("lstEngineModule")))))
              //getmapComponent(request);
              editmapComponent(request);

          eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODELCODE, eCRDUtil.verifyNull(request.getParameter("hdnEngineModelDesc")));

          showEngineModuleListForClassifyComponent(request);
          strCont = eCRDConstants.STRCONTJSP + "ecrd-compMappingDetail";
      }
      if ((eCRDConstants.getActionId("eCRD_MAP_OSB_COMPONENT")).equals(strAction))
      {
          eCRDUtil.removeFromSession(request, "objeCRDMappedCompList");
          //eCRDUtil.clearSession(request);
          strMessage = mapComponent(request);

          eCRDUtil.loadInSession(request, "strMessage", strMessage);


          // To get the Module List for Selected Engine Model
          showEngineModuleListForClassifyComponent(request);
          strCont = eCRDConstants.STRCONTJSP + "ecrd-compMappingDetail";
      }
      if ((eCRDConstants.getActionId("eCRD_DELETE_MAPPING")).equals(strAction))
      {
          eCRDUtil.removeFromSession(request, "objeCRDMappedCompList");
          //eCRDUtil.clearSession(request);
          strMessage = deleteMapping(request);

          eCRDUtil.loadInSession(request, "strMessage", strMessage);

          showEngineModuleListForClassifyComponent(request);
          // To get the Module List for Selected Engine Model
          strCont = eCRDConstants.STRCONTJSP + "ecrd-compMappingDetail";
      }
      // For Component Upload and Download screen having Engine model,Module and Component  
      if ((eCRDConstants.getActionId("eCRD_VIEW_MODIFY_COMPONENT")).equals(strAction))
      {
          eCRDUtil.clearSession(request);
          showEngineModuleLocationList(request);
          strCont = eCRDConstants.STRCONTJSP + "ecrd-viewmodifyComponent";
      }
      //9292_eCRD_Batch_Download_Upload_Mapping_Shyamala Radhakrishnan	
      //For Component Mapping download Upload screen having Engine model and Site
      if ((eCRDConstants.getActionId("eCRD_BATCH_DOWNLOAD_UPLOAD_MAPPING")).equals(strAction))
		{
			strCont = eCRDConstants.STRCONTJSP + "ecrd-batchUploadDownLoadMapping";
		}
      //end
   }
  finally
  {
      strAction = "";
  }
  return strCont;
}

/*
 *  This method is used to save the cycle count class for the component
 */
private void saveClassifyComponentList(HttpServletRequest request,String strAction) throws Exception
{
String strCompClassList = "";
String strUpdateMessage = "";
String strEngineModule ="";

ArrayList arrInParam = null;
eCRDUser objeCRDUser = null;

    eCRDDefaultCatalog objeCRDDefaultCatalog = null;
    eCRDEngineModel objeCRDEngineModel = null;
    eCRDModule objeCRDModule = null;

try
{
        strEngineModule = eCRDUtil.verifyNull((String)eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE));
        objeCRDDefaultCatalog = (eCRDDefaultCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
        if (objeCRDDefaultCatalog == null)
        {
            objeCRDDefaultCatalog = new eCRDDefaultCatalog();
        }
        objeCRDEngineModel = objeCRDDefaultCatalog.getEngineModel();
        objeCRDModule = objeCRDEngineModel.getModule(strEngineModule);
        strCompClassList = eCRDUtil.verifyNull(request.getParameter("hdnCompClassList"));
        arrInParam = new ArrayList();
        arrInParam.add(strCompClassList);
        objeCRDUser = (eCRDUser)eCRDUtil.getFromSessionApp(request, "objeCRDUser");
        strUpdateMessage = objeCRDModule.updateClassifyCompList(objeCRDUser.getUserId(),strAction,strCompClassList);
        request.setAttribute("strMessage",strUpdateMessage);
}
finally
{
        strCompClassList = "";
}
}

/*
 * This method is used to get the list of components for the selected
 * engine model and engine module
 */
private void getClassifyComponentList(HttpServletRequest request) throws Exception
{
    //  To store the resultset of components
    GEAEResultSet rsComponent = null;
    //  To store the formatted resultset
    GEAEResultSet rsFormattedComponent = null;

    eCRDDataBean objeCRDDataBean = null;
    eCRDBusinessBean objeCRDBusinessBean = null;

    //  To store engine module selected
    String strEngineModule = "";
    String strAction ="";
    ArrayList arrlstInParam = null;
    try
    {
        rsFormattedComponent = new GEAEResultSet();
        objeCRDDataBean = new eCRDDataBean();
        objeCRDBusinessBean = new eCRDBusinessBean();

        strAction = eCRDConstants.getActionId("eCRD_CLASSIFY_COMPONENT_DETAILS");
        strEngineModule = eCRDUtil.verifyNull(request.getParameter("hdnEngineModule"));
        if("".equals(strEngineModule))
        {
            strEngineModule = eCRDUtil.verifyNull((String)eCRDUtil.getFromSession(request,eCRDConstants.STRENGINEMODULECODE));
        }
        arrlstInParam = new ArrayList();
        arrlstInParam.add(strEngineModule);
        rsComponent = objeCRDBusinessBean.populateComponentList(strAction, arrlstInParam);
        if (rsComponent.size() > 0)
        {
            rsComponent.setCurrentRow(0);
            // To format the resultset as per the requirement
            rsFormattedComponent = formatClassifyComponentList(rsComponent);
            request.setAttribute("RS_SIZE",""+rsFormattedComponent.size());
        }
        // To set the formatted resultset in the cache
        objeCRDDataBean.setCache(rsFormattedComponent);
        // To save the data bean object in session
        eCRDUtil.loadInSession(request, "objeCRDClassifyComponentList", objeCRDDataBean);
    }
    finally
    {
        strEngineModule = "";
    }
}
/*
 * This method is used to update component site details
 */
private void updateComponentSite(HttpServletRequest request) throws Exception
{
  System.out.println("**** Entered in updateComponentSite ------> ");
  eCRDDefaultCatalog objeCRDDefaultCatalog = null;
  eCRDEngineModel objeCRDEngineModel = null;
  eCRDComponent objeCRDComponent = null;
  eCRDModule objeCRDModule = null;
  eCRDUser objeCRDUser = null;

  String strUpdateMessage = "";
  String strEngineModule = "";
  String strComponentCode = "";
  try
  {
      strEngineModule = eCRDUtil.verifyNull((String)eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE));
      strComponentCode = eCRDUtil.verifyNull((String)eCRDUtil.getFromSession(request, eCRDConstants.STRCOMPONENTCODE));

      objeCRDDefaultCatalog = (eCRDDefaultCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
      if (objeCRDDefaultCatalog == null)
      {
          objeCRDDefaultCatalog = new eCRDDefaultCatalog();
      }

      objeCRDEngineModel = objeCRDDefaultCatalog.getEngineModel();

      objeCRDModule = objeCRDEngineModel.getModule(strEngineModule);
      objeCRDComponent = objeCRDModule.getComponent(strComponentCode);

      objeCRDComponent.clearSiteList();
      objeCRDComponent.addSite(eCRDUtil.verifyNull(request.getParameter("hdnSitesAssiciated")));
      objeCRDComponent.setModule(objeCRDModule);
      objeCRDUser = (eCRDUser)eCRDUtil.getFromSessionApp(request, "objeCRDUser");

      strUpdateMessage = objeCRDComponent.updateSites(objeCRDUser.getUserId());
      request.setAttribute("Message", strUpdateMessage);
      objeCRDModule.setEngineModel(objeCRDEngineModel);
      objeCRDEngineModel.setCatalog(objeCRDDefaultCatalog);
      eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDDefaultCatalog);
  }
  finally
  {
      strEngineModule = "";
      strComponentCode = "";
  }
}

/*
*  This method is used to update componenet details
*/
private void updateComponent(HttpServletRequest request) throws Exception
{
  eCRDDefaultCatalog objeCRDDefaultCatalog = null;
  eCRDEngineModel objeCRDEngineModel = null;
  eCRDComponent objeCRDComponent = null;
  eCRDModule objeCRDModule = null;
  eCRDUser objeCRDUser = null;
    eCRDSite objeCRDSite = null;
  String strDay = "";
  String strMonth = "";
  String strYear = "";
  String strUpdateMessage = "";
  String strEngineModule = "";
  String strComponentCode = "";
  String strAction = "";
  String strMessage = "";
  ArrayList arrlstInParam = null;
  String strUserSite = null;
  String strUserRole = null;
    eCRDSearchBean objeCRDSearchBean = null;
  try
  {
        objeCRDUser = (eCRDUser)eCRDUtil.getFromSessionApp(request, "objeCRDUser");
      strEngineModule = eCRDUtil.verifyNull((String)eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE));
      strComponentCode = eCRDUtil.verifyNull((String)eCRDUtil.getFromSession(request, eCRDConstants.STRCOMPONENTCODE));

      strDay = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_DD"));
      strMonth = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_MM"));
      strYear = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_YYYY"));
      objeCRDSite = objeCRDUser.getSite();
      strUserSite = objeCRDSite.getSiteCode();
      strUserRole = objeCRDUser.getRole();
      // Check if component description is unique or not after modification
        strAction = eCRDConstants.getActionId("eCRD_CHECK_UNIQUE_COMPDESC");
        arrlstInParam = new ArrayList();
        objeCRDSearchBean = new eCRDSearchBean();
        arrlstInParam.clear();
        arrlstInParam.add(eCRDUtil.verifyNull(request.getParameter("hdnEngineModule")));
        arrlstInParam.add(eCRDUtil.verifyNull(request.getParameter("txtComponentDescription")));
        arrlstInParam.add(strComponentCode);

        strMessage = objeCRDSearchBean.checkForUniqueComponentCodeDesc(strAction, arrlstInParam);

        if ("".equals(strMessage)) // Unique desc
        {
            objeCRDDefaultCatalog = (eCRDDefaultCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
            if (objeCRDDefaultCatalog == null)
            {
                objeCRDDefaultCatalog = new eCRDDefaultCatalog();
            }

            objeCRDEngineModel = objeCRDDefaultCatalog.getEngineModel();

            objeCRDModule = objeCRDEngineModel.getModule(strEngineModule);
            objeCRDComponent = objeCRDModule.getComponent(strComponentCode);
            //Adding the Check Whether Component Site Approval is Pending.
            strAction = eCRDConstants.getActionId("eCRD_COMP_SITE_APPR_PENDING");
            arrlstInParam.clear();
            arrlstInParam.add(eCRDUtil.verifyNull(request.getParameter("hdnEngineModule")));
            arrlstInParam.add(strComponentCode);
            arrlstInParam.add(strUserSite);
            arrlstInParam.add(strUserRole);

            strMessage = objeCRDComponent.isComponentSiteAppPending(strAction,arrlstInParam);
            if("".equals(strMessage))
            {
                objeCRDComponent.setComponentDesc(eCRDUtil.verifyNull(request.getParameter("txtComponentDescription")));
                objeCRDComponent.setATARefNo(eCRDUtil.verifyNull(request.getParameter("txtATAReferenceNumber")));
                objeCRDComponent.setBaseLineTAT(eCRDUtil.verifyNull(request.getParameter("txtBaselineTAT")));
                objeCRDComponent.setPercentageYield(eCRDUtil.verifyNull(request.getParameter("txtAgeRepairYield")));
                objeCRDComponent.setComponentEffDt(eCRDUtil.verifyNull(eCRDUtil.formatDate(strDay, strMonth, strYear)));
                objeCRDComponent.setQtyCompPerEngine(eCRDUtil.verifyNull(request.getParameter("txtQuantityPartsPerSet")));
                objeCRDComponent.setCycValClass(eCRDUtil.verifyNull(request.getParameter("lstClass")));
                objeCRDComponent.setTechLvl(eCRDUtil.verifyNull(request.getParameter("tectLvl")));
                objeCRDComponent.setScrapRateAtExposure(eCRDUtil.verifyNull(request.getParameter("txtComponentScrapExposureRate")));
                objeCRDComponent.setServicableAtExposure(eCRDUtil.verifyNull(request.getParameter("txtServiceableAtExposureRate")));
                objeCRDComponent.setShopVisitExposureRate(eCRDUtil.verifyNull(request.getParameter("txtComponentShopVisitExposureRate")));
                objeCRDComponent.setAlternateComponent(eCRDUtil.verifyNull(request.getParameter("hdnAltComponent")));

                objeCRDComponent.clearPartList();
                objeCRDComponent.addPart(eCRDUtil.verifyNull(request.getParameter("hdnPartNumbers")));
                objeCRDComponent.clearSiteList();
                objeCRDComponent.addSite(eCRDUtil.verifyNull(request.getParameter("hdnSitesAssiciated")));
                objeCRDComponent.setModule(objeCRDModule);
                objeCRDComponent.removeRepairs();

                strUpdateMessage = objeCRDComponent.update(objeCRDUser.getUserId(), objeCRDUser.getRole());

                request.setAttribute("Message", strUpdateMessage);
                objeCRDModule.setEngineModel(objeCRDEngineModel);
                objeCRDEngineModel.setCatalog(objeCRDDefaultCatalog);
                eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDDefaultCatalog);
            }
            else
            {
                request.setAttribute("Message", strMessage);
            }
        }
        else
        {
            request.setAttribute("Message", strMessage);
        }
  }
  finally
  {
      strDay = "";
      strMonth = "";
      strYear = "";
      strEngineModule = "";
      strComponentCode = "";
  }
}
/*
* This method is used to delete selected component
*/

private void deleteComponent(HttpServletRequest request) throws Exception
{
  eCRDDefaultCatalog objeCRDDefaultCatalog = null;
  eCRDEngineModel objeCRDEngineModel = null;
  eCRDModule objeCRDModule = null;
  String strComponentSeqId = "";
  eCRDUser objeCRDUser = null;
  String strMessage = "";
  String strEngineModel = "";
  String strEngineModule = "";
//  String strComponentCd = "";
  try
  {
      objeCRDDefaultCatalog = (eCRDDefaultCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
      objeCRDUser = (eCRDUser)eCRDUtil.getFromSessionApp(request, "objeCRDUser");
      strEngineModel = eCRDUtil.verifyNull((String)eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODELCODE));
      strEngineModule = eCRDUtil.verifyNull((String)eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE));
      strComponentSeqId = eCRDUtil.verifyNull((String)eCRDUtil.getFromSession(request, eCRDConstants.STRCOMPONENTCODE));
      if (objeCRDDefaultCatalog == null)
      {
          objeCRDDefaultCatalog = new eCRDDefaultCatalog(strEngineModel,eCRDConstants.STRENGMODELCONST);//Changed the constructor called to get loaded catalog object
      }
      objeCRDEngineModel = objeCRDDefaultCatalog.getEngineModel();
      objeCRDModule = objeCRDEngineModel.getModule(strEngineModule);

      //strComponentSeqId = eCRDUtil.verifyNull(request.getParameter("txtComponentCode"));
      strMessage = objeCRDModule.removeComponent(strComponentSeqId, objeCRDUser.getUserId(), objeCRDUser.getRole());

      request.setAttribute("Message", strMessage);
  }
  finally
  {
      objeCRDModule = null;
  }
}
/*
* This method is used to get list of components from the database based
* on the values of selected engine model,engine module,ATA reference number,
* component code ,component description
* @param request
*/
private void getComponentList(HttpServletRequest request, String strAction) throws Exception
{
  //    To store the resultset of components
  GEAEResultSet rsComponent = null;
  //    To store the formatted resultset
  GEAEResultSet rsFormattedComponent = null;

  eCRDDataBean objeCRDDataBean = null;
  eCRDBusinessBean objeCRDBusinessBean = null;

  //    To store engine model selected
  String strEngineModel = "";
  //    To store engine module selected
  String strEngineModule = "";
  //    To store component selected (CODE / DESCRIPTION)
  String strComponent = "";
  //    To store value corresponding to the component selected
  String strComponentValue = "";
  //  To store the ATA reference Number entered
  String strATAReference = "";
  // To store Engine Module Description
  String strEngineModuleDescription = "";

  ArrayList arrlstInParam = null;
  try
  {
      rsFormattedComponent = new GEAEResultSet();

      objeCRDDataBean = new eCRDDataBean();
      objeCRDBusinessBean = new eCRDBusinessBean();

      //    To get the required entries from the JSP
      strEngineModel = eCRDUtil.verifyNull(request.getParameter("hdnEngineModelDesc"));
      strEngineModule = eCRDUtil.verifyNull(request.getParameter("hdnEngineModuleDesc"));
      strComponent = eCRDUtil.verifyNull(request.getParameter("hdnComponent"));
      strComponentValue = eCRDUtil.verifyNull(request.getParameter("hdnComponentValue"));
      strATAReference = eCRDUtil.verifyNull(request.getParameter("hdnATAReference"));

      arrlstInParam = new ArrayList();
      arrlstInParam.add(strEngineModel);
      arrlstInParam.add(strEngineModule);
      arrlstInParam.add(strComponent);
      arrlstInParam.add(strComponentValue);
      arrlstInParam.add(strATAReference);
 
      //    To get the resultset of components for the required combination of
      //    engine model,engine module,ATANumber,Component Code,component description

      rsComponent = objeCRDBusinessBean.populateComponentList(strAction, arrlstInParam);
      if (rsComponent.size() > 0)
      {
          rsComponent.setCurrentRow(0);
          rsComponent.next();
          // To format the resultset as per the requirement
          // TO DISPLAY THE ENGINE MODULE DESCRIPTION IN THE POP UP
            rsFormattedComponent = formatComponentList(rsComponent);    
      }
      // To set the formatted resultset in the cache
      objeCRDDataBean.setCache(rsFormattedComponent);
      // To save the data bean object in session
      eCRDUtil.loadInSession(request, "objeCRDCompList", objeCRDDataBean);
      eCRDUtil.loadInSession(request, "hdnComponent", strComponent);
  }
  finally
  {
      strEngineModel = "";
      strEngineModule = "";
      strComponent = "";
      strComponentValue = "";
      strATAReference = "";
  }
}
private void getViewModifyComponentList(HttpServletRequest request, String strAction) throws Exception
{
  //    To store the resultset of components
  GEAEResultSet rsComponent = null;
  //    To store the formatted resultset
  GEAEResultSet rsFormattedComponent = null;

  eCRDDataBean objeCRDDataBean = null;
  eCRDBusinessBean objeCRDBusinessBean = null;

  //    To store engine model selected
  String strEngineModel = "";
  //    To store engine module selected
  String strEngineModule = "";
  //    To store component selected (CODE / DESCRIPTION)
  String strComponent = "";
  //    To store value corresponding to the component selected
  String strComponentValue = "";
  // To store Engine Module Description
  String strEngineModuleDescription = "";
  
  ArrayList arrlstInParam = null;
  try
  {
      rsFormattedComponent = new GEAEResultSet();

      objeCRDDataBean = new eCRDDataBean();
      objeCRDBusinessBean = new eCRDBusinessBean();

      //    To get the required entries from the JSP
      strEngineModel = eCRDUtil.verifyNull(request.getParameter("hdnEngineModelDesc"));
      strEngineModule = eCRDUtil.verifyNull(request.getParameter("hdnEngineModuleDesc"));
      strComponent = eCRDUtil.verifyNull(request.getParameter("hdnComponent"));
      strComponentValue = eCRDUtil.verifyNull(request.getParameter("hdnComponentValue"));
      arrlstInParam = new ArrayList();
      arrlstInParam.add(strEngineModel);
      arrlstInParam.add(strEngineModule);
      arrlstInParam.add(strComponent);
      arrlstInParam.add(strComponentValue);
      
      

      //    To get the resultset of components for the required combination of
      //    engine model,engine module,ATANumber,Component Code,component description

      rsComponent = objeCRDBusinessBean.populateComponentList(strAction, arrlstInParam);
      if (rsComponent.size() > 0)
      {
          rsComponent.setCurrentRow(0);
          rsComponent.next();
          // To format the resultset as per the requirement
          // TO DISPLAY THE ENGINE MODULE DESCRIPTION IN THE POP UP
          
          rsFormattedComponent = formatViewModifyComponentList(rsComponent);   
          
      }
      // To set the formatted resultset in the cache
      objeCRDDataBean.setCache(rsFormattedComponent);
      // To save the data bean object in session
      eCRDUtil.loadInSession(request, "objeCRDCompList", objeCRDDataBean);
      eCRDUtil.loadInSession(request, "hdnComponent", strComponent);
  }
  finally
  {
      strEngineModel = "";
      strEngineModule = "";
      strComponent = "";
      strComponentValue = "";
    
  }
}
/*
 * This method is used to show component details page based on whether operation
 * selected is Add new Component or Modify Existing component
 * @param request
 * return parameter = int
 * 1)  Add new component details = return value = 0
 * 2   Modify component details  = return value = 1
 * 3)  Modify component Page  = return value = -1
 *  Last variable used to check whether component with selected values of engine
 *  model,engine module,ATA reference number,componenet code,component description
 *  is not found
*/
private int showComponentDetails(HttpServletRequest request) throws Exception
{
  String strOperation = "";
  int intIfComponentExists = 0;
  try
  {
      strOperation = eCRDUtil.verifyNull(request.getParameter("hdnCheckOperation"));
      if (strOperation.equals("Modify"))
      {
          //    Check if the component with given combination is present or not
          intIfComponentExists = modifyComponent(request);
      }
      else // Operation is add component details
          {
          intIfComponentExists = 0;
      }
  }
  finally
  {
      strOperation = "";
  }
  return (intIfComponentExists);
}

/*
* This method is used to Show the module list for the corresponding engine model
* selected in case of classify component
*/
private void showEngineModuleListForClassifyComponent(HttpServletRequest request) throws Exception
{
    GEAEResultSet rsEngineModule = null;
    GEAEResultSet rsSiteList = null;
    String strEngineModel = "";
    String strModuleDropDown = "";
    String strEngineModule = "";
    //9292_Shyamala Radhakrishnan	
    String strCompCode = "";
    String strCompDesc = "";
    String strSiteDropDown = "";
    String strSite = "";
    //end
    try
    {
        strEngineModel = eCRDUtil.verifyNull((String)eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODELCODE));
        if (strEngineModel.equals(""))
        {
            strEngineModel = eCRDUtil.verifyNull(request.getParameter("lstEngineModel"));
        }
        strEngineModule = eCRDUtil.verifyNull((String)eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE));
        if (strEngineModule.equals(""))
        {
            strEngineModule = eCRDUtil.verifyNull(request.getParameter("hdnEngineModule"));
        }

        if (!strEngineModel.equals(""))
        {
            //  To select the list of modules depending upon the engine model selected
            rsEngineModule = eCRDLoadMaster.getMasterModuleList(strEngineModel);
            //  To get the list of modules in required format of dropdown list
            strModuleDropDown = eCRDUtil.populateOptions(rsEngineModule, strEngineModule, false);
            eCRDUtil.loadInSession(request,"strModuleDropDown",strModuleDropDown);
            eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODELCODE, strEngineModel);
        }
        //9292__Shyamala Radhakrishnan	
        String strCompType = eCRDUtil.verifyNull(request.getParameter("hdnComponent"));
        if(strCompType == "Code")
        {     	
        	strCompCode = eCRDUtil.verifyNull((String)eCRDUtil.getFromSession(request, eCRDConstants.STRCOMPONENTCODE));
        }
        else
        {
        	strCompDesc = eCRDUtil.verifyNull((String)eCRDUtil.getFromSession(request, eCRDConstants.STRCOMPONENTDESC));
        }
        
        strSite = eCRDUtil.verifyNull(request.getParameter("hdnSite"));
        
        if(strCompType.equals("Code"))
        {
        	if (strCompCode.equals(""))
        	{
        	
        		strCompCode = eCRDUtil.verifyNull(request.getParameter("hdnComponentCode"));
        	
        	}

        	if (!strCompCode.equals(""))
        	{
        		//  To select the list of sites depending upon the input Component Code
        		rsSiteList = eCRDLoadMaster.getSiteListComp(request, strEngineModule,strCompCode,strCompDesc,strCompType);
        		//  To get the list of Sites in required format of dropdown list
        		strSiteDropDown = eCRDUtil.populateOptions(rsSiteList, strSite, false);
        		eCRDUtil.loadInSession(request,"strSiteDropDown",strSiteDropDown);
        		eCRDUtil.loadInSession(request, eCRDConstants.STRCOMPONENTCODE, strCompCode);
        	}
        }
        else
        {
        	if (strCompDesc.equals(""))
        	{
               	
        		strCompDesc = eCRDUtil.verifyNull(request.getParameter("hdnComponentDesc"));
        	
        	}

        	if (!strCompDesc.equals(""))
        	{
        		//	To select the list of sites depending upon the input Component Description
        		rsSiteList = eCRDLoadMaster.getSiteListComp(request, strEngineModule,strCompCode,strCompDesc,strCompType);
        		//  To get the list of Sites in required format of dropdown list
        		strSiteDropDown = eCRDUtil.populateOptions(rsSiteList, strSite, false);
        		eCRDUtil.loadInSession(request,"strSiteDropDown",strSiteDropDown);
        		eCRDUtil.loadInSession(request, eCRDConstants.STRCOMPONENTDESC, strCompDesc);
        	}
        }
        //end        
    }
    finally
    {
        rsEngineModule = null;
        rsSiteList = null;
        strEngineModel = "";
        strModuleDropDown = "";
        strEngineModule = "";
        //9292__Shyamala Radhakrishnan	        
        strSiteDropDown = "";
        strSite= "";
        //end        
    }
}

/*
* This method is used to populate engine module dropdown according to the engine
* model selected
*/
private void showEngineModuleList(HttpServletRequest request) throws Exception
{
  GEAEResultSet rsEngineModule = null;
  String strEngineModel = "";
  String strModuleDropDown = "";
  String strEngineModule = "";
  try
  {
      strEngineModel = eCRDUtil.verifyNull((String)eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODELCODE));
      if (strEngineModel.equals(""))
      {
          strEngineModel = eCRDUtil.verifyNull(request.getParameter("lstEngineModel"));
      }
        strEngineModule = eCRDUtil.verifyNull((String)eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE));
        if (strEngineModule.equals(""))
        {
          strEngineModule = eCRDUtil.verifyNull(request.getParameter("hdnEngineModule"));
          
        }

      if (!strEngineModel.equals(""))
      {
          //    To select the list of modules depending upon the engine model selected
          rsEngineModule = eCRDLoadMaster.getMasterModuleList(strEngineModel);
          //    To get the list of modules in required format of dropdown list
          strModuleDropDown = eCRDUtil.populateOptions(rsEngineModule, strEngineModule, false);
          request.setAttribute("strModuleDropDown", strModuleDropDown);
          eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODELCODE, strEngineModel);
      }
  }
  finally
  {
      rsEngineModule = null;
      strEngineModel = "";
      strModuleDropDown = "";
      strEngineModule = "";
  }
}
/*
* This method is used to populate engine module dropdown according to the engine
* model selected
*/
private void showEngineModuleLocationList(HttpServletRequest request) throws Exception
{
  ArrayList arrModuleLocation = null;
  GEAEResultSet rsEngineModule = null;
  GEAEResultSet rsEngineLocation = null;
  String strEngineModel = "";
  String strModuleDropDown = "";
  String strEngineModule = "";
  String strComponentLocation = "";
  String strLocationDropDown = "";
  
  try
  {
      strEngineModel = eCRDUtil.verifyNull((String)eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODELCODE));
      if (strEngineModel.equals(""))
      {
          strEngineModel = eCRDUtil.verifyNull(request.getParameter("lstEngineModel"));
      }
      strEngineModule = eCRDUtil.verifyNull((String)eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE));
      
      if (strEngineModule.equals(""))
      {
          strEngineModule = eCRDUtil.verifyNull(request.getParameter("hdnEngineModule"));
          
      }
       if (strComponentLocation.equals(""))
      {
          strComponentLocation = eCRDUtil.verifyNull(request.getParameter("hdnEngineModule"));
                               
      }

      if (!strEngineModel.equals(""))
      {
          //  To select the list of modules depending upon the engine model selected
          arrModuleLocation = eCRDLoadMaster.getMasterModuleLocationList(strEngineModel);
          rsEngineModule = (GEAEResultSet) arrModuleLocation.get(0);
          rsEngineLocation = (GEAEResultSet) arrModuleLocation.get(1);
          //  To get the list of modules in required format of dropdown list
          strModuleDropDown = eCRDUtil.populateOptions(rsEngineModule, strEngineModule, false);
          
          // To get the list of Locations in required format of dropdown list
          strLocationDropDown = eCRDUtil.populateOptions(rsEngineLocation, strComponentLocation, false);
          
          request.setAttribute("strModuleDropDown", strModuleDropDown);
          request.setAttribute("strLocationDropDown", strLocationDropDown);
          eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODELCODE, strEngineModel);
      }
  }
  finally
  {
      rsEngineModule = null;
      strEngineModel = "";
      strModuleDropDown = "";
      strEngineModule = "";
  }
}
/*
* This method is used to format the resultset containing list of components
* @ param  GEAEResultSet,HttpServletRequest
*/
private GEAEResultSet formatViewModifyComponentList(GEAEResultSet rsComponentList) throws Exception
{
  GEAEResultSet rsFormattedComponentList = null;
  GEAETagNoData tagRadio = null;

  ArrayList arrlstFormattedComponentList = null;

  String strRadioValue = "";
  String strComponentCode = "";
  try
  {
      if (rsComponentList != null && rsComponentList.size() > 0)
      {
          rsFormattedComponentList = new GEAEResultSet();
          for (int i = 0; i < rsComponentList.size(); i++)
          {
              arrlstFormattedComponentList = new ArrayList();
              strComponentCode = rsComponentList.getString(1);
              strRadioValue = "" + eCRDUtil.replaceQuoteForJS(strComponentCode);
              tagRadio =
                  new GEAETagNoData(
                      "<INPUT TYPE=\"radio\" NAME=\"radComponent\" VALUE=\""
                          + strRadioValue
                          + "\" onClick = \"javascript:fnGetComponentValue('"
                          + rsComponentList.getString(2)
                          + "','"
                          + rsComponentList.getString(3)
                          + "',document.frmComponentList)\" ");
              arrlstFormattedComponentList.add(tagRadio);
              arrlstFormattedComponentList.add(eCRDUtil.verifyNull(rsComponentList.getString(1)));
              arrlstFormattedComponentList.add(eCRDUtil.verifyNull(rsComponentList.getString(2)));
              arrlstFormattedComponentList.add(eCRDUtil.verifyNull(rsComponentList.getString(3)));
              rsFormattedComponentList.addRow(arrlstFormattedComponentList);
              rsComponentList.next();
          }
          rsFormattedComponentList.setColumnHeading(1, "Select");
          rsFormattedComponentList.setColumnHeading(2, "Engine Module");
          rsFormattedComponentList.setColumnHeading(3, "Component Code");
          rsFormattedComponentList.setColumnHeading(4, "Component Description");
      }
  }
  finally
  {
      tagRadio = null;
      strRadioValue = "";
      strComponentCode = "";
      arrlstFormattedComponentList = null;
  }
  return rsFormattedComponentList;
}

/*
* This method is used to format the resultset containing list of components
* @ param  GEAEResultSet,HttpServletRequest
*/
private GEAEResultSet formatComponentList(GEAEResultSet rsComponentList) throws Exception
{
  GEAEResultSet rsFormattedComponentList = null;
  GEAETagNoData tagRadio = null;

  ArrayList arrlstFormattedComponentList = null;

  String strRadioValue = "";
  String strComponentCode = "";
  try
  {
      if (rsComponentList != null && rsComponentList.size() > 0)
      {
          rsFormattedComponentList = new GEAEResultSet();
          for (int i = 0; i < rsComponentList.size(); i++)
          {
              arrlstFormattedComponentList = new ArrayList();
              strComponentCode = rsComponentList.getString(1);
              strRadioValue = "" + eCRDUtil.replaceQuoteForJS(strComponentCode);
              tagRadio =
                  new GEAETagNoData(
                      "<INPUT TYPE=\"radio\" NAME=\"radComponent\" VALUE=\""
                          + strRadioValue
                          + "\" onClick = \"javascript:fnGetComponentValue('"
                          + rsComponentList.getString(1)
                          + "','"
                          + rsComponentList.getString(2)
                          + "',document.frmComponentList)\" ");
              arrlstFormattedComponentList.add(tagRadio);
              arrlstFormattedComponentList.add(eCRDUtil.verifyNull(rsComponentList.getString(1)));
              arrlstFormattedComponentList.add(eCRDUtil.verifyNull(rsComponentList.getString(2)));
              rsFormattedComponentList.addRow(arrlstFormattedComponentList);
              rsComponentList.next();
          }
          rsFormattedComponentList.setColumnHeading(1, "Select");
          rsFormattedComponentList.setColumnHeading(2, "Component Code");
          rsFormattedComponentList.setColumnHeading(3, "Component Description");
      }
  }
  finally
  {
      tagRadio = null;
      strRadioValue = "";
      strComponentCode = "";
      arrlstFormattedComponentList = null;
  }
  return rsFormattedComponentList;
}



/*
* This method is used to format the classify component list
*/
private GEAEResultSet formatClassifyComponentList(GEAEResultSet rsComponentList) throws Exception
{
    GEAEResultSet rsFormattedComponentList = null;
    GEAEResultSet rsClassList = null;
    GEAETagNoData tagSelect = null;
    ArrayList arrlstFormattedComponentList = null;
    String strClass = "";
    String strClassList = "";
    int i=0;

    try
    {
        rsClassList = new GEAEResultSet();
        rsClassList = eCRDLoadMaster.getCycClassList();
        if (rsComponentList != null && rsComponentList.size() > 0)
        {
            rsFormattedComponentList = new GEAEResultSet();

            for (i = 0; i < rsComponentList.size(); i++)
            {
                arrlstFormattedComponentList = new ArrayList();
                rsComponentList.next();
                strClass = eCRDUtil.verifyNull(rsComponentList.getString(3));
                strClassList= eCRDUtil.verifyNull(eCRDUtil.populateOptionsWithoutSelect(rsClassList,strClass,false));
                arrlstFormattedComponentList.add(eCRDUtil.verifyNull(rsComponentList.getString(1)));
                arrlstFormattedComponentList.add(eCRDUtil.verifyNull(rsComponentList.getString(2)));
                rsClassList.setCurrentRow(0);
                tagSelect =
                        new GEAETagNoData(
                        "<INPUT TYPE=\"hidden\" NAME=\"hdnCompCode\" VALUE=\" " +rsComponentList.getString(1)+ "\"><INPUT TYPE=\"hidden\" NAME=\"hdnCompClass\" VALUE=\"\"><SELECT NAME=\"lstClass\" CLASS=\"f2\"  ONCHANGE=\"fnCheckClass('" + rsComponentList.getString(3)+"','"+ rsComponentList.getString(1)+"',document.rowcachedform)\" >" + strClassList + "</SELECT>");
                arrlstFormattedComponentList.add(tagSelect);
                rsFormattedComponentList.addRow(arrlstFormattedComponentList);
            }
            rsFormattedComponentList.setColumnHeading(1, "Component Code");
            rsFormattedComponentList.setColumnHeading(2, "Component Description");
            rsFormattedComponentList.setColumnHeading(3, "Class");
        }
    }
    finally
    {
        arrlstFormattedComponentList = null;
    }
    return rsFormattedComponentList;
}
/*
* This method is used to check whether component is present for the selected
* combination of engine model,engine module,ATA reference number,Component Code,
* Component Description.
* @ param request
* return param - int
* returns -1 if component found
*          1 If component not found
*/
private int modifyComponent(HttpServletRequest request) throws Exception
{
  GEAEResultSet rsComponent = null;
  eCRDDefaultCatalog objeCRDDefaultCatalog = null;
  eCRDEngineModel objeCRDEngineModel = null;
  eCRDModule objeCRDModule = null;
  eCRDComponent objeCRDComponent = null;
  eCRDBusinessBean objeCRDBusinessBean = null;

  String strEngineModel = "";
  String strEngineModule = "";
  String strComponent = "";
  String strComponentValue = "";
  String strATAReference = "";
  String strAction = "";

  int intCheckIfComponentFound = 0;

  ArrayList arrlstInParam = null;
  try
  {
      objeCRDBusinessBean = new eCRDBusinessBean();

      //    To get the required entries from JSP
      strEngineModel = eCRDUtil.verifyNull(request.getParameter("hdnEngineModelDesc"));
      strEngineModule = eCRDUtil.verifyNull(request.getParameter("lstEngineModule"));
      strComponent = eCRDUtil.verifyNull(request.getParameter("hdnComponent"));
      strComponentValue = eCRDUtil.verifyNull(request.getParameter("txtComponent"));
      strATAReference = eCRDUtil.verifyNull(request.getParameter("txtATANumber"));
        strComponentValue = strComponentValue.toUpperCase();
      //    To get the resultset of components for the required combination of
      //    engine model,engine module,ATANumber,Component Code,component description

      strAction = eCRDConstants.getActionId("eCRD_MODIFY_COMPONENT");

      arrlstInParam = new ArrayList();
      arrlstInParam.add(strEngineModel);
      arrlstInParam.add(strEngineModule);
      arrlstInParam.add(strComponent);
      arrlstInParam.add(strComponentValue);
      arrlstInParam.add(strATAReference);

      rsComponent = objeCRDBusinessBean.populateComponentList(strAction, arrlstInParam);

      if (rsComponent.size() == 0)
      {
          eCRDUtil.loadInSession(request, eCRDConstants.STRCHECKIFCOMPONENTFOUND, eCRDConstants.STRCOMPONENTNOTFOUND);
          intCheckIfComponentFound = -1;
      }
      else
      {
          rsComponent.setCurrentRow(0);
          rsComponent.next();
          strComponentValue = rsComponent.getString(1);

          objeCRDDefaultCatalog = (eCRDDefaultCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
          if (objeCRDDefaultCatalog == null)
          {
              objeCRDDefaultCatalog = new eCRDDefaultCatalog(strEngineModel,eCRDConstants.STRENGMODELCONST);//Changed the constructor called to get loaded catalog object
          }
          objeCRDEngineModel = new eCRDEngineModel(strEngineModel);
          objeCRDDefaultCatalog.setEngineModel(objeCRDEngineModel);
          objeCRDModule = objeCRDEngineModel.getModule(strEngineModule);
          objeCRDComponent = new eCRDComponent();
          objeCRDComponent.setComponentCode(strComponentValue);

          objeCRDComponent.setModule(objeCRDModule);
          objeCRDModule.setEngineModel(objeCRDEngineModel);
          objeCRDEngineModel.setCatalog(objeCRDDefaultCatalog);

          eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDDefaultCatalog);
          eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODELCODE, strEngineModel);
          eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODULECODE, strEngineModule);
          eCRDUtil.loadInSession(request, eCRDConstants.STRCOMPONENTCODE, strComponentValue);
          intCheckIfComponentFound = 1;
      }
  }
  finally
  {
      rsComponent = null;
      objeCRDDefaultCatalog = null;
      objeCRDEngineModel = null;
      objeCRDModule = null;
      objeCRDComponent = null;
      objeCRDBusinessBean = null;
      strEngineModel = "";
      strEngineModule = "";
      strComponent = "";
      strComponentValue = "";
      strATAReference = "";
      strAction = "";
  }
  return (intCheckIfComponentFound);
}
/**
* Executes steps for creating components.
*/
private int createComponent(HttpServletRequest request, String strFlag) throws Exception
{
  String strDay = ""; // To store Day of the Date
  String strMonth = ""; // To store Month of the Date
  String strYear = ""; // To store Month of the Date
  String strMessage = "";
  String strAction = "";

  eCRDDefaultCatalog objeCRDDefaultCatalog = null;
  eCRDEngineModel objeCRDEngineModel = null;
  eCRDModule objeCRDModule = null;
  eCRDComponent objeCRDComponent = null;
  eCRDSearchBean objeCRDSearchBean = null;
  String strModelCode = null;

  ArrayList arrlstInParam = null;

  int intcheckIfUniqueComponent = 0;
  try
  {
      arrlstInParam = new ArrayList();
      objeCRDSearchBean = new eCRDSearchBean();

      // Retrieving values from the textboxes of JSP page
      strDay = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_DD"));
      strMonth = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_MM"));
      strYear = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_YYYY"));
      objeCRDDefaultCatalog = (eCRDDefaultCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
        strModelCode = eCRDUtil.verifyNull(request.getParameter("hdnEngineModel"));

      if (objeCRDDefaultCatalog == null)
      {
          objeCRDDefaultCatalog = new eCRDDefaultCatalog(strModelCode,eCRDConstants.STRENGMODELCONST);//Changed the constructor called to get loaded catalog object
      }
      objeCRDEngineModel = objeCRDDefaultCatalog.getEngineModel();
      if (objeCRDEngineModel == null)
      {
          objeCRDEngineModel = new eCRDEngineModel();
          objeCRDDefaultCatalog.setEngineModel(objeCRDEngineModel);
      }

      //            objeCRDEngineModel = new eCRDEngineModel(eCRDUtil.verifyNull(request.getParameter("hdnEngineModel")));
      objeCRDModule = objeCRDEngineModel.getModule(eCRDUtil.verifyNull(request.getParameter("hdnEngineModule")));
      //objeCRDComponent.setModule(objeCRDModule);

      // Check if component code is unique or not

      strAction = eCRDConstants.getActionId("eCRD_CHECK_UNIQUE_COMPCODE");
      arrlstInParam.add(eCRDUtil.verifyNull(request.getParameter("hdnEngineModel")));
      arrlstInParam.add(eCRDUtil.verifyNull(request.getParameter("txtComponentCode")));
      //Only if the request is comin from the add component the check for the unique code is need to be done. and not in the case of component approval
      if (strFlag.equals("1"))
    {
          strMessage = objeCRDSearchBean.checkForUniqueComponentCodeDesc(strAction, arrlstInParam);
        }

      if ("".equals(strMessage))
      {
          // Check if component description is unique or not
            strAction = eCRDConstants.getActionId("eCRD_CHECK_UNIQUE_COMPDESC");
            arrlstInParam.clear();
            arrlstInParam.add(eCRDUtil.verifyNull(request.getParameter("hdnEngineModule")));
            arrlstInParam.add(eCRDUtil.verifyNull(request.getParameter("txtComponentDescription")));
          if (strFlag.equals("1"))
          {
                arrlstInParam.add("");
            }
            else if (strFlag.equals("2"))
            {
                arrlstInParam.add(eCRDUtil.verifyNull(request.getParameter("hdnComponentCode")));
            }

            strMessage = objeCRDSearchBean.checkForUniqueComponentCodeDesc(strAction, arrlstInParam);

          if ("".equals(strMessage)) // Unique desc
          {
              if (strFlag.equals("1"))
              {
                  objeCRDComponent = objeCRDModule.addComponent();
              }
              else
              {
                  // add component code string in ths if  loop
                  objeCRDComponent = objeCRDModule.getComponent(request.getParameter("hdnComponentCode"));
              }
              if (strFlag.equals("1"))
              {
                  objeCRDComponent.setComponentCode(eCRDUtil.verifyNull(request.getParameter("txtComponentCode")).toUpperCase());
              }
              else
              {
                  objeCRDComponent.setComponentCode(eCRDUtil.verifyNull(request.getParameter("hdnComponentCode")).toUpperCase());
              }
              objeCRDComponent.setComponentDesc(eCRDUtil.verifyNull(request.getParameter("txtComponentDescription")));
              objeCRDComponent.setATARefNo(eCRDUtil.verifyNull(request.getParameter("txtATAReferenceNumber")));
              objeCRDComponent.setBaseLineTAT(eCRDUtil.verifyNull(request.getParameter("txtBaselineTAT")));
              objeCRDComponent.setPercentageYield(eCRDUtil.verifyNull(request.getParameter("txtAgeRepairYield")));
              objeCRDComponent.setComponentEffDt(eCRDUtil.verifyNull(eCRDUtil.formatDate(strDay, strMonth, strYear)));
              objeCRDComponent.setQtyCompPerEngine(eCRDUtil.verifyNull(request.getParameter("txtQuantityPartsPerSet")));
              objeCRDComponent.setCycValClass(eCRDUtil.verifyNull(request.getParameter("lstClass")));
              objeCRDComponent.setTechLvl(eCRDUtil.verifyNull(request.getParameter("tectLvl")));
              objeCRDComponent.setScrapRateAtExposure(eCRDUtil.verifyNull(request.getParameter("txtComponentScrapExposureRate")));
              objeCRDComponent.setServicableAtExposure(eCRDUtil.verifyNull(request.getParameter("txtServiceableAtExposureRate")));
              objeCRDComponent.setShopVisitExposureRate(eCRDUtil.verifyNull(request.getParameter("txtComponentShopVisitExposureRate")));
              objeCRDComponent.setAlternateComponent(eCRDUtil.verifyNull(request.getParameter("hdnAltComponent")));
              objeCRDComponent.clearPartList();
              objeCRDComponent.addPart(eCRDUtil.verifyNull(request.getParameter("hdnPartNumbers")));
              objeCRDComponent.clearSiteList();
              objeCRDComponent.addSite(eCRDUtil.verifyNull(request.getParameter("hdnSitesAssiciated")));
              objeCRDComponent.setModule(objeCRDModule);
              objeCRDModule.setEngineModel(objeCRDEngineModel);
              objeCRDEngineModel.setCatalog(objeCRDDefaultCatalog);
              eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDDefaultCatalog);

              if (strFlag.equals("1"))
              {
                  eCRDUtil.loadInSession(request, eCRDConstants.STRCOMPONENTCODE, eCRDUtil.verifyNull(request.getParameter("txtComponentCode")));
              }
              else
              {
                  eCRDUtil.loadInSession(request, eCRDConstants.STRCOMPONENTCODE, eCRDUtil.verifyNull(request.getParameter("hdnComponentCode")));
              }

          }
          else
          {
              intcheckIfUniqueComponent = -1;
          }
      }
      else
      {
          intcheckIfUniqueComponent = -1;
      }
      request.setAttribute("Message", strMessage);
  }
  finally
  {
      strDay = "";
      strMonth = "";
      strYear = "";
  }
  return (intcheckIfUniqueComponent);
}

/*
* This method is used to save catalog object in session when the engine model
* and engine module are selected.
*/
private void saveCatalogObjectInSession(HttpServletRequest request) throws Exception
{
    String strEngineModelCode = ""; // String variable to store Engine Model Code
    String strEngineModuleCode = ""; // String variable to store Engine Module Code
    String strEngineModelDesc = "";
    String strEngineModuleDesc = "";
    eCRDDefaultCatalog objeCRDDefaultCatalog = null;
    eCRDEngineModel objeCRDEngineModel = null;
    eCRDModule objeCRDModule = null;
//  eCRDCatalog objeCRDCatalog = null;

    try
    {
        // Get the engine model code selected by the user
        strEngineModelCode = eCRDUtil.verifyNull(request.getParameter("hdnEngineModel"));
        // Get the engine module code selected by the user
        strEngineModuleCode = eCRDUtil.verifyNull(request.getParameter("hdnEngineModule"));
        strEngineModelDesc = eCRDUtil.verifyNull(request.getParameter("hdnEngineModelDesc"));
        strEngineModuleDesc = eCRDUtil.verifyNull(request.getParameter("hdnEngineModuleDesc"));

//      objeCRDCatalog = (eCRDDefaultCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
        objeCRDDefaultCatalog = (eCRDDefaultCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
        if (objeCRDDefaultCatalog == null)
        {
            objeCRDDefaultCatalog = new eCRDDefaultCatalog(eCRDCatalog.getCurrentDefaultSeqId(strEngineModelCode));//Changed the constructor called to get loaded catalog object
        }
        /*added new */
        objeCRDEngineModel = objeCRDDefaultCatalog.getEngineModel();
        if (objeCRDEngineModel == null)
        {
            objeCRDEngineModel = new eCRDEngineModel();
            objeCRDDefaultCatalog.setEngineModel(objeCRDEngineModel);
            objeCRDEngineModel.setEngineModelCode(strEngineModelCode);
            objeCRDEngineModel.setEngineModelDesc(strEngineModelDesc);
        }

        /*addition ends */

        objeCRDModule = objeCRDEngineModel.addModule();
        objeCRDModule.setModuleCode(strEngineModuleCode);
        objeCRDModule.setModuleDesc(strEngineModuleDesc);

        objeCRDModule.setEngineModel(objeCRDEngineModel);
        objeCRDEngineModel.setCatalog(objeCRDDefaultCatalog);

        objeCRDDefaultCatalog.setEngineModel(objeCRDEngineModel);
        eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDDefaultCatalog);
        eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODELCODE, strEngineModelCode);
        eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODULECODE, strEngineModuleCode);
    }
    finally
    {
        strEngineModelCode = "";
        strEngineModuleCode = "";
        objeCRDDefaultCatalog = null;
        objeCRDEngineModel = null;
        objeCRDModule = null;
    }


}
/*
* This function is used to initialize default catalog object while adding new component
*/
private void addComponent(HttpServletRequest request) throws Exception
{
  String strEngineModelCode = ""; // String variable to store Engine Model Code
  String strEngineModuleCode = ""; // String variable to store Engine Module Code
  String strEngineModelDesc = "";
  String strEngineModuleDesc = "";
  eCRDDefaultCatalog objeCRDDefaultCatalog = null;
  eCRDEngineModel objeCRDEngineModel = null;
  eCRDModule objeCRDModule = null;
  eCRDCatalog objeCRDCatalog = null;

  try
  {

      // Get the engine model code selected by the user
      strEngineModelCode = eCRDUtil.verifyNull(request.getParameter("hdnEngineModel"));
      // Get the engine module code selected by the user
      strEngineModuleCode = eCRDUtil.verifyNull(request.getParameter("hdnEngineModule"));
      strEngineModelDesc = eCRDUtil.verifyNull(request.getParameter("hdnEngineModelDesc"));
      strEngineModuleDesc = eCRDUtil.verifyNull(request.getParameter("hdnEngineModuleDesc"));
      objeCRDCatalog = (eCRDDefaultCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
      objeCRDDefaultCatalog = (eCRDDefaultCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
      if (objeCRDDefaultCatalog == null)
      {
          objeCRDDefaultCatalog = new eCRDDefaultCatalog(eCRDCatalog.getCurrentDefaultSeqId(strEngineModelCode));//Changed the constructor called to get loaded catalog object
        }
      /*added new */
      objeCRDEngineModel = objeCRDDefaultCatalog.getEngineModel();
      if (objeCRDEngineModel == null)
      {
          objeCRDEngineModel = new eCRDEngineModel();
          objeCRDDefaultCatalog.setEngineModel(objeCRDEngineModel);
          objeCRDEngineModel.setEngineModelCode(strEngineModelCode);
          objeCRDEngineModel.setEngineModelDesc(strEngineModelDesc);
      }
      /*addition ends */
      objeCRDModule = objeCRDEngineModel.addModule();
      objeCRDModule.setModuleCode(strEngineModuleCode);
      objeCRDModule.setModuleDesc(strEngineModuleDesc);

      objeCRDModule.setEngineModel(objeCRDEngineModel);
      objeCRDEngineModel.setCatalog(objeCRDDefaultCatalog);

      objeCRDDefaultCatalog.setEngineModel(objeCRDEngineModel);
      eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDDefaultCatalog);
      eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODELCODE, strEngineModelCode);
      eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODULECODE, strEngineModuleCode);
      eCRDUtil.loadInSession(request, eCRDConstants.STRCOMPONENTCODE, "");
      eCRDUtil.loadInSession(request, "strFrom", "AddComponent");
  }
  finally
  {
      strEngineModelCode = "";
      strEngineModuleCode = "";
      objeCRDDefaultCatalog = null;
      objeCRDEngineModel = null;
      objeCRDModule = null;
  }
}
//Function to show the list of repairs for a component in the case of component approval.
public int showApprvComponentRepairList(HttpServletRequest request) throws Exception
{
  ArrayList arlstRepairInfo = null;
  eCRDCatalog objeCRDCatalog = null;
  GEAEResultSet rsRepairs = null;
  eCRDSearchBean objeCRDSearchBean = null;
    eCRDUser objeCRDUser = null;
  String strComponentCode = "";
  String strModuleCode = "";
  String strEngineModelCode = "";
  String strCatalogSeqId = "";
  String strActionId = "";
    int intcheckIfUniqueComponent = 0;
  ArrayList arrlstOutParam = null;
  try
  {
        objeCRDUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser");
      objeCRDCatalog = (eCRDCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
      //Call this method to set the parameters in the component object.
      strComponentCode = eCRDUtil.verifyNull(request.getParameter("hdnComponentCode"));
      strModuleCode = eCRDUtil.verifyNull(request.getParameter("hdnEngineModule"));
      strEngineModelCode = eCRDUtil.verifyNull(request.getParameter("hdnEngineModel"));
      strCatalogSeqId = eCRDUtil.verifyNull(request.getParameter("hdnCatalogSeqId"));
      if (!"".equals(strComponentCode))
      {
            intcheckIfUniqueComponent = createComponent(request, "2");
      }
      // Added new for checking if the component description is unique or not
        if (intcheckIfUniqueComponent != -1) // Not unique
        {
            objeCRDSearchBean = new eCRDSearchBean();
            rsRepairs = new GEAEResultSet();
            arlstRepairInfo = new ArrayList();
            strActionId = eCRDConstants.getActionId("eCRD_REPAIR_LISTING");

            if ("".equals(strComponentCode))
            {
                strComponentCode = eCRDUtil.verifyNull((String)eCRDUtil.getFromSession(request, eCRDConstants.STRCOMPONENTCODE));
            }

            if ("".equals(strModuleCode))
            {
                strModuleCode = eCRDUtil.verifyNull((String)eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE));
            }
            if ("".equals(strEngineModelCode))
            {
                strEngineModelCode = eCRDUtil.verifyNull((String)eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODELCODE));
            }
            if ("".equals(strCatalogSeqId))
            {
                strCatalogSeqId = objeCRDCatalog.getCurrentDefaultSeqId(strEngineModelCode);
            }
            eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODELCODE, strEngineModelCode);
            eCRDUtil.loadInSession(request, eCRDConstants.STRCOMPONENTCODE, strComponentCode);
            eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODULECODE, strModuleCode);
            arrlstOutParam = objeCRDSearchBean.getRepairListing(strCatalogSeqId, strEngineModelCode, strModuleCode, "1", strComponentCode, strActionId,eCRDUtil.verifyNull(objeCRDUser.getRole()));
            rsRepairs = (GEAEResultSet)arrlstOutParam.get(0);

            request.setAttribute("rsRepairs", rsRepairs);

            while (rsRepairs.next())
            {
                arlstRepairInfo.add(rsRepairs.getString("Repair_Seq_Id"));
                arlstRepairInfo.add(rsRepairs.getString("Repair_Type"));
            }
            eCRDUtil.loadInSession(request, "ComponentRepairId", arlstRepairInfo);

            //  eCRDUtil.loadInSession(request,"strFrom","ShowApprvoalNewRepairs");
        }
        return intcheckIfUniqueComponent;

  }
  finally
  {
      strComponentCode = null;
      strModuleCode = null;
      strActionId = null;
      strEngineModelCode = null;
      objeCRDSearchBean = null;
  }
}

/*
* This method is used to Map eCRD Component Code to OSB Component Code for a
* combination of engine model,engine module,eCRD Component Code/Description,OSB
* Component Code.
* @ param request
* return param - int
* returns -1 if component found
*        1 If component not found
*/
private String mapComponent(HttpServletRequest request) throws Exception
{
  GEAEResultSet rsComponent = null;
  GEAEResultSet rsFormattedComponent = null;
  eCRDComponent objeCRDComponent = null;
  HttpSession session=null;
  eCRDDataBean objeCRDMappedCompList = null;

  String strEngineModel = "";
  String strEngineModule = "";
  String strEngineModuleDesc = "";
  String strComponentType = "";
  String strComponent = "";
  String strComponentCode = "";
  String strComponentDesc = "";
  String strComponentValue = "";
  String strOSBComponentValue = "";
  String strAction = "";
  String strMessage = "";
//9292__Shyamala Radhakrishnan	
  String strSite = "";
  String strSiteDesc = "";
//end  
  int intCheckIfComponentFound = 0;

  ArrayList arrlstInParam = null;
  ArrayList arrLstResult = null;
  eCRDUser objeCRDUser = null;

  try
  {
      session = request.getSession();
      objeCRDComponent = new eCRDComponent();
      objeCRDMappedCompList = new eCRDDataBean();
      //  To get the required entries from JSP
      strEngineModel = eCRDUtil.verifyNull(request.getParameter("hdnEngineModelDesc"));
      strEngineModule = eCRDUtil.verifyNull(request.getParameter("hdnEngineModule"));
      strEngineModuleDesc = eCRDUtil.verifyNull(request.getParameter("hdnEngineModuleDesc"));
      strComponentType = eCRDUtil.verifyNull(request.getParameter("hdnComponentType"));
      strComponent = eCRDUtil.verifyNull(request.getParameter("hdnComponent"));

      strComponentValue = eCRDUtil.verifyNull(request.getParameter("txtComponent"));
      strComponentValue = strComponentValue.toUpperCase();

      strComponentCode = eCRDUtil.verifyNull(request.getParameter("hdnComponentCode"));
      strComponentDesc = eCRDUtil.verifyNull(request.getParameter("hdnComponentDesc"));

      if("CODE".equals(strComponentType.trim()))
      {
          strComponentDesc = "";
      }
      else
      {
          strComponentCode = "";
      }

      strOSBComponentValue = eCRDUtil.verifyNull(request.getParameter("hdnOSBCompCode"));
      
      //9292__Shyamala Radhakrishnan	
      strSite = eCRDUtil.verifyNull(request.getParameter("hdnSite"));
      strSiteDesc = eCRDUtil.verifyNull(request.getParameter("hdnSiteDesc"));
      //end
      session.setAttribute("hdnEngineModelDesc", strEngineModel);
      session.setAttribute("hdnEngineModuleDesc", strEngineModuleDesc);
      session.setAttribute("hdnComponentType", strComponentType);
      session.setAttribute("hdnComponentCode", strComponentCode);
      session.setAttribute("hdnComponentDesc", strComponentDesc);
      session.setAttribute("hdnOSBCompCode", strOSBComponentValue);
      
      //9292_Shyamala Radhakrishnan	 
      session.setAttribute("hdnSiteDesc", strSiteDesc);
      //end
      
      //  To get the resultset of components for the required combination of
      //  engine model,engine module,ATANumber,Component Code,component description
      objeCRDUser = (eCRDUser)eCRDUtil.getFromSessionApp(request, "objeCRDUser");
      objeCRDUser.getUserId();
      strAction = eCRDConstants.getActionId("eCRD_MAP_OSB_COMPONENT");

      arrlstInParam = new ArrayList();
      arrlstInParam.add(strEngineModel);
      arrlstInParam.add(strEngineModule);
      arrlstInParam.add(strComponentCode.toUpperCase());
      arrlstInParam.add(strComponentDesc.toUpperCase());
      arrlstInParam.add(strOSBComponentValue);
      arrlstInParam.add(objeCRDUser.getUserId());
      
      //9292_Shyamala Radhakrishnan	
      arrlstInParam.add(strSite);
      //end
      
      //rsComponent = objeCRDBusinessBean.mapComponent(strAction, arrlstInParam);
      arrLstResult = objeCRDComponent.mapComponent(strAction, arrlstInParam);
      rsComponent = (GEAEResultSet)arrLstResult.get(0);

      strMessage = (String)arrLstResult.get(1);


      if (rsComponent == null)
      {
          rsComponent = new GEAEResultSet();
      }
      if (rsComponent.size() > 0)
      {
          rsComponent.setCurrentRow(0);
          rsComponent.next();
          //objeCRDMappedCompList.setCache(rsComponent);

          // To format the resultset as per the requirement
          rsFormattedComponent = formatMappedComponentList(rsComponent,"","");
      }
      // To set the formatted resultset in the cache
      objeCRDMappedCompList.setCache(rsFormattedComponent);
      // To save the data bean object in session
      eCRDUtil.loadInSession(request, "objeCRDMappedCompList", objeCRDMappedCompList);


      return (strMessage);
  }
  finally
  {
      rsComponent = null;
      objeCRDComponent = null;
      strEngineModel = "";
      strEngineModule = "";
      strComponent = "";
      strComponentValue = "";
      strAction = "";
      //9292_Shyamala Radhakrishnan	
      strSite = "";
      //end
  }

}
/*
* This method is used to Map eCRD Component Code to OSB Component Code for a
* combination of engine model,engine module,eCRD Component Code/Description,OSB
* Component Code.
* @ param request
* return param - int
* returns -1 if component found
*        1 If component not found
*/
private String deleteMapping(HttpServletRequest request) throws Exception
{
  GEAEResultSet rsComponent = null;
  GEAEResultSet rsFormattedComponent = null;
  eCRDComponent objeCRDComponent = null;
  HttpSession session=null;
  eCRDDataBean objeCRDMappedCompList = null;
  ArrayList arrLstResult = null;
  int intCheckIfComponentFound = 0;

  ArrayList arrlstInParam = null;
  eCRDUser objeCRDUser = null;
  String strMessage = "";
  String strDeleteValue = "";
  String strAction = "";
  String strEngineModel = "";
  String strEngineModule = "";
  //9292_Shyamala Radhakrishnan	
  String strSite = "";
  //end
  
  try
  {
      session = request.getSession();

      objeCRDComponent = new eCRDComponent();
      objeCRDMappedCompList = new eCRDDataBean();
      //  To get the required entries from JSP
      //  To get the resultset of components for the required combination of
      //  engine model,engine module,ATANumber,Component Code,component description
      objeCRDUser = (eCRDUser)eCRDUtil.getFromSessionApp(request, "objeCRDUser");
      objeCRDUser.getUserId();
      strDeleteValue = eCRDUtil.verifyNull(request.getParameter("hdnCheckDeleteRows"));
      strAction = eCRDUtil.verifyNull(request.getParameter("hdnScreenAction"));
      strEngineModel = eCRDUtil.verifyNull(request.getParameter("hdnEngineModelDesc"));
      strEngineModule = eCRDUtil.verifyNull(request.getParameter("hdnEngineModule"));
      //9292_Shyamala Radhakrishnan	
      strSite = eCRDUtil.verifyNull(request.getParameter("hdnSite"));
      //end
      strDeleteValue = strDeleteValue.substring(1) + "|";

      String strEngineModuleDesc = eCRDUtil.verifyNull(request.getParameter("hdnEngineModuleDesc"));
      String strComponentType = eCRDUtil.verifyNull(request.getParameter("hdnComponentType"));
      String strComponentCode = eCRDUtil.verifyNull(request.getParameter("hdnComponentCode"));
      String strComponentDesc = eCRDUtil.verifyNull(request.getParameter("hdnComponentDesc"));
      String strOSBComponentValue = eCRDUtil.verifyNull(request.getParameter("hdnOSBCompCode"));
      //9292_Shyamala Radhakrishnan	
      String strSiteDesc = eCRDUtil.verifyNull(request.getParameter("hdnSiteDesc"));
      //end
      session.setAttribute("hdnEngineModelDesc", strEngineModel);
      session.setAttribute("hdnEngineModuleDesc", strEngineModuleDesc);
      session.setAttribute("hdnComponentType", strComponentType);
      session.setAttribute("hdnComponentCode", strComponentCode);
      session.setAttribute("hdnComponentDesc", strComponentDesc);
      session.setAttribute("hdnOSBCompCode", strOSBComponentValue);
      //9292_Shyamala Radhakrishnan	
      session.setAttribute("hdnSiteDesc", strSiteDesc);
      //end

      arrlstInParam = new ArrayList();
      arrlstInParam.add(strDeleteValue);
      arrlstInParam.add(strEngineModel);
      arrlstInParam.add(strEngineModule);
      arrlstInParam.add(objeCRDUser.getUserId());
      //9292_Shyamala Radhakrishnan	
      arrlstInParam.add(strSite);
      //end
      arrLstResult = objeCRDComponent.deleteMapping(strAction, arrlstInParam);
      rsComponent = (GEAEResultSet)arrLstResult.get(0);

      strMessage = (String)arrLstResult.get(1);

      if (rsComponent == null)
      {
          rsComponent = new GEAEResultSet();
      }
      if (rsComponent.size() > 0)
      {
          rsComponent.setCurrentRow(0);
          rsComponent.next();
          //objeCRDMappedCompList.setCache(rsComponent);
          // To format the resultset as per the requirement
          rsFormattedComponent = formatMappedComponentList(rsComponent, "","");
          //System.out.println(rsFormattedComponent.size());
      }
      //System.out.println("Size of rsFormattedComponent :- " + rsFormattedComponent.size());
      // To set the formatted resultset in the cache
      objeCRDMappedCompList.setCache(rsFormattedComponent);
      // To save the data bean object in session
      eCRDUtil.loadInSession(request, "objeCRDMappedCompList", objeCRDMappedCompList);

      request.setAttribute("Message", strMessage);
      request.setAttribute("deleteMapping", "true");
      return (strMessage);


  }
  finally
  {
      rsComponent = null;
      objeCRDComponent = null;
      strEngineModel = "";
      strEngineModule = "";
      strAction = "";
      //9292_Shyamala Radhakrishnan	 
      strSite = "";
      //end
  }

}

/*
* This method is used to get Mapped eCRD Component Code to OSB Component Code for a
* combination of engine model,engine module.
* @ param request
* return param - int
* returns -1 if component found
*        1 If component not found
*/
private String getmapComponent(HttpServletRequest request) throws Exception
{
  GEAEResultSet rsComponent = null;
  GEAEResultSet rsFormattedComponent = null;
  eCRDComponent objeCRDComponent = null;
  HttpSession session = null;

  eCRDDataBean objeCRDMappedCompList = null;

  String strEngineModel = "";
  String strEngineModule = "";
  String strEngineModuleDesc = "";
  String strComponentType = "";
  String strComponent = "";
  String strComponentCode = "";
  String strComponentDesc = "";
  String strComponentValue = "";
  String strOSBComponentValue = "";
//9292_eCRD_phase4_site mappings_Shyamala Radhakrishnan	 
  String strSite = "";
  String strSiteDesc = "";
//End
  String strAction = "";
  String strMessage = "";

  int intCheckIfComponentFound = 0;

  ArrayList arrlstInParam = null;
  ArrayList arrLstResult = null;
  eCRDUser objeCRDUser = null;



  try
  {
      session = request.getSession();
      objeCRDComponent = new eCRDComponent();
      objeCRDMappedCompList = new eCRDDataBean();
      //  To get the required entries from JSP
      strEngineModel = eCRDUtil.verifyNull(request.getParameter("hdnEngineModelDesc"));
      strEngineModule = eCRDUtil.verifyNull(request.getParameter("lstEngineModule"));
      //  engine model,engine module,ATANumber,Component Code,component description
      
      //9292_eCRD_phase4_site_mappings_Shyamala Radhakrishnan	
      strSite = eCRDUtil.verifyNull(request.getParameter("hdnSite"));
      //end
      objeCRDUser = (eCRDUser)eCRDUtil.getFromSessionApp(request, "objeCRDUser");
      objeCRDUser.getUserId();
      strAction = eCRDConstants.getActionId("eCRD_GET_MAP_OSB_COMPONENT");
      strComponentCode = eCRDUtil.verifyNull(request.getParameter("hdnComponentCode"));
      strComponentDesc = eCRDUtil.verifyNull(request.getParameter("hdnComponentDesc"));

      strEngineModuleDesc = eCRDUtil.verifyNull(request.getParameter("hdnEngineModuleDesc"));
      strComponentType = eCRDUtil.verifyNull(request.getParameter("hdnComponentType"));
      strComponent = eCRDUtil.verifyNull(request.getParameter("hdnComponent"));

      strComponentValue = eCRDUtil.verifyNull(request.getParameter("txtComponent"));
      strComponentValue = strComponentValue.toUpperCase();

      strComponentCode = eCRDUtil.verifyNull(request.getParameter("hdnComponentCode"));
      strComponentDesc = eCRDUtil.verifyNull(request.getParameter("hdnComponentDesc"));

      strOSBComponentValue = eCRDUtil.verifyNull(request.getParameter("hdnOSBCompCode"));
//    9292_eCRD_phase4_site_mappings_Shyamala Radhakrishnan	
      strSiteDesc = eCRDUtil.verifyNull(request.getParameter("hdnSiteDesc"));
      if("CODE".equals(strComponentType.trim()))
      {
          strComponentDesc = "";
      }
      else
      {
          strComponentCode = "";
      }
//    end
      session.setAttribute("hdnEngineModelDesc", strEngineModel);
      session.setAttribute("hdnEngineModuleDesc", strEngineModuleDesc);
      session.setAttribute("hdnComponentType", strComponentType);
      session.setAttribute("hdnComponentCode", strComponentCode);
      session.setAttribute("hdnComponentDesc", strComponentDesc);
      session.setAttribute("hdnOSBCompCode", strOSBComponentValue);
//    9292_eCRD_phase4_site_mappings_Shyamala Radhakrishnan	      
      session.setAttribute("hdnSiteDesc", strSiteDesc);
//end
      arrlstInParam = new ArrayList();
      arrlstInParam.add(strEngineModel);
      arrlstInParam.add(strEngineModule);
      arrlstInParam.add(strComponentCode.toUpperCase());
      arrlstInParam.add(strComponentDesc.toUpperCase());
      arrlstInParam.add(objeCRDUser.getUserId());
//9292_eCRD_phase4_site_mappings_Shyamala Radhakrishnan	
      arrlstInParam.add(strSite);
//end      

      //rsComponent = objeCRDBusinessBean.mapComponent(strAction, arrlstInParam);
      arrLstResult = objeCRDComponent.getmapComponent(strAction, arrlstInParam);
      rsComponent = (GEAEResultSet)arrLstResult.get(0);

      strMessage = (String)arrLstResult.get(1);

      if (rsComponent == null)
      {
          rsComponent = new GEAEResultSet();
      }
      if (rsComponent.size() > 0)
      {
          rsComponent.setCurrentRow(0);
          rsComponent.next();
          //objeCRDMappedCompList.setCache(rsComponent);
          // To format the resultset as per the requirement
          rsFormattedComponent = formatMappedComponentList(rsComponent, strEngineModel, strEngineModule);
          //System.out.println(rsFormattedComponent.size());
      }

      //System.out.println("Size of rsFormattedComponent :- " + rsFormattedComponent.size());
      // To set the formatted resultset in the cache
      objeCRDMappedCompList.setCache(rsFormattedComponent);
      // To save the data bean object in session
      eCRDUtil.loadInSession(request, "objeCRDMappedCompList", objeCRDMappedCompList);

      return (strMessage);

  }
  finally
  {
      rsComponent = null;
      objeCRDComponent = null;
      strEngineModel = "";
      strEngineModule = "";
//9292_eCRD_phase4_site_mappings_Shyamala Radhakrishnan	      
      strSite = "";
//end      
      
      strAction = "";
  }

}

/*
* This method is used to get Mapped eCRD Component Code to OSB Component Code for a
* combination of engine model,engine module.
* @ param request
* return param - int
* returns -1 if component found
*        1 If component not found
*/
private String editmapComponent(HttpServletRequest request) throws Exception
{
  GEAEResultSet rsComponent = null;
  GEAEResultSet rsFormattedComponent = null;
  eCRDComponent objeCRDComponent = null;
  eCRDDataBean objeCRDMappedCompList = null;

  String strEngineModel = "";
  String strEngineModule = "";
  String strAction = "";
  String strMessage = "";
 
  int intCheckIfComponentFound = 0;

  ArrayList arrlstInParam = null;
  ArrayList arrLstResult = null;
  eCRDUser objeCRDUser = null;



  try
  {
      objeCRDComponent = new eCRDComponent();
      objeCRDMappedCompList = new eCRDDataBean();
      //  To get the required entries from JSP
      strEngineModel = eCRDUtil.verifyNull(request.getParameter("hdnEngineModelDesc"));
      strEngineModule = eCRDUtil.verifyNull(request.getParameter("lstEngineModule"));
       //  engine model,engine module,ATANumber,Component Code,component description
      objeCRDUser = (eCRDUser)eCRDUtil.getFromSessionApp(request, "objeCRDUser");
      objeCRDUser.getUserId();
      strAction = eCRDConstants.getActionId("eCRD_EDIT_MAP_OSB_COMPONENT");

      arrlstInParam = new ArrayList();
      arrlstInParam.add(strEngineModel);
      arrlstInParam.add(strEngineModule);
      arrlstInParam.add(objeCRDUser.getUserId());
 
      //rsComponent = objeCRDBusinessBean.mapComponent(strAction, arrlstInParam);
      arrLstResult = objeCRDComponent.editmapComponent(strAction, arrlstInParam);
      rsComponent = (GEAEResultSet)arrLstResult.get(0);

      strMessage = (String)arrLstResult.get(1);

      if (rsComponent == null)
      {
          rsComponent = new GEAEResultSet();
      }
      if (rsComponent.size() > 0)
      {
          rsComponent.setCurrentRow(0);
          rsComponent.next();
          //objeCRDMappedCompList.setCache(rsComponent);
          // To format the resultset as per the requirement
          rsFormattedComponent = formatMappedComponentList(rsComponent, strEngineModel, strEngineModule);
      }
      // To set the formatted resultset in the cache
      objeCRDMappedCompList.setCache(rsFormattedComponent);
      // To save the data bean object in session
      eCRDUtil.loadInSession(request, "objeCRDMappedCompList", objeCRDMappedCompList);

      return (strMessage);

  }
  finally
  {
      rsComponent = null;
      objeCRDComponent = null;
      strEngineModel = "";
      strEngineModule = "";
      strAction = "";
  }

}


/*
* This method is used to format the resultset containing list of components
* @ param  GEAEResultSet,HttpServletRequest
*/
public GEAEResultSet formatMappedComponentList(GEAEResultSet rsComponentList, String strCheckDeleteRows, String strUnCheckDeleteRows) throws Exception
//public GEAEResultSet formatMappedComponentList(eCRDDataBean objeCRDMappedCompList, String strCheckDeleteRows, String strUnCheckDeleteRows) throws Exception
{
  GEAEResultSet rsFormattedComponentList = null;
  //GEAEResultSet rsComponentList = null;
  GEAETagNoData tagCheckBox = null;
  String strEditCodeURL = "";
  String strEditDescURL = "";
  String strEditCodeLink = "";
  String strEditDescLink = "";

  ArrayList arrlstFormattedComponentList = null;
  ArrayList arrlstCheckDeleteRows = null;
  ArrayList arrlstUnCheckDeleteRows = null;
  int intPosition = 0;

  String strSelectValue = "";
  String strComponentCode = "";

  String strPattern = "";
  String strCheckBoxValue = "";
  try
  {
      if (!"".equals(eCRDUtil.checkNull(strCheckDeleteRows)))
      {
          arrlstCheckDeleteRows = eCRDUtil.convertStringToArrayList(strCheckDeleteRows, "|");
      }


      //rsComponentList = objeCRDMappedCompList.getCache();

      if (rsComponentList != null && rsComponentList.size() > 0)
      {
          intPosition = rsComponentList.getCurrentRow();
          rsFormattedComponentList = new GEAEResultSet();
          rsComponentList.setCurrentRow(0);
          rsComponentList.next();
          for (int i = 0; i < rsComponentList.size(); i++)
          {
              arrlstFormattedComponentList = new ArrayList();
              strComponentCode = rsComponentList.getString(1);
              strSelectValue = "" + eCRDUtil.replaceQuoteForJS(strComponentCode);


              if(arrlstCheckDeleteRows != null && !"".equals(arrlstCheckDeleteRows))
              {
                  strPattern = "|" + eCRDUtil.verifyNull(rsComponentList.getString(1))+ "^"
                               + eCRDUtil.verifyNull(rsComponentList.getString(3));
                  if(strCheckDeleteRows.indexOf(strPattern)!=-1)
                  {
                      strCheckBoxValue = "SELECTED";
                  }
              }


              tagCheckBox =
                  new GEAETagNoData(
                      "<INPUT TYPE=\"CHECKBOX\" NAME=\"sel" +i+"\" VALUE=\""
                          + strSelectValue
                          + "\" onClick = \"javascript:fnSelect('"
                          + rsComponentList.getString(1)
                          + "','"
//9292_ecrd_SiteMapping_Shyamala Radhakrishnan	                          
                          + rsComponentList.getString(4)
//end                          
                          + "','sel"+i+"')\" "+ strCheckBoxValue + ">");

              strEditCodeURL  = "\"javascript:fnEdit('"+eCRDUtil.verifyNull(rsComponentList.getString(1))+ "','"
//9292_eCRD_SiteMapping_Shyamala Radhakrishnan	              
                                                      +eCRDUtil.verifyNull(rsComponentList.getString(3))+ "','"
                                                      +eCRDUtil.verifyNull(rsComponentList.getString(4))+ "','"
//end                                                      
                                                      + "CODE" + "')\"";
/*
              strEditDescURL  = "\"javascript:fnEdit('"+eCRDUtil.verifyNull(rsComponentList.getString(1))+ "','"
                                                      +eCRDUtil.verifyNull(rsComponentList.getString(2))+ "','"
                                                      +eCRDUtil.verifyNull(rsComponentList.getString(3))+ "','"
                                                      + "DESCRIPTION" + "')\"";
*/
              strEditCodeLink = "<a href="+strEditCodeURL+">"+ eCRDUtil.verifyNull(rsComponentList.getString(1))+ "</a>";
              //strEditDescLink = "<a href="+strEditDescURL+">"+ eCRDUtil.verifyNull(rsComponentList.getString(2))+ "</a>";

              //System.out.println("strEditCodeLink :- " + strEditCodeLink);
              //System.out.println("strEditDescLink :- " + strEditDescLink);

              arrlstFormattedComponentList.add(tagCheckBox);
              arrlstFormattedComponentList.add(new GEAETag(eCRDUtil.verifyNull(rsComponentList.getString(1)),strEditCodeLink));
              //arrlstFormattedComponentList.add(new GEAETag(eCRDUtil.verifyNull(rsComponentList.getString(2)),strEditDescLink));
//9292 ecrd_SiteMaping_Shyamala Radhakrishnan	              
              arrlstFormattedComponentList.add(eCRDUtil.verifyNull(rsComponentList.getString(2)));
//end              
              arrlstFormattedComponentList.add(eCRDUtil.verifyNull(rsComponentList.getString(3)));
              arrlstFormattedComponentList.add(eCRDUtil.verifyNull(rsComponentList.getString(4)));
              arrlstFormattedComponentList.add(eCRDUtil.verifyNull(rsComponentList.getString(5)));
              arrlstFormattedComponentList.add(eCRDUtil.verifyNull(rsComponentList.getString(6)));
              //System.out.println("arrlstFormattedComponentList :- " + arrlstFormattedComponentList);
              rsFormattedComponentList.addRow(arrlstFormattedComponentList);
              rsComponentList.next();
          }
          rsFormattedComponentList.setColumnHeading(1, "Delete");
          rsFormattedComponentList.setColumnHeading(2, "eCRD Component Code");
//9292_eCRD_SiteMapping_Shyamala Radhakrishnan	          
          rsFormattedComponentList.setColumnHeading(3, "Site");
//end          
          rsFormattedComponentList.setColumnHeading(4, "eCRD Component Description");
          rsFormattedComponentList.setColumnHeading(5, "OSB Component Code");
          rsFormattedComponentList.setColumnHeading(6, "Mapping date");
          rsFormattedComponentList.setColumnHeading(7, "Mapped By");
          //rsComponentList = rsFormattedComponentList;
          //rsComponentList.setCurrentRow(intPosition);
      }
  }
  finally
  {
      tagCheckBox = null;
      strSelectValue = "";
      strComponentCode = "";
      arrlstFormattedComponentList = null;
  }
  return rsFormattedComponentList;
}

/*
* This method is used to format the resultset containing list of components
* @ param  GEAEResultSet,HttpServletRequest
*/
public String showRCTable(GEAEResultSet eCRDRowCached) throws Exception
{
  String strHTML = "";

  try
  {
      eCRDRowCached.setCurrentRow(0);
   
//    19-05-2006 patni checking null value Begin 
      if(eCRDRowCached != null ) 
      { 
//        19-05-2006 patni checking null value End                
      while (eCRDRowCached.next())
      {
         strHTML = strHTML + "<tr class=\"c4f4\">";
         for (int i=1;i<=eCRDRowCached.getColumnCount();i++)
         {
            if (eCRDRowCached.getSortColumn() == i)
            {  //give the sorted column a different color
                strHTML = strHTML + "<td class=\"c2\">";
            }
            else
            {
                strHTML = strHTML + "<td class=\"c4\">";
            }
            strHTML = strHTML + "<div class=\"f2\">";
            strHTML = strHTML + eCRDRowCached.getString(i);
            strHTML = strHTML + "</div>";
            strHTML = strHTML + "</td>";
         }
         strHTML = strHTML + "</tr>";
      }
//    19-05-2006 patni checking null value Begin             
      } // end if 
//    19-05-2006 patni checking null value End            
  }
  finally
  {
      eCRDRowCached = null;
  }
  return strHTML;
}


}