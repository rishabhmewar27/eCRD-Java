//Source file: D:\\ECRD\\SOURCE CODE\\ecrd\\helper\\eCRDManageCustomerCatalogHelper.java
/**
 * Module       : eCRDManageCustomerCatalogHelper.java
 * Author       : Patni Offshore
 * Project      : eCRD
 * Date Written : October 2004
 * Security     : Classified/Unclassified
 * Restrictions : GE PROPRIETORY INFORMATION, FOR GE USE ONLY
 *
 *     ***************************************************************
 *     *          Copyright (2000) with all rights reserved          *
 *     *                  General Electric Company                   *
 *     ***************************************************************
 * Description  :  This class has methods to get the Master Tables Data.
 * Revision Log  (mm/dd/yyyy     Initials    description)
 * -------------------------------------------------------------------
 * mm/dd/yyyy     Initials     Description
 * -------------------------------------------------------------------
 *   31/15/2005     patni  Phase 1 requirement updations 
 */
package ecrd.helper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;

import ecrd.biz.eCRDCatalog;
import ecrd.biz.eCRDCatalogRule;
import ecrd.biz.eCRDChildRepair;
import ecrd.biz.eCRDComponent;
import ecrd.biz.eCRDCustomer;
import ecrd.biz.eCRDCustomerCatalog;
import ecrd.biz.eCRDEngineModel;
import ecrd.biz.eCRDEscalation;
import ecrd.biz.eCRDGroupedRepair;
import ecrd.biz.eCRDRepair;
import ecrd.biz.eCRDRepairPricing;
import ecrd.biz.eCRDIndRepair;
import ecrd.biz.eCRDModule;
import ecrd.biz.eCRDRepairSite;
import ecrd.biz.eCRDUser;
import ecrd.common.eCRDAppSecurityUtil;
import ecrd.common.eCRDBusinessBean;
import ecrd.common.eCRDCommand;
import ecrd.common.eCRDDBMediator;
import ecrd.common.eCRDDataBean;
import ecrd.exception.eCRDException;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDLoadMaster;
import ecrd.util.eCRDUtil;
import ecrd.util.eCRDSearchBean;
import geae.dao.GEAEResultSet;
import geae.util.format.GEAETag;
import geae.util.format.GEAETagNoData;

public class eCRDManageCustomerCatalogHelper implements eCRDCommand
{

    public eCRDManageCustomerCatalogHelper()
    {

    }

    /**
     * This method will identify the method to be invoked and also the subsequent
     * screen to be displayed depending on the functionality.
     * Also sets the received request to member variable.
     * @param request
     */
    public String perform(HttpServletRequest request) throws Exception
    {
        String strCont = "";
        String strMessage = "";
        String strScreenAction = eCRDUtil.verifyNull((String)request.getParameter("hdnScreenAction"));
        eCRDDataBean objeCRDDataBeanSplit = null;
        GEAEResultSet geaeSplitList = null;
        String strRepairCode = null;
        String strHdnContValue = null;
        if ("".equalsIgnoreCase(strScreenAction))
        {
            eCRDUtil.clearSession(request);
            strCont = eCRDConstants.STRCONTJSP + "ecrd-createCustCatalog";
        }

        else if ((eCRDConstants.getActionId("eCRD_ADD_DEL_CUSTOMER")).equals(strScreenAction))
        {
            createCust(request);
            strCont = eCRDConstants.STRCONTJSP + "ecrd-createCustCatalog";
        }
        else if ((eCRDConstants.getActionId("eCRD_CREATE_BLANK_CUST")).equals(strScreenAction))
        {
			strMessage = createBlankCatalog(request);
            if("".equals(strMessage))
            {
				strCont = eCRDConstants.STRCONTJSP + "ecrd-specialRepair";
            }
            else
            {
				strCont = eCRDConstants.STRCONTJSP + "ecrd-createCustCatalog";
            }
        }
		else if ((eCRDConstants.getActionId("eCRD_CREATE_SPECIAL_FOR_CUST")).equals(strScreenAction))
		{
			strHdnContValue = eCRDUtil.verifyNull(request.getParameter("hdnContValue"));
			if(!"ecrd-c-viewRepairs".equals(strHdnContValue))
			{
				eCRDUtil.loadInSession(request,"strFromCust","SPECIALFORCUSTOMER" );
			}
			strCont = eCRDConstants.STRCONTJSP + "ecrd-specialRepair";
		}

        else if ((eCRDConstants.getActionId("eCRD_CUST_TABLE")).equals(strScreenAction))
        {
            getCustomerTable(request);
            strCont = eCRDConstants.STRCONTJSP + "ecrd-CustomerTable";

        }
        
        /*------------ Added By Prathima -----------------------------*/
        else if ((eCRDConstants.getActionId("eCRD_CUST_REPORT_TABLE")).equals(strScreenAction))
        {
        	System.out.println("SANTOSH IN TEST inside the get customerTable");
            getCustomerTable(request);
            System.out.println("SANTOSH IN TEST After the get customerTable");
            strCont = eCRDConstants.STRCONTJSP + "ecrd-CustomerTableReport";

        }
        /*------------ Added By Prathima -----------------------------*/
        else if (eCRDConstants.getActionId("eCRD_RULES_CRITERIA").equalsIgnoreCase(strScreenAction))
        {
            eCRDUtil.removeFromSession(request, eCRDConstants.STRCATALOGRULE);
			eCRDUtil.removeFromSession(request,"Modify");
            strCont = eCRDConstants.STRCONTJSP + "ecrd-CustomerCatalogRules";
        }
        else if (eCRDConstants.getActionId("eCRD_LOAD_DETAILS").equalsIgnoreCase(strScreenAction))
        {
            getDetails(request);
            strCont = eCRDConstants.STRCONTJSP + "ecrd-CustomerCatalogRules";
        }
        else if ((eCRDConstants.getActionId("eCRD_MERGE_SPLIT_REPAIR")).equals(strScreenAction))
        {
            strCont = eCRDConstants.STRCONTJSP + "ecrd-mergeSplitRepair";
        }
        else if ((eCRDConstants.getActionId("eCRD_MERGE_REPAIR_TABLE")).equals(strScreenAction))
        {
            mergeRepair(request);
            strCont = eCRDConstants.STRCONTJSP + "ecrd-mergeRepair";
        }
        else if ((eCRDConstants.getActionId("eCRD_SPLIT_REPAIR_TABLE")).equals(strScreenAction))
        {
            splitRepair(request);
            strCont = eCRDConstants.STRCONTJSP + "ecrd-splitRepair";
        }
        else if (eCRDConstants.getActionId("eCRD_LOAD_CONTRACTUAL_RULES").equalsIgnoreCase(strScreenAction))
        {
            strMessage = saveRuleDetails(request);
            if ("".equals(strMessage))
            {
                strCont = eCRDConstants.STRCONTJSP + "ecrd-ContractualRules";
            }
            else
            {
                getDetails(request);
                strCont = eCRDConstants.STRCONTJSP + "ecrd-CustomerCatalogRules";
            }
        }
        else if (eCRDConstants.getActionId("eCRD_ADD_INFLATION").equalsIgnoreCase(strScreenAction))
        {
            getInflation(request);
            strCont = eCRDConstants.STRCONTJSP + "ecrd-ContractualRules";
        }
        else if (eCRDConstants.getActionId("eCRD_REMOVE_INFLATION").equalsIgnoreCase(strScreenAction))
        {
            deleteInflation(request);
            strCont = eCRDConstants.STRCONTJSP + "ecrd-ContractualRules";
        }
        else if ((eCRDConstants.getActionId("eCRD_COPY_EXISTING_CATALOG")).equals(strScreenAction))
        {
            strMessage = copyExistingCust(request);
            if("".equals(strMessage))
            {
				strCont = eCRDConstants.STRCONTJSP + "ecrd-copyExistingCatalog";
            }
            else
            {
				strCont = eCRDConstants.STRCONTJSP + "ecrd-createCustCatalog";
            }
        }
        else if ((eCRDConstants.getActionId("eCRD_SHOW_CATALOG")).equals(strScreenAction))
        {
            getCatalogList(request, strScreenAction);
            strCont = eCRDConstants.STRCONTJSP + "ecrd-showCatalogList";
        }
        else if ((eCRDConstants.getActionId("eCRD_COPY_CATALOG")).equalsIgnoreCase(strScreenAction))
        {
            strMessage = setCopiedSeqId(request);
            if ("".equals(strMessage))
            {
                strCont = eCRDConstants.STRCONTJSP + "ecrd-CustomerCatalogRules";
            }
            else
            {
                strCont = eCRDConstants.STRCONTJSP + "ecrd-copyExistingCatalog";
            }
        }
        else if (eCRDConstants.getActionId("eCRD_CREATE_RULES").equalsIgnoreCase(strScreenAction))
        {
            strMessage = createCustCatalogRules(request);
            strCont = eCRDConstants.STRCONTJSP + "ecrd-viewRules";
        }
        else if (eCRDConstants.getActionId("eCRD_VIEW_RULES").equalsIgnoreCase(strScreenAction))
        {
            ViewCustCatalogRule(request);
            strCont = eCRDConstants.STRCONTJSP + "ecrd-viewRules";
        }
        else if (eCRDConstants.getActionId("eCRD_MODIFY_RULES").equalsIgnoreCase(strScreenAction))
        {
            modifyCustCatalogRule(request);
            strCont = eCRDConstants.STRCONTJSP + "ecrd-ContractualRules";
        }
        else if (eCRDConstants.getActionId("eCRD_UPDATE_RULE").equalsIgnoreCase(strScreenAction))
        {
            updateCustCatalogRule(request);
            strCont = eCRDConstants.STRCONTJSP + "ecrd-ContractualRules";
        }
        else if (eCRDConstants.getActionId("eCRD_COPY_AND_APPLY_RULE").equalsIgnoreCase(strScreenAction))
        {
            copyAndApplyRules(request);
            strCont = eCRDConstants.STRCONTJSP + "ecrd-viewRules";
        }
        //Below is the code for apply default refresh rules - Kumar.
        else if (eCRDConstants.getActionId("eCRD_APPLY_Default_Refresh_RULE").equalsIgnoreCase(strScreenAction))
        {        	
            ApplyDefaultRefreshRules(request);
            strCont = eCRDConstants.STRCONTJSP + "ecrd-viewRules";
        }
        else if (eCRDConstants.getActionId("eCRD_RULES").equalsIgnoreCase(strScreenAction))
        {
            //copyAndApplyRules(request);
            strCont = eCRDConstants.STRCONTJSP + "ecrd-CustomerCatalogRules";
        }
        else if (eCRDConstants.getActionId("eCRD_APPLY_RULES").equalsIgnoreCase(strScreenAction))
        {
            strCont = eCRDConstants.STRCONTJSP + "ecrd-ContractualRules";
        }
        else if (eCRDConstants.getActionId("eCRD_VIEW_RULE").equalsIgnoreCase(strScreenAction))
        {
            strCont = eCRDConstants.STRCONTJSP + "ecrd-viewRules";
        }
        else if (eCRDConstants.getActionId("eCRD_COMPONENT_LISTING").equalsIgnoreCase(strScreenAction))
        {
            eCRDUtil.loadInSession(request, "eCRDFrom", "Rules");
            strCont = eCRDConstants.STRCONTJSP + "ecrd-ComponentListing";
        }
        else if (eCRDConstants.getActionId("eCRD_SPLIT_REPAIR_SAVE").equalsIgnoreCase(strScreenAction))
        {
            strRepairCode = getChildRepairs(request);
            objeCRDDataBeanSplit = new eCRDDataBean();
            geaeSplitList = eCRDSearchBean.getSplitListing(request);
            if (geaeSplitList != null && geaeSplitList.size() > 0)
            {
                objeCRDDataBeanSplit.setCache(geaeSplitList);
            }
            else
            {
                objeCRDDataBeanSplit.setCache(new GEAEResultSet());
            }
            eCRDUtil.loadInSession(request, "objeCRDDataBeanSplit", objeCRDDataBeanSplit);
            eCRDUtil.loadInSession(request, "strDelRepairs", strRepairCode);
            strCont = eCRDConstants.STRCONTJSP + "ecrd-splitSaveRepair";
        }
        else if (eCRDConstants.getActionId("eCRD_MERGE_SAVE").equalsIgnoreCase(strScreenAction))
        {
            strRepairCode = mergeRepairs(request);
            eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODULECODE, request.getParameter("strEngineModule"));
            eCRDUtil.loadInSession(request, eCRDConstants.STRCOMPONENTCODE, request.getParameter("strCompCode"));
            eCRDUtil.loadInSession(request, eCRDConstants.STRREPAIRSEQID, strRepairCode);
            eCRDUtil.loadInSession(request, "strRepairType", request.getParameter("strRepairType"));
            eCRDUtil.loadInSession(request, "strFrom", request.getParameter("strFrom"));
            eCRDUtil.loadInSession(request, "strDelRepairs", strRepairCode);
            strCont = eCRDConstants.STRCONTJSP + "ecrd-splitMergeSave";
        }
        else if (eCRDConstants.getActionId("eCRD_SPLIT_SELECT_FOR_SAVE").equalsIgnoreCase(strScreenAction))
        {
            eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODULECODE, request.getParameter("strEngineModule"));
            eCRDUtil.loadInSession(request, eCRDConstants.STRCOMPONENTCODE, request.getParameter("strCompCode"));
            eCRDUtil.loadInSession(request, eCRDConstants.STRREPAIRSEQID, request.getParameter("strRepairCode"));
            eCRDUtil.loadInSession(request, "strRepairType", request.getParameter("strRepairType"));
            eCRDUtil.loadInSession(request, "strFrom", request.getParameter("strFrom"));
            strCont = eCRDConstants.STRCONTJSP + "ecrd-splitMergeSave";
        }
        else if (eCRDConstants.getActionId("eCRD_SPLIT_IND_SAVE").equalsIgnoreCase(strScreenAction))
        {
            strMessage = finalSplit(request);
            request.setAttribute("strRepairMessage", strMessage);
            if ("NON_UNIQUE_DISP_SPLIT".equals(strMessage) || "NON_UNIQUE_DESC_SPLIT".equals(strMessage))
            {
                strCont = eCRDConstants.STRCONTJSP + "ecrd-splitSaveRepair";
            }
            else
            {
                request.setAttribute("strRepairMessage", "REPAIR_SPLIT_SUCCESSFULLY");
                strCont = eCRDConstants.STRCONTJSP + "ecrd-mergeSplitRepair";
            }

        }
        else if (eCRDConstants.getActionId("eCRD_BACK_COPY_EXISTING").equalsIgnoreCase(strScreenAction))
        {
            strCont = eCRDConstants.STRCONTJSP + "ecrd-copyExistingCatalog";
        }
        else if (eCRDConstants.getActionId("eCRD_DELETE_RULE").equalsIgnoreCase(strScreenAction))
        {
            deleteCustCatalogRule(request);
            strCont = eCRDConstants.STRCONTJSP + "ecrd-viewRules";
        }
        /*THIS METHOD IS TO POPULATE THE COMPONENT DROP DOWN ON SELECTING THE MODULE DROPDWN
        			 * IN THE TABS SCREEN*/
        else if (eCRDConstants.getActionId("eCRD_COMPONENT_TABS").equals(strScreenAction))
        {
            eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODULECODE, eCRDUtil.verifyNull(request.getParameter("selEngineModule")));
            eCRDUtil.loadInSession(request, eCRDConstants.STRCOMPONENTCODE, "");
            strCont = eCRDConstants.STRCONTJSP + "ecrd-specialRepair";

        }
        return strCont;
    }

    private String createBlankCatalog(HttpServletRequest request) throws Exception
    {

        String strCustomerName[] = null;
        String strCustCode[] = null;
        String strContractNum[] = null;
        String strContractDesc[] = null;
        String strStartDate[] = null;
        String strEndDate[] = null;
        String strCatStartDate = "";
        String strCatEndDate = "";
        String strDelCust = "";

        String strCatalogNumber = "";
        String strCatalogDescription = "";
        
        String strCatInd = null;  //changes by vikrant
        
        String strEngModelCode = "";
        String strContractDesciption = "";
        eCRDEngineModel objeCRDEngineModel = null;
        eCRDCustomer objeCRDCustomer = null;
        eCRDCustomerCatalog objeCRDCustomerCatalog = null;
        eCRDUser objeCRDUser = null;
        String strMessage = "";
        String strOutMessage = "";
        try
        {

            strContractNum = request.getParameterValues("txtContractNumber");
            strCustCode = request.getParameterValues("hdnCustomerCode");
            strCustomerName = request.getParameterValues("hdnCustName");

            strEngModelCode = eCRDUtil.verifyNull(request.getParameter("lstEngModel"));
            strCatStartDate = eCRDUtil.verifyNull(request.getParameter("hdnStartDate"));
            strCatEndDate = eCRDUtil.verifyNull(request.getParameter("hdnEndDate"));
            strCatalogNumber = eCRDUtil.verifyNull(request.getParameter("txtCatalogNum"));
            strCatalogDescription = eCRDUtil.verifyNull(request.getParameter("txtCatalogDesc"));
            strCatalogDescription = eCRDUtil.replaceString(strCatalogDescription, "\r\n", " ");
            
            strCatInd = eCRDUtil.verifyNull(request.getParameter("catInd"));  //changes by vikrant

            strContractNum = request.getParameterValues("txtContractNumber");
            strContractDesc = request.getParameterValues("txtContractDesc");
            strStartDate = request.getParameterValues("hdnCustStartDate");
            strEndDate = request.getParameterValues("hdnCustEndDate");

            strDelCust = eCRDAppSecurityUtil.deleteSplChars(eCRDUtil.verifyNull(request.getParameter("hdnCustomerName")));

            objeCRDUser = (eCRDUser)eCRDUtil.getFromSessionApp(request, "objeCRDUser");

            objeCRDCustomerCatalog = (eCRDCustomerCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);

            if (objeCRDCustomerCatalog == null)
            {
                objeCRDCustomerCatalog = new eCRDCustomerCatalog();

            }
            if (strContractNum != null)
            {
                objeCRDEngineModel = new eCRDEngineModel(strEngModelCode.toUpperCase());
                String strUserId = "";
                objeCRDCustomerCatalog.setEngineModel(objeCRDEngineModel);
                objeCRDCustomerCatalog.setCatalogStartDate(strCatStartDate);
                objeCRDCustomerCatalog.setCatalogEndDate(strCatEndDate);
                objeCRDCustomerCatalog.setCatalogNumber(strCatalogNumber);
                objeCRDCustomerCatalog.setCatalogDesc(strCatalogDescription);
                
                objeCRDCustomerCatalog.setCatInd(strCatInd);  //changes by vikrant
                
                for (int i = 0; i < strContractNum.length; i++)
                {
                    strContractDesciption = strContractDesc[i];
                    strContractDesciption = eCRDUtil.replaceString(strContractDesciption, "\r\n", " ");
                    objeCRDCustomer = new eCRDCustomer();
                    objeCRDCustomer.setContractCode(strContractNum[i]);
                    objeCRDCustomer.setCustomerCode(strCustCode[i]);
                    objeCRDCustomer.setCustomerName(strCustomerName[i]);
                    objeCRDCustomer.setContractDesc(strContractDesciption);
                    objeCRDCustomer.setStartDate(strStartDate[i]);
                    objeCRDCustomer.setEndDate(strEndDate[i]);
                    objeCRDCustomerCatalog.addCustomer(objeCRDCustomer);
					strMessage = objeCRDCustomerCatalog.doesContractExists(strEngModelCode.toUpperCase(),strCustCode[i],strContractNum[i]);
					if(!"".equals(strMessage))
					{
						strOutMessage = objeCRDCustomer.getCustomerName() + eCRDConstants.STRCOLUMNDELIM + "CANNOT_CREATE_CATALOG";
						break;
					}
                }
                strUserId = objeCRDUser.getUserId();
                if("".equals(strOutMessage))
                {
					objeCRDCustomerCatalog.create(strUserId);
                }
                else
                	request.setAttribute("Message",strOutMessage);

				eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDCustomerCatalog);
            }
            return strOutMessage;
        }
        finally
        {

            strCustomerName = null;
            strCustCode = null;
            strContractNum = null;
            strContractDesc = null;
            strStartDate = null;
            strEndDate = null;
            strCatStartDate = "";
            strCatEndDate = "";
            strDelCust = "";
            
            strCatInd = null;  //changes by vikrant

            strCatalogNumber = "";
            strCatalogDescription = "";
            strEngModelCode = "";
            strContractDesciption = "";
            objeCRDEngineModel = null;
            objeCRDCustomer = null;
            objeCRDCustomerCatalog = null;
            objeCRDUser = null;
        }

    }

    /**
    	* Method to populate the merge repair rowcache showing Individual repairs.
      * for executing steps to merge selected repairs
     */
    private void mergeRepair(HttpServletRequest request) throws Exception
    {
        GEAEResultSet rsMergeRepair = null;
        GEAEResultSet rsFormattedMergeRepair = null;
        eCRDDataBean objeCRDDataBean = null;
        eCRDBusinessBean objeCRDBusinessBean = null;
        eCRDModule objeCRDModule = null;
        eCRDEngineModel objeCRDEngineModel = null;
        eCRDComponent objeCRDComponent = null;

        String strCatSeqId = "";
        String strEngModel = "";
        String strEngModule = "";
        String strRepairType = "";
        String strComponent = "";
        eCRDCustomerCatalog objeCRDCustomerCatalog = null;
        try
        {
            objeCRDBusinessBean = new eCRDBusinessBean();
            objeCRDDataBean = new eCRDDataBean();
            objeCRDCustomerCatalog = (eCRDCustomerCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);

            objeCRDEngineModel = objeCRDCustomerCatalog.getEngineModel();
            strEngModel = objeCRDCustomerCatalog.getEngineModel().getEngineModelCode();
            strCatSeqId = eCRDCatalog.getCurrentDefaultSeqId(strEngModel);
            strEngModule = eCRDUtil.verifyNull(request.getParameter("hdnEngineModule"));
            strRepairType = "1";
            strComponent = eCRDUtil.verifyNull(request.getParameter("hdnComponent"));
            objeCRDModule = objeCRDEngineModel.getModule(strEngModule);
            objeCRDModule.setModuleCode(strEngModule);
            objeCRDComponent = objeCRDModule.getComponent(strComponent);
            objeCRDComponent.setComponentCode(strComponent);
            objeCRDComponent.setModule(objeCRDModule);
            objeCRDModule.setEngineModel(objeCRDEngineModel);
            objeCRDEngineModel.setCatalog(objeCRDCustomerCatalog);
            objeCRDCustomerCatalog.setEngineModel(objeCRDEngineModel);
            eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDCustomerCatalog);

            rsMergeRepair = objeCRDBusinessBean.populateRepair(strCatSeqId, strEngModel, strEngModule, strRepairType, strComponent, objeCRDCustomerCatalog.getCatalogSeqId());
            //
            if (rsMergeRepair.size() == 0)
            {
                request.setAttribute("flag", "false");
            }
            else
            {
                request.setAttribute("flag", "true");
            }
            rsFormattedMergeRepair = getMergeRepairFormatResultSet(rsMergeRepair);

            objeCRDDataBean.setCache(rsFormattedMergeRepair);

            eCRDUtil.loadInSession(request, "MergeRepair", objeCRDDataBean);

        }
        finally
        {
            rsMergeRepair = null;
            rsFormattedMergeRepair = null;
            objeCRDDataBean = null;
            objeCRDBusinessBean = null;
            objeCRDModule = null;
            objeCRDEngineModel = null;
            objeCRDComponent = null;
            strEngModel = "";
            strEngModule = "";
            strRepairType = "";
            strComponent = "";
            objeCRDCustomerCatalog = null;
        }

    }
    /**
     * request: action=split
     * Execute steps taken in splitting of repair.
     */
    private void splitRepair(HttpServletRequest request) throws Exception
    {
        GEAEResultSet rsSplitRepair = null;
        GEAEResultSet rsFormattedSplitRepair = null;
        eCRDDataBean objeCRDDataBean = null;
        eCRDBusinessBean objeCRDBusinessBean = null;
        eCRDModule objeCRDModule = null;
        eCRDEngineModel objeCRDEngineModel = null;
        eCRDComponent objeCRDComponent = null;

        String strCatSeqId = "";
        String strEngModel = "";
        String strEngModule = "";
        String strRepairType = "";
        String strComponent = "";
        eCRDCustomerCatalog objeCRDCustomerCatalog = null;
        try
        {
            objeCRDBusinessBean = new eCRDBusinessBean();
            objeCRDDataBean = new eCRDDataBean();
            objeCRDCustomerCatalog = (eCRDCustomerCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);

            objeCRDEngineModel = objeCRDCustomerCatalog.getEngineModel();
            strEngModel = objeCRDCustomerCatalog.getEngineModel().getEngineModelCode();
            strCatSeqId = eCRDCatalog.getCurrentDefaultSeqId(strEngModel);
            strEngModule = eCRDUtil.verifyNull(request.getParameter("hdnEngineModule"));
            strRepairType = "2"; //for Split repair
            strComponent = eCRDUtil.verifyNull(request.getParameter("hdnComponent"));

            objeCRDModule = objeCRDEngineModel.getModule(strEngModule);
            objeCRDModule.setModuleCode(strEngModule);
            objeCRDComponent = objeCRDModule.getComponent(strComponent);
            objeCRDComponent.setComponentCode(strComponent);
            objeCRDComponent.setModule(objeCRDModule);
            objeCRDModule.setEngineModel(objeCRDEngineModel);
            objeCRDEngineModel.setCatalog(objeCRDCustomerCatalog);
            objeCRDCustomerCatalog.setEngineModel(objeCRDEngineModel);
            eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDCustomerCatalog);

            rsSplitRepair = objeCRDBusinessBean.populateRepair(strCatSeqId, strEngModel, strEngModule, strRepairType, strComponent, objeCRDCustomerCatalog.getCatalogSeqId());
            if (rsSplitRepair.size() == 0)
            {
                request.setAttribute("flag", "false");
            }
            else
            {
                request.setAttribute("flag", "true");
            }
            rsFormattedSplitRepair = getSplitRepairFormatResultSet(rsSplitRepair);
            objeCRDDataBean.setCache(rsFormattedSplitRepair);
            eCRDUtil.loadInSession(request, "SplitRepair", objeCRDDataBean);
        }
        finally
        {
            rsSplitRepair = null;
            rsFormattedSplitRepair = null;
            objeCRDDataBean = null;
            objeCRDBusinessBean = null;
            objeCRDModule = null;
            objeCRDEngineModel = null;
            objeCRDComponent = null;

            strEngModel = "";
            strEngModule = "";
            strRepairType = "";
            strComponent = "";
            objeCRDCustomerCatalog = null;

        }

    }
    public GEAEResultSet getSplitRepairFormatResultSet(GEAEResultSet rsSearchResults) throws Exception
    {
        GEAEResultSet rsFormattedRS = null;
        GEAETag geAETag = null;
        ArrayList arrlstTemp = null;
        String strRadio = "";
        String strPrice = "";

        try
        {
            rsFormattedRS = new GEAEResultSet();
            rsSearchResults.setCurrentRow(0);
//          19-05-2006 patni checking null value Begin 
            if (rsSearchResults != null)
            {
//              19-05-2006 patni checking null value End               
           
            while (rsSearchResults.next())
            {
                arrlstTemp = new ArrayList();
                strRadio = "<INPUT TYPE='radio' NAME='chkGrpRepair' VALUE='" + rsSearchResults.getString(8) + "'>";

                geAETag = new GEAETag("", strRadio);
                arrlstTemp.add(geAETag);

                arrlstTemp.add(rsSearchResults.getString(1));
                arrlstTemp.add(rsSearchResults.getString(2));
                arrlstTemp.add(rsSearchResults.getString(3));
                arrlstTemp.add(rsSearchResults.getString(4));
                if ("Y".equals(rsSearchResults.getString(9)))
                {
                    strPrice = "+" + rsSearchResults.getString(5);
                }
                else
                {
                    strPrice = rsSearchResults.getString(5);
                }
                arrlstTemp.add(strPrice);
                arrlstTemp.add(rsSearchResults.getString(6));
                arrlstTemp.add(rsSearchResults.getString(7));
                rsFormattedRS.addRow(arrlstTemp);
            }
//          19-05-2006 patni checking null value Begin             
            } // end if 
//          19-05-2006 patni checking null value End            
            rsFormattedRS.setColumnHeading(1, "Split");
            rsFormattedRS.setColumnHeading(2, "Display Sequence");
            rsFormattedRS.setColumnHeading(3, "Repair Description");
            rsFormattedRS.setColumnHeading(4, "Repair Reference");
            rsFormattedRS.setColumnHeading(5, "Sites");
            rsFormattedRS.setColumnHeading(6, "Price");
            rsFormattedRS.setColumnHeading(7, "Price Type");
            rsFormattedRS.setColumnHeading(8, "TAT");

            return rsFormattedRS;
        }

        finally
        {

            rsFormattedRS = null;
            geAETag = null;
            arrlstTemp = null;
            strRadio = "";
            strPrice = "";
        }

    }

    public GEAEResultSet getMergeRepairFormatResultSet(GEAEResultSet rsSearchResults) throws Exception
    {

        GEAEResultSet rsFormattedRS = null;
        GEAETag geAETag = null;
        ArrayList arrlstTemp = null;
        String strChkBox = "";
        String strPrice = "";
        String strColDelimiter = "";

        try
        {

            rsFormattedRS = new GEAEResultSet();
            rsSearchResults.setCurrentRow(0);
//          19-05-2006 patni checking null value Begin 
            if (rsSearchResults !=null) 
            {
//          19-05-2006 patni checking null value End
            while (rsSearchResults.next())
            {
                arrlstTemp = new ArrayList();
                strColDelimiter = eCRDConstants.STRCOLUMNDELIM;
                strChkBox =
                    "<INPUT TYPE='checkbox' NAME='chkIndRepair' VALUE='"
                        + rsSearchResults.getString(8)
                        + strColDelimiter
                        + rsSearchResults.getString(2)
                        + strColDelimiter
                        + rsSearchResults.getString(3)
                        + "~"
                        + strColDelimiter
                        + rsSearchResults.getString("ref_format")
                        + "~"
                        + strColDelimiter
                        + rsSearchResults.getString("rep_comment")
                        + "~"
                        + strColDelimiter
                        + "'>";
                geAETag = new GEAETag("", strChkBox);
                arrlstTemp.add(geAETag);

                arrlstTemp.add(rsSearchResults.getString(1));
                arrlstTemp.add(rsSearchResults.getString(2));
                arrlstTemp.add(rsSearchResults.getString(3));
                arrlstTemp.add(rsSearchResults.getString(4));
                if ("Y".equals(rsSearchResults.getString(9)))
                {
                    strPrice = "+" + rsSearchResults.getString(5);
                }
                else
                {
                    strPrice = rsSearchResults.getString(5);
                }
                arrlstTemp.add(strPrice);
                arrlstTemp.add(rsSearchResults.getString(6));
                arrlstTemp.add(rsSearchResults.getString(7));
                rsFormattedRS.addRow(arrlstTemp);
            }
//          19-05-2006 patni checking null value Begin             
            } // endif 
//          19-05-2006 patni checking null value End            
            rsFormattedRS.setColumnHeading(1, "Merge");
            rsFormattedRS.setColumnHeading(2, "Display Sequence");
            rsFormattedRS.setColumnHeading(3, "Repair Description");
            rsFormattedRS.setColumnHeading(4, "Repair Reference");
            rsFormattedRS.setColumnHeading(5, "Sites");
            rsFormattedRS.setColumnHeading(6, "Price");
            rsFormattedRS.setColumnHeading(7, "Price Type");
            rsFormattedRS.setColumnHeading(8, "TAT");

            return rsFormattedRS;
        }

        finally
        {

            rsFormattedRS = null;
            geAETag = null;
            arrlstTemp = null;
            strChkBox = "";
            strPrice = "";
            strColDelimiter = "";

        }

    }
    private String copyExistingCust(HttpServletRequest request) throws Exception
    {
        String strCustomerName[] = null;
        String strCustCode[] = null;
        String strContractNum[] = null;
        String strContractDesc[] = null;
        String strStartDate[] = null;
        String strEndDate[] = null;
        String strCatStartDate = "";
        String strCatEndDate = "";
        String strDelCust = "";
		String strOutMessage = "";
		String strMessage = "";
        String strCatalogNumber = "";
        String strCatalogDescription = "";
        
        String strCatInd = null; //changes by vikrant
        
        String strEngModelCode = "";

        eCRDEngineModel objeCRDEngineModel = null;
        eCRDCustomer objeCRDCustomer = null;
        eCRDCustomerCatalog objeCRDCustomerCatalog = null;

        try
        {

            strContractNum = request.getParameterValues("txtContractNumber");
            strCustCode = request.getParameterValues("hdnCustomerCode");
            strCustomerName = request.getParameterValues("hdnCustName");

            strEngModelCode = eCRDUtil.verifyNull(request.getParameter("lstEngModel"));
            strCatStartDate = eCRDUtil.verifyNull(request.getParameter("hdnStartDate"));
            strCatEndDate = eCRDUtil.verifyNull(request.getParameter("hdnEndDate"));
            strCatalogNumber = eCRDUtil.verifyNull(request.getParameter("txtCatalogNum"));
            strCatalogDescription = eCRDUtil.verifyNull(request.getParameter("txtCatalogDesc"));
            
            strCatInd = eCRDUtil.verifyNull(request.getParameter("catInd"));  //changes by vikrant
            
            strContractNum = request.getParameterValues("txtContractNumber");
            strContractDesc = request.getParameterValues("txtContractDesc");
            strStartDate = request.getParameterValues("hdnCustStartDate");
            strEndDate = request.getParameterValues("hdnCustEndDate");

            strDelCust = eCRDAppSecurityUtil.deleteSplChars(eCRDUtil.verifyNullNoTrim(request.getParameter("hdnCustomerName")));

            objeCRDCustomerCatalog = (eCRDCustomerCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
            if (objeCRDCustomerCatalog == null)
            {
                objeCRDCustomerCatalog = new eCRDCustomerCatalog();

            }

            if (strContractNum != null)
            {
                objeCRDEngineModel = new eCRDEngineModel(strEngModelCode.toUpperCase());

                objeCRDCustomerCatalog.setEngineModel(objeCRDEngineModel);
                objeCRDCustomerCatalog.setCatalogStartDate(strCatStartDate);
                objeCRDCustomerCatalog.setCatalogEndDate(strCatEndDate);
                objeCRDCustomerCatalog.setCatalogNumber(strCatalogNumber);
                objeCRDCustomerCatalog.setCatalogDesc(strCatalogDescription);
                
                objeCRDCustomerCatalog.setCatInd(strCatInd);  //changes by vikrant
                
                objeCRDCustomerCatalog.setActive(true);
                for (int i = 0; i < strContractNum.length; i++)
                {
                    objeCRDCustomer = new eCRDCustomer();
                    objeCRDCustomer.setContractCode(strContractNum[i]);
                    objeCRDCustomer.setCustomerCode(strCustCode[i]);
                    objeCRDCustomer.setCustomerName(strCustomerName[i]);
                    objeCRDCustomer.setContractDesc(strContractDesc[i]);
                    objeCRDCustomer.setStartDate(strStartDate[i]);
                    objeCRDCustomer.setEndDate(strEndDate[i]);
                    objeCRDCustomerCatalog.addCustomer(objeCRDCustomer);
					strMessage = objeCRDCustomerCatalog.doesContractExists(strEngModelCode.toUpperCase(),strCustCode[i],strContractNum[i]);
					if(!"".equals(strMessage))
					{
						strOutMessage = objeCRDCustomer.getCustomerName() + eCRDConstants.STRCOLUMNDELIM + "CANNOT_CREATE_CATALOG";
						break;
					}
                }
				request.setAttribute("Message",strOutMessage);

                eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDCustomerCatalog);
            }
            return strOutMessage;
        }
        finally
        {
            strCustomerName = null;
            strCustCode = null;

            strDelCust = "";

            strEngModelCode = "";
            strCatalogNumber = "";
            strCatalogDescription = "";
            
            strCatInd = null;  //changes by vikrant
            
            objeCRDEngineModel = null;
            objeCRDCustomer = null;
        }
    }

    /**
    	* request: action=create
    	* For executing steps to create a blank catalog.
    	*/
    private void createCust(HttpServletRequest request) throws Exception
    {
        String strCustName[] = null;
        String strCustCode[] = null;

        String strCustAddDel = "";
        String strContractNum[] = null;
        String strContractDesc[] = null;
        String strStartDate[] = null;
        String strEndDate[] = null;
        //String strCatStartDate = "";
        //String strCatEndDate = "";
        String strDelCustCode = "";
        String strContractDesciption = "";
        ArrayList arrlstCustCode = null;
        //String strEngModelCode = "";
        String strFlag = "";

        eCRDCustomer objeCRDCustomer = null;
        eCRDCustomerCatalog objeCRDCustomerCatalog = null;
        try
        {
            strCustName = request.getParameterValues("hdnCustName");
            strCustCode = request.getParameterValues("hdnCustomerCode");
            strContractNum = request.getParameterValues("txtContractNumber");
            //strEngModelCode = eCRDUtil.verifyNull(request.getParameter("lstEngModel"));
            //strCatStartDate = eCRDUtil.verifyNull(request.getParameter("hdnStartDate"));
            //strCatEndDate = eCRDUtil.verifyNull(request.getParameter("hdnEndDate"));

            strContractNum = request.getParameterValues("txtContractNumber");
            strContractDesc = request.getParameterValues("txtContractDesc");
            strStartDate = request.getParameterValues("hdnCustStartDate");
            strEndDate = request.getParameterValues("hdnCustEndDate");

            arrlstCustCode = (ArrayList)eCRDUtil.getFromSession(request, "eCRDCustomerCode");

            strFlag = eCRDUtil.verifyNull(request.getParameter("hdnflag"));
            strCustAddDel = eCRDUtil.verifyNull(request.getParameter("hdnAddDelCust"));
            strDelCustCode = eCRDUtil.verifyNull(request.getParameter("hdnCustCode"));

            objeCRDCustomerCatalog = (eCRDCustomerCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
            if ("true".equals(strFlag))
            {
                if (objeCRDCustomerCatalog == null)
                {
                    objeCRDCustomerCatalog = new eCRDCustomerCatalog();

                }
            }

            if (!"true".equals(strFlag) && arrlstCustCode != null)
            {

                arrlstCustCode.remove(strDelCustCode);
                if (objeCRDCustomerCatalog != null)
                {
                    objeCRDCustomer = objeCRDCustomerCatalog.getCustomer(strDelCustCode);

                    if (objeCRDCustomer != null)
                    {
                        objeCRDCustomerCatalog.removeCustomer(strDelCustCode);

                    }

                }
            }
            if (strContractNum != null && "true".equals(strFlag))
            {

                for (int i = 0; i < strCustCode.length; i++)
                {

                    strContractDesciption = strContractDesc[i];
                    strContractDesciption = eCRDUtil.replaceString(strContractDesciption, "\r\n", " ");
                    objeCRDCustomer = new eCRDCustomer();
                    objeCRDCustomer.setContractCode(strContractNum[i]);
                    objeCRDCustomer.setCustomerCode(strCustCode[i]);
                    objeCRDCustomer.setCustomerName(strCustName[i]);
                    objeCRDCustomer.setContractDesc(strContractDesciption);
                    objeCRDCustomer.setStartDate(strStartDate[i]);
                    objeCRDCustomer.setEndDate(strEndDate[i]);
                    objeCRDCustomerCatalog.addCustomer(objeCRDCustomer);

                }
            }
            if ("DelCust".equals(strCustAddDel) && strContractNum != null && "true".equals(strFlag))
            {
                for (int i = 0; i < strCustCode.length; i++)
                {

                    if (strDelCustCode.equals(arrlstCustCode.get(i)))
                    {

                        objeCRDCustomerCatalog.removeCustomer(strCustCode[i]);
                        arrlstCustCode = (ArrayList)eCRDUtil.getFromSession(request, "eCRDCustomerCode");
                        arrlstCustCode.remove(strDelCustCode);
                        eCRDUtil.loadInSession(request, "eCRDCustomerCode", arrlstCustCode);
                        break;
                    }
                }
            }
            eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDCustomerCatalog);

        }
        finally
        {
            strCustName = null;
            strCustCode = null;

            strCustAddDel = "";
            strContractNum = null;
            strContractDesc = null;
            strStartDate = null;
            strEndDate = null;
            //strCatStartDate = "";
            //strCatEndDate = "";
            strDelCustCode = "";
            strContractDesciption = "";
            arrlstCustCode = null;
            //strEngModelCode = "";
            strFlag = "";

        }
    }

    /*
     *
     */
    private String setCopiedSeqId(HttpServletRequest request) throws Exception
    {
        eCRDCustomerCatalog objeCRDCustomerCatalog = null;
        String strCatalogType = "";
        eCRDUser objeCRDUser = null;
        eCRDException objeCRDException = null;
        String strUserId = "";
        String strMessage = "";
        String strCopyCatalogId = "";
        try
        {
            objeCRDCustomerCatalog = (eCRDCustomerCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
            objeCRDUser = (eCRDUser)eCRDUtil.getFromSessionApp(request, "objeCRDUser");
            strUserId = objeCRDUser.getUserId();

            strCatalogType = eCRDUtil.verifyNull(request.getParameter("hdnCatalogType"));
            strCopyCatalogId = eCRDUtil.verifyNull(request.getParameter("hdnCatalogValue"));
            objeCRDCustomerCatalog = (eCRDCustomerCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
            if (objeCRDCustomerCatalog == null)
            {
                objeCRDException = new eCRDException();
                objeCRDException.setExcpId("CATALOG_NOT_SET");
                throw objeCRDException;
            }
            objeCRDCustomerCatalog.setCopiedCatalogSeq(strCopyCatalogId);

            objeCRDCustomerCatalog.create(strUserId);
            if ("C".equals(strCatalogType))
            {
                strMessage = objeCRDCustomerCatalog.copyCatalogRules(strUserId);
            }

            eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDCustomerCatalog);
            request.setAttribute("Message", strMessage);

            return strMessage;
        }
        finally
        {
            objeCRDCustomerCatalog = null;
            strCatalogType = "";
        }
    }

    private void getCatalogList(HttpServletRequest request, String strAction) throws Exception
    {
        // 	To store the resultset of catalog
        GEAEResultSet rsCatalog = null;
        //	To store the formatted resultset
        GEAEResultSet rsFormattedCatalog = null;

        eCRDDataBean objeCRDDataBean = null;
        eCRDBusinessBean objeCRDBusinessBean = null;

        //	To store catalog type
        String strCatalogType = "";

        //	To store catalog name
        String strCatalogName = "";

        //	To store engine model code selected
        String strEngineModelCode = "";

        //	To store caatlog effective date

        String strStartDay = "";
        String strStartMonth = "";
        String strStartYear = "";
        String strComponentEffetciveDate = "";

        //	To store caatlog end date
        String strEndDay = "";
        String strEndMonth = "";
        String strEndYear = "";
        String strComponentEndDate = "";

        ArrayList arrInLst = null;

        try
        {
            arrInLst = new ArrayList();
            rsFormattedCatalog = new GEAEResultSet();

            objeCRDDataBean = new eCRDDataBean();
            objeCRDBusinessBean = new eCRDBusinessBean();

            //	To get the required entries from the JSP

            strCatalogType = eCRDUtil.verifyNull(request.getParameter("hdnCatalogValue"));
            strCatalogName = eCRDUtil.verifyNull(request.getParameter("txtCatalogName"));
            strEngineModelCode = eCRDUtil.verifyNull(request.getParameter("hdnModelCode"));

            strStartDay = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_DD"));
            strStartMonth = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_MM"));
            strStartYear = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_YYYY"));

            strComponentEffetciveDate = eCRDUtil.formatDate(strStartDay, strStartMonth, strStartYear);

            strEndDay = eCRDUtil.verifyNull(request.getParameter("sel_man_Enddate_DD"));
            strEndMonth = eCRDUtil.verifyNull(request.getParameter("sel_man_Enddate_MM"));
            strEndYear = eCRDUtil.verifyNull(request.getParameter("sel_man_Enddate_YYYY"));

            strComponentEndDate = eCRDUtil.formatDate(strEndDay, strEndMonth, strEndYear);

            //	To get the resultset of components for the required combination of
            //	engine model,engine module,ATANumber,Component Code,component description

            arrInLst.add(strCatalogType);
            arrInLst.add(strCatalogName);
            arrInLst.add(strEngineModelCode);
            arrInLst.add(strComponentEffetciveDate);
            arrInLst.add(strComponentEndDate);

            rsCatalog = objeCRDBusinessBean.populateExistingCatalogList(strAction, arrInLst);
            if (rsCatalog.size() == 0)
            {
                eCRDUtil.loadInSession(request, "CatalogList", "Empty");
            }
            if (rsCatalog.size() > 0)
            {
                rsCatalog.setCurrentRow(0);
                rsCatalog.next();
                eCRDUtil.loadInSession(request, "CatalogList", "NotEmpty");
                // To format the resultset as per the requirement
                rsFormattedCatalog = formatCatalogList(rsCatalog);
            }
            // To set the formatted resultset in the cache
            objeCRDDataBean.setCache(rsFormattedCatalog);
            // To save the data bean object in session
            eCRDUtil.loadInSession(request, "objeCRDExistingCatalogList", objeCRDDataBean);
        }
        finally
        {
            strCatalogType = "";
            strCatalogName = "";
            strEngineModelCode = "";
            strStartDay = "";
            strStartMonth = "";
            strStartYear = "";
            strComponentEffetciveDate = "";
            strEndDay = "";
            strEndMonth = "";
            strEndYear = "";
            strComponentEndDate = "";
        }
    }

    private GEAEResultSet formatCatalogList(GEAEResultSet rsCatalogList) throws Exception
    {
        GEAEResultSet rsFormattedComponentList = null;
        ArrayList arrlstFormattedComponentList = null;

        GEAETagNoData tagRadio = null;

        String strRadioValue = "";

        String strCatalogSeqId = "";
        //		String strEngineModelCode = "";

        try
        {
            if (rsCatalogList != null && rsCatalogList.size() > 0)
            {
                rsFormattedComponentList = new GEAEResultSet();
                for (int i = 0; i < rsCatalogList.size(); i++)
                {
                    arrlstFormattedComponentList = new ArrayList();
                    strCatalogSeqId = rsCatalogList.getString(1);
                    //					strEngineModelCode = rsCatalogList.getString(2);
                    strRadioValue = "" + eCRDUtil.replaceQuoteForJS(strCatalogSeqId);
                    tagRadio =
                        new GEAETagNoData(
                            "<INPUT TYPE=\"radio\" NAME=\"radCatalog\" VALUE=\"" + strRadioValue + "\" onClick = \"javascript:fnGetCatalogValue('" + strRadioValue + "',document.frmCatalogList)\" ");
                    arrlstFormattedComponentList.add(tagRadio);
                    arrlstFormattedComponentList.add(eCRDUtil.verifyNull(rsCatalogList.getString(2)));
                    GEAETag geAETag = new GEAETag(rsCatalogList.getString("sortable_start_date"), rsCatalogList.getString(3));
                    //arrlstFormattedComponentList.add(eCRDUtil.verifyNull(rsCatalogList.getString(3)));
                    arrlstFormattedComponentList.add(geAETag);
                    //arrlstFormattedComponentList.add(eCRDUtil.verifyNull(rsCatalogList.getString(5)));
                    GEAETag geAENewTag = new GEAETag(rsCatalogList.getString("sortable_end_date"), rsCatalogList.getString(5));
                    arrlstFormattedComponentList.add(geAENewTag);
                    arrlstFormattedComponentList.add(eCRDUtil.verifyNull(rsCatalogList.getString(7)));
                    rsFormattedComponentList.addRow(arrlstFormattedComponentList);
                    rsCatalogList.next();
                }
                rsFormattedComponentList.setColumnHeading(1, "Select");
                rsFormattedComponentList.setColumnHeading(2, "Engine Model");
                rsFormattedComponentList.setColumnHeading(3, "Start Date");

                rsFormattedComponentList.setColumnHeading(4, "End Date");
                rsFormattedComponentList.setColumnHeading(5, "Description");
                rsFormattedComponentList.sort(2, true);
            }
        }
        finally
        {
            arrlstFormattedComponentList = null;
            tagRadio = null;
            strRadioValue = "";
            strCatalogSeqId = "";
            //			strEngineModelCode = "";
        }
        return rsFormattedComponentList;
    }

    /**
     * request: action=createrule
     * Create Customer Catalog Rules.
     */
    private String createCustCatalogRules(HttpServletRequest request) throws Exception
    {
        eCRDCustomerCatalog objeCRDCustomerCatalog = null;
        eCRDCatalogRule objeCRDCatalogRule = null;
        eCRDEscalation objeCRDEscalation = null;
        String strDiscount = "";
        String strTAT = "";
        String strEscalation = "";
        String strIndexs[] = null;
        String strIndDependency[] = null;
        int intIndexSize = 0;
        String strEsclnIndex[][] = null;
        String strFlowDownChanges = "";
        String strDefaultCompare = "";
        String strUserId = "";
        eCRDUser objeCRDUser = null;
        String strMessage = "";
        try
        {
            objeCRDUser = (eCRDUser)eCRDUtil.getFromSessionApp(request, "objeCRDUser");
            strUserId = objeCRDUser.getUserId();
            objeCRDCustomerCatalog = (eCRDCustomerCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
            if (objeCRDCustomerCatalog == null)
            {
                objeCRDCustomerCatalog = new eCRDCustomerCatalog();
            }
            objeCRDCatalogRule = (eCRDCatalogRule)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOGRULE);
            strDiscount = eCRDUtil.verifyNull(request.getParameter("txtDiscount"));
            strTAT = eCRDUtil.verifyNull(request.getParameter("txtTAT"));
            strEscalation = eCRDUtil.verifyNull(request.getParameter("txtEscln"));
            strFlowDownChanges = eCRDUtil.verifyNull(request.getParameter("chkFlowchange"));
            strDefaultCompare = eCRDUtil.verifyNull(request.getParameter("chkDefaultless"));
            strIndexs = request.getParameterValues("txtindex");
            strIndDependency = request.getParameterValues("txtdepend");

            if (!"".equals(strTAT))
			{
				objeCRDCatalogRule.setTAT(eCRDUtil.verifyIntObj(strTAT));
			}
			else
			{
				objeCRDCatalogRule.setTAT(null);
			}

			if (!"".equals(strDiscount))
			{
				objeCRDCatalogRule.setDiscount(eCRDUtil.verifyDoubleObj(strDiscount));
			}
			else
			{
				objeCRDCatalogRule.setDiscount(null);
			}

            objeCRDEscalation = new eCRDEscalation();
            if (!"".equals(strEscalation))
            {
                objeCRDEscalation.setEscalation(eCRDUtil.verifyDoubleObj(strEscalation));
            }
            else if (strIndexs != null)
            {
                intIndexSize = strIndexs.length;
                strEsclnIndex = new String[intIndexSize][3];
                for (int i = 0; i < intIndexSize; i++)
                {
                    strEsclnIndex[i][0] = strIndexs[i];
                    strEsclnIndex[i][1] = strIndDependency[i];
					strEsclnIndex[i][2] = "Y";
                }
                objeCRDEscalation.setIndexDependency(strEsclnIndex);
            }

            objeCRDCatalogRule.addEscalation(objeCRDEscalation);
            objeCRDCatalogRule.setFlowChangesFrmDef(eCRDUtil.retBoolean(strFlowDownChanges));
			objeCRDCustomerCatalog.setFlowChangesFrmDef(eCRDUtil.retBoolean(strFlowDownChanges));

            objeCRDCatalogRule.setDefaltValCompare(eCRDUtil.retBoolean(strDefaultCompare));
			objeCRDCustomerCatalog.setDefaltValCompare(eCRDUtil.retBoolean(strDefaultCompare));

            strMessage = objeCRDCustomerCatalog.createCatalogRule(objeCRDCatalogRule, strUserId);

            eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDCustomerCatalog);
            eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOGRULE, objeCRDCatalogRule);
            request.setAttribute("Message", strMessage);

            return strMessage;
        }
        finally
        {
            objeCRDCustomerCatalog = null;
            objeCRDCatalogRule = null;
            objeCRDEscalation = null;
            strDiscount = "";
            strTAT = "";
            strEscalation = "";
            strIndexs = null;
            strIndDependency = null;
            intIndexSize = 0;
            strEsclnIndex = null;
            strFlowDownChanges = "";
            strDefaultCompare = "";
            strUserId = "";
            objeCRDUser = null;
            //strMessage = "";
        }
    }

    /**
     * request: action=downlaod
     * For executing steps to downlaod catalog details from database.
     */
    private void downloadCatalog()
    {

    }

    /**
     * request: action=modify
     * Execute steps to store modified Customer Catalog.
     */
    private void modifyCustomerCatalog()
    {

    }

    /**
     * This method will be called when a catalog is selected and u need to apply rules to it.
     * @param HttpServletRequest request
     * throws Exception
     * @author patni
     */
    /*private void getRulesCriteriaDetails(HttpServletRequest request) throws Exception
    {
    	   //eCRDCustomerCatalog objeCRDCustomerCatalog = null;
    	   //ArrayList arrlstInParam = null;
    	   //ArrayList arrlstOutParam = null;
    	   //String strStartDate = "";
    	   //String strEndDate = "";
    	   try
    	   {
    	   	   //objeCRDCustomerCatalog = (eCRDCustomerCatalog)eCRDUtil.getFromSession(request,"eCRDCatalog");
    	   	   //strStartDate = objeCRDCustomerCatalog.getStartDate();
    	   	   //strEndDate = objeCRDCustomerCatalog.getEndDate();
    	   }
    	   finally
    	   {
    	   	   //objeCRDCustomerCatalog = null;
    	   	  // arrlstInParam = null;
    	   	   //arrlstOutParam = null;
    	   }
    }*/

    /** This method will load the details depending on the Rule Level selected.
     * @param HttpServletRequest
     * @return void
     * throws Exception
     * */
    public void getDetails(HttpServletRequest request) throws Exception
    {
        String strRuleCd = "";
        GEAEResultSet rsModules = null;
        String strModuleDropDown = "";
        String strComponentDropDown = "";
        String strRepairDropDown = "";
        eCRDCustomerCatalog objeCRDCustomerCatalog = null;
        eCRDException objeCRDException = null;
        String strCatalogId = "";
        String strModuleId = "";
        String strComponentId = "";
        GEAEResultSet rsComponents = null;
        GEAEResultSet rsRepair = null;
        //String strSelectedModule = "";
        //String strSelectedComponent = "";
        String strSelectedYear = "";
        String strEngineModel = "";
        try
        {
            rsModules = new GEAEResultSet();
            rsComponents = new GEAEResultSet();
            rsRepair = new GEAEResultSet();
            strRuleCd = eCRDUtil.verifyNull(request.getParameter("drpdwn_Rule"));
            if (eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG) != null)
            {
                objeCRDCustomerCatalog = (eCRDCustomerCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
            }
            else
            {
                objeCRDException = new eCRDException();
                objeCRDException.setExcpId("CATALOG_NOT_SET");
                throw objeCRDException;
            }
            strEngineModel = objeCRDCustomerCatalog.getEngineModel().getEngineModelCode();
            strCatalogId = eCRDCatalog.getCurrentDefaultSeqId(strEngineModel);
            strModuleId = eCRDUtil.verifyNull(request.getParameter("drpdwn_Module"));
            strComponentId = eCRDUtil.verifyNull(request.getParameter("drpdwn_Component"));
            strSelectedYear = eCRDUtil.verifyNull(request.getParameter("drpdwn_year"));
            if (!"C".equals(strRuleCd))
            {
                if ("M".equals(strRuleCd) || "CO".equals(strRuleCd) || "R".equals(strRuleCd))
                {
                    rsModules = eCRDLoadMaster.getModuleList(strCatalogId);
                    strModuleDropDown = eCRDUtil.populateOptions(rsModules, strModuleId, false);
                }
                if ("CO".equals(strRuleCd) || "R".equals(strRuleCd))
                {
                    rsComponents = eCRDLoadMaster.getComponentList(strCatalogId, strModuleId);
                    strComponentDropDown = eCRDUtil.populateOptions(rsComponents, strComponentId, false);
                }
                if ("R".equals(strRuleCd))
                {
                    rsRepair = eCRDLoadMaster.getRepairList(strCatalogId, strModuleId, strComponentId);
                    strRepairDropDown = eCRDUtil.populateOptions(rsRepair, "", false);
                }
            }
            request.setAttribute("ModuleDropDown", strModuleDropDown);
            request.setAttribute("ComponentDropDown", strComponentDropDown);
            request.setAttribute("RepairDropDown", strRepairDropDown);
            request.setAttribute("YearDropDown", strSelectedYear);
            eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDCustomerCatalog);
        }
        finally
        {
            strRuleCd = "";
            rsModules = null;
            strModuleDropDown = "";
            strComponentDropDown = "";
            strRepairDropDown = "";
            objeCRDCustomerCatalog = null;
            objeCRDException = null;
            strCatalogId = "";
            strModuleId = "";
            strComponentId = "";
            rsComponents = null;
            rsRepair = null;
            //	strSelectedModule = "";
            //	strSelectedComponent = "";
            strSelectedYear = "";
        }
    }

    /** This method is used to save the Rule in object.
     * @param HttpServletRequest
     * @return void
     * throws Exception
     * */
    public String saveRuleDetails(HttpServletRequest request) throws Exception
    {
        eCRDCustomerCatalog objeCRDCustomerCatalog = null;
        eCRDCatalogRule objeCRDCatalogRule = null;
        String strYear = "";
        String strRuleCd = "";
        String strModuleCd = "";
        String strComponentCd = "";
        String strRepairCd = "";
        int intStartYear = 0;
        int intEndYear = 0;
        HashMap hmIndex = null;
        HashMap hmDependency = null;
        String strMessage = "";
        try
        {
            strYear = eCRDUtil.verifyNull(request.getParameter("drpdwn_year"));
            intStartYear = Integer.parseInt(eCRDUtil.verifyNull(request.getParameter("hdnStartYear")));
            intEndYear = Integer.parseInt(eCRDUtil.verifyNull(request.getParameter("hdnEndYear")));
            strRuleCd = (eCRDUtil.verifyNull(request.getParameter("drpdwn_Rule")));
            strModuleCd = (eCRDUtil.verifyNull(request.getParameter("drpdwn_Module")));
            strComponentCd = (eCRDUtil.verifyNull(request.getParameter("drpdwn_Component")));
            strRepairCd = (eCRDUtil.verifyNull(request.getParameter("drpdwn_Repair")));

            objeCRDCustomerCatalog = (eCRDCustomerCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
            if (objeCRDCustomerCatalog == null)
            {
                //objeCRDCustomerCatalog = new eCRDCustomerCatalog("25");
            }
            if ("All".equalsIgnoreCase(strYear))
            {
                for (int inti = intStartYear; inti <= intEndYear; inti++)
                {

                    strMessage = objeCRDCustomerCatalog.checkRuleExists(inti + "", strRuleCd, strComponentCd, strModuleCd, strRepairCd);
                    if ("".equals(strMessage))
                    {
                        objeCRDCatalogRule = objeCRDCustomerCatalog.getRule(inti + "", strRuleCd, strComponentCd, strModuleCd, strRepairCd);
                        objeCRDCatalogRule.setYear("All");
                    }
                    else
                    {
                        strMessage = "RULE_PRESENT_FOR_OTHER_YEAR";
                        break;
                    }
                    //objeCRDCatalogRule.
                }
            }
            else
            {
                strMessage = objeCRDCustomerCatalog.checkRuleExists(strYear, strRuleCd, strComponentCd, strModuleCd, strRepairCd);
                if ("".equals(strMessage))
                {
                    objeCRDCatalogRule = objeCRDCustomerCatalog.getRule(strYear, strRuleCd, strComponentCd, strModuleCd, strRepairCd);
                }
            }
            hmIndex = new HashMap();
            hmDependency = new HashMap();
            hmIndex.put(0 + "", "");
            hmDependency.put(0 + "", "");
            eCRDUtil.loadInSession(request, "eCRDAddIndex", hmIndex);
            eCRDUtil.loadInSession(request, "eCRDAddDependency", hmDependency);
            eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOGRULE, objeCRDCatalogRule);
            eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDCustomerCatalog);
            request.setAttribute("ExistMessage", strMessage);
            return strMessage;
        }
        finally
        {
            objeCRDCustomerCatalog = null;
            objeCRDCatalogRule = null;
            strYear = "";
            strRuleCd = "";
            strModuleCd = "";
            strComponentCd = "";
            strRepairCd = "";
            intStartYear = 0;
            intEndYear = 0;
            hmIndex = null;
            hmDependency = null;
        }
    }

    /**This method is used to add extra row in Inflation table
     * @param HttpServletRequest
     * @return void
     * throws Exception
     * */
    public void getInflation(HttpServletRequest request) throws Exception
    {
        HashMap hmIndex = null;
        HashMap hmDependency = null;
        int intisize = 0;
        String strIndexs[] = null;
        String strIndDependency[] = null;
        try
        {

            hmIndex = new HashMap();
            hmDependency = new HashMap();
            strIndexs = request.getParameterValues("txtindex");
            strIndDependency = request.getParameterValues("txtdepend");
            if (strIndexs != null)
            {
                for (int i = 0; i < strIndexs.length; i++)
                {
                    hmIndex.put(i + "", strIndexs[i]);
                    hmDependency.put(i + "", strIndDependency[i]);
                }
            }
            intisize = hmIndex.size();
            hmIndex.put((intisize + 1) + "", "");
            hmDependency.put((intisize + 1) + "", "");
            eCRDUtil.loadInSession(request, "eCRDAddIndex", hmIndex);
            eCRDUtil.loadInSession(request, "eCRDAddDependency", hmDependency);
        }
        finally
        {
            hmIndex = null;
            hmDependency = null;
            strIndexs = null;
            strIndDependency = null;
        }
    }

    /**This is used to Delete a row from Inflation Table.
     * @param HttpServletRequest
     * @return void
     * throws Exception
     * */
    public void deleteInflation(HttpServletRequest request) throws Exception
    {
        String strSelectedValue = "";
        String strEsclnIndex[][]=null;
		int intIndexSize = 0;
		eCRDEscalation objeCRDEscalation = null;
		eCRDCatalogRule objeCRDCatalogRule = null;
        try
        {
			objeCRDCatalogRule = (eCRDCatalogRule)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOGRULE);
            strSelectedValue = eCRDUtil.verifyNull(request.getParameter("hdnDeleteValue"));

            eCRDUtil.removeFromSession(request,"eCRDAddIndex");
			eCRDUtil.removeFromSession(request,"eCRDAddDependency");

            objeCRDEscalation = objeCRDCatalogRule.getEscalation();
            strEsclnIndex = objeCRDEscalation.getIndexDependency();
			for (int i = 0; i < strEsclnIndex.length; i++)
			{
				if(i == Integer.parseInt(strSelectedValue))
				{
					strEsclnIndex[i][2] = "N";
				}
			}
			objeCRDEscalation.setIndexDependency(strEsclnIndex);
			objeCRDCatalogRule.addEscalation(objeCRDEscalation);
			eCRDUtil.removeFromSession(request,eCRDConstants.STRCATALOGRULE);
			eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOGRULE, objeCRDCatalogRule);
        }
        finally
        {
            strSelectedValue = "";
			strEsclnIndex = null;
			intIndexSize = 0;
			objeCRDEscalation = null;
			objeCRDCatalogRule = null;
        }
    }
    private void getCustomerTable(HttpServletRequest request) throws Exception
    {

        GEAEResultSet rsFormatted = null;
        GEAEResultSet rsCustomerTable = null;
        eCRDDataBean objeCRDDataBean = null;
        String strFindCustName = null ;
        String	strActive = null ;
        String strEngineModel = null;
        try
        {
        	System.out.println("SANTOSH IN TEST getting customer RS Method");
            rsFormatted = new GEAEResultSet();
            rsCustomerTable = new GEAEResultSet();
            objeCRDDataBean = new eCRDDataBean();

            strFindCustName = eCRDAppSecurityUtil.deleteSplChars(eCRDUtil.verifyNull(request.getParameter("hdnCustomerName")));
			strActive = eCRDUtil.verifyNull(request.getParameter("hdnOnlyActive"));
			strEngineModel = eCRDUtil.verifyNull(request.getParameter("hdnEngineModel"));
			
			System.out.println("SANTOSH IN TEST getting customer RS Method Engine Model"+strEngineModel);
			
            rsCustomerTable = eCRDLoadMaster.getCustomerListReport(strFindCustName,strEngineModel,strActive);
            rsFormatted = formatCustomerResultSet(rsCustomerTable);
            objeCRDDataBean.setCache(rsFormatted);
            eCRDUtil.loadInSession(request, "CustomerTable", objeCRDDataBean);
        }
        finally
        {

            rsFormatted = null;
            rsCustomerTable = null;
            objeCRDDataBean = null;
        }

    }

    private GEAEResultSet formatCustomerResultSet(GEAEResultSet rsSearchResults) throws Exception
    {
        GEAEResultSet rsFormattedRS = null;
        ArrayList arrlstTemp = null;
        rsFormattedRS = new GEAEResultSet();

        GEAETag geAETag = null;
        try
        {
            rsSearchResults.setCurrentRow(0);
//          19-05-2006 patni checking null value Begin 
            if (rsSearchResults != null)
            { 
//          19-05-2006 patni checking null value Begin 
            while (rsSearchResults.next())
            {
                arrlstTemp = new ArrayList();

                geAETag = new GEAETag("", "<INPUT TYPE='RADIO' NAME='radio' value='" + rsSearchResults.getString(1) + "^" + rsSearchResults.getString(2) + "'>");
                arrlstTemp.add(geAETag);
                arrlstTemp.add(rsSearchResults.getString(1));
                arrlstTemp.add(rsSearchResults.getString(2));

                System.out.println("SANTOSH IN TEST getting customer RS FORMAT Method"+rsSearchResults.getString(1));
                
                rsFormattedRS.addRow(arrlstTemp);
                arrlstTemp = null;
                geAETag = null;

            }
//          19-05-2006 patni checking null value Begin             
            } //end if 
//          19-05-2006 patni checking null value Begin             
            rsFormattedRS.setColumnHeading(1, "Select");
            rsFormattedRS.setColumnHeading(2, "Customer Code");
            rsFormattedRS.setColumnHeading(3, "Customer Name");
            rsFormattedRS.sort(3, true);
            return rsFormattedRS;
        }
        finally
        {
            rsFormattedRS = null;

        }

    }

    /**This Method is used to load all the rules for the selected Year
     * @param HttpServletRequest
     * @return void
     * throws Exception
     * */
    private void ViewCustCatalogRule(HttpServletRequest request) throws Exception
    {
        eCRDCustomerCatalog objeCRDCustomerCatalog = null;
        eCRDException objeCRDException = null;
        String strYear = "";
        GEAEResultSet rsCatalog = null;
        GEAEResultSet rsInflation = null;
        GEAEResultSet rsModules = null;
        GEAEResultSet rsComponent = null;
        GEAEResultSet rsRepair = null;
        GEAEResultSet rsResults[] = null;
        try
        {
            rsResults = new GEAEResultSet[5];
            strYear = eCRDUtil.verifyNull(request.getParameter("drpdwn_year"));
            objeCRDCustomerCatalog = (eCRDCustomerCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
            if (objeCRDCustomerCatalog == null)
            {
                objeCRDException = new eCRDException();
                objeCRDException.setExcpId("CATALOG_NOT_SET");
                throw objeCRDException;
            }

            rsResults = objeCRDCustomerCatalog.viewRules(strYear);

            rsCatalog = rsResults[0];
            rsInflation = rsResults[1];
            rsModules = rsResults[2];
            rsComponent = rsResults[3];
            rsRepair = rsResults[4];

            request.setAttribute("CatalogRule", rsCatalog);
            request.setAttribute("InflationRule", rsInflation);
            request.setAttribute("ComponentRule", rsComponent);
            request.setAttribute("ModuleRule", rsModules);
            request.setAttribute("RepairRule", rsRepair);

			eCRDUtil.removeFromSession(request,"eCRDAddIndex");
			eCRDUtil.removeFromSession(request,"eCRDAddDependency");
        }
        finally
        {
            objeCRDCustomerCatalog = null;
            objeCRDException = null;
            strYear = "";
            rsCatalog = null;
            rsInflation = null;
            rsModules = null;
            rsComponent = null;
            rsRepair = null;
            rsResults = null;
        }
    }

    /** This Method is used to load the details of the rules to be modified
     * @param HttpServletRequet
     * @return void
     * throws Exception
     * */
    private void modifyCustCatalogRule(HttpServletRequest request) throws Exception
    {
        String strYear = "";
        String strModuleId = "";
        String strComponentId = "";
        String strRepairId = "";
        String strRuleCd = "";
        eCRDCustomerCatalog objeCRDCustomerCatalog = null;
        eCRDCatalogRule objeCRDCatalogRule = null;
        HashMap hmIndex = null;
        HashMap hmDependency = null;
        try
        {
            strYear = eCRDUtil.verifyNull(request.getParameter("hdnYear"));
            strModuleId = eCRDUtil.verifyNull(request.getParameter("hdnModuleCd"));
            strComponentId = eCRDUtil.verifyNull(request.getParameter("hdnComponentCd"));
            strRepairId = eCRDUtil.verifyNull(request.getParameter("hdnRepairCd"));
            strRuleCd = eCRDUtil.verifyNull(request.getParameter("hdnRuleCd"));

            objeCRDCustomerCatalog = (eCRDCustomerCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
            objeCRDCatalogRule = objeCRDCustomerCatalog.getRule(strYear, strRuleCd, strComponentId, strModuleId, strRepairId);

			/*hmIndex = new HashMap();
			hmDependency = new HashMap();
			hmIndex.put(0 + "", "");
			hmDependency.put(0 + "", "");*/
			eCRDUtil.loadInSession(request, "eCRDAddIndex", hmIndex);
			eCRDUtil.loadInSession(request, "eCRDAddDependency", hmDependency);

            eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOGRULE, objeCRDCatalogRule);
            eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDCustomerCatalog);
			eCRDUtil.loadInSession(request,"Modify", "Y");
        }
        finally
        {
            strYear = "";
            strModuleId = "";
            strComponentId = "";
            strRepairId = "";
            strRuleCd = "";
            objeCRDCustomerCatalog = null;
            objeCRDCatalogRule = null;
        }
    }

    /** This Method updates the rule in the Database.
     * @param HttpServletRequest
     * @return void
     * throws Exception
     */
    private void updateCustCatalogRule(HttpServletRequest request) throws Exception
    {
        eCRDCustomerCatalog objeCRDCustomerCatalog = null;
        eCRDCatalogRule objeCRDCatalogRule = null;
        eCRDEscalation objeCRDEscalation = null;
        String strDiscount = "";
        String strTAT = "";
        String strEscalation = "";
        String strIndexs[] = null;
        String strIndDependency[] = null;
        int intIndexSize = 0;
        String strEsclnIndex[][] = null;
        String strFlowDownChanges = "";
        String strDefaultCompare = "";
        String strUserId = "";
        eCRDUser objeCRDUser = null;
        String strMessage = "";
        HashMap hmIndex = null;
        HashMap hmDependency = null;
        try
        {
            objeCRDUser = (eCRDUser)eCRDUtil.getFromSessionApp(request, "objeCRDUser");
            strUserId = objeCRDUser.getUserId();
            objeCRDCustomerCatalog = (eCRDCustomerCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
            if (objeCRDCustomerCatalog == null)
            {
                objeCRDCustomerCatalog = new eCRDCustomerCatalog();
            }
            objeCRDCatalogRule = (eCRDCatalogRule)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOGRULE);
            strDiscount = eCRDUtil.verifyNull(request.getParameter("txtDiscount"));
            strTAT = eCRDUtil.verifyNull(request.getParameter("txtTAT"));
            strEscalation = eCRDUtil.verifyNull(request.getParameter("txtEscln"));
            strFlowDownChanges = eCRDUtil.verifyNull(request.getParameter("chkFlowchange"));
            strDefaultCompare = eCRDUtil.verifyNull(request.getParameter("chkDefaultless"));
            strIndexs = request.getParameterValues("txtindex");
            strIndDependency = request.getParameterValues("txtdepend");

			if (!"".equals(strDiscount))
			{
				objeCRDCatalogRule.setDiscount(eCRDUtil.verifyDoubleObj(strDiscount));
			}
			else
			{
				objeCRDCatalogRule.setDiscount(null);
			}

			if (!"".equals(strTAT))
			{
				objeCRDCatalogRule.setTAT(eCRDUtil.verifyIntObj(strTAT));
			}
			else
			{
				objeCRDCatalogRule.setTAT(null);
			}

            objeCRDEscalation = new eCRDEscalation();
            if (!"".equals(strEscalation))
            {
                objeCRDEscalation.setEscalation(eCRDUtil.verifyDoubleObj(strEscalation));
            }
            else if (strIndexs != null)
            {
                intIndexSize = strIndexs.length;
                strEsclnIndex = new String[intIndexSize][3];
                for (int i = 0; i < intIndexSize; i++)
                {
                    strEsclnIndex[i][0] = strIndexs[i];
                    strEsclnIndex[i][1] = strIndDependency[i];
					strEsclnIndex[i][2] = "Y";
                }
                objeCRDEscalation.setIndexDependency(strEsclnIndex);
            }

            objeCRDCatalogRule.addEscalation(objeCRDEscalation);

			objeCRDCustomerCatalog.setFlowChangesFrmDef(eCRDUtil.retBoolean(strFlowDownChanges));
			objeCRDCustomerCatalog.setDefaltValCompare(eCRDUtil.retBoolean(strDefaultCompare));

            strMessage = objeCRDCustomerCatalog.UpdateCatalogRule(objeCRDCatalogRule, strUserId);

            eCRDUtil.loadInSession(request,"Modify", "Y");
            request.setAttribute("Message", strMessage);

			eCRDUtil.removeFromSession(request,"eCRDAddIndex");
			eCRDUtil.removeFromSession(request,"eCRDAddDependency");

			/*eCRDUtil.loadInSession(request, "eCRDAddIndex", hmIndex);
			eCRDUtil.loadInSession(request, "eCRDAddDependency", hmDependency);*/
            eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOGRULE, objeCRDCatalogRule);
            eCRDUtil.loadInSession(request,eCRDConstants.STRCATALOG,objeCRDCustomerCatalog);
        }
        finally
        {
            objeCRDCustomerCatalog = null;
            objeCRDCatalogRule = null;
            objeCRDEscalation = null;
            strDiscount = "";
            strTAT = "";
            strEscalation = "";
            strIndexs = null;
            strIndDependency = null;
            intIndexSize = 0;
            strEsclnIndex = null;
            strFlowDownChanges = "";
            strDefaultCompare = "";
            strUserId = "";
            objeCRDUser = null;
            strMessage = "";
        }
    }
    /** This Methods call's copyandApplyRule method of Customercatalog to apply Rules
     * @param HttpServletRequest
     * @return void
     * throws Exception
     */
    private void copyAndApplyRules(HttpServletRequest request) throws Exception
    {
        eCRDCustomerCatalog objeCRDCustomerCatalog = null;
        eCRDUser objeCRDUser = null;
        String strMessage = "";
        String strUserId = "";
        try
        {
            objeCRDCustomerCatalog = (eCRDCustomerCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
            objeCRDUser = (eCRDUser)eCRDUtil.getFromSessionApp(request, "objeCRDUser");
            strUserId = objeCRDUser.getUserId();
            strMessage = objeCRDCustomerCatalog.copyAndApplyRules(strUserId);

            request.setAttribute("Message", strMessage);
            request.setAttribute("DisplayMessage", "N");
            eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDCustomerCatalog);
        }
        finally
        {
            objeCRDCustomerCatalog = null;
            objeCRDUser = null;
            strMessage = "";
            strUserId = "";
        }
    }
    /** This Methods call's ApplyDefaultRefreshRules  method of Customercatalog to apply Default Refresh Rules -Kumar
     * @param HttpServletRequest
     * @return void
     * throws Exception
     */
    private void ApplyDefaultRefreshRules (HttpServletRequest request) throws Exception
    {
        eCRDCustomerCatalog objeCRDCustomerCatalog = null;
        eCRDUser objeCRDUser = null;
        String strMessage = "";
        String strUserId = "";
        try
        {
            objeCRDCustomerCatalog = (eCRDCustomerCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
            objeCRDUser = (eCRDUser)eCRDUtil.getFromSessionApp(request, "objeCRDUser");
            strUserId = objeCRDUser.getUserId();
            strMessage = objeCRDCustomerCatalog.ApplyDefaultRefreshRules(strUserId);

            request.setAttribute("Message", strMessage);
            request.setAttribute("DisplayMessage", "N");
            eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDCustomerCatalog);
        }
        finally
        {
            objeCRDCustomerCatalog = null;
            objeCRDUser = null;
            strMessage = "";
            strUserId = "";
        }
    }
    /**
     *
     * @param request
     * @return String
     * @throws Exception
     */
    private String mergeRepairs(HttpServletRequest request) throws Exception
    {
        //String strAlertCode = null;
        String strRepairs = null;
        StringBuffer strbuffRepairsCommaSep = null;
        String strRepairsCommaSep = null;

        StringTokenizer strtknRow = null;
        StringTokenizer strtknCol = null;
        //String strCost = null;
        String strModuleCd = null;
        String strCompCd = null;
        String strRepComments = null;
        String strRepref = null;
        String strReprefFormat = null;

        String strRepairsMerge = null;
        String strRepairsMergeDesc = null;

        HashMap hmLbrRate = null;

        GEAEResultSet geaersetSite = null;
        GEAEResultSet geaersetLbrRate = null;

        ArrayList arrlstInParam = null;
        ArrayList arrlstOutParam = null;

        eCRDCustomerCatalog objeCRDCustomerCatalog = null;
        eCRDEngineModel objeCRDEngineModel = null;
        eCRDException objeCRDException = null;
        eCRDGroupedRepair objeCRDGroupedRepair = null;
        eCRDChildRepair objeCRDChildRepair = null;
        eCRDComponent objeCRDComponent = null;
        eCRDModule objeCRDModule = null;
        eCRDRepairSite objeCRDRepairSite = null;
        eCRDUser objeCRDUser = null;

        //double dblCost = 0;
        //int intCtr = 0;
        try
        {
            objeCRDCustomerCatalog = (eCRDCustomerCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
            if (objeCRDCustomerCatalog == null)
            {
                objeCRDException = new eCRDException();
                objeCRDException.setExcpId("CATALOG_NOT_SET");
                throw objeCRDException;
            }
            objeCRDEngineModel = objeCRDCustomerCatalog.getEngineModel();
            if (objeCRDEngineModel == null)
            {
                objeCRDException = new eCRDException();
                objeCRDException.setExcpId("MODEL_NOT_SET");
                throw objeCRDException;
            }
            objeCRDUser = (eCRDUser)eCRDUtil.getFromSessionApp(request, "objeCRDUser");
            strRepairs = request.getParameter("hdnSelectedRepair");
            strtknRow = new StringTokenizer(strRepairs, eCRDConstants.STRROWDELIM);

            strModuleCd = request.getParameter("hdnEngineModule");
            strCompCd = request.getParameter("hdnComponent");
            objeCRDModule = objeCRDEngineModel.getModule(strModuleCd);
            objeCRDComponent = objeCRDModule.getComponent(strCompCd);
            objeCRDComponent.removeRepairs();
            objeCRDGroupedRepair = (eCRDGroupedRepair)objeCRDComponent.addRepair(eCRDConstants.STRGROUPREPAIR);

            objeCRDGroupedRepair.setCreatedFromMerge(new Boolean(true));
            objeCRDGroupedRepair.setRepairType(eCRDConstants.STRMERGEREPAIR);
            strbuffRepairsCommaSep = new StringBuffer();
            while (strtknRow.hasMoreTokens())
            {
                strtknCol = new StringTokenizer(strtknRow.nextToken(), eCRDConstants.STRCOLUMNDELIM);

                strRepairsMerge = strtknCol.nextToken();
                strRepairsMergeDesc = strtknCol.nextToken();
                strRepref = strtknCol.nextToken();
                strReprefFormat = strtknCol.nextToken();
                strRepComments = strtknCol.nextToken();

                strRepref = strRepref.substring(0, strRepref.length() - 1);
                strReprefFormat = strReprefFormat.substring(0, strReprefFormat.length() - 1);
                strRepComments = strRepComments.substring(0, strRepComments.length() - 1);

                strbuffRepairsCommaSep.append(strRepairsMerge);
                strbuffRepairsCommaSep.append(",");
                objeCRDChildRepair = objeCRDGroupedRepair.addChildRepair();
                objeCRDChildRepair.setStrReapirDesc(strRepairsMergeDesc);
                objeCRDChildRepair.setStrChildRepairCode(strRepairsMerge);
                objeCRDChildRepair.setMergeSplitSeqId(strRepairsMerge);
                objeCRDChildRepair.setStrRepairRefNo(strRepref);
                objeCRDChildRepair.setStrReapairRefFormat(strReprefFormat);
                objeCRDChildRepair.setStrComments(strRepComments);
            }
            arrlstInParam = new ArrayList();
            strRepairsCommaSep = strbuffRepairsCommaSep.toString();
            objeCRDGroupedRepair.setStrRepairCode(strRepairsCommaSep);
            arrlstInParam.add(strRepairsCommaSep);

            arrlstInParam.add(objeCRDUser.getUserId());
            arrlstOutParam = eCRDDBMediator.doDBOperation(eCRDConstants.getActionId("eCRD_GET_LBHR_CST"), arrlstInParam);
            geaersetSite = (GEAEResultSet)arrlstOutParam.get(0);
            geaersetLbrRate = (GEAEResultSet)arrlstOutParam.get(1);
            hmLbrRate = new HashMap();
            if (geaersetLbrRate != null && geaersetLbrRate.size() > 0)
            {
                while (geaersetLbrRate.next())
                {
                    hmLbrRate.put(geaersetLbrRate.getString("location_id"), eCRDUtil.verifyNullReturnZero(geaersetLbrRate.getString("location_labor_rate")));
                }
            }
            if (geaersetSite != null && geaersetSite.size() > 0)
            {
                while (geaersetSite.next())
                {
                    objeCRDRepairSite = objeCRDGroupedRepair.addSite();
                    objeCRDRepairSite.setLaborHr(eCRDUtil.verifyDouble(geaersetSite.getString("labour_hours")));
                    objeCRDRepairSite.setMaterialCost(Double.parseDouble(eCRDUtil.verifyNullReturnZero(geaersetSite.getString("material_cost"))));
                    objeCRDRepairSite.setSiteCode(geaersetSite.getString("location_id"));
                    objeCRDRepairSite.setSiteDescription(geaersetSite.getString("location_desc"));
                    objeCRDRepairSite.setLocationLaborRate(Double.parseDouble((String)hmLbrRate.get(geaersetSite.getString("location_id"))));
                    objeCRDRepairSite.setECRDGroupedRepair(objeCRDGroupedRepair);
                }

            }

            objeCRDGroupedRepair.setECRDComponent(objeCRDComponent);

            objeCRDComponent.setModule(objeCRDModule);
            objeCRDModule.setEngineModel(objeCRDEngineModel);
            objeCRDEngineModel.setCatalog(objeCRDCustomerCatalog);
            eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDCustomerCatalog);
            return strRepairsCommaSep;
        }
        finally
        {
            //strAlertCode = null;
            strRepairs = null;
            //strCost = null;

            strRepairsMerge = null;

            objeCRDCustomerCatalog = null;
            objeCRDEngineModel = null;
            objeCRDException = null;
            objeCRDGroupedRepair = null;
            objeCRDChildRepair = null;
            objeCRDComponent = null;
            objeCRDModule = null;

        }

    }
    /**
     *
     * @param request
     * @return
     * @throws Exception
     */
    private String getChildRepairs(HttpServletRequest request) throws Exception
    {
        //String strAlertCode = null;
        //String strRepairs = null;
        String strModuleCd = null;
        String strCompCd = null;
        //String strRepSeqId = null;
        String strParentRepair = null;

        StringBuffer strbuffRepairs = null;
        eCRDCustomerCatalog objeCRDCustomerCatalog = null;
        eCRDEngineModel objeCRDEngineModel = null;
        eCRDException objeCRDException = null;
        eCRDIndRepair objeCRDIndRepair = null;

        eCRDComponent objeCRDComponent = null;
        eCRDModule objeCRDModule = null;

        ArrayList arrlstInParam = null;
        ArrayList arrlstOutParam = null;

        GEAEResultSet geaersetChildRepairs = null;

        try
        {
            objeCRDCustomerCatalog = (eCRDCustomerCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
            if (objeCRDCustomerCatalog == null)
            {
                objeCRDException = new eCRDException();
                objeCRDException.setExcpId("CATALOG_NOT_SET");
                throw objeCRDException;
            }
            objeCRDEngineModel = objeCRDCustomerCatalog.getEngineModel();
            if (objeCRDEngineModel == null)
            {
                objeCRDException = new eCRDException();
                objeCRDException.setExcpId("MODEL_NOT_SET");
                throw objeCRDException;
            }
            strParentRepair = request.getParameter("hdnSelectedRepair");
            strbuffRepairs = new StringBuffer();
            strbuffRepairs.append(strParentRepair + ",");
            //strRepSeqId = "";
            strModuleCd = request.getParameter("hdnEngineModule");
            strCompCd = request.getParameter("hdnComponent");
            objeCRDModule = objeCRDEngineModel.getModule(strModuleCd);
            objeCRDComponent = objeCRDModule.getComponent(strCompCd);
            objeCRDComponent.removeRepairs();
            arrlstInParam = new ArrayList();
            //arrlstInParam.add(objeCRDCustomerCatalog.getCatalogSeqId());

            arrlstInParam.add(strParentRepair);
            arrlstOutParam = eCRDDBMediator.doDBOperation(eCRDConstants.getActionId("eCRD_GET_CHILD_RPRS"), arrlstInParam);
            geaersetChildRepairs = (GEAEResultSet)arrlstOutParam.get(0);
            if (geaersetChildRepairs != null && geaersetChildRepairs.size() > 0)
            {
                while (geaersetChildRepairs.next())
                {
                    objeCRDIndRepair = (eCRDIndRepair)objeCRDComponent.addRepair(eCRDConstants.STRINDIVIDUALREPAIR);
                    objeCRDIndRepair.setCreatedFromSplit(true);
                    objeCRDIndRepair.setRepairType(eCRDConstants.STRSLITREPAIR);
                    objeCRDIndRepair.setRepairRefNo(geaersetChildRepairs.getString("repair_ref"));
                    objeCRDIndRepair.setStrRepairDesc(geaersetChildRepairs.getString("repair_desc"));
                    objeCRDIndRepair.setRepairRefFormat(geaersetChildRepairs.getString("repair_ref_format"));
                    objeCRDIndRepair.setStrRepairCode(geaersetChildRepairs.getString("repair_seqid"));
                    strbuffRepairs.append(geaersetChildRepairs.getString("repair_seqid") + ",");
                    objeCRDIndRepair.setMergeSplitSeqId(geaersetChildRepairs.getString("repair_seqid"));
                    objeCRDIndRepair.setECRDComponent(objeCRDComponent);
                }

            }
            else
            {
                throw new Exception("Child repairs not found for Parent Repair");
            }
            objeCRDComponent.setModule(objeCRDModule);
            objeCRDModule.setEngineModel(objeCRDEngineModel);
            objeCRDEngineModel.setCatalog(objeCRDCustomerCatalog);
            eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDCustomerCatalog);

            return strbuffRepairs.toString();
        }
        finally
        {
            //strAlertCode = null;
            //strRepairs = null;
            strParentRepair = null;

            objeCRDCustomerCatalog = null;
            objeCRDEngineModel = null;
            objeCRDException = null;
            objeCRDIndRepair = null;

            objeCRDComponent = null;
            objeCRDModule = null;

            arrlstInParam = null;
            arrlstOutParam = null;

            geaersetChildRepairs = null;
        }
    }

    /** This Method is used to load the details of the rules to be modified
     * @param HttpServletRequet
     * @return void
     * throws Exception
     * */
    private void deleteCustCatalogRule(HttpServletRequest request) throws Exception
    {
        String strYear = "";
        String strModuleId = "";
        String strComponentId = "";
        String strRepairId = "";
        String strRuleCd = "";
        String strCatalogId = "";
        eCRDCustomerCatalog objeCRDCustomerCatalog = null;
        String strMessage = null;
        try
        {
            strYear = eCRDUtil.verifyNull(request.getParameter("hdnYear"));
            strModuleId = eCRDUtil.verifyNull(request.getParameter("hdnModuleCd"));
            strComponentId = eCRDUtil.verifyNull(request.getParameter("hdnComponentCd"));
            strRepairId = eCRDUtil.verifyNull(request.getParameter("hdnRepairCd"));
            strRuleCd = eCRDUtil.verifyNull(request.getParameter("hdnRuleCd"));

            objeCRDCustomerCatalog = (eCRDCustomerCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
            strCatalogId = objeCRDCustomerCatalog.getCatalogSeqId() + "";
            strMessage = objeCRDCustomerCatalog.deleteRule(strYear, strRuleCd, strComponentId, strModuleId, strRepairId, strCatalogId);

            //eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOGRULE, objeCRDCatalogRule);
            eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDCustomerCatalog);

            request.setAttribute("Message", strMessage);

            ViewCustCatalogRule(request);
        }
        finally
        {
            strYear = "";
            strModuleId = "";
            strComponentId = "";
            strRepairId = "";
            strRuleCd = "";
            objeCRDCustomerCatalog = null;
            //objeCRDCatalogRule = null;
        }
    }
    private String finalSplit(HttpServletRequest request) throws Exception
    {
        String strDelRepairs = null;
        String strReturn = null;
        String strModuleCd = null;
        String strCompCd = null;

        ArrayList arrlstRepairs = null;
        HashMap hmDesc = null;
        HashMap hmDispSeq = null;

        eCRDComponent objeCRDComponent = null;
        eCRDCustomerCatalog objeCRDCustomerCatalog = null;
        eCRDUser objeCRDUser = null;
        eCRDException objeCRDException = null;
        eCRDEngineModel objeCRDEngineModel = null;
        eCRDRepair objeCRDRepair = null;
        eCRDRepairPricing objeCRDRepairPricing = null;

        int intRepairSize = 0;
        //int                      intDispSize             = 0   ;
        //int                      intDescSize             = 0   ;
        boolean isUniqueDisp = true;
        boolean isUniqueDesc = true;
        try
        {
            strDelRepairs = (String)eCRDUtil.getFromSession(request, "strDelRepairs");
            strDelRepairs = eCRDUtil.verifyNull(strDelRepairs);
            if ("".equals(strDelRepairs))
            {
                objeCRDException = new eCRDException();
                objeCRDException.setExcpId("eCRD_SESSION");
                throw objeCRDException;
            }
            objeCRDCustomerCatalog = (eCRDCustomerCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
            if (objeCRDCustomerCatalog == null)
            {
                objeCRDException = new eCRDException();
                objeCRDException.setExcpId("CATALOG_NOT_SET");
                throw objeCRDException;
            }
            objeCRDEngineModel = objeCRDCustomerCatalog.getEngineModel();
            if (objeCRDEngineModel == null)
            {
                objeCRDException = new eCRDException();
                objeCRDException.setExcpId("MODEL_NOT_SET");
                throw objeCRDException;
            }
            strModuleCd = eCRDUtil.verifyNull(request.getParameter("hdnEngineModule"));
            strCompCd = eCRDUtil.verifyNull(request.getParameter("hdnComponent"));
            if ("".equals(strModuleCd) || "".equals(strCompCd))
            {
                throw new Exception("Hidden Paramters not set in request");
            }
            objeCRDComponent = objeCRDEngineModel.getModule(strModuleCd).getComponent(strCompCd);
            hmDesc = new HashMap();
            hmDispSeq = new HashMap();
            arrlstRepairs = objeCRDComponent.getAllRepairs();
            if (arrlstRepairs != null && arrlstRepairs.size() > 0)
            {
                intRepairSize = arrlstRepairs.size();
                for (int intCtr = 0; intCtr < intRepairSize; intCtr++)
                {
                    objeCRDRepair = (eCRDRepair)arrlstRepairs.get(intCtr);
                    objeCRDRepairPricing = objeCRDRepair.getObjRepairPricing();
                    hmDesc.put(objeCRDRepair.getStrRepairDesc(), objeCRDRepair.getStrRepairDesc());
                    hmDispSeq.put(objeCRDRepairPricing.getRepairSeqNo(), objeCRDRepairPricing.getRepairSeqNo());
                }
                isUniqueDisp = intRepairSize != hmDispSeq.size();
                isUniqueDesc = intRepairSize != hmDesc.size();
                if (isUniqueDisp)
                {
                    return "NON_UNIQUE_DISP_SPLIT";
                }
                if (isUniqueDesc)
                {
                    return "NON_UNIQUE_DESC_SPLIT";
                }
            }
            objeCRDUser = (eCRDUser)eCRDUtil.getFromSessionApp(request, "objeCRDUser");
            strReturn = objeCRDComponent.createRepair(request, objeCRDUser.getUserId(), objeCRDUser.getRole(), eCRDConstants.STRSLITREPAIR, "", strDelRepairs);
            return strReturn;
        }
        finally
        {

        }

    }
}
