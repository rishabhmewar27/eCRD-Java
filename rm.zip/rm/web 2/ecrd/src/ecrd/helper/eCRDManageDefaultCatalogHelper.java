//Source file: D:\\ECRD\\SOURCE CODE\\ecrd\\helper\\eCRDManageDefaultCatalogHelper.java
/**
 * Module       : eCRDManageDefaultCatalogHelper.java
 * Author       : Patni Offshore
 * Project      : eCRD
 * Date Written : October 2004
 * Security     : Classified/Unclassified
 * Restrictions : GE PROPRIETORY INFORMATION, FOR GE USE ONLY
 *
 *     ***************************************************************
 *     *          Copyright (2000) with all rights reserved          *
 *     *                  General Electric Company                   *
 *     ***************************************************************
 * Description  :  This class has methods to get the Master Tables Data.
 * Revision Log  (mm/dd/yyyy     Initials    description)
 * -------------------------------------------------------------------
 * mm/dd/yyyy     Initials     Description
 * -------------------------------------------------------------------
 *	10/15/2004		GM   	Coded
 *   31/15/2005     patni  Phase 1 requirement updations 
 */
package ecrd.helper;
import java.util.ArrayList;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;

import ecrd.biz.eCRDCatalog;
import ecrd.biz.eCRDDefaultCatalog;
import ecrd.biz.eCRDEngineModel;
import ecrd.biz.eCRDModule;
import ecrd.biz.eCRDUser;
import ecrd.common.eCRDBusinessBean;
import ecrd.common.eCRDCommand;
import ecrd.common.eCRDDataBean;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDSearchBean;
import ecrd.util.eCRDUtil;
import geae.dao.GEAEResultSet;
import geae.util.format.GEAETag;
import geae.util.format.GEAETagNoData;

public class eCRDManageDefaultCatalogHelper implements eCRDCommand
{

    public eCRDManageDefaultCatalogHelper()
    {
    }

    /**
    * Based "action" attribute from the request, this function calls the appropriate 
    * private functions in this class.
    * Also sets the received request to member variable.
    * @param request
    */

    public String perform(HttpServletRequest request) throws Exception
    {
        String strReturnURL = "";
        String strScreenAction = "";
        boolean blncont = true;

        try
        {
            strScreenAction = eCRDUtil.verifyNull(request.getParameter("hdnScreenAction"));

            if ("".equalsIgnoreCase(strScreenAction))
            {
                eCRDUtil.clearSession(request);
                strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-createCatalog";
            }
            else if (eCRDConstants.getActionId("eCRD_CREATE_BLANK_CATALOG").equalsIgnoreCase(strScreenAction))
            {
                blncont = createBlankCatalog(request);
                if (blncont == true)
                {
                    engineModuleListing(request);
                    strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-engineModuleList";
                }
                else
                {
                    strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-createCatalog";
                }
            }
            else if ((eCRDConstants.getActionId("eCRD_CREATE_MODULE")).equalsIgnoreCase(strScreenAction))
            {
                strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-createModule";
            }
            else if ((eCRDConstants.getActionId("eCRD_CREATE_MODULE_ACTION")).equalsIgnoreCase(strScreenAction))
            {
                createNewModule(request);
                engineModuleListing(request);
                strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-engineModuleList";

            }
            else if ((eCRDConstants.getActionId("eCRD_MODIFY_MODULE_ACTION")).equalsIgnoreCase(strScreenAction))
            {
                ModifyModule(request);
                engineModuleListing(request);
                strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-engineModuleList";
            }

            else if ((eCRDConstants.getActionId("eCRD_MODIFY_MODULE")).equalsIgnoreCase(strScreenAction))
            {

                strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-modifyModule";
            }
            else if ((eCRDConstants.getActionId("eCRD_ADD_MODULE")).equalsIgnoreCase(strScreenAction))
            {
                addEngModules(request);
                engineModuleListing(request);
                strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-engineModuleList";
            }
            else if ((eCRDConstants.getActionId("eCRD_DELETE_MODULE")).equalsIgnoreCase(strScreenAction))
            {

                deleteEngModules(request);
                engineModuleListing(request);
                strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-engineModuleList";
            }

            else if (eCRDConstants.getActionId("eCRD_GET_DEFAULT_CATALOGLIST").equalsIgnoreCase(strScreenAction))
            {
                getDefaultCatalogList(request);
                strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-getDefaultCatalogList";
            }
            else if (eCRDConstants.getActionId("eCRD_COPY_DEFAULT_CATALOG").equalsIgnoreCase(strScreenAction))
            {
                blncont = copyDefaultCatalog(request);
                if (blncont == true)
                {
                    strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-ComponentListing";
                }
                else
                {
                    strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-createCatalog";
                }
            }

        }
        finally
        {
        }
        return strReturnURL;
    }

    /**
    * For executing steps in creation of Blank Catalog
    */
    private boolean createBlankCatalog(HttpServletRequest request) throws Exception
    {

        eCRDUser objeCRDUser = null;
        eCRDEngineModel objeCRDEngineModel = null;
        eCRDDefaultCatalog objeCRDDefaultCatalog = null;
        String strUserID = null;
        String strEngCode = null;
        String strEngDesc = null;
        String strStartdate_DD = null;
        String strStartdate_MM = null;
        String strStartdate_YYYY = null;
        String strEnddate_DD = null;
        String strEnddate_MM = null;
        String strEnddate_YYYY = null;
        String strStartDate = null;
        String strEndDate = null;
        String strCatDesc = null;
        
        String strCatInd = null;  //changes by vikrant
        
        String strErrMsg = null;
		String strVisibleToCWC = null;
		
        boolean blncont = true;

        try
        {
            objeCRDEngineModel = new eCRDEngineModel();
            objeCRDDefaultCatalog = new eCRDDefaultCatalog();
            objeCRDUser = (eCRDUser)eCRDUtil.getFromSessionApp(request, "objeCRDUser");

            strEngCode = eCRDUtil.verifyNull(request.getParameter("txtEngCode")).toUpperCase();
            
            strCatInd = eCRDUtil.verifyNull(request.getParameter("catInd"));  //changes by vikrant
            
            strEngDesc = eCRDUtil.verifyNull(request.getParameter("txtEngDesc")).toUpperCase();
            strStartdate_DD = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_DD"));
            strStartdate_MM = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_MM"));
            strStartdate_YYYY = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_YYYY"));
            strEnddate_DD = eCRDUtil.verifyNull(request.getParameter("sel_man_Enddate_DD"));
            strEnddate_MM = eCRDUtil.verifyNull(request.getParameter("sel_man_Enddate_MM"));
            strEnddate_YYYY = eCRDUtil.verifyNull(request.getParameter("sel_man_Enddate_YYYY"));
            strCatDesc = eCRDUtil.verifyNull(request.getParameter("txtCatDesc"));
			strVisibleToCWC = eCRDUtil.verifyNull(request.getParameter("chkVisibleToCWC"));			
            strStartDate = eCRDUtil.formatDate(strStartdate_DD, strStartdate_MM, strStartdate_YYYY);
            strEndDate = eCRDUtil.formatDate(strEnddate_DD, strEnddate_MM, strEnddate_YYYY);

            //setting the seqid to the copied object 
            strUserID = eCRDUtil.verifyNull(objeCRDUser.getUserId());

            //setting the object with respective values
            objeCRDEngineModel.setEngineModelCode(strEngCode);
            objeCRDEngineModel.setEngineModelDesc(strEngDesc);
            objeCRDDefaultCatalog.setCatalogStartDate(strStartDate);
            objeCRDDefaultCatalog.setCatalogEndDate(strEndDate);
            objeCRDDefaultCatalog.setCatalogDesc(strCatDesc);
            
            objeCRDDefaultCatalog.setCatInd(strCatInd);  //changes by vikrant
            
            objeCRDDefaultCatalog.setEngineModel(objeCRDEngineModel);
			objeCRDDefaultCatalog.setVisibleToCWC(strVisibleToCWC);
			

            //calling the biz method for DB Operation
            blncont = objeCRDDefaultCatalog.create(strUserID);

            if (blncont == true) //if blncont true then the object is set in the session forwarded to the new jsp.
            {
                eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDDefaultCatalog);
            }
            else //else displays the error message in the same JSP.
                {
                eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDDefaultCatalog);
                strErrMsg = eCRDConstants.getMessage("eCRD_CATALOG_ALREADY_EXIST");
                request.setAttribute("ErrorMsg", strErrMsg);
            }

        }
        finally
        {

            objeCRDEngineModel = null;
            objeCRDDefaultCatalog = null;
            objeCRDUser = null;
            strUserID = null;
            strEngCode = null;
            
            strCatInd = null;  //changes by vikrant
            
            strEngDesc = null;
            strStartdate_DD = null;
            strStartdate_MM = null;
            strStartdate_YYYY = null;
            strEnddate_DD = null;
            strEnddate_MM = null;
            strEnddate_YYYY = null;
            strStartDate = null;
            strEndDate = null;
            strCatDesc = null;
            strErrMsg = null;
        }
        return blncont;
    }

    /**
    * This function is called when action=DeleteModules.
    * Function adds selected modules  for  a Engine Model code 
    * which is taken from the request .
    */

    private void engineModuleListing(HttpServletRequest request) throws Exception
    {

        eCRDDataBean objeCRDDataBean = null;
        eCRDBusinessBean objeCRDBusinessBean = null;
        eCRDSearchBean objeCRDSearchBean = null;
        GEAEResultSet rsFormatted = null;
        GEAEResultSet rsModules = null;
        GEAEResultSet rsEngModule = null;
        String strEngModelCode = "";

        try
        {

            objeCRDDataBean = new eCRDDataBean();
            objeCRDBusinessBean = new eCRDBusinessBean();
            objeCRDSearchBean = new eCRDSearchBean();
            strEngModelCode = eCRDUtil.verifyNull(request.getParameter("hdnEngModelCode"));
            rsEngModule = objeCRDSearchBean.searchModule(strEngModelCode);
            eCRDUtil.loadInSession(request, "eCRDModuleListing", rsEngModule);
            rsModules = objeCRDBusinessBean.populateModule(strEngModelCode);
            if (rsModules.size() == 0)
            {
                request.setAttribute("flag", "false");
            }
            else
            {
                request.setAttribute("flag", "true");
            }
            rsFormatted = getModuleFormatResultSet(rsModules);
            objeCRDDataBean.setCache(rsFormatted);
            eCRDUtil.loadInSession(request, "eCRDEngModuleListing", objeCRDDataBean);
        }
        finally
        {
            strEngModelCode = "";
            objeCRDDataBean = null;
            objeCRDBusinessBean = null;
            objeCRDSearchBean = null;
            rsFormatted = null;
            rsModules = null;
            rsEngModule = null;

        }
    }
    /**
    * 
    * Function formats the resultset to be shown in the jsp.
    */

    public GEAEResultSet getModuleFormatResultSet(GEAEResultSet rsSearchResults) throws Exception
    {

        GEAEResultSet rsFormattedRS = null;
        GEAETag geAETag = null;
        ArrayList arrlstTemp = null;
        String basePath = "";
        String strChkBox = "";
        String strEngineModule = "";

        try
        {
            rsFormattedRS = new GEAEResultSet();
            basePath = eCRDUtil.getBasePath();
            rsSearchResults.setCurrentRow(0);
//          19-05-2006 patni checking null value Begin 
            if (rsSearchResults != null)
            {
//              19-05-2006 patni checking null value End                
           
            while (rsSearchResults.next())
            {
                arrlstTemp = new ArrayList();

                strChkBox = "<INPUT TYPE='checkbox' NAME='chkEngModule' VALUE='" + rsSearchResults.getString(1) + "'>";
                geAETag = new GEAETag("", strChkBox);
                arrlstTemp.add(geAETag);

                strEngineModule =
                    "<A href=\"javascript:fnSelectEngineModule(\'"
                        + rsSearchResults.getString(1)
                        + "\',\'"
                        + rsSearchResults.getString(2)
                        + "\',\'"
                        + basePath
                        + "\')\">"
                        + rsSearchResults.getString(2)
                        + "</A>";
                geAETag = new GEAETag(rsSearchResults.getString(1), strEngineModule);

                arrlstTemp.add(geAETag);
                arrlstTemp.add(rsSearchResults.getString(3));
                geAETag = new GEAETag(rsSearchResults.getString("sortable_creation_date"), rsSearchResults.getString(4));
                arrlstTemp.add(geAETag);

                rsFormattedRS.addRow(arrlstTemp);
            }
//          19-05-2006 patni checking null value Begin             
            } // end if
//          19-05-2006 patni checking null value End            
            rsFormattedRS.setColumnHeading(1, "Select");
            rsFormattedRS.setColumnHeading(2, "Engine Module");
            rsFormattedRS.setColumnHeading(3, "Created By");
            rsFormattedRS.setColumnHeading(4, "Created Date");
            rsFormattedRS.sort(2, true);
            return rsFormattedRS;
        }

        finally
        {

            basePath = "";
            strChkBox = "";
            strEngineModule = "";
            rsFormattedRS = null;
            arrlstTemp = null;
            geAETag = null;

        }

    }
    /**
    * This function is called when action=eCRDModifyModule.
    * Function modifies(updates) name of selected module to new name given  for  a Engine Model code 
    * which is taken from the request .
    */

    private void ModifyModule(HttpServletRequest request) throws Exception
    {

        String strModuleSeqID = "";
        String strEngModuleName = "";
        String strEngModelCode = "";
        String strUserId = "";
        String strModifyModuleMsg = "";
        eCRDUser objeCRDUser = null;
        eCRDDefaultCatalog objeCRDDefaultCatalog = null;
        objeCRDDefaultCatalog = new eCRDDefaultCatalog();
        eCRDModule objeCRDModule = null;
        eCRDEngineModel objeCRDEngineModel = null;

        try
        {

            strModuleSeqID = eCRDUtil.verifyNull(request.getParameter("hdnModSeqID"));
            strEngModelCode = eCRDUtil.verifyNull(request.getParameter("hdnEngModelCode"));
            objeCRDUser = (eCRDUser)eCRDUtil.getFromSessionApp(request, "objeCRDUser");
            objeCRDDefaultCatalog = (eCRDDefaultCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
            if (objeCRDDefaultCatalog == null)
            {
                objeCRDDefaultCatalog = new eCRDDefaultCatalog(strEngModelCode,eCRDConstants.STRENGMODELCONST);//Changed the constructor called to get loaded catalog object

            }
            strEngModuleName = eCRDUtil.verifyNull(request.getParameter("hdnModifyModuleName"));
            objeCRDEngineModel = new eCRDEngineModel(strEngModelCode);
            strUserId = objeCRDUser.getUserId();
            objeCRDModule = objeCRDEngineModel.getModule(strModuleSeqID);
            objeCRDModule.setModuleDesc(strEngModuleName);
            strModifyModuleMsg = objeCRDModule.Update(strUserId);
            request.setAttribute("strMessage", strModifyModuleMsg);
            objeCRDModule.setEngineModel(objeCRDEngineModel);
            objeCRDDefaultCatalog.setEngineModel(objeCRDEngineModel);
            objeCRDEngineModel.setCatalog(objeCRDDefaultCatalog);
            eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDDefaultCatalog);
        }
        finally
        {
            strModuleSeqID = "";
            strEngModuleName = "";
            strEngModelCode = "";
            strUserId = "";
            objeCRDUser = null;
            strModifyModuleMsg = "";
            objeCRDDefaultCatalog = null;
            objeCRDModule = null;
            objeCRDEngineModel = null;

        }

    }
    /**
    * This function is called when action=AddModules.
    * Function creates adds selected modules  to the Engine Model code 
    * .which is taken from the request.
    */
    private void addEngModules(HttpServletRequest request) throws Exception
    {

        String strEngModules = "";
        String strSingleEngModule = "";
        String strEngModelCode = "";
        String strUserId = "";
        String strAddModuleMsg = "";
        eCRDDefaultCatalog objeCRDDefaultCatalog = null;
        eCRDModule objeCRDModule = null;
        eCRDEngineModel objeCRDEngineModel = null;
        eCRDUser objeCRDUser = null;
        try
        {

            objeCRDUser = (eCRDUser)eCRDUtil.getFromSessionApp(request, "objeCRDUser");
            objeCRDDefaultCatalog = (eCRDDefaultCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
			strEngModelCode = eCRDUtil.verifyNull(request.getParameter("hdnEngModelCode"));
            if (objeCRDDefaultCatalog == null)
            {
                objeCRDDefaultCatalog = new eCRDDefaultCatalog(strEngModelCode,eCRDConstants.STRENGMODELCONST);//Changed the constructor called to get loaded catalog object

            }

            
            objeCRDEngineModel = new eCRDEngineModel(strEngModelCode.toUpperCase());

            StringTokenizer stEngModules = null;

            strUserId = objeCRDUser.getUserId();
            strEngModules = eCRDUtil.verifyNull(request.getParameter("hdnSelectedModule"));
            stEngModules = new StringTokenizer(strEngModules, eCRDConstants.STRCOLUMNDELIM);
            while (stEngModules.hasMoreTokens())
            {

                strSingleEngModule = stEngModules.nextToken();
                objeCRDModule = objeCRDEngineModel.addModule();
                objeCRDModule.setModuleDesc(strSingleEngModule);

            }

            strAddModuleMsg = objeCRDEngineModel.saveModule(strUserId);
            request.setAttribute("strMessage", strAddModuleMsg);
            objeCRDModule.setEngineModel(objeCRDEngineModel);
            objeCRDEngineModel.setCatalog(objeCRDDefaultCatalog);
            objeCRDDefaultCatalog.setEngineModel(objeCRDEngineModel);
            eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDDefaultCatalog);
        }
        finally
        {
            strEngModules = "";
            strSingleEngModule = "";
            strEngModelCode = "";
            strUserId = "";
            strAddModuleMsg = "";
            objeCRDDefaultCatalog = null;

            objeCRDModule = null;
            objeCRDEngineModel = null;
            objeCRDUser = null;
        }

    }
    /**
    * This function is called when action=DeleteModules.
    * Function deletes   selected modules  for  a Engine Model code 
    * which is taken from the request .
    */
    private void deleteEngModules(HttpServletRequest request) throws Exception
    {

        String strEngModules = "";
        String strEngModelCode = "";
        String strEngDelModule = "";
        String strDelModuleMsg = "";
        eCRDModule objeCRDModule = null;
        eCRDDefaultCatalog objeCRDDefaultCatalog = null;
        eCRDEngineModel objeCRDEngineModel = null;
        StringTokenizer stEngModules = null;

        try
        {

            objeCRDDefaultCatalog = (eCRDDefaultCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
			strEngModelCode = eCRDUtil.verifyNull(request.getParameter("hdnEngModelCode"));
            if (objeCRDDefaultCatalog == null)
            {
                objeCRDDefaultCatalog = new eCRDDefaultCatalog(strEngModelCode,eCRDConstants.STRENGMODELCONST);//Changed the constructor called to get loaded catalog object

            }

            strEngModules = eCRDUtil.verifyNull(request.getParameter("hdnDelEngModule"));
            
            strEngModelCode = strEngModelCode.toUpperCase();
            stEngModules = new StringTokenizer(strEngModules, eCRDConstants.STRCOLUMNDELIM);

            while (stEngModules.hasMoreTokens())
            {

                strEngDelModule = stEngModules.nextToken();
                objeCRDEngineModel = new eCRDEngineModel(strEngModelCode);
                objeCRDModule = objeCRDEngineModel.getModule(strEngDelModule);
                strDelModuleMsg = objeCRDModule.remove();

            }

            request.setAttribute("strMessage", strDelModuleMsg);
            objeCRDModule.setEngineModel(objeCRDEngineModel);
            objeCRDDefaultCatalog.setEngineModel(objeCRDEngineModel);
            objeCRDEngineModel.setCatalog(objeCRDDefaultCatalog);
            eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDDefaultCatalog);

        }
        finally
        {

            strEngModules = "";
            strEngModelCode = "";
            strDelModuleMsg = "";
            objeCRDModule = null;
            objeCRDDefaultCatalog = null;
            objeCRDEngineModel = null;
        }

    }
    /**
    * This function is called when action=cataloglist.
    * Get the list of default catalogs by hitting the database. Convert it into 
    * string and set it in request.
    */
    private void getDefaultCatalogList(HttpServletRequest request) throws Exception
    {
        eCRDDataBean objeCRDDataBean = null;
        GEAEResultSet rsCatalogList = null;

        try
        {
            objeCRDDataBean = new eCRDDataBean();
            rsCatalogList = (GEAEResultSet)eCRDSearchBean.getEngineModelList();
            if (rsCatalogList != null)
            {
                if (rsCatalogList.size() == 0)
                {
                    request.setAttribute("Display", "N");
                }
                rsCatalogList = getCatalogFormatResultSet(rsCatalogList);
                if (rsCatalogList != null && rsCatalogList.size() > 0)
                {
                    rsCatalogList.setCurrentRow(0);
                    objeCRDDataBean.setCache(rsCatalogList);
                }
                /*else
                {
                	objeCRDDataBean.setCache(new GEAEResultSet());
                }*/
            }
            /*else
            {
            	rsCatalogList = new GEAEResultSet();
            }*/
            eCRDUtil.loadInSession(request, "objeCRDCatalogList", objeCRDDataBean);
        }
        finally
        {
            objeCRDDataBean = null;
            rsCatalogList = null;
        }
    }

    private GEAEResultSet getCatalogFormatResultSet(GEAEResultSet rsCatalogList) throws Exception
    {
        GEAEResultSet rsFormatted = null;
        ArrayList arrlstFormat = null;
        GEAETagNoData tagRadio = null;
        String strRadioValue = null;
        String strTempTagName = null;

        try
        {
            if (rsCatalogList != null && rsCatalogList.size() > 0)
            {
                rsFormatted = new GEAEResultSet();

                while (rsCatalogList.next())
                {
                    arrlstFormat = new ArrayList();
                    strTempTagName = eCRDUtil.replaceQuote(rsCatalogList.getString("ENG_MDL_NUMBER"), "\"");
                    strRadioValue = "" + eCRDUtil.replaceQuoteForJS(strTempTagName);
                    tagRadio = new GEAETagNoData("<INPUT TYPE=\"radio\" NAME=\"radCatalog\" VALUE=\"" + strRadioValue + "\"");
                    arrlstFormat.add(tagRadio);
                    arrlstFormat.add(eCRDUtil.verifyNull(rsCatalogList.getString(1)));

                    rsFormatted.addRow(arrlstFormat);
                }
                rsFormatted.setColumnHeading(1, "Select");
                rsFormatted.setColumnHeading(2, "Engine Model");
            }
            return rsFormatted;
        }
        finally
        {
            arrlstFormat = null;
            tagRadio = null;
            strRadioValue = null;
            strTempTagName = null;

        }

    }

    /**
    * This function is called when action=eCRDCreateModule.
    * Function creates a new module and adds it in the database for a particular Engine Model code 
    * coming from the request.
    */
    private void createNewModule(HttpServletRequest request) throws Exception
    {

        String strEngModuleName = "";
        String strEngModelCode = "";
        String strCreateModuleMsg = "";
        String strUserId = "";
        eCRDUser objeCRDUser = null;
        eCRDDefaultCatalog objeCRDDefaultCatalog = null;
        eCRDModule objeCRDModule = null;
        eCRDEngineModel objeCRDEngineModel = null;

        try
        {
            strEngModelCode = eCRDUtil.verifyNull(request.getParameter("EngModelCode"));
            objeCRDUser = (eCRDUser)eCRDUtil.getFromSessionApp(request, "objeCRDUser");
            objeCRDDefaultCatalog = (eCRDDefaultCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
            if (objeCRDDefaultCatalog == null)
            {
                objeCRDDefaultCatalog = new eCRDDefaultCatalog(strEngModelCode,eCRDConstants.STRENGMODELCONST);//Changed the constructor called to get loaded catalog object

            }

            strEngModelCode = eCRDUtil.verifyNull(request.getParameter("hdnEngModelCode"));
            strEngModuleName = eCRDUtil.verifyNull(request.getParameter("hdnCreateModuleName"));
            objeCRDEngineModel = new eCRDEngineModel(strEngModelCode.toUpperCase());
            strUserId = objeCRDUser.getUserId();
            objeCRDModule = objeCRDEngineModel.addModule();
            objeCRDModule.setModuleDesc(strEngModuleName);
            strCreateModuleMsg = objeCRDEngineModel.saveModule(strUserId);
            request.setAttribute("strMessage", strCreateModuleMsg);
            objeCRDModule.setEngineModel(objeCRDEngineModel);
            objeCRDDefaultCatalog.setEngineModel(objeCRDEngineModel);
            objeCRDEngineModel.setCatalog(objeCRDDefaultCatalog);
            eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDDefaultCatalog);
        }
        finally
        {

            objeCRDUser = null;
            objeCRDDefaultCatalog = null;
            objeCRDModule = null;
            objeCRDEngineModel = null;
            strEngModuleName = "";
            strCreateModuleMsg = "";
            strUserId = "";

        }

    }
    /**
    	   * For executing steps in copying of a default catalog
    	   */
    private boolean copyDefaultCatalog(HttpServletRequest request) throws Exception
    {
        eCRDUser objeCRDUser = null;
        eCRDEngineModel objeCRDEngineModel = null;
        eCRDDefaultCatalog objeCRDDefaultCatalog = null;
        eCRDDefaultCatalog objeCRDCopiedCatalog = null;
        String strUserID = null;
        String strSeqID = null;
        String strCopyEngData = null;
        String strEngCode = null;
        String strEngDesc = null;
        String strStartdate_DD = null;
        String strStartdate_MM = null;
        String strStartdate_YYYY = null;
        String strEnddate_DD = null;
        String strEnddate_MM = null;
        String strEnddate_YYYY = null;
        String strStartDate = null;
        String strEndDate = null;
        String strCatDesc = null;
        
        String strCatInd = null; //changes by vikrant
        
        String strErrMsg = null;
        String strVisibleToCWC = null;
        boolean blncont = true;

        try
        {

            objeCRDEngineModel = new eCRDEngineModel();
            objeCRDDefaultCatalog = new eCRDDefaultCatalog();
            objeCRDCopiedCatalog = new eCRDDefaultCatalog();
            objeCRDUser = (eCRDUser)eCRDUtil.getFromSessionApp(request, "objeCRDUser");

            strCopyEngData = eCRDUtil.verifyNull(request.getParameter("hdnEngData"));
            strEngCode = eCRDUtil.verifyNull(request.getParameter("txtEngCode")).toUpperCase();
            
            strCatInd = eCRDUtil.verifyNull(request.getParameter("catInd"));  //changes by vikrant
            
            strEngDesc = eCRDUtil.verifyNull(request.getParameter("txtEngDesc")).toUpperCase();
            strStartdate_DD = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_DD"));
            strStartdate_MM = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_MM"));
            strStartdate_YYYY = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_YYYY"));
            strEnddate_DD = eCRDUtil.verifyNull(request.getParameter("sel_man_Enddate_DD"));
            strEnddate_MM = eCRDUtil.verifyNull(request.getParameter("sel_man_Enddate_MM"));
            strEnddate_YYYY = eCRDUtil.verifyNull(request.getParameter("sel_man_Enddate_YYYY"));
            strCatDesc = eCRDUtil.verifyNull(request.getParameter("txtCatDesc"));
			strVisibleToCWC = eCRDUtil.verifyNull(request.getParameter("chkVisibleToCWC"));

            strStartDate = eCRDUtil.formatDate(strStartdate_DD, strStartdate_MM, strStartdate_YYYY);
            strEndDate = eCRDUtil.formatDate(strEnddate_DD, strEnddate_MM, strEnddate_YYYY);

            //getting the seg-id of the coping engine model 
            strSeqID = eCRDCatalog.getCurrentDefaultSeqId(strCopyEngData);

            //setting the seqid to the copied object 
            objeCRDCopiedCatalog.setCatalogSeqId(strSeqID);

            //setting the object with respective values
            objeCRDEngineModel.setEngineModelCode(strEngCode);
            objeCRDEngineModel.setEngineModelDesc(strEngDesc);
            objeCRDDefaultCatalog.setCatalogStartDate(strStartDate);
            objeCRDDefaultCatalog.setCatalogEndDate(strEndDate);
            objeCRDDefaultCatalog.setCatalogDesc(strCatDesc);
            
            objeCRDDefaultCatalog.setCatInd(strCatInd);  //changes by vikrant
            
            objeCRDDefaultCatalog.setEngineModel(objeCRDEngineModel);
            objeCRDDefaultCatalog.setCatalogType(eCRDConstants.STRDEFAULTCATALOGTYPE);
            objeCRDDefaultCatalog.setActive(true);
			objeCRDDefaultCatalog.setVisibleToCWC(strVisibleToCWC);
            strUserID = eCRDUtil.verifyNull(objeCRDUser.getUserId());

            //calling the biz method for DB Operation
            blncont = objeCRDDefaultCatalog.copyCatalog((eCRDCatalog)objeCRDCopiedCatalog, strUserID);

            if (blncont == true) //if blncont true then the object is set in the session forwarded to the new jsp. 
            {
                eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDDefaultCatalog);
            }
            else //else displays the error message in the same JSP.
                {
                eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDDefaultCatalog);
                strErrMsg = eCRDConstants.getMessage("eCRD_CATALOG_ALREADY_EXIST");
                request.setAttribute("ErrorMsg", strErrMsg);
            }
        }
        finally
        {

            objeCRDEngineModel = null;
            objeCRDDefaultCatalog = null;
            objeCRDCopiedCatalog = null;
            objeCRDUser = null;
            strUserID = null;
            strSeqID = null;
            strCopyEngData = null;
            strEngCode = null;
            
            strCatInd = null;  //changes by vikrant
            
            strEngDesc = null;
            strStartdate_DD = null;
            strStartdate_MM = null;
            strStartdate_YYYY = null;
            strEnddate_DD = null;
            strEnddate_MM = null;
            strEnddate_YYYY = null;
            strStartDate = null;
            strEndDate = null;
            strCatDesc = null;
            strErrMsg = null;

        }
        return blncont;
    }

    /**
     * This function is called when action=load
     * Get the list of default catalogs by hitting the database. Convert it into 
     * string and set it in request.
     */
    private void LoadDefaultCatalog()
    {

    }

    /**
     * This function is called when action=upload
     * Uploads the passed excel to the database.
     */
    private void uploadCatalog()
    {

    }

    /**
     * This function is called when action=download
     * Downlaods the selected default catalog
     */
    private void downloadCatalog()
    {

    }

    /**
     * This function is called when action=modify
     * Steps to modify the catalog.
     */
    private void modifyCatalog()
    {

    }

}
