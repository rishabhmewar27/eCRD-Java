//Source file: D:\\ECRD\\SOURCE CODE\\ecrd\\helper\\eCRDManageModuleHelper.java
/**
 * Module       : eCRDManageModuleHelper.java
 * Author       : Patni Offshore
 * Project      : eCRD
 * Date Written : October 2004
 * Security     : Classified/Unclassified
 * Restrictions : GE PROPRIETORY INFORMATION, FOR GE USE ONLY
 *
 *     ***************************************************************
 *     *          Copyright (2000) with all rights reserved          *
 *     *                  General Electric Company                   *
 *     ***************************************************************
 * Description  :  This class has methods to get the Master Tables Data.
 * Revision Log  (mm/dd/yyyy     Initials    description)
 * -------------------------------------------------------------------
 * mm/dd/yyyy     Initials     Description
 * -------------------------------------------------------------------
 *
 */
package ecrd.helper;

import javax.servlet.http.HttpServletRequest;

import ecrd.common.eCRDCommand;

/**
 * Helper for managing actions on 'Module'
 */
public class eCRDManageModuleHelper implements eCRDCommand
{
    private HttpServletRequest request = null;

    public eCRDManageModuleHelper()
    {

    }

    /**
     * Based on the "action" passed in request this function redirects request to 
     * appropriate private function from this class.
     * Also sets the received request to member variable.
     * @param request
     */
    public String perform(HttpServletRequest request) throws Exception
    {
        return null;
    }

    /**
     * request : action=create
     * Executes steps to create a module.
     */
    private void createModule()
    {

    }
}
