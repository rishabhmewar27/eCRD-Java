/**
 * Module       : eCRDManageRepairHelper.java
 * Author       : Patni Offshore
 * Project      : eCRD
 * Date Written : October 2004
 * Security     : Classified/Unclassified
 * Restrictions : GE PROPRIETORY INFORMATION, FOR GE USE ONLY
 *
 *     ***************************************************************
 *     *          Copyright (2000) with all rights reserved          *
 *     *                  General Electric Company                   *
 *     ***************************************************************
 * Description  :  This class has methods to get the Master Tables Data.
 * Revision Log  (mm/dd/yyyy     Initials    description)
 * -------------------------------------------------------------------
 * mm/dd/yyyy     Initials     Description
 * -------------------------------------------------------------------
 *31/05/2006 Patni Phase 1 Requirement Updations  
 *28/06/2006 Patni Phase 2 Updated perform()
 *06/09/2006 Patni Phase 3 Updated method formatRepResultSet
 */
package ecrd.helper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.StringTokenizer;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import ecrd.exception.eCRDException;
import ecrd.biz.eCRDCatalog;
import ecrd.biz.eCRDChildRepair;
import ecrd.biz.eCRDComponent;
import ecrd.biz.eCRDCustomerCatalog;
import ecrd.biz.eCRDDefaultCatalog;
import ecrd.biz.eCRDEngineModel;
import ecrd.biz.eCRDGroupedRepair;
import ecrd.biz.eCRDIndRepair;
import ecrd.biz.eCRDModule;
import ecrd.biz.eCRDRepair;
import ecrd.biz.eCRDRepairApproval;
import ecrd.biz.eCRDRepairPricing;
import ecrd.biz.eCRDRepairSite;
import ecrd.biz.eCRDUser;
import ecrd.common.eCRDBusinessBean;
import ecrd.common.eCRDCommand;
import ecrd.common.eCRDDBMediator;
import ecrd.common.eCRDDataBean;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDLoadMaster;
import ecrd.util.eCRDSearchBean;
import ecrd.util.eCRDUtil;
import geae.dao.GEAEResultSet;
import geae.util.format.GEAETag;
import geae.util.format.GEAETagNoData;

/**
 * Helper for managing actions on 'Repair'.
 */
public class eCRDManageRepairHelper implements eCRDCommand
{
    private HttpServletRequest request = null;
    private ServletContext ctxServlet = null;
    public eCRDManageRepairHelper()
    {

    }
    /**
     * Based on the "action" passed in request this function redirects request to
     * appropriate private function from this class.
     * Also sets the received request to member variable.
     * @param request
     */
    public String perform(HttpServletRequest request) throws Exception
    {
        
        String strForwardURL = null;
        String strScreenAction = "";
        String strFrom = "";
        String strMessage = "";
        String strRepairType = null ;

        /* Patni 28-Jun-2006 - To declare the Approval Status Message variable - Begin */
        String strApproveMessage = "";
        /* Patni 28-Jun-2006 - To declare the Approval Status Message variable - End */

        int intcheckIfComponenPresent = 0;

        try
        {
            strScreenAction = eCRDUtil.verifyNull(request.getParameter("hdnScreenAction"));
            
            // When Add Repair link is clicked
            if ((eCRDConstants.getActionId("eCRD_ADD_REPAIR_LINK")).equals(strScreenAction))
            {
                eCRDUtil.clearSession(request);
                showEngineModuleList(request);
                strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-addRepair";
            }
            else if ((eCRDConstants.getActionId("eCRD_FIND_COMP")).equals(strScreenAction))
            {
                getComponentCode(request);
                strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-successRepair";
            }

            //else if((eCRDConstants.getActionId("eCRD_GET_MODULE")).equals(strScreenAction))
            else if ("getModules".equals(strScreenAction))
            {
                strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-addRepair";
            }
            // Checking if component with given details is present in DB
            else if ((eCRDConstants.getActionId("eCRD_ADD_REPAIR_FIND_ACTION")).equals(strScreenAction))
            {
                intcheckIfComponenPresent = showRepairDetails(request);
                if (intcheckIfComponenPresent == -1) // Not Found
                {
                    showEngineModuleList(request);
                    strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-addRepair";
                }
                else // Found
                    {
                    strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-detRepair";
                }
            }
            else if ((eCRDConstants.getActionId("eCRD_MODIFY_REPAIR_ACTION")).equals(strScreenAction))
            {
                modifyRepair(request);
                removeRepairs(request);
                if ("RD_NUMBER_VALIDATION_FAILED".equals(request.getAttribute("strRepairMessage")) 
                        || "REPAIR_DESC_EXISTS".equals(request.getAttribute("strRepairMessage")) 
                        || "REPAIR_DISP_SEQ_EXISTS".equals(request.getAttribute("strRepairMessage")))
                {
                    if("ecrd-c-viewRepairs".equals(eCRDUtil.verifyNull(request.getParameter("hdnContValue")))
                    || "ecrd-c-specialRepair".equals(eCRDUtil.verifyNull(request.getParameter("hdnContValue")))
                    || "ecrd-c-addSpecialRepair".equals(eCRDUtil.verifyNull(request.getParameter("hdnContValue")))      )
                    {
                        
                        strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-addSpecialRepair";
                    }
                    else if(eCRDUtil.verifyNull(request.getParameter("hdnRepairType")).equals(eCRDConstants.STRSPECIALINDIVIDUALREPAIR)
                    ||eCRDUtil.verifyNull(request.getParameter("hdnRepairType")).equals(eCRDConstants.STRSPECIALGROUPREPAIR)
                    ||eCRDUtil.verifyNull(request.getParameter("hdnRepairType")).equals(eCRDConstants.STRMERGEREPAIR)
                    ||eCRDUtil.verifyNull(request.getParameter("hdnRepairType")).equals(eCRDConstants.STRSLITREPAIR))
                    {
                        strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-repairPricing";
                    }
                    else
                    {
                        strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-detRepair";
                    }
                }
                else
                {
                                
                    if("RepairPricing".equals(eCRDUtil.verifyNull((String)request.getAttribute("strFrom"))))
                    {
                        setNewRepairInRequest(request);
                        strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-listRepairs";
                    }
                    else if("ecrd-c-viewRepairs".equals(eCRDUtil.verifyNull(request.getParameter("hdnContValue")))
                            || "ecrd-c-addSpecialRepair".equals(eCRDUtil.verifyNull(request.getParameter("hdnContValue"))))
                    {
                        setSpecialNewRepairInRequest(request);
                        strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-viewRepairs";
                    }
                    else
                    {
                        setNewRepairInRequest(request);
                        strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-modifyRepairDetail";
                    }
                }
            }
            else if ((eCRDConstants.getActionId("eCRD_SHOW_PRICING_INFO_EDITABLE")).equals(strScreenAction))
            {
                String strCheckStatus = eCRDUtil.verifyNull(request.getParameter("hdnPriceOverWriteInd"));
                if("false".equals(strCheckStatus))
                {
                    updatePriceOverWriteInd(request);
                }
                strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-repairPricing";
            }
            else if ((eCRDConstants.getActionId("eCRD_CREATE_IND_REPAIR")).equals(strScreenAction))
            {
                addRemoveSites(request); 
                createIndRepair(request);
                if ("REPAIR_DESC_EXISTS".equals(request.getAttribute("strRepairMessage")) 
                        || "REPAIR_DISP_SEQ_EXISTS".equals(request.getAttribute("strRepairMessage"))
                        || "RD_NUMBER_VALIDATION_FAILED".equals(request.getAttribute("strRepairMessage")))
                {
                    if("ecrd-c-viewRepairs".equals(eCRDUtil.verifyNull(request.getParameter("hdnContValue")))
                            || "ecrd-c-addSpecialRepair".equals(eCRDUtil.verifyNull(request.getParameter("hdnContValue")))
                            )
                    {
                        strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-addSpecialRepair";
                    }
                    else {
                        strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-detRepair";
                    }
                }
                else
                {
                    
                    if("RepairPricing".equals(eCRDUtil.verifyNull((String)request.getAttribute("strFrom"))))
                    {
                        setNewRepairInRequest(request);
                        strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-listRepairs";
                    }
                    else if("ecrd-c-addSpecialRepair".equals(eCRDUtil.verifyNull(request.getParameter("hdnContValue"))))
                    {
                        setSpecialNewRepairInRequest(request);
                        strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-viewRepairs";
                    }
                    else
                    {
                        setNewRepairInRequest(request);
                        strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-modifyRepairDetail";
                    }
                        
                }
            }
            else if ((eCRDConstants.getActionId("eCRD_CREATE_GRP_REPAIR")).equals(strScreenAction))
            {
                addRemoveChildRepair(request);
                addRemoveSites(request);
                createGroupRepair(request);
                
                if ("REPAIR_DESC_EXISTS".equals(request.getAttribute("strRepairMessage")) || "REPAIR_DISP_SEQ_EXISTS".equals(request.getAttribute("strRepairMessage"))
                        || "RD_NUMBER_VALIDATION_FAILED".equals(request.getAttribute("strRepairMessage")))
                {
                    if("ecrd-c-viewRepairs".equals(eCRDUtil.verifyNull(request.getParameter("hdnContValue")))
                            || "ecrd-c-addSpecialRepair".equals(eCRDUtil.verifyNull(request.getParameter("hdnContValue")))
                            )
                    {
                        strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-addSpecialRepair";
                    }
                    else
                        strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-detRepair";
                }
                else
                {
                    
                    if("RepairPricing".equals(eCRDUtil.verifyNull((String)request.getAttribute("strFrom"))))
                    {
                        setNewRepairInRequest(request);
                        strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-listRepairs";
                    }
                    else if("ecrd-c-addSpecialRepair".equals(eCRDUtil.verifyNull(request.getParameter("hdnContValue"))))
                    {
                        setSpecialNewRepairInRequest(request);
                        strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-viewRepairs";
                    }
                    else
                    {
                        setNewRepairInRequest(request);
                        strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-modifyRepairDetail";
                    }
                        
                }
            }
            // To add or remove child repairs
            else if ((eCRDConstants.getActionId("eCRD_ADD_CHILD_REPAIR")).equals(strScreenAction))
            {
                addRemoveChildRepair(request);
                addRemoveSites(request);
                strFrom = (String) eCRDUtil.getFromSession(request, "strFrom");
                if (strFrom.equals("AddComponent") || strFrom.equals("Modify") || strFrom.equals("AddRepair"))
                {
                    strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-detRepair";
                }
                else if (strFrom.equals("Approval"))
                {
                    strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-showNewRepairApprDet";
                }
                else if (strFrom.equals("NewRepairApproval"))
                {
                    strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-showNewRepairApprDet";
                }
                else if (strFrom.equals("RepairPricing"))
                {
                    strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-repairPricing";
                }
                if("ecrd-c-viewRepairs".equals(eCRDUtil.verifyNull(request.getParameter("hdnContValue")))
                || "ecrd-c-addSpecialRepair".equals(eCRDUtil.verifyNull(request.getParameter("hdnContValue")))
                )
                {
                    strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-addSpecialRepair";
                }
            }
            // To add or remove sites
            else if ((eCRDConstants.getActionId("eCRD_ADD_MORE_SITES")).equals(strScreenAction))
            {
                addRemoveSites(request);
                
                strRepairType = eCRDUtil.verifyNull(request.getParameter("hdnRepairType"));
                if (strRepairType.equals(eCRDConstants.STRGROUPREPAIR)
                || strRepairType .equals(eCRDConstants.STRMERGEREPAIR)
                || strRepairType .equals(eCRDConstants.STRSPECIALGROUPREPAIR)
                )
                {
                    addRemoveChildRepair(request);
                }
                strFrom = (String) eCRDUtil.getFromSession(request, "strFrom");
                if( strFrom.equals("AddComponent")  || strFrom.equals("Modify") || strFrom.equals("AddRepair") )
                {
                    strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-detRepair";
                }
                else if( strFrom.equals("MERGE")||strFrom.equals("SPLIT"))
                {
                    strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-splitMergeSave";
                }
                else if (strFrom.equals("Approval"))
                {
                    strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-showNewRepairApprDet";
                }
                else if (strFrom.equals("NewRepairApproval"))
                {
                    strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-showNewRepairApprDet";
                }
                else if (strFrom.equals("RepairPricing"))
                {
                    strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-repairPricing";
                }
                if("ecrd-c-viewRepairs".equals(eCRDUtil.verifyNull(request.getParameter("hdnContValue")))
                        || "ecrd-c-addSpecialRepair".equals(eCRDUtil.verifyNull(request.getParameter("hdnContValue")))
                        )
                {
                    strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-addSpecialRepair";
                }
            }
            else if ((eCRDConstants.getActionId("eCRD_APPROVE_NEW_REPAIR")).equals(strScreenAction))
            {
                // Added check to see if the repair desc and disp seq id is unique
                // after modofication 
                

                /* Patni 28-Jun-2006 - To return the status message after Approval - Begin */
                strApproveMessage = approveNewRepair(request);
                //if("".equals(approveNewRepair(request)))
                if("".equals(strApproveMessage))
                {
                    strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-approveRepair";
                }
                else
                {
                    // Patni 28-Jun-2006 - Approval Status Message is set to the request object
                    request.setAttribute("strMessage", strApproveMessage);

                    strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-showNewRepairApprDet";
                }
                /* Patni 28-Jun-2006 - To return the status message after Approval - End */

            }
            else if ((eCRDConstants.getActionId("eCRD_COMPONENT_TO_REPAIR_LISTING")).equals(strScreenAction))
            {
                getRepairListing(request);
                strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-listRepairs";
            }
            else if ((eCRDConstants.getActionId("eCRD_ADD_REPAIR")).equals(strScreenAction))
            {
                if((eCRDUtil.verifyNull(request.getParameter("hdnClearArrayListFromSession")).equals("Clear")))
                {
                    eCRDUtil.removeFromSession(request,"eCRDRepairSites");
                    eCRDUtil.removeFromSession(request,"eCRDChildRepairArrayList");
                    removeRepairs(request);
                }
                addSpecialRepair(request);
                strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-detRepair";
            }
            /*this is on click of the special repair button in the special repiar tab*/
            else if ((eCRDConstants.getActionId("eCRD_ADD_SPECIAL_REPAIR")).equals(strScreenAction))
            {
                if((eCRDUtil.verifyNull(request.getParameter("hdnClearArrayListFromSession")).equals("Clear")))
                {
                    eCRDUtil.removeFromSession(request,"eCRDRepairSites");
                    eCRDUtil.removeFromSession(request,"eCRDChildRepairArrayList");
                    removeRepairs(request);
                }
                addSpecialRepair(request);
                strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-addSpecialRepair";
            }
            else if ((eCRDConstants.getActionId("eCRD_MODIFY_REPAIR")).equals(strScreenAction))
            {
                setCatalogObject(request, "Modify");
                if ("Approval".equals(eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, "strFrom"))))
                {
                    strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-showNewRepairApprDet";
                }
                else if("ecrd-c-viewRepairs".equals(eCRDUtil.verifyNull(request.getParameter("hdnContValue"))))
                {
                    strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-addSpecialRepair";
                }
                else
                {
                    strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-detRepair";
                }
            }
            else if((eCRDConstants.getActionId("eCRD_MODIFY_SPECIAL_REPAIR")).equals(strScreenAction))
            {
                setCatalogObject(request, "Modify");
                strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-addSpecialRepair";
            }
            else if((eCRDConstants.getActionId("eCRD_DELETE_REPAIR")).equals(strScreenAction))
            {
                strMessage = removeRepair(request);
                if ("".equals(strMessage))
                {
                    request.setAttribute("Message", "DELETE_COMPONENT");
                    strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-deleteComponent";
                }
                else
                {
                    request.setAttribute("Message", strMessage);
                    //strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-Detail";
                    strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-modifyRepairDetail";
                }
                request.setAttribute("strRepairMessage",strMessage);
            }
            // To display table of components which pops up for 'Find' on modify component page
            else if (eCRDConstants.getActionId("eCRD_SAVE_MERGE_REPAIR").equals(strScreenAction))
            {
                createGroupRepair(request);
                if ("REPAIR_DESC_EXISTS".equals(request.getAttribute("strRepairMessage")) 
                        || "REPAIR_DISP_SEQ_EXISTS".equals(request.getAttribute("strRepairMessage"))
                        || "RD_NUMBER_VALIDATION_FAILED".equals(request.getAttribute("strRepairMessage")))
                {
                    strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-splitMergeSave";
                }
                else
                {
                    request.setAttribute("strRepairMessage", "REPAIRS_MERGE_SUCCESSFULLY");
                    strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-mergeSplitRepair";
                }
            }
            else if ((eCRDConstants.getActionId("eCRD_NEW_COMP_REPAIR_DETAILS")).equals(strScreenAction))
            {
                setCatalogObject(request,(String)eCRDUtil.getFromSession(request,"strFrom"));
                strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-showNewRepairApprDet";
            }
            else if (eCRDConstants.getActionId("eCRD_SPLIT_CONTINUE").equals(strScreenAction))
            {
                createIndRepair(request);
                if ("REPAIR_DESC_EXISTS".equals(request.getAttribute("strRepairMessage")) 
                        || "REPAIR_DISP_SEQ_EXISTS".equals(request.getAttribute("strRepairMessage"))
                        || "RD_NUMBER_VALIDATION_FAILED".equals(request.getAttribute("strRepairMessage")))
                {
                    strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-splitMergeSave";
                }
                else
                {
                    eCRDDataBean objeCRDDataBeanSplit = new eCRDDataBean();
                    GEAEResultSet geaeSplitList = eCRDSearchBean.getSplitListing(request);
                    if (!(geaeSplitList != null && geaeSplitList.size() > 0))
                    {
                        geaeSplitList = new GEAEResultSet();
                    }
                    objeCRDDataBeanSplit.setCache(geaeSplitList);
                    eCRDUtil.loadInSession(request, "objeCRDDataBeanSplit", objeCRDDataBeanSplit);
                    strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-splitSaveRepair";
                }

            }
            else if (eCRDConstants.getActionId("eCRD_SAVE_REPAIR").equals(strScreenAction))
            {
                setNewRepairIntoCatalog(request);
                // To check if repair desc and disp seq id is unique
                if ("REPAIR_DESC_EXISTS".equals(request.getAttribute("strRepairMessage")) 
                        || "REPAIR_DISP_SEQ_EXISTS".equals(request.getAttribute("strRepairMessage"))
                        || "RD_NUMBER_VALIDATION_FAILED".equals(request.getAttribute("strRepairMessage")))
                {
                    strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-showNewRepairApprDet";
                }
                else
                {
                    getRepairListingAfterSavingRepair(request);
                    strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-showApprComponentRepairList";
                }
            }
            else if ((eCRDConstants.getActionId("eCRD_REPAIR_PRICING")).equals(strScreenAction))
            {
                setRepairObject(request);
                strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-repairPricing";
            }
            else if ((eCRDConstants.getActionId("eCRD_SAVE_PRICING_INFO")).equals(strScreenAction))
            {
                saveRepairPricingInfo(request, strScreenAction);
                strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-repairPricing";
            }
            //added by RR
            else if(eCRDConstants.getActionId("eCRD_ADD_REPAIR_TO_CSC").equalsIgnoreCase(strScreenAction))
            {
                addRepairtoCSC(request,strScreenAction);
                strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-CompListingAddModifyCSCforRepair";
            }
            
            if ((eCRDConstants.getActionId("eCRD_RD_TABLE")).equals(strScreenAction))
            {
                // To get the list of RD Numbers for the given value of RD Number Search
                getRDList(request, strScreenAction);
                strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-showRDTable";
            }
            
            if ((eCRDConstants.getActionId("eCRD_RD_OVERRIDE")).equals(strScreenAction))
            {
                strForwardURL = eCRDConstants.STRCONTJSP + "ecrd-showRDOverride";
            }
            
            return strForwardURL;
        }
        finally
        {
            strForwardURL = null;
            strScreenAction = "";
            strFrom = "";
            strMessage = "";
            intcheckIfComponenPresent = 0;
        }
    }
    
    
    // Added by Sushant for RD # populate
    /*
     * This method is used to get list of components from the database based
     * on the values of selected engine model,engine module,ATA reference number,
     * component code ,component description
     * @param request
     */
    private void getRDList(HttpServletRequest request, String strAction) throws Exception
    {
        //  To store the resultset of components
        GEAEResultSet rsRDList = null;
        //  To store the formatted resultset
        GEAEResultSet rsFormattedRDList = null;

        eCRDDataBean objeCRDDataBean = null;
        eCRDBusinessBean objeCRDBusinessBean = null;

        //  To store component selected (CODE / DESCRIPTION)
        String strRDNumber = "";
        ArrayList arrlstInParam = null;
        try
        {
            rsFormattedRDList = new GEAEResultSet();

            objeCRDDataBean = new eCRDDataBean();
            objeCRDBusinessBean = new eCRDBusinessBean();

            //  To get the required entries from the JSP
            strRDNumber = eCRDUtil.verifyNull(request.getParameter("hdnRDNumber"));
            arrlstInParam = new ArrayList();
            arrlstInParam.add(strRDNumber);

            //  To get the resultset of RD Number

            rsRDList = objeCRDBusinessBean.populateRDList(strAction, arrlstInParam);

            if (rsRDList.size() > 0)
            {
                rsRDList.setCurrentRow(0);
                rsRDList.next();
                // To format the resultset as per the requirement
                rsFormattedRDList = formatRDList(rsRDList);
            }
            // To set the formatted resultset in the cache
            objeCRDDataBean.setCache(rsFormattedRDList);
            // To save the data bean object in session
            eCRDUtil.loadInSession(request, "objeCRDRDList", objeCRDDataBean);
            eCRDUtil.loadInSession(request, "hdnRDNumber", strRDNumber);
        }
        finally
        {
            strRDNumber = "";
        }
    }
    
    /*
     * This method is used to format the resultset containing list of components
     * @ param  GEAEResultSet,HttpServletRequest
     */
    private GEAEResultSet formatRDList(GEAEResultSet rsRDList) throws Exception
    {
        GEAEResultSet rsFormattedRDList = null;
        GEAETagNoData tagRadio = null;

        ArrayList arrlstFormattedRDList = null;

        String strRadioValue = "";
        String strRDNumber = "";
        try
        {
            if (rsRDList != null && rsRDList.size() > 0)
            {
                rsFormattedRDList = new GEAEResultSet();
                for (int i = 0; i < rsRDList.size(); i++)
                {
                    arrlstFormattedRDList = new ArrayList();
                    strRDNumber = rsRDList.getString(1);
                    strRadioValue = "" + eCRDUtil.replaceQuoteForJS(strRDNumber);
                    tagRadio =
                        new GEAETagNoData(
                            "<INPUT TYPE=\"radio\" NAME=\"radRDNumber\" VALUE=\""
                                + strRadioValue
                                + "\" onClick = \"javascript:fnGetRDNumber('"
                                + rsRDList.getString(1)
                                + "',document.frmRDList)\" ");
                    arrlstFormattedRDList.add(tagRadio);
                    arrlstFormattedRDList.add(eCRDUtil.verifyNull(rsRDList.getString(1)));
                    arrlstFormattedRDList.add(eCRDUtil.verifyNull(rsRDList.getString(2)));
                    rsFormattedRDList.addRow(arrlstFormattedRDList);
                    rsRDList.next();
                }
                rsFormattedRDList.setColumnHeading(1, "Select");
                rsFormattedRDList.setColumnHeading(2, "RD Number");
                rsFormattedRDList.setColumnHeading(3, "Program Title");
            }
        }
        finally
        {
            tagRadio = null;
            strRadioValue = "";
            strRDNumber = "";
            arrlstFormattedRDList = null;
        }
        return rsFormattedRDList;
    }

    
    // End
    
    
    //  Added new

    private void saveRepairPricingInfo(HttpServletRequest request, String strScreenAction) throws Exception
    {
        eCRDCustomerCatalog objeCRDCustomerCatalog = null;
        eCRDEngineModel objeCRDEngineModel = null;
        eCRDModule objeCRDModule = null;
        eCRDComponent objeCRDComponent = null;
        eCRDIndRepair objeCRDIndRepair = null;
        eCRDGroupedRepair objeCRDGroupedRepair = null;
        eCRDRepairPricing objeCRDRepairPricing = null;
        eCRDUser objeCRDUser = null;
        eCRDRepairSite objeCRDSite = null;
        String strEngineModule = "";
        String strCompCode = "";
        String strRepairType = "";
        String strRepairCode = "";
        String strDay = "";
        String strMonth = "";
        String strYear = "";
        String strEngModelCode = "";
        String strMessage = "";
        double dblPrice = 0.0;
        ArrayList arrlstInParam = null;
        ArrayList arrlstSites = null;   
        try
        {
            arrlstInParam = new ArrayList();

            strEngineModule = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE));
            strEngModelCode = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODELCODE));
            strCompCode = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRCOMPONENTCODE));

            objeCRDCustomerCatalog = (eCRDCustomerCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
            objeCRDEngineModel = objeCRDCustomerCatalog.getEngineModel();
            objeCRDEngineModel.setCatalog(objeCRDCustomerCatalog);
            
            objeCRDModule = objeCRDEngineModel.getModule(strEngineModule);
            objeCRDComponent = objeCRDModule.getComponent(strCompCode);

            strRepairType = eCRDUtil.verifyNull(request.getParameter("hdnRepairType"));
            strRepairCode = eCRDUtil.verifyNull(request.getParameter("hdnRepairCode"));

            if (strRepairType.equals(eCRDConstants.STRINDIVIDUALREPAIR)
            ||strRepairType.equals(eCRDConstants.STRSPECIALINDIVIDUALREPAIR)
            ||strRepairType.equals(eCRDConstants.STRSLITREPAIR) )
            {
                objeCRDIndRepair = (eCRDIndRepair) objeCRDComponent.getRepair(
                        strRepairCode, strRepairType);
                objeCRDRepairPricing = objeCRDIndRepair.getObjRepairPricing();
                arrlstSites = objeCRDIndRepair.getRepairSiteList();
            }
            if (strRepairType.equals(eCRDConstants.STRGROUPREPAIR)
            ||strRepairType.equals(eCRDConstants.STRMERGEREPAIR)
            ||strRepairType.equals(eCRDConstants.STRSPECIALGROUPREPAIR))
            {
                objeCRDGroupedRepair = (eCRDGroupedRepair) objeCRDComponent.getRepair(
                        strRepairCode
                        ,strRepairType);
                objeCRDRepairPricing = objeCRDGroupedRepair.getObjRepairPricing();
                arrlstSites = objeCRDGroupedRepair.getRepairSiteList();
            }
            strDay = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_DD1"));
            strMonth = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_MM1"));
            strYear = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_YYYY1"));

            objeCRDRepairPricing.setFlgPriceOverWriteInd(true);

            if (eCRDUtil.verifyNull(request.getParameter("hdnIncrTime")).equals("true"))
            {
                objeCRDRepairPricing.setFlgIncrTAT(true);
            }
            else
            {
                objeCRDRepairPricing.setFlgIncrTAT(false);
            }
            objeCRDRepairPricing.setIntTAT(eCRDUtil.verifyIntObj(request.getParameter("txtTurnAround")));
            if (eCRDUtil.verifyNull(request.getParameter("hdnIncrPrice")).equals("true"))
            {
                objeCRDRepairPricing.setFlgIncrPrice(true);
            }
            else
            {
                objeCRDRepairPricing.setFlgIncrPrice(false);
            }
            if (eCRDUtil.verifyNull(request.getParameter("txtPrice")).equals(""))
            {
                objeCRDRepairPricing.setDblPrice(null);
            }
            else
            {
                objeCRDRepairPricing.setDblPrice(eCRDUtil.verifyDoubleObj(request.getParameter("txtPrice")));
            }
            objeCRDRepairPricing.setStrPriceType(eCRDUtil.verifyNull(request.getParameter("lstPriceType")));
            if (eCRDUtil.verifyNull(request.getParameter("txtFuturePrice")).equals(""))
            {
                objeCRDRepairPricing.setDblFuturePrice(null);
            }
            else
            {
                objeCRDRepairPricing.setDblFuturePrice(eCRDUtil.verifyDoubleObj(request.getParameter("txtFuturePrice")));
            }
            if (eCRDUtil.verifyNull(request.getParameter("txtFutureTAT")).equals(""))
            {
                objeCRDRepairPricing.setIntFutureTAT(null);
            }
            else
            {
                objeCRDRepairPricing.setIntFutureTAT(eCRDUtil.verifyIntObj(request.getParameter("txtFutureTAT")));
            }
            objeCRDRepairPricing.setDtFuturePriceTATEffDt(eCRDUtil.verifyNull(eCRDUtil.formatDate(strDay, strMonth, strYear)));
            for(int i=0;i<arrlstSites.size();i++)
            {
                objeCRDSite=(eCRDRepairSite)arrlstSites.get(i);
                if(objeCRDRepairPricing.getDblPrice()!=null) 
                dblPrice = objeCRDRepairPricing.getDblPrice().doubleValue();
                if(objeCRDRepairPricing.getDblPrice()==null ||dblPrice  ==0)
                {
                    objeCRDSite.setCM(0.0);
                }
                else
                {
                    objeCRDSite.setCM((dblPrice-objeCRDSite.getTotalCost())*100/dblPrice);                  
                }
                if (strRepairType.equals(eCRDConstants.STRINDIVIDUALREPAIR)
                    ||strRepairType.equals(eCRDConstants.STRSPECIALINDIVIDUALREPAIR)
                    ||strRepairType.equals(eCRDConstants.STRSLITREPAIR))
                {
                    objeCRDSite.setECRDIndRepair(objeCRDIndRepair);
                }
                else if(strRepairType.equals(eCRDConstants.STRGROUPREPAIR)
                ||strRepairType.equals(eCRDConstants.STRMERGEREPAIR)
                ||strRepairType.equals(eCRDConstants.STRSPECIALGROUPREPAIR) )
                {
                    objeCRDSite.setECRDGroupedRepair(objeCRDGroupedRepair);
                }
                
                
            }
            arrlstInParam.add(objeCRDCustomerCatalog.getCatalogSeqId());
            // 2
            if (strRepairType.equals(eCRDConstants.STRINDIVIDUALREPAIR)
            ||strRepairType.equals(eCRDConstants.STRSPECIALINDIVIDUALREPAIR)
            ||strRepairType.equals(eCRDConstants.STRSLITREPAIR))
            {
                objeCRDRepairPricing.setObjCRDRepair(objeCRDIndRepair);
                objeCRDIndRepair.setECRDComponent(objeCRDComponent);
                arrlstInParam.add(objeCRDIndRepair.getStrRepairCode());
                
            }
            else if (strRepairType.equals(eCRDConstants.STRGROUPREPAIR)
            ||strRepairType.equals(eCRDConstants.STRMERGEREPAIR)
            ||strRepairType.equals(eCRDConstants.STRSPECIALGROUPREPAIR))
            {
                objeCRDRepairPricing.setObjCRDRepair(objeCRDGroupedRepair);
                objeCRDGroupedRepair.setECRDComponent(objeCRDComponent);
                arrlstInParam.add(objeCRDGroupedRepair.getStrRepairCode());
            }
            objeCRDUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser");
            // 3
            arrlstInParam.add(objeCRDUser.getUserId());
            if (objeCRDRepairPricing.isFlgIncrTAT() == true)
            {
                arrlstInParam.add("Y");
            }
            else
            {
                arrlstInParam.add("N");
            }
            arrlstInParam.add(eCRDUtil.verifyNullReturnObject(objeCRDRepairPricing.getIntTAT()).toString());
            if (objeCRDRepairPricing.isFlgIncrPrice() == true)
            {
                arrlstInParam.add("Y");
            }
            else
            {
                arrlstInParam.add("N");
            }
            arrlstInParam.add(eCRDUtil.verifyNullReturnObject( objeCRDRepairPricing.getDblPrice()).toString());
            arrlstInParam.add(objeCRDRepairPricing.getStrPriceType());
            arrlstInParam.add(eCRDUtil.verifyNullReturnObject( objeCRDRepairPricing.getDblFuturePrice()).toString());
            arrlstInParam.add(eCRDUtil.verifyNullReturnObject(objeCRDRepairPricing.getIntFutureTAT()).toString());
            arrlstInParam.add(objeCRDRepairPricing.getDtFuturePriceTATEffDt());
                
            strMessage = objeCRDRepairPricing.update(strScreenAction, arrlstInParam);
            objeCRDComponent.setModule(objeCRDModule);
            objeCRDModule.setEngineModel(objeCRDEngineModel);
            objeCRDEngineModel.setCatalog(objeCRDCustomerCatalog);
            eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDCustomerCatalog);
            request.setAttribute("strMessage", strMessage);
        }
        finally
        {
            objeCRDCustomerCatalog = null;
            objeCRDEngineModel = null;
            objeCRDModule = null;
            objeCRDComponent = null;
            objeCRDIndRepair = null;
            objeCRDGroupedRepair = null;
            objeCRDRepairPricing = null;
            objeCRDUser = null;

            strEngineModule = null;
            strCompCode = null;
            strRepairType = null;
            strRepairCode = null;
            strDay= null;
            strMonth= null;
            strYear = null;
            strEngModelCode= null;
            strMessage = null;
            arrlstInParam = null;
        }
    }
    //  End Added new

    private void setNewRepairInRequest(HttpServletRequest request) throws Exception
    {

        String strEngineModel = "";
        String strEngineModule = "";
        String strComponentCode = "";
        String strCompType = "";
        String strAction = "";
        String strCatalogId = "";
        eCRDCatalog objeCRDCatalog = null;
        eCRDSearchBean objeCRDSearchBean = null;
        ArrayList arrlstOutParam = null;
        GEAEResultSet rsRepairs = null;
        eCRDUser objeCRDUser = null;
        try
        {
            objeCRDSearchBean = new eCRDSearchBean();
            rsRepairs = new GEAEResultSet();
            objeCRDCatalog = (eCRDCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
            objeCRDUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser");


            strEngineModel = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODELCODE));
            
            strCatalogId = eCRDUtil.verifyNull(objeCRDCatalog.getCatalogSeqId());
            
            if("".equals(strEngineModel))
            {
                strEngineModel = objeCRDCatalog.getEngineModel().getEngineModelCode(); 
            }

            strEngineModule = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE));
            strComponentCode = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRCOMPONENTCODE));
            strCompType = "1";
            strAction = eCRDUtil.verifyNull(eCRDConstants.getActionId("eCRD_REPAIR_LISTING"));

            /*passin null as catalog seq id so that default catalog will be considered by the plsql procedure*/
            arrlstOutParam = objeCRDSearchBean.getRepairListing(strCatalogId, strEngineModel, strEngineModule, strCompType, strComponentCode, strAction,eCRDUtil.verifyNull(objeCRDUser.getRole()));
            rsRepairs = (GEAEResultSet) arrlstOutParam.get(0);
            request.setAttribute("rsRepairs", rsRepairs);
        }
        finally
        {
            strEngineModel= null;
            strEngineModule= null;
            strComponentCode = null;
            strCompType = null;
            strAction = null;
            objeCRDSearchBean = null;
            arrlstOutParam = null;
            rsRepairs = null;
        }
    }

    private void addRemoveSites(HttpServletRequest request) throws Exception
    {
        String strSite[] = null;
        String strMaterialCost[] = null;
        String strLabourHours[] = null;
        String strLocLabourRate[] = null;
        String strTotalCost[] = null;
        String strCM[] = null;
        String strRepairSiteAction = "";
        String strDelSiteCode = "";
        String strSiteCode = "";
        String strSiteDesc = "";
        StringTokenizer stSite = null;

        ArrayList arrlstRepairSites = null;
        int i = 0, intCheckIfToBeDeleted;
        eCRDRepairSite objeCRDRepairSite = null;

        try
        {
            strSite = request.getParameterValues("lstSite");
            strMaterialCost = request.getParameterValues("txtMatCost");
            strLabourHours = request.getParameterValues("txtLabourHrs");
            strLocLabourRate = request.getParameterValues("txtLocLabourRate");
            strTotalCost = request.getParameterValues("txtTotalCost");
            strCM = request.getParameterValues("txtCM");
            strDelSiteCode = eCRDUtil.verifyNull(request.getParameter("hdnDeleteSiteCode"));
            strRepairSiteAction = eCRDUtil.verifyNull(request.getParameter("hdnRepairSiteAction"));
            arrlstRepairSites = new ArrayList();
            for (i = 0; i < strSite.length; i++)
            {
                if (!strSite[i].equals(""))
                {
                    stSite = new StringTokenizer(strSite[i], "^");
                    intCheckIfToBeDeleted = 0;
                    while (stSite.hasMoreTokens())
                    {
                        strSiteCode = stSite.nextToken();
                        stSite.nextToken();
                        strSiteDesc = stSite.nextToken();
                    }
                    if ("DeleteRepairSite".equals(strRepairSiteAction))
                    {
                        if ((strDelSiteCode.equals(strSite[i])))
                        {
                            intCheckIfToBeDeleted = 1;
                        }
                        if("-1".equals(strDelSiteCode))
                        {
                            if(i==strSite.length-1 )
                            {
                                intCheckIfToBeDeleted = 1;
                            }
                        }
                    }
                    if (intCheckIfToBeDeleted == 0)
                    {
                        objeCRDRepairSite = new eCRDRepairSite();
                        objeCRDRepairSite.setSiteCode(strSiteCode);
                        objeCRDRepairSite.setSiteDescription(strSiteDesc);
                        objeCRDRepairSite.setMaterialCost(eCRDUtil.verifyDouble(strMaterialCost[i]));
                        objeCRDRepairSite.setLaborHr(eCRDUtil.verifyDouble(strLabourHours[i]));
                        objeCRDRepairSite.setLocationLaborRate(eCRDUtil.verifyDouble(strLocLabourRate[i]));
                        objeCRDRepairSite.setTotalCost(eCRDUtil.verifyDouble(strTotalCost[i]));
                        if (strCM[i].equals(""))
                        {
                            objeCRDRepairSite.setCM(Double.parseDouble("0"));
                        }
                        else
                        {
                            objeCRDRepairSite.setCM(Double.parseDouble(strCM[i]));
                        }
                        arrlstRepairSites.add(objeCRDRepairSite);
                    }
                }
            }
            eCRDUtil.loadInSession(request, "eCRDRepairSites", arrlstRepairSites);
        }
        finally
        {
            strSite = null;
            strMaterialCost = null;
            strLabourHours = null;
            strLocLabourRate = null;
            strTotalCost = null;
            strCM = null;
            strRepairSiteAction = "";
            strDelSiteCode = "";
            strSiteCode = "";
            strSiteDesc = "";
            stSite = null;
            arrlstRepairSites = null;
            i = 0;
            intCheckIfToBeDeleted = 0;
            objeCRDRepairSite = null;
        }
    }

    private void addRemoveChildRepair(HttpServletRequest request) throws Exception
    {
        String strDispSeq[] = null;
        String strRepairDesc[] = null;
        String strRepairReferenceFormat[] = null;
        String strRepairReference[] = null;
        String strComments[] = null;
        String strChildRepairCode[] = null;

        String strRDNumber[] = null;        
        String strRDOverride[] = null;
        String strRDComments[] = null;
        String strRDAssociation[] = null;
        String strRDCreationDt[] = null;
        String strRDModifiedDt[] = null;
        
        String strChildRepairAction = "";
        String strDelRepairSeqId = null;
        String strDelRepairAction = "";

        ArrayList arrlstChildRepair = null;

        String strDelDisSeq = "";
        int i = 0, intChildToBeDeleted = 0;
        //  String strFrom = "";
        eCRDChildRepair objeCRDChildRepair = null;

        try
        {
            strDispSeq = request.getParameterValues("txtDisplaySequence");
            strRepairDesc = request.getParameterValues("txtRepairDesc");
            strRepairReferenceFormat = request.getParameterValues("lstRepairFormat");
            strRepairReference = request.getParameterValues("txtRepairFormat");
            strComments = request.getParameterValues("txtComments");
            strDelDisSeq = eCRDUtil.verifyNull(request.getParameter("hdnDelDisSeq"));
            strChildRepairAction = eCRDUtil.verifyNull(request.getParameter("hdnChildRepairAction"));
            strChildRepairCode = request.getParameterValues("hdnChildRepairCode");
            strDelRepairSeqId = request.getParameter("hdnChildRepairSeqId");
            strDelRepairAction = request.getParameter("hdnChildRepairAction");
            strRDNumber = request.getParameterValues("txtRDNumber");
            strRDOverride = request.getParameterValues("txtRDOverride");
            strRDComments = request.getParameterValues("txtRDComments");
            strRDAssociation = request.getParameterValues("hdnRDAssociation");
            strRDCreationDt = request.getParameterValues("hdnRDChildCreationDt");
            strRDModifiedDt = request.getParameterValues("hdnRDChildModifiedDt");            
            
            arrlstChildRepair = new ArrayList();
            for (i = 0; i < strDispSeq.length; i++)
            {
                intChildToBeDeleted = 0;
                if (!strDispSeq[i].equals(""))
                {
                    if ("DelChildRepair".equals(strChildRepairAction))
                    {
                        if (Integer.parseInt(strDelDisSeq) == i)
                        {
                            intChildToBeDeleted = 1;
                        }
                        if(Integer.parseInt(strDelDisSeq) == -1 && i==strDispSeq.length-1 )
                        {
                            intChildToBeDeleted = 1;
                        }
                    }
                    if (intChildToBeDeleted == 0)
                    {
                        objeCRDChildRepair = new eCRDChildRepair();
                        if (!("DelChildRepair".equals(strDelRepairAction) && (strDelRepairSeqId.equals(strChildRepairCode[i]))))
                        {
                            objeCRDChildRepair.setStrChildRepairCode(eCRDUtil.verifyNull(strChildRepairCode[i]));
                        }
                        else if ("AddChildRepair".equals(strDelRepairAction))
                        {
                            objeCRDChildRepair.setStrChildRepairCode(eCRDUtil.verifyNull(strChildRepairCode[i]));
                        }

                        objeCRDChildRepair.setRepairSeqNo(strDispSeq[i]);
                        eCRDUtil.replaceString(strRepairDesc[i], "\r\n", " ");
                        objeCRDChildRepair.setStrReapirDesc(strRepairDesc[i]);
                        objeCRDChildRepair.setStrReapairRefFormat(eCRDUtil.verifyNull(eCRDUtil.verifyNull(strRepairReferenceFormat[i])));
                        objeCRDChildRepair.setStrRepairRefNo(eCRDUtil.verifyNull(strRepairReference[i]));
                        eCRDUtil.replaceString(strComments[i], "\r\n", " ");
                        objeCRDChildRepair.setStrComments(eCRDUtil.verifyNull(strComments[i]));
                        // Sushant
                        objeCRDChildRepair.setStrRDNumber(eCRDUtil.verifyNull(strRDNumber[i]));
                        objeCRDChildRepair.setStrReasonRDOverride(eCRDUtil.verifyNull(strRDOverride[i]));            
                        eCRDUtil.replaceString(strRDComments[i], "\r\n", " ");
                        objeCRDChildRepair.setStrRDNumberComment(eCRDUtil.verifyNull(strRDComments[i]));
                        objeCRDChildRepair.setStrRDAssociation(eCRDUtil.verifyNull(strRDAssociation[i]));
                        objeCRDChildRepair.setStrRDCreationDt(eCRDUtil.verifyNull(strRDCreationDt[i]));                        
                        objeCRDChildRepair.setStrRDModifiedDt(eCRDUtil.verifyNull(strRDModifiedDt[i]));
                        arrlstChildRepair.add(objeCRDChildRepair);
                    }
                }
            }
            eCRDUtil.loadInSession(request, "eCRDChildRepairArrayList", arrlstChildRepair);
        }
        finally
        {
            strDispSeq = null;
            strRepairDesc = null;
            strRepairReferenceFormat = null;
            strRepairReference = null;
            strComments = null;
            strChildRepairAction = "";
            arrlstChildRepair = null;
            strDelDisSeq = "";
            i = 0;
            objeCRDChildRepair = null;
        }
    }
    private void showEngineModuleList(HttpServletRequest request) throws Exception
    {
        GEAEResultSet rsEngineModule = null;
        String strEngineModel = "";
        String strModuleDropDown = "";
        String strEngineModule = "";
        try
        {
            strEngineModel = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODELCODE));
    
            if (strEngineModel.equals(""))
            {
                strEngineModel = eCRDUtil.verifyNull(request.getParameter("lstEngineModel"));
    
            }
            strEngineModule = eCRDUtil.verifyNull(request.getParameter("hdnEngineModule"));
            if (!strEngineModel.equals(""))
            {
                //  To select the list of modules depending upon the engine model selected
                rsEngineModule = eCRDLoadMaster.getMasterModuleList(strEngineModel);
                //  To get the list of modules in required format of dropdown list
                strModuleDropDown = eCRDUtil.populateOptions(rsEngineModule, strEngineModule, false);
                request.setAttribute("strModuleDropDown", strModuleDropDown);
                eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODELCODE, strEngineModel);
            }
    
        }
        finally
        {
            rsEngineModule = null;
            strEngineModel = "";
            strModuleDropDown = "";
            strEngineModule = "";
        }
    }

    public void getComponentCode(HttpServletRequest request) throws Exception
    {
        HttpSession session = null;
        //      GEAEResultSet objResultSet = null ;
        eCRDDataBean objeCRDDataBean = null;
        ArrayList arrLstInParam = new ArrayList();
        ArrayList arrLstOutParam = new ArrayList();
        String strScreenAction = "";

        String strComponent = "";
        String strATAno = "";

        String strEngineModel = "";
        String strEngineModule = "";
        String strComponentCode = "";

        try
        {
            strEngineModel = eCRDUtil.verifyNull(request.getParameter("EngineModel"));
            strEngineModule = eCRDUtil.verifyNull(request.getParameter("EngineModule"));
            strComponent = eCRDUtil.verifyNull(request.getParameter("Component"));
            strComponentCode = eCRDUtil.verifyNull(request.getParameter("ComponentCode"));

            strScreenAction = eCRDUtil.verifyNull(request.getParameter("hdnScreenAction"));
            strATAno = "";

            arrLstInParam.add(strEngineModel);
            arrLstInParam.add(strEngineModule);
            arrLstInParam.add(strComponentCode);
            arrLstInParam.add(strComponent);
            arrLstInParam.add(strATAno);

            arrLstOutParam = eCRDDBMediator.doDBOperation(strScreenAction, arrLstInParam);
            GEAEResultSet rsRepair = (GEAEResultSet) arrLstOutParam.get(0);
            rsRepair.setCurrentRow(0);
            rsRepair.next();

            eCRDUtil.loadInSession(request, eCRDConstants.STRCOMPONENTCODE, rsRepair.getString(1));
            eCRDUtil.loadInSession(request, "CompCodeDesc", rsRepair.getString(2));
            session = request.getSession();
            objeCRDDataBean = new eCRDDataBean();
            session.setAttribute("objeCRDCompList", objeCRDDataBean);

            if (rsRepair.size() > 0)
            {
                rsRepair = formatRepair(rsRepair, request);

                if (rsRepair != null && rsRepair.size() > 0)
                {
                    rsRepair.setCurrentRow(0);
                    objeCRDDataBean.setCache(rsRepair);
                }
            }
            else
            {
                objeCRDDataBean.setCache(new GEAEResultSet());
            }
        }
        finally
        {
            session = null;
            //      objResultSet = null;
            objeCRDDataBean = null;
            arrLstInParam = null;
            arrLstOutParam = null;
            strScreenAction = "";
            strEngineModel = "";
            strEngineModule = "";
            strComponentCode = "";
            strComponent = "";
            strATAno = "";
        }
    }

    public boolean chkComponentCode(HttpServletRequest request) throws Exception
    {
        boolean chkCompCode;
        ArrayList arrLstInParamChk = new ArrayList();
        ArrayList arrLstOutParamChk = new ArrayList();
        String strScreenAction = "";
        String strEngineModel = "";
        String strEngineModule = "";
        String strComponentCode = "";
        //          String strComponent = "";
        try
        {
            strScreenAction = eCRDUtil.verifyNull(request.getParameter("hdnScreenAction"));
            strEngineModel = eCRDUtil.verifyNull(request.getParameter("EngineModel"));
            strEngineModule = eCRDUtil.verifyNull(request.getParameter("EngineModule"));
            //      strComponent = eCRDUtil.verifyNull(request.getParameter("Component"));
            strComponentCode = eCRDUtil.verifyNull(request.getParameter("FIND_COMP"));

            arrLstInParamChk.add(strComponentCode);
            arrLstInParamChk.add(strEngineModel);
            arrLstInParamChk.add(strEngineModule);

            arrLstOutParamChk = eCRDDBMediator.doDBOperation(strScreenAction, arrLstInParamChk);
            if ("New Component Code".equals(arrLstOutParamChk.get(0)))
            {
                chkCompCode = false;
            }
            else
            {
                chkCompCode = true;
            }

            eCRDUtil.loadInSession(request, "CompCodeChk", arrLstOutParamChk.get(0));

            //request.setAttribute("CompCodeChk",arrLstOutParamChk.get(0));

        }

        finally
        {
            arrLstInParamChk = null;
            arrLstOutParamChk = null;
            strScreenAction = "";
            strEngineModel = "";
            strEngineModule = "";
            strComponentCode = "";
            //          strComponent = "";
        }
        return chkCompCode;
    }

    /**
        * Executes steps to create a new repair.
     */
    private void createIndRepair(HttpServletRequest request) throws Exception

    {
        eCRDCatalog objeCRDDefaultCatalog = null;
        eCRDEngineModel objeCRDEngineModel = null;
        eCRDModule objeCRDModule = null;
        eCRDComponent objeCRDComponent = null;

        eCRDIndRepair objeCRDIndRepair = null;
        eCRDRepairPricing objeCRDPrice = null;
        eCRDUser objeCRDUser = null;
        eCRDRepair objeCRDRepair = null;

        //String strEngModelCode = "";
        String strRepairSeqId = "";
        String strRepairType = "";
        String strCheckFrom = "";
        String strEngineModule = "";
        String strCompCode = "";
        String strDay = "";
        String strMonth = "";
        String strYear = "";
        String strMessage = "";
        String strComments = "";
        String strDesc = "";
        String strRDNumber = "";
        String strReasonRDOverride = "";
        String strRDNumberComment = "";
        String strRDCreationDt = "";
        String strRDModifiedDt = "";
        String strNPIClassification = "";
        String strAction = "";
        String strFrom = "";
        String strEngineModel ="";
        String strCatSeqId="";
        String strPriceTypeValue ="";
        // Patni 17-May-2006 Begin Repair Effective Date of the Repair should not be updatable.
        String strBlEffDate = "";
        String strEffectiveDate = "";
        // Patni 17-May-2006 Begin Repair Effective Date of the Repair should not be updatable.
        HashMap hmPriceTypes = null;

        boolean blnForAdd = false;
        eCRDSearchBean objeCRDSearchBean = null;

        ArrayList arrlstInParam = null;
        try
        {

            objeCRDSearchBean = new eCRDSearchBean();
            arrlstInParam = new ArrayList();
            hmPriceTypes = new HashMap();
            hmPriceTypes = eCRDConstants.getPriceTypes();

            strEngineModule = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE));
            strCompCode = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRCOMPONENTCODE));
            strDesc = eCRDUtil.verifyNull(request.getParameter("txtRepairDescription"));
            strDesc=eCRDUtil.replaceString(strDesc, "\r\n", " ");
            //RD# by sushant
            strRDNumber = eCRDUtil.verifyNull(request.getParameter("txtRDNumber"));
            strReasonRDOverride = eCRDUtil.verifyNull(request.getParameter("txtRDOverride"));
            strRDNumberComment = eCRDUtil.verifyNull(request.getParameter("txtRDComments"));
            strRDNumberComment=eCRDUtil.replaceString(strRDNumberComment, "\r\n", " ");
            strRDCreationDt = eCRDUtil.verifyNull(request.getParameter("hdnRDCreationDt"));
            strRDModifiedDt = eCRDUtil.verifyNull(request.getParameter("hdnRDModifiedDt"));
            strNPIClassification = eCRDUtil.verifyNull(request.getParameter("selectRprType"));
            //RD# by sushant
            strRepairType = eCRDUtil.verifyNull(request.getParameter("hdnRepairType"));
            strFrom = (String) eCRDUtil.getFromSession(request, "strFrom");
        
            objeCRDDefaultCatalog = (eCRDCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
            
            // Check if Desc Is Unique
            if (strFrom.equals("AddComponent") || strFrom.equals("SPLIT") ||  strFrom.equals("AddRepair"))
            {
                strAction = eCRDConstants.getActionId("eCRD_CHECK_UNIQUE_REPAIRDESC");

                arrlstInParam.add(eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRCOMPONENTCODE)));
                arrlstInParam.add(eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE)));
                arrlstInParam.add(eCRDUtil.verifyNull(strDesc));
                arrlstInParam.add("");
                strMessage = objeCRDSearchBean.checkForUniqueRepairDescOrDispSeq(strAction, arrlstInParam);
                if (strMessage.equals(""))
                {
                    blnForAdd = true;
                }
                else
                {
                    blnForAdd = false;
                    request.setAttribute("strRepairMessage", strMessage);
                }
            }

            if (strFrom.equals("Modify")  || strFrom.equals("Approval")  || strFrom.equals("NewRepairApproval") ||strFrom.equals("RepairPricing"))
            {
            
                strAction = eCRDConstants.getActionId("eCRD_CHECK_UNIQUE_REPAIRDESC");

                arrlstInParam.add(eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRCOMPONENTCODE)));
                arrlstInParam.add(eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE)));
                arrlstInParam.add(eCRDUtil.verifyNull(strDesc));
                arrlstInParam.add(eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRREPAIRSEQID)));
                strMessage = objeCRDSearchBean.checkForUniqueRepairDescOrDispSeq(strAction, arrlstInParam);
                if (strMessage.equals(""))
                {
                    blnForAdd = true;
                }
                else
                {
                    blnForAdd = false;
                    request.setAttribute("strRepairMessage", strMessage);
                }
            }

            if (strMessage.equals(""))
            {
                if (strFrom.equals("AddComponent") || strFrom.equals("SPLIT") ||  strFrom.equals("AddRepair"))
                {
                    strAction = eCRDConstants.getActionId("eCRD_CHECK_UNIQUE_REPAIRDISP_SEQ");
                    arrlstInParam.clear();

                    strEngineModel =(String)objeCRDDefaultCatalog.getEngineModel().getEngineModelCode();
                    
                    strCatSeqId = eCRDUtil.verifyNull(objeCRDDefaultCatalog.getCatalogSeqId());
                    if("".equals(strCatSeqId))
                    {
                        strCatSeqId=eCRDCatalog.getCurrentDefaultSeqId(eCRDUtil.verifyNull(strEngineModel));
                    }
                    
                    arrlstInParam.add(strCatSeqId);
                    arrlstInParam.add(eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRCOMPONENTCODE)));
                    arrlstInParam.add(eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE)));
                    arrlstInParam.add(eCRDUtil.verifyNull(request.getParameter("txtDisplaySeq")));
                    arrlstInParam.add("");
                    strMessage = objeCRDSearchBean.checkForUniqueRepairDescOrDispSeq(strAction, arrlstInParam);
                }

                if (strFrom.equals("Modify") || strFrom.equals("Approval")  || strFrom.equals("NewRepairApproval") || strFrom.equals("RepairPricing"))
                {
                    strAction = eCRDConstants.getActionId("eCRD_CHECK_UNIQUE_REPAIRDISP_SEQ");
                    arrlstInParam.clear();

                    strEngineModel =(String)objeCRDDefaultCatalog.getEngineModel().getEngineModelCode();
                    
                    strCatSeqId = eCRDUtil.verifyNull(objeCRDDefaultCatalog.getCatalogSeqId());
                    if("".equals(strCatSeqId))
                    {
                        strCatSeqId=eCRDCatalog.getCurrentDefaultSeqId(eCRDUtil.verifyNull(strEngineModel));
                    }
//                  strCatSeqId=eCRDCatalog.getCurrentDefaultSeqId(eCRDUtil.verifyNull(strEngineModel));
                    arrlstInParam.add(strCatSeqId);
                    arrlstInParam.add(eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRCOMPONENTCODE)));
                    arrlstInParam.add(eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE)));
                    arrlstInParam.add(eCRDUtil.verifyNull(request.getParameter("txtDisplaySeq")));
                    arrlstInParam.add(eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRREPAIRSEQID)));
                    strMessage = objeCRDSearchBean.checkForUniqueRepairDescOrDispSeq(strAction, arrlstInParam);
                }

                if (strMessage.equals(""))
                {
                    blnForAdd = true;
                }
                else
                {
                    blnForAdd = false;
                    request.setAttribute("strRepairMessage", strMessage);
                }
            }
            else
            {
                blnForAdd = false;
                request.setAttribute("strRepairMessage", strMessage);
            }

            if (blnForAdd || ((!strFrom.equalsIgnoreCase("AddComponent")) && (!strFrom.equalsIgnoreCase("AddRepair"))))
            {

                /*if (objeCRDDefaultCatalog == null)
                {
                    objeCRDDefaultCatalog = new eCRDDefaultCatalog();
                }*/

                objeCRDEngineModel = objeCRDDefaultCatalog.getEngineModel();
                objeCRDModule = objeCRDEngineModel.getModule(strEngineModule);
                objeCRDComponent = objeCRDModule.getComponent(strCompCode);
                if (strFrom.equals("AddComponent") || strFrom.equals("AddRepair"))
                {
                    if(strRepairType.equals("IR"))
                    {
                        objeCRDIndRepair = (eCRDIndRepair) objeCRDComponent.addRepair(eCRDConstants.STRINDIVIDUALREPAIR);
                    }
                    if(strRepairType.equals("SI"))
                    {
                        objeCRDIndRepair = (eCRDIndRepair) objeCRDComponent.addRepair(eCRDConstants.STRSPECIALINDIVIDUALREPAIR);
                    }
                }
                else if (strFrom.equals("ShowApprvoalNewRepairs"))
                {
                    strRepairSeqId = (String) eCRDUtil.getFromSession(request, eCRDConstants.STRREPAIRSEQID);
                    objeCRDIndRepair = (eCRDIndRepair) objeCRDComponent.getRepair(strRepairSeqId, eCRDConstants.STRINDIVIDUALREPAIR);
                }
                else
                {
                    strRepairSeqId = (String) eCRDUtil.getFromSession(request, eCRDConstants.STRREPAIRSEQID);
                    strRepairType = (String) eCRDUtil.getFromSession(request, "strRepairType");

                    objeCRDRepair = objeCRDComponent.getRepair(strRepairSeqId, strRepairType);
                    objeCRDIndRepair = (eCRDIndRepair) objeCRDRepair;
                }

                /* Patni 17-May-2006 Begin Repair Effective Date of the Repair should not be updatable.*/
                strBlEffDate = eCRDUtil.verifyNull(request.getParameter("hdnBoolEffDate"));
                strEffectiveDate = eCRDUtil.verifyNull(request.getParameter("hdnRepairDate"));
                if(strBlEffDate.equals("true"))
                {
                  strDay = eCRDUtil.getDay(strEffectiveDate);
                  strMonth =eCRDUtil.getMonth(strEffectiveDate);
                  strYear=eCRDUtil.getYear(strEffectiveDate);
                }
               else
              {
                strDay = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_DD"));
                strMonth = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_MM"));
                strYear = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_YYYY"));
              }
                /* Patni 17-May-2006 End Repair Effective Date of the Repair should not be updatable.*/
                objeCRDIndRepair.setStrRepairDesc(strDesc);
                objeCRDIndRepair.setStrRapairVolume(eCRDUtil.verifyNull(request.getParameter("txtRepairVolume")));
                objeCRDIndRepair.setRepairRefFormat(eCRDUtil.verifyNull(request.getParameter("lstRepairReference")));
                objeCRDIndRepair.setRepairRefNo(eCRDUtil.verifyNull(request.getParameter("txtRepairReference")));

                //objeCRDIndRepair.setMergeSplitSeqId(eCRDUtil.verifyNull(request.getParameter("hdnMergeSplitSeqIdInd")));

                objeCRDIndRepair.setDtRepairEffDate(eCRDUtil.verifyNull(eCRDUtil.formatDate(strDay, strMonth, strYear)));
                strComments = eCRDUtil.verifyNull(request.getParameter("txtRepairComments"));
                strComments = eCRDUtil.replaceString(strComments, "\r\n", " ");
                objeCRDIndRepair.setStrComments(strComments);
                
                //RD# setters by sushant
                objeCRDIndRepair.setStrRDNumber(strRDNumber);
                objeCRDIndRepair.setStrReasonRDOverride(strReasonRDOverride);
                objeCRDIndRepair.setStrRDNumberComment(strRDNumberComment);
                objeCRDIndRepair.setStrRDAssociation(""); // This Value is not Required for Individual Repair
                objeCRDIndRepair.setStrRDCreationDt(strRDCreationDt);
                objeCRDIndRepair.setStrRDModifiedDt(strRDModifiedDt);
                objeCRDIndRepair.setStrNPIClassification(strNPIClassification);
                //RD# setters by sushant
                
                objeCRDPrice = objeCRDIndRepair.addRepairPricing();

                strDay = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_DD1"));
                strMonth = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_MM1"));
                strYear = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_YYYY1"));

                if (eCRDUtil.verifyNull(request.getParameter("txtFuturePrice")).equals(""))
                {
                    objeCRDPrice.setDblFuturePrice(null);
                }
                else
                {
                    objeCRDPrice.setDblFuturePrice(eCRDUtil.verifyDoubleObj(request.getParameter("txtFuturePrice")));
                }
                if (eCRDUtil.verifyNull(request.getParameter("txtPrice")).equals(""))
                {
                    objeCRDPrice.setDblPrice(null);
                }
                else
                {
                    objeCRDPrice.setDblPrice(eCRDUtil.verifyDoubleObj(request.getParameter("txtPrice")));
                }
                objeCRDPrice.setDtFuturePriceTATEffDt(eCRDUtil.verifyNull(eCRDUtil.formatDate(strDay, strMonth, strYear)));

                strPriceTypeValue = eCRDUtil.verifyNull(request.getParameter("lstPriceType"));
                strPriceTypeValue = (String) hmPriceTypes.get(strPriceTypeValue);
                objeCRDPrice.setStrPriceType(strPriceTypeValue);

                objeCRDPrice.setIntTAT(eCRDUtil.verifyIntObj(request.getParameter("txtTurnAround")));

                if (eCRDUtil.verifyNull(request.getParameter("txtFutureTAT")).equals(""))
                {
                    objeCRDPrice.setIntFutureTAT(null);
                }
                else
                {
                    objeCRDPrice.setIntFutureTAT(eCRDUtil.verifyIntObj(request.getParameter("txtFutureTAT")));
                }

                objeCRDPrice.setRepairSeqNo(eCRDUtil.verifyNull(request.getParameter("txtDisplaySeq")));

                if (eCRDUtil.verifyNull(request.getParameter("hdnIncrTime")).equals("true"))
                {
                    objeCRDPrice.setFlgIncrTAT(true);
                }
                else
                {
                    objeCRDPrice.setFlgIncrTAT(false);
                }
                // For PriceOverWriteIndicator
                if (eCRDUtil.verifyNull(request.getParameter("hdnPriceOverWriteInd")).equals("true"))
                {
                    objeCRDPrice.setFlgPriceOverWriteInd(true);
                }
                else
                {
                    objeCRDPrice.setFlgPriceOverWriteInd(false);
                }

                if (eCRDUtil.verifyNull(request.getParameter("hdnIncrPrice")).equals("true"))
                {
                    objeCRDPrice.setFlgIncrPrice(true);
                }
                else
                {
                    objeCRDPrice.setFlgIncrPrice(false);
                }

                createSite(request, objeCRDIndRepair);
                objeCRDPrice.setObjCRDRepair(objeCRDIndRepair);
                objeCRDComponent.setModule(objeCRDModule);
                objeCRDModule.setEngineModel(objeCRDEngineModel);
                objeCRDEngineModel.setCatalog(objeCRDDefaultCatalog);
                objeCRDDefaultCatalog.setEngineModel(objeCRDEngineModel);
                eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDDefaultCatalog);
                //
                strCheckFrom = eCRDUtil.verifyNull(request.getParameter("hdnFrom"));
                objeCRDUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser");
                if (strCheckFrom.equals("AddRepair"))
                {
                    if(strRepairType.equals(eCRDConstants.STRSPECIALINDIVIDUALREPAIR))
                    {
                        strMessage = objeCRDComponent.createRepair(request, objeCRDUser.getUserId(), objeCRDUser.getRole(), eCRDConstants.STRSPECIALINDIVIDUALREPAIR, "", "SI");
                    }
                    if(strRepairType.equals(eCRDConstants.STRINDIVIDUALREPAIR))
                    {
                        strMessage = objeCRDComponent.createRepair(request, objeCRDUser.getUserId(), objeCRDUser.getRole(), eCRDConstants.STRINDIVIDUALREPAIR, "", "");
                    }
                }

                if (strCheckFrom.equals("AddComponent") && !"RD_NUMBER_VALIDATION_FAILED".equals(strMessage))
                {
                    strMessage = objeCRDComponent.create(objeCRDUser.getUserId(), objeCRDUser.getRole());
                }
                objeCRDComponent.setModule(objeCRDModule);
                objeCRDModule.setEngineModel(objeCRDEngineModel);
                objeCRDEngineModel.setCatalog(objeCRDDefaultCatalog);
                objeCRDDefaultCatalog.setEngineModel(objeCRDEngineModel);
                eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDDefaultCatalog);
                
                request.setAttribute("strRepairMessage", strMessage);
                if ("SPLIT".equals(strCheckFrom))
                {
                    eCRDUtil.loadInSession(request, "strFrom", "SPLIT");
                }
                else if("Approval".equals(strFrom))
                {
                    eCRDUtil.loadInSession(request, "strFrom", "Approval");
                }
                else if("NewRepairApproval".equals(strFrom))
                {
                    eCRDUtil.loadInSession(request, "strFrom", "NewRepairApproval");
                }
                else if("RepairPricing".equals(strFrom))
                {
                    eCRDUtil.loadInSession(request, "strFrom", "RepairPricing");
                    request.setAttribute("strFrom","RepairPricing");
                } 
                else if (!"RD_NUMBER_VALIDATION_FAILED".equals(strMessage))
                {
                    eCRDUtil.loadInSession(request, "strFrom", "Modify");
                }
            }
        }
        finally
        {
            objeCRDDefaultCatalog = null;
            objeCRDEngineModel = null;
            objeCRDModule = null;
            objeCRDComponent = null;
            objeCRDIndRepair = null;
            objeCRDPrice = null;
            strEngineModule = "";
            strCompCode = "";
            strDay = "";
            strMonth = "";
            strYear = "";
        }
    }

    private void createGroupRepair(HttpServletRequest request) throws Exception
    {
        eCRDCatalog objeCRDDefaultCatalog = null;
        eCRDGroupedRepair objeCRDGroupedRepair = null;
        eCRDEngineModel objeCRDEngineModel = null;
        eCRDModule objeCRDModule = null;
        eCRDComponent objeCRDComponent = null;
        eCRDRepairSite objeCRDRepairSite = null;
        eCRDRepairPricing objeCRDPrice = null;
        eCRDUser objeCRDUser = null;
        eCRDSearchBean objeCRDSearchBean = null;
        eCRDRepair objeCRDRepair = null;

        String strRepairSeqId = "";
        String strRepairType = "";
        String strPriceTypeValue = "";
        String strEngineModel ="";

        String strEngineModule = "";
        String strCompCode = "";
        String strDay = "";
        String strMonth = "";
        String strCheckFrom = "";
        String strYear = "";
        String strMessage = "";
        String strComments = "";
        String strNPIClassification = "";
        String strDesc = "";
        String strAction = "";
        String strFrom = "";
        String strCatSeqId  ="";
        String strDelRepairs = null;
        ArrayList arrlstInParam = null;
        ArrayList arrChildRepairlst = null;
        // Patni 17-May-2006 Begin Repair Effective Date of the Repair should not be updatable.
        String strBlEffDate = "";
        String strEffectiveDate = "";
        // Patni 17-May-2006 Begin Repair Effective Date of the Repair should not be updatable.
        
        HashMap hmPriceTypes = null;

        boolean blnForAdd = false;
        String strEngModelCode="";

        try
        {
            hmPriceTypes = new HashMap();
            hmPriceTypes = eCRDConstants.getPriceTypes();
            arrlstInParam = new ArrayList();
            objeCRDSearchBean = new eCRDSearchBean();
            strEngineModule = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE));
            strCompCode = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRCOMPONENTCODE));
            strFrom = (String) eCRDUtil.getFromSession(request, "strFrom");
            strDesc = eCRDUtil.verifyNull(request.getParameter("txtRepairDescription"));
            strDesc=eCRDUtil.replaceString(strDesc, "\r\n", " ");
            strRepairType = eCRDUtil.verifyNull(request.getParameter("hdnRepairType"));
            strNPIClassification = eCRDUtil.verifyNull(request.getParameter("selectRprType"));
            objeCRDDefaultCatalog = (eCRDCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
            
            // Check if Desc Is Unique
            if (strFrom.equals("AddRepair") || strFrom.equals("MERGE") || strFrom.equals("AddComponent"))
            {
                strAction = eCRDConstants.getActionId("eCRD_CHECK_UNIQUE_REPAIRDESC");

                arrlstInParam.add(eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRCOMPONENTCODE)));
                arrlstInParam.add(eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE)));
                arrlstInParam.add(eCRDUtil.verifyNull(strDesc));
                arrlstInParam.add("");
                strMessage = objeCRDSearchBean.checkForUniqueRepairDescOrDispSeq(strAction, arrlstInParam);

                if (strMessage.equals(""))
                {
                    blnForAdd = true;
                }
                else
                {
                    blnForAdd = false;
                    request.setAttribute("strRepairMessage", strMessage);
                }

            }
            if (strFrom.equals("Modify")  || strFrom.equals("Approval")  || strFrom.equals("NewRepairApproval") ||strFrom.equals("RepairPricing"))
            {
                strAction = eCRDConstants.getActionId("eCRD_CHECK_UNIQUE_REPAIRDESC");

                arrlstInParam.add(eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRCOMPONENTCODE)));
                arrlstInParam.add(eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE)));
                arrlstInParam.add(eCRDUtil.verifyNull(strDesc));
                arrlstInParam.add(eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRREPAIRSEQID)));

                strMessage = objeCRDSearchBean.checkForUniqueRepairDescOrDispSeq(strAction, arrlstInParam);
                
                if (strMessage.equals(""))
                {
                    blnForAdd = true;
                }
                else
                {
                    blnForAdd = false;
                    request.setAttribute("strRepairMessage", strMessage);
                }
            }

            if ("".equals(strMessage))
            {
                if (strFrom.equals("AddRepair") || strFrom.equals("MERGE") || strFrom.equals("AddComponent"))
                {
                    strAction = eCRDConstants.getActionId("eCRD_CHECK_UNIQUE_REPAIRDISP_SEQ");
                    arrlstInParam.clear();
    
                    strEngineModel =(String)objeCRDDefaultCatalog.getEngineModel().getEngineModelCode();
                    
                    strCatSeqId = eCRDUtil.verifyNull(objeCRDDefaultCatalog.getCatalogSeqId());
                    if("".equals(strCatSeqId))
                    {
                        strCatSeqId=eCRDCatalog.getCurrentDefaultSeqId(eCRDUtil.verifyNull(strEngineModel));
                    }

//                  strCatSeqId=eCRDCatalog.getCurrentDefaultSeqId(eCRDUtil.verifyNull(strEngineModel));
    
                    arrlstInParam.add(strCatSeqId);
                    arrlstInParam.add(eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRCOMPONENTCODE)));
                    arrlstInParam.add(eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE)));
                    arrlstInParam.add(eCRDUtil.verifyNull(request.getParameter("txtDisplaySeq")));
                    arrlstInParam.add("");
                    strMessage = objeCRDSearchBean.checkForUniqueRepairDescOrDispSeq(strAction, arrlstInParam);

                }

                if (strFrom.equals("Modify")  || strFrom.equals("Approval")  || strFrom.equals("NewRepairApproval") ||strFrom.equals("RepairPricing"))
                {
                    strAction = eCRDConstants.getActionId("eCRD_CHECK_UNIQUE_REPAIRDISP_SEQ");
                    arrlstInParam.clear();

                    strEngineModel =(String)objeCRDDefaultCatalog.getEngineModel().getEngineModelCode();
                    
                    
                    strCatSeqId = eCRDUtil.verifyNull(objeCRDDefaultCatalog.getCatalogSeqId());
                    if("".equals(strCatSeqId))
                    {
                        strCatSeqId=eCRDCatalog.getCurrentDefaultSeqId(eCRDUtil.verifyNull(strEngineModel));
                    }

//                  strCatSeqId=(String)eCRDCatalog.getCurrentDefaultSeqId(strEngineModel);
                
                    arrlstInParam.add(strCatSeqId );
                    arrlstInParam.add(eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRCOMPONENTCODE)));
                    arrlstInParam.add(eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE)));
                    arrlstInParam.add(eCRDUtil.verifyNull(request.getParameter("txtDisplaySeq")));
                    arrlstInParam.add(eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRREPAIRSEQID)));
                    strMessage = objeCRDSearchBean.checkForUniqueRepairDescOrDispSeq(strAction, arrlstInParam);
                }
                if ("".equals(strMessage))
                {
                    blnForAdd = true;
                }
                else
                {
                    blnForAdd = false;
                    request.setAttribute("strRepairMessage", strMessage);
                }
            }
            else
            {
                blnForAdd = false;
                request.setAttribute("strRepairMessage", strMessage);
            }
            if (blnForAdd || ((!strFrom.equalsIgnoreCase("AddRepair")) && (!strFrom.equalsIgnoreCase("AddComponent"))))
            //if (blnForAdd)
            {

                /*if (objeCRDDefaultCatalog == null)
                {
                    objeCRDDefaultCatalog = new eCRDDefaultCatalog();
                }*/

                objeCRDEngineModel = objeCRDDefaultCatalog.getEngineModel();
                objeCRDEngineModel.setCatalog(objeCRDDefaultCatalog);
                objeCRDModule = objeCRDEngineModel.getModule(strEngineModule);
                objeCRDComponent = objeCRDModule.getComponent(strCompCode);

                if (strFrom.equals("AddRepair") || strFrom.equals("AddComponent"))
                {
                    if(strRepairType.equals(eCRDConstants.STRGROUPREPAIR))
                    {       
                        objeCRDGroupedRepair = (eCRDGroupedRepair) objeCRDComponent.addRepair(eCRDConstants.STRGROUPREPAIR);
                    }
                    if(strRepairType.equals(eCRDConstants.STRSPECIALGROUPREPAIR))
                    {       
                        objeCRDGroupedRepair = (eCRDGroupedRepair) objeCRDComponent.addRepair(eCRDConstants.STRSPECIALGROUPREPAIR);
                    }
                }

                else if (strFrom.equals("ShowApprvoalNewRepairs"))
                {
                    strRepairSeqId = (String) eCRDUtil.getFromSession(request, eCRDConstants.STRREPAIRSEQID);
                    objeCRDGroupedRepair = (eCRDGroupedRepair) objeCRDComponent.getRepair(strRepairSeqId, eCRDConstants.STRGROUPREPAIR);
                }
                else
                {
                    strRepairSeqId = (String) eCRDUtil.getFromSession(request, eCRDConstants.STRREPAIRSEQID);
                    strRepairType = (String) eCRDUtil.getFromSession(request, "strRepairType");

                    objeCRDRepair = objeCRDComponent.getRepair(strRepairSeqId, strRepairType);
                    objeCRDGroupedRepair = (eCRDGroupedRepair) objeCRDRepair;
                }


                /* Patni 17-May-2006 Begin Repair Effective Date of the Repair should not be updatable.*/
                strBlEffDate = eCRDUtil.verifyNull(request.getParameter("hdnBoolEffDate"));
                strEffectiveDate = eCRDUtil.verifyNull(request.getParameter("hdnRepairDate"));
                if(strBlEffDate.equals("true"))
                {
                  strDay = eCRDUtil.getDay(strEffectiveDate);
                  strMonth =eCRDUtil.getMonth(strEffectiveDate);
                  strYear=eCRDUtil.getYear(strEffectiveDate);
                }
              else
              {
                strDay = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_DD"));
                strMonth = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_MM"));
                strYear = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_YYYY"));
              }
                /* Patni 17-May-2006 Begin Repair Effective Date of the Repair should not be updatable.*/

                objeCRDGroupedRepair.setStrRepairDesc(strDesc);
                objeCRDGroupedRepair.setStrRapairVolume(eCRDUtil.verifyNull(request.getParameter("txtRepairVolume")));
                objeCRDGroupedRepair.setDtRepairEffDate(eCRDUtil.verifyNull(eCRDUtil.formatDate(strDay, strMonth, strYear)));
                strComments = eCRDUtil.verifyNull(request.getParameter("txtRepairComments"));
                strComments = eCRDUtil.replaceString(strComments, "\r\n", " ");
                objeCRDGroupedRepair.setStrComments(strComments);
                objeCRDGroupedRepair.setStrNPIClassification(strNPIClassification);

                objeCRDPrice = objeCRDGroupedRepair.addRepairPricing();
                strDay = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_DD1"));
                strMonth = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_MM1"));
                strYear = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_YYYY1"));

                if (eCRDUtil.verifyNull(request.getParameter("txtFuturePrice")).equals(""))
                {
                    objeCRDPrice.setDblFuturePrice(null);
                }
                else
                {
                    objeCRDPrice.setDblFuturePrice(eCRDUtil.verifyDoubleObj(request.getParameter("txtFuturePrice")));
                }
                if (eCRDUtil.verifyNull(request.getParameter("txtPrice")).equals(""))
                {
                    objeCRDPrice.setDblPrice(null);
                }
                else
                {
                    objeCRDPrice.setDblPrice(eCRDUtil.verifyDoubleObj(request.getParameter("txtPrice")));
                }
                objeCRDPrice.setDtFuturePriceTATEffDt(eCRDUtil.verifyNull(eCRDUtil.formatDate(strDay, strMonth, strYear)));
                strPriceTypeValue = eCRDUtil.verifyNull(request.getParameter("lstPriceType"));
                strPriceTypeValue = (String) hmPriceTypes.get(strPriceTypeValue);
                objeCRDPrice.setStrPriceType(strPriceTypeValue);
                objeCRDPrice.setIntTAT(eCRDUtil.verifyIntObj(request.getParameter("txtTurnAround")));
                if (eCRDUtil.verifyNull(request.getParameter("txtFutureTAT")).equals(""))
                {
                    objeCRDPrice.setIntFutureTAT(null);
                }
                else
                {
                    objeCRDPrice.setIntFutureTAT(eCRDUtil.verifyIntObj(request.getParameter("txtFutureTAT")));
                }

                objeCRDPrice.setRepairSeqNo(eCRDUtil.verifyNull(request.getParameter("txtDisplaySeq")));
                if (eCRDUtil.verifyNull(request.getParameter("hdnIncrTime")).equals("true"))
                {
                    objeCRDPrice.setFlgIncrTAT(true);
                }
                else
                {
                    objeCRDPrice.setFlgIncrTAT(false);
                }
                if (eCRDUtil.verifyNull(request.getParameter("hdnIncrPrice")).equals("true"))
                {
                    objeCRDPrice.setFlgIncrPrice(true);
                }
                else
                {
                    objeCRDPrice.setFlgIncrPrice(false);
                }
                
                objeCRDRepairSite = createSiteForGroupRepair(request, objeCRDGroupedRepair);

                // Code to add child repairs
                

                createChildRepair(request, objeCRDGroupedRepair);
                
                objeCRDRepairSite.setECRDGroupedRepair(objeCRDGroupedRepair);
                objeCRDPrice.setObjCRDRepair(objeCRDGroupedRepair);
                objeCRDComponent.setModule(objeCRDModule);
                objeCRDModule.setEngineModel(objeCRDEngineModel);
                objeCRDEngineModel.setCatalog(objeCRDDefaultCatalog);
                objeCRDDefaultCatalog.setEngineModel(objeCRDEngineModel);
                eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDDefaultCatalog);

                strCheckFrom = eCRDUtil.verifyNull(request.getParameter("hdnFrom"));
                strCheckFrom = strCheckFrom.trim();
                objeCRDUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser");
                
                if (strCheckFrom.equals("AddRepair"))
                {
                    if(strRepairType.equals(eCRDConstants.STRSPECIALGROUPREPAIR))
                    {
                        strMessage = objeCRDComponent.createRepair(request, objeCRDUser.getUserId(), objeCRDUser.getRole(), "", eCRDConstants.STRSPECIALGROUPREPAIR, "SG");
                    }
                    if(strRepairType.equals(eCRDConstants.STRGROUPREPAIR))
                    {
                        strMessage = objeCRDComponent.createRepair(request, objeCRDUser.getUserId(), objeCRDUser.getRole(), "", eCRDConstants.STRGROUPREPAIR, "");
                    }
                }
                else if (strCheckFrom.equalsIgnoreCase("MERGE")  && blnForAdd)
                {
                    strDelRepairs = (String) eCRDUtil.getFromSession(request, "strDelRepairs");
                    strDelRepairs = eCRDUtil.verifyNull(strDelRepairs);
                    if ("".equals(strDelRepairs))
                    {
                        eCRDException objeCRDException = new eCRDException();
                        objeCRDException.setExcpId("eCRD_SESSION");
                        throw objeCRDException;
                    }
                    strMessage = objeCRDComponent.createRepair(request, objeCRDUser.getUserId(), objeCRDUser.getRole(), "", eCRDConstants.STRMERGEREPAIR, strDelRepairs);
                }
                if (strCheckFrom.equals("AddComponent") && !"RD_NUMBER_VALIDATION_FAILED".equals(strMessage))
                {
                    strMessage = objeCRDComponent.create(objeCRDUser.getUserId(), objeCRDUser.getRole());
                }
                
                request.setAttribute("strRepairMessage", strMessage);
                objeCRDComponent.setModule(objeCRDModule);
                objeCRDModule.setEngineModel(objeCRDEngineModel);
                objeCRDEngineModel.setCatalog(objeCRDDefaultCatalog);
                objeCRDDefaultCatalog.setEngineModel(objeCRDEngineModel);
                eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDDefaultCatalog);


                if ("MERGE".equals(strCheckFrom))
                {
                    eCRDUtil.loadInSession(request, "strFrom", "MERGE");
                }
                else if("Approval".equals(strFrom))
                {
                    eCRDUtil.loadInSession(request, "strFrom", "Approval");
                }
                else if("NewRepairApproval".equals(strFrom))
                {
                    eCRDUtil.loadInSession(request, "strFrom", "NewRepairApproval");
                }
                else if("RepairPricing".equals(strFrom))
                {
                    eCRDUtil.loadInSession(request, "strFrom", "RepairPricing");
                    request.setAttribute("strFrom","RepairPricing");
                }
                else if(!"RD_NUMBER_VALIDATION_FAILED".equals(strMessage))
                {
                    eCRDUtil.loadInSession(request, "strFrom", "Modify");
                }
             }
        }
        finally
        {
            objeCRDDefaultCatalog = null;
            objeCRDEngineModel = null;
            objeCRDModule = null;
            objeCRDComponent = null;
            objeCRDRepairSite = null;
            objeCRDPrice = null;

            strEngineModule = "";
            strCompCode = "";
            strDay = "";
            strMonth = "";
            strYear = "";
        }
    }
    private void createChildRepair(HttpServletRequest request, eCRDGroupedRepair objeCRDGroupedRepair) throws Exception
    {
        eCRDChildRepair objeCRDChildRepair = null;

        String strChildRepSeqId[] = null;
        String strDispSeq[] = null;
        String strRepairDesc[] = null;
        String strRepairReferenceFormat[] = null;
        String strRepairReference[] = null;
        String strComments[] = null;
        String strRDNumber[] = null;        
        String strRDOverride[] = null;
        String strRDComments[] = null;
        String strRDAssociation[] = null;
        String strRDCreationDt[] = null;
        String strRDModifiedDt[] = null;
        String strMergeSplit[] = null;
        //      String strFrom      = null ;
        ArrayList arrlstChildRepair = null;
        //      ArrayList arrlstRemove= null;
        //      int intCheckIfChildRepairSet = 0;
        int i = 0;
        //      int j = 0;
        String strFrom="";

        try
        {

            arrlstChildRepair = new ArrayList();
            arrlstChildRepair = new ArrayList();

            strChildRepSeqId = request.getParameterValues("hdnChildRepairCode");
            strDispSeq = request.getParameterValues("txtDisplaySequence");
            strRepairDesc = request.getParameterValues("txtRepairDesc");
            strRepairReferenceFormat = request.getParameterValues("lstRepairFormat");
            strRepairReference = request.getParameterValues("txtRepairFormat");
            strComments = request.getParameterValues("txtComments");
            strMergeSplit = request.getParameterValues("hdnMergeSplitSeqId");
            
            strRDNumber = request.getParameterValues("txtRDNumber");
            strRDOverride = request.getParameterValues("txtRDOverride");
            strRDComments = request.getParameterValues("txtRDComments");
            strRDAssociation = request.getParameterValues("hdnRDAssociation");
            strRDCreationDt = request.getParameterValues("hdnRDChildCreationDt");
            strRDModifiedDt = request.getParameterValues("hdnRDChildModifiedDt");
            //          strFrom =(String)eCRDUtil.getFromSession(request,"strFrom");
            strFrom = (String) eCRDUtil.getFromSession(request, "strFrom");
    
            objeCRDGroupedRepair.removeChildRepair();


                for (i = 0; i < strDispSeq.length; i++)
                {
                    if (!strDispSeq[i].equals(""))
                    {
                        objeCRDChildRepair = objeCRDGroupedRepair.addChildRepair();

                        objeCRDChildRepair.setStrChildRepairCode(strChildRepSeqId[i]);
                        objeCRDChildRepair.setRepairSeqNo(strDispSeq[i]);
                        eCRDUtil.replaceString(strRepairDesc[i], "\r\n", " ");
                        objeCRDChildRepair.setStrReapirDesc(strRepairDesc[i]);
                        objeCRDChildRepair.setStrReapairRefFormat(eCRDUtil.verifyNull(eCRDUtil.verifyNull(strRepairReferenceFormat[i])));
                        objeCRDChildRepair.setStrRepairRefNo(eCRDUtil.verifyNull(strRepairReference[i]));
                        eCRDUtil.replaceString(strComments[i], "\r\n", " ");
                        objeCRDChildRepair.setStrComments(eCRDUtil.verifyNull(strComments[i]));
                        objeCRDChildRepair.setStrRDNumber(eCRDUtil.verifyNull(strRDNumber[i]));
                        objeCRDChildRepair.setStrReasonRDOverride(eCRDUtil.verifyNull(strRDOverride[i]));            
                        eCRDUtil.replaceString(strRDComments[i], "\r\n", " ");
                        objeCRDChildRepair.setStrRDNumberComment(eCRDUtil.verifyNull(strRDComments[i]));

                        try {
                            objeCRDChildRepair.setStrRDAssociation(eCRDUtil.verifyNull(strRDAssociation[i]));
                        }
                        catch (Exception exp){
                            objeCRDChildRepair.setStrRDAssociation("N");    
                        }

                        objeCRDChildRepair.setStrRDCreationDt(eCRDUtil.verifyNull(strRDCreationDt[i]));                        
                        objeCRDChildRepair.setStrRDModifiedDt(eCRDUtil.verifyNull(strRDModifiedDt[i]));
                        if (strMergeSplit != null)
                        {
                            try
                            {
                                objeCRDChildRepair.setMergeSplitSeqId(eCRDUtil.verifyNull(strMergeSplit[i]));
                            }
                            catch (ArrayIndexOutOfBoundsException e)
                            {
                                objeCRDChildRepair.setMergeSplitSeqId("");
                            }

                        }
                        arrlstChildRepair.add(objeCRDChildRepair);
                    }
                
                eCRDUtil.loadInSession(request, "eCRDChildRepairArrayList", arrlstChildRepair);

            }

        }
        finally
        {
            objeCRDChildRepair = null;
            strChildRepSeqId = null;
            strDispSeq = null;
            strRepairDesc = null;
            strRepairReferenceFormat = null;
            strRepairReference = null;
            strComments = null;
            strMergeSplit = null;
            arrlstChildRepair = null;
            strRDNumber = null;
            strRDOverride = null;
            strRDComments = null;
            strRDAssociation = null;
            strRDCreationDt = null;
            strRDModifiedDt = null;
            //          arrlstRemove= null;
            //          intCheckIfChildRepairSet = 0;
            i = 0;
            //          j = 0;
        }
    }
    private int showRepairDetails(HttpServletRequest request) throws Exception
    {
        GEAEResultSet rsComponent = null;
        eCRDDefaultCatalog objeCRDDefaultCatalog = null;
        eCRDEngineModel objeCRDEngineModel = null;
        eCRDModule objeCRDModule = null;
        eCRDComponent objeCRDComponent = null;
        eCRDBusinessBean objeCRDBusinessBean = null;

        String strEngineModel = "";
        String strEngineModule = "";
        String strComponent = "";
        String strComponentValue = "";
        String strATAReference = "";
        String strAction = "";

        int intCheckIfComponentFound = 0;

        ArrayList arrlstInParam = null;
        try
        {
            objeCRDBusinessBean = new eCRDBusinessBean();
            //  To get the required entries from JSP
            strEngineModel = eCRDUtil.verifyNull(request.getParameter("hdnEngineModelDesc"));
            strEngineModule = eCRDUtil.verifyNull(request.getParameter("lstEngineModule"));
            strComponent = eCRDUtil.verifyNull(request.getParameter("hdnComponent"));
            strComponentValue = eCRDUtil.verifyNull(request.getParameter("txtComponent"));

            //  To get the resultset of components for the required combination of
            //  engine model,engine module,ATANumber,Component Code,component description

            strAction = eCRDConstants.getActionId("eCRD_MODIFY_COMPONENT");

            arrlstInParam = new ArrayList();
            arrlstInParam.add(strEngineModel);
            arrlstInParam.add(strEngineModule);
            arrlstInParam.add(strComponent);
            arrlstInParam.add(strComponentValue);
            arrlstInParam.add(strATAReference);

            rsComponent = objeCRDBusinessBean.populateComponentList(strAction, arrlstInParam);

            if (rsComponent.size() == 0)
            {
                request.setAttribute("ComponentFound", "No");
                intCheckIfComponentFound = -1;
            }
            else
            {
                rsComponent.setCurrentRow(0);
                rsComponent.next();
                strComponentValue = rsComponent.getString(1);

                objeCRDDefaultCatalog = (eCRDDefaultCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
                if (objeCRDDefaultCatalog == null)
                {
                    objeCRDDefaultCatalog = new eCRDDefaultCatalog(strEngineModel,eCRDConstants.STRENGMODELCONST);//Changed the constructor called to get loaded catalog object
                }
                objeCRDEngineModel = new eCRDEngineModel(strEngineModel);
                objeCRDDefaultCatalog.setEngineModel(objeCRDEngineModel);
                objeCRDModule = objeCRDEngineModel.getModule(strEngineModule);
                objeCRDComponent = new eCRDComponent();
                objeCRDComponent.setComponentCode(strComponentValue);
                objeCRDComponent.setModule(objeCRDModule);
                objeCRDModule.setEngineModel(objeCRDEngineModel);
                objeCRDEngineModel.setCatalog(objeCRDDefaultCatalog);

                eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDDefaultCatalog);
                eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODELCODE, strEngineModel);
                eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODULECODE, strEngineModule);
                eCRDUtil.loadInSession(request, eCRDConstants.STRCOMPONENTCODE, strComponentValue);
                eCRDUtil.loadInSession(request, "strFrom", "AddRepair");
                //          request.setAttribute("strFrom","Add");
                intCheckIfComponentFound = 1;
            }
            
        }
        finally
        {
            rsComponent = null;
            objeCRDDefaultCatalog = null;
            objeCRDEngineModel = null;
            objeCRDModule = null;
            objeCRDComponent = null;
            objeCRDBusinessBean = null;
            strEngineModel = "";
            strEngineModule = "";
            strComponent = "";
            strComponentValue = "";
            strATAReference = "";
            strAction = "";
        }
        return (intCheckIfComponentFound);
    }

    private void addRepairObject(HttpServletRequest request) throws Exception
    {

        
        String strEngineModelCode = ""; // String variable to store Engine Model Code
        String strEngineModuleCode = ""; // String variable to store Engine Module Code
        String strEngineModelDesc = "";
        String strEngineModuleDesc = "";
        String strCompCode = "";
        eCRDDefaultCatalog objeCRDDefaultCatalog = null;
        eCRDEngineModel objeCRDEngineModel = null;
        eCRDModule objeCRDModule = null;
        eCRDComponent objeCRDComponent = null;

        try
        {

            // Get the engine model code selected by the user
            strEngineModelCode = eCRDUtil.verifyNull(request.getParameter("hdnEngineModel"));
            // Get the engine module code selected by the user
            strEngineModuleCode = eCRDUtil.verifyNull(request.getParameter("hdnEngineModule"));
            strEngineModelDesc = eCRDUtil.verifyNull(request.getParameter("hdnEngineModelDesc"));
            strEngineModuleDesc = eCRDUtil.verifyNull(request.getParameter("hdnEngineModuleDesc"));
            strCompCode = (String) eCRDUtil.verifyNull(request.getParameter("hdnSelectedComponentCode"));

            objeCRDDefaultCatalog = (eCRDDefaultCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
            if (objeCRDDefaultCatalog == null)
            {
                objeCRDDefaultCatalog = new eCRDDefaultCatalog(strEngineModelCode,eCRDConstants.STRENGMODELCONST);//Changed the constructor called to get loaded catalog object
            }
            objeCRDEngineModel = objeCRDDefaultCatalog.getEngineModel();
            if (objeCRDEngineModel == null)
            {
                objeCRDEngineModel = new eCRDEngineModel();
                objeCRDDefaultCatalog.setEngineModel(objeCRDEngineModel);
            }

            objeCRDEngineModel.setEngineModelCode(strEngineModelCode);
            objeCRDEngineModel.setEngineModelDesc(strEngineModelDesc);
            
            objeCRDModule = objeCRDEngineModel.addModule();
            objeCRDModule.setModuleCode(strEngineModuleCode);
            
            objeCRDModule.setModuleDesc(strEngineModuleDesc);
            objeCRDComponent = objeCRDModule.addComponent();
            objeCRDComponent.setComponentCode(strCompCode);

            objeCRDComponent.setModule(objeCRDModule);
            objeCRDModule.setEngineModel(objeCRDEngineModel);
            objeCRDEngineModel.setCatalog(objeCRDDefaultCatalog);
            eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDDefaultCatalog);
            eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODELCODE, strEngineModelCode);
            eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODULECODE, strEngineModuleCode);
            eCRDUtil.loadInSession(request, eCRDConstants.STRCOMPONENTCODE, strCompCode);
        }
        finally
        {
            strEngineModelCode = "";
            strEngineModuleCode = "";
            strEngineModuleDesc = "";
            strCompCode = "";
            objeCRDDefaultCatalog = null;
            objeCRDEngineModel = null;
            objeCRDModule = null;
            objeCRDComponent = null;
        }

    }

    private GEAEResultSet formatRepair(GEAEResultSet rsCompCodeList, HttpServletRequest request) throws Exception
    {
        GEAEResultSet rsFormatted = null;
        ArrayList arrlstFormat = null;
        GEAETagNoData tagRadio = null;
        String strRadioValue = null;
        String strTempTagName = null;
        String strComponent = "";

        try
        {
            strComponent = request.getParameter("Component");
            
            if (rsCompCodeList != null && rsCompCodeList.size() > 0)
            {
                rsFormatted = new GEAEResultSet();
                
                for (int i = 0; i < rsCompCodeList.size(); i++)
                {
                    
                    arrlstFormat = new ArrayList();
                    strTempTagName = rsCompCodeList.getString(1);
                    strRadioValue = "" + eCRDUtil.replaceQuoteForJS(strTempTagName);
                    
                    
                    if ("Code".equalsIgnoreCase(strComponent))
                    {
                        tagRadio =
                            new GEAETagNoData(
                                "<INPUT TYPE=\"radio\" NAME=\"radCatalog\" VALUE=\"" + strRadioValue + "\" onClick = \"javascript:fnGetCompCode('" + rsCompCodeList.getString(1) + "')\"");
                    }
                    else if ("Description".equalsIgnoreCase(strComponent))
                    {
                        tagRadio =
                            new GEAETagNoData(
                                "<INPUT TYPE=\"radio\" NAME=\"radCatalog\" VALUE=\"" + strRadioValue + "\" onClick = \"javascript:fnGetCompCode('" + rsCompCodeList.getString(2) + "')\"");
                    }
                    request.setAttribute("CompCode", rsCompCodeList.getString(1));
                    arrlstFormat.add(tagRadio);
                    arrlstFormat.add(eCRDUtil.verifyNull(rsCompCodeList.getString(1)));
                    arrlstFormat.add(eCRDUtil.verifyNull(rsCompCodeList.getString(2)));
                    rsFormatted.addRow(arrlstFormat);

                    rsCompCodeList.next();
                }
                rsFormatted.setColumnHeading(1, "Select");
                rsFormatted.setColumnHeading(2, "Component Code");
                rsFormatted.setColumnHeading(3, "Component Description");

            }
            return rsFormatted;
        }
        finally
        {
            rsFormatted = null;
            arrlstFormat = null;
            tagRadio = null;
            strRadioValue = null;
            strTempTagName = null;
            strComponent = "";
        }

    }

    private eCRDRepairSite createSiteForGroupRepair(HttpServletRequest request, eCRDGroupedRepair objeCRDGroupedRepair) throws Exception
    {
        eCRDRepairSite objeCRDRepairSite = null;
        String strMatCost[] = null;
        String strLaborHrs[] = null;
        String strLaborRts[] = null;
        String strTotCost[] = null;
        String strCM[] = null;
        String strSite[] = null;
        String strSiteCode = "";
        StringTokenizer stSite = null;
        String strSiteDesc = "";
        String strDelSiteCode = "";
        ArrayList arrlstRemove = null;
        ArrayList arrlstRepairSites = null;

        try
        {
            arrlstRepairSites = new ArrayList();
            arrlstRemove = new ArrayList();
            strSite = request.getParameterValues("lstSite");
            strMatCost = request.getParameterValues("txtMatCost");
            strLaborHrs = request.getParameterValues("txtLabourHrs");
            strLaborRts = request.getParameterValues("txtLocLabourRate");
            strTotCost = request.getParameterValues("txtTotalCost");
            strCM = request.getParameterValues("txtCM");

            arrlstRemove = objeCRDGroupedRepair.getRepairSiteList();

            if (arrlstRemove != null)
            {

                for (int i = arrlstRemove.size(); arrlstRemove.size() > 0; i++)
                {
                    objeCRDRepairSite = (eCRDRepairSite) arrlstRemove.get(arrlstRemove.size() - 1);
                    strDelSiteCode = objeCRDRepairSite.getSiteCode();
                    
                    objeCRDGroupedRepair.removeSite(strDelSiteCode);
                }
            }
            arrlstRemove = objeCRDGroupedRepair.getRepairSiteList();
            for (int i = 0; i < strMatCost.length; i++)
            {
                if (!strSite[i].equals(""))
                {
                    objeCRDRepairSite = objeCRDGroupedRepair.addECRDRepairSite();
                    stSite = new StringTokenizer(strSite[i], "^");
                    while (stSite.hasMoreTokens())
                    {
                        strSiteCode = stSite.nextToken();
                        stSite.nextToken();
                        strSiteDesc = stSite.nextToken();
                    }
                    objeCRDRepairSite.setSiteCode(strSiteCode);
                    objeCRDRepairSite.setSiteDescription(strSiteDesc);
                    objeCRDRepairSite.setMaterialCost(Double.parseDouble(strMatCost[i]));
                    objeCRDRepairSite.setLaborHr(eCRDUtil.verifyDouble(strLaborHrs[i]));
                    objeCRDRepairSite.setLocationLaborRate(Double.parseDouble(strLaborRts[i]));
                    objeCRDRepairSite.setTotalCost(Double.parseDouble(strTotCost[i]));
                    objeCRDRepairSite.setCM(Double.parseDouble(eCRDUtil.verifyNullReturnZero(strCM[i])));
                    arrlstRepairSites.add(objeCRDRepairSite);
                }
            }
            eCRDUtil.loadInSession(request, "eCRDRepairSites", arrlstRepairSites);

            return objeCRDRepairSite;
        }
        finally
        {
            objeCRDRepairSite = null;
            strMatCost = null;
            strLaborHrs = null;
            strLaborRts = null;
            strTotCost = null;
            strCM = null;
            strSite = null;
            strSiteCode = "";
            stSite = null;
            strSiteDesc = "";
            strDelSiteCode = "";
            arrlstRemove = null;
            arrlstRepairSites = null;
        }
    }

    private void createSite(HttpServletRequest request, eCRDIndRepair objeCRDIndRepair) throws Exception
    {
        eCRDRepairSite objeCRDRepairSite = null;

        String strMatCost[] = null;
        String strLaborHrs[] = null;
        String strLaborRts[] = null;
        String strTotCost[] = null;
        String strCM[] = null;
        String strSite[] = null;
        String strSiteCode = "";
        StringTokenizer stSite = null;
        String strSiteDesc = "";
        String strDelSiteCode = "";
        ArrayList arrlstRepairSites = null;
        ArrayList arrlstRemove = null;
        int i = 0;
        try
        {
            arrlstRepairSites = new ArrayList();
            arrlstRemove = new ArrayList();
            strSite = request.getParameterValues("lstSite");
            strMatCost = request.getParameterValues("txtMatCost");
            strLaborHrs = request.getParameterValues("txtLabourHrs");
            strLaborRts = request.getParameterValues("txtLocLabourRate");
            strTotCost = request.getParameterValues("txtTotalCost");
            strCM = request.getParameterValues("txtCM");

            arrlstRemove = objeCRDIndRepair.getRepairSiteList();

            if (arrlstRemove != null)
            {
                for (i = arrlstRemove.size(); arrlstRemove.size() > 0; i++)
                {
                    objeCRDRepairSite = (eCRDRepairSite) arrlstRemove.get(arrlstRemove.size() - 1);
                    strDelSiteCode = objeCRDRepairSite.getSiteCode();
                    
                    objeCRDIndRepair.removeSite(strDelSiteCode);
                }
            }
            arrlstRemove = objeCRDIndRepair.getRepairSiteList();
            for (i = 0; i < strMatCost.length; i++)
            {
                if (!strSite[i].equals(""))
                {
                    stSite = new StringTokenizer(strSite[i], "^");
                    while (stSite.hasMoreTokens())
                    {
                        strSiteCode = stSite.nextToken();
                        stSite.nextToken();
                        strSiteDesc = stSite.nextToken();
                    }

                    objeCRDRepairSite = objeCRDIndRepair.getRepairSite(strSiteCode);
                    objeCRDRepairSite = objeCRDIndRepair.addECRDRepairSite();

                    objeCRDRepairSite.setSiteCode(strSiteCode);
                    objeCRDRepairSite.setSiteDescription(strSiteDesc);
                    objeCRDRepairSite.setMaterialCost(Double.parseDouble(strMatCost[i]));
                    objeCRDRepairSite.setLaborHr(eCRDUtil.verifyDouble(strLaborHrs[i]));
                    objeCRDRepairSite.setLocationLaborRate(Double.parseDouble(strLaborRts[i]));
                    objeCRDRepairSite.setTotalCost(Double.parseDouble(strTotCost[i]));
                    objeCRDRepairSite.setCM(Double.parseDouble(eCRDUtil.verifyNullReturnZero(strCM[i])));
                    arrlstRepairSites.add(objeCRDRepairSite);
                }
            }
            eCRDUtil.loadInSession(request, "eCRDRepairSites", arrlstRepairSites);
    }
        finally
        {
            strMatCost = null;
            strLaborHrs = null;
            strLaborRts = null;
            strTotCost = null;
            strCM = null;
            strSiteCode = "";
            stSite = null;
            strSiteDesc = "";
            strDelSiteCode = "";
            arrlstRepairSites = null;
            arrlstRemove = null;
            i = 0;
        }
    }

    public void getRepairListingAfterSavingRepair(HttpServletRequest request) throws Exception
    {
        String strCatalogSeqId = "";
        String strComponentCode = "";
        String strModuleCode = "";
        //      String strCatalogType = "";
        String strActionId = "";
        String strEngineModelCode = "";
        ArrayList arrlstOutParam = null;
        GEAEResultSet rsRepairs = null;
        eCRDSearchBean objeCRDSearchBean = null;
        eCRDUser objeCRDUser = null;
        try
        {
            objeCRDSearchBean = new eCRDSearchBean();
            objeCRDUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser");
            strEngineModelCode = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODELCODE));
            strComponentCode = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRCOMPONENTCODE));
            strModuleCode = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE));
            strCatalogSeqId = eCRDCatalog.getCurrentDefaultSeqId(strEngineModelCode);
            strActionId = eCRDConstants.getActionId("eCRD_REPAIR_LISTING");
            
            arrlstOutParam = objeCRDSearchBean.getRepairListing(strCatalogSeqId, strEngineModelCode, strModuleCode, "1", strComponentCode, strActionId,eCRDUtil.verifyNull(objeCRDUser.getRole()));
            rsRepairs = (GEAEResultSet) arrlstOutParam.get(0);
            
            request.setAttribute("rsRepairs", rsRepairs);

        }
        finally
        {

        }
    }
    public void getRepairListing(HttpServletRequest request) throws Exception
    {

        eCRDCatalog objeCRDCatalog = null;
        eCRDDefaultCatalog objeCRDDefaultCatalog = null;
        eCRDCustomerCatalog objeCRDCustomerCatalog = null;
        eCRDException objeCRDException = null;
        eCRDEngineModel objeCRDEngineModel = null;
        String strCatalogSeqId = "";
        String strComponentCode = "";
        String strModuleCode = "";
        String strCatalogType = "";
        String strActionId = "";
        String strEngineModelCode = "";
        ArrayList arrlstOutParam = null;
        GEAEResultSet rsRepairs = null;
        eCRDSearchBean objeCRDSearchBean = null;
        eCRDUser objeCRDUser = null;
        try
        {
            objeCRDUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser");
            objeCRDCatalog = (eCRDCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
            if (objeCRDCatalog == null)
            {
                objeCRDException = new eCRDException();
                objeCRDException.setExcpId("CATALOG_NOT_SET");
                throw objeCRDException;

            }
            strCatalogSeqId = objeCRDCatalog.getCatalogSeqId();
            strCatalogType = eCRDUtil.verifyNull(objeCRDCatalog.getCatalogType());
            objeCRDSearchBean = new eCRDSearchBean();

            
            if (eCRDConstants.STRDEFAULTCATALOGTYPE.equals(strCatalogType))
            {

                objeCRDDefaultCatalog = (eCRDDefaultCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
                if (objeCRDDefaultCatalog == null)
                {
                    objeCRDDefaultCatalog = new eCRDDefaultCatalog();
                }
                objeCRDEngineModel = objeCRDDefaultCatalog.getEngineModel();
                if (objeCRDEngineModel == null)
                {
                    objeCRDEngineModel = new eCRDEngineModel();
                }
                strEngineModelCode = objeCRDEngineModel.getEngineModelCode();

            }
            else
            {
                objeCRDCustomerCatalog = (eCRDCustomerCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
                if (objeCRDCustomerCatalog == null)
                {
                    objeCRDCustomerCatalog = new eCRDCustomerCatalog();
                }
                objeCRDEngineModel = objeCRDCustomerCatalog.getEngineModel();

                if (objeCRDEngineModel == null)
                {
                    objeCRDEngineModel = new eCRDEngineModel();
                }
                strEngineModelCode = objeCRDEngineModel.getEngineModelCode();
            }

            rsRepairs = new GEAEResultSet();
            strActionId = eCRDConstants.getActionId("eCRD_REPAIR_LISTING");
            strComponentCode = eCRDUtil.verifyNull(request.getParameter("hdnComponentCode"));
            strModuleCode = eCRDUtil.verifyNull(request.getParameter("selModule"));

            eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODELCODE, strEngineModelCode);
            eCRDUtil.loadInSession(request, eCRDConstants.STRCOMPONENTCODE, strComponentCode);
            eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODULECODE, strModuleCode);
            eCRDUtil.loadInSession(request, "strFrom", "ComponentListing");

            
            arrlstOutParam = objeCRDSearchBean.getRepairListing(strCatalogSeqId, strEngineModelCode, strModuleCode, "1", strComponentCode, strActionId,eCRDUtil.verifyNull(objeCRDUser.getRole()));
            rsRepairs = (GEAEResultSet) arrlstOutParam.get(0);
            
            request.setAttribute("rsRepairs", rsRepairs);
        }
        finally
        {
            objeCRDCatalog = null;
            objeCRDDefaultCatalog = null;
            objeCRDCustomerCatalog = null;
            objeCRDEngineModel = null;
            strComponentCode = null;
            strModuleCode = null;
            strCatalogType = null;
            strActionId = null;
            strEngineModelCode = null;
            arrlstOutParam = null;
            rsRepairs = null;
            objeCRDSearchBean = null;
        }
    }

    private void setCatalogObject(HttpServletRequest request, String strFrom) throws Exception
    {

        // String variable to store Engine Model Code
        String strEngineModuleCode = ""; // String variable to store Engine Module Code
        String strComponentCode = "";
        String strRepairCode = "";
        String strRepairType = "";

        /*eCRDDefaultCatalog objeCRDDefaultCatalog = null;
        eCRDCustomerCatalog objeCRDCustomerCatalog = null;*/
        eCRDCatalog objeCRDCatalog = null;
        eCRDException objeCRDException = null;
        eCRDEngineModel objeCRDEngineModel = null;
        eCRDModule objeCRDModule = null;
        eCRDComponent objeCRDComponent = null;
        eCRDRepair objeCRDRepair = null;

        try
        {
            strRepairCode = eCRDUtil.verifyNull(request.getParameter("hdnRepairCode"));
            strRepairType = eCRDUtil.verifyNull(request.getParameter("hdnRepairType"));
            strEngineModuleCode = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE));
            strComponentCode = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRCOMPONENTCODE));

            objeCRDCatalog = (eCRDCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
            if (objeCRDCatalog == null)
            {
                objeCRDException = new eCRDException();
                objeCRDException.setExcpId("CATALOG_NOT_SET");
                throw objeCRDException;
            }
            objeCRDEngineModel = objeCRDCatalog.getEngineModel();
            objeCRDEngineModel.setCatalog(objeCRDCatalog);
            objeCRDModule = objeCRDEngineModel.getModule(strEngineModuleCode);
            objeCRDComponent = objeCRDModule.getComponent(strComponentCode);
            objeCRDRepair = objeCRDComponent.getRepair(strRepairCode, strRepairType);
            objeCRDRepair.setECRDComponent(objeCRDComponent);
            objeCRDComponent.setModule(objeCRDModule);
            objeCRDModule.setEngineModel(objeCRDEngineModel);
            objeCRDEngineModel.setCatalog(objeCRDCatalog);
            eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDCatalog);
            
            eCRDUtil.loadInSession(request, "strFrom", strFrom);
            eCRDUtil.loadInSession(request, eCRDConstants.STRREPAIRSEQID, strRepairCode);
            eCRDUtil.loadInSession(request, eCRDConstants.STRREPAIRTYPE, strRepairType);
            //eCRDUtil.loadInSession(request, "strForm", "MODIFY");

        }
        finally
        {

            strEngineModuleCode = "";

            /* objeCRDDefaultCatalog = null;
             objeCRDEngineModel       = null;
             objeCRDModule                 = null;
              objeCRDComponent           = null;*/
        }

    }

    /**
        * Function to get all Engine Model
        */

    /*private void getEngineModel()
    {
        eCRDLoadMaster objeCRDLoadMaster = new eCRDLoadMaster();
        GEAEResultSet objEngineList = new GEAEResultSet();
        objEngineList = objeCRDLoadMaster.getEngineModelList();
        objEngineList.setCurrentRow(0);
        objEngineList.next();
        
        }*/

    /**
     * Executes steps to modify a new repair.
     * request:
     * action=modify
     */
    private void modifyRepair(HttpServletRequest request) throws Exception
    {

        String strRepairType = "";

        try
        {

            strRepairType = (String) eCRDUtil.getFromSession(request, "strRepairType");

            if (strRepairType.equals(eCRDConstants.STRINDIVIDUALREPAIR)|| strRepairType.equals(eCRDConstants.STRSPECIALINDIVIDUALREPAIR) || strRepairType.equals(eCRDConstants.STRSLITREPAIR) )
            {
                
                createIndRepair(request);
                
                if (!("REPAIR_DESC_EXISTS".equals(request.getAttribute("strRepairMessage")) 
                        || "REPAIR_DISP_SEQ_EXISTS".equals(request.getAttribute("strRepairMessage"))
                        || "RD_NUMBER_VALIDATION_FAILED".equals(request.getAttribute("strRepairMessage"))))
                {
                    
                    setModifyRepair(request);
                }
            }
            else if (strRepairType.equals(eCRDConstants.STRGROUPREPAIR)|| strRepairType.equals(eCRDConstants.STRSPECIALGROUPREPAIR)|| strRepairType.equals(eCRDConstants.STRMERGEREPAIR))
            {
                
                createGroupRepair(request);
                
                if (!("REPAIR_DESC_EXISTS".equals(request.getAttribute("strRepairMessage")) 
                        || "REPAIR_DISP_SEQ_EXISTS".equals(request.getAttribute("strRepairMessage"))
                        || "RD_NUMBER_VALIDATION_FAILED".equals(request.getAttribute("strRepairMessage"))))
                {
                       
                        setModifyRepair(request);
                }

            }

            /**
             * Do Db operation
            */

        }
        finally
        {
        }
    }

    private void setModifyRepair(HttpServletRequest request) throws Exception
    {
        String struserId = "";
        String struserRole = "";
        StringBuffer strRepairBuff = null;
        StringBuffer strChildRepairBuff = null;

        String strTcModify = "";
        String strEngModelCode = "";
        String strEngineModule = "";
        String strCompCode = "";
        String strRepairSeqId = "";
        String strRepairType = "";
        String strCatalogSeqId = "";
        String strActionId = "";
        eCRDCatalog objeCRDDefaultCatalog = null;
        //eCRDCatalog objeCRDCatalog = null;
        eCRDEngineModel objeCRDEngineModel = null;
        eCRDModule objeCRDModule = null;
        eCRDComponent objeCRDComponent = null;
        ArrayList arrlstInpParam = null;
        ArrayList arrlstOutParam = null;
        eCRDIndRepair objeCRDIndRepair = null;
        //      eCRDRepairPricing objeCRDPrice = null;
        eCRDChildRepair objeCRDChildRepair = null;
        eCRDGroupedRepair objeCRDGrpRepair = null;
        eCRDRepair objeCRDRepair = null;
        eCRDRepairSite objeCRDRepairSite = null;
        eCRDUser objeCRDUser = null;
        eCRDSearchBean objeCRDSearchBean = null;
        GEAEResultSet rsRepairs = null;
        

        try
        {
            strActionId = eCRDUtil.verifyNull(request.getParameter("hdnScreenAction"));
            arrlstInpParam = new ArrayList();
            objeCRDSearchBean = new eCRDSearchBean();
            strChildRepairBuff = new StringBuffer();
            strRepairBuff = new StringBuffer();
            objeCRDUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser");
            objeCRDDefaultCatalog = (eCRDCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
            strEngineModule = (String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE);
            strCompCode = (String) eCRDUtil.getFromSession(request, eCRDConstants.STRCOMPONENTCODE);
            strRepairSeqId = (String) eCRDUtil.getFromSession(request, eCRDConstants.STRREPAIRSEQID);
            strRepairType = (String) eCRDUtil.getFromSession(request, "strRepairType");
            strTcModify = eCRDUtil.verifyNull(request.getParameter("hdnTCModify"));

            objeCRDDefaultCatalog = (eCRDCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
            objeCRDEngineModel = objeCRDDefaultCatalog.getEngineModel();
            objeCRDEngineModel.setCatalog(objeCRDDefaultCatalog);
            strEngModelCode = objeCRDDefaultCatalog.getEngineModel().getEngineModelCode();
            objeCRDModule = objeCRDEngineModel.getModule(strEngineModule);
            objeCRDComponent = objeCRDModule.getComponent(strCompCode);
            objeCRDRepair = objeCRDComponent.getRepair(strRepairSeqId, strRepairType);

            if (strRepairType.equals(eCRDConstants.STRINDIVIDUALREPAIR) || strRepairType.equals(eCRDConstants.STRSPECIALINDIVIDUALREPAIR) || strRepairType.equals(eCRDConstants.STRSLITREPAIR))
            {
                objeCRDIndRepair = (eCRDIndRepair) objeCRDRepair;
                
                objeCRDIndRepair.getStrRepairDesc(); 
                objeCRDIndRepair.getStrRepairVolume();
                objeCRDIndRepair.getDtRepairEffDate();
                objeCRDIndRepair.getStrComments();
        
                strCatalogSeqId = eCRDUtil.verifyNull(objeCRDDefaultCatalog.getCatalogSeqId());
                
                if("".equals(strCatalogSeqId))
                {
                    strCatalogSeqId = eCRDCatalog.getCurrentDefaultSeqId(strEngModelCode);
                }

                

                arrlstInpParam.add(strCatalogSeqId);
                
                arrlstInpParam.add(objeCRDComponent.getComponentCode());
                
                arrlstInpParam.add(objeCRDModule.getModuleCode());
                
                arrlstInpParam.add(objeCRDIndRepair.getStrRepairCode());
                
                arrlstInpParam.add(objeCRDIndRepair.getStrRepairDesc());
                
                arrlstInpParam.add(objeCRDIndRepair.getStrRepairVolume());
                
                arrlstInpParam.add(objeCRDIndRepair.getDtRepairEffDate());
                
                arrlstInpParam.add(objeCRDIndRepair.getStrComments());
                
                arrlstInpParam.add(strRepairType);
                
                arrlstInpParam.add(objeCRDIndRepair.getRepairRefNo());
                
                arrlstInpParam.add(objeCRDIndRepair.getRepairRefFormat());
                

                for (int i = 0; i < objeCRDIndRepair.getRepairSiteList().size(); i++)
                {
                    objeCRDRepairSite = (eCRDRepairSite) objeCRDIndRepair.getRepairSiteList().get(i);
                    strRepairBuff.append(eCRDUtil.verifyNull(objeCRDRepairSite.getSiteCode()));
                    strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                    strRepairBuff.append(objeCRDRepairSite.getMaterialCost());
                    strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                    strRepairBuff.append(objeCRDRepairSite.getLaborHr());
                    strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                    strRepairBuff.append(eCRDConstants.STRROWDELIM);

                }
                arrlstInpParam.add(strRepairBuff.toString());
                arrlstInpParam.add(strChildRepairBuff.toString());

                
                

                if ("true".equals(strTcModify))
                {
                    arrlstInpParam.add("true");
                    
                }
                else
                {
                    arrlstInpParam.add("false");
                    
                }

                if (objeCRDIndRepair.getObjRepairPricing().isFlgIncrTAT())
                {
                    arrlstInpParam.add("Y");
                    
                }
                else
                {
                    arrlstInpParam.add("N");
                    
                }
                if(objeCRDIndRepair.getObjRepairPricing().getIntTAT()==null)
                {
                    arrlstInpParam.add("");
                }
                else
                {
                arrlstInpParam.add("" + objeCRDIndRepair.getObjRepairPricing().getIntTAT());
                }
                
                if (objeCRDIndRepair.getObjRepairPricing().isFlgIncrPrice())
                {
                    arrlstInpParam.add("Y");
                }
                else
                {
                    arrlstInpParam.add("N");
                }
                if(objeCRDIndRepair.getObjRepairPricing().getDblPrice()==null)
                {
                    arrlstInpParam.add("");
                }
                else
                {
                arrlstInpParam.add("" + objeCRDIndRepair.getObjRepairPricing().getDblPrice());
                }
                
                arrlstInpParam.add(objeCRDIndRepair.getObjRepairPricing().getStrPriceType());
                
                arrlstInpParam.add(objeCRDIndRepair.getObjRepairPricing().getRepairSeqNo()); /*--display seq id*/
                if(objeCRDIndRepair.getObjRepairPricing().getDblFuturePrice()==null)
                {
                    arrlstInpParam.add("");
                }
                else
                {
                arrlstInpParam.add("" + objeCRDIndRepair.getObjRepairPricing().getDblFuturePrice());
                }
                if(objeCRDIndRepair.getObjRepairPricing().getIntFutureTAT()==null)
                {
                    arrlstInpParam.add("");
                }
                else
                {
                arrlstInpParam.add("" + objeCRDIndRepair.getObjRepairPricing().getIntFutureTAT());
                }
                arrlstInpParam.add(objeCRDIndRepair.getObjRepairPricing().getDtFuturePriceTATEffDt());
                struserId = objeCRDUser.getUserId();
                struserRole = objeCRDUser.getRole();
                
                
                arrlstInpParam.add(struserId);
                arrlstInpParam.add(struserRole);
                arrlstInpParam.add(eCRDConstants.STRROWDELIM);
                arrlstInpParam.add(eCRDConstants.STRCOLUMNDELIM);
                // Sushant
                arrlstInpParam.add(objeCRDIndRepair.getStrRDNumber());
                arrlstInpParam.add(objeCRDIndRepair.getStrReasonRDOverride());
                arrlstInpParam.add(objeCRDIndRepair.getStrRDNumberComment());
                arrlstInpParam.add(objeCRDIndRepair.getStrRDAssociation());
                arrlstInpParam.add(objeCRDIndRepair.getStrNPIClassification());
            }
            else if (strRepairType.equals(eCRDConstants.STRGROUPREPAIR) || strRepairType.equals(eCRDConstants.STRSPECIALGROUPREPAIR) || strRepairType.equals(eCRDConstants.STRMERGEREPAIR))
            {
                objeCRDGrpRepair = (eCRDGroupedRepair) objeCRDRepair;
                
                objeCRDGrpRepair.getStrRepairDesc();
                objeCRDGrpRepair.getStrRepairVolume();
                objeCRDGrpRepair.getDtRepairEffDate();
                objeCRDGrpRepair.getStrComments();

                strCatalogSeqId = eCRDUtil.verifyNull(objeCRDDefaultCatalog.getCatalogSeqId());
                
                if("".equals(strCatalogSeqId))
                {
                    strCatalogSeqId = eCRDCatalog.getCurrentDefaultSeqId(strEngModelCode);
                }

                

                arrlstInpParam.add(strCatalogSeqId);
                
                arrlstInpParam.add(objeCRDComponent.getComponentCode());
                
                arrlstInpParam.add(objeCRDModule.getModuleCode());
                
                arrlstInpParam.add(objeCRDGrpRepair.getStrRepairCode());
                
                arrlstInpParam.add(objeCRDGrpRepair.getStrRepairDesc());

                arrlstInpParam.add(objeCRDGrpRepair.getStrRepairVolume());
                
                arrlstInpParam.add(objeCRDGrpRepair.getDtRepairEffDate());
                
                arrlstInpParam.add(objeCRDGrpRepair.getStrComments());
                
                arrlstInpParam.add(strRepairType);
                
                arrlstInpParam.add(""); // added for crd_e_repair.repair_reference%TYPE
                
                arrlstInpParam.add("");  // crd_e_repair.repair_reference_format%TYPE
                
                
                // Repair Site Details added here to stringBuffer
                for (int i = 0; i < objeCRDGrpRepair.getRepairSiteList().size(); i++)
                {
                    objeCRDRepairSite = (eCRDRepairSite) objeCRDGrpRepair.getRepairSiteList().get(i);
                    strRepairBuff.append(eCRDUtil.verifyNull(objeCRDRepairSite.getSiteCode()));
                    strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                    strRepairBuff.append(objeCRDRepairSite.getMaterialCost());
                    strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                    strRepairBuff.append(objeCRDRepairSite.getLaborHr());
                    strRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                    strRepairBuff.append(eCRDConstants.STRROWDELIM);

                }

                // Child Repair Details are added here to StringBuffer
                for (int i = 0; i < objeCRDGrpRepair.getChildRepairsList().size(); i++)
                {

                    objeCRDChildRepair = (eCRDChildRepair) objeCRDGrpRepair.getChildRepairsList().get(i);
                    strChildRepairBuff.append(objeCRDChildRepair.getStrChildRepairCode());
                    strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                    strChildRepairBuff.append(objeCRDChildRepair.getStrReapirDesc());
                    strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                    strChildRepairBuff.append(objeCRDChildRepair.getStrRepairRefNo());
                    strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                    strChildRepairBuff.append(objeCRDChildRepair.getStrComments());
                    strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                    strChildRepairBuff.append(objeCRDChildRepair.getStrReapairRefFormat());
                    strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                    strChildRepairBuff.append(objeCRDChildRepair.getRepairSeqNo()); /*check*/
                    strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                    strChildRepairBuff.append(objeCRDChildRepair.getStrRDNumber());
                    strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                    strChildRepairBuff.append(objeCRDChildRepair.getStrReasonRDOverride());
                    strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                    strChildRepairBuff.append(objeCRDChildRepair.getStrRDNumberComment());
                    strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                    strChildRepairBuff.append(objeCRDChildRepair.getStrRDAssociation());
                    strChildRepairBuff.append(eCRDConstants.STRCOLUMNDELIM);
                  

                    strChildRepairBuff.append(eCRDConstants.STRROWDELIM);

                }
                
                //Repair Site Details added to ArrayListInParam
                arrlstInpParam.add(strRepairBuff.toString());
                // Child Repair Details added to ArrayListInParam
                arrlstInpParam.add(strChildRepairBuff.toString());

                
                
                // IF user has Role TC then true will be passed here to ArrayListInParam
                if ("true".equals(strTcModify))
                {
                    arrlstInpParam.add("true");
                    
                }
                else
                {
                    arrlstInpParam.add("false");
                    
                }

                if (objeCRDGrpRepair.getObjRepairPricing().isFlgIncrTAT())
                {
                    arrlstInpParam.add("Y");
                    
                }
                else
                {
                    arrlstInpParam.add("N");
                    
                }

                arrlstInpParam.add("" + eCRDUtil.verifyNullReturnObject(objeCRDGrpRepair.getObjRepairPricing().getIntTAT()));
                
                if (objeCRDGrpRepair.getObjRepairPricing().isFlgIncrPrice())
                {
                    arrlstInpParam.add("Y");
                }
                else
                {
                    arrlstInpParam.add("N");
                }
                
                arrlstInpParam.add("" + eCRDUtil.verifyNullReturnObject(objeCRDGrpRepair.getObjRepairPricing().getDblPrice()));
                
                arrlstInpParam.add(objeCRDGrpRepair.getObjRepairPricing().getStrPriceType());
                
                arrlstInpParam.add(objeCRDGrpRepair.getObjRepairPricing().getRepairSeqNo()); /*--display seq id*/
                
                arrlstInpParam.add("" + eCRDUtil.verifyNullReturnObject(objeCRDGrpRepair.getObjRepairPricing().getDblFuturePrice()));
                
                arrlstInpParam.add("" +eCRDUtil.verifyNullReturnObject( objeCRDGrpRepair.getObjRepairPricing().getIntFutureTAT()));
                
                arrlstInpParam.add(objeCRDGrpRepair.getObjRepairPricing().getDtFuturePriceTATEffDt());
                
                // User Id & Role added here 
                struserId = objeCRDUser.getUserId();
                struserRole = objeCRDUser.getRole();

                
                
                arrlstInpParam.add(struserId);
                arrlstInpParam.add(struserRole);
                arrlstInpParam.add(eCRDConstants.STRROWDELIM);
                arrlstInpParam.add(eCRDConstants.STRCOLUMNDELIM);
                // Sushant added for RD Number
                arrlstInpParam.add(""); // RD Number
                arrlstInpParam.add(""); // Rd Override Reason
                arrlstInpParam.add(""); // RD Comments
                arrlstInpParam.add(""); // RD Association
                arrlstInpParam.add(objeCRDGrpRepair.getStrNPIClassification()); // NPI Classification
            }
            
            arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);
            request.setAttribute("strRepairMessage",arrlstOutParam.get(0));
            arrlstOutParam = objeCRDSearchBean.getRepairListing(strCatalogSeqId, strEngModelCode, strEngineModule, "1", strCompCode, eCRDConstants.getActionId("eCRD_REPAIR_LISTING"),eCRDUtil.verifyNull(objeCRDUser.getRole()));
            rsRepairs = (GEAEResultSet) arrlstOutParam.get(0);
            request.setAttribute("rsRepairs", rsRepairs);
        }
        finally
        {
            struserId =null;
            struserRole = null;
            strRepairBuff = null;
            strChildRepairBuff = null;

            strTcModify = null;
            strEngModelCode =null;
            strEngineModule =null;
            strCompCode = null;
            strRepairSeqId =null;
            strRepairType = null;
            strCatalogSeqId = null;
            strActionId =null;
            objeCRDDefaultCatalog = null;
            objeCRDEngineModel = null;
            objeCRDModule = null;
            objeCRDComponent = null;
            arrlstInpParam = null;
            arrlstOutParam = null;
            objeCRDIndRepair = null;
            //          objeCRDPrice = null;
            objeCRDChildRepair = null;
            objeCRDGrpRepair = null;
            objeCRDRepair = null;
            objeCRDRepairSite = null;
            objeCRDUser = null;
            objeCRDSearchBean = null;
            rsRepairs = null;
        }

    }

    /**
     * Executes steps to search a repair.
     * request: action=search
     */
    private void searchRepair()
    {

    }

    /**
     * Executes steps to search a repair.
     * request: action=loadRepair details
     */
    private void loadRepair()
    {

    }

    public String approveNewRepair(HttpServletRequest request) throws Exception
    {
        String strModuleCode = "";
        String strComponentCode = "";
        String strRepairSeqId = "";
        String strRepairType = "";
        //  ArrayList arlstInParam=null;
        ArrayList arlstOutParam = null;

        eCRDDefaultCatalog objCatalog = null;
        eCRDEngineModel objModel = null;
        eCRDModule objModule = null;
        eCRDComponent objComponent = null;
        eCRDRepair objRepair = null;
        //  eCRDIndRepair objIndRepair =null;
        //  eCRDGroupedRepair objGrpRepair=null;
        eCRDRepairApproval objRepairApproval = null;
        GEAEResultSet rsApprvRep = null;
        eCRDDataBean objeCRDDataBean = null;
        eCRDUser objeCRDUser = null;
        GEAEResultSet rsFormatted = null;
        String strRole = null;
        String strUserId = null;
        
        String strMessage = "";
            
        try
        {
            objeCRDUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser");
            if (objeCRDUser == null)
            {
                throw new Exception("User Not Found");
            }
            strModuleCode = (String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE);
            strComponentCode = (String) eCRDUtil.getFromSession(request, eCRDConstants.STRCOMPONENTCODE);
            strRepairSeqId = (String) eCRDUtil.getFromSession(request, eCRDConstants.STRREPAIRSEQID);
            //strRepairType = (String)eCRDUtil.getFromSession(request,"strRepairType");
            strRepairType = (String) eCRDUtil.verifyNull(request.getParameter("hdnRepairType"));
            if (strRepairType.equals("IR"))
            {
                createIndRepair(request);
            }
            else
            {
                createGroupRepair(request);
            }
    
            if ("REPAIR_DESC_EXISTS".equals(request.getAttribute("strRepairMessage")) 
                    || "REPAIR_DISP_SEQ_EXISTS".equals(request.getAttribute("strRepairMessage"))
                    || "RD_NUMBER_VALIDATION_FAILED".equals(request.getAttribute("strRepairMessage")))
            {   
                strMessage =(String)request.getAttribute("strRepairMessage");       
            }
            else
            {       
                objCatalog = (eCRDDefaultCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
                objModel = objCatalog.getEngineModel();
                objModel.setCatalog(objCatalog);
                //  strEngModelCode =(String)eCRDUtil.getFromSession(request,eCRDConstants.STRENGINEMODELCODE);
                objModule = objModel.getModule(strModuleCode);
                objComponent = objModule.getComponent(strComponentCode);
                objRepair = objComponent.getRepair(strRepairSeqId, strRepairType);
                objRepairApproval = objRepair.getApproveRepairdetails();
                objRepairApproval.setStgApprovalRepair(objRepair);
                objRepairApproval.setApprovedBy(objeCRDUser.getUserId());
    
                objRepairApproval.approve();
    
                objeCRDDataBean = (eCRDDataBean) eCRDUtil.getFromSession(request, "objeCRDDataBean");
                if (objeCRDDataBean == null)
                {
                    objeCRDDataBean = new eCRDDataBean();
                    eCRDUtil.loadInSession(request, "objeCRDDataBean", objeCRDDataBean);
                }
    
                //method to be called to perform doDBoperation from bean
    
                objeCRDUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser");
                strRole = objeCRDUser.getRole();
                strUserId=objeCRDUser.getUserId();
                
                //Patni 16-06-2006 Clearing the session values Begin
                eCRDUtil.clearSession(request);
                //Patni 16-06-2006 Clearing the session values End
                
                arlstOutParam = objRepairApproval.getApprovalRepair(eCRDConstants.getActionId("eCRD_GET_APPROVAL_REPAIR_LIST"),strRole,strUserId);
    
                //formating of the resultset obtained
                rsApprvRep = (GEAEResultSet) arlstOutParam.get(0);
    
                rsFormatted = formatRepResultSet(rsApprvRep);
    
                objeCRDDataBean.setCache(rsFormatted);
    
                eCRDUtil.loadInSession(request, "objeCRDDataBean", objeCRDDataBean);
            }
            return strMessage;
        }
        finally
        {
            strModuleCode = null;
            strComponentCode = null;
            strRepairSeqId = null;
            strRepairType = null;
            arlstOutParam = null;
            objCatalog = null;
            objModel = null;
            objModule = null;
            objComponent = null;
            objRepair = null;
            objRepairApproval = null;
            rsApprvRep = null;
            objeCRDDataBean = null;
            objeCRDUser = null;
            rsFormatted = null;
            strRole = null;
            strUserId = null;
            strMessage = null;
        }
    }
    public GEAEResultSet formatRepResultSet(GEAEResultSet rsSearchResults) throws Exception
    {
        String strCompCode = "";
        String strCompDesc = "";
        String strEngModelCode = "";
        //          String strEngModelDesc="";
        String strEngModuleCode = "";
        String strEngModuleDesc = "";
        String strRequestedBy = "";
        String strRequesedDate = "";
        String strFlg = "";
        //          String strUrlAdditionChange = "";
        String strNoTagChange = "";
        String strRepairDesc = "";
        String strRepairCode = "";
        String strRepairType = "";
        //          GEAEResultSet rsFormatted = null;
        GEAEResultSet rsFormattedRS = null;
        rsFormattedRS = new GEAEResultSet();
        ArrayList arrlstTemp = null;
        GEAETag geAERepairTag = null;
        GEAETag geNoTag = null;
        try
        {
            rsFormattedRS = new GEAEResultSet();
            rsSearchResults.setCurrentRow(0);

            while (rsSearchResults.next())
            {
                /* Patni 06-Sep-2006 - Engine Model Code should be retrieved instead of Description - Begin */                
                //strEngModelCode = eCRDUtil.verifyNull(rsSearchResults.getString("mdl_description"));                
                strEngModelCode = eCRDUtil.verifyNull(rsSearchResults.getString("mdl_number"));
                /* Patni 06-Sep-2006 - Engine Model Code should be retrieved instead of Description - End */
                
                strEngModuleDesc = eCRDUtil.verifyNull(rsSearchResults.getString("module_desc"));
                strCompDesc = eCRDUtil.verifyNull(rsSearchResults.getString("comp_desc"));
                strRepairDesc = eCRDUtil.verifyNull(rsSearchResults.getString("repair_desc"));
                strRequestedBy = eCRDUtil.verifyNull(rsSearchResults.getString("user_name"));
                strRequesedDate = eCRDUtil.verifyNull(rsSearchResults.getString("req_date"));
                strFlg = eCRDUtil.verifyNull(rsSearchResults.getString("flg"));
                strCompCode = eCRDUtil.verifyNull(rsSearchResults.getString("comp_code"));
                strEngModuleCode = eCRDUtil.verifyNull(rsSearchResults.getString("module_code"));
                strRepairCode = eCRDUtil.verifyNull(rsSearchResults.getString("repair_code"));
                strRepairType = eCRDUtil.verifyNull(rsSearchResults.getString("repair_type"));
                arrlstTemp = new ArrayList();

                arrlstTemp.add(strEngModelCode);
                arrlstTemp.add(strEngModuleDesc);
                arrlstTemp.add(strCompDesc);
                //Making the link to the Repair description to take to the page showing the details about the repair
                String strLink =
                    "<A href=javascript:fnGetRepairDetails('"
                        + strEngModelCode
                        + "',"
                        + strEngModuleCode
                        + ",'"
                        + strCompCode
                        + "',"
                        + strRepairCode
                        + ",'"
                        + strFlg
                        + "','"
                        + strRepairType
                        + "')>"
                        + strRepairDesc
                        + "</A>";
                geAERepairTag = new GEAETag(strRepairDesc, strLink);

                arrlstTemp.add(geAERepairTag);

                arrlstTemp.add(strRequestedBy);
                arrlstTemp.add(strRequesedDate);
                //The image will be shown depending on whether the repair is new or old
                if (strFlg.equals("N"))
                {
                    strNoTagChange = "<IMG src='" +eCRDUtil.getBasePath()+ eCRDConstants.STRBASEIMGPATH + "icon_checkmark.gif' ALT='' width='20' height='20'></IMG>";
                    geNoTag = new GEAETag("", strNoTagChange);

                }
                else
                {
                    geNoTag = new GEAETag("", "");
                }
                arrlstTemp.add(geNoTag);
                rsFormattedRS.addRow(arrlstTemp);
            }
            rsFormattedRS.setColumnHeading(1, "Engine Model");
            rsFormattedRS.setColumnHeading(2, "Engine Module");
            rsFormattedRS.setColumnHeading(3, "Component");
            rsFormattedRS.setColumnHeading(4, "Repair Description");
            rsFormattedRS.setColumnHeading(5, "Requested By");
            rsFormattedRS.setColumnHeading(6, "Requested Date");
            rsFormattedRS.setColumnHeading(7, "New");
            rsFormattedRS.sort(1, true);
            
        }
        finally
        {
        }
        return rsFormattedRS;
    }

    private String removeRepair(HttpServletRequest request) throws Exception
    {
        eCRDUser objeCRDUser = null;
        eCRDDefaultCatalog objeCRDDefaultCatalog = null;
        eCRDEngineModel objeCRDEngineModel = null;
        eCRDModule objeCRDModule = null;
        eCRDComponent objeCRDComponent = null;
        eCRDRepair objeCRDRepair = null;
        String strEngModelCode = "";
        String strEngineModule = "";
        String strCompCode = "";
        String strRepairSeqId = "";
        String strRepairType = "";
        String strMessage = "";
        try
        {
            objeCRDUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser");
            strEngModelCode = (String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODELCODE);
            strEngineModule = (String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE);
            strCompCode = (String) eCRDUtil.getFromSession(request, eCRDConstants.STRCOMPONENTCODE);
            strRepairSeqId = (String) eCRDUtil.getFromSession(request, eCRDConstants.STRREPAIRSEQID);
            strRepairType = (String) eCRDUtil.getFromSession(request, "strRepairType");
            objeCRDDefaultCatalog = (eCRDDefaultCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
            objeCRDEngineModel = objeCRDDefaultCatalog.getEngineModel();
            objeCRDEngineModel.setCatalog(objeCRDDefaultCatalog);
            strEngModelCode = objeCRDDefaultCatalog.getEngineModel().getEngineModelCode();
            objeCRDModule = objeCRDEngineModel.getModule(strEngineModule);
            objeCRDComponent = objeCRDModule.getComponent(strCompCode);
            objeCRDRepair = objeCRDComponent.getRepair(strRepairSeqId, strRepairType);
            if (objeCRDUser == null)
            {
                throw new Exception("User Not Found");
            }
            System.out.println("Before call to remove Repair "+objeCRDUser.getRole());
            
            strMessage = objeCRDRepair.removeRepair(objeCRDUser.getUserId(), objeCRDUser.getRole());
            System.out.println("Before call to remove Repair "+objeCRDUser.getUserId());
            System.out.println("strMessage "+strMessage);
            if("REMOVE_COMP_RPR_SUCCESS".equals(strMessage)||"REMOVE_REPAIR_SUCCESS".equals(strMessage))
            {
                objeCRDRepair.setIsLastRepair("D");
                objeCRDComponent.setModule(objeCRDModule);
                objeCRDModule.setEngineModel(objeCRDEngineModel);
                objeCRDEngineModel.setCatalog(objeCRDDefaultCatalog);
                eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG,objeCRDDefaultCatalog);
            }
            
            setNewRepairInRequest(request);
            System.out.println("Before call to setNewRepairInRequest ");
            return strMessage;
        }
        finally
        {
        }
    }
    public void setNewRepairIntoCatalog(HttpServletRequest request) throws Exception
    {
        String strRepairType = "";
        try
        {
            strRepairType = eCRDUtil.verifyNull(request.getParameter("hdnRepairType"));
            if (eCRDConstants.STRINDIVIDUALREPAIR.equals(strRepairType))
            {
                createIndRepair(request);
            }
            else if (eCRDConstants.STRGROUPREPAIR.equals(strRepairType))
            {
                createGroupRepair(request);
            }
        }
        finally
        {
            strRepairType = null;
        }
    }

    private void setRepairObject(HttpServletRequest request) throws Exception
    {
        //      String strEngineModelCode = ""; // String variable to store Engine Model Code
        String strEngineModuleCode = ""; // String variable to store Engine Module Code
        String strComponentCode = "";
        //      String strEngineModelDesc = "";
        //      String strEngineModuleDesc = "";
        //      String strCompCode = "";
        String strRepairCode = "";
        //      String strCatalogType = "";
        String strRepairType = "";

        /*eCRDDefaultCatalog objeCRDDefaultCatalog = null;
        eCRDCustomerCatalog objeCRDCustomerCatalog = null;*/
        eCRDCatalog objeCRDCatalog = null;
        eCRDException objeCRDException = null;
        eCRDEngineModel objeCRDEngineModel = null;
        eCRDModule objeCRDModule = null;
        eCRDComponent objeCRDComponent = null;
        //      eCRDIndRepair objeCRDIndRepair           = null;
        eCRDRepair objeCRDRepair = null;

        try
        {
            strRepairCode = eCRDUtil.verifyNull(request.getParameter("hdnRepairCode"));
            strRepairType = eCRDUtil.verifyNull(request.getParameter("hdnRepairType"));
            strEngineModuleCode = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE));
            strComponentCode = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRCOMPONENTCODE));

            objeCRDCatalog = (eCRDCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
            if (objeCRDCatalog == null)
            {
                objeCRDException = new eCRDException();
                objeCRDException.setExcpId("CATALOG_NOT_SET");
                throw objeCRDException;
            }
            objeCRDEngineModel = objeCRDCatalog.getEngineModel();
            
            objeCRDEngineModel.setCatalog(objeCRDCatalog);
            objeCRDModule = objeCRDEngineModel.getModule(strEngineModuleCode);
            objeCRDComponent = objeCRDModule.getComponent(strComponentCode);

            objeCRDRepair = objeCRDComponent.getRepair(strRepairCode, strRepairType);

            objeCRDRepair.setECRDComponent(objeCRDComponent);
            objeCRDComponent.setModule(objeCRDModule);
            objeCRDModule.setEngineModel(objeCRDEngineModel);
            objeCRDEngineModel.setCatalog(objeCRDCatalog);
            eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDCatalog);
            
            eCRDUtil.loadInSession(request, "strFrom", "RepairPricing");
            eCRDUtil.loadInSession(request, eCRDConstants.STRREPAIRSEQID, strRepairCode);
            eCRDUtil.loadInSession(request, eCRDConstants.STRREPAIRTYPE, strRepairType);
            //eCRDUtil.loadInSession(request, "strForm", "MODIFY");
        }
        finally
        {
            //          strEngineModelCode = "";
            strEngineModuleCode = "";
            //          strEngineModuleDesc = "";
            //          strCompCode = "";
            /* objeCRDDefaultCatalog = null;
             objeCRDEngineModel       = null;
             objeCRDModule                 = null;
              objeCRDComponent           = null;*/
        }
    }
    private void addSpecialRepair(HttpServletRequest request) throws Exception
    {
        String strEngineModuleCode = ""; // String variable to store Engine Module Code
        String strComponentCode = "";
        String strRepairCode = "";
        String strRepairType = "";

        try
        {
            strEngineModuleCode = eCRDUtil.verifyNull(request.getParameter("selEngineModule"));
            strComponentCode = eCRDUtil.verifyNull(request.getParameter("selComponent"));

            if ("".equals(strEngineModuleCode))
            {
                strEngineModuleCode = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE));
            }
            if ("".equals(strComponentCode))
            {
                strComponentCode = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRCOMPONENTCODE));
            }

            
            /*this is to be decided when user clicks on the add special repair button in the special reapir tab*/
            eCRDUtil.loadInSession(request, "strFrom", "AddRepair");
            eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODULECODE, strEngineModuleCode);
            eCRDUtil.loadInSession(request, eCRDConstants.STRCOMPONENTCODE, strComponentCode);

        }
        finally
        {

            strEngineModuleCode = "";

            /* objeCRDDefaultCatalog = null;
             objeCRDEngineModel       = null;
             objeCRDModule                 = null;
              objeCRDComponent           = null;*/
        }
    }
    private void removeRepairs(HttpServletRequest request) throws Exception
    {
        String          strEngineModuleCode   = null; // String variable to store Engine Module Code
        String          strComponentCode      = null;
        eCRDCatalog     objeCRDDefaultCatalog = null;
        eCRDEngineModel objeCRDEngineModel    = null;
        eCRDModule      objeCRDModule         = null;
        eCRDComponent   objeCRDComponent      = null;
        try
        {
            strEngineModuleCode = eCRDUtil.verifyNull(request.getParameter("selEngineModule"));
            strComponentCode = eCRDUtil.verifyNull(request.getParameter("selComponent"));

            if ("".equals(strEngineModuleCode))
            {
                strEngineModuleCode = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE));
            }
            if ("".equals(strComponentCode))
            {
                strComponentCode = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRCOMPONENTCODE));
            }

            /*this is to be decided when user clicks on the add special repair button in the special reapir tab*/
            objeCRDDefaultCatalog = (eCRDCatalog)eCRDUtil.getFromSession(request,eCRDConstants.STRCATALOG);
            objeCRDEngineModel    = objeCRDDefaultCatalog.getEngineModel();
            objeCRDModule         = objeCRDEngineModel.getModule(strEngineModuleCode);    
            objeCRDComponent      = objeCRDModule.getComponent(strComponentCode); 
            objeCRDComponent.removeRepairs();
            
            objeCRDComponent.setModule(objeCRDModule);
            objeCRDModule.setEngineModel(objeCRDEngineModel);
            objeCRDEngineModel.setCatalog(objeCRDDefaultCatalog);
            eCRDUtil.loadInSession(request,eCRDConstants.STRCATALOG,objeCRDDefaultCatalog);
        }
        finally
        {
            strEngineModuleCode   = null;
            objeCRDDefaultCatalog = null;
            objeCRDEngineModel    = null;
            objeCRDModule         = null;
            objeCRDComponent      = null;
        }
    }
    private void setSpecialNewRepairInRequest(HttpServletRequest request) throws Exception
    {

        String strEngineModel = "";
        String strEngineModule = "";
        String strComponentCode = "";
        String strCompType = "";
        String strAction = "";
        String strCatalogId = "";
        eCRDCatalog objeCRDCatalog = null;
        eCRDSearchBean objeCRDSearchBean = null;
        ArrayList arrlstOutParam = null;
        GEAEResultSet rsRepairs = null;
        eCRDUser objeCRDUser = null;

        try
        {

            objeCRDSearchBean = new eCRDSearchBean();
            rsRepairs = new GEAEResultSet();
            objeCRDCatalog = (eCRDCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
        
            objeCRDUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser");

            strEngineModel = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODELCODE));
        
            strCatalogId = eCRDUtil.verifyNull(objeCRDCatalog.getCatalogSeqId());
        
            if("".equals(strEngineModel))
            {
                strEngineModel = objeCRDCatalog.getEngineModel().getEngineModelCode(); 
            }

            strEngineModule = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE));
            strComponentCode = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRCOMPONENTCODE));
            strCompType = "1";
            strAction = eCRDUtil.verifyNull(eCRDConstants.getActionId("eCRD_SPECIAL_REPAIR_LISTING"));

            /*passin null as catalog seq id so that default catalog will be considered by the plsql procedure*/
            arrlstOutParam = objeCRDSearchBean.getRepairListing(strCatalogId, strEngineModel, strEngineModule, strCompType, strComponentCode, strAction,eCRDUtil.verifyNull(objeCRDUser.getRole()));
            rsRepairs = (GEAEResultSet) arrlstOutParam.get(0);
            request.setAttribute("rsRepairs", rsRepairs);
        }
        finally
        {
            strEngineModel= null;
            strEngineModule = null;
            strComponentCode = null;
            strCompType = null;
            strAction = null;
            objeCRDSearchBean = null;
            arrlstOutParam = null;
            rsRepairs = null;
        }
    }
    private void updatePriceOverWriteInd(HttpServletRequest request) throws Exception
    {
        eCRDRepair objeCRDRepair  = null;
        eCRDUser objeCRDUser = null;
        eCRDModule objeCRDModule = null;
        eCRDIndRepair objeCRDIndRepair=null;
        eCRDCatalog objeCRDCatalog = null;
        eCRDComponent objeCRDComponent = null;
        eCRDEngineModel objeCRDEngineModel= null;
        eCRDRepairPricing objeCRDRepairPricing=null;
        eCRDGroupedRepair objeCRDGroupedRepair = null;
 
        String strCompCode = null;
        String strRepairType = null;
        String strEngineModel = null;
        String strEngineModule = null;
        String strRepairCode = null;

        ArrayList arrlstInParam = null;
        String strAction = null;
        try
        {
            arrlstInParam = new ArrayList();
            objeCRDUser = (eCRDUser)eCRDUtil.getFromSessionApp(request,"objeCRDUser");
            strEngineModel = (String)eCRDUtil.getFromSession(request,eCRDConstants.STRENGINEMODELCODE);
            strEngineModule = (String)eCRDUtil.getFromSession(request,eCRDConstants.STRENGINEMODULECODE);
            strCompCode = (String)eCRDUtil.getFromSession(request,eCRDConstants.STRCOMPONENTCODE);
   
            strRepairCode =(String)eCRDUtil.getFromSession(request, "strRepairCode");
    
            objeCRDCatalog = (eCRDCustomerCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);

            objeCRDEngineModel  = objeCRDCatalog.getEngineModel();
            objeCRDModule = objeCRDEngineModel.getModule(strEngineModule);
            objeCRDComponent = objeCRDModule.getComponent(strCompCode); 
    
            strRepairCode  = (String)eCRDUtil.getFromSession(request,eCRDConstants.STRREPAIRSEQID);
            strRepairType = (String)eCRDUtil.getFromSession(request,"strRepairType");
            if(strRepairType!=null)
            {
               objeCRDRepair=objeCRDComponent.getRepair(strRepairCode,strRepairType);      
            }
    
            arrlstInParam.add(0,strRepairCode);
            arrlstInParam.add(1,objeCRDCatalog.getCatalogSeqId()+"");
    
            strAction = (String)eCRDUtil.verifyNull(request.getParameter("hdnScreenAction"));
                            
            objeCRDRepairPricing = objeCRDRepair.getObjRepairPricing();
            objeCRDRepairPricing.setFlgPriceOverWriteInd(false);
    
            objeCRDRepairPricing.updatePriceOverWriteInd(strAction,arrlstInParam);
    
            eCRDUtil.loadInSession(request,eCRDConstants.STRCATALOG,objeCRDCatalog);
        }
        finally
        {
        }
    }
    
    /**
     * This Method is used to add the selected Repair in Customer Specific Catalog.
     * @param request
     * @param String 
     * @return void
     * thorws Exception
     */
    private void addRepairtoCSC(HttpServletRequest request, String strActionId) throws Exception
    {
        String strRepairId = null;
        String strCatalogId = null;
        String strDefaultCatalogId = null;
        String strMessage = null;
        String strRepairstobeadded[] = null;
        eCRDCatalog objeCRDCatalog = null;
        eCRDUser objeCRDUser = null;
        String strCompCode = null;
        String strEngineModel = null;
        String strEngineModule = null;
        int intCount = 0;
        eCRDSearchBean objeCRDSearchBean = null;
        GEAEResultSet rsRepairs = null;
        ArrayList arrlstOutParam = null;
        String strUserId = null;
        try
        {
            strRepairId = "";
            arrlstOutParam = new ArrayList();
            rsRepairs = new GEAEResultSet();
            objeCRDUser = (eCRDUser)eCRDUtil.getFromSessionApp(request,"objeCRDUser");
            strUserId = eCRDUtil.verifyNull(objeCRDUser.getUserId());
            strEngineModel = (String)eCRDUtil.getFromSession(request,eCRDConstants.STRENGINEMODELCODE);
            strEngineModule = (String)eCRDUtil.getFromSession(request,eCRDConstants.STRENGINEMODULECODE);
            strCompCode = (String)eCRDUtil.getFromSession(request,eCRDConstants.STRCOMPONENTCODE);
            
            objeCRDCatalog = (eCRDCustomerCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);

            strCatalogId = objeCRDCatalog.getCatalogSeqId();
            strDefaultCatalogId = objeCRDCatalog.getCurrentDefaultSeqId(strEngineModel);
            strRepairstobeadded = request.getParameterValues("chkRepairSelect");
            
            if(strRepairstobeadded != null)
            {
                intCount = strRepairstobeadded.length;
                for (int intI =0; intI<intCount; intI++)
                {
                    strRepairId = strRepairId + strRepairstobeadded[intI]+eCRDConstants.STRCOLUMNDELIM; 
                }
            }
            objeCRDSearchBean = new eCRDSearchBean();
            strMessage = objeCRDSearchBean.addRepairtoCSC(strRepairId,strCatalogId,strDefaultCatalogId,strActionId,strUserId);
            request.setAttribute("strMessage",strMessage);
            
            strActionId = eCRDConstants.getActionId("eCRD_DEFAULT_REPAIR_LISTING");
            arrlstOutParam = objeCRDSearchBean.getDefaultRepairListing(strCatalogId, strEngineModel, strEngineModule, "1", strCompCode, strActionId);
            
            rsRepairs = (GEAEResultSet) arrlstOutParam.get(0);
        
            request.setAttribute("rsRepairs", rsRepairs);
        }
        finally
        {
            strRepairId = null;
            strCatalogId = null;
            strDefaultCatalogId = null;
            strMessage = null;
            strRepairstobeadded = null;
            objeCRDCatalog = null;
            strCompCode = null;
            strEngineModel = null;
            strEngineModule = null;
            intCount = 0;
        }
    }
}