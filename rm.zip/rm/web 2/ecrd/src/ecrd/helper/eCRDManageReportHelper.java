//Source file: D:\\ECRD\\SOURCE CODE\\ecrd\\helper\\eCRDManageReportHelper.java
/**
 * Module       : eCRDManageReportHelper.java
 * Author       : Patni Offshore
 * Project      : eCRD
 * Date Written : October 2004
 * Security     : Classified/Unclassified
 * Restrictions : GE PROPRIETORY INFORMATION, FOR GE USE ONLY
 *
 *     ***************************************************************
 *     *          Copyright (2000) with all rights reserved          *
 *     *                  General Electric Company                   *
 *     ***************************************************************
 * Description  :  This class has methods to get the Master Tables Data.
 * Revision Log  (mm/dd/yyyy     Initials    description)
 * -------------------------------------------------------------------
 * 					10/20/2004     GM    Description
 * -------------------------------------------------------------------
 * *               31/05/2006 Patni Phase 1 Requirement Updations  
 */
package ecrd.helper;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import ecrd.common.eCRDAppSecurityUtil;
import ecrd.common.eCRDBusinessBean;
import ecrd.common.eCRDCommand;
import ecrd.common.eCRDDataBean;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDUtil;
import geae.dao.GEAEResultSet;
import geae.util.format.GEAETag;
import geae.util.format.GEAETagNoData;

import ecrd.biz.eCRDCatalog;
import ecrd.exception.eCRDException;
import ecrd.biz.eCRDUser;

public class eCRDManageReportHelper implements eCRDCommand
{

	public eCRDManageReportHelper()
	{
	}

	/**
	* Based "action" attribute from the request, this function calls the appropriate
	* private functions in this class.
	* Also sets the received request to member variable.
	* @param request
	*/

	public String perform(HttpServletRequest request) throws Exception
	{
		String strReturnURL = "";
		String strScreenAction = "";
		try
		{
			strScreenAction = eCRDUtil.verifyNull(request.getParameter("hdnScreenAction"));

			if ("".equalsIgnoreCase(strScreenAction))
			{
				eCRDUtil.clearSession(request);
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-compYearlyCatlg";
			}
			else if(eCRDConstants.getActionId("eCRD_SEARCH_CATALOG").equalsIgnoreCase(strScreenAction))
			{
				searchCatalog(request);
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-compYearlyCatalogResults";
			}
			/*else if (eCRDConstants.getActionId("eCRD_ADHOC_REPORT_SEL_ENG").equalsIgnoreCase(strScreenAction))
			{
				eCRDUtil.clearSession(request);
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-adhocSelectEngine";
			}*/
			else if(eCRDConstants.getActionId("eCRD_ADHOC_REPORT").equalsIgnoreCase(strScreenAction))
			{
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-adhocRepairRpt";
			}
			else if(eCRDConstants.getActionId("eCRD_ADHOC_SEQ").equalsIgnoreCase(strScreenAction))
			{
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-adhocSeqCols";
			}
			//Added by Bora
			else if(eCRDConstants.getActionId("eCRD_EN_ADHOC_SEQ").equalsIgnoreCase(strScreenAction))
			{
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-enAdhocSeqCols";
			}
			//End Bora
			//Adding Customer Adhoc Repair Reports started DES1121903 sujitha
			else if(eCRDConstants.getActionId("eCRD_CUSTADHOC_REPORT").equalsIgnoreCase(strScreenAction))
			{
				
				//System.out.println("First Time Page Load");
				eCRDUtil.removeFromSession(request,"ActiveInd");
				eCRDUtil.removeFromSession(request,"strCustName");
				eCRDUtil.removeFromSession(request,"eCRDCustomerCataloglist");
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-custadhocRepairRpt";
			}
			else if(eCRDConstants.getActionId("eCRD_CUSTADHOC_SEQ").equalsIgnoreCase(strScreenAction))
			{
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-custadhocSeqCols";
			}
			else if(eCRDConstants.getActionId("eCRD_EN_CUSTADHOC_SEQ").equalsIgnoreCase(strScreenAction))
			{
				//System.out.println("inside the eCRD_EN_CUSTADHOC_SEQ please check.....");
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-encustadhocSeqCols";
			}
		
			// Adding Customer Adhoc Repair Reports ended 
			
			/*Cust adhoc changes --Prathima*/
			
			else if(eCRDConstants.getActionId("eCRD_CUSTOMER_CATALOG_LISTING_RC").equals(strScreenAction))
			{
		    	getCustomeCatalogList(request);
		        //strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-custadhocRepairRpt";
		    	String strCustomer="";
		    	HttpSession session = request.getSession();
		    	strCustomer = eCRDUtil.verifyNull(request.getParameter("txtCustCode"));
		    	if(!strCustomer.equals(""))
		    	{
		    		eCRDUtil.loadInSession(request, "strCustName", strCustomer);
		    	}
	    		
	    	//
	    		
		        strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-custadhocRepairCatDetails";
			}
			
			/*Cust adhoc changes end--Prathima*/
			
			else if(eCRDConstants.getActionId("eCRD_SHOW_ENG_REV").equalsIgnoreCase(strScreenAction))
			{
				eCRDUtil.clearSession(request);
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-engineRevenue";
			}
			/*else if(eCRDConstants.getActionId("eCRD_GENERATE_ADHOC_REPORT").equalsIgnoreCase(strScreenAction))
			{
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-adhocSeqCols";
			}*/
			return strReturnURL;
		}
		finally
		{
		}
	}

	
	/*Cust Adhoc changes --Prathima*/
	private void getCustomeCatalogList (HttpServletRequest request) throws Exception
	{

		eCRDCatalog objeCRDCatalog = null;
		
		eCRDBusinessBean objeCRDBusinessBean = null;
		eCRDDataBean objeCRDDataBean = null;
		 HttpSession session = request.getSession();
		String strEngineModelId = "";
		String strCustomerCode = "";
		String strActionId = "";
		//String strCustomer = "";
		
		String strCustCatAvtiveInd = null;
		GEAEResultSet rsCustomerCatalog = null;
		
		
		ArrayList arrLstInParam = null;

		try
		{
			
			strActionId = eCRDConstants.getActionId("eCRD_CUSTOMER_CATALOG_LISTING_RC");
			strEngineModelId = eCRDUtil.verifyNull(request.getParameter("lstEngModel"));
            strCustomerCode=eCRDUtil.verifyNull(request.getParameter("hdnCustCode")); 
			
            
            strCustCatAvtiveInd =  eCRDUtil.verifyNull(request.getParameter("txtCustActiveInd"));
            //System.out.println("Active Status value"+strCustCatAvtiveInd);
            
           
            
            //System.out.println("SANTOSH IN TEST for get cust_catalog"+strEngineModelId+"---"+strCustomerCode);
			objeCRDBusinessBean = new eCRDBusinessBean();
			objeCRDDataBean = new eCRDDataBean();
			rsCustomerCatalog = new GEAEResultSet();
			arrLstInParam = new ArrayList();

			

			arrLstInParam.add(strEngineModelId);
			arrLstInParam.add(strCustomerCode);

			arrLstInParam.add(strCustCatAvtiveInd);

			rsCustomerCatalog = objeCRDBusinessBean.populateCustomerCatalogList(strActionId, arrLstInParam);


			rsCustomerCatalog = formatCustomerCatalogResultSet(rsCustomerCatalog);


			objeCRDDataBean.setCache(rsCustomerCatalog);
			eCRDUtil.loadInSession(request, "eCRDCustomerCataloglist", objeCRDDataBean);
			
		
			if(strCustCatAvtiveInd.equals("Y"))
            {
            	  
                  session.setAttribute("ActiveInd", strCustCatAvtiveInd);
            }
			else 
            {
            	strCustCatAvtiveInd="N";
            	 session.setAttribute("ActiveInd", strCustCatAvtiveInd);
            	
            }

		
			
		
			//
			/*strCustomer = eCRDUtil.verifyNull(request.getParameter("txtCustCode"));
    		eCRDUtil.loadInSession(request,"strCustomer",strCustomer);*/
			
			//
			
			
		}
		finally
		{
			
			objeCRDBusinessBean = null;
			objeCRDDataBean = null;
			rsCustomerCatalog = null;
			strEngineModelId = null;
			strCustomerCode = null;
			strActionId = null;			
			strCustomer ="";
			arrLstInParam = null;
		}
	}

/* Customer adhoc changes end -Prathima*/
	
	

	/*cust adhoc changes Prathima*/

	//formatCustomerCatalogResultSet
	    private GEAEResultSet formatCustomerCatalogResultSet
	 (GEAEResultSet rsSearchResults) throws Exception
		{
			GEAEResultSet rsFormattedRS = null;
			ArrayList arrlstTemp = null;
			String strCheckCatalog = null;
			GEAETag geAETag = null;

			try
			{
				rsFormattedRS = new GEAEResultSet();
				rsSearchResults.setCurrentRow(0);


				

				while (rsSearchResults.next())
				{


					strCheckCatalog = rsSearchResults.getString("cat_seq_id") + "^" 
					+ rsSearchResults.getString("Engine_Desc") + "^" + rsSearchResults.getString("Customer_name") +"^"
					+ rsSearchResults.getString("Description");
					arrlstTemp = new ArrayList();
						geAETag =
							new GEAETag(
								"",
								"<INPUT TYPE='checkbox' NAME='checkBox' VALUE='" + strCheckCatalog +"'>");
		
						arrlstTemp.add(geAETag);                                     		//1
						arrlstTemp.add(rsSearchResults.getString("Catalog_number"));   		//2
						arrlstTemp.add(rsSearchResults.getString("Engine_Desc")); 			//3
						arrlstTemp.add(rsSearchResults.getString("Customer_name"));			//4
						arrlstTemp.add(rsSearchResults.getString("Contract_number"));		//5
						arrlstTemp.add(rsSearchResults.getString("Discount"));				//6
						arrlstTemp.add(rsSearchResults.getString("Start_Date"));			//7
						//arrlstTemp.add(rsSearchResults.getString("Sortable_Start_Date"));	//8
						arrlstTemp.add(rsSearchResults.getString("End_Date"));				//9
						//arrlstTemp.add(rsSearchResults.getString("Sortable_End_Date"));		//10
						arrlstTemp.add(rsSearchResults.getString("Description"));			//11
						arrlstTemp.add(rsSearchResults.getString("cat_type"));				//12
				
					
					rsFormattedRS.addRow(arrlstTemp);
					arrlstTemp = null;
					geAETag = null;
					strCheckCatalog = null;

				}
				
				rsFormattedRS.setColumnHeading(1, "Select");
				rsFormattedRS.setColumnHeading(2, "Catalog Number");
				rsFormattedRS.setColumnHeading(3, "Engine Model");
				rsFormattedRS.setColumnHeading(4, "Customer Name");
				rsFormattedRS.setColumnHeading(5, "Contract Number");
				rsFormattedRS.setColumnHeading(6, "Discount");
				rsFormattedRS.setColumnHeading(7, "Start Date");
				//rsFormattedRS.setColumnHeading(8, "Sortable Start Date");
				rsFormattedRS.setColumnHeading(8, "End Date");
				//rsFormattedRS.setColumnHeading(10, "Sortable End Date");
				rsFormattedRS.setColumnHeading(9, "Description");
				rsFormattedRS.setColumnHeading(10, "Catalog Type");

				
					rsFormattedRS.sort(1, true);
				

				return rsFormattedRS;
			}
			finally
			{
				rsFormattedRS = null;
				arrlstTemp = null;
				geAETag = null;
				strCheckCatalog = null;
			}

		}
		
	/*cust adhoc changes end --Prathima*/

	
	
	private void searchCatalog (HttpServletRequest request) throws Exception
	{
		String strEngineModel = null;
		String strStartDay = null;
		String strStartMonth = null;
		String strStartYear = null;
		String strEndDay = null;
		String strEndMonth = null;
		String strEndYear = null;
		String strStartDate = null;
		String strEndDate = null;

        String strRprEffDay = null;
        String strRprEffMonth = null;
        String strRprEffYear = null;
        String strRprEffDate = null;
        String strMessage = null;

        String strCustomerCode = null;
		String strEngModelText = null;
		String strDisplayStartDate = null;
		String strDisplayEndDate = null;
		String strOnlyDefault = null;
		String strReportType = null;
		String strCatalogNum = null;
		ArrayList arrlstInParam = null;
        ArrayList arrlstResult = null;
		eCRDBusinessBean objeCRDBusinessBean = null;
		GEAEResultSet rsCatalogs = null;
		eCRDDataBean objeCRDDataBean = null;
		GEAEResultSet rsFormattedRs = null;

		try
		{
			arrlstInParam = new ArrayList();
			objeCRDBusinessBean = new eCRDBusinessBean();
			objeCRDDataBean = new eCRDDataBean();
			strEngineModel = eCRDUtil.verifyNull(request.getParameter("lstEngModel"));
			strStartDay = eCRDUtil.verifyNull(request.getParameter("sel_man_StartDate_DD"));
			strStartMonth = eCRDUtil.verifyNull(request.getParameter("sel_man_StartDate_MM"));
			strStartYear = eCRDUtil.verifyNull(request.getParameter("sel_man_StartDate_YYYY"));
			strEndDay = eCRDUtil.verifyNull(request.getParameter("sel_man_EndDate_DD"));
			strEndMonth = eCRDUtil.verifyNull(request.getParameter("sel_man_EndDate_MM"));
			strEndYear = eCRDUtil.verifyNull(request.getParameter("sel_man_EndDate_YYYY"));
            //Start For Repair Effective Date on 08Nov2005 By Rajiv
            strRprEffDay = eCRDUtil.verifyNull(request.getParameter("sel_repair_eff_DD"));
            strRprEffMonth = eCRDUtil.verifyNull(request.getParameter("sel_repair_eff_MM"));
            strRprEffYear = eCRDUtil.verifyNull(request.getParameter("sel_repair_eff_YYYY"));
            //Start For Repair Effective Date on 08Nov2005 By Rajiv

            strStartDate = eCRDUtil.verifyNull(eCRDUtil.formatDate(strStartDay,strStartMonth,strStartYear));
			strEndDate = eCRDUtil.verifyNull(eCRDUtil.formatDate(strEndDay,strEndMonth,strEndYear));
            strRprEffDate = eCRDUtil.verifyNull(eCRDUtil.formatDate(strRprEffDay,strRprEffMonth,strRprEffYear));

			strCustomerCode = eCRDUtil.verifyNullNoTrim(request.getParameter("hdnCustCode"));
			strEngModelText = eCRDUtil.verifyNull(request.getParameter("hdnEngineText"));
			strReportType =  eCRDUtil.verifyNull(request.getParameter("hdnReportType"));
			strCatalogNum =  eCRDUtil.verifyNull(request.getParameter("txtCatalogNum"));
			if("".equals(strCustomerCode))
			{
				strCustomerCode = eCRDAppSecurityUtil.deleteSplChars(eCRDUtil.verifyNullNoTrim(request.getParameter("txtCustCode")));
			}

			if(!"".equals(strStartDay))
			{
				strDisplayStartDate = eCRDUtil.convertToDisplayDateFormat(strStartDate);
			}
			if(!"".equals(strEndDay))
			{
				strDisplayEndDate = eCRDUtil.convertToDisplayDateFormat(strEndDate);
			}
			if(strReportType.equals(eCRDConstants.STRENGREVYIELD))
			{
				strOnlyDefault="D";
			}
			else
			{
				strOnlyDefault="";
			}
			arrlstInParam.add(strEngineModel);
			arrlstInParam.add(strStartDate);
			arrlstInParam.add(strEndDate);
			arrlstInParam.add(strCustomerCode);
			arrlstInParam.add(strOnlyDefault);
			arrlstInParam.add(strCatalogNum);
            arrlstInParam.add(strRprEffDate);


            eCRDUtil.loadInSession(request, "strRprEffDate", strRprEffDate);
			//rsCatalogs = objeCRDBusinessBean.populateCatalogs(arrlstInParam);
            arrlstResult = new ArrayList();

            arrlstResult =  objeCRDBusinessBean.populateCatalogs(arrlstInParam);

            rsCatalogs = (GEAEResultSet)arrlstResult.get(0);

			rsFormattedRs = formatCatalogListForRprEffectiveDate(rsCatalogs, request);
			objeCRDDataBean.setCache(rsFormattedRs);

            strMessage = (String)arrlstResult.get(1);

            eCRDUtil.loadInSession(request, "strMessage", strMessage);
            eCRDUtil.loadInSession(request, "eCRDCatalogsList", objeCRDDataBean);
			eCRDUtil.loadInSession(request,"Engine",strEngModelText);
			eCRDUtil.loadInSession(request,"StartDate",strDisplayStartDate);
			eCRDUtil.loadInSession(request,"EndDate",strDisplayEndDate);
		}
		finally
		{
			strEngineModel = null;
			strStartDay = null;
			strStartMonth = null;
			strStartYear= null;
			strEndDay= null;
			strEndMonth = null;
			strEndYear = null;
			strStartDate = null;
			strEndDate= null;
			strCustomerCode = null;
			arrlstInParam = null;
			objeCRDBusinessBean = null;
			rsCatalogs = null;
			objeCRDDataBean = null;
			rsFormattedRs = null;
		}
	}

	private GEAEResultSet formatCatalogList(GEAEResultSet rsSearchResults) throws Exception
	{
		GEAEResultSet rsFormattedRS = null;
		ArrayList arrlstTemp = null;
		GEAETagNoData tagRadio = null;
		String strRadioValue = null;
		String strTempTagName = null;
		GEAETag geAETag = null;
		String strCatalogNumber = null;
		try
		{
			rsFormattedRS = new GEAEResultSet();
			rsSearchResults.setCurrentRow(0);
//        19-05-2006 patni checking null value Begin 			
            if(rsSearchResults != null)
            {
//              19-05-2006 patni checking null value End             
                while(rsSearchResults.next())
			{
				arrlstTemp = new ArrayList();
				strTempTagName = eCRDUtil.replaceQuote(rsSearchResults.getString("cat_seq_id"), "\"");
				strRadioValue = "" + eCRDUtil.replaceQuoteForJS(strTempTagName);
				strCatalogNumber = eCRDUtil.verifyNull(rsSearchResults.getString("Catalog_number"));
				tagRadio = new GEAETagNoData("<INPUT TYPE=\"radio\" NAME=\"radCatalog\" VALUE=\"" + strRadioValue + "\" onClick = \"javascript:fnGetCatalogValue('" + strRadioValue + "','" + strCatalogNumber + "',document.frmCompYearlyCatResults)\" ");
				arrlstTemp.add(tagRadio);
				arrlstTemp.add(rsSearchResults.getString("Engine_Model"));
				geAETag = new GEAETag(rsSearchResults.getString("Sortable_Start_Date"), rsSearchResults.getString("Start_Date"));
				arrlstTemp.add(geAETag);
				geAETag = new GEAETag(rsSearchResults.getString("Sortable_End_Date"), rsSearchResults.getString("End_Date"));
				arrlstTemp.add(geAETag);
				arrlstTemp.add(rsSearchResults.getString("Description"));
				rsFormattedRS.addRow(arrlstTemp);
				arrlstTemp = null;
			}
//              19-05-2006 patni checking null value Begin 
            } // end if 
//          19-05-2006 patni checking null value End
            
			rsFormattedRS.setColumnHeading(1, "Select");
			rsFormattedRS.setColumnHeading(2, "Catalog Number");
			rsFormattedRS.setColumnHeading(3, "Start Date");
			rsFormattedRS.setColumnHeading(4, "End  Date");
			rsFormattedRS.setColumnHeading(5, "Description");
			rsFormattedRS.sort(2, true);
			return rsFormattedRS;
		}
		finally
		{
			rsFormattedRS = null;
			arrlstTemp = null;
			tagRadio = null;
			strRadioValue = null;
			strTempTagName = null;
			geAETag = null;
			strCatalogNumber = null;
		}
	}

//Rajiv

    private GEAEResultSet formatCatalogListForRprEffectiveDate(GEAEResultSet rsSearchResults, HttpServletRequest request) throws Exception
    {
        GEAEResultSet rsFormattedRS = null;
        ArrayList arrlstTemp = null;
        GEAETagNoData tagRadio = null;
        String strRadioValue = null;
        String strTempTagName = null;
        GEAETag geAETag = null;
        String strCatalogNumber = null;
        String strRprEffDate = null;
        try
        {
            rsFormattedRS = new GEAEResultSet();
            rsSearchResults.setCurrentRow(0);
//          19-05-2006 patni checking null value Begin 
            if (rsSearchResults != null)
            {
//          19-05-2006 patni checking null value Begin             
            while(rsSearchResults.next())
            {
                strRprEffDate = eCRDUtil.verifyNull((String)eCRDUtil.getFromSession(request, "strRprEffDate"));
                arrlstTemp = new ArrayList();
                strTempTagName = eCRDUtil.replaceQuote(rsSearchResults.getString("cat_seq_id"), "\"");
                strRadioValue = "" + eCRDUtil.replaceQuoteForJS(strTempTagName);
                strCatalogNumber = eCRDUtil.verifyNull(rsSearchResults.getString("Catalog_number"));
                tagRadio = new GEAETagNoData("<INPUT TYPE=\"radio\" NAME=\"radCatalog\" VALUE=\"" + strRadioValue + "\" onClick = \"javascript:fnGetCatalogValueForRprEffDate('" + strRadioValue + "','" + strCatalogNumber + "','" + rsSearchResults.getString("CATALOG_END_DATE") +"','" + strRprEffDate + "',document.frmCompYearlyCatResults)\" ");
                arrlstTemp.add(tagRadio);
                arrlstTemp.add(rsSearchResults.getString("Engine_Model"));
                geAETag = new GEAETag(rsSearchResults.getString("Sortable_Start_Date"), rsSearchResults.getString("Start_Date"));
                arrlstTemp.add(geAETag);
                geAETag = new GEAETag(rsSearchResults.getString("Sortable_End_Date"), rsSearchResults.getString("End_Date"));
                arrlstTemp.add(geAETag);
                arrlstTemp.add(rsSearchResults.getString("Description"));
                rsFormattedRS.addRow(arrlstTemp);
                arrlstTemp = null;
            }
//          19-05-2006 patni checking null value Begin             
            } // end if 
//          19-05-2006 patni checking null value End            
            rsFormattedRS.setColumnHeading(1, "Select");
            rsFormattedRS.setColumnHeading(2, "Catalog Number");
            rsFormattedRS.setColumnHeading(3, "Start Date");
            rsFormattedRS.setColumnHeading(4, "End  Date");
            rsFormattedRS.setColumnHeading(5, "Description");
            rsFormattedRS.sort(2, true);
            return rsFormattedRS;
        }
        finally
        {
            rsFormattedRS = null;
            arrlstTemp = null;
            tagRadio = null;
            strRadioValue = null;
            strTempTagName = null;
            geAETag = null;
            strCatalogNumber = null;
        }
    }

}