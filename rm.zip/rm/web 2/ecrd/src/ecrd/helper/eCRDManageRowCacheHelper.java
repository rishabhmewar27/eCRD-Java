//Source file: D:\\ECRD\\SOURCE CODE\\ecrd\\helper\\eCRDManageRowCacheHelper.java

package ecrd.helper;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import ecrd.biz.eCRDCatalog;
import ecrd.biz.eCRDCustomer;
import ecrd.biz.eCRDCustomerCatalog;
import ecrd.biz.eCRDDefaultCatalog;
import ecrd.biz.eCRDEngineModel;
import ecrd.biz.eCRDUser;
import ecrd.common.eCRDAppSecurityUtil;
import ecrd.common.eCRDBusinessBean;
import ecrd.common.eCRDCommand;
import ecrd.common.eCRDDBMediator;
import ecrd.common.eCRDDataBean;
import ecrd.exception.eCRDException;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDLoadMaster;
import ecrd.util.eCRDSearchBean;
import ecrd.util.eCRDUtil;
import geae.dao.GEAEResultSet;
import geae.util.format.GEAETag;

public class eCRDManageRowCacheHelper implements eCRDCommand
{
	private HttpServletRequest request = null;



	public eCRDManageRowCacheHelper()
	{


	}

	/**
	 * Based "action" attribute from the request, this function calls the appropriate
	 * private functions in this class.
	 * Also sets the received request to member variable.
	 * @param request
	 */
	public String perform(HttpServletRequest request) throws Exception
	{

		String strReturnURL = "";
		String strScreenAction = "";


		try
		{

			strScreenAction = eCRDUtil.verifyNull(request.getParameter("hdnScreenAction"));
			if ((eCRDConstants.getActionId("eCRD_VIEW_MODIFY_CATALOG")).equals(strScreenAction))
			{
				eCRDUtil.clearSession(request);
				/* This is added new For Price Change Listing Report Yearly*/
				if(eCRDConstants.STRPRICECHANGELISTINGREPORTYRL.equals(eCRDUtil.verifyNull(request.getParameter("hdnReport"))))
				{
					strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-priceListChangesYrs";
				}
				else
				{
					strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-SearchEngineCatalog";
				}
			}
			/*THIS MEHOD GETS THE RESULT OF THE ENGINE CATALOG SEARCH IN RC FORMAT*/
			else if ((eCRDConstants.getActionId("eCRD_SHOW_SEARCH_RESULTS")).equals(strScreenAction))
			{
				getCatalogList(request);
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-ViewEngineCatalog";
			}
			//Ehren start
			/*This is added new for Search Catalog */
			else if ((eCRDConstants.getActionId("eCRD_SEARCH_CATALOG")).equals(strScreenAction))
			{
				eCRDUtil.clearSession(request);
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-SearchCatalog";
			}
			/*THIS MEHOD GETS THE RESULT OF THE ENGINE CATALOG SEARCH IN RC FORMAT*/
			else if ((eCRDConstants.getActionId("eCRD_SHOW_SEARCH_RESULTS_FOR_ADD_MODIFY_CSC")).equals(strScreenAction))
			{
				getCatalogList(request);
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-ShowSearchResultsForAddModifyCSC";
			}
			/*THIS METHOD DISPLAS THE COMPONENT LISTING TABS PAGE*/
			else if ((eCRDConstants.getActionId("eCRD_COMP_LIST_ADD_MODIFY_CSC")).equals(strScreenAction))
			{
				createCatalogObj(request);
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-CompListingAddModifyCSC";
			}
			else if ((eCRDConstants.getActionId("eCRD_DEFAULT_COMPONENT_LISTING_RC")).equals(strScreenAction))
			{
					getDefaultComponentList(request);
					eCRDUtil.loadInSession(request, eCRDConstants.STRCOMPONENTCODE, "");
					strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-CompListingAddModifyCSC";
			}
			else if(eCRDConstants.getActionId("eCRD_COMP_REPAIR_LISTING_FROM_DEFAULT").equals(strScreenAction))
			{
				getRepairListing(request);
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-CompListingAddModifyCSCforRepair";
			}
			//Ehren end
			/* This is added new For Price Change Listing Report*/
			/*THIS MEHOD GETS THE RESULT OF THE ENGINE CATALOG SEARCH IN RC FORMAT*/
			else if ((eCRDConstants.getActionId("eCRD_SHOW_SEARCH_RESULTS_FOR_REPORT")).equals(strScreenAction))
			{
				getCatalogList(request);
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-ViewEngineCatalogForReport";
			}
			/*THIS METHOD DISPLAYS THE MODIFY ENGINE CATALOG PAGE*/
			else if ((eCRDConstants.getActionId("eCRD_MODIFY_CATALOG")).equals(strScreenAction))
			{
				createCatalogObj(request);
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-ModifyCatalog";
			}
			/*THIS METHOD DISPLAS THE COMPONENT LISTING TABS PAGE*/
			else if ((eCRDConstants.getActionId("eCRD_COMPONENT_LISTING")).equals(strScreenAction))
			{
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-ComponentListing";
			}
			/*THIS METHOD SAVES THE DETAILS OF THE ENGINE CATALOG ON CLICKING
			 *  THE SAVE BUTTON RETURNING TO THE SAME SCREEN*/
			else if ((eCRDConstants.getActionId("eCRD_UPDATE_ENGINE_DETAILS")).equals(strScreenAction))
			{
				//createCust(request);
				saveCatalogDetails(request);
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-ModifyCatalog";
			}
			/*THIS METHOD GETS THE RESULT SET FOR THE COMPONENT LISTING RC*/
			else if ((eCRDConstants.getActionId("eCRD_COMPONENT_LISTING_RC")).equals(strScreenAction))
			{
				getComponentList(request);
				eCRDUtil.loadInSession(request, eCRDConstants.STRCOMPONENTCODE, "");
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-ComponentListing";
			}
			/*THIS METHOD DISPLAYS THE BLANK CATALOG TABS SCREEN*/
			else if (eCRDConstants.getActionId("eCRD_MANAGE_CATALOG").equals(strScreenAction))
			{
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-createCustCatalog";
			}
			/*THIS METHOD IS INVOKED WHEN USER CLICKS THE ADD BUTTON IN THE MODIFY PAGE TO ADD AN USER*/
			else if ((eCRDConstants.getActionId("eCRDADD_CUSTOMERS")).equals(strScreenAction))
			{
				createCust(request);
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-ModifyCatalog";
			}
			/*THIS METHOD IS INVOKED WHEN USER CLICKS DELETE BUTTON TO DELETE A COMPONENT*/
			else if ((eCRDConstants.getActionId("eCRD_DELETE_COMPONENT")).equals(strScreenAction))
			{
				deleteComponents(request);
				getComponentList(request);
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-ComponentListing";
			}
			else if ((eCRDConstants.getActionId("eCRD_CUSTOMER_TABLE")).equals(strScreenAction))
			{
				getCustomerTable(request);
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-CustomerTable";
			}
			/*THIS METHOD IS TO GET THE APPROVAL COMPONENT SITE*/
			else if ((eCRDConstants.getActionId("eCRD_GET_APPROVAL_COMP_SITE")).equals(strScreenAction))
			{
				eCRDUtil.clearSession(request);
				getApprovalCompSites(request);
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-approveComponentSite";
			}
			else if ((eCRDConstants.getActionId("eCRD_APPROVE_COMPONENT_SITES")).equals(strScreenAction))
			{
				ApproveRejectCompSites(request);
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-approveComponentSite";
			}
			else if ((eCRDConstants.getActionId("eCRD_BATCH_DOWNLOAD_UPLOAD")).equals(strScreenAction))
			{
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-batchUploadDownLoad";
			}
			else if ((eCRDConstants.getActionId("eCRD_SHOW_MODULE_FOR_PRICE_LISTING_REPORT")).equals(strScreenAction))
			{
				createCatalogObj(request);
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-moduleListingForReport";
			}

			/*else if ((eCRDConstants.getActionId("eCRD_PRCNGCOMP_LIST")).equals(strScreenAction))
			{

				getPricingComponentList(request);
			//	getCatalogList(request);
				strReturnURL = eCRDConstants.STRCONTJSP +"ecrd-pricingAddEditScenario";
				//"ecrd-pricingAddEditScenario";
			}
			*/


			//added by meenakshi starts here
			else if ((eCRDConstants.getActionId("eCRD_CRM_DATA_LIST")).equals(strScreenAction))
			{

				getCRMDataComponentList(request);//make new
				strReturnURL = eCRDConstants.STRCONTJSP +"ecrd-pricingeCRDViewCRMDataHelper";
			}

			else if ((eCRDConstants.getActionId("eCRD_WIN_RATE_DATA_LIST")).equals(strScreenAction))
			{

				getWinRateDataComponentList(request);//make new
				strReturnURL = eCRDConstants.STRCONTJSP +"ecrd-pricingeCRDViewWinRateHelper";
			}

			else if ((eCRDConstants.getActionId("eCRD_METRIO_DATA_LIST_EXT")).equals(strScreenAction))
			{

				getMetrioDataListExt(request);//make new
				strReturnURL = eCRDConstants.STRCONTJSP +"ecrd-pricingeCRDViewMetrioDataHelper";
			}
			else if ((eCRDConstants.getActionId("eCRD_METRIO_DATA_LIST_INT")).equals(strScreenAction))
			{

				getMetrioDataListInt(request);//make new
				strReturnURL = eCRDConstants.STRCONTJSP +"ecrd-pricingeCRDViewMetrioDataHelper";
			}

			else if ((eCRDConstants.getActionId("eCRD_PRCNGCOMP_LIST")).equals(strScreenAction))
			{

				getPricingComponentList(request);
			//	getCatalogList(request);
				strReturnURL = eCRDConstants.STRCONTJSP +"ecrd-pricingComponentList";
				//"ecrd-pricingAddEditScenario";
			}

			//added by meenakshi ends here
			else if ((eCRDConstants.getActionId("eCRD_PRCNRPR_DETAILS")).equals(strScreenAction))
			{

				getPricingRepairList(request);
			//	getCatalogList(request);
				strReturnURL = eCRDConstants.STRCONTJSP +"ecrd-pricingAddProject3";
				//"ecrd-pricingAddEditScenario";
			}
			else if ((eCRDConstants.getActionId("eCRD_GET_CUSTOMER_ESC")).equals(strScreenAction))
			{

				getCustomerEscalationCap(request);
			//	getCatalogList(request);
				strReturnURL = eCRDConstants.STRCONTJSP +"ecrd-pricingAddProject3";
				//"ecrd-pricingAddEditScenario";
			}



			return strReturnURL;
		}
		finally
		{
			strScreenAction = null;
		}
	}
	/**
	 * This method searches for a Catalog based on the engine model selected
	*/
	private void getCatalogList(HttpServletRequest request) throws Exception
	{

		eCRDBusinessBean objeCRDBusinessBean = null;
		GEAEResultSet rsFormatted = null;
		GEAEResultSet rsEngineCatalog = null;
		eCRDDataBean objeCRDDataBean = null;
		String strCustomerCode = "";
		String strEngineModelNumber = "";
		String strStartDate = "";
		String strEndDate = "";
		String strActionId = "";
		ArrayList arrLstInParam = null;
		String strCatalogType = "";
		
		String strCatInd = "";   //changes by vikrant
		
		String strCatalogNum = null ;
		String strReport ="";
		String strFrom = null;
		// Added By Santosh
		ArrayList arrLstRsCatalog = null;
		String strcatAvtiveInd = null;
		// Ended BY Santosh
		
		//test
		GEAEResultSet rsFormattedRS = null;
		String strEngine = "";
		ArrayList arrlstTemp = null;
		GEAETag geAETag = null;
		GEAEResultSet rsSearchResults = null;
		//test
		
		try
		{

			rsFormatted = new GEAEResultSet();
			rsEngineCatalog = new GEAEResultSet();
			objeCRDDataBean = new eCRDDataBean();
			arrLstInParam = new ArrayList();

			objeCRDBusinessBean = new eCRDBusinessBean();
			strActionId = eCRDConstants.getActionId("eCRD_SHOW_SEARCH_RESULTS");
			strFrom = eCRDUtil.verifyNull(request.getParameter("hdnFrom"));
			//          strCustomerCode = eCRDUtil.verifyNull(request.getParameter("selCustomer"));
			strCustomerCode = eCRDAppSecurityUtil.deleteSplChars(eCRDUtil.verifyNullNoTrim(request.getParameter("hdnCustCode")));
			if ("".equals(strCustomerCode))
			{
				strCustomerCode = eCRDAppSecurityUtil.deleteSplChars(eCRDUtil.verifyNullNoTrim(request.getParameter("txtCustCode")));
			}
			//strEngineModelNumber = eCRDUtil.verifyNull(request.getParameter("selEngModel"));
			strStartDate = eCRDUtil.verifyNull(request.getParameter("hdnStartDate"));
			strEndDate = eCRDUtil.verifyNull(request.getParameter("hdnEndDate"));
			strCatalogType = eCRDUtil.verifyNull(request.getParameter("radCatalog"));
			
			strCatInd = eCRDUtil.verifyNull(request.getParameter("catInd"));   //changes by vikrant
			
			// Added By Santosh for active indicator for catalog
			strcatAvtiveInd =  eCRDUtil.verifyNull(request.getParameter("txtActiveInd"));
			// Ended By Santosh for active indicator for catalog
			if("eCRDAddRepToCSC".equals(strFrom))
			{
				strCatalogType = eCRDConstants.STRCUSTOMERCATALOGTYPE;
			}
			strCatalogNum  = eCRDAppSecurityUtil.deleteSplChars(eCRDUtil.verifyNull(request.getParameter("txtCatalogNum")));
			eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODELCODE, strEngineModelNumber);
			arrLstInParam.add(strCustomerCode);
			//arrLstInParam.add(strEngineModelNumber);
			arrLstInParam.add(strStartDate);
			arrLstInParam.add(strEndDate);
			arrLstInParam.add(strCatalogType);
			arrLstInParam.add(strCatalogNum);
			
			arrLstInParam.add(strCatInd);   //changes by vikrant
			
			arrLstInParam.add(strcatAvtiveInd);
			// Added by Santosh 
			
			//test
			strReport = eCRDUtil.verifyNull(request.getParameter("hdnReport"));
			//test
			
			String [] strEngineModelNumbers = request.getParameterValues("selEngModel");
			
			arrLstRsCatalog = new ArrayList();
			if(strEngineModelNumbers != null)
			{
				for(int i = 0;i < strEngineModelNumbers.length;i++)
				{
					
					arrLstInParam.add(strEngineModelNumbers[i]);
					
					rsSearchResults = objeCRDBusinessBean.populateCatalogList(strActionId, arrLstInParam);
					
					
					
					
					
					//test
					rsFormattedRS = new GEAEResultSet();
					rsSearchResults.setCurrentRow(0);
					while (rsSearchResults.next())
					{
						
						arrlstTemp = new ArrayList();
						if("".equals(strReport))
						{
							strEngine =
							"<A href='javascript:fnSelectEngineModel(\""
								+ rsSearchResults.getString("cat_seq_id")
								+ "\",\""
								+ rsSearchResults.getString("cat_type")
								+ "\")'>"
								+ rsSearchResults.getString("Engine_Model")
								+ "</A>";
						}
						else if("ADDMODIFYCSC".equals(strReport))
						{
							strEngine =
							"<A href='javascript:fnSelectEngineModelCSC(\""
								+ rsSearchResults.getString("cat_seq_id")
								+ "\",\""
								+ rsSearchResults.getString("cat_type")
								+ "\")'>"
								+ rsSearchResults.getString("Engine_Model")
								+ "</A>";
						}
						else
						{
							strEngine =
							"<A href='javascript:fnSelectEngineModelForReport(\""
								+ rsSearchResults.getString("cat_seq_id")
								+ "\",\""
								+ rsSearchResults.getString("cat_type")
								+ "\")'>"
								+ rsSearchResults.getString("Engine_Model")
								+ "</A>";

						}
						
						geAETag = new GEAETag(rsSearchResults.getString("Engine_Model"), strEngine);
						arrlstTemp.add(geAETag);
						//Added by Santosh
						arrlstTemp.add(rsSearchResults.getString("Engine_Desc"));
						arrlstTemp.add(rsSearchResults.getString("Customer_name"));
						arrlstTemp.add(rsSearchResults.getString("Contract_number"));
						arrlstTemp.add(rsSearchResults.getString("Discount"));
						//Ended by Santosh
						geAETag = new GEAETag(rsSearchResults.getString("Sortable_Start_Date"), rsSearchResults.getString("Start_Date"));
						arrlstTemp.add(geAETag);
						geAETag = new GEAETag(rsSearchResults.getString("Sortable_End_Date"), rsSearchResults.getString("End_Date"));
						arrlstTemp.add(geAETag);
						arrlstTemp.add(rsSearchResults.getString("Description"));
						rsFormattedRS.addRow(arrlstTemp);
						arrlstTemp = null;
						geAETag = null;
					}
					rsSearchResults = null;
					/*rsFormattedRS.setColumnHeading(1, "Catalog Number");
					rsFormattedRS.setColumnHeading(2, "Start Date");
					rsFormattedRS.setColumnHeading(3, "End  Date");
					rsFormattedRS.setColumnHeading(4, "Description");
					rsFormattedRS.sort(1, true);*/
					//return rsFormattedRS;
					//test*/
					arrLstInParam.remove(arrLstInParam.size()-1);
					
				}
				
				rsFormattedRS.setColumnHeading(1, "Catalog Number");
				rsFormattedRS.setColumnHeading(2, "Engine Model");
				rsFormattedRS.setColumnHeading(3, "Customer Name");
				rsFormattedRS.setColumnHeading(4, "Contract Number");
				rsFormattedRS.setColumnHeading(5, "Discount(%)");
				rsFormattedRS.setColumnHeading(6, "Start Date");
				rsFormattedRS.setColumnHeading(7, "End Date");
				rsFormattedRS.setColumnHeading(8, "Description");
				rsFormattedRS.sort(2, true);
			}
			
			
			//Ended by Santosh

			objeCRDDataBean.setCache(rsFormattedRS);
			eCRDUtil.loadInSession(request, "eCRDCatalogList", objeCRDDataBean);
		}
		finally
		{

			rsEngineCatalog = null;
			rsFormatted = null;
			objeCRDDataBean = null;
			objeCRDBusinessBean = null;
			strEngineModelNumber = null;
			strCustomerCode = null;
			
			strCatInd = null;    //changes by vikrant
			
			strStartDate = null;
			strEndDate = null;
			strActionId = null;
			arrLstInParam = null;

		}

	}

	/**
	 * Method to create the catalog object depending on whether the catalog type is C or D
	 */
	private void createCatalogObj(HttpServletRequest request) throws Exception
	{
		eCRDCustomerCatalog objeCRDCustomerCatalog = null;
		eCRDDefaultCatalog objeCRDDefaultCatalog = null;
		eCRDEngineModel objeCRDEngineModel = null;
		String strEngModel = "";
		String strCatalogCode = "";
		String strCatalogType = "";
		
		String strCatInd = "";   //changes by vikrant
		
		try
		{

			/*this is to get the engine model */
			//strEngModel = (String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODELCODE); --eCRDEngineModelCode
			//Syetem.out.println("Santosh In Test in Helper Class Engine Model"+strEngModel);
			
			//objeCRDEngineModel = new eCRDEngineModel(strEngModel);
			strCatalogCode = eCRDUtil.verifyNull(request.getParameter("hdnCatalog_Seq_Id"));
			strCatalogType = eCRDUtil.verifyNull(request.getParameter("hdnCatalogType"));
			
			strCatInd = eCRDUtil.verifyNull(request.getParameter("hdnCatInd"));    //changes by vikrant
			
			if (eCRDConstants.STRDEFAULTCATALOGTYPE.equals(strCatalogType))
			{
				objeCRDDefaultCatalog = new eCRDDefaultCatalog(strCatalogCode);
				objeCRDDefaultCatalog.setEngineModel(objeCRDEngineModel);
				objeCRDDefaultCatalog.setCatalogType(eCRDConstants.STRDEFAULTCATALOGTYPE);
				/*	if(strEndDate.indexOf("-") != -1)
				   {
					 strEndDate		= eCRDUtil.convertDateString(strEndDate);
				   }

				if(eCRDUtil.compareDates(strEndDate,"")>0)
				   {
					objeCRDDefaultCatalog.setActive(true);
				   }
				else
				   {
					objeCRDDefaultCatalog.setActive(false);
				   }*/
				eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDDefaultCatalog);
			}
			else
			{
				objeCRDCustomerCatalog = new eCRDCustomerCatalog(strCatalogCode);
				objeCRDCustomerCatalog.setEngineModel(objeCRDEngineModel);
				objeCRDCustomerCatalog.setCatalogType(eCRDConstants.STRCUSTOMERCATALOGTYPE);
               //19-05-2006 Patni adding catalog type into session begin
                eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDCustomerCatalog);
                //19-05-2006 Patni adding catalog type into session End

				/*if(strEndDate.indexOf("-") != -1)
				  {
				    strEndDate		= eCRDUtil.convertDateString(strEndDate);
				  }
				if(eCRDUtil.compareDates(,"")>0)
				  {
					objeCRDCustomerCatalog.setActive(true);
				  }
				else
				  {
					objeCRDCustomerCatalog.setActive(false);
				  }*/
				getCustomers(request, objeCRDCustomerCatalog);

			}
		}
		finally
		{
			objeCRDCustomerCatalog = null;
			objeCRDDefaultCatalog = null;
			objeCRDEngineModel = null;
			strCatalogCode = null;
			strCatalogType = null;
			
			strCatInd = null;   //changes by vikrant

		}
	}
	private void getCustomers(HttpServletRequest request, eCRDCustomerCatalog objeCRDCustomerCatalog) throws Exception
	{
		eCRDCustomer objeCRDCustomer = null;
		HashMap hmeCRDCustomers = null;
		ArrayList arrlstExistCustCode = null;
		ArrayList arrlstExistCustDetails = null;
		String strValue = "";
		Set keySet;
		Iterator customerIterator = null;
		try
		{
			arrlstExistCustCode = new ArrayList();
			arrlstExistCustDetails = new ArrayList();
			hmeCRDCustomers = objeCRDCustomerCatalog.getCustomers();
			if (hmeCRDCustomers != null && hmeCRDCustomers.size() > 0)
			{
				keySet = hmeCRDCustomers.keySet();
				customerIterator = keySet.iterator();
				keySet = hmeCRDCustomers.keySet();
				while (customerIterator.hasNext())
				{
					strValue = (String) customerIterator.next();
					objeCRDCustomer = (eCRDCustomer) hmeCRDCustomers.get(strValue);
					arrlstExistCustCode.add(objeCRDCustomer.getCustomerCode());
					arrlstExistCustDetails.add(objeCRDCustomer.getCustomerName());
					arrlstExistCustDetails.add(objeCRDCustomer.getContractCode());
					arrlstExistCustDetails.add(objeCRDCustomer.getContractDesc());
                    /*Patni 10-May-2006 Begin Add Contract Start and End Date*/
                    arrlstExistCustDetails.add(objeCRDCustomer.getStartDate());
                    arrlstExistCustDetails.add(objeCRDCustomer.getEndDate());
                    /*Patni 10-May-2006 End Add Contract Start and End Date*/
				}
				eCRDUtil.loadInSession(request, "arrlstExistCustCode", arrlstExistCustCode);
				eCRDUtil.loadInSession(request, "arrlstExistCustDetails", arrlstExistCustDetails);
			}
			eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDCustomerCatalog);
		}
		finally
		{
			objeCRDCustomer = null;
			hmeCRDCustomers = null;
			arrlstExistCustCode = null;
			arrlstExistCustDetails = null;
			strValue = null;
			customerIterator = null;

		}

	}

	/**
	 * Method to get pricing repair list.
	 * @param request
	 */
	 private void getPricingRepairList(HttpServletRequest request) throws Exception {

			eCRDBusinessBean objeCRDBusinessBean = null;
			GEAEResultSet rsFormatted = null;
			GEAEResultSet rsEngineCatalog = null;
			eCRDDataBean objeCRDDataBean = null;
			String strActionId = "";
			ArrayList arrLstInParam = null;
			String strReport ="";
			String componentCode="";

			int scnarioId=0;
			int projectId=0;
			HttpSession session = request.getSession(false);

			if(session.getAttribute("scenarioId")!=null) {
				scnarioId = Integer.parseInt((session.getAttribute("scenarioId").toString()));
			}
			if(session.getAttribute("projectId")!=null) {
				projectId =Integer.parseInt((session.getAttribute("projectId").toString()));
			}

			try
			{

				if( request.getParameter("componentCode")!=null) {
					componentCode = request.getParameter("componentCode").toString();
				}
				if(session.getAttribute("componentCode")!=null && componentCode.equalsIgnoreCase("")) {
					componentCode = session.getAttribute("componentCode").toString();
				}

				session.setAttribute("componentCode", componentCode);

				rsFormatted = new GEAEResultSet();
				rsEngineCatalog = new GEAEResultSet();
				objeCRDDataBean = new eCRDDataBean();
				arrLstInParam = new ArrayList();

				objeCRDBusinessBean = new eCRDBusinessBean();
				strActionId = eCRDConstants.getActionId("eCRD_PRCNRPR_DETAILS");


				arrLstInParam.add(Integer.toString(projectId));
				arrLstInParam.add(Integer.toString(scnarioId));
				arrLstInParam.add(componentCode);

				rsEngineCatalog = objeCRDBusinessBean.populateComponentList(strActionId, arrLstInParam);
				strReport = eCRDUtil.verifyNull(request.getParameter("hdnReport"));
				rsFormatted = formatPricingRepairResultSet(rsEngineCatalog,strReport);
				objeCRDDataBean.setCache(rsFormatted);
				eCRDUtil.loadInSession(request, "eCRDCatalogList", objeCRDDataBean);
			}
			finally
			{

				rsEngineCatalog = null;
				rsFormatted = null;
				objeCRDDataBean = null;
				objeCRDBusinessBean = null;
				strActionId = null;
				arrLstInParam = null;

			}

		}



	private void saveCatalogDetails(HttpServletRequest request) throws Exception
	{
		eCRDDefaultCatalog objeCRDDefaultCatalog = null;
		eCRDCustomerCatalog objeCRDCustomerCatalog = null;
		eCRDCatalog objeCRDCatalog = null;
		eCRDBusinessBean objeCRDBusinessBean = null;
		eCRDUser objeCRDUser = null;
		eCRDCustomer objeCRDCustomer = null;
		eCRDException objeCRDException = null;
		String strCatalogDesc = "";
		String strEndDate = "";
		String strCatalogType = "";
		String strUserId = "";
		String strCatalogSeqId = "";
		String strInParam = "";
		String strMessage = "";
		String strActionId = "";
        /* Patni 16-May-2006 Begin Add Contract Start and End Date */
        String strCntrctEndDate[] = null;
        String strCntrctNumber[] = null;
        String strCntrctDesc[] = null;
        String strContractEndDate[] = null;
        String CustCode[] = null;
        String strTempEndDate = null;
        ArrayList arrlstOutParam = null ;
        GEAEResultSet rsCustomerDetails = null;
        ArrayList arrlstExistCustDetails = null;
        ArrayList arrlstExistCustCode = null;
        int intCounter = 0;
        int intTemp =0;
        /* Patni 16-May-2006 End Add Contract Start and End Date */
		ArrayList arrLstInParam = null;
		String strContractNum[] = null;
        String strContractDesc[] = null;
		String strCustCode[] = null;
        Format formatter = new SimpleDateFormat("MM/dd/yyyy");
        Date date =  new Date();
		String strModifiedEndDate = null;
		int intAdd = 0;
		try
		{
			objeCRDBusinessBean = new eCRDBusinessBean();
			objeCRDCatalog = (eCRDCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
			if (objeCRDCatalog == null)
			{
				objeCRDException = new eCRDException();
				objeCRDException.setExcpId("CATALOG_NOT_SET");
				throw objeCRDException;
			}

			objeCRDUser = new eCRDUser();
			objeCRDUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser");
			strUserId = objeCRDUser.getUserId();
			arrLstInParam = new ArrayList();
			strCatalogType = eCRDUtil.verifyNull(objeCRDCatalog.getCatalogType());
			strEndDate = eCRDUtil.verifyNull(request.getParameter("hdnEndDate"));
			strCatalogDesc = eCRDUtil.verifyNull(request.getParameter("txtDesc"));
			strCatalogDesc = eCRDUtil.replaceString(strCatalogDesc, "\r\n", " ");

			strActionId = eCRDConstants.getActionId("eCRD_SAVE_CATALOG");
			if (strEndDate.indexOf("-") != -1)
			{
				strEndDate = (String) eCRDUtil.convertDateString(strEndDate);
			}
			if (eCRDUtil.compareDates(strEndDate, "") > 0)
			{
				objeCRDCatalog.setActive(true);
			}
			else
			{
				objeCRDCatalog.setActive(false);
			}
			if (eCRDConstants.STRDEFAULTCATALOGTYPE.equals(strCatalogType))
			{
				objeCRDDefaultCatalog = (eCRDDefaultCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
				strCatalogSeqId = objeCRDDefaultCatalog.getCatalogSeqId();
				objeCRDDefaultCatalog.setCatalogDesc(strCatalogDesc);

                if(strEndDate.equals(objeCRDDefaultCatalog.getEndDate())) {
                    objeCRDDefaultCatalog.setCatalogEndDateModifiedBy(objeCRDDefaultCatalog.getCatalogEndDateModifiedBy());
                    objeCRDDefaultCatalog.setCatalogEndDateModifiedDate(objeCRDDefaultCatalog.getCatalogEndDateModifiedDate());
                }else{
                    objeCRDDefaultCatalog.setCatalogEndDateModifiedBy(objeCRDUser.getFirstName()+' '+objeCRDUser.getLastName());
                    strModifiedEndDate = (String) formatter.format(date);
                    objeCRDDefaultCatalog.setCatalogEndDateModifiedDate(strModifiedEndDate);
                }
                objeCRDDefaultCatalog.setCatalogEndDate(strEndDate);
				eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDDefaultCatalog);
			}
			else if (eCRDConstants.STRCUSTOMERCATALOGTYPE.equals(strCatalogType))
			{
				strContractNum = request.getParameterValues("txtContractNumber");
				strContractDesc = request.getParameterValues("txtContractDesc");
				strCustCode = request.getParameterValues("hdnCustomerCode");
                /* Patni 16-May-2006 Begin Add Contract Start and End Date */
                strCntrctEndDate = request.getParameterValues("hdnCustEndDate");
                strCntrctNumber = request.getParameterValues("CntrctNumber");
                strContractEndDate = request.getParameterValues("CntrctEndDate");
                strCntrctDesc = request.getParameterValues("CntrctDesc");
                CustCode = request.getParameterValues("CustCode");
                /* Patni 16-May-2006 End Add Contract Start and End Date */
				objeCRDCustomerCatalog = (eCRDCustomerCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
                if(strEndDate.equals(objeCRDCustomerCatalog.getEndDate())) {
                    objeCRDCustomerCatalog.setCatalogEndDateModifiedBy(objeCRDCustomerCatalog.getCatalogEndDateModifiedBy());
                    objeCRDCustomerCatalog.setCatalogEndDateModifiedDate(objeCRDCustomerCatalog.getCatalogEndDateModifiedDate());
                }else{
                    objeCRDCustomerCatalog.setCatalogEndDateModifiedBy(objeCRDUser.getFirstName()+' '+objeCRDUser.getLastName());
                    strModifiedEndDate = (String) formatter.format(date);
                    objeCRDCustomerCatalog.setCatalogEndDateModifiedDate(strModifiedEndDate);
                }
				objeCRDCustomerCatalog.setCatalogEndDate(strEndDate);
				objeCRDCustomerCatalog.setCatalogDesc(strCatalogDesc);
				strCatalogSeqId = objeCRDCustomerCatalog.getCatalogSeqId();
                if (strContractNum != null)
				{
					for (intAdd = 0; intAdd < strContractNum.length; intAdd++)
					{
						strContractDesc[intAdd] = eCRDUtil.replaceString(strContractDesc[intAdd], "\r\n", " ");
                        strInParam =
							strCustCode[intAdd]
								+ eCRDConstants.STRCOLUMNDELIM
								+ strContractNum[intAdd]
								+ eCRDConstants.STRCOLUMNDELIM
								+ strContractDesc[intAdd]
								+ eCRDConstants.STRCOLUMNDELIM
                                /* Patni 16-May-2006 Begin Add Contract Start and End Date */
                                + strCntrctEndDate[intAdd]
                                + eCRDConstants.STRCOLUMNDELIM
                                /* Patni 16-May-2006 End Add Contract Start and End Date */
								+ eCRDConstants.STRROWDELIM
								+ strInParam;
						objeCRDCustomer = new eCRDCustomer(strCustCode[intAdd]);
						objeCRDCustomer.setContractCode(strContractNum[intAdd]);
						objeCRDCustomer.setContractDesc(strContractDesc[intAdd]);
                        /* Patni 16-May-2006 Begin Add Contract Start and End Date */
                        objeCRDCustomer.setEndDate(strTempEndDate);
                        /* Patni 16-May-2006 End Add Contract Start and End Date */
						objeCRDCustomerCatalog.addCustomer(objeCRDCustomer);
					}
				}
                /* Patni 16-May-2006 Begin Add Contract Start and End Date */
                if(strCntrctNumber!= null)
                {

                    for (intAdd = 0;intAdd < (strCntrctNumber.length)-1 ; intAdd++)
                    {
                        strCntrctDesc[intAdd] = eCRDUtil.replaceString(strCntrctDesc[intAdd], "\r\n", " ");
                        strInParam =
                            CustCode[intAdd]
                                + eCRDConstants.STRCOLUMNDELIM
                                + strCntrctNumber[intAdd]
                                + eCRDConstants.STRCOLUMNDELIM
                                + strCntrctDesc[intAdd]
                                + eCRDConstants.STRCOLUMNDELIM
                                + strContractEndDate[intAdd]
                                + eCRDConstants.STRCOLUMNDELIM
                                + eCRDConstants.STRROWDELIM
                                + strInParam;
                        objeCRDCustomer = new eCRDCustomer(CustCode[intAdd]);
                        objeCRDCustomer.setEndDate(strContractEndDate[intAdd]);
                    }

                }/* Patni 16-May-2006 End Add Contract Start and End Date */
                getCustomers(request, objeCRDCustomerCatalog);
			}
			arrLstInParam.add(strCatalogSeqId);
			arrLstInParam.add(strCatalogDesc);
			arrLstInParam.add(strEndDate);
			arrLstInParam.add(strInParam);
			arrLstInParam.add(strUserId);
			arrlstOutParam = objeCRDBusinessBean.SaveCatalog(strActionId, arrLstInParam);
            /* Patni 22-May-2006 Begin Add Contract Start and End Date */
            rsCustomerDetails = (GEAEResultSet)arrlstOutParam.get(0);
            //eCRDUtil.removeFromSession(request,"arrlstExistCustDetails");
            //arrlstExistCustDetails = (ArrayList)eCRDUtil.getFromSession(request,"arrlstExistCustDetails");
            arrlstExistCustDetails = new ArrayList(rsCustomerDetails.size());
            arrlstExistCustCode = new ArrayList();
            if(rsCustomerDetails!=null && rsCustomerDetails.size()>0  )
            {

               while(rsCustomerDetails.next())
               {
                arrlstExistCustDetails.add(intCounter,eCRDUtil.verifyNull(rsCustomerDetails.getString("cust_name")));
                intCounter++;
                arrlstExistCustDetails.add(intCounter,eCRDUtil.verifyNull(rsCustomerDetails.getString("contract_code")));
                intCounter++;
                arrlstExistCustDetails.add(intCounter,eCRDUtil.verifyNull(rsCustomerDetails.getString("cont_desc")));
                intCounter++;
                arrlstExistCustDetails.add(intCounter,eCRDUtil.verifyNull(rsCustomerDetails.getString("start_date")));
                intCounter++;
                arrlstExistCustDetails.add(intCounter,eCRDUtil.verifyNull(rsCustomerDetails.getString("end_date")));
                intCounter++;
                arrlstExistCustCode.add(intTemp,eCRDUtil.verifyNull(rsCustomerDetails.getString("cust_code")));
                intTemp++;
               }
                //rsCustomerDetails.next();

            eCRDUtil.loadInSession(request, "arrlstExistCustDetails", arrlstExistCustDetails);
            eCRDUtil.loadInSession(request, "arrlstExistCustCode", arrlstExistCustCode);
               eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDCustomerCatalog);
            }
//            else
//            {
//                throw new Exception("Customer Not Found");
//            }
            strMessage = eCRDUtil.verifyNull((String)arrlstOutParam.get(1));
           /* Patni 22-May-2006 End Add Contract Start and End Date */
			request.setAttribute("eCRDMessage", strMessage);
		}
		finally
		{
			objeCRDDefaultCatalog = null;
			objeCRDCustomerCatalog = null;
			objeCRDCatalog = null;
			objeCRDBusinessBean = null;
			objeCRDUser = null;
			strContractNum = null;
			strContractDesc = null;
			strCustCode = null;
            /* Patni 16-May-2006 Begin Add Contract Start and End Date */
            strCntrctNumber = null;
            strCntrctEndDate = null;
            strContractEndDate = null;
            strCntrctDesc = null;
            CustCode = null;
            /* Patni 16-May-2006 End Add Contract Start and End Date */
			arrLstInParam = null;
			strCatalogDesc = null;
			strEndDate = null;
			strCatalogType = null;
			strUserId = null;
			strCatalogSeqId = null;
			strInParam = null;
			strMessage = null;
			strActionId = null;
            strModifiedEndDate = null;
		}

	}
	/**
	 * Method to show the Repair rowcache.
	 */
	private void getRepairList()
	{

	}

	/**
	 * Method to show the component rowcache.
	 */
	private void getComponentList(HttpServletRequest request) throws Exception
	{

		eCRDCatalog objeCRDCatalog = null;
		eCRDException objeCRDException = null;
		eCRDBusinessBean objeCRDBusinessBean = null;
		eCRDDataBean objeCRDDataBean = null;
		GEAEResultSet rsComponent = null;
		String strModule_Seq_Id = "";
		String strCatalog_Seq_Id = "";
		String strActionId = "";
		eCRDUser objeCRDUser = null;
		String strUserRole = "";

		boolean blnEditable = false;
		ArrayList arrLstInParam = null;

		try
		{
			objeCRDUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser");
			strUserRole = objeCRDUser.getRole();
			strActionId = eCRDConstants.getActionId("eCRD_COMPONENT_LISTING_RC");
			strModule_Seq_Id = eCRDUtil.verifyNull(request.getParameter("selModule"));

			if ("".equals(strModule_Seq_Id))
			{
				strModule_Seq_Id = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE));
			}

			objeCRDBusinessBean = new eCRDBusinessBean();
			objeCRDDataBean = new eCRDDataBean();
			rsComponent = new GEAEResultSet();
			arrLstInParam = new ArrayList();

			objeCRDCatalog = (eCRDCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
			if (objeCRDCatalog == null)
			{
				objeCRDException = new eCRDException();
				objeCRDException.setExcpId("CATALOG_NOT_SET");
				throw objeCRDException;
			}
			strCatalog_Seq_Id = eCRDUtil.verifyNull(objeCRDCatalog.getCatalogSeqId());

			if ("ADMIN".equals(strUserRole) && objeCRDCatalog.isActive() && eCRDConstants.STRDEFAULTCATALOGTYPE.equalsIgnoreCase(objeCRDCatalog.getCatalogType()))
			{
				blnEditable = true;
			}
			else
			{
				blnEditable = false;
			}

			arrLstInParam.add(strCatalog_Seq_Id);
			arrLstInParam.add(strModule_Seq_Id);



			rsComponent = objeCRDBusinessBean.populateComponentList(strActionId, arrLstInParam);


			rsComponent = formatComponentResultSet(rsComponent, blnEditable);


			objeCRDDataBean.setCache(rsComponent);
			eCRDUtil.loadInSession(request, "eCRDComponentList", objeCRDDataBean);
			eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODULECODE, strModule_Seq_Id);
		}
		finally
		{
			objeCRDCatalog = null;
			objeCRDBusinessBean = null;
			objeCRDDataBean = null;
			rsComponent = null;
			strModule_Seq_Id = null;
			strCatalog_Seq_Id = null;
			strActionId = null;

			arrLstInParam = null;
		}
	}

	private void getCustomerTable(HttpServletRequest request) throws Exception
	{

		GEAEResultSet rsFormatted = null;
		GEAEResultSet rsCustomerTable = null;
		eCRDDataBean objeCRDDataBean = null;
		String strCustomerName = null;
		String strActive = null;
		try
		{

			rsFormatted = new GEAEResultSet();
			rsCustomerTable = new GEAEResultSet();
			objeCRDDataBean = new eCRDDataBean();
			strCustomerName = eCRDAppSecurityUtil.deleteSplChars(eCRDUtil.verifyNull(request.getParameter("hdnCustomerName")));
			strActive = eCRDAppSecurityUtil.deleteSplChars(eCRDUtil.verifyNull(request.getParameter("hdnOnlyActive")));
			rsCustomerTable = eCRDLoadMaster.getCustomerList(strCustomerName
															,strActive 	);
			rsFormatted = formatCustomerResultSet(rsCustomerTable);
			objeCRDDataBean.setCache(rsFormatted);
			eCRDUtil.loadInSession(request, "CustomerTable", objeCRDDataBean);
			if (rsCustomerTable.size() == 0)
			{
				request.setAttribute("flag", "false");
			}
			else
			{
				request.setAttribute("flag", "true");
			}
		}
		finally
		{

			rsFormatted = null;
			rsCustomerTable = null;
			objeCRDDataBean = null;
			strCustomerName = null;
		}

	}

	/**
		 * Method to delete components from row cache.
		 */
	private void deleteComponents(HttpServletRequest request) throws Exception
	{
		eCRDBusinessBean objeCRDBusinessBean = null;
		eCRDCatalog objeCRDCatalog = null;
		eCRDException objeCRDException = null;
		eCRDEngineModel objeCRDEngineModel = null;
		eCRDUser objeCRDUser = null;
		ArrayList arrLstInParam = null;
		String strCatalog_Seq_Id = "";
		String strEngine_Model_Code = "";
		String strActionId = "";
		String strMessage = "";
		String strInParam = "";
		try
		{
			objeCRDBusinessBean = new eCRDBusinessBean();
			objeCRDUser = new eCRDUser();
			objeCRDCatalog = (eCRDCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
			if (objeCRDCatalog == null)
			{
				objeCRDException = new eCRDException();
				objeCRDException.setExcpId("CATALOG_NOT_SET");
				throw objeCRDException;
			}
			strCatalog_Seq_Id = objeCRDCatalog.getCatalogSeqId();
			objeCRDEngineModel = objeCRDCatalog.getEngineModel();
			strEngine_Model_Code = objeCRDEngineModel.getEngineModelCode();
			objeCRDUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser");
			strActionId = eCRDConstants.getActionId("eCRD_DELETE_COMPONENT");
			strInParam = eCRDUtil.verifyNull(request.getParameter("hdnInParam"));
			arrLstInParam = new ArrayList();
			arrLstInParam.add(strInParam);
			arrLstInParam.add(strEngine_Model_Code);
			arrLstInParam.add(strCatalog_Seq_Id);
			arrLstInParam.add(objeCRDUser.getUserId());
			arrLstInParam.add(objeCRDUser.getRole());
			strMessage = objeCRDBusinessBean.removeComponent(strActionId, arrLstInParam);
			request.setAttribute("strMessage", strMessage);
		}
		finally
		{
			objeCRDBusinessBean = null;
			arrLstInParam = null;
			objeCRDUser = null;
			arrLstInParam = null;
			strCatalog_Seq_Id = null;
			strEngine_Model_Code = null;
			strActionId = null;
			strMessage = null;
		}
	}

	private void getApprovalCompSites(HttpServletRequest request) throws Exception
	{
		eCRDBusinessBean objeCRDBusinessBean = null;
		GEAEResultSet rsFormatted = null;
		GEAEResultSet rsApproveCompSite = null;
		eCRDDataBean objeCRDDataBean = null;
		String strActionId = null;
		ArrayList arrLstInParam = null;
		eCRDUser objeCRDUser = null;
		String strRole = null;
		String strUserId = null;
		try
		{
			objeCRDBusinessBean = new eCRDBusinessBean();
			rsFormatted = new GEAEResultSet();
			rsApproveCompSite = new GEAEResultSet();
			objeCRDDataBean = new eCRDDataBean();
			arrLstInParam = new ArrayList();
			objeCRDUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser");
			strRole = objeCRDUser.getRole();
			strUserId = objeCRDUser.getUserId();
			arrLstInParam.add(eCRDUtil.verifyNull(strRole));
			arrLstInParam.add(eCRDUtil.verifyNull(strUserId));
			strActionId = eCRDConstants.getActionId("eCRD_APPROVE_COMP_SITE");
			rsApproveCompSite = objeCRDBusinessBean.populateApproveCompSite(strActionId, arrLstInParam);
			if (eCRDConstants.ROLE_TECH_COORD.equals(strRole))
			{
				rsFormatted = formatTCApproveCompSiteResultSet(rsApproveCompSite);

			}
			else if (eCRDConstants.ROLE_ADMINISTRATOR.equals(strRole))
			{
				rsFormatted = formatApproveCompSiteResultSet(rsApproveCompSite);

			}

			objeCRDDataBean.setCache(rsFormatted);
			eCRDUtil.loadInSession(request, "eCRDApproveComponentSite", objeCRDDataBean);
			if (rsApproveCompSite.size() == 0)
			{
				request.setAttribute("eCRDMessage", "true");
			}

		}
		finally
		{

			objeCRDBusinessBean = null;
			rsFormatted = null;
			rsApproveCompSite = null;
			objeCRDDataBean = null;
			strActionId = null;
			arrLstInParam = null;
			objeCRDUser = null;
			strRole = null;
			strUserId = null;

		}

	}

	private void ApproveRejectCompSites(HttpServletRequest request) throws Exception
	{
		eCRDBusinessBean objeCRDBusinessBean = null;
		eCRDUser objeCRDUser = null;
		GEAEResultSet rsCompSite = null;
		GEAEResultSet rsFormatted = null;
		eCRDDataBean objeCRDDataBean = null;
		ArrayList arrLstInParam = null;
		String strInParam = "";
		String strActionId = "";
		String strMessage = "";
		ArrayList arrLstOutParam = null;

		try
		{
			rsCompSite = new GEAEResultSet();
			rsFormatted = new GEAEResultSet();
			objeCRDDataBean = new eCRDDataBean();
			strInParam = eCRDUtil.verifyNull(request.getParameter("hdnInputParam"));
			strInParam = eCRDUtil.replaceString(strInParam, "\r\n", " ");
			objeCRDUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser");
			objeCRDBusinessBean = new eCRDBusinessBean();
			arrLstInParam = new ArrayList();
			arrLstOutParam = new ArrayList();
			strActionId = eCRDConstants.getActionId("eCRD_APPROVE_REJECT_COMP_SITE");
			arrLstInParam.add(strInParam);
			arrLstInParam.add(objeCRDUser.getRole());
			arrLstInParam.add(objeCRDUser.getUserId());
			arrLstOutParam = objeCRDBusinessBean.ApproveCompSite(strActionId, arrLstInParam);
			rsCompSite = (GEAEResultSet) arrLstOutParam.get(0);
			rsFormatted = formatApproveCompSiteResultSet(rsCompSite);
			objeCRDDataBean.setCache(rsFormatted);
			eCRDUtil.loadInSession(request, "eCRDApproveComponentSite", objeCRDDataBean);
			if (rsCompSite.size() == 0)
			{
				request.setAttribute("eCRDMessage", "true");
			}
			strMessage = (String) arrLstOutParam.get(1);
			request.setAttribute("strMessage", strMessage);

		}
		finally
		{
			objeCRDBusinessBean = null;
			objeCRDUser = null;
			arrLstInParam = null;
			strInParam = null;
			strActionId = null;

		}
	}

	private void createCust(HttpServletRequest request) throws Exception
	{
		String strCustName[] = null;
		String strCustCode[] = null;

		String strCustAddDel = "";
		String strContractNum[] = null;
		String strContractDesc[] = null;
		String strDelCustCode = "";

		ArrayList arrlstCustCode = null;

		String strFlag = "";

		eCRDCustomer objeCRDCustomer = null;
		eCRDCustomerCatalog objeCRDCustomerCatalog = null;
		try
		{
			strCustName = request.getParameterValues("hdnCustName");
			strCustCode = request.getParameterValues("hdnCustomerCode");
			strContractNum = request.getParameterValues("txtContractNumber");

			strContractDesc = request.getParameterValues("txtContractDesc");
			arrlstCustCode = (ArrayList) eCRDUtil.getFromSession(request, "eCRDCustomerCode");

			strFlag = eCRDUtil.verifyNull(request.getParameter("hdnflag"));
			strCustAddDel = eCRDUtil.verifyNull(request.getParameter("hdnAddDelCust"));
			strDelCustCode = eCRDUtil.verifyNullNoTrim(request.getParameter("hdnCustCode"));

			objeCRDCustomerCatalog = (eCRDCustomerCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
			if ("true".equals(strFlag))
			{
				if (objeCRDCustomerCatalog == null)
				{
					objeCRDCustomerCatalog = new eCRDCustomerCatalog();

				}
			}

			if (!"true".equals(strFlag) && arrlstCustCode != null)
			{

				arrlstCustCode.remove(strDelCustCode);
			}
			if (strContractNum != null && "true".equals(strFlag))
			{

				for (int i = 0; i < strContractNum.length; i++)
				{

					objeCRDCustomer = new eCRDCustomer();
					objeCRDCustomer.setContractCode(strContractNum[i]);
					objeCRDCustomer.setCustomerCode(strCustCode[i]);
					objeCRDCustomer.setCustomerName(strCustName[i]);
					objeCRDCustomer.setContractDesc(strContractDesc[i]);
					objeCRDCustomerCatalog.addCustomer(objeCRDCustomer);

				}
			}
			if ("DelCust".equals(strCustAddDel) && strContractNum != null && "true".equals(strFlag))
			{
				for (int i = 0; i < strCustCode.length; i++)
				{

					if (strDelCustCode.equals(arrlstCustCode.get(i)))
					{
						objeCRDCustomerCatalog.removeCustomer(strCustCode[i]);

						arrlstCustCode = (ArrayList) eCRDUtil.getFromSession(request, "eCRDCustomerCode");
						arrlstCustCode.remove(strDelCustCode);
						eCRDUtil.loadInSession(request, "eCRDCustomerCode", arrlstCustCode);
						break;
					}
				}
			}
			eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDCustomerCatalog);
		}
		finally
		{
			strCustName = null;
			strCustCode = null;
			strCustAddDel = null;
			strDelCustCode = null;
			arrlstCustCode = null;
			objeCRDCustomer = null;

		}
	}

	/**
	* Method to show the Notification Group rowcache.
	*/
	private void getNotificationGroupList()
	{

	}

	/**
	 * Method to show the Catalog Reapir catalog list rowcache.
	 */
	private void getReportComponentRepairYearlyCatalog()
	{

	}

	/**
	 * Method to show the Repair Price Change Report rowcache.
	 */
	private void getReportPriceChgList()
	{

	}

	/**
	 * Method to show the Repair Price Change Yearly Report rowcache.
	 */
	private void getReportPriceListChgYearly()
	{

	}

	/**
	 * Method to show the user list rowcache.
	 */
	private void getUserList()
	{

	}

	private GEAEResultSet formatCatalogResultSet(GEAEResultSet rsSearchResults,String strReport) throws Exception
	{

		GEAEResultSet rsFormattedRS = null;
		String strEngine = "";
		ArrayList arrlstTemp = null;
		GEAETag geAETag = null;
		try
		{
			rsFormattedRS = new GEAEResultSet();
			rsSearchResults.setCurrentRow(0);
			while (rsSearchResults.next())
			{

				arrlstTemp = new ArrayList();
				if("".equals(strReport))
				{
					strEngine =
					"<A href='javascript:fnSelectEngineModel(\""
						+ rsSearchResults.getString("cat_seq_id")
						+ "\",\""
						+ rsSearchResults.getString("cat_type")
						+ "\")'>"
						+ rsSearchResults.getString("Engine_Model")
						+ "</A>";
				}
				else if("ADDMODIFYCSC".equals(strReport))
				{
					strEngine =
					"<A href='javascript:fnSelectEngineModelCSC(\""
						+ rsSearchResults.getString("cat_seq_id")
						+ "\",\""
						+ rsSearchResults.getString("cat_type")
						+ "\")'>"
						+ rsSearchResults.getString("Engine_Model")
						+ "</A>";
				}
				else
				{
					strEngine =
					"<A href='javascript:fnSelectEngineModelForReport(\""
						+ rsSearchResults.getString("cat_seq_id")
						+ "\",\""
						+ rsSearchResults.getString("cat_type")
						+ "\")'>"
						+ rsSearchResults.getString("Engine_Model")
						+ "</A>";

				}
				geAETag = new GEAETag(rsSearchResults.getString("Engine_Model"), strEngine);
				arrlstTemp.add(geAETag);
				geAETag = new GEAETag(rsSearchResults.getString("Sortable_Start_Date"), rsSearchResults.getString("Start_Date"));
				arrlstTemp.add(geAETag);
				geAETag = new GEAETag(rsSearchResults.getString("Sortable_End_Date"), rsSearchResults.getString("End_Date"));
				arrlstTemp.add(geAETag);
				arrlstTemp.add(rsSearchResults.getString("Description"));
				rsFormattedRS.addRow(arrlstTemp);
				arrlstTemp = null;
				geAETag = null;
			}
			rsFormattedRS.setColumnHeading(1, "Catalog Number");
			rsFormattedRS.setColumnHeading(2, "Start Date");
			rsFormattedRS.setColumnHeading(3, "End  Date");
			rsFormattedRS.setColumnHeading(4, "Description");
			rsFormattedRS.sort(1, true);
			return rsFormattedRS;
		}
		finally
		{
			rsFormattedRS = null;
			strEngine = null;
			arrlstTemp = null;
			geAETag = null;
		}

	}
	private GEAEResultSet formatComponentResultSet(GEAEResultSet rsSearchResults, boolean blnEditable) throws Exception
	{
		GEAEResultSet rsFormattedRS = null;
		ArrayList arrlstTemp = null;
		String strCode = "";
		int intCoulmns = 0;
		GEAETag geAETag = null;

		try
		{
			rsFormattedRS = new GEAEResultSet();
			rsSearchResults.setCurrentRow(0);




			while (rsSearchResults.next())
			{



				arrlstTemp = new ArrayList();

				if (blnEditable)
				{
					geAETag =
						new GEAETag(
							"",
							"<INPUT TYPE='checkbox' NAME='checkBox' VALUE='" + rsSearchResults.getString("code") + eCRDConstants.STRCOLUMNDELIM + rsSearchResults.getString("module_seq_id") + "'>");
					arrlstTemp.add(geAETag);
				}

				strCode =
					"<A HREF=\"javascript:fnSelectRepairComponent('"
						+ rsSearchResults.getString("code")
						+ "','"
						+ rsSearchResults.getString("module_seq_id")
						+ "')\">"
						+ rsSearchResults.getString("code")
						+ "</A>";
				geAETag = new GEAETag(rsSearchResults.getString("code"), strCode);
				arrlstTemp.add(geAETag);
				arrlstTemp.add(rsSearchResults.getString("description"));
				arrlstTemp.add(rsSearchResults.getString("ata_ref_num"));
				if ("".equals(eCRDUtil.verifyNull(rsSearchResults.getString("tat"))))
				{
					arrlstTemp.add(rsSearchResults.getString("tat"));
				}
				else
				{
					arrlstTemp.add(new Integer(rsSearchResults.getString("tat")));
				}
				arrlstTemp.add(rsSearchResults.getString("site"));
				arrlstTemp.add(rsSearchResults.getString("class"));
				arrlstTemp.add(rsSearchResults.getString("part"));
				rsFormattedRS.addRow(arrlstTemp);
				arrlstTemp = null;
				geAETag = null;

			}
			if (blnEditable)
			{
				intCoulmns = 1;
				rsFormattedRS.setColumnHeading(intCoulmns, "Select");
			}
			else
			{
				intCoulmns = 0;
			}
			rsFormattedRS.setColumnHeading(intCoulmns + 1, "Component Code");
			rsFormattedRS.setColumnHeading(intCoulmns + 2, "Component Description");
			rsFormattedRS.setColumnHeading(intCoulmns + 3, "ATA Reference Number");
			rsFormattedRS.setColumnHeading(intCoulmns + 4, "Baseline TAT");
			rsFormattedRS.setColumnHeading(intCoulmns + 5, "Sites");
			rsFormattedRS.setColumnHeading(intCoulmns + 6, "Class");
			rsFormattedRS.setColumnHeading(intCoulmns + 7, "Part Nos");

			if (blnEditable)
			{
				intCoulmns = 1;
				rsFormattedRS.sort(2, true);
			}
			else
			{
				rsFormattedRS.sort(1, true);
			}

			return rsFormattedRS;
		}
		finally
		{
			rsFormattedRS = null;
			arrlstTemp = null;
			strCode = null;
			geAETag = null;
		}

	}

	private GEAEResultSet formatCustomerResultSet(GEAEResultSet rsSearchResults) throws Exception
	{
		GEAEResultSet rsFormattedRS = null;
		ArrayList arrlstTemp = null;
		GEAETag geAETag = null;
		try
		{
			rsFormattedRS = new GEAEResultSet();
			rsSearchResults.setCurrentRow(0);
			while (rsSearchResults.next())
			{
				arrlstTemp = new ArrayList();

				geAETag =
					new GEAETag(
						"",
						"<INPUT TYPE='RADIO' NAME='radio' value='" + rsSearchResults.getString("customer_code") + eCRDConstants.STRCOLUMNDELIM + rsSearchResults.getString("customer_name") + "'>");
				arrlstTemp.add(geAETag);
				arrlstTemp.add(rsSearchResults.getString(1));
				arrlstTemp.add(rsSearchResults.getString(2));
				rsFormattedRS.addRow(arrlstTemp);
			}
			rsFormattedRS.setColumnHeading(1, "Select");
			rsFormattedRS.setColumnHeading(2, "Customer Code");
			rsFormattedRS.setColumnHeading(3, "Customer Name");
			rsFormattedRS.sort(3, true);
			return rsFormattedRS;
		}
		finally
		{
			rsFormattedRS = null;
			arrlstTemp = null;
			geAETag = null;

		}

	}

	private GEAEResultSet formatApproveCompSiteResultSet(GEAEResultSet rsSearchResults) throws Exception
	{

		GEAEResultSet rsFormattedRS = null;
		String strApprove = "";
		String strReject = "";
		ArrayList arrlstTemp = null;
		GEAETag geAETag = null;
		String strRequestedBy = "";
		String strLocationCode = "";
		String strModule = "";
		String strCmpCode = "";
		String strChgStrtDt = "";
		String strEmailId = "";
		int intName = 0;
		String strComments = "";
		try
		{

			rsFormattedRS = new GEAEResultSet();
			arrlstTemp = new ArrayList();
			rsSearchResults.setCurrentRow(0);
			while (rsSearchResults.next())
			{
				intName++;
				arrlstTemp = new ArrayList();
				strLocationCode = rsSearchResults.getString("location_id");
				strModule = rsSearchResults.getString("engine_module");
				strCmpCode = rsSearchResults.getString("component_code");
				strChgStrtDt = rsSearchResults.getString("change_start_date");
				strEmailId = rsSearchResults.getString("email_id");
				arrlstTemp.add(rsSearchResults.getString("engine_model"));
				arrlstTemp.add(rsSearchResults.getString("eng_module_desc"));
				arrlstTemp.add(strCmpCode);
				arrlstTemp.add(rsSearchResults.getString("description"));
				arrlstTemp.add(rsSearchResults.getString("location"));
				strRequestedBy = "<A href=mailto:" + strEmailId + ">" + rsSearchResults.getString("first_name") + "  " + rsSearchResults.getString("last_name") + "</A>";
				geAETag = new GEAETag(rsSearchResults.getString("first_name") + "  " + rsSearchResults.getString("last_name"), strRequestedBy);
				arrlstTemp.add(geAETag);
				geAETag = new GEAETag(rsSearchResults.getString("sortable_requested_date"), rsSearchResults.getString("requested_date"));
				arrlstTemp.add(geAETag);
				strApprove =
					"<INPUT TYPE='radio' NAME='radio"
						+ String.valueOf(intName)
						+ "' VALUE='A"
						+ eCRDConstants.STRCOLUMNDELIM
						+ strModule
						+ eCRDConstants.STRCOLUMNDELIM
						+ strCmpCode
						+ eCRDConstants.STRCOLUMNDELIM
						+ strLocationCode
						+ eCRDConstants.STRCOLUMNDELIM
						+ strChgStrtDt
						+ "'>";
				geAETag = new GEAETag("", strApprove);
				arrlstTemp.add(geAETag);
				strReject =
					"<INPUT TYPE='radio' NAME='radio"
						+ String.valueOf(intName)
						+ "'VALUE='R"
						+ eCRDConstants.STRCOLUMNDELIM
						+ strModule
						+ eCRDConstants.STRCOLUMNDELIM
						+ strCmpCode
						+ eCRDConstants.STRCOLUMNDELIM
						+ strLocationCode
						+ eCRDConstants.STRCOLUMNDELIM
						+ strChgStrtDt
						+ "'>";
				geAETag = new GEAETag("", strReject);
				arrlstTemp.add(geAETag);
				//strComments = "<INPUT TYPE='textarea' NAME='txtComment' VALUE='' ROWS='2' COLS='10'>";
				strComments = "<TEXTAREA CLASS='f2' NAME='txtComment' ROWS='2' COLS='10'></TEXTAREA>";
				geAETag = new GEAETag("", strComments);
				arrlstTemp.add(geAETag);
				rsFormattedRS.addRow(arrlstTemp);

			}
			rsFormattedRS.setColumnHeading(1, "Engine Model");
			rsFormattedRS.setColumnHeading(2, "Engine Module");
			rsFormattedRS.setColumnHeading(3, "Component Code");
			rsFormattedRS.setColumnHeading(4, "Component Description");
			rsFormattedRS.setColumnHeading(5, "Site");
			rsFormattedRS.setColumnHeading(6, "Requested By");
			rsFormattedRS.setColumnHeading(7, "Request Date");
			rsFormattedRS.setColumnHeading(8, "Approve");
			rsFormattedRS.setColumnHeading(9, "Reject");
			rsFormattedRS.setColumnHeading(10, "Comments");
			rsFormattedRS.sort(1, true);
			return rsFormattedRS;
		}
		finally
		{
			rsFormattedRS = null;
			strApprove = null;
			strReject = null;
			arrlstTemp = null;
			geAETag = null;
			strRequestedBy = null;
			strLocationCode = null;
			strModule = null;
			strCmpCode = null;
			strChgStrtDt = null;
			strEmailId = null;
			strComments = null;
		}

	}
	private GEAEResultSet formatTCApproveCompSiteResultSet(GEAEResultSet rsSearchResults) throws Exception
	{

		GEAEResultSet rsFormattedRS = null;
		ArrayList arrlstTemp = null;
		GEAETag geAETag = null;
		String strModule = null;
		String strCmpCode = null;
		int intName = 0;
		try
		{

			rsFormattedRS = new GEAEResultSet();
			arrlstTemp = new ArrayList();
			rsSearchResults.setCurrentRow(0);
			while (rsSearchResults.next())
			{
				intName++;
				arrlstTemp = new ArrayList();
				strModule = rsSearchResults.getString("engine_module");
				strCmpCode = rsSearchResults.getString("component_code");
				arrlstTemp.add(rsSearchResults.getString("engine_model"));
				arrlstTemp.add(rsSearchResults.getString("eng_module_desc"));
				arrlstTemp.add(strCmpCode);
				arrlstTemp.add(rsSearchResults.getString("description"));
				arrlstTemp.add(rsSearchResults.getString("location"));
				arrlstTemp.add(rsSearchResults.getString("first_name") + "  " + rsSearchResults.getString("last_name"));
				geAETag = new GEAETag(rsSearchResults.getString("sortable_requested_date"), rsSearchResults.getString("requested_date"));
				arrlstTemp.add(geAETag);
				rsFormattedRS.addRow(arrlstTemp);
			}
			rsFormattedRS.setColumnHeading(1, "Engine Model");
			rsFormattedRS.setColumnHeading(2, "Engine Module");
			rsFormattedRS.setColumnHeading(3, "Component Code");
			rsFormattedRS.setColumnHeading(4, "Component Description");
			rsFormattedRS.setColumnHeading(5, "Site");
			rsFormattedRS.setColumnHeading(6, "Requested By");
			rsFormattedRS.setColumnHeading(7, "Request Date");
			rsFormattedRS.sort(1, true);
			return rsFormattedRS;
		}
		finally
		{
			rsFormattedRS = null;
			arrlstTemp = null;
			geAETag = null;
			strModule = null;
			strCmpCode = null;
		}
	}

	//ehren start
	/**
	 * Method to show the default component rowcache.
	 * @param request
	 * @return void
	 * throws Exception
	 */
	private void getDefaultComponentList(HttpServletRequest request) throws Exception
	{

		eCRDCatalog objeCRDCatalog = null;
		eCRDException objeCRDException = null;
		eCRDBusinessBean objeCRDBusinessBean = null;
		eCRDDataBean objeCRDDataBean = null;
		GEAEResultSet rsComponent = null;
		String strModule_Seq_Id = "";
		String strCatalog_Seq_Id = "";
		String strActionId = "";

		boolean blnEditable = false;
		ArrayList arrLstInParam = null;

		try
		{
			strActionId = eCRDConstants.getActionId("eCRD_DEFAULT_COMPONENT_LISTING_RC");
			strModule_Seq_Id = eCRDUtil.verifyNull(request.getParameter("selModule"));

			if ("".equals(strModule_Seq_Id))
			{
				strModule_Seq_Id = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE));
			}

			objeCRDBusinessBean = new eCRDBusinessBean();
			objeCRDDataBean = new eCRDDataBean();
			rsComponent = new GEAEResultSet();
			arrLstInParam = new ArrayList();

			objeCRDCatalog = (eCRDCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
			if (objeCRDCatalog == null)
			{
				objeCRDException = new eCRDException();
				objeCRDException.setExcpId("CATALOG_NOT_SET");
				throw objeCRDException;
			}
			strCatalog_Seq_Id = eCRDUtil.verifyNull(objeCRDCatalog.getCatalogSeqId());


			arrLstInParam.add(strCatalog_Seq_Id);
			arrLstInParam.add(strModule_Seq_Id);



			rsComponent = objeCRDBusinessBean.populateComponentList(strActionId, arrLstInParam);




			rsComponent = formatComponentResultSetFromDefault(rsComponent, blnEditable);




			objeCRDDataBean.setCache(rsComponent);
			eCRDUtil.loadInSession(request, "eCRDDefaultComponentList", objeCRDDataBean);
			eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODULECODE, strModule_Seq_Id);
		}
		finally
		{
			objeCRDCatalog = null;
			objeCRDBusinessBean = null;
			objeCRDDataBean = null;
			rsComponent = null;
			strModule_Seq_Id = null;
			strCatalog_Seq_Id = null;
			strActionId = null;

			arrLstInParam = null;
		}
	}
//ehren end

    /**
     * This method is used to Format the resultset that is used for Displayu in RC.
     * @param GEAEResultSet
     * @param boolean
     * @return GEAEResultSet
     * throws Exception
     */
    private GEAEResultSet formatComponentResultSetFromDefault(GEAEResultSet rsSearchResults, boolean blnEditable) throws Exception
    {
	    GEAEResultSet rsFormattedRS = null;
	    ArrayList arrlstTemp = null;
	    String strCode = "";
	    int intCoulmns = 0;
	    GEAETag geAETag = null;

	    try
	    {
		    rsFormattedRS = new GEAEResultSet();
		    rsSearchResults.setCurrentRow(0);



		    while (rsSearchResults.next())
		    {



			    arrlstTemp = new ArrayList();

			    strCode =
				    "<A HREF=\"javascript:fnSelectRepairComponentFromDefault('"
					    + rsSearchResults.getString("code")
					    + "','"
					    + rsSearchResults.getString("module_seq_id")
					    + "')\">"
					    + rsSearchResults.getString("code")
					    + "</A>";
			    geAETag = new GEAETag(rsSearchResults.getString("code"), strCode);
			    arrlstTemp.add(geAETag);
			    arrlstTemp.add(rsSearchResults.getString("description"));
			    arrlstTemp.add(rsSearchResults.getString("ata_ref_num"));
			    if ("".equals(eCRDUtil.verifyNull(rsSearchResults.getString("tat"))))
			    {
				    arrlstTemp.add(rsSearchResults.getString("tat"));
			    }
			    else
			    {
				    arrlstTemp.add(new Integer(rsSearchResults.getString("tat")));
			    }
			    arrlstTemp.add(rsSearchResults.getString("site"));
			    arrlstTemp.add(rsSearchResults.getString("class"));
			    arrlstTemp.add(rsSearchResults.getString("part"));
			    rsFormattedRS.addRow(arrlstTemp);
			    arrlstTemp = null;
			    geAETag = null;

		    }

		    rsFormattedRS.setColumnHeading(intCoulmns + 1, "Component Code");
		    rsFormattedRS.setColumnHeading(intCoulmns + 2, "Component Description");
		    rsFormattedRS.setColumnHeading(intCoulmns + 3, "ATA Reference Number");
		    rsFormattedRS.setColumnHeading(intCoulmns + 4, "Baseline TAT");
		    rsFormattedRS.setColumnHeading(intCoulmns + 5, "Sites");
		    rsFormattedRS.setColumnHeading(intCoulmns + 6, "Class");
		    rsFormattedRS.setColumnHeading(intCoulmns + 7, "Part Nos");

		    if (blnEditable)
		    {
			    intCoulmns = 1;
			    rsFormattedRS.sort(2, true);
		    }
		    else
		    {
			    rsFormattedRS.sort(1, true);
		    }

		    return rsFormattedRS;
	    }
	    finally
	    {
		    rsFormattedRS = null;
		    arrlstTemp = null;
		    strCode = null;
		    geAETag = null;
	    }
    }

	 /**
	  * This method is used to get the Repair Listing for
	  * Default Catalog without repairs that are present in Customer Catalogs.
	  * @param request
	  * @return void
	  * throws Exception
	  */
    
    			//doubt
	 public void getRepairListing(HttpServletRequest request) throws Exception
	 {

		 eCRDCatalog objeCRDCatalog = null;
		 eCRDDefaultCatalog objeCRDDefaultCatalog = null;
		 eCRDCustomerCatalog objeCRDCustomerCatalog = null;
		 eCRDException objeCRDException = null;
		 eCRDEngineModel objeCRDEngineModel = null;
		 String strCatalogSeqId = "";
		 String strComponentCode = "";
		 String strModuleCode = "";
		 String strCatalogType = "";
		 String strActionId = "";
		 String strEngineModelCode = "";
		 ArrayList arrlstOutParam = null;
		 GEAEResultSet rsRepairs = null;
		 eCRDSearchBean objeCRDSearchBean = null;
		 try
		 {

			 objeCRDCatalog = (eCRDCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
			 if (objeCRDCatalog == null)
			 {
				 objeCRDException = new eCRDException();
				 objeCRDException.setExcpId("CATALOG_NOT_SET");
				 throw objeCRDException;

			 }
			 strCatalogSeqId = objeCRDCatalog.getCatalogSeqId();
			 strCatalogType = eCRDUtil.verifyNull(objeCRDCatalog.getCatalogType());
			 objeCRDSearchBean = new eCRDSearchBean();


			 if (eCRDConstants.STRDEFAULTCATALOGTYPE.equals(strCatalogType))
			 {

				 objeCRDDefaultCatalog = (eCRDDefaultCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
				 if (objeCRDDefaultCatalog == null)
				 {
					 objeCRDDefaultCatalog = new eCRDDefaultCatalog();
				 }
				 objeCRDEngineModel = objeCRDDefaultCatalog.getEngineModel();
				 if (objeCRDEngineModel == null)
				 {
					 objeCRDEngineModel = new eCRDEngineModel();
				 }
				 strEngineModelCode = objeCRDEngineModel.getEngineModelCode();
			 }
			 else
			 {
				 objeCRDCustomerCatalog = (eCRDCustomerCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
				 if (objeCRDCustomerCatalog == null)
				 {
					 objeCRDCustomerCatalog = new eCRDCustomerCatalog();
				 }
				 objeCRDEngineModel = objeCRDCustomerCatalog.getEngineModel();

				 if (objeCRDEngineModel == null)
				 {
					 objeCRDEngineModel = new eCRDEngineModel();
				 }
				 strEngineModelCode = objeCRDEngineModel.getEngineModelCode();
			 }

			 rsRepairs = new GEAEResultSet();
			 strActionId = eCRDConstants.getActionId("eCRD_DEFAULT_REPAIR_LISTING");
			 strComponentCode = eCRDUtil.verifyNull(request.getParameter("hdnComponentCode"));
			 strModuleCode = eCRDUtil.verifyNull(request.getParameter("selModule"));
			 eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODELCODE, strEngineModelCode);
			 eCRDUtil.loadInSession(request, eCRDConstants.STRCOMPONENTCODE, strComponentCode);
			 eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODULECODE, strModuleCode);
			 eCRDUtil.loadInSession(request, "strFrom", "ComponentListing");


			 arrlstOutParam = objeCRDSearchBean.getDefaultRepairListing(strCatalogSeqId, strEngineModelCode, strModuleCode, "1", strComponentCode, strActionId);
			 rsRepairs = (GEAEResultSet) arrlstOutParam.get(0);

			 request.setAttribute("rsRepairs", rsRepairs);
		 }
		 finally
		 {
			 objeCRDCatalog = null;
			 objeCRDDefaultCatalog = null;
			 objeCRDCustomerCatalog = null;
			 objeCRDEngineModel = null;
			 strComponentCode = null;
			 strModuleCode = null;
			 strCatalogType = null;
			 strActionId = null;
			 strEngineModelCode = null;
			 arrlstOutParam = null;
			 rsRepairs = null;
			 objeCRDSearchBean = null;
		 }
	 }

	 private void getPricingComponentList(HttpServletRequest request) throws Exception
		{

			eCRDBusinessBean objeCRDBusinessBean = null;
			GEAEResultSet rsFormatted = null;
			GEAEResultSet rsEngineCatalog = null;
			eCRDDataBean objeCRDDataBean = null;
			String strCustomerCode = "";
			String strEngineModelNumber = "";
			String strStartDate = "";
			String strEndDate = "";
			String strActionId = "";
			ArrayList arrLstInParam = null;
			String strCatalogType = "";
			String strCatalogNum = null ;
			String strReport ="";
			String strFrom = null;
			int scnarioId=0;
			int projectId=0;
			HttpSession session = request.getSession(false);

			if(session.getAttribute("scenarioId")!=null)
				scnarioId = Integer.parseInt((session.getAttribute("scenarioId").toString()));
					if(session.getAttribute("projectId")!=null)
						projectId =Integer.parseInt((session.getAttribute("projectId").toString()));
			try
			{



				rsFormatted = new GEAEResultSet();
				rsEngineCatalog = new GEAEResultSet();
				objeCRDDataBean = new eCRDDataBean();
				arrLstInParam = new ArrayList();

				objeCRDBusinessBean = new eCRDBusinessBean();
				strActionId = eCRDConstants.getActionId("eCRD_PRCNGCOMP_LIST");
				//strFrom = eCRDUtil.verifyNull(request.getParameter("hdnFrom"));
				//          strCustomerCode = eCRDUtil.verifyNull(request.getParameter("selCustomer"));
				/*strCustomerCode = eCRDAppSecurityUtil.deleteSplChars(eCRDUtil.verifyNullNoTrim(request.getParameter("hdnCustCode")));
				if ("".equals(strCustomerCode))
				{
					strCustomerCode = eCRDAppSecurityUtil.deleteSplChars(eCRDUtil.verifyNullNoTrim(request.getParameter("txtCustCode")));
				}
				strEngineModelNumber = eCRDUtil.verifyNull(request.getParameter("selEngModel"));
				strStartDate = eCRDUtil.verifyNull(request.getParameter("hdnStartDate"));
				strEndDate = eCRDUtil.verifyNull(request.getParameter("hdnEndDate"));
				strCatalogType = eCRDUtil.verifyNull(request.getParameter("radCatalog"));
				if("eCRDAddRepToCSC".equals(strFrom))
				{
					strCatalogType = eCRDConstants.STRCUSTOMERCATALOGTYPE;
				}
				strCatalogNum  = eCRDAppSecurityUtil.deleteSplChars(eCRDUtil.verifyNull(request.getParameter("txtCatalogNum")));
				eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODELCODE, strEngineModelNumber);*/
			/*	arrLstInParam.add(strCustomerCode);
				arrLstInParam.add(strEngineModelNumber);
				arrLstInParam.add(strStartDate);
				arrLstInParam.add(strEndDate);
				arrLstInParam.add(strCatalogType);
				arrLstInParam.add(strCatalogNum);*/

				/*arrLstInParam.add("abc");
				arrLstInParam.add("256");
				arrLstInParam.add("21/5/2000");
				arrLstInParam.add("21/8/2000");
				arrLstInParam.add("My");
				arrLstInParam.add("2144");*/
			//	rsEngineCatalog = objeCRDBusinessBean.populateCatalogList(strActionId, arrLstInParam);
				arrLstInParam.add(Integer.toString(projectId));
				arrLstInParam.add(Integer.toString(scnarioId));
				rsEngineCatalog = objeCRDBusinessBean.populateComponentList(strActionId, arrLstInParam);//new
				strReport = eCRDUtil.verifyNull(request.getParameter("hdnReport"));
				rsFormatted = formatPricingComponentResultSet(rsEngineCatalog,strReport);//new
				objeCRDDataBean.setCache(rsFormatted);
				eCRDUtil.loadInSession(request, "eCRDCatalogList", objeCRDDataBean);
			}
			finally
			{

				rsEngineCatalog = null;
				rsFormatted = null;
				objeCRDDataBean = null;
				objeCRDBusinessBean = null;
				strEngineModelNumber = null;
				strCustomerCode = null;
				strStartDate = null;
				strEndDate = null;
				strActionId = null;
				arrLstInParam = null;

			}

		}



	 private void getCustomerEscalationCap(HttpServletRequest request) throws Exception
		{

			eCRDBusinessBean objeCRDBusinessBean = null;
			GEAEResultSet rsFormatted = null;
			GEAEResultSet rsEngineCatalog = null;
			eCRDDataBean objeCRDDataBean = null;
			String strCustomerCode = "";
			String strEngineModelNumber = "";
			String strStartDate = "";
			String strEndDate = "";
			String strActionId = "";
			ArrayList arrLstInParam = null;
			String strCatalogType = "";
			String strCatalogNum = null ;
			String strReport ="";
			String strFrom = null;
			int scnarioId=0;
			int projectId=0;
			HttpSession session = request.getSession(false);


			try
			{



				rsFormatted = new GEAEResultSet();
				rsEngineCatalog = new GEAEResultSet();
				objeCRDDataBean = new eCRDDataBean();
				arrLstInParam = new ArrayList();

				objeCRDBusinessBean = new eCRDBusinessBean();
				strActionId = eCRDConstants.getActionId("eCRD_GET_CUSTOMER_ESC");
				//strFrom = eCRDUtil.verifyNull(request.getParameter("hdnFrom"));
				//          strCustomerCode = eCRDUtil.verifyNull(request.getParameter("selCustomer"));
				/*strCustomerCode = eCRDAppSecurityUtil.deleteSplChars(eCRDUtil.verifyNullNoTrim(request.getParameter("hdnCustCode")));
				if ("".equals(strCustomerCode))
				{
					strCustomerCode = eCRDAppSecurityUtil.deleteSplChars(eCRDUtil.verifyNullNoTrim(request.getParameter("txtCustCode")));
				}
				strEngineModelNumber = eCRDUtil.verifyNull(request.getParameter("selEngModel"));
				strStartDate = eCRDUtil.verifyNull(request.getParameter("hdnStartDate"));
				strEndDate = eCRDUtil.verifyNull(request.getParameter("hdnEndDate"));
				strCatalogType = eCRDUtil.verifyNull(request.getParameter("radCatalog"));
				if("eCRDAddRepToCSC".equals(strFrom))
				{
					strCatalogType = eCRDConstants.STRCUSTOMERCATALOGTYPE;
				}
				strCatalogNum  = eCRDAppSecurityUtil.deleteSplChars(eCRDUtil.verifyNull(request.getParameter("txtCatalogNum")));
				eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODELCODE, strEngineModelNumber);*/
			/*	arrLstInParam.add(strCustomerCode);
				arrLstInParam.add(strEngineModelNumber);
				arrLstInParam.add(strStartDate);
				arrLstInParam.add(strEndDate);
				arrLstInParam.add(strCatalogType);
				arrLstInParam.add(strCatalogNum);*/

				/*arrLstInParam.add("abc");
				arrLstInParam.add("256");
				arrLstInParam.add("21/5/2000");
				arrLstInParam.add("21/8/2000");
				arrLstInParam.add("My");
				arrLstInParam.add("2144");*/
			//	rsEngineCatalog = objeCRDBusinessBean.populateCatalogList(strActionId, arrLstInParam);
				arrLstInParam.add(Integer.toString(projectId));
				arrLstInParam.add(Integer.toString(scnarioId));
				rsEngineCatalog = objeCRDBusinessBean.populateComponentList(strActionId, arrLstInParam);//new
				strReport = eCRDUtil.verifyNull(request.getParameter("hdnReport"));
				rsFormatted = formatCustomerEscResultSet(rsEngineCatalog,strReport);//new
				objeCRDDataBean.setCache(rsFormatted);
				eCRDUtil.loadInSession(request, "eCRDCustomerEsc", objeCRDDataBean);
			}
			finally
			{

				rsEngineCatalog = null;
				rsFormatted = null;
				objeCRDDataBean = null;
				objeCRDBusinessBean = null;
				strEngineModelNumber = null;
				strCustomerCode = null;
				strStartDate = null;
				strEndDate = null;
				strActionId = null;
				arrLstInParam = null;

			}

		}

	 /**
	  *
	  * @param request
	  * @throws Exception
	  */
	 private void getCRMDataComponentList(HttpServletRequest request) throws Exception
		{

			eCRDBusinessBean objeCRDBusinessBean = null;
			GEAEResultSet rsFormatted = null;
			GEAEResultSet rsEngineCatalog = null;
			eCRDDataBean objeCRDDataBean = null;
			String strActionId = "";
			ArrayList arrLstInParam = null;
			String strReport ="";
			int scnarioId=0;
			int projectId=0;
			HttpSession session = request.getSession(false);

			if (session.getAttribute("scenarioId") != null) {
				scnarioId = Integer.parseInt((session.getAttribute("scenarioId").toString()));
			}
			if (session.getAttribute("projectId") != null) {
				projectId =Integer.parseInt((session.getAttribute("projectId").toString()));
			}

			try {
				rsFormatted = new GEAEResultSet();
				rsEngineCatalog = new GEAEResultSet();
				objeCRDDataBean = new eCRDDataBean();
				arrLstInParam = new ArrayList();

				arrLstInParam.add(Integer.toString(projectId));
				arrLstInParam.add(Integer.toString(scnarioId));

				objeCRDBusinessBean = new eCRDBusinessBean();
				strActionId = eCRDConstants.getActionId("eCRD_CRM_DATA_LIST");

				rsEngineCatalog = objeCRDBusinessBean.populateComponentList(strActionId, arrLstInParam);
				strReport = eCRDUtil.verifyNull(request.getParameter("hdnReport"));
				rsFormatted = formatCRMDataResultSet(rsEngineCatalog,strReport);//new
				objeCRDDataBean.setCache(rsFormatted);
				eCRDUtil.loadInSession(request, "eCRDCRMDataList", objeCRDDataBean);
			}
			finally
			{

				rsEngineCatalog = null;
				rsFormatted = null;
				objeCRDDataBean = null;
				objeCRDBusinessBean = null;
				strActionId = null;
				arrLstInParam = null;

			}

		}


	 /**
	  *
	  * @param rsSearchResults
	  * @param strReport
	  * @return
	  * @throws Exception
	  */
	 private GEAEResultSet formatCRMDataResultSet(GEAEResultSet rsSearchResults,String strReport) throws Exception
		{

			GEAEResultSet rsFormattedRS = null;
			String repairType = "";
			final String quoteDisplayVal = "";
			ArrayList arrlstTemp = null;
			GEAETag geAETag = null;
			try
			{
				rsFormattedRS = new GEAEResultSet();
				rsSearchResults.setCurrentRow(0);
				while (rsSearchResults.next())
				{

					arrlstTemp = new ArrayList();
					geAETag = new GEAETag((rsSearchResults.getString("COMPONENT_CODE")),(rsSearchResults.getString("COMPONENT_CODE")));
					arrlstTemp.add(geAETag);
					geAETag = new GEAETag(rsSearchResults.getString("COMPONENT_DESC"),rsSearchResults.getString("COMPONENT_DESC"));
					arrlstTemp.add(geAETag);

					geAETag = new GEAETag(Integer.toString(rsSearchResults.getInt("REPAIR_SEQ")),Integer.toString(rsSearchResults.getInt("REPAIR_SEQ")));
					arrlstTemp.add(geAETag);
					geAETag = new GEAETag(rsSearchResults.getString("REPAIR_DESC"),rsSearchResults.getString("REPAIR_DESC"));
					arrlstTemp.add(geAETag);

					repairType = rsSearchResults.getString("REPAIR_TYPE");
					if(repairType != null && "quote".equalsIgnoreCase(repairType)) {
						geAETag = new GEAETag(quoteDisplayVal, quoteDisplayVal);// REPAIR_PRICE
						arrlstTemp.add(geAETag);
						geAETag = new GEAETag(quoteDisplayVal, quoteDisplayVal);// NEW_REPAIR_PRICE
						arrlstTemp.add(geAETag);
					} else {
					//	geAETag = new GEAETag(Double.toString(rsSearchResults.getDouble("REPAIR_PRICE")),Double.toString(rsSearchResults.getDouble("REPAIR_PRICE")));
						geAETag = new GEAETag((Integer.toString((new Double(rsSearchResults.getDouble("REPAIR_PRICE")).intValue()))),
								(Integer.toString((new Double(rsSearchResults.getDouble("REPAIR_PRICE")).intValue()))));
						arrlstTemp.add(geAETag);
						geAETag = new GEAETag((Integer.toString((new Double(rsSearchResults.getDouble("NEW_REPAIR_PRICE")).intValue()))),
								(Integer.toString((new Double(rsSearchResults.getDouble("NEW_REPAIR_PRICE")).intValue()))));
						//geAETag = new GEAETag(Double.toString(rsSearchResults.getDouble("NEW_REPAIR_PRICE")),Double.toString(rsSearchResults.getDouble("NEW_REPAIR_PRICE")));
						arrlstTemp.add(geAETag);
					}

					geAETag = new GEAETag(rsSearchResults.getString("ATA_CHAPAR"),(rsSearchResults.getString("ATA_CHAPAR")));
					arrlstTemp.add(geAETag);
					geAETag = new GEAETag(Double.toString(rsSearchResults.getDouble("QPE")),Double.toString(rsSearchResults.getDouble("QPE")));
					arrlstTemp.add(geAETag);



					rsFormattedRS.addRow(arrlstTemp);
					arrlstTemp = null;
					geAETag = null;
				}
				rsFormattedRS.setColumnHeading(1, "Component Code");
				rsFormattedRS.setColumnHeading(2, "Component Description");
				rsFormattedRS.setColumnHeading(3, "Repair Seq");
				rsFormattedRS.setColumnHeading(4, "Repair Description");
				rsFormattedRS.setColumnHeading(5, "Repair Price");
				rsFormattedRS.setColumnHeading(6, "New Repair Price");
				rsFormattedRS.setColumnHeading(7, "ATA Chapter");
				rsFormattedRS.setColumnHeading(8, "QPE");


				rsFormattedRS.sort(1, true);
				return rsFormattedRS;
			}
			finally
			{
				rsFormattedRS = null;
				repairType = null;
				arrlstTemp = null;
				geAETag = null;
			}

		}



	 private void getWinRateDataComponentList(HttpServletRequest request) throws Exception
		{

			eCRDBusinessBean objeCRDBusinessBean = null;

			GEAEResultSet rsFormatted = null;
			GEAEResultSet rsEngineCatalog = null;
			eCRDDataBean objeCRDDataBean = null;
			String strCustomerCode = "";
			String strEngineModelNumber = "";
			String strStartDate = "";
			String strEndDate = "";
			String strActionId = "";

			ArrayList arrLstInParam = null;
			String strCatalogType = "";
			String strCatalogNum = null ;
			String strReport ="";
			String strFrom = null;
			int scnarioId=0;
			int projectId=0;
			HttpSession session = request.getSession(false);

			if(session.getAttribute("scenarioId")!=null)
				scnarioId = Integer.parseInt((session.getAttribute("scenarioId").toString()));
					if(session.getAttribute("projectId")!=null)
						projectId =Integer.parseInt((session.getAttribute("projectId").toString()));
			try
			{

				rsFormatted = new GEAEResultSet();
				rsEngineCatalog = new GEAEResultSet();
				objeCRDDataBean = new eCRDDataBean();
				arrLstInParam = new ArrayList();

				// to do
				arrLstInParam.add(Integer.toString(projectId));
				arrLstInParam.add(Integer.toString(scnarioId));//pass value for prj id

				// ends to do

				objeCRDBusinessBean = new eCRDBusinessBean();
				strActionId = eCRDConstants.getActionId("eCRD_WIN_RATE_DATA_LIST");

				rsEngineCatalog = objeCRDBusinessBean.populateComponentList(strActionId, arrLstInParam);
				strReport = eCRDUtil.verifyNull(request.getParameter("hdnReport"));
				rsFormatted = formatWinRateDataResultSet(rsEngineCatalog,strReport);//new
				objeCRDDataBean.setCache(rsFormatted);
				eCRDUtil.loadInSession(request, "ecrdWinRateDataList", objeCRDDataBean);
			}
			finally
			{

				rsEngineCatalog = null;
				rsFormatted = null;
				objeCRDDataBean = null;
				objeCRDBusinessBean = null;
				strEngineModelNumber = null;
				strCustomerCode = null;
				strStartDate = null;
				strEndDate = null;
				strActionId = null;
				arrLstInParam = null;

			}

		}

	 private void getMetrioDataListInt(HttpServletRequest request) throws Exception
		{

			GEAEResultSet rsFormatted = null;
			GEAEResultSet rsEngineCatalog = null;
			eCRDDataBean objeCRDDataBean = null;
			String strActionId = "";
			ArrayList arrLstInParam = null;
			String strReport ="";
			String lastUpdatedDate = "";
			int scnarioId=0;
			int projectId=0;

			HttpSession session = request.getSession(false);
			if(session.getAttribute("scenarioId")!=null)
				scnarioId = Integer.parseInt((session.getAttribute("scenarioId").toString()));
			if(session.getAttribute("projectId")!=null)
				projectId =Integer.parseInt((session.getAttribute("projectId").toString()));

			try {


				rsFormatted = new GEAEResultSet();
				rsEngineCatalog = new GEAEResultSet();
				objeCRDDataBean = new eCRDDataBean();
				arrLstInParam = new ArrayList();

				arrLstInParam.add(Integer.toString(projectId));
				arrLstInParam.add(Integer.toString(scnarioId));

				strActionId = eCRDConstants.getActionId("eCRD_METRIO_DATA_LIST_INT");
				//strActionId2 = eCRDConstants.getActionId("eCRD_METRIO_DATA_LIST_INT");
				//rsEngineCatalog = objeCRDBusinessBean.populateComponentList(strActionId, arrLstInParam);

				ArrayList arrLstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrLstInParam);
				rsEngineCatalog = (GEAEResultSet) arrLstOutParam.get(0);
				lastUpdatedDate = (String) arrLstOutParam.get(1);

				strReport = eCRDUtil.verifyNull(request.getParameter("hdnReport"));
				rsFormatted = formatMetrioDataResultSet(rsEngineCatalog,strReport);//new
				objeCRDDataBean.setCache(rsFormatted);
				eCRDUtil.loadInSession(request, "ecrdMetrioDataList", objeCRDDataBean);
			}
			finally
			{

				rsEngineCatalog = null;
				rsFormatted = null;
				objeCRDDataBean = null;
				strActionId = null;
				arrLstInParam = null;
			}
			session.setAttribute("selectedCustomer", "Internal");
			session.setAttribute("lastUpdatedDate", lastUpdatedDate);
		}


	 private void getMetrioDataListExt(HttpServletRequest request) throws Exception
		{

			GEAEResultSet rsFormatted = null;
			GEAEResultSet rsEngineCatalog = null;
			eCRDDataBean objeCRDDataBean = null;
			String strActionId = "";
			ArrayList arrLstInParam = null;
			String strReport ="";
			String lastUpdatedDate = "";

			int scnarioId=0;
			int projectId=0;
			HttpSession session = request.getSession(false);
			if(session.getAttribute("scenarioId")!=null)
				scnarioId = Integer.parseInt((session.getAttribute("scenarioId").toString()));
					if(session.getAttribute("projectId")!=null)
						projectId =Integer.parseInt((session.getAttribute("projectId").toString()));
			try
			{


				rsFormatted = new GEAEResultSet();
				rsEngineCatalog = new GEAEResultSet();
				objeCRDDataBean = new eCRDDataBean();
				arrLstInParam = new ArrayList();

				arrLstInParam.add(Integer.toString(projectId));
				arrLstInParam.add(Integer.toString(scnarioId));

				strActionId = eCRDConstants.getActionId("eCRD_METRIO_DATA_LIST_EXT");
				//strActionId2 = eCRDConstants.getActionId("eCRD_METRIO_DATA_LIST_INT");
				//rsEngineCatalog = objeCRDBusinessBean.populateComponentList(strActionId, arrLstInParam);

				ArrayList arrLstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrLstInParam);
				rsEngineCatalog = (GEAEResultSet) arrLstOutParam.get(0);
				lastUpdatedDate = (String) arrLstOutParam.get(1);

				strReport = eCRDUtil.verifyNull(request.getParameter("hdnReport"));
				rsFormatted = formatMetrioDataResultSet(rsEngineCatalog,strReport);//new
				objeCRDDataBean.setCache(rsFormatted);
				eCRDUtil.loadInSession(request, "ecrdMetrioDataList", objeCRDDataBean);
			}
			finally
			{

				rsEngineCatalog = null;
				rsFormatted = null;
				objeCRDDataBean = null;
				strActionId = null;
				arrLstInParam = null;

			}

			session.setAttribute("selectedCustomer", "External");
			session.setAttribute("lastUpdatedDate", lastUpdatedDate);
		}
	 private GEAEResultSet formatWinRateDataResultSet(GEAEResultSet rsSearchResults,String strReport) throws Exception
		{

			GEAEResultSet rsFormattedRS = null;
			//String strEngine = "";
			ArrayList arrlstTemp = null;
			GEAETag geAETag = null;
			try
			{
				rsFormattedRS = new GEAEResultSet();
				rsSearchResults.setCurrentRow(0);
				while (rsSearchResults.next())
				{

					arrlstTemp = new ArrayList();

					/*strEngine =
						"<A href='javascript:fnSelectComponentCode(\""
							+ rsSearchResults.getString("Component_code")
							+ "\")'>"
							+ rsSearchResults.getString("Component_code")
							+ "</A>";*/

//					geAETag = new GEAETag(rsSearchResults.getString("Component_code"), strEngine);
//					arrlstTemp.add(geAETag);
					geAETag = new GEAETag((rsSearchResults.getString("COMPONENT_CODE")),(rsSearchResults.getString("COMPONENT_CODE")));
					arrlstTemp.add(geAETag);
					geAETag = new GEAETag((rsSearchResults.getString("COMPONENT_DESC")),(rsSearchResults.getString("COMPONENT_DESC")));
					arrlstTemp.add(geAETag);
					//geAETag = new GEAETag(Double.toString(rsSearchResults.getDouble("EXT_SLS_ANL")),Double.toString(rsSearchResults.getDouble("EXT_SLS_ANL")));
					geAETag = new GEAETag((Integer.toString((new Double(rsSearchResults.getDouble("EXT_SLS_ANL")).intValue()))),
							(Integer.toString((new Double(rsSearchResults.getDouble("EXT_SLS_ANL")).intValue()))));
					arrlstTemp.add(geAETag);
					//geAETag = new GEAETag(Double.toString(rsSearchResults.getDouble("CTLG_REV_SV")),Double.toString(rsSearchResults.getDouble("CTLG_REV_SV")));
					geAETag = new GEAETag((Integer.toString((new Double(rsSearchResults.getDouble("CTLG_REV_SV")).intValue()))),
							(Integer.toString((new Double(rsSearchResults.getDouble("CTLG_REV_SV")).intValue()))));
					arrlstTemp.add(geAETag);
					//geAETag = new GEAETag(Double.toString(rsSearchResults.getDouble("DISCOUNTED_REV_SV")),Double.toString(rsSearchResults.getDouble("DISCOUNTED_REV_SV")));
					geAETag = new GEAETag((Integer.toString((new Double(rsSearchResults.getDouble("DISCOUNTED_REV_SV")).intValue()))),
							(Integer.toString((new Double(rsSearchResults.getDouble("DISCOUNTED_REV_SV")).intValue()))));
					arrlstTemp.add(geAETag);

					//geAETag = new GEAETag(Double.toString(rsSearchResults.getDouble("DISCOUNTED_REV_PRT")),Double.toString(rsSearchResults.getDouble("DISCOUNTED_REV_PRT")));

					geAETag = new GEAETag((Integer.toString((new Double(rsSearchResults.getDouble("DISCOUNTED_REV_PRT")).intValue()))),
							(Integer.toString((new Double(rsSearchResults.getDouble("DISCOUNTED_REV_PRT")).intValue()))));

					arrlstTemp.add(geAETag);
					//geAETag = new GEAETag(Double.toString(rsSearchResults.getDouble("EXT_MKT")),Double.toString(rsSearchResults.getDouble("EXT_MKT")));
					geAETag = new GEAETag((Integer.toString((new Double(rsSearchResults.getDouble("EXT_MKT")).intValue()))),
							(Integer.toString((new Double(rsSearchResults.getDouble("EXT_MKT")).intValue()))));
					arrlstTemp.add(geAETag);
					geAETag = new GEAETag(Double.toString(rsSearchResults.getDouble("WIN_RT")),Double.toString(rsSearchResults.getDouble("WIN_RT")));
					arrlstTemp.add(geAETag);

					rsFormattedRS.addRow(arrlstTemp);
					arrlstTemp = null;
					geAETag = null;
				}
				rsFormattedRS.setColumnHeading(1, "Component Code");
				rsFormattedRS.setColumnHeading(2, "Component Description");
				rsFormattedRS.setColumnHeading(3, "EXTERNAL Sales Annualized");
				rsFormattedRS.setColumnHeading(4, "Catalog REV/SV");
				rsFormattedRS.setColumnHeading(5, "Discounted REV/SV");
				rsFormattedRS.setColumnHeading(6, "Discounted REV/PART");
				rsFormattedRS.setColumnHeading(7, "External Market");
				rsFormattedRS.setColumnHeading(8, "Win Rate");

				rsFormattedRS.sort(1, true);
				return rsFormattedRS;
			}
			finally
			{
				rsFormattedRS = null;
				//strEngine = null;
				arrlstTemp = null;
				geAETag = null;
			}

		}

	 private GEAEResultSet formatMetrioDataResultSet(GEAEResultSet rsSearchResults,String strReport) throws Exception
		{

			GEAEResultSet rsFormattedRS = null;
			//String strEngine = "";
			ArrayList arrlstTemp = null;
			GEAETag geAETag = null;
			try
			{
				rsFormattedRS = new GEAEResultSet();
				rsSearchResults.setCurrentRow(0);
				while (rsSearchResults.next())
				{

					arrlstTemp = new ArrayList();

					/*strEngine =
						"<A href='javascript:fnSelectComponentCode(\""
							+ rsSearchResults.getString("Component_code")
							+ "\")'>"
							+ rsSearchResults.getString("Component_code")
							+ "</A>";*/

//					geAETag = new GEAETag(rsSearchResults.getString("Component_code"), strEngine);
//					arrlstTemp.add(geAETag);
//					geAETag = new GEAETag(rsSearchResults.getString("ENG_MDL_NUMBER"),rsSearchResults.getString("ENG_MDL_NUMBER"));
//					arrlstTemp.add(geAETag);
					//(screen, excel)
					geAETag = new GEAETag(rsSearchResults.getString("COMPONENT_CODE"),rsSearchResults.getString("COMPONENT_CODE"));
					arrlstTemp.add(geAETag);
					geAETag = new GEAETag(rsSearchResults.getString("COMPONENT_DESC"),rsSearchResults.getString("COMPONENT_DESC"));
					arrlstTemp.add(geAETag);
					geAETag = new GEAETag(rsSearchResults.getString("CUST_NAME"),rsSearchResults.getString("CUST_NAME"));
					arrlstTemp.add(geAETag);

					geAETag = new GEAETag(Double.toString(rsSearchResults.getDouble("INVOICE_REVENUE")),Double.toString(rsSearchResults.getDouble("INVOICE_REVENUE")));
					arrlstTemp.add(geAETag);
					geAETag = new GEAETag(Double.toString(rsSearchResults.getDouble("MDL_ESC_PCT")),Double.toString(rsSearchResults.getDouble("MDL_ESC_PCT")));
					arrlstTemp.add(geAETag);
					geAETag = new GEAETag(Double.toString(rsSearchResults.getDouble("ESC_CAP_PCT")),Double.toString(rsSearchResults.getDouble("ESC_CAP_PCT")));
					arrlstTemp.add(geAETag);
					geAETag = new GEAETag(rsSearchResults.getString("CAP_ENFORCED_IND"),rsSearchResults.getString("CAP_ENFORCED_IND"));
					arrlstTemp.add(geAETag);

					//geAETag = new GEAETag(Double.toString(rsSearchResults.getDouble("NT_EXT_PR_ANL")),Double.toString(rsSearchResults.getDouble("GRS_EXT_ESC_GROWTH_ANL")));
					geAETag = new GEAETag((Integer.toString((new Double(rsSearchResults.getDouble("NT_EXT_PR_ANL")).intValue()))),
							(Integer.toString((new Double(rsSearchResults.getDouble("NT_EXT_PR_ANL")).intValue()))));
					arrlstTemp.add(geAETag);
					geAETag = new GEAETag((Integer.toString((new Double(rsSearchResults.getDouble("GRS_EXT_ESC_GROWTH_ANL")).intValue()))),
							(Integer.toString((new Double(rsSearchResults.getDouble("GRS_EXT_ESC_GROWTH_ANL")).intValue()))));


				//	geAETag = new GEAETag(Double.toString(rsSearchResults.getDouble("GRS_EXT_ESC_GROWTH_ANL")),Double.toString(rsSearchResults.getDouble("GRS_EXT_ESC_GROWTH_ANL")));
					arrlstTemp.add(geAETag);

//					geAETag = new GEAETag(Double.toString(rsSearchResults.getDouble("cat_shop_visit")),Double.toString(rsSearchResults.getDouble("cat_shop_visit")));
//					arrlstTemp.add(geAETag);
//					geAETag = new GEAETag(Double.toString(rsSearchResults.getDouble("discnt_shop_visit")),Double.toString(rsSearchResults.getDouble("discnt_shop_visit")));
//					arrlstTemp.add(geAETag);
//					geAETag = new GEAETag(Double.toString(rsSearchResults.getDouble("discnt_part")),Double.toString(rsSearchResults.getDouble("discnt_part")));
//					arrlstTemp.add(geAETag);
//					geAETag = new GEAETag(Double.toString(rsSearchResults.getDouble("win_rate")),Double.toString(rsSearchResults.getDouble("win_rate")));
//					arrlstTemp.add(geAETag);

					rsFormattedRS.addRow(arrlstTemp);
					arrlstTemp = null;
					geAETag = null;
				}
			//	rsFormattedRS.setColumnHeading(1, "Engine Model"); // need to map with db
				rsFormattedRS.setColumnHeading(1, "Component Code");
				rsFormattedRS.setColumnHeading(2, "Component Description");
				rsFormattedRS.setColumnHeading(3, "Parent Customer(Bill To)");
				rsFormattedRS.setColumnHeading(4, "Invoice Revenue");
				rsFormattedRS.setColumnHeading(5, "Model Escalatio Percent");
				rsFormattedRS.setColumnHeading(6, "Escalatio Cap Percent");
				rsFormattedRS.setColumnHeading(7, "Cap Enforced");
				rsFormattedRS.setColumnHeading(8, "Net Ext Price Annual");
				rsFormattedRS.setColumnHeading(9, "Gross Ext Escalation Growth Annual");

				//rsFormattedRS.setColumnHeading(7, "Rebate %");// need to map with db
				//rsFormattedRS.setColumnHeading(8, "Esc Cap %");// need to map with db

				rsFormattedRS.sort(1, true);
				return rsFormattedRS;
			}
			finally
			{
				rsFormattedRS = null;
				//strEngine = null;
				arrlstTemp = null;
				geAETag = null;
			}

		}

	 //added by meenakshi ends here


	 private GEAEResultSet formatCustomerEscResultSet(GEAEResultSet rsSearchResults,String strReport) throws Exception
		{

			GEAEResultSet rsFormattedRS = null;
			String strEngine = "";
			ArrayList arrlstTemp = null;
			GEAETag geAETag = null;
			try
			{
				rsFormattedRS = new GEAEResultSet();
				rsSearchResults.setCurrentRow(0);
				while (rsSearchResults.next())
				{

					arrlstTemp = new ArrayList();
					/*if("".equals(strReport))
					{
						strEngine =
						"<A href='javascript:fnSelectEngineModel(\""
							+ rsSearchResults.getString("cat_seq_id")
							+ "\",\""
							+ rsSearchResults.getString("cat_type")
							+ "\")'>"
							+ rsSearchResults.getString("Engine_Model")
							+ "</A>";
					}
					else if("ADDMODIFYCSC".equals(strReport))
					{
						strEngine =
						"<A href='javascript:fnSelectEngineModelCSC(\""
							+ rsSearchResults.getString("cat_seq_id")
							+ "\",\""
							+ rsSearchResults.getString("cat_type")
							+ "\")'>"
							+ rsSearchResults.getString("Engine_Model")
							+ "</A>";
					}
					else
					{
						strEngine =
						"<A href='javascript:fnSelectEngineModelForReport(\""
							+ rsSearchResults.getString("cat_seq_id")
							+ "\",\""
							+ rsSearchResults.getString("cat_type")
							+ "\")'>"
							+ rsSearchResults.getString("Engine_Model")
							+ "</A>";

					}*/
					//geAETag = new GEAETag(rsSearchResults.getString("Engine_Model"), strEngine);
					//arrlstTemp.add(geAETag);

					geAETag = new GEAETag( rsSearchResults.getString("engine_model"),rsSearchResults.getString("engine_model"));
					arrlstTemp.add(geAETag);
					geAETag = new GEAETag( rsSearchResults.getString("customer_name"),rsSearchResults.getString("customer_name"));
					arrlstTemp.add(geAETag);
					geAETag = new GEAETag(Double.toString(rsSearchResults.getDouble("esc_cap")),Double.toString(rsSearchResults.getDouble("esc_cap")));
					arrlstTemp.add(geAETag);





					/*geAETag = new GEAETag(rsSearchResults.getString("Sortable_End_Date"), rsSearchResults.getString("End_Date"));
					arrlstTemp.add(geAETag);
					arrlstTemp.add(rsSearchResults.getString("Description"));*/
					rsFormattedRS.addRow(arrlstTemp);
					arrlstTemp = null;
					geAETag = null;
				}
				rsFormattedRS.setColumnHeading(1, "Engine Model");
				rsFormattedRS.setColumnHeading(2, "Customer Name");
				rsFormattedRS.setColumnHeading(3, "Escalation Cap");


		/*		rsFormattedRS.setColumnHeading(2, "Start Date");
				rsFormattedRS.setColumnHeading(3, "End  Date");
				rsFormattedRS.setColumnHeading(4, "Description");*/
				rsFormattedRS.sort(1, true);
				return rsFormattedRS;
			}
			finally
			{
				rsFormattedRS = null;
				strEngine = null;
				arrlstTemp = null;
				geAETag = null;
			}

		}

	 private GEAEResultSet formatPricingComponentResultSet(GEAEResultSet rsSearchResults,String strReport) throws Exception
		{

			GEAEResultSet rsFormattedRS = null;
			String strEngine = "";
			ArrayList arrlstTemp = null;
			GEAETag geAETag = null;
			try
			{
				rsFormattedRS = new GEAEResultSet();
				rsSearchResults.setCurrentRow(0);
				while (rsSearchResults.next())
				{

					arrlstTemp = new ArrayList();
					/*if("".equals(strReport))
					{
						strEngine =
						"<A href='javascript:fnSelectEngineModel(\""
							+ rsSearchResults.getString("cat_seq_id")
							+ "\",\""
							+ rsSearchResults.getString("cat_type")
							+ "\")'>"
							+ rsSearchResults.getString("Engine_Model")
							+ "</A>";
					}
					else if("ADDMODIFYCSC".equals(strReport))
					{
						strEngine =
						"<A href='javascript:fnSelectEngineModelCSC(\""
							+ rsSearchResults.getString("cat_seq_id")
							+ "\",\""
							+ rsSearchResults.getString("cat_type")
							+ "\")'>"
							+ rsSearchResults.getString("Engine_Model")
							+ "</A>";
					}
					else
					{
						strEngine =
						"<A href='javascript:fnSelectEngineModelForReport(\""
							+ rsSearchResults.getString("cat_seq_id")
							+ "\",\""
							+ rsSearchResults.getString("cat_type")
							+ "\")'>"
							+ rsSearchResults.getString("Engine_Model")
							+ "</A>";

					}*/
					//geAETag = new GEAETag(rsSearchResults.getString("Engine_Model"), strEngine);
					//arrlstTemp.add(geAETag);
					strEngine =
						"<A href='javascript:fnSelectComponentCode(\""
							+ rsSearchResults.getString("Component_code") +"\",\""
							+ rsSearchResults.getString("component_desc")
							+ "\")'>"
							+ rsSearchResults.getString("Component_code")
							+ "</A>";

					geAETag = new GEAETag(rsSearchResults.getString("Component_code"), strEngine);
					arrlstTemp.add(geAETag);
					geAETag = new GEAETag( rsSearchResults.getString("component_desc"),rsSearchResults.getString("component_desc"));
					arrlstTemp.add(geAETag);

					geAETag = new GEAETag(rsSearchResults.getString("tech_level"),rsSearchResults.getString("tech_level"));
					arrlstTemp.add(geAETag);
					geAETag = new GEAETag(Double.toString(rsSearchResults.getDouble("default_esc")),Double.toString(rsSearchResults.getDouble("default_esc")));
					arrlstTemp.add(geAETag);
					geAETag = new GEAETag(Double.toString(rsSearchResults.getDouble("external_volume")),Double.toString(rsSearchResults.getDouble("external_volume")));
					arrlstTemp.add(geAETag);





					/*geAETag = new GEAETag(rsSearchResults.getString("Sortable_End_Date"), rsSearchResults.getString("End_Date"));
					arrlstTemp.add(geAETag);
					arrlstTemp.add(rsSearchResults.getString("Description"));*/
					rsFormattedRS.addRow(arrlstTemp);
					arrlstTemp = null;
					geAETag = null;
				}
				rsFormattedRS.setColumnHeading(1, "Component Code");
				rsFormattedRS.setColumnHeading(2, "Component Description");
				rsFormattedRS.setColumnHeading(3, "Tech Level");
				rsFormattedRS.setColumnHeading(4, "Default Escalation");
				rsFormattedRS.setColumnHeading(5, "External Volume");

		/*		rsFormattedRS.setColumnHeading(2, "Start Date");
				rsFormattedRS.setColumnHeading(3, "End  Date");
				rsFormattedRS.setColumnHeading(4, "Description");*/
				rsFormattedRS.sort(1, true);
				return rsFormattedRS;
			}
			finally
			{
				rsFormattedRS = null;
				strEngine = null;
				arrlstTemp = null;
				geAETag = null;
			}

		}

	 /**
	  *
	  * @param rsSearchResults
	  * @param strReport
	  * @return
	  * @throws Exception
	  */
	 private GEAEResultSet formatPricingRepairResultSet(GEAEResultSet rsSearchResults,String strReport) throws Exception
		{

			GEAEResultSet rsFormattedRS = null;
			String strEngine = "";
			String repairType = "";
			final String quoteDisplayVal = "";
			ArrayList arrlstTemp = null;
			GEAETag geAETag = null;
			try
			{
				rsFormattedRS = new GEAEResultSet();
				rsSearchResults.setCurrentRow(0);
				while (rsSearchResults.next())
				{

					arrlstTemp = new ArrayList();

					strEngine =
						"<A href='javascript:fnSelectComponentCode(\""
							+ rsSearchResults.getInt("rpr_seq_id")
							+ "\")'>"
							+ rsSearchResults.getInt("rpr_seq_id")
							+ "</A>";
					geAETag = new GEAETag(Integer.toString(rsSearchResults.getInt("rpr_seq_id")), strEngine);
					arrlstTemp.add(geAETag);

					geAETag = new GEAETag( rsSearchResults.getString("dis_seq_id"),rsSearchResults.getString("dis_seq_id"));
					arrlstTemp.add(geAETag);
					geAETag = new GEAETag( rsSearchResults.getString("component_code"),rsSearchResults.getString("component_code"));
					arrlstTemp.add(geAETag);
					geAETag = new GEAETag(rsSearchResults.getString("rpr_desc"),rsSearchResults.getString("rpr_desc"));
					arrlstTemp.add(geAETag);

					repairType = rsSearchResults.getString("REPAIR_TYPE");
					if(repairType != null && "quote".equalsIgnoreCase(repairType)) {
						geAETag = new GEAETag(quoteDisplayVal, quoteDisplayVal);
						arrlstTemp.add(geAETag);
						geAETag = new GEAETag(quoteDisplayVal, quoteDisplayVal);
						arrlstTemp.add(geAETag);
					} else {
						geAETag = new GEAETag((Integer.toString((new Double(rsSearchResults.getDouble("rpr_price")).intValue()))),
								(Integer.toString((new Double(rsSearchResults.getDouble("rpr_price")).intValue()))));

						arrlstTemp.add(geAETag);

						geAETag = new GEAETag((Integer.toString((new Double(rsSearchResults.getDouble("NEW_REPAIR_PRICE")).intValue()))),
								(Integer.toString((new Double(rsSearchResults.getDouble("NEW_REPAIR_PRICE")).intValue()))));
						///geAETag = new GEAETag(Double.toString(rsSearchResults.getDouble("NEW_REPAIR_PRICE")),Double.toString(rsSearchResults.getDouble("NEW_REPAIR_PRICE")));
						arrlstTemp.add(geAETag);


					}
					geAETag = new GEAETag(Double.toString(rsSearchResults.getDouble("default_esc")),Double.toString(rsSearchResults.getDouble("default_esc")));
					arrlstTemp.add(geAETag);
					geAETag = new GEAETag(Integer.toString(rsSearchResults.getInt("rpr_tat")), Integer.toString(rsSearchResults.getInt("rpr_tat")));
					arrlstTemp.add(geAETag);
				//	geAETag = new GEAETag(Double.toString(rsSearchResults.getDouble("manual_esc")),Double.toString(rsSearchResults.getDouble("manual_esc")));
					geAETag = new GEAETag((Integer.toString((new Double(rsSearchResults.getDouble("manual_esc")).intValue()))),
							(Integer.toString((new Double(rsSearchResults.getDouble("manual_esc")).intValue()))));
					arrlstTemp.add(geAETag);


					rsFormattedRS.addRow(arrlstTemp);
					arrlstTemp = null;
					geAETag = null;
				}

				rsFormattedRS.setColumnHeading(1, "Repair Code");
				rsFormattedRS.setColumnHeading(2, "Display Code");
				rsFormattedRS.setColumnHeading(3, "Component Code");
				rsFormattedRS.setColumnHeading(4, "Repair Description");
				rsFormattedRS.setColumnHeading(5, "Repair Price");
				rsFormattedRS.setColumnHeading(6, "New Repair Price");
				rsFormattedRS.setColumnHeading(7, "Default Escalation");
				rsFormattedRS.setColumnHeading(8, "Repair TAT");
				rsFormattedRS.setColumnHeading(9, "Manual Override Price");


				rsFormattedRS.sort(1, true);
				return rsFormattedRS;
			}
			finally
			{
				rsFormattedRS = null;
				strEngine = null;
				repairType = null;
				arrlstTemp = null;
				geAETag = null;
			}

		}

}
