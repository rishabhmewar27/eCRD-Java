//Source file: D:\\ECRD\\SOURCE CODE\\ecrd\\helper\\eCRDManageUserHelper.java
/**
 * Module       : eCRDManageUserHelper.java
 * Author       : Patni Offshore
 * Project      : eCRD
 * Date Written : October 2004
 * Security     : Classified/Unclassified
 * Restrictions : GE PROPRIETORY INFORMATION, FOR GE USE ONLY
 *
 *     ***************************************************************
 *     *          Copyright (2000) with all rights reserved          *
 *     *                  General Electric Company                   *
 *     ***************************************************************
 * Description  :  This class has methods to get the Master Tables Data.
 * Revision Log  (mm/dd/yyyy     Initials    description)
 * -------------------------------------------------------------------
 * mm/dd/yyyy     Initials     Description
 * -------------------------------------------------------------------
 *   31/05/2006 Patni Phase 1 Requirement Updations  
 */
package ecrd.helper;
import java.util.ArrayList;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;

import ecrd.biz.eCRDSite;
import ecrd.biz.eCRDUser;
import ecrd.common.eCRDBusinessBean;
import ecrd.common.eCRDCommand;
import ecrd.common.eCRDDBMediator;
import ecrd.common.eCRDDataBean;
import ecrd.exception.eCRDException;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDSearchBean;
import ecrd.util.eCRDUtil;
import geae.dao.GEAEResultSet;
import geae.ldap.GEAELdapBeanFactory;
import geae.ldap.GEAELdapObject;
import geae.ldap.GEAELdapSL;
import geae.ldap.GEAELdapSearchOperation;
import geae.security.GEAEPrincipal;
import geae.util.format.GEAETag;
import geae.util.format.GEAETagNoData;
public class eCRDManageUserHelper implements eCRDCommand
{
	private HttpServletRequest request = null;
	public eCRDManageUserHelper()
	{
	}
	/**
	 * Based "action" attribute from the request, this function calls the appropriate 
	 * private functions in this class.
	 * Also sets the received request to member variable.
	 * @param request
	 */
	public String perform(HttpServletRequest request) throws Exception
	{
		String strReturnURL = "";
		String strScreenAction = "";
		try
		{
			this.request = request;
			strScreenAction = eCRDUtil.verifyNull(request.getParameter("hdnScreenAction"));
            
			if ("".equalsIgnoreCase(strScreenAction))
			{
				eCRDUtil.clearSession(request);
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-listUsers";
			}
			else if ((eCRDConstants.getActionId("eCRD_ADD_USER")).equalsIgnoreCase(strScreenAction))
			{
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-createUser";
			}
			else if ((eCRDConstants.getActionId("eCRD_SEARCH_USER")).equalsIgnoreCase(strScreenAction))
			{
				loadUser(eCRDConstants.getActionId("eCRD_SEARCH_USER"));
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-listUsers";
			}
			else if ((eCRDConstants.getActionId("eCRD_CREATE_USER")).equalsIgnoreCase(strScreenAction))
			{
				createUser();
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-modifyUser";
			}
			else if ((eCRDConstants.getActionId("eCRD_LDAP_SEARCH")).equalsIgnoreCase(strScreenAction))
			{
				getLdapRowCacheDetails();
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-ldapSearchUser";
			}
			else if ((eCRDConstants.getActionId("eCRD_MODIFY_USER")).equalsIgnoreCase(strScreenAction))
			{
                // added by sushant MCR 9292#11. Check before deactivating a user
                loadPendingApprovals(request, eCRDConstants.getActionId("eCRD_PENDING_REQUEST"));
                // added by sushant MCR 9292#11. Check before deactivating a user
                strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-modifyUser";
			}
			else if ((eCRDConstants.getActionId("eCRD_UPDATE_USER")).equalsIgnoreCase(strScreenAction))
			{
			    modifyUser();
                // added by sushant MCR 9292#11. Check before deactivating a user
                loadPendingApprovals(request, eCRDConstants.getActionId("eCRD_PENDING_REQUEST"));
                // added by sushant MCR 9292#11. Check before deactivating a user
			    strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-modifyUser";
			}
			else if ((eCRDConstants.getActionId("eCRD_USER_DETAILS")).equalsIgnoreCase(strScreenAction))
			{
				strReturnURL = getLdapSubmitDetails();
                // added by sushant MCR 9292#11. Check before deactivating a user
                loadPendingApprovals(request, eCRDConstants.getActionId("eCRD_PENDING_REQUEST"));
                // added by sushant MCR 9292#11. Check before deactivating a user
			}
			else if ((eCRDConstants.getActionId("eCRD_EMAIL_GROUP")).equals(strScreenAction))
			{
				eCRDUtil.clearSession(request);
				getEmailGroups();
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-emailGrpMaint";
			}
			else if ((eCRDConstants.getActionId("eCRD_CREATE_EMAIL_GROUP")).equals(strScreenAction))
			{
				String strMsg = null;
				strMsg = createGroups();
				if ("GROUP_ALREADY_EXISTS".equals(strMsg))
				{
					strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-emailGrpMaint";
				}
				else
				{
					strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-createEmailGrp";
				}

			}
			else if ((eCRDConstants.getActionId("eCRD_SEARCH_USER_FOR_GROUP")).equals(strScreenAction))
			{
				searchGroupUser();
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-searchEmailAddress";
			}
			else if ((eCRDConstants.getActionId("eCRD_ADD_EMAIL_IN_GROUP")).equals(strScreenAction))
			{
				addEmailToGroup();
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-createEmailGrp";
			}
			else if ((eCRDConstants.getActionId("eCRD_DELETE_EMAIL_FROM_GROUP")).equals(strScreenAction))
			{
				deleteEmailFromGroup();
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-createEmailGrp";
			}
			else if ((eCRDConstants.getActionId("eCRD_ADD_EMAIL_IN_GRP")).equals(strScreenAction))
			{
				listEmailForGroup();
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-createEmailGrp";
			}
			else if ((eCRDConstants.getActionId("eCRD_ASSOCIATE_EVENT")).equals(strScreenAction))
			{

				associateEvent();
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-associateEvent";
			}
			else if ((eCRDConstants.getActionId("eCRD_ATTACH_EVENT_TO_GROUP")).equals(strScreenAction))
			{

				attachEventToGroup(request);
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-associateEvent";
			}
			else if ((eCRDConstants.getActionId("eCRD_DELETE_GROUP")).equals(strScreenAction))
			{

				deleteGroup(request);
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-emailGrpMaint";
			}
			return strReturnURL;
		}
		finally
		{
			strReturnURL = null;
			strScreenAction = null;
		}
	} 
    
    /**
     * Description : this method is used to hit the data base to collect the pending user requsets for a 
     *               perticular user.
     * @param request
     * @param strAction
     * @throws Exception
     */
    // added by sushant for MCR 9292#11. Check before deactivating a user
    private void loadPendingApprovals(HttpServletRequest request, String strAction) throws Exception
    {
        String userId = request.getParameter("hdnUserId");
        ArrayList arrlstInpParam = new ArrayList();
        arrlstInpParam.add(userId);
        ArrayList arrlstOutParam = new ArrayList();

        try
        {
            arrlstOutParam = eCRDDBMediator.doDBOperation(strAction, arrlstInpParam);
        }
        finally
        {
            arrlstInpParam = null;
        }
        request.setAttribute("pendingComponentCount", arrlstOutParam.get(0));
        request.setAttribute("pendingComponentSiteCount", arrlstOutParam.get(1));
        request.setAttribute("pendingRepairCount", arrlstOutParam.get(2));
    }
    // end MCR 9292#11. Check before deactivating a user.

    /**
	 * 
		 * Method name:   createUser
		 * @author    :  Patni Computer Systems--Offshore Team
		 * @version   :  1.0
		 * @param     :  None
		 * @return    :  String
		 * @since     :  JDK1.0
		 * request: action=create
	  * For executing steps in creation of user
	  * Returns strMesg
	  */
	private void createUser() throws Exception
	{
		eCRDUser objeCRDUser = null;
		eCRDUser objeCRDNewUser = null;
		eCRDSite objeCRDSite = null;
		String strMesg = "";
		String strRole = "";
		String strUserId = "";
		try
		{
			objeCRDUser = new eCRDUser();
			objeCRDSite = new eCRDSite();
			objeCRDNewUser = new eCRDUser();
			objeCRDSite.setSiteCode(eCRDUtil.verifyNull(request.getParameter("selSite")));
			objeCRDUser.setFirstName(eCRDUtil.verifyNull(request.getParameter("txtFName")));
			objeCRDUser.setLastName(eCRDUtil.verifyNull(request.getParameter("txtLName")));
			objeCRDUser.setUserId(eCRDUtil.verifyNull(request.getParameter("txtUserId")));
			objeCRDUser.setEMailId(eCRDUtil.verifyNull(request.getParameter("txtEmailId")));
			objeCRDUser.setStatus(eCRDUtil.verifyNull(request.getParameter("selActive")));
			objeCRDUser.setRole(eCRDUtil.verifyNull(request.getParameter("selRole")));
			objeCRDUser.setDualRoleIndValue(eCRDUtil.verifyNull(request.getParameter("selDualRoleIndicator")));
			objeCRDUser.setSite(objeCRDSite);
			objeCRDNewUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser");
			strUserId = objeCRDNewUser.getUserId();
			strRole = objeCRDNewUser.getRole();
			strMesg = objeCRDUser.create(strUserId, strRole);
			request.setAttribute("strMesg", strMesg);
		}
		finally
		{
			objeCRDNewUser = null;
			objeCRDUser = null;
			objeCRDSite = null;
			strMesg = null;
		}
	} //end of the method createUser()
	/**
	 * request: action=delete
	 * For executing steps in deletion of a user.
	 */
	private void deleteUser()
	{
	}
	/*
		 * Method name:   modifyUser
		 * @author    :  Patni Computer Systems--Offshore Team
		 * @version   :  1.0
		 * @param     :  None
		 * @return    :  String
		 * @since     :  JDK1.0
		 */
	private void modifyUser() throws Exception
	{
		eCRDUser objeCRDUser = null;
		eCRDUser objeCRDNewUser = null;
		eCRDSite objeCRDSite = null;
		String strMesg = "";
		String strRole = "";
		String strUserId = "";
		String strHdnUserId = "";
		String strRoleCode = "";
		GEAEResultSet rsSearchList = null;
		try
		{
            objeCRDUser = new eCRDUser();
			objeCRDNewUser = new eCRDUser();
			objeCRDSite = new eCRDSite();
			rsSearchList = new GEAEResultSet();
			objeCRDSite.setSiteCode(eCRDUtil.verifyNull(request.getParameter("selSite")));
			objeCRDUser.setFirstName(eCRDUtil.verifyNull(request.getParameter("txtFName")));
			objeCRDUser.setLastName(eCRDUtil.verifyNull(request.getParameter("txtLName")));
			objeCRDUser.setUserId(eCRDUtil.verifyNull(request.getParameter("txtUserId")));
			objeCRDUser.setEMailId(eCRDUtil.verifyNull(request.getParameter("txtEmailId")));
			objeCRDUser.setStatus(eCRDUtil.verifyNull(request.getParameter("selActive")));
			objeCRDUser.setRole(eCRDUtil.verifyNull(request.getParameter("selRole")));
			objeCRDUser.setDualRoleIndValue(eCRDUtil.verifyNull(request.getParameter("selDualRoleIndicator")));
			objeCRDUser.setSite(objeCRDSite);
			objeCRDNewUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser");
			strUserId = objeCRDNewUser.getUserId();
			strRole = objeCRDNewUser.getRole();
			strHdnUserId = eCRDUtil.verifyNull(request.getParameter("txtUserId"));
            rsSearchList = searchUserDetails(strHdnUserId);
			rsSearchList.setCurrentRow(0);
			rsSearchList.next();
			strRoleCode = rsSearchList.getString(2);
			if (eCRDConstants.ROLE_TECH_COORD.equals(strRole) && eCRDConstants.ROLE_ADMINISTRATOR.equals(strRoleCode))
			{
			}
			else
			{
                strMesg = objeCRDUser.update(strUserId, strRole);
			}
			if ("".equals(strMesg))
			{
				strMesg = "USER_PRIVILAGE";
			}
			request.setAttribute("strMesg", strMesg);
        }
		finally
		{
			objeCRDUser = null;
			objeCRDNewUser = null;
			objeCRDSite = null;
			strMesg = null;
			strHdnUserId = null;
			rsSearchList = null;
			strRoleCode = null;
		}
	}
	/*
	 * Method name:   loadUser
	 * Brief logic:	 Taking action load user and list the user  
	 * @author    :  Patni Computer Systems--Offshore Team
	 * @version   :  1.0
	 * @param     :  GEAEResultSet
	 * @return    :  GEAEResultSet
	 * @since     :  JDK1.0
	 */
	private void loadUser(String strAction) throws Exception
	{
		ArrayList arrLstInParam = null;
		eCRDDataBean objeCRDDataBean = null;
		eCRDBusinessBean objeCRDBusinessBean = null;
		eCRDUser objeCRDNewUser = null;
		String strFName = "";
		String strLName = "";
		String strRole = "";
		String strSite = "";
		String strDualRoleIndValue = "";
		String strLoginRole = "";
		GEAEResultSet rsFormatted = null;
		GEAEResultSet geaersetUserList = null;
		String strUserId = "";
		String strSiteCode = "";
		eCRDSite objeCRDSite = null;
		try
		{
			arrLstInParam = new ArrayList();
			strFName = eCRDUtil.verifyNull(request.getParameter("txtFirstName"));
			strLName = eCRDUtil.verifyNull(request.getParameter("txtLastName"));
			strRole = eCRDUtil.verifyNull(request.getParameter("txtRole"));
			strSite = eCRDUtil.verifyNull(request.getParameter("txtSite"));
			strDualRoleIndValue = eCRDUtil.verifyNull(request.getParameter("txtDualRoleIndicator"));
			objeCRDBusinessBean = new eCRDBusinessBean();
			objeCRDDataBean = new eCRDDataBean();
			objeCRDNewUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser");
			strUserId = objeCRDNewUser.getUserId();
			strLoginRole = objeCRDNewUser.getRole();
			objeCRDSite = objeCRDNewUser.getSite();
			strSiteCode = objeCRDSite.getSiteCode();
			arrLstInParam.add(strFName);
			arrLstInParam.add(strLName);
			arrLstInParam.add(strRole);
			arrLstInParam.add(strSite);
			arrLstInParam.add(strUserId);
			arrLstInParam.add(strLoginRole);
			arrLstInParam.add(strSiteCode);
			arrLstInParam.add(strDualRoleIndValue);
			geaersetUserList = objeCRDBusinessBean.populateUserList(strAction, arrLstInParam);
			rsFormatted = formatResultSet(geaersetUserList);
			objeCRDDataBean.setCache(rsFormatted);
			eCRDUtil.loadInSession(request, "objeCRDUserListing", objeCRDDataBean);
		}
		finally
		{
			arrLstInParam = null;
			objeCRDDataBean = null;
			objeCRDBusinessBean = null;
			strFName = null;
			strLName = null;
			strRole = null;
			strSite = null;
			rsFormatted = null;
			geaersetUserList = null;
		}
	}
	/*
	* Method name:   formatResultSet
	* Brief logic:	 Taking resultset and format it into required format
	* @author    :  Patni Computer Systems--Offshore Team
	* @version   :  1.0
	* @param     :  GEAEResultSet
	* @return    :  GEAEResultSet
	* @since     :  JDK1.0
	*/
	private GEAEResultSet formatResultSet(GEAEResultSet rsSearchResults) throws Exception
	{
		GEAEResultSet rsFormattedRS = null;
		eCRDUser objeCRDNewUser = null;
		String strLoginRole = "";
		String strUser = "";
		String strFirstName = "";
		String strLastName = "";
		String strRole = "";
		String strSites = "";
		String strActive = "";
		String strDualRoleIndValue = "";
		ArrayList arrlstInRow = null;
		GEAETag geAETag = null;
		try
		{
			rsFormattedRS = new GEAEResultSet();
			rsSearchResults.setCurrentRow(0);
//        19-05-2006 patni checking null value Begin 
            if (rsSearchResults!=null)
            {
//              19-05-2006 patni checking null value End                
            while (rsSearchResults.next())
			{
				arrlstInRow = new ArrayList();
				strUser =
					"<A href=\"javascript:fnModifyUser('"
						+ rsSearchResults.getString(1)
						+ "\',\'"
						+ rsSearchResults.getString(2)
						+ "\',\'"
						+ rsSearchResults.getString(3)
						+ "\',\'"
						+ rsSearchResults.getString(4)
						+ "\',\'"
						+ rsSearchResults.getString(5)
						+ "\',\'"
						+ rsSearchResults.getString(6)
						+ "\',\'"
						+ rsSearchResults.getString(7)
						+ "\',\'"
						+ rsSearchResults.getString(8)
						+ "\',\'"
						+ rsSearchResults.getString(4)
						+ "\',\'"
						+ rsSearchResults.getString(9)
						+ "')\">"
						+ rsSearchResults.getString(1)
						+ "</A>";
				geAETag = new GEAETag(rsSearchResults.getString(1), strUser);

				objeCRDNewUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser");
				strLoginRole = objeCRDNewUser.getRole();

				if (eCRDConstants.ROLE_CSM.equals(strLoginRole)&& "N".equalsIgnoreCase(rsSearchResults.getString(9))) {
					arrlstInRow.add(rsSearchResults.getString(1));
				} else {
					arrlstInRow.add(geAETag);					
				}
				strFirstName = rsSearchResults.getString(2);
				arrlstInRow.add(strFirstName);
				strLastName = rsSearchResults.getString(3);
				arrlstInRow.add(strLastName);
				strRole = rsSearchResults.getString(4);
				arrlstInRow.add(strRole);
				strSites = rsSearchResults.getString(5);
				arrlstInRow.add(strSites);
				strActive = rsSearchResults.getString(6);
				arrlstInRow.add(strActive);
				strDualRoleIndValue = rsSearchResults.getString(9);
				arrlstInRow.add(strDualRoleIndValue);
				rsFormattedRS.addRow(arrlstInRow);
				arrlstInRow = null;
			}
//          19-05-2006 patni checking null value Begin 
            } // end if
//          19-05-2006 patni checking null value End            
			rsFormattedRS.setColumnHeading(1, "User Id");
			rsFormattedRS.setColumnHeading(2, "First Name");
			rsFormattedRS.setColumnHeading(3, "Last Name");
			rsFormattedRS.setColumnHeading(4, "Role");
			rsFormattedRS.setColumnHeading(5, "Sites");
			rsFormattedRS.setColumnHeading(6, "Status");
			rsFormattedRS.setColumnHeading(7, "Dual Role Indicator");
			return rsFormattedRS;
		}
		finally
		{
			rsFormattedRS = null;
			strUser = null;
			strFirstName = null;
			strLastName = null;
			strRole = null;
			strSites = null;
			strActive = null;
			arrlstInRow = null;
			geAETag = null;
		}
	}
	/*
		* Method name:  getUserInfoFromLDAP
		* Brief logic:	Taking search value and find the user information
		* @author    :  Patni Computer Systems--Offshore Team
		* @version   :  1.0
		* @param     :  GEAEPrincipal,String,HttpServletRequest
		* @return    :  GEAEResultSet
		* @since     :  JDK1.0
		*/
	private GEAEResultSet getUserInfoFromLDAP(GEAEPrincipal objGEAEPrincipal, String strSearchValue) throws Exception
	{
		Vector vecLdapList = new Vector();
		GEAELdapObject objUsers = null;
		String[] arrUserId = null;
		String[] arrFirstName = null;
		String[] arrLastName = null;
		String[] arrMailId = null;
		String strLDAPUserId = "";
		String strLDAPFirstName = "";
		String strLDAPLastName = "";
		String strLDAPMailId = "";
		ArrayList arrLstRow = null;
		GEAEResultSet geaeUserResultSet = null;
		String[] strArrAttributeLst = null;
		StringBuffer strBuffQry = null;
		GEAELdapSearchOperation objLDAPSearchOp = null;
		try
		{
			objLDAPSearchOp = new GEAELdapSearchOperation();
			strArrAttributeLst = new String[] { "uid", "givenname", "sn", "mail" };
			strBuffQry = new StringBuffer();

			if (!"".equals(strSearchValue))
			{
				strBuffQry.append("(uid=" + strSearchValue + ")");
			}
			objLDAPSearchOp.setAttributes(strArrAttributeLst);
			objLDAPSearchOp.setQuery(strBuffQry.toString());
			GEAELdapSL ldapBean = GEAELdapBeanFactory.getLdapBean(objGEAEPrincipal);
			objLDAPSearchOp = (GEAELdapSearchOperation) ldapBean.doOperation(objLDAPSearchOp);
			vecLdapList = objLDAPSearchOp.getResultSet();
			geaeUserResultSet = new GEAEResultSet();
			if (vecLdapList != null && !vecLdapList.isEmpty())
			{
				for (int intCtr = 0; intCtr < vecLdapList.size(); intCtr++)
				{
					objUsers = (GEAELdapObject) vecLdapList.elementAt(intCtr);
					arrLstRow = new ArrayList();
					if (objUsers != null)
					{
						arrUserId = objUsers.getValues("uid");
						arrFirstName = objUsers.getValues("givenname");
						arrLastName = objUsers.getValues("sn");
						arrMailId = objUsers.getValues("mail");
					}
					if (arrUserId != null && arrUserId.length > 0)
					{
						strLDAPUserId = arrUserId[0];
					}
					if (arrFirstName != null && arrFirstName.length > 0)
					{
						strLDAPFirstName = eCRDUtil.verifyNull(arrFirstName[0]);
					}
					if (arrLastName != null && arrLastName.length > 0)
					{
						strLDAPLastName = eCRDUtil.verifyNull(arrLastName[0]);
					}
					if (arrMailId != null && arrMailId.length > 0)
					{
						strLDAPMailId = eCRDUtil.verifyNull(arrMailId[0]);

					}
					arrLstRow.add(strLDAPUserId + "^" + strLDAPFirstName + "^" + strLDAPLastName + "^" + strLDAPMailId);
					arrLstRow.add(strLDAPUserId);
					arrLstRow.add(strLDAPFirstName);
					arrLstRow.add(strLDAPLastName);
					arrLstRow.add(strLDAPMailId);
					geaeUserResultSet.addRow(arrLstRow);
				}
			}
			return geaeUserResultSet;
		}
		finally
		{
			geaeUserResultSet = null;
			vecLdapList = null;
			objUsers = null;
			arrUserId = null;
			arrFirstName = null;
			arrLastName = null;
			arrMailId = null;
			strLDAPUserId = "";
			strLDAPFirstName = "";
			strLDAPLastName = "";
			strLDAPMailId = "";
			arrLstRow = null;
			geaeUserResultSet = null;
		}
	} //end of method getUserInfoFromLDAP()

	/*
		* Method name:  getUserEmailInfoFromLDAP
		* Brief logic:	Taking search values and find the user information
		* @author    :  Patni Computer Systems--Offshore Team
		* @version   :  1.0
		* @param     :  GEAEPrincipal,String,String
		* @return    :  GEAEResultSet
		* @since     :  JDK1.0
		*/
	private GEAEResultSet getUserEmailInfoFromLDAP(GEAEPrincipal objGEAEPrincipal, String strFirstNameSearchValue, String strLastNameSearchValue) throws Exception
	{
		Vector vecLdapList = new Vector();
		GEAELdapObject objUsers = null;
		String[] arrUserId = null;
		String[] arrFirstName = null;
		String[] arrLastName = null;
		String[] arrMailId = null;
		String strLDAPUserId = "";
		String strLDAPFirstName = "";
		String strLDAPLastName = "";
		String strLDAPMailId = "";
		ArrayList arrLstRow = null;
		GEAEResultSet geaeUserResultSet = null;
		String[] strArrAttributeLst = null;
		StringBuffer strBuffQry = null;
		GEAELdapSearchOperation objLDAPSearchOp = null;
		try
		{
			objLDAPSearchOp = new GEAELdapSearchOperation();
			strArrAttributeLst = new String[] { "givenname", "sn", "mail" };
			strBuffQry = new StringBuffer();

			if (!"".equals(strFirstNameSearchValue) && !"".equals(strLastNameSearchValue))
			{
				strBuffQry.append("(&(givenname=" + strFirstNameSearchValue + ")(sn=" + strLastNameSearchValue + "))");
			}
			else
			{

				if (!"".equals(strFirstNameSearchValue))
				{
					strBuffQry.append("(givenname=" + strFirstNameSearchValue + ")");
				}

				if (!"".equals(strLastNameSearchValue))
				{
					strBuffQry.append("(sn=" + strLastNameSearchValue + ")");
				}
			}

			objLDAPSearchOp.setAttributes(strArrAttributeLst);
			objLDAPSearchOp.setQuery(strBuffQry.toString());
			GEAELdapSL ldapBean = GEAELdapBeanFactory.getLdapBean(objGEAEPrincipal);
			objLDAPSearchOp = (GEAELdapSearchOperation) ldapBean.doOperation(objLDAPSearchOp);
			vecLdapList = objLDAPSearchOp.getResultSet();
			geaeUserResultSet = new GEAEResultSet();
			if (vecLdapList != null && !vecLdapList.isEmpty())
			{
				for (int intCtr = 0; intCtr < vecLdapList.size(); intCtr++)
				{
					objUsers = (GEAELdapObject) vecLdapList.elementAt(intCtr);
					arrLstRow = new ArrayList();
					if (objUsers != null)
					{
						arrFirstName = objUsers.getValues("givenname");
						arrLastName = objUsers.getValues("sn");
						arrMailId = objUsers.getValues("mail");
					}
					if (arrUserId != null && arrUserId.length > 0)
					{
						strLDAPUserId = arrUserId[0];
					}
					if (arrFirstName != null && arrFirstName.length > 0)
					{
						strLDAPFirstName = eCRDUtil.verifyNull(arrFirstName[0]);
					}
					if (arrLastName != null && arrLastName.length > 0)
					{
						strLDAPLastName = eCRDUtil.verifyNull(arrLastName[0]);
					}
					if (arrMailId != null && arrMailId.length > 0)
					{
						strLDAPMailId = eCRDUtil.verifyNull(arrMailId[0]);

					}
					arrLstRow.add(strLDAPFirstName);
					arrLstRow.add(strLDAPLastName);
					arrLstRow.add(strLDAPMailId);
					geaeUserResultSet.addRow(arrLstRow);
				}
			}
			return geaeUserResultSet;
		}
		finally
		{
			geaeUserResultSet = null;
			vecLdapList = null;
			objUsers = null;
			arrUserId = null;
			arrFirstName = null;
			arrLastName = null;
			arrMailId = null;
			strLDAPUserId = "";
			strLDAPFirstName = "";
			strLDAPLastName = "";
			strLDAPMailId = "";
			arrLstRow = null;
			geaeUserResultSet = null;
		}
	} //end of method getUserEmailInfoFromLDAP()

	/*
			* Method name:  searchUserDetails
			* Brief logic:	Taking UserId and find the user information if that user id is present in db
			* @author    :  Patni Computer Systems--Offshore Team
			* @version   :  1.0
			* @param     :  GEAEPrincipal,String,HttpServletRequest
			* @return    :  GEAEResultSet
			* @since     :  JDK1.0
			*/
	private GEAEResultSet searchUserDetails(String strUserId) throws Exception
	{
		GEAEResultSet rsHold = null;
		ArrayList arrLstInParam = null;
		eCRDSearchBean eCRDSearchBean = null;
		String strAction = "";
		try
		{
			arrLstInParam = new ArrayList();
			eCRDSearchBean = new eCRDSearchBean();
			rsHold = new GEAEResultSet();
			arrLstInParam.add(strUserId);
			strAction = eCRDConstants.getActionId("eCRD_USER_DETAILS");
			rsHold = eCRDSearchBean.SearchUserData(strAction, arrLstInParam);
			return rsHold;
		}
		finally
		{
			rsHold = null;
			arrLstInParam = null;
			strAction = null;
		}
	}
	//end of method searchUserDetails()
	/*
				* Method name:  formatLdapResultSet
				* Brief logic:	Taking GEAEResultSet and formating it 
				* @author    :  Patni Computer Systems--Offshore Team
				* @version   :  1.0
				* @param     :  GEAEPrincipal,String,HttpServletRequest
				* @return    :  GEAEResultSet
				* @since     :  JDK1.0
				*/
	private GEAEResultSet formatLdapResultSet(GEAEResultSet rsSearchList) throws Exception
	{
		GEAEResultSet rsFormattedRS = null;
		ArrayList arrLstInRow = null;
		rsFormattedRS = new GEAEResultSet();
		GEAETagNoData ctag = null;
		String strTagValue = "";
		try
		{
			rsSearchList.setCurrentRow(0);
//        19-05-2006 patni checking null value Begin
            if(rsSearchList != null)
            {
//        19-05-2006 patni checking null value End 
            while (rsSearchList.next())
			{
				arrLstInRow = new ArrayList();
				strTagValue = "<INPUT TYPE='RADIO' NAME='rdUser' value='" + rsSearchList.getString(1) + "' ";
				strTagValue += " >";
				ctag = new GEAETagNoData(strTagValue);
				arrLstInRow.add(ctag);
				arrLstInRow.add(rsSearchList.getString(2));
				arrLstInRow.add(rsSearchList.getString(3) + ' ' + rsSearchList.getString(4));
				arrLstInRow.add(rsSearchList.getString(5));
				arrLstInRow.add(rsSearchList.getString(5));
				rsFormattedRS.addRow(arrLstInRow);
			}
//          19-05-2006 patni checking null value Begin             
        } // end if 
//    19-05-2006 patni checking null value End
			rsFormattedRS.setColumnHeading(1, "");
			rsFormattedRS.setColumnHeading(2, "User ID");
			rsFormattedRS.setColumnHeading(3, "User Name");
			rsFormattedRS.setColumnHeading(4, "Email Id");
			return rsFormattedRS;
		}
		finally
		{
			arrLstInRow = null;
			rsFormattedRS = null;
			ctag = null;
			strTagValue = null;
		}
	} //end of method formatLdapResultSet()
	private String getLdapSubmitDetails() throws Exception
	{
		String strHdnUserId = "";
		String strSiteCode = "";
		String strRoleCode = "";
		String strStatus = "";
		eCRDUser objeCRDNewUser = null;
		String strRole = "";
		String strSite = "";
		String strMsg = "";
		String strReturnURL = "";
		String strDualRoleIndicator = "";
		GEAEResultSet rsSearchList = null;
		try
		{
			strHdnUserId = eCRDUtil.verifyNull(request.getParameter("hdnUserId"));
			rsSearchList = searchUserDetails(strHdnUserId);
			//strRoleCode = rsSearchList.getString(2);
			objeCRDNewUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser");
			strRole = objeCRDNewUser.getRole();
			strSite = objeCRDNewUser.getSite().getSiteCode();
			strMsg = eCRDConstants.getMessage("USER_PRIVILAGE");
			if (rsSearchList != null && rsSearchList.size() != 0)
			{
				rsSearchList.next();
				strSiteCode = rsSearchList.getString(1);
				strRoleCode = rsSearchList.getString(2);
				strStatus = rsSearchList.getString(3);
				strDualRoleIndicator = rsSearchList.getString(4);
				request.setAttribute("strSiteCode", strSiteCode);
				request.setAttribute("strRoleCode", strRoleCode);
				request.setAttribute("strStatus", strStatus);
				request.setAttribute("strDualRoleIndicator", strDualRoleIndicator);

				if (eCRDConstants.ROLE_TECH_COORD.equals(strRole) && (eCRDConstants.ROLE_ADMINISTRATOR.equals(strRoleCode)
				|| !strSite.equals(strSiteCode ) ))
				{
					request.setAttribute("strMsg", strMsg);
					strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-listUsers";
				}
				else
				{
                    strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-modifyUser";
				}
			}
			else
			{
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-createUser";
			}
			return strReturnURL;
		}
		finally
		{
			strHdnUserId = null;
			strSiteCode = null;
			strRoleCode = null;
			strStatus = null;
			objeCRDNewUser = null;
			strRole = null;
			strMsg = null;
			strReturnURL = null;
			rsSearchList = null;
		}
	}
	private void getLdapRowCacheDetails() throws Exception
	{
		String strSearch = "";
		GEAEResultSet rsSearchList = null;
		GEAEResultSet rsFormatSearchList = null;
		eCRDDataBean objeCRDDataBean = null;
		GEAEPrincipal objGEAEPrincipal = null;
		eCRDException objeCRDException = null;
		try
		{
			objeCRDDataBean = new eCRDDataBean();
			strSearch = eCRDUtil.verifyNull(request.getParameter("txtUserId"));
			//rsSearchList = getUserDetails(strSearch, request);
			/*Remove Following Comment For Ldap Connection And Commented Above Line */
			objGEAEPrincipal = new GEAEPrincipal();
			rsSearchList = getUserInfoFromLDAP(objGEAEPrincipal, strSearch);
			if (rsSearchList.size() == 0)
			{
				objeCRDException = new eCRDException();
				objeCRDException.setExcpId("USER_NOT_FOUND_LDAP");
				throw objeCRDException;
			}
			rsFormatSearchList = formatLdapResultSet(rsSearchList);
			objeCRDDataBean.setCache(rsFormatSearchList);
			eCRDUtil.loadInSession(request, "objeCRDLdapUserListing", objeCRDDataBean);
		}
		finally
		{
			strSearch = null;
			rsSearchList = null;
			rsFormatSearchList = null;
			objeCRDDataBean = null;
			objGEAEPrincipal = null;
		}
	}
	/**
			 * request: action=
			 * Updates Price for All the repairs under that component.
			 */

	private void getEmailGroups() throws Exception
	{
		GEAEResultSet rsGroups = null;
		ArrayList arrLstInParam = null;
		eCRDSearchBean eCRDSearchBean = null;
		String strAction = null;
		GEAEResultSet rsFormattedGroup = null;
		eCRDDataBean objeCRDNewDataBean = null;
		try
		{
			arrLstInParam = new ArrayList();
			eCRDSearchBean = new eCRDSearchBean();
			//rsHold = new GEAEResultSet();
			objeCRDNewDataBean = new eCRDDataBean();

			rsGroups = eCRDSearchBean.listGroups();
			rsFormattedGroup = formatGroupInformation(rsGroups);
			objeCRDNewDataBean.setCache(rsFormattedGroup);
			eCRDUtil.loadInSession(request, "objeCRDGroupListing", objeCRDNewDataBean);
		}
		finally
		{
			rsGroups = null;
			arrLstInParam = null;
			strAction = null;
			objeCRDNewDataBean = null;
		}
	}

	/*
				   * Method name:  searchGroupUser
				   * Brief logic:	This method searched the database  depending
				   *  				the parameters such as first name last name
				   * 				coming from request
				   * @return    :  void
				   */

	private void searchGroupUser() throws Exception
	{
		ArrayList arrLstInParam = null;
		eCRDDataBean objeCRDDataBean = null;
		eCRDDataBean objeCRDNewDataBean = null;
		eCRDBusinessBean objeCRDBusinessBean = null;
		eCRDUser objeCRDNewUser = null;
		String strAction = null;
		String strFName = null;
		String strLName = null;
		String strRole = null;
		String strSite = null;
		String strLoginRole = null;
		GEAEResultSet rsSearchList = null;
		String strUserId = null;
		String strSiteCode = null;
		eCRDSite objeCRDSite = null;
		GEAEResultSet rsGroupFormatted = null;
		GEAEPrincipal objGEAEPrincipal = null;
		eCRDException objeCRDException = null;
		try
		{
			arrLstInParam = new ArrayList();
			strFName = eCRDUtil.verifyNull(request.getParameter("txtFName"));
			strLName = eCRDUtil.verifyNull(request.getParameter("txtLName"));
			objeCRDBusinessBean = new eCRDBusinessBean();
			objeCRDNewDataBean = new eCRDDataBean();

			strAction = eCRDConstants.getActionId("eCRD_SEARCH_USER_FOR_GROUP");
			/*			arrLstInParam.add(strFName);
						arrLstInParam.add(strLName);
						geaersetUserList = objeCRDBusinessBean.populateEmailList(strAction, arrLstInParam);
						
						rsGroupFormatted = formatEmailResultSet(geaersetUserList);*/
			objGEAEPrincipal = new GEAEPrincipal();
			rsSearchList = getUserEmailInfoFromLDAP(objGEAEPrincipal, strFName, strLName);
			if (rsSearchList.size() == 0)
			{
				objeCRDException = new eCRDException();
				objeCRDException.setExcpId("USER_NOT_FOUND_LDAP");
				throw objeCRDException;
			}
			rsGroupFormatted = formatEmailResultSet(rsSearchList);
			objeCRDNewDataBean.setCache(rsGroupFormatted);
			eCRDUtil.loadInSession(request, "objeCRDGroupUserListing", objeCRDNewDataBean);
		}
		finally
		{
			arrLstInParam = null;
			objeCRDDataBean = null;
			objeCRDBusinessBean = null;
			strFName = null;
			strLName = null;
			strRole = null;
			strSite = null;

			objeCRDNewDataBean = null;
		}
	}

	/**
				 * 
				 * This function formats the resultset for email addresses in a Email group.
				 */

	private GEAEResultSet formatEmailResultSet(GEAEResultSet rsSearchResults) throws Exception
	{
		GEAEResultSet rsFormattedRS = null;
		String strUser = null;
		String strFirstName = null;
		String strLastName = null;
		String strEmailId = null;
		ArrayList arrlstInRow = null;
		GEAETag geAETag = null;
		try
		{
			rsFormattedRS = new GEAEResultSet();
			rsSearchResults.setCurrentRow(0);
//        19-05-2006 patni checking null value Begin 
            if(rsSearchResults!=null)
            {
//        19-05-2006 patni checking null value end 
            
            while (rsSearchResults.next())
			{
				arrlstInRow = new ArrayList();
				strUser =
					"<A href=\"javascript:fnAddInGroup('"
						+ rsSearchResults.getString(1)
						+ "\',\'"
						+ rsSearchResults.getString(2)
						+ "\',\'"
						+ rsSearchResults.getString(3)
						+ "')\">"
						+ rsSearchResults.getString(1)
						+ " "
						+ rsSearchResults.getString(2)
						+ "</A>";
				geAETag = new GEAETag(rsSearchResults.getString(1), strUser);
				arrlstInRow.add(geAETag);
				strEmailId = rsSearchResults.getString(3);
				arrlstInRow.add(strEmailId);
				rsFormattedRS.addRow(arrlstInRow);
				arrlstInRow = null;
			}
//          19-05-2006 patni checking null value Begin 
        } // end if 
//    19-05-2006 patni checking null value Begin 
			rsFormattedRS.setColumnHeading(1, "Name");
			rsFormattedRS.setColumnHeading(2, "Email Id");
			return rsFormattedRS;
		}
		finally
		{
			rsFormattedRS = null;
			strUser = null;
			strFirstName = null;
			strLastName = null;
			strEmailId = null;
			arrlstInRow = null;
			geAETag = null;
		}
	}

	/**
				 * 
				 * This function formats the resultset.
				 */

	private GEAEResultSet formatGroupInformation(GEAEResultSet rsSearchList) throws Exception
	{
		GEAEResultSet rsFormattedRS = null;
		ArrayList arrLstInRow = null;
		rsFormattedRS = new GEAEResultSet();
		GEAETagNoData ctag = null;
		String strTagValue = null;
		try
		{
			rsSearchList.setCurrentRow(0);
//        19-05-2006 patni checking null value Begin 
            if(rsSearchList != null)
            {
//        19-05-2006 patni checking null value end             
            
            while (rsSearchList.next())
			{
				arrLstInRow = new ArrayList();
				strTagValue = "<INPUT TYPE='RADIO' NAME='rdUser' value='" + rsSearchList.getString(1) + "^" + rsSearchList.getString(2) + "' ";
				strTagValue += " >";
				ctag = new GEAETagNoData(strTagValue);
				arrLstInRow.add(ctag);
				arrLstInRow.add(rsSearchList.getString(2));
				rsFormattedRS.addRow(arrLstInRow);
			}
//          19-05-2006 patni checking null value Begin             
            } // end if
//          19-05-2006 patni checking null value end            
			rsFormattedRS.setColumnHeading(1, "Select");
			rsFormattedRS.setColumnHeading(2, "Group Name");
			return rsFormattedRS;
		}
		finally
		{
			arrLstInRow = null;
			rsFormattedRS = null;
			ctag = null;
			strTagValue = null;
		}
	}

	private String createGroups() throws Exception
	{
		ArrayList arrLstInParam = null;
		String strAction = null;
		String strGroupName = null;
		String strUserId = null;
		String strGroupCode = null;
		eCRDUser objeCRDUser = null;
		ArrayList arrlstOutParam = null;
		String strMsg = null;
		try
		{
			objeCRDUser = new eCRDUser();
			arrlstOutParam = new ArrayList();

			strGroupName = eCRDUtil.verifyNull(request.getParameter("txtGrpName"));
			

			arrLstInParam = new ArrayList();
			objeCRDUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser");
			strUserId = objeCRDUser.getUserId();
			arrLstInParam.add(strGroupName);
			arrLstInParam.add(strUserId);			
			strAction = eCRDConstants.getActionId("eCRD_CREATE_EMAIL_GROUP");
			arrlstOutParam = (ArrayList) objeCRDUser.insertEmailGroup(strAction, arrLstInParam);
			strGroupCode = (String) arrlstOutParam.get(0);
			strMsg = (String) arrlstOutParam.get(1);
			request.setAttribute("strMsg", strMsg);
			if (!"GROUP_ALREADY_EXISTS".equals(strMsg))
			{
				eCRDUtil.loadInSession(request, "strGroupName", strGroupName);	
			}
			if (strGroupCode != null)
			{
				eCRDUtil.loadInSession(request, "strGroupCode", strGroupCode);
			}
			request.setAttribute("hdnGroupCode", strGroupCode);
			return strMsg;

		}
		finally
		{
			arrLstInParam = null;
			strAction = null;
			strGroupName = null;
			strUserId = null;
			strGroupCode = null;
			objeCRDUser = null;
			strMsg = null;
		}
	}

	/**
	 * This method adds particular email id into the data base.
	 * returns void
		 */

	private void addEmailToGroup() throws Exception
	{
		String strGroupCode = null;
		ArrayList arrLstInParam = null;
		String strAction = null;
		String strEmailAddress = null;
		String strUserId = null;
		GEAEResultSet rsetUserList = null;
		eCRDUser objeCRDUser = null;
		ArrayList arrlstOutParam = null;
		String strMsg = null;
		try
		{
			objeCRDUser = new eCRDUser();
			arrlstOutParam = new ArrayList();
			arrLstInParam = new ArrayList();
			strGroupCode = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, "strGroupCode"));
			if ("".equals(strGroupCode) || strGroupCode == null)
			{
				strGroupCode = eCRDUtil.verifyNull(request.getParameter("hdnGroupCode"));
				eCRDUtil.loadInSession(request, "strGroupCode", strGroupCode);
			}

			strEmailAddress = eCRDUtil.verifyNull(request.getParameter("hdnEmail"));
			strAction = eCRDConstants.getActionId("eCRD_ADD_EMAIL_IN_GROUP");
			objeCRDUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser");
			strUserId = objeCRDUser.getUserId();
			arrLstInParam.add(strGroupCode);
			arrLstInParam.add(strEmailAddress);
			arrLstInParam.add(strUserId);
			arrlstOutParam = objeCRDUser.addEmailInGroup(strAction, arrLstInParam);
			rsetUserList = (GEAEResultSet) arrlstOutParam.get(0);
			strMsg = (String) arrlstOutParam.get(1);
			request.setAttribute("strMsg", strMsg);
			request.setAttribute("rsGroupsAddress", rsetUserList);
		}
		finally
		{
			strGroupCode = null;
			arrLstInParam = null;
			strAction = null;
			strEmailAddress = null;
			strUserId = null;
			rsetUserList = null;
			objeCRDUser = null;
			arrlstOutParam = null;
			strMsg = null;
		}
	}

	/**
	 * This method delete particular email id into the data base.
	 * returns void
	 */

	private void deleteEmailFromGroup() throws Exception
	{
		String strGroupCode = null;
		ArrayList arrLstInParam = null;
		String strAction = null;
		String strEmailAddress = null;
		ArrayList arrlstOutParam = null;
		GEAEResultSet rsetUserList = null;
		eCRDUser objeCRDUser = null;
		String strMsg = null;
		try
		{
			objeCRDUser = new eCRDUser();
			arrlstOutParam = new ArrayList();
			strGroupCode = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, "strGroupCode"));
			if ("".equals(strGroupCode) || strGroupCode == null)
			{
				strGroupCode = eCRDUtil.verifyNull(request.getParameter("hdnGroupCode"));
				eCRDUtil.loadInSession(request, "strGroupCode", strGroupCode);
			}

			strEmailAddress = eCRDUtil.verifyNull(request.getParameter("hdnEmail"));
			strAction = eCRDConstants.getActionId("eCRD_DELETE_EMAIL_FROM_GROUP");
			arrLstInParam = new ArrayList();
			arrLstInParam.add(strGroupCode);
			arrLstInParam.add(strEmailAddress);
			arrlstOutParam = (ArrayList) objeCRDUser.deleteEmailFromGroup(strAction, arrLstInParam);
			rsetUserList = (GEAEResultSet) arrlstOutParam.get(0);
			strMsg = (String) arrlstOutParam.get(1);
			request.setAttribute("strMsg", strMsg);
			request.setAttribute("rsGroupsAddress", rsetUserList);
		}
		finally
		{
			strGroupCode = null;
			arrLstInParam = null;
			strAction = null;
			strEmailAddress = null;
			arrlstOutParam = null;
			rsetUserList = null;
			objeCRDUser = null;
			strMsg = null;

		}
	}
	/**
		 * This method is called to populate email addresses in 
		 * a particular group from the data base.
		 * returns void
			 */

	private void listEmailForGroup() throws Exception
	{
		String strGroupCode = null;
		String strGroupName = null;
		ArrayList arrLstInParam = null;
		String strAction = null;
		eCRDUser objeCRDUser = null;
		GEAEResultSet rsetUserList = null;
		try
		{

			strGroupCode = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, "strGroupCode"));
			strGroupName = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, "strGroupName"));
			if ("".equals(strGroupName) || strGroupName == null)
			{
				strGroupName = eCRDUtil.verifyNull(request.getParameter("hdnGroupName"));
				eCRDUtil.loadInSession(request, "strGroupName", strGroupName);
			}
			if ("".equals(strGroupCode) || strGroupCode == null)
			{
				strGroupCode = eCRDUtil.verifyNull(request.getParameter("hdnGroupCode"));
				eCRDUtil.loadInSession(request, "strGroupCode", strGroupCode);
			}
			strAction = eCRDConstants.getActionId("eCRD_ADD_EMAIL_IN_GRP");
			arrLstInParam = new ArrayList();
			objeCRDUser = new eCRDUser();
			arrLstInParam.add(strGroupCode);
			rsetUserList = objeCRDUser.listEmailForGroup(strAction, arrLstInParam);
			request.setAttribute("rsGroupsAddress", rsetUserList);
		}
		finally
		{
			strGroupCode = null;
			strGroupName = null;
			arrLstInParam = null;
			strAction = null;
			objeCRDUser = null;
			rsetUserList = null;
		}
	}

	/**
			 * This method is called to populate email addresses in 
			 * a particular group from the data base.
			 * returns void
				 */

	private void associateEvent() throws Exception
	{
		String strGroupName = null;
		String strGroupCode = null;
		try
		{

			strGroupCode = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, "strGroupCode"));
			strGroupName = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, "strGroupName"));

			if ("".equals(strGroupName) || strGroupName == null)
			{
				strGroupName = eCRDUtil.verifyNull(request.getParameter("hdnGroupName"));
				eCRDUtil.loadInSession(request, "strGroupName", strGroupName);
				strGroupCode = eCRDUtil.verifyNull(request.getParameter("hdnGroupCode"));
				eCRDUtil.loadInSession(request, "strGroupCode", strGroupCode);											
			}
			eCRDUtil.loadInSession(request, "strAssociateEvent", "");
		}
		finally
		{
			strGroupName = null;
			strGroupCode = null;

		}

	}

	/**
			 * This method is called to associate the events  
			 * a particular group from the data base.
			 * returns void
				 */

	private void attachEventToGroup(HttpServletRequest request) throws Exception
	{
		String strEvents = null;
		String strGroupCode = null;
		String strMsg = null;
		String strActionId = null;
		String strUserId = null;
		ArrayList arrlstInParam = null;
		eCRDUser objeCRDUser = null;

		try
		{

			objeCRDUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser");
			strUserId = objeCRDUser.getUserId();
			arrlstInParam = new ArrayList();
			strActionId = eCRDConstants.getActionId("eCRD_ATTACH_EVENT_TO_GROUP");
			strEvents = eCRDUtil.verifyNull(request.getParameter("hdnEvents"));
			strGroupCode = eCRDUtil.verifyNull(request.getParameter("hdnGroupCode"));
			arrlstInParam.add(strGroupCode);
			arrlstInParam.add(strEvents);
			arrlstInParam.add(strUserId);
			strMsg = objeCRDUser.attachEventToGroup(strActionId, arrlstInParam);
			request.setAttribute("strMsg", strMsg);
			eCRDUtil.loadInSession(request, "strAssociateEvent", eCRDConstants.STRASSOCIATEEVENTSAVED);

		}
		finally
		{
			strEvents = null;
			strGroupCode = null;
			strMsg = null;
			strActionId = null;
			strUserId = null;
			arrlstInParam = null;
			objeCRDUser = null;

		}
	}

	private void deleteGroup(HttpServletRequest request) throws Exception
	{
		String strGroupCode = null;
		ArrayList arrLstInParam = null;
		ArrayList arrlstOutParam = null;
		String strAction = null;
		eCRDUser objeCRDUser = null;
		String strMsg = null;
		GEAEResultSet rsetUserList = null;
		GEAEResultSet rsFormattedGroup = null;
		eCRDDataBean objeCRDNewDataBean = null;
		try
		{

		
			objeCRDUser = new eCRDUser();
			objeCRDNewDataBean = new eCRDDataBean();
			strGroupCode = eCRDUtil.verifyNull(request.getParameter("hdnGroupCode"));
			strAction = eCRDConstants.getActionId("eCRD_DELETE_GROUP");
			arrLstInParam = new ArrayList();
			arrLstInParam.add(strGroupCode);
			arrlstOutParam = objeCRDUser.deleteGroup(strAction, arrLstInParam);
			rsetUserList = (GEAEResultSet) arrlstOutParam.get(0);
			strMsg = (String) arrlstOutParam.get(1);
			request.setAttribute("strMsg", strMsg);
			rsFormattedGroup = formatGroupInformation(rsetUserList);
			objeCRDNewDataBean.setCache(rsFormattedGroup);
			eCRDUtil.loadInSession(request, "objeCRDGroupListing", objeCRDNewDataBean);
		}
		finally
		{
			strGroupCode = null;
			arrLstInParam = null;
			strAction = null;
			objeCRDUser = null;
			rsetUserList = null;
		}
	}

}
