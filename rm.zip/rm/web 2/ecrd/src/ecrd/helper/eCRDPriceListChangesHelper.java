//Source file: D:\\ECRD\\SOURCE CODE\\ecrd\\helper\\eCRDPriceListChangesHelper.java

/**
 * Module       : eCRDPriceListChangesHelper.java
 * Author       : Patni Offshore
 * Project      : eCRD
 * Date Written : October 2004
 * Security     : Classified/Unclassified
 * Restrictions : GE PROPRIETORY INFORMATION, FOR GE USE ONLY
 *
 *     ***************************************************************
 *     *          Copyright (2000) with all rights reserved          *
 *     *                  General Electric Company                   *
 *     ***************************************************************
 * Description  :  This class has methods to get the Master Tables Data.
 * Revision Log  (mm/dd/yyyy     Initials    description)
 * -------------------------------------------------------------------
 *                  10/20/2004     GM    Description
 * -------------------------------------------------------------------
 *
 */

package ecrd.helper;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import ecrd.biz.eCRDCatalog;
import ecrd.biz.eCRDUser;
import ecrd.common.eCRDBusinessBean;
import ecrd.common.eCRDCommand;
import ecrd.common.eCRDDataBean;
import ecrd.exception.eCRDException;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDSearchBean;
import ecrd.util.eCRDUtil;
import geae.dao.GEAEResultSet;

public class eCRDPriceListChangesHelper implements eCRDCommand
{

    public eCRDPriceListChangesHelper()
    {
    }

    /**
    * Based "action" attribute from the request, this function calls the appropriate 
    * private functions in this class.
    * Also sets the received request to member variable.
    * @param request
    */

    public String perform(HttpServletRequest request) throws Exception
    {
        String strReturnURL = "";
        String strScreenAction = "";
        try
        {
            strScreenAction = eCRDUtil.verifyNull(request.getParameter("hdnScreenAction"));
            if ("".equalsIgnoreCase(strScreenAction))
            {
                eCRDUtil.clearSession(request);
                strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-priceListChanges";
            }
            else if (eCRDConstants.getActionId("eCRD_PRICE_LIST_REPORT").equalsIgnoreCase(strScreenAction))
            {
                getPriceListReport(request);
                strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-priceListChangesReport";
            }
            // To display the page for selecting catalog for price 
            // listing changes report yearly
            else if (eCRDConstants.getActionId("eCRD_PRICE_LIST_CHANGES_YRS").equalsIgnoreCase(strScreenAction))
            {
                eCRDUtil.clearSession(request);
                strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-priceListChangesYrs";
            }
            // To display the Price Listing Changes Yearly Report
            else if (eCRDConstants.getActionId("eCRD_VIEW_PRICE_CHANGE_LISTING_REPORT_YEARLY").equalsIgnoreCase(strScreenAction))
            {
                // Get the list for Price Listing Changes Report
                getPriceListingChangesYearly(request);
                strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-moduleListingForReport";
            }
        }
        finally
        {
        }
        return strReturnURL;
    }

    private void getPriceListingChangesYearly(HttpServletRequest request) throws Exception
    {
        //  To store the resultset 
        GEAEResultSet rsPriceList = null;
        //  To store the formatted resultset
        GEAEResultSet rsFormattedPriceList = null;

        eCRDDataBean objeCRDDataBean = null;
        eCRDBusinessBean objeCRDBusinessBean = null;
        eCRDException objeCRDException = null;
        eCRDCatalog objeCRDCatalog = null;
    
        //  To store engine module selected
        String strEngineModule = "";
        String strAction ="";
        String strCatalogSeqId = "";
        String strCatalogType = "";
        String strRole = null;
        eCRDUser objeCRDNewUser = null;
        ArrayList arrlstInParam = null;
        
        try
        {
            arrlstInParam = new ArrayList();
            objeCRDDataBean = new eCRDDataBean();
            rsFormattedPriceList = new GEAEResultSet();
            objeCRDBusinessBean  = new eCRDBusinessBean();
            
            objeCRDNewUser =  (eCRDUser)eCRDUtil.getFromSessionApp(request, "objeCRDUser");  
            strRole = objeCRDNewUser.getRole();
            strAction = eCRDConstants.getActionId("eCRD_VIEW_PRICE_CHANGE_LISTING_REPORT_YEARLY");
            
            // Get catalog Object From Session
            objeCRDCatalog = (eCRDCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
            if (objeCRDCatalog == null)
            {
                objeCRDException = new eCRDException();
                objeCRDException.setExcpId("CATALOG_NOT_SET");
                throw objeCRDException;
            }

            strCatalogSeqId = eCRDUtil.verifyNull(objeCRDCatalog.getCatalogSeqId());
            strEngineModule = eCRDUtil.verifyNull(request.getParameter("lstModule"));
            strCatalogType  =  eCRDUtil.verifyNull(objeCRDCatalog.getCatalogType());
            // Adding Parameters to input array list
            arrlstInParam.add(strEngineModule);
            arrlstInParam.add(strCatalogSeqId);
            arrlstInParam.add(strCatalogType);  
            
            rsPriceList = objeCRDBusinessBean.populateComponentList(strAction, arrlstInParam);
            if (rsPriceList.size() > 0)
            {
                rsPriceList.setCurrentRow(0);
                // To format the resultset as per the requirement
                rsFormattedPriceList = formatPriceListChangesYrly(rsPriceList,strRole);
            }
            // To set the formatted resultset in the cache
            objeCRDDataBean.setCache(rsFormattedPriceList);
            // To save the data bean object in session
            eCRDUtil.loadInSession(request, "objeCRDPriceChangeListingYearly", objeCRDDataBean);
            eCRDUtil.loadInSession(request,eCRDConstants.STRENGINEMODULECODE,strEngineModule);
        }
        finally
        {
            strAction =null;
            strEngineModule =null;
            strCatalogSeqId =null;
            rsPriceList = null;
            rsFormattedPriceList = null;
            objeCRDCatalog = null;
            objeCRDDataBean = null;
            objeCRDException = null;
            objeCRDBusinessBean = null;
            arrlstInParam = null;
        }
    }

    /**
    * Get the list of Price list reports by hitting the database. Convert it into 
    * string and set it in request.
    */
    private void getPriceListReport(HttpServletRequest request) throws Exception
    {
        HttpSession session = null;
        eCRDDataBean objeCRDDataBean = null;
        GEAEResultSet rsPriceList = null;
        String strEngModel = null;
        String strPriceDesc = null;
        String strStartdate_DD = null;
        String strStartdate_MM = null;
        String strStartdate_YYYY = null;
        String strEnddate_DD = null;
        String strEnddate_MM = null;
        String strEnddate_YYYY = null;
        String strStartDate = null;
        String strEndDate = null;
        /*Added By Santosh */
        ArrayList arrlist = null; 
        try
        {
            session = request.getSession();
            objeCRDDataBean = new eCRDDataBean();
            rsPriceList = new GEAEResultSet();

            session.setAttribute("PriceList", objeCRDDataBean);

            strEngModel = eCRDUtil.verifyNull(request.getParameter("lstEngModel"));
            strPriceDesc = eCRDUtil.verifyNull(request.getParameter("lstFeature").toLowerCase());
            strStartdate_DD = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_DD"));
            strStartdate_MM = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_MM"));
            strStartdate_YYYY = eCRDUtil.verifyNull(request.getParameter("sel_man_Startdate_YYYY"));
            strEnddate_DD = eCRDUtil.verifyNull(request.getParameter("sel_man_Enddate_DD"));
            strEnddate_MM = eCRDUtil.verifyNull(request.getParameter("sel_man_Enddate_MM"));
            strEnddate_YYYY = eCRDUtil.verifyNull(request.getParameter("sel_man_Enddate_YYYY"));

            strStartDate = eCRDUtil.formatDate(strStartdate_DD, strStartdate_MM, strStartdate_YYYY);
            strEndDate = eCRDUtil.formatDate(strEnddate_DD, strEnddate_MM, strEnddate_YYYY);

            rsPriceList = (GEAEResultSet)eCRDSearchBean.getPriceList(strEngModel, strPriceDesc, strStartDate, strEndDate);

            /* Added By Santosh */

            if (rsPriceList != null)
            {
                if (rsPriceList.size() == 0)
                {
                    request.setAttribute("Display", "N");
                }
                if("added".equalsIgnoreCase(strPriceDesc))
                {
                	rsPriceList = getPriceFormatResultSetForAdded(rsPriceList,strPriceDesc);
                }
                if("deleted".equalsIgnoreCase(strPriceDesc))
                {
                	rsPriceList = getPriceFormatResultSetForDeleted(rsPriceList,strPriceDesc);
                }
                if("Modified".equalsIgnoreCase(strPriceDesc))
                {
                	rsPriceList = getPriceFormatResultSetForModified(rsPriceList,strPriceDesc);
                }
                if (rsPriceList != null && rsPriceList.size() > 0)
                {
                    rsPriceList.setCurrentRow(0);
                    objeCRDDataBean.setCache(rsPriceList);
                }
                else
                {
                    objeCRDDataBean.setCache(new GEAEResultSet());
                }
            }
        }
        finally
        {
            session = null;
            objeCRDDataBean = null;
            rsPriceList = null;
            strEngModel = null;
            strPriceDesc = null;
            strStartdate_DD = null;
            strStartdate_MM = null;
            strStartdate_YYYY = null;
            strEnddate_DD = null;
            strEnddate_MM = null;
            strEnddate_YYYY = null;
            strStartDate = null;
            strEndDate = null;
        }
    }

    /*
     * To format the resultset as per the requirement for Price Listing Report 
     */
    private GEAEResultSet getPriceFormatResultSetForAdded(GEAEResultSet rsPriceList, String feature) throws Exception
    {
        GEAEResultSet rsFormatted = null;
        ArrayList arrlstFormat = null;
        String strTATsign = null;
        String strPRICEsign = null;

        try
        {
            if (rsPriceList != null && rsPriceList.size() > 0)
            {
                rsFormatted = new GEAEResultSet();

                while (rsPriceList.next())
                {
                    arrlstFormat = new ArrayList();
                    arrlstFormat.add(eCRDUtil.verifyNull(rsPriceList.getString(1)));
                    arrlstFormat.add(eCRDUtil.verifyNull(rsPriceList.getString(2)));
                    arrlstFormat.add(eCRDUtil.verifyNull(rsPriceList.getString(3)));
                    arrlstFormat.add(eCRDUtil.verifyNull(rsPriceList.getString(4)));
                    arrlstFormat.add(eCRDUtil.verifyNull(rsPriceList.getString(5)));
                    arrlstFormat.add(eCRDUtil.verifyNull(rsPriceList.getString(6)));
                    arrlstFormat.add(eCRDUtil.verifyNull(rsPriceList.getString(7)));
                    arrlstFormat.add(eCRDUtil.verifyNull(rsPriceList.getString(8)));
                    arrlstFormat.add(eCRDUtil.verifyNull(rsPriceList.getString(9)));
                    arrlstFormat.add(eCRDUtil.verifyNull(eCRDUtil.replaceString(rsPriceList.getString(10), "\r\n", " ")));
                    arrlstFormat.add(eCRDUtil.verifyNull(rsPriceList.getString(11)));
                    strPRICEsign = eCRDUtil.verifyNull(rsPriceList.getString(12));
                    strTATsign = eCRDUtil.verifyNull(rsPriceList.getString(13));
                    

                    if (strTATsign.equals("Y")) //checks if strTATsign contains Y
                    {
                        strTATsign = "+"; //assigns "+" to stsTATsign
                    }
                    else
                    {
                        strTATsign = "";
                    }

                    if (strPRICEsign.equals("Y"))
                    {
                        strPRICEsign = "+"; //assigns "+" to stsTATsign
                    }
                    else
                    {
                        strPRICEsign = "";
                    }
                    arrlstFormat.add(strPRICEsign + eCRDUtil.verifyNull(rsPriceList.getString(14)));
                    arrlstFormat.add(strTATsign + eCRDUtil.verifyNull(rsPriceList.getString(15)));
                    arrlstFormat.add(eCRDUtil.verifyNull(rsPriceList.getString(16)));
                    arrlstFormat.add(eCRDUtil.verifyNull(rsPriceList.getString(17)));
                    arrlstFormat.add(eCRDUtil.verifyNull(rsPriceList.getString(18)));
                   
                    
                    rsFormatted.addRow(arrlstFormat);

                }

                rsFormatted.setColumnHeading(1, "Engine Model");
                rsFormatted.setColumnHeading(2, "Catalog Number");
                rsFormatted.setColumnHeading(3, "Module");
                rsFormatted.setColumnHeading(4, "Component Code");
                rsFormatted.setColumnHeading(5, "Component Description");
                rsFormatted.setColumnHeading(6, "Component ATA Number");
                rsFormatted.setColumnHeading(7, "Repair Seq ID");
                rsFormatted.setColumnHeading(8, "Repair Type");
                rsFormatted.setColumnHeading(9, "Parent Rep Seq ID");
                rsFormatted.setColumnHeading(10, "Repair Description");
                rsFormatted.setColumnHeading(11, "Repair Reference");
                rsFormatted.setColumnHeading(12, "Price");
                rsFormatted.setColumnHeading(13, "TAT");
                rsFormatted.setColumnHeading(14, "Price Type");
                rsFormatted.setColumnHeading(15, "Creation Date");
                rsFormatted.setColumnHeading(16, "Created By");
                
            }
            return rsFormatted;
        }
        finally
        {
            arrlstFormat = null;
            strTATsign = null;
            strPRICEsign = null;
        }

    }
    
    /*
     * Added By Santosh
     * 
     */
    
    private GEAEResultSet getPriceFormatResultSetForDeleted(GEAEResultSet rsPriceList, String feature) throws Exception
    {
        GEAEResultSet rsFormatted = null;
        ArrayList arrlstFormat = null;
        String strTATsign = null;
        String strPRICEsign = null;

        try
        {
            if (rsPriceList != null && rsPriceList.size() > 0)
            {
                rsFormatted = new GEAEResultSet();

                while (rsPriceList.next())
                {
                    arrlstFormat = new ArrayList();
                    arrlstFormat.add(eCRDUtil.verifyNull(rsPriceList.getString(1))); //1
                    arrlstFormat.add(eCRDUtil.verifyNull(rsPriceList.getString(2))); //2
                    arrlstFormat.add(eCRDUtil.verifyNull(rsPriceList.getString(3))); //3
                    arrlstFormat.add(eCRDUtil.verifyNull(rsPriceList.getString(4))); //4
                    arrlstFormat.add(eCRDUtil.verifyNull(rsPriceList.getString(5))); //5
                    arrlstFormat.add(eCRDUtil.verifyNull(rsPriceList.getString(6))); //6
                    arrlstFormat.add(eCRDUtil.verifyNull(rsPriceList.getString(7))); //7
                    arrlstFormat.add(eCRDUtil.verifyNull(rsPriceList.getString(8)));
                    arrlstFormat.add(eCRDUtil.verifyNull(rsPriceList.getString(9)));
                    arrlstFormat.add(eCRDUtil.verifyNull(eCRDUtil.replaceString(rsPriceList.getString(10), "\r\n", " "))); //8
                    arrlstFormat.add(eCRDUtil.verifyNull(rsPriceList.getString(11))); //9
                    strPRICEsign = eCRDUtil.verifyNull(rsPriceList.getString(12));
                    strTATsign = eCRDUtil.verifyNull(rsPriceList.getString(13));
                    

                    if (strTATsign.equals("Y")) //checks if strTATsign contains Y
                    {
                        strTATsign = "+"; //assigns "+" to stsTATsign
                    }
                    else
                    {
                        strTATsign = "";
                    }

                    if (strPRICEsign.equals("Y"))
                    {
                        strPRICEsign = "+"; //assigns "+" to stsTATsign
                    }
                    else
                    {
                        strPRICEsign = "";
                    }
                    arrlstFormat.add(strPRICEsign + eCRDUtil.verifyNull(rsPriceList.getString(14))); //10
                    arrlstFormat.add(strTATsign + eCRDUtil.verifyNull(rsPriceList.getString(15))); //11
                    arrlstFormat.add(eCRDUtil.verifyNull(rsPriceList.getString(16))); //12
                    arrlstFormat.add(eCRDUtil.verifyNull(rsPriceList.getString(17))); //13
                    arrlstFormat.add(eCRDUtil.verifyNull(rsPriceList.getString(18))); //14
                    arrlstFormat.add(eCRDUtil.verifyNull(rsPriceList.getString(19))); //15
                    arrlstFormat.add(eCRDUtil.verifyNull(rsPriceList.getString(20))); //16
                    
                    
                    rsFormatted.addRow(arrlstFormat);

                }

                rsFormatted.setColumnHeading(1, "Engine Model");
                rsFormatted.setColumnHeading(2, "Catalog Number");
                rsFormatted.setColumnHeading(3, "Module");
                rsFormatted.setColumnHeading(4, "Component Code");
                rsFormatted.setColumnHeading(5, "Component Description");
                rsFormatted.setColumnHeading(6, "Component ATA Number");
                rsFormatted.setColumnHeading(7, "Repair Seq ID");
                rsFormatted.setColumnHeading(8, "Repair Type");
                rsFormatted.setColumnHeading(9, "Parent Rep Seq ID");
                rsFormatted.setColumnHeading(10, "Repair Description");
                rsFormatted.setColumnHeading(11, "Repair Reference");
                rsFormatted.setColumnHeading(12, "Price");
                rsFormatted.setColumnHeading(13, "TAT");
                rsFormatted.setColumnHeading(14, "Price Type");
                rsFormatted.setColumnHeading(15, "Created By");
                rsFormatted.setColumnHeading(16, "Created Date");
                rsFormatted.setColumnHeading(17, "Deleted By");
                rsFormatted.setColumnHeading(18, "Repair End Date");
                
            }
            return rsFormatted;
        }
        finally
        {
            arrlstFormat = null;
            strTATsign = null;
            strPRICEsign = null;
        }

    }
    
    /*
     * To format the resultset as per the requirement for Price Listing Report for modified
     */
    private GEAEResultSet getPriceFormatResultSetForModified(GEAEResultSet rsPriceList, String feature) throws Exception
    {
        GEAEResultSet rsFormatted = null;
        ArrayList arrlstFormat = null;
        String strTATsign = null;
        String strPRICEsign = null;
        
        String engineModel = null;   		//1
        
        String prevCatalog = null;  		//2
        String nextCatalog = null;
        
        String prevModule = null;    		//3
        String nextModule = null;        
        
        String prevComponent = null;   		//4
        String nextComponent = null;
        
        String prevDescription = null; 		//5	
        String nextDescription = null;
        
        String prevAtaNumber = null;		//6
        String nextAtaNumber = null;
        
        String prevRepairId = null;			//7
        String nextRepairId = null;
        
        String prevRepairDesc = null;		//8
        String nextRepairDesc = null;
        
        String prevRepairRef = null;		//9
        String nextRepairRef = null;
        
        String prevRepairPrice = null;		//10
        String nextRepairPrice = null;
        
        String prevRepairTat = null;		//11
        String nextRepairTat = null;
        
        String prevRepairType = null;		//12
        String nextRepairType = null;
        
        String prevcreatedBy = null;        	//13
        String nextcreatedBy = null; 
        
        String prevcreationDate = null;			//14
        String nextcreationDate = null;
        
        String prevupdatedBy = null;			//15
        String nextupdatedBy = null;
        
        String prevupdatedDate = null;			//16
        String nextupdatedDate = null;	
        
        String prevcomments = null;				//17
        String nextcomments = null;	
        String modifiedVar = null;
        String modifiedResult = null;
        String prevtabType = null;
        String nexttabType = null;
        boolean ifCheck = false;
        boolean lastRecordCheck = false;
        boolean checkCom = false;
       
        try
        {
        	if (rsPriceList != null && rsPriceList.size() > 0)
        	{	 
        		rsFormatted = new GEAEResultSet();
        	
        	while(rsPriceList.next())
        	{
        		if(prevCatalog == null && prevModule == null && prevComponent == null && prevRepairId == null )
        		{
        			engineModel			= eCRDUtil.verifyNull(rsPriceList.getString(1));    //1
        			prevCatalog			= eCRDUtil.verifyNull(rsPriceList.getString(2));    //2
        			prevModule			= eCRDUtil.verifyNull(rsPriceList.getString(3));    //3
        			prevComponent		= eCRDUtil.verifyNull(rsPriceList.getString(4));    //4
        			prevDescription		= eCRDUtil.verifyNull(eCRDUtil.replaceString(rsPriceList.getString(5), "\r\n", " "));  //5
        			prevAtaNumber		= eCRDUtil.verifyNull(rsPriceList.getString(6));   //6
        			prevRepairId		= eCRDUtil.verifyNull(rsPriceList.getString(7));   //7
        			prevRepairDesc		= eCRDUtil.verifyNull(rsPriceList.getString(8));   //8
        			prevRepairRef		= eCRDUtil.verifyNull(rsPriceList.getString(9));   //9
        
        			strPRICEsign		= eCRDUtil.verifyNull(rsPriceList.getString(11));
        			strTATsign			= eCRDUtil.verifyNull(rsPriceList.getString(13));
        			 if (strTATsign.equals("Y")) //checks if strTATsign contains Y
                     {
                         strTATsign = "+"; //assigns "+" to stsTATsign
                     }
                     else
                     {
                         strTATsign = "";
                     }

                     if (strPRICEsign.equals("Y"))
                     {
                         strPRICEsign = "+"; //assigns "+" to stsTATsign
                     }
                     else
                     {
                         strPRICEsign = "";
                     }
        			
        			
        			prevRepairPrice		= strPRICEsign + eCRDUtil.verifyNull(rsPriceList.getString(10)); //10
        			
        			prevRepairTat		= strTATsign + eCRDUtil.verifyNull(rsPriceList.getString(12));  //11
        			prevRepairType		= eCRDUtil.verifyNull(rsPriceList.getString(14));   //12
        			
        			prevupdatedBy			= eCRDUtil.verifyNull(rsPriceList.getString(15)); //13
        			prevupdatedDate			= eCRDUtil.verifyNull(rsPriceList.getString(16)); //14
        			//prevtabType				= eCRDUtil.verifyNull(rsPriceList.getString(17)); //14
        			prevcomments			= eCRDUtil.verifyNull(rsPriceList.getString(19));//15
        			
        			
        				
        		}
        		else
        		{
        			engineModel			= eCRDUtil.verifyNull(rsPriceList.getString(1));
        			nextCatalog			= eCRDUtil.verifyNull(rsPriceList.getString(2));
        			nextModule			= eCRDUtil.verifyNull(rsPriceList.getString(3));
        			nextComponent		= eCRDUtil.verifyNull(rsPriceList.getString(4));
        			nextDescription		= eCRDUtil.verifyNull(eCRDUtil.replaceString(rsPriceList.getString(5), "\r\n", " "));
        			nextAtaNumber		= eCRDUtil.verifyNull(rsPriceList.getString(6));
        			nextRepairId		= eCRDUtil.verifyNull(rsPriceList.getString(7));
        			nextRepairDesc		= eCRDUtil.verifyNull(rsPriceList.getString(8));
        			nextRepairRef		= eCRDUtil.verifyNull(rsPriceList.getString(9));
        
        			strPRICEsign		= eCRDUtil.verifyNull(rsPriceList.getString(11));
        			strTATsign			= eCRDUtil.verifyNull(rsPriceList.getString(13));
        			 if (strTATsign.equals("Y")) //checks if strTATsign contains Y
                     {
                         strTATsign = "+"; //assigns "+" to stsTATsign
                     }
                     else
                     {
                         strTATsign = "";
                     }

                     if (strPRICEsign.equals("Y"))
                     {
                         strPRICEsign = "+"; //assigns "+" to stsTATsign
                     }
                     else
                     {
                         strPRICEsign = "";
                     }
        			
        			
        			nextRepairPrice		= strPRICEsign + eCRDUtil.verifyNull(rsPriceList.getString(10));
        			
        			nextRepairTat		= strTATsign + eCRDUtil.verifyNull(rsPriceList.getString(12));
        			nextRepairType		= eCRDUtil.verifyNull(rsPriceList.getString(14));
        			
        			nextupdatedBy			= eCRDUtil.verifyNull(rsPriceList.getString(15));
        			nextupdatedDate			= eCRDUtil.verifyNull(rsPriceList.getString(16));
        			//nexttabType				= eCRDUtil.verifyNull(rsPriceList.getString(17));
        			nextcomments			= eCRDUtil.verifyNull(rsPriceList.getString(19));
        			
        			if(nextCatalog.equals(prevCatalog) && nextModule.equals(prevModule) && nextComponent.equals(prevComponent) && nextRepairId.equals(prevRepairId))
        			{
        				//nextcomments = prevcomments;
        				checkCom = true;
        				
        				if(!nextRepairDesc.equals(prevRepairDesc)){
        					modifiedVar = " Repair Description";
        				}
        				if(!nextRepairRef.equals(prevRepairRef))
        				{
        					if(modifiedVar != null)
        					{
        					modifiedVar = modifiedVar.concat(",Repair Ref");
        					}
        					else
        					{
        						modifiedVar = " Repair Ref";
        					}
        				}
        				if(!nextRepairPrice.equals(prevRepairPrice))
        				{
        					if(modifiedVar != null)
        					{
        					modifiedVar = modifiedVar.concat(",Price");
        					}
        					else
        					{
        						modifiedVar = " Price";
        					}
        				}
        				if(!nextRepairTat.equals(prevRepairTat))
        				{
        					if(modifiedVar != null)
        					{
        					modifiedVar = modifiedVar.concat(",TAT");
        					}
        					else
        					{
        						modifiedVar = " TAT";
        					}
        				}
        				if(!nextRepairType.equals(prevRepairType))
        				{
        					if(modifiedVar != null)
        					{
        					modifiedVar = modifiedVar.concat(",Price Type");
        					}
        					else
        					{
        						modifiedVar = " Price Type";
        					}
        				}
        				
        				if(modifiedVar != null){
        					modifiedVar =modifiedVar.concat(" modified. ");
        					
        					if("Current Active Record.".equals(prevcomments) || "Repair Deleted.".equals(prevcomments))
        					{
        						arrlstFormat = new ArrayList();
                    			arrlstFormat.add(engineModel); //1
                    			arrlstFormat.add(prevCatalog); //2
                    			arrlstFormat.add(prevModule); //3
                    			arrlstFormat.add(prevComponent);  //4
                    			arrlstFormat.add(prevDescription); //5
                    			arrlstFormat.add(prevAtaNumber); //6
                    			arrlstFormat.add(prevRepairId); //7
                    			arrlstFormat.add(prevRepairDesc); //8
                    			arrlstFormat.add(prevRepairRef); //9
                    			arrlstFormat.add(prevRepairPrice); //10
                    			arrlstFormat.add(prevRepairTat); //11
                    			arrlstFormat.add(prevRepairType); //12
                    			arrlstFormat.add(prevupdatedBy); //15
                    			arrlstFormat.add(prevupdatedDate); //16
                    			arrlstFormat.add(prevcomments); //17
                    			
                    			rsFormatted.addRow(arrlstFormat);
        					}
        					
        					/*if(prevcomments != null)
        					{
        					modifiedVar = prevcomments.concat(modifiedVar);
        					}*/
        					
        					ifCheck = true;
        					lastRecordCheck = true;
        					arrlstFormat = new ArrayList();
                			arrlstFormat.add(engineModel); //1
                			arrlstFormat.add(prevCatalog); //2
                			arrlstFormat.add(prevModule); //3
                			arrlstFormat.add(prevComponent);  //4
                			arrlstFormat.add(prevDescription); //5
                			arrlstFormat.add(prevAtaNumber); //6
                			arrlstFormat.add(prevRepairId); //7
                			arrlstFormat.add(prevRepairDesc); //8
                			arrlstFormat.add(prevRepairRef); //9
                			arrlstFormat.add(prevRepairPrice); //10
                			arrlstFormat.add(prevRepairTat); //11
                			arrlstFormat.add(prevRepairType); //12
                			arrlstFormat.add(prevupdatedBy); //15
                			arrlstFormat.add(prevupdatedDate); //16
                			arrlstFormat.add(modifiedVar); //17
                			
                			rsFormatted.addRow(arrlstFormat);	
        				}
        				if(prevcomments == null){
        					prevcomments = "";
        				}
        				if(nextcomments == null)
        				{
        					nextcomments = "";
        				}
        				if(modifiedVar == null &&checkCom == true ){
        					nextcomments=prevcomments;
        					nextupdatedDate = prevupdatedDate;
        					nextupdatedBy = prevupdatedBy;
        					checkCom = false;
        				}
        				
        			}else if(ifCheck){
        				arrlstFormat = new ArrayList();
            			arrlstFormat.add(engineModel); //1
            			arrlstFormat.add(prevCatalog); //2
            			arrlstFormat.add(prevModule); //3
            			arrlstFormat.add(prevComponent);  //4
            			arrlstFormat.add(prevDescription); //5
            			arrlstFormat.add(prevAtaNumber); //6
            			arrlstFormat.add(prevRepairId); //7
            			arrlstFormat.add(prevRepairDesc); //8
            			arrlstFormat.add(prevRepairRef); //9
            			arrlstFormat.add(prevRepairPrice); //10
            			arrlstFormat.add(prevRepairTat); //11
            			arrlstFormat.add(prevRepairType); //12
            			arrlstFormat.add(prevupdatedBy); //15
            			arrlstFormat.add(prevupdatedDate); //16
            			arrlstFormat.add("Initial Record"); //17
            			rsFormatted.addRow(arrlstFormat);
            			ifCheck 		= false;
            			lastRecordCheck = false;
        			}
        			
        			
        			prevCatalog 	= nextCatalog;
        			prevModule 		= nextModule;
        			prevComponent	= nextComponent;
        			prevDescription	= nextDescription;
        			prevAtaNumber	= nextAtaNumber;
        			prevRepairId	= nextRepairId;
        			prevRepairDesc	= nextRepairDesc;
        			prevRepairRef	= nextRepairRef;
        			prevRepairPrice	= nextRepairPrice;
        			prevRepairTat	= nextRepairTat;
        			prevRepairType	= nextRepairType;
        			prevupdatedBy	= nextupdatedBy;
        			prevupdatedDate	= nextupdatedDate;
        			prevcomments	= nextcomments;
        			//prevtabType		= nexttabType
        			modifiedVar     = null;
          			modifiedResult  = null;
          			
        			
        		}
        	}
        	
        	/* added to display last record*/
        	if(lastRecordCheck)
        	{
        	arrlstFormat = new ArrayList();
			arrlstFormat.add(engineModel); //1
			arrlstFormat.add(nextCatalog); //2
			arrlstFormat.add(nextModule); //3
			arrlstFormat.add(nextComponent);  //4
			arrlstFormat.add(nextDescription); //5
			arrlstFormat.add(nextAtaNumber); //6
			arrlstFormat.add(nextRepairId); //7
			arrlstFormat.add(nextRepairDesc); //8
			arrlstFormat.add(nextRepairRef); //9
			arrlstFormat.add(nextRepairPrice); //10
			arrlstFormat.add(nextRepairTat); //11
			arrlstFormat.add(nextRepairType); //12
			arrlstFormat.add(nextupdatedBy); //15
			arrlstFormat.add(nextupdatedDate); //16
			arrlstFormat.add("Initial Record"); //17
			rsFormatted.addRow(arrlstFormat);
			lastRecordCheck = false;
        	}
        	 rsFormatted.setColumnHeading(1,  "Engine Model");
             rsFormatted.setColumnHeading(2,  "Catalog Number");
             rsFormatted.setColumnHeading(3,  "Module");
             rsFormatted.setColumnHeading(4,  "Component code");
             rsFormatted.setColumnHeading(5,  "Component Description");
             rsFormatted.setColumnHeading(6,  "Component ATA Number");
		     rsFormatted.setColumnHeading(7,  "Repair Seq ID");
             rsFormatted.setColumnHeading(8,  "Repair Description");
             rsFormatted.setColumnHeading(9,  "Repair Reference");
             rsFormatted.setColumnHeading(10, "Price");
             rsFormatted.setColumnHeading(11, "TAT");
             rsFormatted.setColumnHeading(12, "Price Type");
             rsFormatted.setColumnHeading(13, "Updated By");
             rsFormatted.setColumnHeading(14, "Updated Date");
             rsFormatted.setColumnHeading(15, "Comments");
        	}	
             return rsFormatted;
        }
        
        
        finally
        {
            arrlstFormat = null;
            strTATsign = null;
            strPRICEsign = null;
        }

    }
    /*
     * To format the resultset as per the requirement for Price Listing 
     * Changes Report Yearly
     */
    private GEAEResultSet formatPriceListChangesYrly(GEAEResultSet rsPriceList,String strRole) throws Exception
    {
        GEAEResultSet rsFormatted = null;
        ArrayList arrlstFormat = null;
        
        String strTATsign = null;
        String strPRICEsign = null;
        Calendar calendar = null;
        
        
        int intYear = 0;
        try
        {
            // To get the system date
            calendar = new GregorianCalendar();
            intYear = calendar.get(Calendar.YEAR);
            if (rsPriceList != null && rsPriceList.size() > 0)
            {
                rsFormatted = new GEAEResultSet();
                while (rsPriceList.next())
                {
                    arrlstFormat = new ArrayList();
                    
                    arrlstFormat.add(eCRDUtil.verifyNull(rsPriceList.getString(1)));
                    arrlstFormat.add(eCRDUtil.verifyNull(rsPriceList.getString(2)));
                    arrlstFormat.add(eCRDUtil.verifyNull(rsPriceList.getString(3)));
                    // Cost Information for Past year
                    //Restricting Guest User from Seeing the Cost Information
                    if(!strRole.equals(eCRDConstants.ROLE_GUEST)) {
                    arrlstFormat.add(eCRDUtil.verifyNull(rsPriceList.getString(4)));
                    }
                    strTATsign = eCRDUtil.verifyNull(rsPriceList.getString(10));
                    if (strTATsign.equals(eCRDConstants.STRTRUE)) //checks if strTATsign contains Y
                    {
                        strTATsign = "+"; //assigns "+" to stsTATsign
                    }
                    else
                    {
                        strTATsign = "";
                    }
                    arrlstFormat.add(strTATsign + eCRDUtil.verifyNull(rsPriceList.getString(5)));
                    strPRICEsign = eCRDUtil.verifyNull(rsPriceList.getString(11));
                    if (strPRICEsign.equals(eCRDConstants.STRTRUE))
                    {
                        strPRICEsign = "+"; //assigns "+" to stsTATsign
                    }
                    else
                    {
                        strPRICEsign = "";
                    }
                    arrlstFormat.add(strPRICEsign + eCRDUtil.verifyNull(rsPriceList.getString(6)));
                    
                    // Cost Information For Current Year
                    //Restricting Guest User from Seeing the Cost Information
                    if(!strRole.equals(eCRDConstants.ROLE_GUEST)) {
                    arrlstFormat.add(eCRDUtil.verifyNull(rsPriceList.getString(7)));
                    }
                    strTATsign = eCRDUtil.verifyNull(rsPriceList.getString(10));
                    if (strTATsign.equals(eCRDConstants.STRTRUE)) //checks if strTATsign contains Y
                    {
                        strTATsign = "+"; //assigns "+" to stsTATsign
                    }
                    else
                    {
                        strTATsign = "";
                    }
                    arrlstFormat.add(strTATsign + eCRDUtil.verifyNull(rsPriceList.getString(8)));
                    strPRICEsign = eCRDUtil.verifyNull(rsPriceList.getString(11));
                    if (strPRICEsign.equals(eCRDConstants.STRTRUE))
                    {
                        strPRICEsign = "+"; //assigns "+" to strPRICEsign
                    }
                    else
                    {
                        strPRICEsign = "";
                    }
                    arrlstFormat.add(strPRICEsign + eCRDUtil.verifyNull(rsPriceList.getString(9)));                 
                    rsFormatted.addRow(arrlstFormat);
                }
                if(strRole.equals(eCRDConstants.ROLE_GUEST)) {
                rsFormatted.setColumnHeading(1, "Component Description");
                rsFormatted.setColumnHeading(2, "Repair Description");
                rsFormatted.setColumnHeading(3, "Site");
                rsFormatted.setColumnHeading(4, "Repair TAT -" + (intYear -1));
                rsFormatted.setColumnHeading(5, "Repair Price -" + (intYear -1));
                rsFormatted.setColumnHeading(6, "Repair TAT -" + intYear);
                rsFormatted.setColumnHeading(7, "Repair Price -" + intYear);
                }else {
                rsFormatted.setColumnHeading(1, "Component Description");
                rsFormatted.setColumnHeading(2, "Repair Description");
                rsFormatted.setColumnHeading(3, "Site");
                rsFormatted.setColumnHeading(4, "Repair Cost - " + (intYear -1));
                rsFormatted.setColumnHeading(5, "Repair TAT -" + (intYear -1));
                rsFormatted.setColumnHeading(6, "Repair Price -" + (intYear -1));
                rsFormatted.setColumnHeading(7, "Repair Cost - " + intYear);
                rsFormatted.setColumnHeading(8, "Repair TAT -" + intYear);
                rsFormatted.setColumnHeading(9, "Repair Price -" + intYear);    
                }
                arrlstFormat = null;
            }
            return rsFormatted;
        }
        finally
        {
            arrlstFormat = null;
            strTATsign = null;
            strPRICEsign = null;
            calendar = null;
            intYear = 0;
        }
    }    
}