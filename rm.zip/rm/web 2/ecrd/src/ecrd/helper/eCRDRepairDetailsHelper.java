//Source file: D:\\ECRD\\SOURCE CODE\\ecrd\\helper\\eCRDMaintenanceHelper.java
/**
 * Module       : eCRDRepairDetailsHelper.java
 * Author       : Patni Offshore
 * Project      : eCRD
 * Date Written : October 2004
 * Security     : Classified/Unclassified
 * Restrictions : GE PROPRIETORY INFORMATION, FOR GE USE ONLY
 *
 *     ***************************************************************
 *     *          Copyright (2000) with all rights reserved          *
 *     *                  General Electric Company                   *
 *     ***************************************************************
 * Description  :  This class has methods to get the Master Tables Data.
 * Revision Log  (mm/dd/yyyy     Initials    description)
 * -------------------------------------------------------------------
 * mm/dd/yyyy     Initials     Description
 * -------------------------------------------------------------------
 *
 */
package ecrd.helper;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;

import ecrd.common.eCRDCommand;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDUtil;
import ecrd.util.eCRDSearchBean;

import geae.dao.GEAEResultSet;

public class eCRDRepairDetailsHelper implements eCRDCommand
{
    private HttpServletRequest request = null;

    public eCRDRepairDetailsHelper()
    {

    }

    /**
     * This method will identify the method to be invoked and also the subsequent
     * screen to be displayed depending on the functionality.
     * Also sets the received request to member variable.
     * @param request
     */
    public String perform(HttpServletRequest request) throws Exception
    {
        String strReturnURL = "";
        String strScreenAction = "";
        HttpSession session = null;
        GEAEResultSet rsRepairs = null;

        try
        {
            strScreenAction = eCRDUtil.verifyNull(request.getParameter("hdnScreenAction"));
            session = request.getSession();

            if ("RepairDetails".equals(strScreenAction))
            {
                //return "/eCRD/jsp/eCRDViewRepairsHelper.jsp";
                //getRepairList(request);
                strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-repairDetails";
            }
        }
        finally
        {
        }
        return strReturnURL;
    }

    /**
     *
     * gets the list of repairs for the selected component
     */
    private void getRepairList(HttpServletRequest request) throws Exception
    {
        ArrayList arrlstOutParam = null;
        String strActionId = null;
        eCRDSearchBean objeCRDSearchBean = null;
        String strEngineModelCode = null;
        String strModuleCode = null;
        String strComponentCode = null;
        String strRepairCode = null;
        GEAEResultSet rsRepairs = null;

        try
        {
            strActionId = eCRDUtil.verifyNull(request.getParameter("hdnScreenAction"));
            objeCRDSearchBean = new eCRDSearchBean();
            strEngineModelCode = eCRDUtil.verifyNull(request.getParameter("txtEngModel"));
            strModuleCode = eCRDUtil.verifyNull(request.getParameter("txtModule"));
            strComponentCode = eCRDUtil.verifyNull(request.getParameter("txtComponent"));
            strRepairCode = eCRDUtil.verifyNull(request.getParameter("txtRepair"));
            strActionId = "eCRD_SEARCH_REPAIR";

            //arrlstOutParam = objeCRDSearchBean.searchRepair(strEngineModelCode, strModuleCode, strComponentCode,strRepairCode,strActionId);
            rsRepairs = (GEAEResultSet)arrlstOutParam.get(0);
            request.setAttribute("rsRepairs", rsRepairs);
        }
        finally
        {
            arrlstOutParam = null;
            strActionId = null;
        }

    }

}
