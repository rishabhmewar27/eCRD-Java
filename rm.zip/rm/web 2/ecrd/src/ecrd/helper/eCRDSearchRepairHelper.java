//Source file: D:\\ECRD\\SOURCE CODE\\ecrd\\helper\\eCRDMaintenanceHelper.java
/**
 * Module       : eCRDSearchRepairHelper.java
 * Author       : Patni Offshore
 * Project      : eCRD
 * Date Written : October 2004
 * Security     : Classified/Unclassified
 * Restrictions : GE PROPRIETORY INFORMATION, FOR GE USE ONLY
 *
 *     ***************************************************************
 *     *          Copyright (2000) with all rights reserved          *
 *     *                  General Electric Company                   *
 *     ***************************************************************
 * Description  :  This class has methods to get the Master Tables Data.
 * Revision Log  (mm/dd/yyyy     Initials    description)
 * -------------------------------------------------------------------
 * mm/dd/yyyy     Initials     Description
 * -------------------------------------------------------------------
 *
 */
package ecrd.helper;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import ecrd.biz.eCRDComponent;
import ecrd.biz.eCRDDefaultCatalog;
import ecrd.biz.eCRDEngineModel;
import ecrd.biz.eCRDModule;
import ecrd.biz.eCRDRepair;
import ecrd.common.eCRDCommand;
import ecrd.common.eCRDDBMediator;
import ecrd.common.eCRDDataBean;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDLoadMaster;
import ecrd.util.eCRDSearchBean;
import ecrd.util.eCRDUtil;
import geae.dao.GEAEResultSet;
import geae.util.format.GEAETagNoData;

public class eCRDSearchRepairHelper implements eCRDCommand
{
    private HttpServletRequest request = null;

    public eCRDSearchRepairHelper()
    {

    }

    /**
     * This method will identify the method to be invoked and also the subsequent
     * screen to be displayed depending on the functionality.
     * Also sets the received request to member variable.
     * @param request
     */
    public String perform(HttpServletRequest request) throws Exception
    {
        String strReturnURL = "";
        String strAction = "";
        String strEngineModel = "";
        //String strModuleDropDown="";
        String strMessage = "";
        GEAEResultSet rsEngineModule = null;
        GEAEResultSet rsRepairs = null;
        //HttpSession session = null;
        try
        {
            strAction = eCRDUtil.verifyNull(request.getParameter("hdnScreenAction"));

            //if((eCRDConstants.getActionId("eCRD_MODIFY_COMPONENT")).equals(strAction))
            if ("GetModuleForModel".equals(strAction))
            {

                strEngineModel = request.getParameter("lstEngineModel");
                if (strEngineModel != null)
                {
                    rsEngineModule = eCRDLoadMaster.getMasterModuleList(strEngineModel);
                    request.setAttribute("rsEngineModule", rsEngineModule);
                }
                strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-modifyRepair";
            }
            else if ("SearchRepair".equals(strAction))
            {
                eCRDUtil.clearSession(request);
                strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-modifyRepair";
            }
            else if ("eCRDFindComponent".equals(strAction))
            {
                getComponentCode(request);
                strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-listComponents";
            }
            else if ("eCRDFindRepair".equals(strAction))
            {
                getRepairCode(request);
                strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-findRepairs";
            }
            else if ("RepairDetails".equals(strAction))
            {
                rsRepairs = getRepairDetails(request);
                if ((rsRepairs == null) || (rsRepairs.size() == 0))
                {
                    strMessage = eCRDConstants.getMessage("NO_REPAIR_EXISTS");
                    request.setAttribute("Message", strMessage);
                    strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-modifyRepair";
                }
                else
                {
                    request.setAttribute("rsRepairs", rsRepairs);
                    eCRDUtil.loadInSession(request, "rsRepairs", rsRepairs);
                    strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-modifyRepairDetail";
                }
            }

        }
        finally
        {
        }
        return strReturnURL;
    }

    public void getComponentCode(HttpServletRequest request) throws Exception
    {
        HttpSession session = null;
        eCRDDataBean objeCRDDataBean = null;
        eCRDSearchBean objeCRDSearchBean = null;
        ArrayList arrLstOutParam = new ArrayList();

        String strScreenAction;
        String strEngineModel;
        String strEngineModule;
        String strComponentCode;
        String strComponent;
        try
        {
            objeCRDSearchBean = new eCRDSearchBean();
            strScreenAction = request.getParameter("hdnScreenAction");
            strEngineModel = request.getParameter("EngineModel");
            strEngineModule = request.getParameter("EngineModule");
            strComponent = request.getParameter("Component");
            strComponentCode = request.getParameter("ComponentCode");
			
	        if ("1".equals(strComponent))
            {
                strComponent = "Code";
            }
            else if ("2".equals(strComponent))
            {
                strComponent = "Description";
            }

            arrLstOutParam = objeCRDSearchBean.findComponentCode(strEngineModel, strEngineModule, strComponentCode, strComponent, strScreenAction);
            GEAEResultSet rsComponent = (GEAEResultSet)arrLstOutParam.get(0);
            rsComponent.setCurrentRow(0);
            rsComponent.next();
            session = request.getSession();
            objeCRDDataBean = new eCRDDataBean();
            session.setAttribute("objeCRDCompList", objeCRDDataBean);
            if (rsComponent.size() > 0)
            {
                rsComponent = formatComponent(rsComponent, request);
                if (rsComponent != null && rsComponent.size() > 0)
                {
                    rsComponent.setCurrentRow(0);
                    objeCRDDataBean.setCache(rsComponent);
                }

            }
            else
            {
                objeCRDDataBean.setCache(new GEAEResultSet());
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw e;
        }

    }

    private GEAEResultSet formatComponent(GEAEResultSet rsCompCodeList, HttpServletRequest request) throws Exception
    {
        GEAEResultSet rsFormatted = null;
        ArrayList arrlstFormat = null;
        GEAETagNoData tagRadio = null;
        String strRadioValue = null;
        String strTempTagName = null;
        String strComponent = "";

        try
        {
            strComponent = request.getParameter("Component");
            if (rsCompCodeList != null && rsCompCodeList.size() > 0)
            {
                rsFormatted = new GEAEResultSet();
                for (int i = 0; i < rsCompCodeList.size(); i++)
                {
                    arrlstFormat = new ArrayList();
                    strTempTagName = rsCompCodeList.getString(1);
                    strRadioValue = "" + eCRDUtil.replaceQuoteForJS(strTempTagName);
                    if ("1".equals(strComponent))
                    {
                        tagRadio =
                            new GEAETagNoData(
                                "<INPUT TYPE=\"radio\" NAME=\"radCatalog\" VALUE=\""
                                    + strRadioValue
                                    + "\" onClick = \"javascript:fnGetCompCodeInSearch('"
                                    + rsCompCodeList.getString(1)
                                    + "','"
                                    + rsCompCodeList.getString(1)
                                    + "')\"");
                    }
                    else if ("2".equals(strComponent))
                    {
                        tagRadio =
                            new GEAETagNoData(
                                "<INPUT TYPE=\"radio\" NAME=\"radCatalog\" VALUE=\""
                                    + strRadioValue
                                    + "\" onClick = \"javascript:fnGetCompCodeInSearch('"
                                    + rsCompCodeList.getString(2)
                                    + "','"
                                    + rsCompCodeList.getString(1)
                                    + "')\"");
                    }
                    request.setAttribute("CompCode", rsCompCodeList.getString(1));
                    arrlstFormat.add(tagRadio);
                    arrlstFormat.add(eCRDUtil.verifyNull(rsCompCodeList.getString(1)));

                    arrlstFormat.add(eCRDUtil.verifyNull(rsCompCodeList.getString(2)));
                    rsFormatted.addRow(arrlstFormat);
                    rsCompCodeList.next();
                }
                rsFormatted.setColumnHeading(1, "Select");
                rsFormatted.setColumnHeading(2, "Component Code");
                rsFormatted.setColumnHeading(3, "Component Description");

            }
            return rsFormatted;
        }
        finally
        {
            arrlstFormat = null;
        }

    }

    public void getRepairCode(HttpServletRequest request) throws Exception
    {
        HttpSession session = null;
        eCRDDataBean objeCRDDataBean = null;
        eCRDSearchBean objeCRDSearchBean = null;
        ArrayList arrLstOutParam = new ArrayList();

        String strScreenAction;
        String strEngineModel;
        String strEngineModule;
        String strComponentCode;
        String strComponent;
        String strRepairCode;
        String strRepair;
        
        String strRepairInd; //changes by rishabh mewar
        
        try
        {
            objeCRDSearchBean = new eCRDSearchBean();
            strScreenAction = request.getParameter("hdnScreenAction");
            strEngineModel = request.getParameter("EngineModel");
            strEngineModule = request.getParameter("EngineModule");
            strComponent = request.getParameter("Component");
            strComponentCode = request.getParameter("ComponentCode");
            strRepair = request.getParameter("Repair");
            strRepairCode = request.getParameter("RepairCode");
            
          //  strRepairInd = request.getParameter("RepairInd"); //changes by rishabh mewar
            
            if ("1".equals(strComponent))
            {
                strComponent = "Code";
            }
            else if ("2".equals(strComponent))
            {
                strComponent = "Description";
            }
            if ("1".equals(strRepair))
            {
                strRepair = "Code";
            }
            else if ("2".equals(strRepair))
            {
                strRepair = "Description";
            }
            												//changes by rishabh mewar
            arrLstOutParam = objeCRDSearchBean.findRepairCode(strEngineModel, strEngineModule, strComponentCode, strComponent, strRepairCode, strRepair, strScreenAction);

            GEAEResultSet rsRepair = (GEAEResultSet)arrLstOutParam.get(0);
            rsRepair.setCurrentRow(0);
            rsRepair.next();
            strRepairCode = rsRepair.getString(1);
            eCRDUtil.loadInSession(request, "strRepairCode", strRepairCode);

            session = request.getSession();
            objeCRDDataBean = new eCRDDataBean();
            session.setAttribute("objeCRDRepairList", objeCRDDataBean);
            if (rsRepair.size() > 0)
            {
                rsRepair = formatRepair(rsRepair, request);
                if (rsRepair != null && rsRepair.size() > 0)
                {
                    rsRepair.setCurrentRow(0);
                    objeCRDDataBean.setCache(rsRepair);
                }
            }
            else
            {
                objeCRDDataBean.setCache(new GEAEResultSet());
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw e;
        }

    }

    private GEAEResultSet formatRepair(GEAEResultSet rsRepairCodeList, HttpServletRequest request) throws Exception
    {
        GEAEResultSet rsFormatted = null;
        ArrayList arrlstFormat = null;
        GEAETagNoData tagRadio = null;
        String strRadioValue = null;
        String strTempTagName = null;
        String strRepair = "";

        try
        {
            strRepair = request.getParameter("Repair");
            if (rsRepairCodeList != null && rsRepairCodeList.size() > 0)
            {
                rsFormatted = new GEAEResultSet();
                for (int i = 0; i < rsRepairCodeList.size(); i++)
                {
                    arrlstFormat = new ArrayList();
                    strTempTagName = rsRepairCodeList.getString(1);
                    strRadioValue = "" + eCRDUtil.replaceQuoteForJS(strTempTagName);
                    if ("1".equals(strRepair))
                    {
                        //tagRadio = new GEAETagNoData("<INPUT TYPE=\"radio\" NAME=\"radCatalog\" VALUE=\"" + strRadioValue + "\" onClick = \"javascript:fnGetRepairCodeInSearch('"+rsRepairCodeList.getString("rep_display_seq_id")+"','"+rsRepairCodeList.getString("rep_type")+"')\"");
                        tagRadio =
                            new GEAETagNoData(
                                "<INPUT TYPE=\"radio\" NAME=\"radCatalog\" VALUE=\""
                                    + strRadioValue
                                    + "\" onClick = \"javascript:fnGetRepairCodeInSearch('"
                                    + rsRepairCodeList.getString("rep_display_seq_id")
                                    + "')\"");
                    }
                    else if ("2".equals(strRepair))
                    {
                        //tagRadio = new GEAETagNoData("<INPUT TYPE=\"radio\" NAME=\"radCatalog\" VALUE=\"" + strRadioValue + "\" onClick = \"javascript:fnGetRepairCodeInSearch('"+rsRepairCodeList.getString("rep_description")+"','"+rsRepairCodeList.getString("rep_type")+"')\"");
                        tagRadio =
                            new GEAETagNoData(
                                "<INPUT TYPE=\"radio\" NAME=\"radCatalog\" VALUE=\""
                                    + strRadioValue
                                    + "\" onClick = \"javascript:fnGetRepairCodeInSearch('"
                                    + rsRepairCodeList.getString("rep_description")
                                    + "')\"");
                    }
                    request.setAttribute("CompCode", rsRepairCodeList.getString("rep_display_seq_id"));
                    arrlstFormat.add(tagRadio);
                    arrlstFormat.add(eCRDUtil.verifyNull(rsRepairCodeList.getString("rep_display_seq_id")));
                    arrlstFormat.add(eCRDUtil.verifyNull(rsRepairCodeList.getString("rep_description")));
                    rsFormatted.addRow(arrlstFormat);
                    rsRepairCodeList.next();
                }
                rsFormatted.setColumnHeading(1, "Select");
                rsFormatted.setColumnHeading(2, "Repair Display Sequence");
                rsFormatted.setColumnHeading(3, "Repair Description");

            }
            return rsFormatted;
        }
        finally
        {
            arrlstFormat = null;
        }
    }
    public GEAEResultSet getRepairDetails(HttpServletRequest request) throws Exception
    {
        eCRDDefaultCatalog objeCRDDefaultCatalog = null;
        eCRDEngineModel objeCRDEngineModel = null;
        eCRDModule objeCRDModule = null;
        eCRDComponent objeCRDComponent = null;
        eCRDRepair objCRDRepair = null;

        ArrayList arrLstInParam = new ArrayList();
        ArrayList arrLstOutParam = new ArrayList();

        String strEngineModel = "";
        String strEngineModule = "";
        String strComponent = "";
        String strComponentValue = "";
        String strRepair = "";
        String strRepairValue = "";
        String strComponentCode = "";
        //String strRepairType  = "";
        String strScreenAction = "";
        
        String strRepairInd = "" ;  //changes by rishabh mewar
        
        try
        {
            strEngineModel = eCRDUtil.verifyNull(request.getParameter("hdnEngineModel"));
            strEngineModule = eCRDUtil.verifyNull(request.getParameter("hdnModule"));
            strComponent = eCRDUtil.verifyNull(request.getParameter("hdnComponentDropdown"));
            strComponentValue = eCRDUtil.verifyNull(request.getParameter("txtComponent"));
            strRepair = eCRDUtil.verifyNull(request.getParameter("hdnRepairDropdown"));
            strRepairValue = eCRDUtil.verifyNull(request.getParameter("txtRepair"));
            strComponentCode = eCRDUtil.verifyNull(request.getParameter("hdnComponentCode"));
			
            strRepairInd = eCRDUtil.verifyNull(request.getParameter("hdnRepairInd")); //changes bby rishabh mewar

            objeCRDDefaultCatalog = new eCRDDefaultCatalog(strEngineModel,eCRDConstants.STRENGMODELCONST);//Changed the constructor called to get loaded catalog object 
            objeCRDDefaultCatalog.setCatalogType(eCRDConstants.STRDEFAULTCATALOGTYPE);
            objeCRDEngineModel = new eCRDEngineModel(strEngineModel);
            objeCRDModule = objeCRDEngineModel.getModule(strEngineModule);
            objeCRDComponent = objeCRDModule.getComponent(strComponentValue);
            //	objCRDRepair		  = objeCRDComponent.getRepair(strRepair,strRepairType);
		
            if ("2".equals(strComponent))
            {
                eCRDUtil.loadInSession(request, eCRDConstants.STRCOMPONENTCODE, strComponentCode.toUpperCase());

            }
            else
            {
                eCRDUtil.loadInSession(request, eCRDConstants.STRCOMPONENTCODE, strComponentValue.toUpperCase());
            }
            objeCRDDefaultCatalog.setEngineModel(objeCRDEngineModel);
            objeCRDEngineModel.setCatalog(objeCRDDefaultCatalog);
            
            eCRDUtil.loadInSession(request, eCRDConstants.STRCATALOG, objeCRDDefaultCatalog);
            eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODELCODE, strEngineModel);
            eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODULECODE, strEngineModule);

            //eCRDUtil.loadInSession(request, "strComponentType", strComponent);
            eCRDUtil.loadInSession(request, "strFrom", "Modify");

            //strScreenAction = request.getParameter("hdnScreenAction");
            strScreenAction = "eCRDSearchRepair";
            arrLstInParam.add(strEngineModel);
            arrLstInParam.add(strEngineModule);
            arrLstInParam.add(strComponent);
            arrLstInParam.add(strComponentValue);
            arrLstInParam.add(strRepair);
            arrLstInParam.add(strRepairValue);
            
            arrLstInParam.add(strRepairInd); //changes by rishabh mewar
            
            arrLstOutParam = eCRDDBMediator.doDBOperation(strScreenAction, arrLstInParam);
            GEAEResultSet rsRepair = (GEAEResultSet)arrLstOutParam.get(0);
            eCRDUtil.loadInSession(request, "strFrom", "Modify");

            return rsRepair;
        }
        finally
        {
        }

    }

}
