//Source file: D:\\ECRD\\SOURCE CODE\\ecrd\\helper\\eCRDMaintenanceHelper.java
/**
 * Module       : eCRDViewRepairsHelper.java
 * Author       : Patni Offshore
 * Project      : eCRD
 * Date Written : October 2004
 * Security     : Classified/Unclassified
 * Restrictions : GE PROPRIETORY INFORMATION, FOR GE USE ONLY
 *
 *     ***************************************************************
 *     *          Copyright (2000) with all rights reserved          *
 *     *                  General Electric Company                   *
 *     ***************************************************************
 * Description  :  This class has methods to get the Master Tables Data.
 * Revision Log  (mm/dd/yyyy     Initials    description)
 * -------------------------------------------------------------------
 * mm/dd/yyyy     Initials     Description
 * -------------------------------------------------------------------
 *
 */
package ecrd.helper;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import ecrd.biz.eCRDCatalog;
import ecrd.biz.eCRDEngineModel;
import ecrd.biz.eCRDUser;
import ecrd.common.eCRDCommand;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDSearchBean;
import ecrd.util.eCRDUtil;
import geae.dao.GEAEResultSet;

public class eCRDViewRepairsHelper implements eCRDCommand
{
    private HttpServletRequest request = null;

    public eCRDViewRepairsHelper()
    {

    }

    /**
     * This method will identify the method to be invoked and also the subsequent
     * screen to be displayed depending on the functionality.
     * Also sets the received request to member variable.
     * @param request
     */
    public String perform(HttpServletRequest request) throws Exception
    {
        String strReturnURL = "";
        String strScreenAction = "";
        try
        {
            strScreenAction = eCRDUtil.verifyNull(request.getParameter("hdnScreenAction"));

            if ("ViewRepairs".equals(strScreenAction))
            {
                //return "/eCRD/jsp/eCRDViewRepairsHelper.jsp";
                getRepairList(request);
                strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-modifyRepairDetail";
            }
            if ("ViewRepair".equals(strScreenAction))
            {
                //return "/eCRD/jsp/eCRDViewRepairsHelper.jsp";
                getRepairList(request);
                strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-listRepairs";
            }
            else /*this is on click of the tab link view repairs */
                if ((eCRDConstants.getActionId("eCRD_VIEW_SPECIAL_REPAIR")).equals(strScreenAction))
                {
                    //return "/eCRD/jsp/eCRDViewRepairsHelper.jsp";
                    //getRepairList(request);
					setSpecialNewRepairInRequest(request);
                    eCRDUtil.loadInSession(request, "strFrom", "specialRepair");
                    strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-viewRepairs";
                }
                else /*this is on click of the tab link add repairs in the special repair tab*/
                    if ("AddRepairs".equals(strScreenAction))
                    {
                        strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-specialRepair";
                    }
        }
        finally
        {
        }
        return strReturnURL;
    }

    /**
     *
     * gets the list of repairs for the selected component
     */
    private void getRepairList(HttpServletRequest request) throws Exception
    {

        //   eCRDUser objeCRDUser = null;
        ArrayList arrlstOutParam = null;
        String strActionId = null;
        eCRDSearchBean objeCRDSearchBean = null;
        String strEngineModelCode = null;
        String strModuleCode = null;
        String strComponentCode = null;
        //String strRepairCode = null;
        String strComponentType = null;
        //String strRepairType = null;
        GEAEResultSet rsRepairs = null;
        eCRDCatalog objeCRDCatalog = null;
        eCRDEngineModel objeCRDEngineModel = null;
        String strCatalogSeqId = "";
		eCRDUser objeCRDUser = null;

        try
        {
            strActionId = eCRDUtil.verifyNull(request.getParameter("hdnScreenAction"));
			objeCRDUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser");
            objeCRDCatalog = (eCRDCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
            if (objeCRDCatalog != null)
            {
                strCatalogSeqId = eCRDUtil.verifyNull(objeCRDCatalog.getCatalogSeqId());
                objeCRDEngineModel = objeCRDCatalog.getEngineModel();
                strEngineModelCode = objeCRDEngineModel.getEngineModelCode();
            }

            objeCRDSearchBean = new eCRDSearchBean();

            strModuleCode = eCRDUtil.verifyNull(request.getParameter("selEngineModule"));
            strComponentCode = eCRDUtil.verifyNull(request.getParameter("selComponent"));

            if ("".equals(strModuleCode))
            {
                strModuleCode = (String)eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE);
            }
            if ("".equals(strComponentCode))
            {
                strComponentCode = (String)eCRDUtil.getFromSession(request, eCRDConstants.STRCOMPONENTCODE);
            }
            eCRDUtil.loadInSession(request, eCRDConstants.STRENGINEMODULECODE, strModuleCode);
            eCRDUtil.loadInSession(request, eCRDConstants.STRCOMPONENTCODE, strComponentCode);
            //strRepairType = eCRDUtil.verifyNull(request.getParameter("hdnRepairDropdown"));
            //strRepairCode = eCRDUtil.verifyNull(request.getParameter("txtRepair"));

            strActionId = eCRDConstants.getActionId("eCRD_REPAIR_LISTING");
            arrlstOutParam = objeCRDSearchBean.getRepairListing(strCatalogSeqId, strEngineModelCode, strModuleCode, "1", strComponentCode, strActionId,eCRDUtil.verifyNull(objeCRDUser.getRole()));

            rsRepairs = (GEAEResultSet)arrlstOutParam.get(0);
            request.setAttribute("rsRepairs", rsRepairs);
        }
        finally
        {
            arrlstOutParam = null;
            strActionId = null;
            objeCRDSearchBean = null;
            strEngineModelCode = null;
            strModuleCode = null;
            strComponentCode = null;
            //strRepairCode = null;
            strComponentType = null;
            //strRepairType = null;
            rsRepairs = null;
            objeCRDCatalog = null;
            strCatalogSeqId = null;
        }
    }
		private void setSpecialNewRepairInRequest(HttpServletRequest request) throws Exception
		{

			String strEngineModel = "";
			String strEngineModule = "";
			String strComponentCode = "";
			String strCompType = "";
			String strAction = "";
			String strCatalogId = "";
			eCRDCatalog objeCRDCatalog = null;
			eCRDSearchBean objeCRDSearchBean = null;
			ArrayList arrlstOutParam = null;
			GEAEResultSet rsRepairs = null;
			eCRDUser objeCRDUser = null;
			
			try
			{
				objeCRDSearchBean = new eCRDSearchBean();
				objeCRDUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser");
				rsRepairs = new GEAEResultSet();
				objeCRDCatalog = (eCRDCatalog)eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
	

				strEngineModel = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODELCODE));
	
				strCatalogId = eCRDUtil.verifyNull(objeCRDCatalog.getCatalogSeqId());
	
				if("".equals(strEngineModel))
				{
					strEngineModel = objeCRDCatalog.getEngineModel().getEngineModelCode(); 
				}

				strEngineModule = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRENGINEMODULECODE));
				strComponentCode = eCRDUtil.verifyNull((String) eCRDUtil.getFromSession(request, eCRDConstants.STRCOMPONENTCODE));
				strCompType = "1";
				strAction = eCRDUtil.verifyNull(eCRDConstants.getActionId("eCRD_SPECIAL_REPAIR_LISTING"));

				/*passin null as catalog seq id so that default catalog will be considered by the plsql procedure*/
				arrlstOutParam = objeCRDSearchBean.getRepairListing(strCatalogId, strEngineModel, strEngineModule, strCompType, strComponentCode, strAction,eCRDUtil.verifyNull(objeCRDUser.getRole()));
				rsRepairs = (GEAEResultSet) arrlstOutParam.get(0);
				request.setAttribute("rsRepairs", rsRepairs);
			}
			finally
			{
				strEngineModel= null;
				strEngineModule = null;
				strComponentCode = null;
				strCompType = null;
				strAction = null;
				objeCRDSearchBean = null;
				arrlstOutParam = null;
				rsRepairs = null;
			}
		}
    
}
