/**
 * Copyright (C) 2011 General Electric Company
 * All rights reserved
 */
package ecrd.pricing.bo;

 import ecrd.pricing.dao.ECRDAddEditScenarioDAO;
 import ecrd.pricing.form.ECRDAddEditScenarioForm;
 import geae.dao.GEAEResultSet;
 import ecrd.biz.*;
 import geae.office.spreadsheet.excel.*;
 import geae.office.spreadsheet.*;
/**
 *
 * @author NGTAPXS
 *
 */
public class ECRDAddEditScenarioBo {

	private ECRDAddEditScenarioDAO addEditScenario = new ECRDAddEditScenarioDAO();

	 public void getDefaultValues(final ECRDAddEditScenarioForm form) throws Exception {
		this.addEditScenario.getDefaultValues(form);
	}

	/**
	 * To get all scenario level data, without performing calculation
	 * @param form
	 * @throws Exception
	 */
	public void getScenarionValues(final ECRDAddEditScenarioForm form) throws Exception {
		this.addEditScenario.getScenarionValues(form);
	}

	public void createScenario(final ECRDAddEditScenarioForm form) throws Exception {

		this.addEditScenario.createScenario(form);
	}

	public void reCalculateScenario(final ECRDAddEditScenarioForm form) throws Exception {
		this.addEditScenario.reCalculateScenario(form);
	}

	/**
	 * To delete a scenario
	 * @param form
	 * @throws Exception
	 */
	public void deleteScenario(final ECRDAddEditScenarioForm form) throws Exception {
		this.addEditScenario.deleteScenario(form);
	}

	/**
	 * To finalize a scenario
	 * @param form
	 * @throws Exception
	 */
	public GEAEExcelWorkbook finalizeScenario(final ECRDAddEditScenarioForm form,String futureEffectiveDate) throws Exception {
		GEAEResultSet rsCatalogueDetails=this.addEditScenario.finalizeScenario(form);
	    eCRDBatchDownload objECRDBatchDownLoad = new eCRDBatchDownload();
		GEAEExcelWorkbook workBook;
		workBook = objECRDBatchDownLoad.generateFlatFileXLSSheet(rsCatalogueDetails,futureEffectiveDate,form.getDefaultCatalog());
		return workBook;
	}
	/**
	 * To finalize a scenario
	 * @param form
	 * @throws Exception
	 */
	public void applyToRepair(final ECRDAddEditScenarioForm form, final String repairSeqId, final String manualOverrideEsc) throws Exception {
		this.addEditScenario.applyToRepair(form, repairSeqId, manualOverrideEsc);
	}

}