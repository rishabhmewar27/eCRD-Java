/**
 * Copyright (C) 2011 General Electric Company
 * All rights reserved
 */
package ecrd.pricing.bo;

import ecrd.pricing.dao.ECRDAddProjectDAO;
import ecrd.pricing.form.ECRDAddProjectForm;
/**
 * 
 */
public class ECRDAddProjectBo
{
	ECRDAddProjectDAO addDAO = new ECRDAddProjectDAO();
	public void getProjectList(final ECRDAddProjectForm form) throws Exception
	{
		addDAO.getProjectList(form);
		
	}
	public void getCatalogList(final ECRDAddProjectForm form) throws Exception
	{
		addDAO.getCatalogList(form);
	}
	
	
	public void addProjectBo(final ECRDAddProjectForm form) throws Exception
	{
		addDAO.addProjectDAO(form);
		
		if(form.isProjectExists())
		form.setProjectExists(false);
		String startDate = form.getMeteroStartDate();
		String []startDateArray = startDate.split("/");
		form.setStrStartDay(startDateArray[0]);
		form.setStrStartMonth(startDateArray[1]);
		form.setStrStartYear(startDateArray[2]);
		
		String endDate = form.getMeteroEndDate();
		String []endDateArray = endDate.split("/");
		form.setStrEndDay(endDateArray[0]);
		form.setStrEndMonth(endDateArray[1]);
		form.setStrEndYear(endDateArray[2]);
	}
	
	
	public void fetchProjectDetailsBo(final ECRDAddProjectForm form) throws Exception
	{
		addDAO.fetchProjectDetails(form);
		String startDate = form.getMeteroStartDate();
		String []startDateArray = startDate.split("-");
		form.setStrStartDay(startDateArray[0]);
		form.setStrStartMonth(startDateArray[1]);
		form.setStrStartYear(startDateArray[2]);
		
		String endDate = form.getMeteroEndDate();
		String []endDateArray = endDate.split("-");
		form.setStrEndDay(endDateArray[0]);
		form.setStrEndMonth(endDateArray[1]);
		form.setStrEndYear(endDateArray[2]);
	}
	
}