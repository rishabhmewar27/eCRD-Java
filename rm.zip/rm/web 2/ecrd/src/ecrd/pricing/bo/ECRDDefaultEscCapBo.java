/**
 * Copyright (C) 2011 General Electric Company
 * All rights reserved
 */

package ecrd.pricing.bo;



import ecrd.pricing.dao.ECRDDefaultEscCapDAO;
import ecrd.pricing.form.ECRDDefaultEscCapForm;




/**
 * 
 * @author NGTAPXS
 *
 */

public class ECRDDefaultEscCapBo {

	

	
	ECRDDefaultEscCapDAO escDAO = new ECRDDefaultEscCapDAO();
	
	
	
	
	public void getEscCapBo(final ECRDDefaultEscCapForm form) throws Exception
	{
		
		escDAO.getCustomerList(form);
		
		

		
	}
	
	public void updateEscCapBo(final ECRDDefaultEscCapForm form) throws Exception
	{

		escDAO.updateCustomerMaster(form);
		
		

		
	}
	
	public void getEngineModelsBo(final ECRDDefaultEscCapForm form) throws Exception
	{

		escDAO.getEngineModels(form);
		
		
		
		
	}
	
	public void getEscalationCapBo(final ECRDDefaultEscCapForm form) throws Exception
	{
		
		escDAO.getEscalatioCap(form);
		
		
		
		
	}
	
	
}


