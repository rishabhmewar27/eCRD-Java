/**
 * Copyright (C) 2011 General Electric Company
 * All rights reserved
 */
package ecrd.pricing.bo;

import ecrd.pricing.dao.ECRDDefaultPricingAllEngineDAO;
import ecrd.pricing.form.ECRDDefaultPricingAllEngineForm;

/**
 * 
 * @author NGTAPXS
 *
 */
public class ECRDDefaultPricingAllEngineBo {

	ECRDDefaultPricingAllEngineDAO engineLineDAO = new ECRDDefaultPricingAllEngineDAO();

	public void getDefualtPricingAllEngine(final ECRDDefaultPricingAllEngineForm form) throws Exception {
		engineLineDAO.getDefaultPriceForAllEngine(form);

	}
	
	public void saveDefualtPricingAllEngine(final ECRDDefaultPricingAllEngineForm form) throws Exception {
		engineLineDAO.saveDefaultPriceForAllEngine(form);

	}

}