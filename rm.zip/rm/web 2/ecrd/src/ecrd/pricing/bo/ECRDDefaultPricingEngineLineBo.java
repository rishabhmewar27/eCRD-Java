/**
 * Copyright (C) 2011 General Electric Company
 * All rights reserved
 */
package ecrd.pricing.bo;

import ecrd.pricing.dao.ECRDDefaultPricingEngineLineDAO;
import ecrd.pricing.form.ECRDDefaultPricingEngineLineForm;
/**
 * 
 * @author NGTAPXS
 *
 */
public class ECRDDefaultPricingEngineLineBo {

	private ECRDDefaultPricingEngineLineDAO engineLineDAO = new ECRDDefaultPricingEngineLineDAO();

	/**
	 * To select list of engine lines
	 * @param form
	 * @throws Exception
	 */
	public void getEngineLine(ECRDDefaultPricingEngineLineForm form) throws Exception {
		engineLineDAO.getEngineLine(form);
	}
	
	/**
	 * Method to load data from db for a given engine line.
	 * @param form
	 * @throws Exception
	 */
	public void getDefualtPricingEngineLine(ECRDDefaultPricingEngineLineForm form) throws Exception {
		if ("selected".equalsIgnoreCase(form.getEngineLine())) {
			form.clear();
		} else {
			engineLineDAO.getDefaultEngLineValues(form);
		}
	}

	/**
	 * Method to save data in db for a given engine line.
	 * @param form
	 * @throws Exception
	 */
	public void saveDefaultEngLineValues(final ECRDDefaultPricingEngineLineForm form) throws Exception {
		engineLineDAO.saveDefaultEngLineValues(form);
	}
}