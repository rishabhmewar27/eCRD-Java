/**
 * Copyright (C) 2011 General Electric Company
 * All rights reserved
 */
package ecrd.pricing.bo;
import org.apache.log4j.Logger;

import ecrd.pricing.dao.ECRDEditProjectDAO;
import ecrd.pricing.form.ECRDEditProjectForm;

/**
 * 
 * @author NGTAPXS
 *
 */

public class ECRDEditProjectBo 
{
	private static final Logger LOGGER = Logger.getLogger("ECRDEditProjectBo.class");
	ECRDEditProjectDAO editProject = new ECRDEditProjectDAO();
	//ECRDAddProjectBo probjectBo = new ECRDAddProjectBo();
	public void editExistingProject(ECRDEditProjectForm formNew)  throws Exception
	{
		try
		{
		
		editProject.getProjectList(formNew);
		
		}
		catch(Exception exp)
		{
			LOGGER.info(" Exception Occured " + exp.getMessage());
		}
		
		
	}
	public void fetchProjectDetailsBo(ECRDEditProjectForm form)  throws Exception
	{
		try
		{
		
		editProject.fetchProjectDetails(form);
		String startDate = form.getMeteroStartDate();
		String []startDateArray = startDate.split("-");
		form.setStrStartDay(startDateArray[0]);
		form.setStrStartMonth(startDateArray[1]);
		form.setStrStartYear(startDateArray[2]);
		
		String endDate = form.getMeteroEndDate();
		String []endDateArray = endDate.split("-");
		form.setStrEndDay(endDateArray[0]);
		form.setStrEndMonth(endDateArray[1]);
		form.setStrEndYear(endDateArray[2]);
		
		}
		catch(Exception exp)
		{
			LOGGER.info(" Exception Occured " + exp.getMessage());
		}
	}
	
	public void editProjectBo(final ECRDEditProjectForm form) throws Exception
	{
		editProject.editProjectDAO(form);
		String startDate = form.getMeteroStartDate();
		String []startDateArray = startDate.split("/");
		form.setStrStartDay(startDateArray[0]);
		form.setStrStartMonth(startDateArray[1]);
		form.setStrStartYear(startDateArray[2]);
		
		String endDate = form.getMeteroEndDate();
		String []endDateArray = endDate.split("/");
		form.setStrEndDay(endDateArray[0]);
		form.setStrEndMonth(endDateArray[1]);
		form.setStrEndYear(endDateArray[2]);
	}
	
	public void deleteExistingProject(ECRDEditProjectForm form)  throws Exception
	{
		try
		{
		editProject.deleteExistingProject(form);
		}
		catch(Exception exp)
		{
			LOGGER.info(" Exception Occured " + exp.getMessage());
		}
	}
	public void addProjectBo(final ECRDEditProjectForm form) throws Exception
	{
		editProject.addProjectDAO(form);
		
		if(form.isProjectExists()){
		form.setProjectExists(false);
		}
		String startDate = form.getMeteroStartDate();
		String []startDateArray = startDate.split("/");
		form.setStrStartDay(startDateArray[0]);
		form.setStrStartMonth(startDateArray[1]);
		form.setStrStartYear(startDateArray[2]);
		
		String endDate = form.getMeteroEndDate();
		String []endDateArray = endDate.split("/");
		form.setStrEndDay(endDateArray[0]);
		form.setStrEndMonth(endDateArray[1]);
		form.setStrEndYear(endDateArray[2]);
	}
}