/**
 * Copyright (C) 2011 General Electric Company
 * All rights reserved
 */
package ecrd.pricing.bo;

import ecrd.pricing.dao.ECRDRepairDetailsDAO;
import ecrd.pricing.form.ECRDRepairDetailsForm;
/**
 * 
 * @author NGTAPXS
 *
 */
public class ECRDRepairDetailsBo {

	private ECRDRepairDetailsDAO dao = new ECRDRepairDetailsDAO();

	/**
	 * To get the repair details 
	 * @param form the ECRDRepairDetailsForm to set
	 * @throws Exception
	 */
	public void getRepairDetails(final ECRDRepairDetailsForm form) throws Exception {
		dao.getRepairDetails(form);
	}
	
	/**
	 * To save the manual override price 
	 * @param form the ECRDRepairDetailsForm to set
	 * @throws Exception
	 */
	public void saveRepairDetails(final ECRDRepairDetailsForm form) throws Exception {
		dao.saveRepairDetails(form);
	}
	
	/**
	 * To apply changes to repair 
	 * @param form the ECRDRepairDetailsForm to set
	 * @throws Exception
	 */
}
