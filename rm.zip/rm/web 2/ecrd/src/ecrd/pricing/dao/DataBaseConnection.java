/**
 * Copyright (C) 2011 General Electric Company
 * All rights reserved
 */
package ecrd.pricing.dao;
 

/**
 * 
 * @author NGTAPXS
 *
 */
public class DataBaseConnection
{
 /*
  * 
  * SQDB
  */
 
}
