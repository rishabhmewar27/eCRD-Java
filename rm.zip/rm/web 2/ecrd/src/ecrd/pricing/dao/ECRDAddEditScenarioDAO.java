/**
 * Copyright (C) 2011 General Electric Company
 * All rights reserved
 */
package ecrd.pricing.dao;

import java.util.ArrayList;
import ecrd.common.eCRDDBMediator;
import ecrd.common.ECRDPricingCommon;
import ecrd.pricing.form.ECRDAddEditScenarioForm;
import ecrd.util.eCRDUtil;
import geae.dao.GEAEResultSet;

/**
 *
 * @author NGTAPXS
 *
 */
public class ECRDAddEditScenarioDAO extends ECRDPricingCommon {
	//private static final Logger LOGGER = Logger.getLogger("ECRDAddEditScenarioDAO.class");
	/**
	 * To fetch win matrix data only.
	 */
	private static final String GET_DEFAULT_PROC_ACTN = "eCRDPricingScenarionDataActn";

	/**
	 * To fetch all data from db tables without invoking calculation
	 */
	private static final String GET_SCENARIO_PROC_ACTN = "eCRDPricingGetScenarionAllDataActn";

	/**
	 * To check scenario name.
	 */
	private static final String CHK_SCENARIO_NM_PROC_ACTN = "eCRDPricingChkScenarionNameActn";

	/**
	 * To create a new scenario, save values and recalculate
	 */
	private static final String CRT_SAVE_N_RECALC_PROC_ACTN = "eCRDPricingScenarionSaveActn";

	/**
	 * To save and recalculated an existing scenario
	 */
	private static final String SAVE_N_RECALC_PROC_ACTN = "eCRDPricingScenarionUpdateActn";

	/**
	 * To delete scenario
	 */
	private static final String DEL_SCENARIO_PROC_ACTN = "eCRDPricingScenarionDeleteActn";

	/**
	 * To finalize scenario
	 */
	private static final String FNLZ_SCENARIO_PROC_ACTN = "eCRDPricingScenarionFinalizeActn";



	public void resize() {

	}

	/**
	 * To fetch win matrix data only.
	 * This method is called only in case of new scenario being created.
	 * Procedure fetches default data based on the 'engine line default' or 'all engine default' values.
	 * @param form
	 * @throws Exception
	 */
	public void getDefaultValues(final ECRDAddEditScenarioForm form) throws Exception {
		ArrayList arrlstInParam = new ArrayList();

		arrlstInParam.add(form.getProjectId().toString());

		ArrayList arrlstOutParam = eCRDDBMediator.doDBOperation(GET_DEFAULT_PROC_ACTN, arrlstInParam);
		GEAEResultSet rs = (GEAEResultSet) arrlstOutParam.get(0);
		form.populateFromDB(rs);
		form.setDefaultEscChkd(false);

	}

	/**
	 * To get all scenario level data, without performing calculation
	 * @param form
	 * @throws Exception
	 */
	public void getScenarionValues(final ECRDAddEditScenarioForm form) throws Exception {
		ArrayList arrlstInParam = new ArrayList();

		arrlstInParam.add(form.getProjectId().toString());
		arrlstInParam.add(form.getScenarioId().toString());

		ArrayList arrlstOutParam = eCRDDBMediator.doDBOperation(GET_SCENARIO_PROC_ACTN, arrlstInParam);
		GEAEResultSet rs = (GEAEResultSet) arrlstOutParam.get(0);
		form.populateFromDB(rs);
		form.populateAllFromDB(rs);

		String finalizeInd = eCRDUtil.verifyNull(rs.getString("p_finalized_ind"));
		String defaultFlag = eCRDUtil.verifyNull(rs.getString("P_Default_Flag_in"));
		form.setFinalized("Y".equalsIgnoreCase(finalizeInd));
		form.setSaudiDiscount(eCRDUtil.verifyDoubleObj(rs.getString("p_saudi_discount")));
		if(defaultFlag!=null && defaultFlag.equalsIgnoreCase("Y"))
		{
			form.setDefaultEscChkd(true);
		}
		else if(defaultFlag!=null && defaultFlag.equalsIgnoreCase("N"))
		{
			form.setDefaultEscChkd(false);
		}

	}

	/**
	 * To check if the provided scenario name exists in database.
	 * If status comes as -1 then scenario exist,
	 * if status comes as 0 then scenario does not exist.
	 *
	 * @param projectId the project id
	 * @param ScenarioName the scenario id
	 * @return true if scenario exists
	 * @throws Exception
	 */
	public boolean isScenarioNameExists(final String projectId, final String scenarioName) throws Exception {
		ArrayList arrlstInParam = new ArrayList();

		arrlstInParam.add(projectId);
		arrlstInParam.add(scenarioName);

		ArrayList arrlstOutParam = eCRDDBMediator.doDBOperation(CHK_SCENARIO_NM_PROC_ACTN, arrlstInParam);
		String status = arrlstOutParam.get(0).toString();

		// if status is -1 the scenario name exists in database
		return "-1".equals(status);//p_status_out
	}

	/**
	 * To create a new scenario and get the new calculated values.
	 * @param form
	 * @throws Exception
	 */
	public void createScenario(final ECRDAddEditScenarioForm form) throws Exception {
		ArrayList arrlstInParam = new ArrayList();
		if(isScenarioNameExists(form.getProjectId().toString(), form.getScenarioName())) {

			form.setMessage("<font color=\"red\" CLASS=\"error\"><b>" +
					"<i>Scenario name exists. Please provide " +
					"some other name to scenario.</i></b></font>");

			return;
		}

		String scenarioId = "";

		arrlstInParam.add(form.getProjectId().toString());
		arrlstInParam.add(scenarioId);// Scenario Id as blank for 1st time
		arrlstInParam.add(form.getScenarioName().toString());



		if (form.isDefaultEscChkd()) {
			// if true then only default escalation will be applicable so setting
			// all win rate values to defaultEscalation in order to ease calculation
			arrlstInParam.add(form.getDefaultEscalation().toString());
			arrlstInParam.add(form.getDefaultEscalation().toString());
			arrlstInParam.add(form.getDefaultEscalation().toString());
			arrlstInParam.add(form.getDefaultEscalation().toString());
			arrlstInParam.add(form.getDefaultEscalation().toString());
			arrlstInParam.add(form.getDefaultEscalation().toString());
			arrlstInParam.add(form.getDefaultEscalation().toString());
			arrlstInParam.add(form.getLowWinPercentage() == null ? "0" : form.getLowWinPercentage().toString());
			arrlstInParam.add(form.getSaudiDiscount() == null ? "" : form.getSaudiDiscount().toString());
			arrlstInParam.add("Y");

		} else {
			arrlstInParam.add(form.getDefaultEscalation() == null ? "0" : form.getDefaultEscalation().toString());
			arrlstInParam.add(form.getWinHighHigh().toString());
			arrlstInParam.add(form.getWinHighMed().toString());
			arrlstInParam.add(form.getWinHighLow().toString());
			arrlstInParam.add(form.getWinLowHigh().toString());
			arrlstInParam.add(form.getWinLowMed().toString());
			arrlstInParam.add(form.getWinLowLow().toString());
			arrlstInParam.add(form.getLowWinPercentage().toString());
			arrlstInParam.add(form.getSaudiDiscount() == null ? "" : form.getSaudiDiscount().toString());
			arrlstInParam.add("N");
		}


		ArrayList arrlstOutParam = eCRDDBMediator.doDBOperation(CRT_SAVE_N_RECALC_PROC_ACTN, arrlstInParam);
		GEAEResultSet rs = (GEAEResultSet) arrlstOutParam.get(0);
		//GEAEResultSet resultSet2 = (GEAEResultSet) arrlstOutParam.get(1);

		form.setScenarioId(Integer.valueOf(eCRDUtil.verifyNull((String)arrlstOutParam.get(1))));
		form.setMessage("<font color=\"blue\" CLASS=\"error\">" +
				"<b><i>Scenario created Successfully</i></b></font>");


		rs.next();
		form.populateAllFromDB(rs);



	}

	/**
	 * To save changed values of a scenario and get the new calculated values.
	 * @param form
	 * @throws Exception
	 */
	public void reCalculateScenario(final ECRDAddEditScenarioForm form) throws Exception {
		ArrayList arrlstInParam = new ArrayList();
		arrlstInParam.add(form.getProjectId().toString());
		arrlstInParam.add(form.getScenarioId().toString());
		arrlstInParam.add(form.getScenarioName());

		if (form.isDefaultEscChkd()) {
			// if true then only default escalation will be applicable, so setting
			// all win rate values to defaultEscalation in order to ease calculation
			arrlstInParam.add(form.getDefaultEscalation().toString());
			arrlstInParam.add(form.getDefaultEscalation().toString());
			arrlstInParam.add(form.getDefaultEscalation().toString());
			arrlstInParam.add(form.getDefaultEscalation().toString());
			arrlstInParam.add(form.getDefaultEscalation().toString());
			arrlstInParam.add(form.getDefaultEscalation().toString());
			arrlstInParam.add(form.getDefaultEscalation().toString());
			arrlstInParam.add(form.getLowWinPercentage() == null ? "0" : form.getLowWinPercentage().toString());
			arrlstInParam.add(form.getSaudiDiscount() == null ? "" : form.getSaudiDiscount().toString());
			arrlstInParam.add("Y");

		} else {
			arrlstInParam.add(form.getDefaultEscalation() == null ? "0" : form.getDefaultEscalation().toString());
			arrlstInParam.add(form.getWinHighHigh().toString());
			arrlstInParam.add(form.getWinHighMed().toString());
			arrlstInParam.add(form.getWinHighLow().toString());
			arrlstInParam.add(form.getWinLowHigh().toString());
			arrlstInParam.add(form.getWinLowMed().toString());
			arrlstInParam.add(form.getWinLowLow().toString());
			arrlstInParam.add(form.getLowWinPercentage().toString());
			arrlstInParam.add(form.getSaudiDiscount() == null ? "" : form.getSaudiDiscount().toString());
			arrlstInParam.add("N");
		}


		ArrayList arrlstOutParam = eCRDDBMediator.doDBOperation(SAVE_N_RECALC_PROC_ACTN, arrlstInParam);
		GEAEResultSet rs = (GEAEResultSet) arrlstOutParam.get(0);
		rs.next();
		form.populateAllFromDB(rs);



	}

	/**
	 * To delete a scenario
	 * @param form
	 * @throws Exception
	 */
	public void deleteScenario(final ECRDAddEditScenarioForm form) throws Exception {
		ArrayList arrlstInParam = new ArrayList();

		arrlstInParam.add(form.getProjectId().toString());
		arrlstInParam.add(form.getScenarioId().toString());

		ArrayList arrlstOutParam = eCRDDBMediator.doDBOperation(DEL_SCENARIO_PROC_ACTN, arrlstInParam);
		form.setMessage((String) arrlstOutParam.get(0));

	}

	/**
	 * To finalize a scenario
	 * @param form
	 * @throws Exception
	 */
	public GEAEResultSet finalizeScenario(final ECRDAddEditScenarioForm form) throws Exception {


		ArrayList arrlstInParam = new ArrayList();
		 GEAEResultSet rsCatalogueDetails = new GEAEResultSet();
		arrlstInParam.add(form.getProjectId().toString());
		arrlstInParam.add(form.getScenarioId().toString());

		 //System.out.println("Inside ECRDADDEditScenarioDAO Before doDBOperation***********************");

		ArrayList arrlstOutParam = eCRDDBMediator.doDBOperation(FNLZ_SCENARIO_PROC_ACTN, arrlstInParam);

		//System.out.println("Inside ECRDADDEditScenarioDAO After doDBOperation***********************");

		rsCatalogueDetails=(GEAEResultSet)arrlstOutParam.get(0);

        return rsCatalogueDetails ;

	}

	/**
	 * To save manual over ride price and call calculation proc.
	 * @param form
	 * @param repairSeqId
	 * @param manualOverrideEsc
	 * @throws Exception
	 */
	public void applyToRepair(final ECRDAddEditScenarioForm form, final String repairSeqId,
			final String manualOverrideEsc) throws Exception {
		ArrayList arrlstInParam = new ArrayList();

		// to save manual override price
		saveRepairDetails(form, repairSeqId, manualOverrideEsc);

		// to call calculation proc
		arrlstInParam.add(form.getProjectId().toString());
		arrlstInParam.add(form.getScenarioId().toString());

		eCRDDBMediator.doDBOperation("ecrdPricingRepairDetailsApplyData", arrlstInParam);

		getScenarionValues(form);


	}

	/**
	 * To save the manual override price
	 * @param form the ECRDRepairDetailsForm to set
	 * @throws Exception
	 */
	private void saveRepairDetails(final ECRDAddEditScenarioForm form, final
		String repairSeqId, final String manualOverrideEsc) throws Exception {

		ArrayList arrlstInParam = new ArrayList();
		arrlstInParam.add(form.getProjectId().toString());
		arrlstInParam.add(form.getScenarioId().toString());
		arrlstInParam.add(repairSeqId);
		arrlstInParam.add(manualOverrideEsc);

		eCRDDBMediator.doDBOperation("ecrdPricingRepairDetailsSaveData", arrlstInParam);

	}

}