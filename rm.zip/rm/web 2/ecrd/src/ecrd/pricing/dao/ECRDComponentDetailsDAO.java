/**
 * Copyright (C) 2011 General Electric Company
 * All rights reserved
 */
package ecrd.pricing.dao;

import java.util.ArrayList;

import org.apache.log4j.Logger;

import ecrd.pricing.form.ECRDComponentDetailsForm;
import ecrd.common.eCRDDBMediator;
import ecrd.common.ECRDPricingCommon;

/**
 * 
 * @author NGTAPXS
 *
 */
public class ECRDComponentDetailsDAO extends ECRDPricingCommon
{
	private static final Logger LOGGER = Logger.getLogger("ECRDComponentDetailsDAO.class");
	public void resize()
	{
		
	}
	public ECRDComponentDetailsForm getComponentDetailsDAO(ECRDComponentDetailsForm form)
	{
		
		ArrayList arrlstOutParam;
		try
		{
			ArrayList arrlstInParam = new ArrayList();
			arrlstInParam.add(form.getComponentCode());	
		arrlstOutParam = eCRDDBMediator.doDBOperation("", arrlstInParam);
		form.setComponentCode(arrlstOutParam.get(0).toString());
		
		}
		catch(Exception exp)
		{
			LOGGER.info("Error Occured " + exp.getMessage());
		}
		
		return form;
		
	}
	
	
	}