/**
 * Copyright (C) 2011 General Electric Company
 * All rights reserved
 */
package ecrd.pricing.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


import ecrd.common.eCRDDBMediator;
import ecrd.pricing.form.DomainValuesTO;
import ecrd.pricing.form.ECRDDefaultEscCapForm;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDUtil;
import geae.dao.GEAEResultSet;

/**
 * 
 * @author NGTAPXS
 *
 */


public class ECRDDefaultEscCapDAO {

	String strActionId;

	public void getCustomerList(final ECRDDefaultEscCapForm form) throws Exception
	{
		
		strActionId = eCRDUtil.verifyNull((String) eCRDConstants.getActionId("eCRD_ESCALATION_CAP"));


		
		ArrayList arrlstInParam = new ArrayList();
		ArrayList arrOutParam ;
		GEAEResultSet rsProjectList = null;
		
		List  listNew = new ArrayList();
		

		
		arrOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInParam);
		rsProjectList = (GEAEResultSet) arrOutParam.get(0);

		

		form.setMapDrpDwn(new HashMap ());
		

		
		while ( rsProjectList.next())
		{
			
			DomainValuesTO obj = new DomainValuesTO();
			
			obj.setName(rsProjectList.getString("customer_name"));
			

			listNew.add(obj);
		}
		
		form.getMapDrpDwn().put("escList",listNew);
		

	}



	public void updateCustomerMaster(final ECRDDefaultEscCapForm form) throws Exception
	{
		
		strActionId = eCRDUtil.verifyNull((String) eCRDConstants.getActionId("eCRD_ESCALATION_CAP_UPT"));


		
		ArrayList arrlstInParam = new ArrayList();
		ArrayList arrOutParam ;
		
		
		///List  List = new ArrayList();
	

		
		arrlstInParam.add(form.getEscCap());
		arrlstInParam.add(form.getCustomer());
		arrlstInParam.add(form.getEngineMdl());

		arrOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInParam);
		String answer=eCRDUtil.verifyNull((String)arrOutParam.get(0));
		if(answer.equalsIgnoreCase("Success"))
			form.setErrorMessage("<font color=\"blue\" CLASS=\"error\"><b><i>The " +
					"Customer Escalation Cap" +
					" is modified successfully.</i></b></font>");
		else if(answer.equalsIgnoreCase("failure"))
			form.setErrorMessage("<font color=\"red\" CLASS=\"error\"><b><i>The Customer Escalation Cap"
					+	" is modification failed.</i></b></font>");
		


		
		getCustomerList(form);
		
		List escTemp;
		escTemp  = (List) form.getMapDrpDwn().get("escList");
		
		
			
		if(escTemp!=null)
		{

			
			for(int count=0;count<escTemp.size();count++)

			{
			

				
				form.getMapDrpDwn().put("escList",escTemp);
				
			}


		}
	}
	
	
	public void getEngineModels(final ECRDDefaultEscCapForm form) throws Exception
	{
		
		strActionId = eCRDUtil.verifyNull((String) eCRDConstants.getActionId("eCRD_GET_ENGINE_MODELS"));


	
		ArrayList arrlstInParam = new ArrayList();
		ArrayList arrOutParam ;
		GEAEResultSet rsModelList = null;
		
		List  List = new ArrayList();
		

		
		arrlstInParam.add(form.getCustomer());

		
		arrOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInParam);
		rsModelList = (GEAEResultSet) arrOutParam.get(0);
	
		


		
		while ( rsModelList.next())
		{
		
			DomainValuesTO obj = new DomainValuesTO();
			
			obj.setName(rsModelList.getString("eng_mdl"));

			List.add(obj);
			








		



		}
		
		form.getMapDrpDwn().put("mdlList",List);
	}
	
	public void getEscalatioCap(final ECRDDefaultEscCapForm form) throws Exception
	{
		
		strActionId = eCRDUtil.verifyNull((String) eCRDConstants.getActionId("eCRD_GET_ESC_CAP"));


		
		ArrayList arrlstInParam = new ArrayList();
		ArrayList arrOutParam ;
		GEAEResultSet rsModelList = null;
		
		////List  List = new ArrayList();
		

		
		arrlstInParam.add(form.getCustomer());
		arrlstInParam.add(form.getEngineMdl());

		
		arrOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInParam);
		rsModelList = (GEAEResultSet) arrOutParam.get(0);
	
		


		
		while ( rsModelList.next())
		{
		
	//	String var = (new Double(rsModelList.getDouble("esc_cap")).toString());
			String var = (rsModelList.getString("esc_cap"));
		
		if(var.equalsIgnoreCase("0"))
				{
			form.setEscCap("N");
				}
		else
		{	
			//form.setEscCap((new Double(rsModelList.getDouble("esc_cap")).toString()));
			form.setEscCap(rsModelList.getString("esc_cap"));
		}


		}
		
	
	}
}
