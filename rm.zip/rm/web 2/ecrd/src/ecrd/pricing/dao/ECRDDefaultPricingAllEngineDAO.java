/**
 * Copyright (C) 2011 General Electric Company
 * All rights reserved
 */
package ecrd.pricing.dao;

import java.util.ArrayList;
import java.util.Calendar;

import ecrd.common.eCRDDBMediator;
import ecrd.common.ECRDPricingCommon;
import ecrd.pricing.form.ECRDDefaultPricingAllEngineForm;
import ecrd.util.eCRDUtil;
import geae.dao.GEAEResultSet;
/**
 * 
 * @author NGTAPXS
 *
 */
public class ECRDDefaultPricingAllEngineDAO extends ECRDPricingCommon {
	
	private static final String ALL = "ALL";
	private static final String GET_DATA_PROC_ACTN = "eCRDPricingDefaultAllDataActn";
	private static final String SAVE_DATA_PROC_ACTN = "eCRDPricingDefaultAllSaveActn";
	
	public void resize() {

	}

	/**
	 * To get the default price for all engines
	 * @param form
	 * @throws Exception
	 */
	public void getDefaultPriceForAllEngine(final ECRDDefaultPricingAllEngineForm form) throws Exception {
		ArrayList arrlstInParam = new ArrayList();
		
		try {
			arrlstInParam.add(ALL);
			//arrlstInParam.add(String.valueOf(Calendar.getInstance().get(Calendar.YEAR) + 1));// next year value
			arrlstInParam.add(eCRDUtil.getCatalogCreationYear());
			ArrayList arrlstOutParam = eCRDDBMediator.doDBOperation(GET_DATA_PROC_ACTN, arrlstInParam);

			GEAEResultSet rs = (GEAEResultSet)arrlstOutParam.get(0);
			
			form.populateFromDB(rs);
			form.setMessage(form.SUCCESS);
			
		} catch(Exception e){
			checkNoDataFound(e, form);
		}

	}

	/**
	 * To save the defaults for all engines.
	 * @param form
	 * @throws Exception
	 */
	public void saveDefaultPriceForAllEngine(final ECRDDefaultPricingAllEngineForm form) throws Exception {
		ArrayList arrlstInParam = new ArrayList();
		
		try {
			arrlstInParam.add(ALL);
			//arrlstInParam.add(String.valueOf(Calendar.getInstance().get(Calendar.YEAR) + 1));// next year value
			arrlstInParam.add(eCRDUtil.getCatalogCreationYear());
			arrlstInParam.add(form.getDefaultEscalation().toString());
			arrlstInParam.add(form.getWinHighHigh().toString());
			arrlstInParam.add(form.getWinHighMed().toString());
			arrlstInParam.add(form.getWinHighLow().toString());
			arrlstInParam.add(form.getWinLowHigh().toString());
			arrlstInParam.add(form.getWinLowMed().toString());
			arrlstInParam.add(form.getWinLowLow().toString());
			arrlstInParam.add(form.getLowWinPercentage().toString());
			
			eCRDDBMediator.doDBOperation(SAVE_DATA_PROC_ACTN, arrlstInParam);
			getDefaultPriceForAllEngine(form);
			form.setMessage(ECRDDefaultPricingAllEngineForm.SUCCESS);
			
		} catch(Exception exp){
			checkNoDataFound(exp, form);
		}

	}

	/**
	 * Method to check for 'no data found' exception.
	 * @param e the <code>Exception</code> caught
	 * @param f the <code>ECRDDefaultPricingEngineLineForm</code> object to set
	 * @throws Exception
	 */
	private void checkNoDataFound(final Exception exp, final ECRDDefaultPricingAllEngineForm frm) throws Exception {
		if(exp.getMessage().indexOf("no data found") != -1) {
			frm.clear();
			frm.setMessage(ECRDDefaultPricingAllEngineForm.FAILURE);
		} else {
			frm.setMessage(ECRDDefaultPricingAllEngineForm.FAILURE);
			throw exp;
		}
	}
}