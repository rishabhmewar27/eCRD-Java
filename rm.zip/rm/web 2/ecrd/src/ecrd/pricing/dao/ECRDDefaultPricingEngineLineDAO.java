/**
 * Copyright (C) 2011 General Electric Company
 * All rights reserved
 */
package ecrd.pricing.dao;

import java.util.ArrayList;
import java.util.Calendar;

import ecrd.common.eCRDDBMediator;
import ecrd.common.ECRDPricingCommon;
import ecrd.pricing.form.DomainValuesTO;
import ecrd.pricing.form.ECRDDefaultPricingEngineLineForm;
import ecrd.util.eCRDUtil;
import geae.dao.GEAEResultSet;
/**
 * 
 * @author NGTAPXS
 *
 */
public class ECRDDefaultPricingEngineLineDAO extends ECRDPricingCommon {
	
	private static final String GET_ENG_LINE_PROC_ACTN = "eCRDPricingDefaultEngLineActn";
	private static final String GET_DATA_PROC_ACTN = "eCRDPricingDefaultAllDataActn";
	private static final String SAVE_DATA_PROC_ACTN = "eCRDPricingDefaultAllSaveActn";
	
	public void resize() {

	}

	public void getEngineLine(ECRDDefaultPricingEngineLineForm form) throws Exception {
		
		
		try {
			ArrayList arrlstInParam = new ArrayList();
			ArrayList arrlstOutParam = eCRDDBMediator.doDBOperation(GET_ENG_LINE_PROC_ACTN, arrlstInParam);
			GEAEResultSet rs = (GEAEResultSet) arrlstOutParam.get(0);
			String colName = rs.getMetaData().getColumnName(1);
			form.removeAll(ECRDDefaultPricingEngineLineForm.ENGINE_LINE_LIST);
			
			for (int cntr = 0; cntr < rs.size(); cntr++, rs.next()) {
				String engLine = rs.getString(colName);
				if("".equalsIgnoreCase(engLine) || "ALL".equalsIgnoreCase(engLine)) {
					continue;
				}
				DomainValuesTO dvt = new DomainValuesTO();
				dvt.setName(rs.getString(colName));
				dvt.setStrId(rs.getString(colName));
				form.add(ECRDDefaultPricingEngineLineForm.ENGINE_LINE_LIST, dvt);
			}
			form.setMessage(ECRDDefaultPricingEngineLineForm.SUCCESS);
			
		} catch(Exception exp){
			checkNoDataFound(exp, form);
		}
	}
	
	public void getDefaultEngLineValues(final ECRDDefaultPricingEngineLineForm form) throws Exception {
		

		try {
			ArrayList arrlstInParam = new ArrayList();
			arrlstInParam.add(form.getEngineLine());
			arrlstInParam.add(String.valueOf(Calendar.getInstance().get(Calendar.YEAR) + 1));// next year value
			ArrayList arrlstOutParam = eCRDDBMediator.doDBOperation(GET_DATA_PROC_ACTN, arrlstInParam);
			
			GEAEResultSet rs = (GEAEResultSet)arrlstOutParam.get(0);
			form.populateFromDB(rs);
			form.setMessage(ECRDDefaultPricingEngineLineForm.SUCCESS);
			
		} catch(Exception exp){
			checkNoDataFound(exp, form);
		}
	}

	public void saveDefaultEngLineValues(final ECRDDefaultPricingEngineLineForm form) throws Exception {
		
		
		try {
			ArrayList arrlstInParam = new ArrayList();
			arrlstInParam.add(form.getEngineLine());
			//arrlstInParam.add(String.valueOf(Calendar.getInstance().get(Calendar.YEAR) + 1));// next year value
			arrlstInParam.add(eCRDUtil.getCatalogCreationYear());
			arrlstInParam.add(form.getDefaultEscalation().toString());
			arrlstInParam.add(form.getWinHighHigh().toString());
			arrlstInParam.add(form.getWinHighMed().toString());
			arrlstInParam.add(form.getWinHighLow().toString());
			arrlstInParam.add(form.getWinLowHigh().toString());
			arrlstInParam.add(form.getWinLowMed().toString());
			arrlstInParam.add(form.getWinLowLow().toString());
			arrlstInParam.add(form.getLowWinPercentage().toString());
			
			eCRDDBMediator.doDBOperation(SAVE_DATA_PROC_ACTN, arrlstInParam);
			getDefaultEngLineValues(form);
			form.setMessage(ECRDDefaultPricingEngineLineForm.SUCCESS);
			
		}  catch(Exception exp){
			checkNoDataFound(exp, form);
		}

	}

	/**
	 * Method to check for 'no data found' exception.
	 * @param e the <code>Exception</code> caught
	 * @param f the <code>ECRDDefaultPricingEngineLineForm</code> object to set
	 * @throws Exception
	 */
	private void checkNoDataFound(final Exception exp, final ECRDDefaultPricingEngineLineForm frm) throws Exception {
		if(exp.getMessage().indexOf("no data found") != -1) {
			frm.clear();
			frm.setMessage(ECRDDefaultPricingEngineLineForm.FAILURE);
		} else {
			frm.setMessage(ECRDDefaultPricingEngineLineForm.FAILURE);
			throw exp;
		}
	}
}