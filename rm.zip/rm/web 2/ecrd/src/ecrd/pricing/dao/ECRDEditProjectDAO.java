/**
 * Copyright (C) 2011 General Electric Company
 * All rights reserved
 */
package ecrd.pricing.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import ecrd.pricing.form.DomainValuesTO;
import ecrd.pricing.form.ECRDEditProjectForm;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDUtil;
import ecrd.common.eCRDDBMediator;
import ecrd.common.ECRDPricingCommon;
import geae.dao.GEAEResultSet;

/**
 *
 * @author NGTAPXS
 *
 */
public class ECRDEditProjectDAO extends ECRDPricingCommon
{

	String strActionId = "";

//	DomainValuesTO domainTo ;
	public void resize()
	{

	}
	public void getProjectList(ECRDEditProjectForm form) throws Exception
	{
		ArrayList arrlstInParam = new ArrayList();
		ArrayList arrOutParam;
		GEAEResultSet rsProjectList = null;

			strActionId = eCRDUtil.verifyNull((String) eCRDConstants.getActionId("eCRD_PROJECT_LIST"));
			List  list = new ArrayList();

			arrlstInParam.add(eCRDUtil.getCatalogCreationYear());

			arrOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInParam);
			rsProjectList = (GEAEResultSet) arrOutParam.get(0);
			String projectName = form.getProjectName();
			form.setMapDrpDwn(new HashMap ());
			while ( rsProjectList.next())
			{

			DomainValuesTO obj = new DomainValuesTO();
			obj.setName(rsProjectList.getString("projectname"));
			obj.setId(rsProjectList.getInt("projectId"));
			if(projectName != null && !("".equals(projectName)) && projectName.equalsIgnoreCase(rsProjectList.getString("projectname")))
			{
				form.setProjectId(rsProjectList.getInt("projectId"));
			}

			list.add(obj);

		}
		form.getMapDrpDwn().put("List",list);

		if(form.isBlank())
		{
		form.setProjectName("");
		form.setDefaultCaltalog("");
		form.setWwShopVisit(-1);
		form.setTmShopVisit(-1);
		form.setExternalShopVisit(-1);
		form.setWwShopVisit(-1);
		form.setAvgDiscount(new Double(-1.0));
		form.setCsaShopVisit(-1);
		form.setSaudiRag(-1);
		form.setAnnualFactor(new Double(-1.0));
		form.setProjectId(-1);
		form.setStrEndDay("01");
		form.setStrStartDay("01");
		form.setStrStartMonth("01");
		form.setStrEndMonth("01");
		form.setStrStartYear("2000");
		form.setStrEndYear("2000");
		}

	}

	public void fetchProjectDetails(final ECRDEditProjectForm form) throws Exception
	{
		GEAEResultSet rsProjectDetails = null;
		GEAEResultSet rsScenarioDetails = null;
		List  scnList = new ArrayList();
		strActionId = eCRDUtil.verifyNull((String) eCRDConstants.getActionId("eCRD_PROJECT_DETAILS"));
		ArrayList arrlstInParam = new ArrayList();
		ArrayList arrOutParam ;

		arrlstInParam.add(Integer.toString(form.getProjectId()));
		arrOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInParam);
		rsProjectDetails = (GEAEResultSet) arrOutParam.get(0);
		rsScenarioDetails = (GEAEResultSet) arrOutParam.get(1);

		while(rsProjectDetails.next())
		{
			form.setExternalShopVisit(rsProjectDetails.getInt("EXT_SV"));
			form.setTmShopVisit(rsProjectDetails.getInt("TNM_SV"));
			form.setAvgDiscount(new Double (rsProjectDetails.getDouble("AVG_DISC")));
			form.setAnnualFactor(new Double(rsProjectDetails.getDouble("ANNULAIZATION_FCTR")));

			System.out.println("AnnualFactor="+form.getAnnualFactor());

			form.setCsaShopVisit(rsProjectDetails.getInt("CSA_SV"));
			form.setWwShopVisit(rsProjectDetails.getInt("WW_SV"));
			form.setDefaultCaltalog(rsProjectDetails.getString("ENG_MDL_DESC"));
			form.setProjectName(rsProjectDetails.getString("PROJ_NM"));
			form.setMeteroStartDate(rsProjectDetails.getString("METREO_STRT_DT"));
			form.setMeteroEndDate(rsProjectDetails.getString("METREO_END_DT"));
			form.setSaudiRag(rsProjectDetails.getInt("SAUDI_RAG"));
		}
		while(rsScenarioDetails.next())
		{
			DomainValuesTO obj = new DomainValuesTO();
			obj.setName(rsScenarioDetails.getString("SCNR_NM"));
			obj.setId(rsScenarioDetails.getInt("SCNR_ID"));
			scnList.add(obj);
		}
		form.setBlank(false);
		getProjectList(form);
		form.getMapDrpDwn().put("scnList",scnList);

	}

	public void editProjectDAO(ECRDEditProjectForm form) throws Exception
	{
		DateFormat formatter ;
		DateFormat formatter2 ;
		Date date ;
		Date date2 ;

		strActionId = eCRDUtil.verifyNull((String) eCRDConstants.getActionId("eCRD_UPDATE_PROJECT"));

		ArrayList arrlstInParam = new ArrayList();
		arrlstInParam.add(form.getProjectName());
		arrlstInParam.add(form.getDefaultCaltalog());
		arrlstInParam.add(Double.toString((form.getCsaShopVisit())));
		arrlstInParam.add(Double.toString((form.getTmShopVisit())));
		arrlstInParam.add(Double.toString((form.getWwShopVisit())));
		arrlstInParam.add(Double.toString((form.getSaudiRag())));
		arrlstInParam.add(Double.toString((form.getExternalShopVisit())));
		arrlstInParam.add(((form.getAvgDiscount()).toString()));
		arrlstInParam.add(((form.getAnnualFactor()).toString()));
		arrlstInParam.add(eCRDUtil.getCatalogCreationYear());

		formatter = new SimpleDateFormat("dd/MM/yyyy"); //please notice the capital M
		 date = formatter.parse(form.getMeteroStartDate());
		 date2 = formatter.parse(form.getMeteroEndDate());
		 formatter2 = new SimpleDateFormat("dd/MMM/yyyy"); //please notice the capital M

		 arrlstInParam.add(formatter2.format(date));
			arrlstInParam.add(formatter2.format(date2));
		eCRDDBMediator.doDBOperation(strActionId, arrlstInParam);

		form.setBlank(false);
		getProjectList(form);
		form.setErrorMessage("<font color=\"blue\" CLASS=\"error\">" +
				"<b><i>Project Updated Successfully</i></b></font>");
	}

	public void deleteExistingProject(final ECRDEditProjectForm form) throws Exception
	{
		strActionId = eCRDUtil.verifyNull((String) eCRDConstants.getActionId("eCRD_DELETE_PROJECT"));
		ArrayList arrlstInParam = new ArrayList();
		ArrayList arrOutParam ;


		arrlstInParam.add(Integer.toString(form.getProjectId()));
		arrOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInParam);

		String strMessage = eCRDUtil.verifyNull((String)arrOutParam.get(0));

		if(strMessage.equalsIgnoreCase("Success"))
		{
			form.setErrorMessage("<font color=\"blue\" CLASS=\"error\">" +
					"<b><i>Project Deleted Successfully</i></b></font>");
		getProjectList(form);
		form.setProjectName("");

		form.setDefaultCaltalog("");
		form.setWwShopVisit(-1);
		form.setTmShopVisit(-1);
		form.setExternalShopVisit(-1);
		form.setCsaShopVisit(-1);
		form.setWwShopVisit(-1);
		form.setSaudiRag(-1);
		form.setAvgDiscount(new Double(-1.0));
		form.setAnnualFactor(new Double(-1.0));
		form.setProjectId(-1);
		form.setStrEndDay("01");
		form.setStrStartDay("01");
		form.setStrStartMonth("01");
		form.setStrEndMonth("01");
		form.setStrStartYear("2000");
		form.setStrEndYear("2000");

		}
		else
		{
			form.setErrorMessage("<font color=\"red\" CLASS=\"error\"><b><i>Project deletion failed</i></b></font>");
		}

	}
	public void addProjectDAO(final ECRDEditProjectForm form) throws Exception
	{
		form.setBlank(false);
		getProjectList(form);
		strActionId = eCRDUtil.verifyNull((String) eCRDConstants.getActionId("eCRD_CREATE_PROJECT"));

		DateFormat formatter ;
		DateFormat formatter2 ;
		Date date ;
		Date date2 ;
		DomainValuesTO domainTo1;

		List tempList  = (List) form.getMapDrpDwn().get("List");

		for(int cntr = 1 ; cntr < tempList.size() ; cntr++)
		{
			domainTo1 = (DomainValuesTO)tempList.get(cntr);
			if(domainTo1.getName().equalsIgnoreCase(form.getProjectName()))
					{
					form.setProjectExists(true);
					form.setErrorMessage("<font color=\"red\" CLASS=\"error\"><b><i>" +
							"The project with the same name already exists. Please enter" +
							" another project name</i></b></font>");

					}
		}
		if(!form.isProjectExists())

		{
		ArrayList arrlstInParam = new ArrayList();
		arrlstInParam.add(form.getProjectName());
		arrlstInParam.add(form.getDefaultCaltalog());
		arrlstInParam.add(Double.toString((form.getCsaShopVisit())));
		arrlstInParam.add(Double.toString((form.getTmShopVisit())));
		arrlstInParam.add(Double.toString((form.getWwShopVisit())));
		arrlstInParam.add(Double.toString((form.getSaudiRag())));
		arrlstInParam.add(Double.toString((form.getExternalShopVisit())));
		arrlstInParam.add(((form.getAvgDiscount().toString())));
		arrlstInParam.add(((form.getAnnualFactor().toString())));
		arrlstInParam.add(eCRDUtil.getCatalogCreationYear());

		 formatter = new SimpleDateFormat("dd/MM/yyyy"); //please notice the capital M
		 date = formatter.parse(form.getMeteroStartDate());
		 date2 = formatter.parse(form.getMeteroEndDate());
		 formatter2 = new SimpleDateFormat("dd/MMM/yyyy"); //please notice the capital M

		 arrlstInParam.add(formatter2.format(date));
			arrlstInParam.add(formatter2.format(date2));



		eCRDDBMediator.doDBOperation(strActionId, arrlstInParam);
		form.setBlank(false);
		getProjectList(form);
		form.setErrorMessage("<font color=\"blue\" CLASS=\"error\">" +
				"<b><i>Project Added Successfully</i></b></font>");
		}

	}

	}