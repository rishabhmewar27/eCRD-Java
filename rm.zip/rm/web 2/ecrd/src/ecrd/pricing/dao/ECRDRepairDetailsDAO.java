/**
 * Copyright (C) 2011 General Electric Company
 * All rights reserved
 */
package ecrd.pricing.dao;

import java.util.ArrayList;

import ecrd.common.eCRDDBMediator;
import ecrd.common.ECRDPricingCommon;
import ecrd.pricing.form.ECRDRepairDetailsForm;
import ecrd.util.eCRDUtil;
import geae.dao.GEAEResultSet;
/**
 * 
 * @author NGTAPXS
 *
 */
public class ECRDRepairDetailsDAO  extends ECRDPricingCommon {

	////private static final Logger LOGGER = Logger.getLogger("ECRDAddEditScenarioDAO.class");
	public void resize() {
		
	}

	/**
	 * To save the manual override price 
	 * @param form the ECRDRepairDetailsForm to set
	 * @throws Exception
	 */
	public void getRepairDetails(final ECRDRepairDetailsForm form) throws Exception {
		
			ArrayList arrlstInParam = new ArrayList();
			arrlstInParam.add(form.getProjectId().toString());
			arrlstInParam.add(form.getScenarioId().toString());
			arrlstInParam.add(form.getRepairSeq().toString());
			
			ArrayList arrlstOutParam = eCRDDBMediator.doDBOperation(form.getHdnScreenAction(), arrlstInParam);
			GEAEResultSet rs = (GEAEResultSet) arrlstOutParam.get(0);
			populate(form, rs);
		
	}
	

	/**
	 * To save the manual override price 
	 * @param form the ECRDRepairDetailsForm to set
	 * @throws Exception
	 */
	public void saveRepairDetails(final ECRDRepairDetailsForm form) throws Exception {
		
		
			ArrayList arrlstInParam = new ArrayList();
			arrlstInParam.add(form.getProjectId().toString());
			arrlstInParam.add(form.getScenarioId().toString());
			arrlstInParam.add(form.getRepairSeq().toString());
			arrlstInParam.add(Integer.toString((form.getManualOverrideEsc())));
			
			 eCRDDBMediator.doDBOperation("ecrdPricingRepairDetailsSaveData", arrlstInParam);
		
	}
	
	/**
	 * To populate database values in Form object.
	 * @param rs
	 * @throws Exception
	 */
	public void populate(final ECRDRepairDetailsForm form, final GEAEResultSet rs) throws Exception{
		
		rs.next();
		form.setComponentCode(eCRDUtil.checkNull(rs.getString("Cmpnt_Cd")));
		form.setComponentDesc(eCRDUtil.checkNull(rs.getString("Cmpnt_Desc")));
		form.setAtaChapter(eCRDUtil.checkNull(rs.getString("Ata_Chptr")));
		form.setQpe(eCRDUtil.checkNull(rs.getString("qpe")));
		form.setRepairSeq(eCRDUtil.verifyIntObj(eCRDUtil.checkNull(rs.getString("rpr_seq"))));
		form.setDisplaySeq(eCRDUtil.verifyIntObj(eCRDUtil.checkNull(rs.getString("Dsply_Seq"))));
		form.setRepairDesc(eCRDUtil.checkNull(rs.getString("rpr_desc")));
		form.setRepairTAT(eCRDUtil.checkNull(rs.getString("rpr_tat")));
		form.setRepairPrice(eCRDUtil.verifyInt(eCRDUtil.checkNull(rs.getString("rpr_pr"))));
		form.setRepairPriceForCal(eCRDUtil.verifyInt(eCRDUtil.checkNull(rs.getString("RPR_PR_FOR_CALC"))));
		form.setDefaultEsc(eCRDUtil.verifyDoubleObj(eCRDUtil.checkNull(rs.getString("DFLT_ESC"))));
		form.setWinRate(eCRDUtil.checkNull(rs.getString("WIN_RATE")));
		form.setRoundedPriceDefaultEsc(eCRDUtil.verifyInt(eCRDUtil.checkNull(rs.getString("ROUNDED_TO_5D_PR_BY_DFLT_ESC"))));
		form.setManualOverrideEsc(eCRDUtil.verifyInt(eCRDUtil.checkNull(rs.getString("MNL_OVRD_PR"))));
		form.setPublishPriceEscNewCatalog(eCRDUtil.verifyInt(eCRDUtil.checkNull(rs.getString("ESC_NW_CTLG_PBLSH_PR"))));
		form.setFinalRepairEsc(eCRDUtil.verifyInt(eCRDUtil.checkNull(rs.getString("FNL_RPR_ESC"))));
		form.setRepairType(eCRDUtil.checkNull(rs.getString("pr_typ")));
	}
	
}
