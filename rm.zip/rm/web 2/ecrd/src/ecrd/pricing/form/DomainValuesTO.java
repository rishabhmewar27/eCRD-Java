/**
 * Copyright (C) 2011 General Electric Company
 * All rights reserved
 */
package ecrd.pricing.form;
/**
 * 
 * @author NGTAPXS
 *
 */
public class DomainValuesTO {
	
private long id;
private String name;
private Double esc;
private String strId;
public Double getEsc() {
	return esc;
}
public void setEsc(Double esc) {
	this.esc = esc;
}

public long getId() {
	return id;
}
public void setId(long id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getStrId() {
	return strId;
}
public void setStrId(String strId) {
	this.strId = strId;
}
//@Override 
public String toString()
{
	return " id = " + this.strId + " name= " + this.name;
}
}
