/**
 * Copyright (C) 2011 General Electric Company
 * All rights reserved
 */
package ecrd.pricing.form;

import java.util.Calendar;

import ecrd.util.eCRDUtil;
import geae.dao.GEAEResultSet;
/**
 * 
 * @author NGTAPXS
 *
 */
public class ECRDAddEditScenarioForm extends ECRDDefaultPricingAllEngineForm {

	private Integer projectId;
	private String projectName = "";
	private String defaultCatalog = "";
	private Integer scenarioId;
	private String scenarioName = "";
	private String prctgOfYear = "";
	private boolean isDefaultEscChkd;
	private boolean isFinalized;

	private ECRDInternalSummary internalSummary;
	private ECRDExternalSummary externalSummary;
	private ECRDWinRateAnalysis winRateAnalysis;

	private Double saudiDiscount;
	
	public ECRDAddEditScenarioForm() {
		this.internalSummary = new ECRDInternalSummary();
		this.externalSummary = new ECRDExternalSummary();
		this.winRateAnalysis = new ECRDWinRateAnalysis();
		
	}

	/**
	 * @return the projectId
	 */
	public Integer getProjectId() {
		return projectId;
	}

	/**
	 * @param projectId the projectId to set
	 */
	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}

	/**
	 * @return the projectName
	 */
	public String getProjectName() {
		return projectName;
	}

	/**
	 * @param projectName
	 *            the projectName to set
	 */
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	/**
	 * @return the defaultCatalog
	 */
	public String getDefaultCatalog() {
		return defaultCatalog;
	}

	/**
	 * @param defaultCatalog the defaultCatalog to set
	 */
	public void setDefaultCatalog(String defaultCatalog) {
		this.defaultCatalog = defaultCatalog;
	}

	/**
	 * @return the scenarioId
	 */
	public Integer getScenarioId() {
		return scenarioId;
	}

	/**
	 * @param scenarioId the scenarioId to set
	 */
	public void setScenarioId(Integer scenarioId) {
		this.scenarioId = scenarioId;
	}

	public String getScenarioName() {
		return scenarioName;
	}

	public void setScenarioName(String scenarioName) {
		this.scenarioName = scenarioName;
	}

	/**
	 * @return the prctgOfYear
	 */
	public String getPrctgOfYear() {
		return prctgOfYear;
	}

	/**
	 * @param prctgOfYear the prctgOfYear to set
	 */
	public void setPrctgOfYear(String prctgOfYear) {
		this.prctgOfYear = prctgOfYear;
	}

	
	/**
	 * @return the winRateAnalysis
	 */
	public ECRDWinRateAnalysis getWinRateAnalysis() {
		return winRateAnalysis;
	}

	/**
	 * @param winRateAnalysis
	 *            the winRateAnalysis to set
	 */
	public void setWinRateAnalysis(ECRDWinRateAnalysis winRateAnalysis) {
		this.winRateAnalysis = winRateAnalysis;
	}

	/**
	 * @return the internalSummary
	 */
	public ECRDInternalSummary getInternalSummary() {
		return internalSummary;
	}

	/**
	 * @param internalSummary
	 *            the internalSummary to set
	 */
	public void setInternalSummary(ECRDInternalSummary internalSummary) {
		this.internalSummary = internalSummary;
	}

	/**
	 * @return the externalSummary
	 */
	public ECRDExternalSummary getExternalSummary() {
		return externalSummary;
	}

	/**
	 * @param externalSummary
	 *            the externalSummary to set
	 */
	public void setExternalSummary(ECRDExternalSummary externalSummary) {
		this.externalSummary = externalSummary;
	}

	/**
	 * @return the isDefaultEscChkd
	 */
	public boolean isDefaultEscChkd() {
		return isDefaultEscChkd;
	}

	/**
	 * @param isDefaultEscChkd the isDefaultEscChkd to set
	 */
	public void setDefaultEscChkd(boolean isDefaultEscChkdIn) {
		this.isDefaultEscChkd = isDefaultEscChkdIn;
	}

	/**
	 * @return the isFinalized
	 */
	public boolean isFinalized() {
		return isFinalized;
	}

	/**
	 * @param isFinalized the isFinalized to set
	 */
	public void setFinalized(boolean isFinalizedIn) {
		this.isFinalized = isFinalizedIn;
	}

	/**
	 * @return the saudiDiscount
	 */
	public Double getSaudiDiscount() {
		return saudiDiscount;
	}

	/**
	 * @param saudiDiscount the saudiDiscount to set
	 */
	public void setSaudiDiscount(Double saudiDiscount) {
		this.saudiDiscount = saudiDiscount;
	}

	public void clear(){
		super.clear();
		this.defaultCatalog = "";
		this.scenarioId = null;
		this.scenarioName = "";
		this.prctgOfYear = "";
		this.isDefaultEscChkd = false;
		this.isFinalized = false;

		this.internalSummary = new ECRDInternalSummary();
		this.externalSummary = new ECRDExternalSummary();
		this.winRateAnalysis = new ECRDWinRateAnalysis();
		
		this.saudiDiscount = null;
	}
	

	/**
	 * 
	 * @param obj
	 * @return
	 */
	public Long parseDoubleToLong(String obj) {
		if(obj == null || "".equals(obj.trim())){
			return null;
		} else{
			Double val = new Double(obj);
			return  new Long(Math.round(val.doubleValue()));
		}
	}
	
	/**
	 * This method is to set only table values that is internal summary, external summary and win rate analysis tables data only.
	 * @throws Exception 
	 * 
	 */
	public void populateAllFromDB(final GEAEResultSet rs) throws Exception {
//		super.populateFromDB(rs);
//		rs.next();
		Double extGrossPriceRealizationPrctg = eCRDUtil.verifyDoubleObj(this.checkNullObject(rs.getString("p_ext_Gross_Prc_Realiz_Prctg")));
		Long extGrossPriceRealizationPrice = this.parseDoubleToLong(rs.getString("p_ext_Gross_Prc_Realiz_Price"));
		Double extEscalationCapPrctg = eCRDUtil.verifyDoubleObj(this.checkNullObject(rs.getString("p_ext_Esc_Cap_Prctg")));
		Long extEscalationCapPrice = this.parseDoubleToLong(rs.getString("p_ext_Esc_Cap_Price"));
		Double extPriceSubTotalPrctg = eCRDUtil.verifyDoubleObj(this.checkNullObject(rs.getString("p_ext_Prc_Subtotal_Prctg")));
		Long extPriceSubTotalPrice = this.parseDoubleToLong(rs.getString("p_ext_Prc_Subtotal_Price"));
		Double extVolumeRealizationPrctg = eCRDUtil.verifyDoubleObj(this.checkNullObject(rs.getString("p_ext_vol_Realiz_Prctg")));
		Long extVolumeRealizationPrice = this.parseDoubleToLong(rs.getString("p_ext_vol_Realiz_Price"));
		Double extExternalRealizationPrctg = eCRDUtil.verifyDoubleObj(this.checkNullObject(rs.getString("p_ext_ext_Realiz_Prctg")));
		Long extExternalRealizationPrice = this.parseDoubleToLong(rs.getString("p_ext_ext_Realiz_Price"));
		
		Double intGrossPriceRealizationPrctg = eCRDUtil.verifyDoubleObj(this.checkNullObject(rs.getString("p_int_Gross_Prc_Realiz_Prctg")));
		Long intGrossPriceRealizationPrice = this.parseDoubleToLong(rs.getString("p_int_Gross_Prc_Realiz_Price"));
		Double intEscalationCapPrctg = eCRDUtil.verifyDoubleObj(this.checkNullObject(rs.getString("p_int_Esc_Cap_Prctg")));
		Long intEscalationCapPrice = this.parseDoubleToLong(rs.getString("p_int_Esc_Cap_Price"));
		Double intNetPriceRealizationPrctg = eCRDUtil.verifyDoubleObj(this.checkNullObject(rs.getString("p_int_net_Prc_Realiz_Prctg")));
		Long intNetPriceRealizationPrice = this.parseDoubleToLong(rs.getString("p_int_net_Prc_Realiz_Price"));
		Double intCsaEliminationPrctg = eCRDUtil.verifyDoubleObj(this.checkNullObject(rs.getString("p_int_Csa_Elimination_Prctg")));
		Long intCsaEliminationPrice = this.parseDoubleToLong(rs.getString("p_int_Csa_Elimination_Price"));
		Double intGessPriceRealizationPrctg = eCRDUtil.verifyDoubleObj(this.checkNullObject(rs.getString("p_int_Gess_Prc_Realiz_Prctg")));
		Long intGessPriceRealizationPrice = this.parseDoubleToLong(rs.getString("p_int_Gess_Prc_Realiz_Price"));
		Double intVolumeRealizationPrctg = eCRDUtil.verifyDoubleObj(this.checkNullObject(rs.getString("p_int_vol_Realiz_Prctg")));
		Long intVolumeRealizationPrice = this.parseDoubleToLong(rs.getString("p_int_vol_Realiz_Price"));
		Double intGessRealizationPrctg = eCRDUtil.verifyDoubleObj(this.checkNullObject(rs.getString("p_int_Gess_Realiz_Prctg")));
		Long intGessRealizationPrice = this.parseDoubleToLong(rs.getString("p_int_Gess_Realiz_Price"));
		Double intSaudiRagNetPrctg = eCRDUtil.verifyDoubleObj(this.checkNullObject(rs.getString("P_SAUDI_RAG_NT_PCT")));
		Long intSaudiRagNetPrice = this.parseDoubleToLong(rs.getString("P_SAUDI_RAG_NT_PR"));
		
		Double wrGrossEscalationPrctg = eCRDUtil.verifyDoubleObj(this.checkNullObject(rs.getString("p_wr_Gross_Esc_Prctg")));
		Long wrGrossEscalationPrice = this.parseDoubleToLong(rs.getString("p_wr_Gross_Esc_Price"));
		Double wrEscalationCapPrctg = eCRDUtil.verifyDoubleObj(this.checkNullObject(rs.getString("p_wr_Esc_Cap_Prctg")));
		Long wrEscalationCapPrice = this.parseDoubleToLong(rs.getString("p_wr_Esc_Cap_Price"));
		Double wrNetPricePrctg = eCRDUtil.verifyDoubleObj(this.checkNullObject(rs.getString("p_wr_Net_Prc_Prctg")));
		Long wrNetPricePrice = this.parseDoubleToLong(rs.getString("p_wr_Net_Prc_Price"));
//		int scenarioId = ((rs.getInt("p_scnr_id")));
		
		
		getExternalSummary().getGrossPriceRealization().setPercentage(extGrossPriceRealizationPrctg);
		getExternalSummary().getGrossPriceRealization().setPrice(extGrossPriceRealizationPrice);
		getExternalSummary().getEscalationCap().setPercentage(extEscalationCapPrctg);
		getExternalSummary().getEscalationCap().setPrice(extEscalationCapPrice);
		getExternalSummary().getPriceSubTotal().setPercentage(extPriceSubTotalPrctg);
		getExternalSummary().getPriceSubTotal().setPrice(extPriceSubTotalPrice);
		getExternalSummary().getVolumeRealization().setPercentage(extVolumeRealizationPrctg);
		getExternalSummary().getVolumeRealization().setPrice(extVolumeRealizationPrice);
		getExternalSummary().getExternalRealization().setPercentage(extExternalRealizationPrctg);
		getExternalSummary().getExternalRealization().setPrice(extExternalRealizationPrice);
		
		getInternalSummary().getGrossPriceRealization().setPercentage(intGrossPriceRealizationPrctg);
		getInternalSummary().getGrossPriceRealization().setPrice(intGrossPriceRealizationPrice);
		getInternalSummary().getEscalationCap().setPercentage(intEscalationCapPrctg);
		getInternalSummary().getEscalationCap().setPrice(intEscalationCapPrice);
		getInternalSummary().getNetPriceRealization().setPercentage(intNetPriceRealizationPrctg);
		getInternalSummary().getNetPriceRealization().setPrice(intNetPriceRealizationPrice);
		getInternalSummary().getCsaElimination().setPercentage(intCsaEliminationPrctg);
		getInternalSummary().getCsaElimination().setPrice(intCsaEliminationPrice);
		getInternalSummary().getGessPriceRealization().setPercentage(intGessPriceRealizationPrctg);
		getInternalSummary().getGessPriceRealization().setPrice(intGessPriceRealizationPrice);
		getInternalSummary().getVolumeRealization().setPercentage(intVolumeRealizationPrctg);
		getInternalSummary().getVolumeRealization().setPrice(intVolumeRealizationPrice);
		getInternalSummary().getGessRealization().setPercentage(intGessRealizationPrctg);
		getInternalSummary().getGessRealization().setPrice(intGessRealizationPrice);
		getInternalSummary().getSaudiRagNet().setPercentage(intSaudiRagNetPrctg);
		getInternalSummary().getSaudiRagNet().setPrice(intSaudiRagNetPrice);

		getWinRateAnalysis().getGrossEscalation().setPercentage(wrGrossEscalationPrctg);
		getWinRateAnalysis().getGrossEscalation().setPrice(wrGrossEscalationPrice);
		getWinRateAnalysis().getEscalationCap().setPercentage(wrEscalationCapPrctg);
		getWinRateAnalysis().getEscalationCap().setPrice(wrEscalationCapPrice);
		getWinRateAnalysis().getNetPrice().setPercentage(wrNetPricePrctg);
		getWinRateAnalysis().getNetPrice().setPrice(wrNetPricePrice);
		
		//setPrctgOfYear(String.valueOf(Calendar.getInstance().get(Calendar.YEAR) + 1)); // next year value.
		setPrctgOfYear(eCRDUtil.getCatalogCreationYear());
	}
}