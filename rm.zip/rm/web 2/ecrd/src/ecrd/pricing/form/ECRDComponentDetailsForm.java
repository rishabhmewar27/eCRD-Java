/**
 * Copyright (C) 2011 General Electric Company
 * All rights reserved
 */
package ecrd.pricing.form;

/**
 * 
 * @author NGTAPXS
 *
 */
public class ECRDComponentDetailsForm
{
	private String componentCode;
	private String componentDescription;
	private String ataChapter;
	private int repairSequnce;
	private int displaySequnce;
	private String repairDescription;
	private String primarySite;
	private String repairTAT;
	private double repairPrice;
	private double repairPriceForCalculation;
	private int defaultEscalation;
	private String der;
	private String oemCompletion;
	private String risk;
	private String techLevel;
	private String escalationCatagory;
	private String winRate;
	private double overidePrice;
	private double overideEscalation;
	private double finalRepairEscalation;
	
	public String getComponentDescription() {
		return componentDescription;
	}
	
	public void setComponentDescription(String componentDescription) {
		this.componentDescription = componentDescription;
	}
	
	public String getAtaChapter() {
		return ataChapter;
	}
	
	public void setAtaChapter(String ataChapter) {
		this.ataChapter = ataChapter;
	}
	
	public int getRepairSequnce() {
		return repairSequnce;
	}
	
	public void setRepairSequnce(int repairSequnce) {
		this.repairSequnce = repairSequnce;
	}
	
	public int getDisplaySequnce() {
		return displaySequnce;
	}
	
	public void setDisplaySequnce(int displaySequnce) {
		this.displaySequnce = displaySequnce;
	}
	
	public String getRepairDescription() {
		return repairDescription;
	}
	
	public void setRepairDescription(String repairDescription) {
		this.repairDescription = repairDescription;
	}
	
	public String getPrimarySite() {
		return primarySite;
	}
	
	public void setPrimarySite(String primarySite) {
		this.primarySite = primarySite;
	}
	
	public String getRepairTAT() {
		return repairTAT;
	}
	
	public void setRepairTAT(String repairTAT) {
		this.repairTAT = repairTAT;
	}
	
	public double getRepairPrice() {
		return repairPrice;
	}
	
	public void setRepairPrice(double repairPrice) {
		this.repairPrice = repairPrice;
	}
	
	public double getRepairPriceForCalculation() {
		return repairPriceForCalculation;
	}
	
	public void setRepairPriceForCalculation(double repairPriceForCalculation) {
		this.repairPriceForCalculation = repairPriceForCalculation;
	}
	
	public int getDefaultEscalation() {
		return defaultEscalation;
	}
	
	public void setDefaultEscalation(int defaultEscalation) {
		this.defaultEscalation = defaultEscalation;
	}
	
	public String getDer() {
		return der;
	}
	
	public void setDer(String der) {
		this.der = der;
	}
	
	public String getOemCompletion() {
		return oemCompletion;
	}
	
	public void setOemCompletion(String oemCompletion) {
		this.oemCompletion = oemCompletion;
	}
	
	public String getRisk() {
		return risk;
	}
	
	public void setRisk(String risk) {
		this.risk = risk;
	}
	
	public String getTechLevel() {
		return techLevel;
	}
	
	public void setTechLevel(String techLevel) {
		this.techLevel = techLevel;
	}
	
	public String getEscalationCatagory() {
		return escalationCatagory;
	}
	
	public void setEscalationCatagory(String escalationCatagory) {
		this.escalationCatagory = escalationCatagory;
	}
	
	public String getWinRate() {
		return winRate;
	}
	
	public void setWinRate(String winRate) {
		this.winRate = winRate;
	}
	
	public double getOveridePrice() {
		return overidePrice;
	}
	
	public void setOveridePrice(double overidePrice) {
		this.overidePrice = overidePrice;
	}
	
	public double getOverideEscalation() {
		return overideEscalation;
	}
	
	public void setOverideEscalation(double overideEscalation) {
		this.overideEscalation = overideEscalation;
	}
	
	public double getFinalRepairEscalation() {
		return finalRepairEscalation;
	}
	
	public void setFinalRepairEscalation(double finalRepairEscalation) {
		this.finalRepairEscalation = finalRepairEscalation;
	}

	public String getComponentCode() {
		return componentCode;
	}

	public void setComponentCode(String componentCode) {
		this.componentCode = componentCode;
	}
	
}