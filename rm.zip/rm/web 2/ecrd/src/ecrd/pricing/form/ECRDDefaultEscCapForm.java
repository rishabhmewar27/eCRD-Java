/**
 * Copyright (C) 2011 General Electric Company
 * All rights reserved
 */
package ecrd.pricing.form;


import java.util.Map;


/**
 * 
 * @author NGTAPXS
 *
 */

public class ECRDDefaultEscCapForm {
	
private Map mapDrpDwn;
	String customer;
	String errorMessage="";
	String engineMdl="";
	public String getEngineMdl() {
		return engineMdl;
	}


	public void setEngineMdl(String engineMdl) {
		this.engineMdl = engineMdl;
	}


	public String getErrorMessage() {
		return errorMessage;
	}


	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}


	public String getCustomer() {
		return customer;
	}


	public void setCustomer(String customer) {
		this.customer = customer;
	}


	String escCap ;
	public String getEscCap() {
		return escCap;
	}


	public void setEscCap(String escCap) {
		this.escCap = escCap;
	}


	public Map getMapDrpDwn() {
		return mapDrpDwn;
	}


	public void setMapDrpDwn(Map mapDrpDwn) {
		this.mapDrpDwn = mapDrpDwn;
	}



}
