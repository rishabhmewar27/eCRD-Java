/**
 * Copyright (C) 2011 General Electric Company
 * All rights reserved
 */
package ecrd.pricing.form;

import ecrd.util.eCRDUtil;
import geae.dao.GEAEResultSet;

/**
 * 
 * @author NGTAPXS
 *
 */
public class ECRDDefaultPricingAllEngineForm {

	public static final String SUCCESS = "SUCCESS";
	public static final String FAILURE = "FAILURE";
	
	private Double defaultEscalation;
	private Double winHighHigh;
	private Double winHighMed;
	private Double winHighLow;
	private Double winLowHigh;
	private Double winLowMed;
	private Double winLowLow;
	private Double lowWinPercentage;
	private String message;
	
	/**
	 * @return the defaultEscalation
	 */
	public Double getDefaultEscalation() {
		return defaultEscalation;
	}
	/**
	 * @param defaultEscalation the defaultEscalation to set
	 */
	public void setDefaultEscalation(Double defaultEscalationIn) {
		this.defaultEscalation = defaultEscalationIn;
	}
	
	
	/**
	 * @return the winHighHigh
	 */
	public Double getWinHighHigh() {
		return winHighHigh;
	}
	/**
	 * @param winHighHigh the winHighHigh to set
	 */
	public void setWinHighHigh(Double winHighHighIn) {
		this.winHighHigh = winHighHighIn;
	}
	/**
	 * @return the winHighMed
	 */
	public Double getWinHighMed() {
		return winHighMed;
	}
	/**
	 * @param winHighMed the winHighMed to set
	 */
	public void setWinHighMed(Double winHighMedIn) {
		this.winHighMed = winHighMedIn;
	}
	/**
	 * @return the winHighLow
	 */
	public Double getWinHighLow() {
		return winHighLow;
	}
	/**
	 * @param winHighLow the winHighLow to set
	 */
	public void setWinHighLow(Double winHighLowIn) {
		this.winHighLow = winHighLowIn;
	}
	/**
	 * @return the winLowHigh
	 */
	public Double getWinLowHigh() {
		return winLowHigh;
	}
	/**
	 * @param winLowHigh the winLowHigh to set
	 */
	public void setWinLowHigh(Double winLowHighIn) {
		this.winLowHigh = winLowHighIn;
	}
	/**
	 * @return the winLowMed
	 */
	public Double getWinLowMed() {
		return winLowMed;
	}
	/**
	 * @param winLowMed the winLowMed to set
	 */
	public void setWinLowMed(Double winLowMedIn) {
		this.winLowMed = winLowMedIn;
	}
	/**
	 * @return the winLowLow
	 */
	public Double getWinLowLow() {
		return winLowLow;
	}
	/**
	 * @param winLowLow the winLowLow to set
	 */
	public void setWinLowLow(Double winLowLowIn) {
		this.winLowLow = winLowLowIn;
	}
	/**
	 * @return the lowWinPercentage
	 */
	public Double getLowWinPercentage() {
		return lowWinPercentage;
	}
	/**
	 * @param lowWinPercentage the lowWinPercentage to set
	 */
	public void setLowWinPercentage(Double lowWinPercentageIn) {
		this.lowWinPercentage = lowWinPercentageIn;
	}

	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * @param message the message to set
	 */
	public void setMessage(String messageIn) {
		this.message = messageIn;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */

	
	//@Override
	public String toString() {
		return "ECRDDefaultPricingAllEngineForm [defaultEscalation="
				+ defaultEscalation + ", winHighHigh=" + winHighHigh
				+ ", winHighMed=" + winHighMed + ", winHighLow=" + winHighLow
				+ ", winLowHigh=" + winLowHigh + ", winLowMed=" + winLowMed
				+ ", winLowLow=" + winLowLow + ", lowWinPercentage="
				+ lowWinPercentage + "]";
	}

	/**
	 * Clears all the properties of form
	 */
	public void clear() {
		this.defaultEscalation = null;
		this.winHighHigh = null;
		this.winHighMed = null;
		this.winHighLow = null;
		this.winLowHigh = null;
		this.winLowMed = null;
		this.winLowLow = null;
		this.lowWinPercentage = null;
		this.message = "";
	}

	public void populateFromDB(final GEAEResultSet rs) throws Exception {
		rs.next();
		
		Double defEsc = eCRDUtil.verifyDoubleObj(this.checkNullObject(rs.getString("p_dflt_esc_out")));
		Double winHighHigh1 = eCRDUtil.verifyDoubleObj(this.checkNullObject(rs.getString("p_win_high_high_out")));
		Double winHighMed1 = eCRDUtil.verifyDoubleObj(this.checkNullObject(rs.getString("p_win_high_med_out")));
		Double winHighLow1 = eCRDUtil.verifyDoubleObj(this.checkNullObject(rs.getString("p_win_high_low_out")));
		Double winLowHigh1 = eCRDUtil.verifyDoubleObj(this.checkNullObject(rs.getString("p_win_low_high_out")));
		Double winLowMed1 = eCRDUtil.verifyDoubleObj(this.checkNullObject(rs.getString("p_win_low_med_out")));
		Double winLowLow1 = eCRDUtil.verifyDoubleObj(this.checkNullObject(rs.getString("p_win_low_low_out")));
		Double lowWinPercentage1 = eCRDUtil.verifyDoubleObj(this.checkNullObject(rs.getString("P_LOW_WIN_PCT_OUT")));
		

		this.setDefaultEscalation(defEsc);
		this.setWinHighHigh(winHighHigh1);
		this.setWinHighMed(winHighMed1);
		this.setWinHighLow(winHighLow1);
		this.setWinLowHigh(winLowHigh1);
		this.setWinLowMed(winLowMed1);
		this.setWinLowLow(winLowLow1);
		this.setLowWinPercentage(lowWinPercentage1);

	}
	
	public String checkNullObject(Object obj) {
		return (obj == null) ? null : obj.toString();
	}
	
	public String replaceNullWithBlnk(Object obj) {
		return (obj == null) ? "" : obj.toString();
	}
}