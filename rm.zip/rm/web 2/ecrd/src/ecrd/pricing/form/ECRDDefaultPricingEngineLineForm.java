/**
 * Copyright (C) 2011 General Electric Company
 * All rights reserved
 */
package ecrd.pricing.form;

import geae.dao.GEAEResultSet;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 
 * @author NGTAPXS
 *
 */
public class ECRDDefaultPricingEngineLineForm extends ECRDDefaultPricingAllEngineForm {
	
	public static final String ENGINE_LINE_LIST = "ENGINE_LINE_LIST";
	
	private String engineLine;
	private Map dropDownListHandler = new HashMap();

	
	
	/**
	 * @return the engineLine
	 */
	public String getEngineLine() {
		return engineLine;
	}

	/**
	 * @param engineLine the engineLine to set
	 */
	public void setEngineLine(String engineLine) {
		this.engineLine = engineLine;
	}

	
	
	public List get(String key) {
		return (List)dropDownListHandler.get(key);
	}

	public void add(String key, DomainValuesTO val) {
		if(dropDownListHandler.get(key) == null) {
			dropDownListHandler.put(key, new ArrayList());
		}
		((List)dropDownListHandler.get(key)).add(val);
	}
	
	public void addAll(String key, List val) {
		dropDownListHandler.put(key, val);
	}
	
	public void removeAll(String key) {
		if(dropDownListHandler.get(key) != null) {
			((List)dropDownListHandler.get(key)).clear();
		}
	}
	//@Override
	public String toString() {
		return "ECRDDefaultPricingEngineLineForm [getEngineLine()="
				+ getEngineLine() + ", getDefaultEscalation()="
				+ getDefaultEscalation() + ", getWinHighHigh()="
				+ getWinHighHigh() + ", getWinHighMed()=" + getWinHighMed()
				+ ", getWinHighLow()=" + getWinHighLow() + ", getWinLowHigh()="
				+ getWinLowHigh() + ", getWinLowMed()=" + getWinLowMed()
				+ ", getWinLowLow()=" + getWinLowLow()
				+ ", getLowWinPercentage()=" + getLowWinPercentage()
				+ ", getMessage()=" + getMessage() + "]";
	}

	public void clear() {
		super.clear();
	}
	
	public void populateFromDB(final GEAEResultSet rs) throws Exception{
		super.populateFromDB(rs);
	}
	
}