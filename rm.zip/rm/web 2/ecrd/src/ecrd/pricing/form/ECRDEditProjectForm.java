/**
 * Copyright (C) 2011 General Electric Company
 * All rights reserved
 */
package ecrd.pricing.form;

import java.util.Map;
/**
 * 
 * @author NGTAPXS
 *
 */
public class ECRDEditProjectForm
{
	
	private String projectName;
	boolean projectExists;
	private boolean isBlank ;

	private String strStartDay;
	private String strStartMonth;
	private String strStartYear;
	private String strEndYear;
	private String strEndMonth;
	private String strEndDay;
	private String defaultCaltalog;
	private int csaShopVisit;
	private int tmShopVisit;
	private int externalShopVisit;
	private Double avgDiscount;
	private Double annualFactor;
	private String meteroStartDate;
	private String meteroEndDate;
	private Map mapDrpDwn;
	private int projectId;
	private String errorMessage = "";
	private String projectList;
	private int wwShopVisit;
	public ECRDEditProjectForm()
	{
		super();
		this.defaultCaltalog = "";
		this.csaShopVisit = 0;
		this.tmShopVisit = 0;
		this.externalShopVisit = 0;
		this.avgDiscount = new Double(00.0);
		this.annualFactor = new Double(00.0);
		this.meteroStartDate = "";
		this.meteroEndDate = "";
		this.errorMessage = "";
		this.wwShopVisit = 0;
		
		mapDrpDwn = null;
		
	
	}
	
	public boolean isBlank() {
		return isBlank;
	}
	
	public boolean isProjectExists() {
		return projectExists;
	}
	
	int saudiRag;

	public int getSaudiRag() {
		return saudiRag;
	}
	public void setSaudiRag(int saudiRag) {
		this.saudiRag = saudiRag;
	}

	public void setProjectExists(boolean projectExists1) {
		this.projectExists = projectExists1;
	}
	public void setBlank(boolean isBlank1) {
		this.isBlank = isBlank1;
	}
	public String getStrStartDay() {
		return strStartDay;
	}
	public void setStrStartDay(String strStartdateDD) {
		strStartDay = strStartdateDD;
	}
	public String getStrStartMonth() {
		return strStartMonth;
	}
	public void setStrStartMonth(String strStartdateMM) {
		strStartMonth = strStartdateMM;
	}
	public String getStrStartYear() {
		return strStartYear;
	}
	public void setStrStartYear(String strStartdateYYYY) {
		strStartYear = strStartdateYYYY;
	}
	public String getStrEndYear() {
		return strEndYear;
	}
	public void setStrEndYear(String strEnddateYYYY) {
		strEndYear = strEnddateYYYY;
	}
	public String getStrEndMonth() {
		return strEndMonth;
	}
	public void setStrEndMonth(String strEnddateMM) {
		strEndMonth = strEnddateMM;
	}
	public String getStrEndDay() {
		return strEndDay;
	}
	public void setStrEndDay(String strEnddateDD) {
		strEndDay = strEnddateDD;
	}


	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	public int getWwShopVisit() {
		return wwShopVisit;
	}
	public void setWwShopVisit(int wwShopVisit) {
		this.wwShopVisit = wwShopVisit;
	}
	public String getProjectList() {
		return projectList;
	}
	public void setProjectList(String projectList) {
		this.projectList = projectList;
	}
	
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getDefaultCaltalog() {
		return defaultCaltalog;
	}
	public void setDefaultCaltalog(String defaultCaltalog) {
		this.defaultCaltalog = defaultCaltalog;
	}
	public int getCsaShopVisit() {
		return csaShopVisit;
	}
	public void setCsaShopVisit(int csaShopVisit) {
		this.csaShopVisit = csaShopVisit;
	}
	public int getTmShopVisit() {
		return tmShopVisit;
	}
	public void setTmShopVisit(int tmShopVisit) {
		this.tmShopVisit = tmShopVisit;
	}
	public int getExternalShopVisit() {
		return externalShopVisit;
	}
	public void setExternalShopVisit(int externalShopVisit) {
		this.externalShopVisit = externalShopVisit;
	}
	public Double getAvgDiscount() {
		return avgDiscount;
	}
	public void setAvgDiscount(Double avgDiscount) {
		this.avgDiscount = avgDiscount;
	}
	public Double getAnnualFactor() {
		return annualFactor;
	}
	public void setAnnualFactor(Double annualFactor) {
		this.annualFactor = annualFactor;
	}
	public String getMeteroStartDate() {
		return meteroStartDate;
	}
	public void setMeteroStartDate(String meteroStartDate) {
		this.meteroStartDate = meteroStartDate;
	}
	public String getMeteroEndDate() {
		return meteroEndDate;
	}
	public void setMeteroEndDate(String meteroEndDate) {
		this.meteroEndDate = meteroEndDate;
	}
	
	public Map getMapDrpDwn() {
		return mapDrpDwn;
	}


	public void setMapDrpDwn(Map mapDrpDwn) {
		this.mapDrpDwn = mapDrpDwn;
	}
	
	public int getProjectId() {
		return projectId;
	}


	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}
	
}