/**
 * Copyright (C) 2011 General Electric Company
 * All rights reserved
 */
package ecrd.pricing.form;

/**
 * 
 * @author NGTAPXS
 *
 */
public class ECRDExternalSummary {

	private PricePercentTO grossPriceRealization;
	private PricePercentTO escalationCap;
	private PricePercentTO priceSubTotal;
	private PricePercentTO volumeRealization;
	private PricePercentTO externalRealization;

	public ECRDExternalSummary() {
		grossPriceRealization = new PricePercentTO();
		escalationCap = new PricePercentTO();
		priceSubTotal = new PricePercentTO();
		volumeRealization = new PricePercentTO();
		externalRealization = new PricePercentTO();
	}
	/**
	 * @return the grossPriceRealization
	 */
	public PricePercentTO getGrossPriceRealization() {
		return grossPriceRealization;
	}

	/**
	 * @param grossPriceRealization
	 *            the grossPriceRealization to set
	 */
	public void setGrossPriceRealization(PricePercentTO grossPriceRealization) {
		this.grossPriceRealization = grossPriceRealization;
	}

	/**
	 * @return the escalationCap
	 */
	public PricePercentTO getEscalationCap() {
		return escalationCap;
	}

	/**
	 * @param escalationCap
	 *            the escalationCap to set
	 */
	public void setEscalationCap(PricePercentTO escalationCap) {
		this.escalationCap = escalationCap;
	}

	/**
	 * @return the priceSubTotal
	 */
	public PricePercentTO getPriceSubTotal() {
		return priceSubTotal;
	}

	/**
	 * @param priceSubTotal
	 *            the priceSubTotal to set
	 */
	public void setPriceSubTotal(PricePercentTO priceSubTotal) {
		this.priceSubTotal = priceSubTotal;
	}

	/**
	 * @return the volumeRealization
	 */
	public PricePercentTO getVolumeRealization() {
		return volumeRealization;
	}

	/**
	 * @param volumeRealization
	 *            the volumeRealization to set
	 */
	public void setVolumeRealization(PricePercentTO volumeRealization) {
		this.volumeRealization = volumeRealization;
	}

	/**
	 * @return the externalRealization
	 */
	public PricePercentTO getExternalRealization() {
		return externalRealization;
	}

	/**
	 * @param externalRealization
	 *            the externalRealization to set
	 */
	public void setExternalRealization(PricePercentTO externalRealization) {
		this.externalRealization = externalRealization;
	}

}