/**
 * Copyright (C) 2011 General Electric Company
 * All rights reserved
 */
package ecrd.pricing.form;
/**
 * 
 * @author NGTAPXS
 *
 */
public class ECRDInternalSummary {
	
	private PricePercentTO grossPriceRealization;
	private PricePercentTO escalationCap;
	private PricePercentTO netPriceRealization;
	private PricePercentTO csaElimination;
	private PricePercentTO gessPriceRealization;
	private PricePercentTO volumeRealization;
	private PricePercentTO gessRealization;
	private PricePercentTO saudiRagNet;

	public ECRDInternalSummary() {
		grossPriceRealization = new PricePercentTO();
		escalationCap = new PricePercentTO();
		netPriceRealization = new PricePercentTO();
		csaElimination = new PricePercentTO();
		gessPriceRealization = new PricePercentTO();
		volumeRealization = new PricePercentTO();
		gessRealization = new PricePercentTO();
		saudiRagNet = new PricePercentTO();
	}
	
	/**
	 * @return the grossPriceRealization
	 */
	public PricePercentTO getGrossPriceRealization() {
		return grossPriceRealization;
	}

	/**
	 * @param grossPriceRealization
	 *            the grossPriceRealization to set
	 */
	public void setGrossPriceRealization(PricePercentTO grossPriceRealization) {
		this.grossPriceRealization = grossPriceRealization;
	}

	/**
	 * @return the escalationCap
	 */
	public PricePercentTO getEscalationCap() {
		return escalationCap;
	}

	/**
	 * @param escalationCap
	 *            the escalationCap to set
	 */
	public void setEscalationCap(PricePercentTO escalationCap) {
		this.escalationCap = escalationCap;
	}

	/**
	 * @return the netPriceRealization
	 */
	public PricePercentTO getNetPriceRealization() {
		return netPriceRealization;
	}

	/**
	 * @param netPriceRealization
	 *            the netPriceRealization to set
	 */
	public void setNetPriceRealization(PricePercentTO netPriceRealization) {
		this.netPriceRealization = netPriceRealization;
	}

	/**
	 * @return the csaElimination
	 */
	public PricePercentTO getCsaElimination() {
		return csaElimination;
	}

	/**
	 * @param csaElimination
	 *            the csaElimination to set
	 */
	public void setCsaElimination(PricePercentTO csaElimination) {
		this.csaElimination = csaElimination;
	}

	/**
	 * @return the gessPriceRealization
	 */
	public PricePercentTO getGessPriceRealization() {
		return gessPriceRealization;
	}

	/**
	 * @param gessPriceRealization
	 *            the gessPriceRealization to set
	 */
	public void setGessPriceRealization(PricePercentTO gessPriceRealization) {
		this.gessPriceRealization = gessPriceRealization;
	}

	/**
	 * @return the volumeRealization
	 */
	public PricePercentTO getVolumeRealization() {
		return volumeRealization;
	}

	/**
	 * @param volumeRealization
	 *            the volumeRealization to set
	 */
	public void setVolumeRealization(PricePercentTO volumeRealization) {
		this.volumeRealization = volumeRealization;
	}

	/**
	 * @return the gessRealization
	 */
	public PricePercentTO getGessRealization() {
		return gessRealization;
	}

	/**
	 * @param gessRealization
	 *            the gessRealization to set
	 */
	public void setGessRealization(PricePercentTO gessRealization) {
		this.gessRealization = gessRealization;
	}

	/**
	 * @return the saudiRagNet
	 */
	public PricePercentTO getSaudiRagNet() {
		return saudiRagNet;
	}

	/**
	 * @param saudiRagNet the saudiRagNet to set
	 */
	public void setSaudiRagNet(PricePercentTO saudiRagNet) {
		this.saudiRagNet = saudiRagNet;
	}

}