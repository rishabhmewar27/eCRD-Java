/**
 * Copyright (C) 2011 General Electric Company
 * All rights reserved
 */
package ecrd.pricing.form;

/**
 * 
 * @author NGTAPXS
 *
 */
public class ECRDRepairDetailsForm {

	private String hdnScreenAction;
	private Integer projectId;
	private String projectName;
	private Integer scenarioId;
	private String scenarioName;
	
	private String componentCode;
	private String componentDesc;
	private String ataChapter;
	private String qpe;
	private Integer repairSeq;
	private Integer displaySeq;
	private String repairDesc;
	private String repairTAT;
	private int repairPrice;
	private int repairPriceForCal;
	private Double defaultEsc;
	private String techLevel;
	private String winRate;
	private int roundedPriceDefaultEsc;
	private int manualOverrideEsc;
	private int publishPriceEscNewCatalog;
	private int finalRepairEsc;
	private String repairType;

	
	/**
	 * @return the hdnScreenAction
	 */
	public String getHdnScreenAction() {
		return hdnScreenAction;
	}
	/**
	 * @param hdnScreenAction the hdnScreenAction to set
	 */
	public void setHdnScreenAction(String hdnScreenAction) {
		this.hdnScreenAction = hdnScreenAction;
	}
	/**
	 * @return the projectId
	 */
	public Integer getProjectId() {
		return projectId;
	}
	/**
	 * @param projectId the projectId to set
	 */
	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}
	/**
	 * @return the projectName
	 */
	public String getProjectName() {
		return projectName;
	}
	/**
	 * @param projectName the projectName to set
	 */
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	/**
	 * @return the scenarioId
	 */
	public Integer getScenarioId() {
		return scenarioId;
	}
	/**
	 * @param scenarioId the scenarioId to set
	 */
	public void setScenarioId(Integer scenarioId) {
		this.scenarioId = scenarioId;
	}
	/**
	 * @return the scenarioName
	 */
	public String getScenarioName() {
		return scenarioName;
	}
	/**
	 * @param scenarioName the scenarioName to set
	 */
	public void setScenarioName(String scenarioNameIn) {
		this.scenarioName = scenarioNameIn;
	}
	/**
	 * @return the componentCode
	 */
	public String getComponentCode() {
		return componentCode;
	}
	/**
	 * @param componentCode the componentCode to set
	 */
	public void setComponentCode(String componentCode) {
		this.componentCode = componentCode;
	}
	/**
	 * @return the componentDesc
	 */
	public String getComponentDesc() {
		return componentDesc;
	}
	/**
	 * @param componentDesc the componentDesc to set
	 */
	public void setComponentDesc(String componentDesc) {
		this.componentDesc = componentDesc;
	}
	/**
	 * @return the ataChapter
	 */
	public String getAtaChapter() {
		return ataChapter;
	}
	/**
	 * @param ataChapter the ataChapter to set
	 */
	public void setAtaChapter(String ataChapter) {
		this.ataChapter = ataChapter;
	}
	/**
	 * @return the qpe
	 */
	public String getQpe() {
		return qpe;
	}
	/**
	 * @param qpe the qpe to set
	 */
	public void setQpe(String qpe) {
		this.qpe = qpe;
	}
	/**
	 * @return the repairSeq
	 */
	public Integer getRepairSeq() {
		return repairSeq;
	}
	/**
	 * @param repairSeq the repairSeq to set
	 */
	public void setRepairSeq(Integer repairSeq) {
		this.repairSeq = repairSeq;
	}
	/**
	 * @return the displaySeq
	 */
	public Integer getDisplaySeq() {
		return displaySeq;
	}
	/**
	 * @param displaySeq the displaySeq to set
	 */
	public void setDisplaySeq(Integer displaySeq) {
		this.displaySeq = displaySeq;
	}
	/**
	 * @return the repairDesc
	 */
	public String getRepairDesc() {
		return repairDesc;
	}
	/**
	 * @param repairDesc the repairDesc to set
	 */
	public void setRepairDesc(String repairDesc) {
		this.repairDesc = repairDesc;
	}
	
	/**
	 * @return the repairTAT
	 */
	public String getRepairTAT() {
		return repairTAT;
	}
	/**
	 * @param repairTAT the repairTAT to set
	 */
	public void setRepairTAT(String repairTAT) {
		this.repairTAT = repairTAT;
	}
	/**
	 * @return the repairPrice
	 */
	public int getRepairPrice() {
		return repairPrice;
	}
	/**
	 * @param repairPrice the repairPrice to set
	 */
	public void setRepairPrice(int repairPrice) {
		this.repairPrice = repairPrice;
	}
	/**
	 * @return the repairPriceForCal
	 */
	public int getRepairPriceForCal() {
		return repairPriceForCal;
	}
	/**
	 * @param repairPriceForCal the repairPriceForCal to set
	 */
	public void setRepairPriceForCal(int repairPriceForCal) {
		this.repairPriceForCal = repairPriceForCal;
	}
	/**
	 * @return the defaultEsc
	 */
	public Double getDefaultEsc() {
		return defaultEsc;
	}
	/**
	 * @param defaultEsc the defaultEsc to set
	 */
	public void setDefaultEsc(Double defaultEsc) {
		this.defaultEsc = defaultEsc;
	}
	/**
	 * @return the techLevel
	 */
	public String getTechLevel() {
		return techLevel;
	}
	/**
	 * @param techLevel the techLevel to set
	 */
	public void setTechLevel(String techLevel) {
		this.techLevel = techLevel;
	}
	
	/**
	 * @return the winRate
	 */
	public String getWinRate() {
		return winRate;
	}
	/**
	 * @param winRate the winRate to set
	 */
	public void setWinRate(String winRate) {
		this.winRate = winRate;
	}
	/**
	 * @return the roundedPriceDefaultEsc
	 */
	public int getRoundedPriceDefaultEsc() {
		return roundedPriceDefaultEsc;
	}
	/**
	 * @param roundedPriceDefaultEsc the roundedPriceDefaultEsc to set
	 */
	public void setRoundedPriceDefaultEsc(int roundedPriceDefaultEsc) {
		this.roundedPriceDefaultEsc = roundedPriceDefaultEsc;
	}
	/**
	 * @return the manualOverrideEsc
	 */
	public int getManualOverrideEsc() {
		return manualOverrideEsc;
	}
	/**
	 * @param manualOverrideEsc the manualOverrideEsc to set
	 */
	public void setManualOverrideEsc(int manualOverrideEsc) {
		this.manualOverrideEsc = manualOverrideEsc;
	}
	/**
	 * @return the publishPriceEscNewCatalog
	 */
	public int getPublishPriceEscNewCatalog() {
		return publishPriceEscNewCatalog;
	}
	/**
	 * @param publishPriceEscNewCatalog the publishPriceEscNewCatalog to set
	 */
	public void setPublishPriceEscNewCatalog(int publishPriceEscNewCatalog) {
		this.publishPriceEscNewCatalog = publishPriceEscNewCatalog;
	}
	/**
	 * @return the finalRepairEsc
	 */
	public int getFinalRepairEsc() {
		return finalRepairEsc;
	}
	/**
	 * @param finalRepairEsc the finalRepairEsc to set
	 */
	public void setFinalRepairEsc(int finalRepairEsc) {
		this.finalRepairEsc = finalRepairEsc;
	}
	/**
	 * @return the repairType
	 */
	public String getRepairType() {
		return repairType;
	}
	/**
	 * @param repairType the repairType to set
	 */
	public void setRepairType(String repairType) {
		this.repairType = repairType;
	}

}
