/**
 * Copyright (C) 2011 General Electric Company
 * All rights reserved
 */
package ecrd.pricing.form;

/**
 * 
 * @author NGTAPXS
 *
 */
public class ECRDWinRateAnalysis {
	
	private PricePercentTO grossEscalation;
	private PricePercentTO escalationCap;
	private PricePercentTO netPrice;

	public ECRDWinRateAnalysis() {
		grossEscalation = new PricePercentTO();
		escalationCap = new PricePercentTO();
		netPrice = new PricePercentTO();
	}
	
	/**
	 * @return the grossEscalation
	 */
	public PricePercentTO getGrossEscalation() {
		return grossEscalation;
	}
	/**
	 * @param grossEscalation the grossEscalation to set
	 */
	public void setGrossEscalation(PricePercentTO grossEscalation) {
		this.grossEscalation = grossEscalation;
	}
	/**
	 * @return the escalationCap
	 */
	public PricePercentTO getEscalationCap() {
		return escalationCap;
	}
	/**
	 * @param escalationCap the escalationCap to set
	 */
	public void setEscalationCap(PricePercentTO escalationCap) {
		this.escalationCap = escalationCap;
	}
	/**
	 * @return the netPrice
	 */
	public PricePercentTO getNetPrice() {
		return netPrice;
	}
	/**
	 * @param netPrice the netPrice to set
	 */
	public void setNetPrice(PricePercentTO netPrice) {
		this.netPrice = netPrice;
	}

	
}