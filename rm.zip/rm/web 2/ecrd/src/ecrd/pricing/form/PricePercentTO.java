/**
 * Copyright (C) 2011 General Electric Company
 * All rights reserved
 */
package ecrd.pricing.form;

/**
 * 
 * @author NGTAPXS
 *
 */
public class PricePercentTO {

	private Double percentage;
	private Long price;
	
	/**
	 * @return the percentage
	 */
	public Double getPercentage() {
		return percentage;
	}
	
	/**
	 * @param percentage the percentage to set
	 */
	public void setPercentage(Double percentage) {
		this.percentage = percentage;
	}
	
	/**
	 * @return the price
	 */
	public Long getPrice() {
		return price;
	}
	
	/**
	 * @param price the price to set
	 */
	public void setPrice(Long price) {
		this.price = price;
	}
	
	
}
