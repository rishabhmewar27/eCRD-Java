/**
 * Copyright (C) 2011 General Electric Company
 * All rights reserved
 */
package ecrd.pricing.helper;

import java.util.Calendar;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.hssf.util.Region;

import ecrd.pricing.form.ECRDAddEditScenarioForm;
import ecrd.pricing.form.PricePercentTO;

/**
 * 
 * @author 393641
 *
 */
public class ECRDAddEditScenarioExcel {

	private HSSFWorkbook workBook;
	
	public static final String BLANK = "";

	/**
	 * To generate scenario excel file
	 * @param form the ECRDAddEditScenarioForm object
	 * @return excel workbook object
	 * @throws Exception
	 */
	public HSSFWorkbook generatePricingScenarioExcel(final ECRDAddEditScenarioForm form) throws Exception {
		HSSFRow row;
	    HSSFCell cell;
	    HSSFSheet sheet;
	    final HSSFCellStyle headerStyle;
	    final HSSFCellStyle dataStyle;
	    final HSSFCellStyle uncheckedStyle;
	    
	    final String sheetName = "Scenario";
	    int rowCount = 0;
	    short colCount = 0;
	       
	    
	    try {
	       workBook = new HSSFWorkbook();
	       sheet = workBook.createSheet(sheetName);
	       
	       headerStyle = getHeaderStyle();
	       dataStyle = getDataStyle();
	       uncheckedStyle = getUncheckedStyle();
	       
	       setTopRowData(sheet, dataStyle, rowCount++, "Catalog Name ", form.getDefaultCatalog());
	       setTopRowData(sheet, dataStyle, rowCount++, "Project Name ", form.getProjectName());
	       setTopRowData(sheet, dataStyle, rowCount++, "Scenario Name ", form.getScenarioName());


	       // To Show the default escalation fields.
	       if(form.isDefaultEscChkd()) {
	    	   
	    	   setTopRowData(sheet, dataStyle, rowCount++, "Default Escalation ", form.getDefaultEscalation());
	    	   row = sheet.createRow(rowCount++);
	    	   
	    	   setEscValues(sheet, headerStyle, rowCount++, BLANK, "Value Pricing Matrix", BLANK);
		       setEscValues(sheet, headerStyle, rowCount++, BLANK, "Low win", "High win");
		       setEscValues(sheet, uncheckedStyle, rowCount++, "Low Tech (%) ", form.getWinLowLow(),form.getWinLowHigh());
		       setEscValues(sheet, uncheckedStyle, rowCount++, "Medium Tech (%) ", form.getWinLowMed(),form.getWinHighMed());
		       setEscValues(sheet, uncheckedStyle, rowCount++, "High Tech (%) ", form.getWinLowHigh(),form.getWinHighHigh());
		       setTopRowData(sheet, uncheckedStyle, rowCount++, "Low Win (%) ", form.getLowWinPercentage());
	       } else {
	    	   
	    	   setTopRowData(sheet, uncheckedStyle, rowCount++, "Default Escalation ", form.getDefaultEscalation());
	    	   row = sheet.createRow(rowCount++);
	    	   
	    	   setEscValues(sheet, headerStyle, rowCount++, BLANK, "Value Pricing Matrix", BLANK);
		       setEscValues(sheet, headerStyle, rowCount++, BLANK, "Low win","High win");
		       setEscValues(sheet, dataStyle, rowCount++, "Low Tech (%) ", form.getWinLowLow(),form.getWinLowHigh());
		       setEscValues(sheet, dataStyle, rowCount++, "Medium Tech (%) ", form.getWinLowMed(),form.getWinHighMed());
		       setEscValues(sheet, dataStyle, rowCount++, "High Tech (%) ", form.getWinLowHigh(),form.getWinHighHigh());
		       setTopRowData(sheet, dataStyle, rowCount++, "Low Win (%) ", form.getLowWinPercentage());
	       }

	       // To add Saudi discount if catalog name is 'GE90'
	       if(null != form.getDefaultCatalog() && form.getDefaultCatalog().toUpperCase().equals("GE90")) {
	    	   setTopRowData(sheet, dataStyle, rowCount++, "Saudi Discount (%) ", form.getSaudiDiscount());
	       }
	       
		   row = sheet.createRow(rowCount++);
	       row = sheet.createRow(rowCount++);
	       
           /* =============================================================
	        * To add Internal summary
	        * =============================================================
	        */
	       {
	    	   colCount = 0;
	           row = sheet.createRow(rowCount++);
	           cell = row.createCell(colCount++);
	           cell.setCellStyle(headerStyle);
	           cell.setCellValue("INTERNAL SUMMARY");
	           
	           cell = row.createCell(colCount++);
	           cell.setCellStyle(headerStyle);
	           
	           cell = row.createCell(colCount++);
	           cell.setCellStyle(headerStyle);
	           
	           sheet.addMergedRegion( new Region(rowCount - 1, (short) 0, (rowCount - 1), (short)2) );
	           //sheet.addMergedRegion( new CellRangeAddress(rowCount - 1, rowCount - 1, 0, 2) );//A14:C14
	       }
	       
	       {
	    	   colCount = 0;
	    	   row = sheet.createRow(rowCount++);
	           
	           cell = row.createCell(colCount++);
	           cell.setCellStyle(headerStyle);
	           cell.setCellValue(BLANK);
	           
	           cell = row.createCell(colCount++);
	           cell.setCellStyle(headerStyle);
	           cell.setCellValue("% of "+ (form.getPrctgOfYear()));
	           
	           cell = row.createCell(colCount++);
	           cell.setCellStyle(headerStyle);
	           cell.setCellValue("$");
	       }
	       
	       
	       setExcelRow(sheet, dataStyle, "Gross Price Realization", form.getInternalSummary().getGrossPriceRealization(),	rowCount++);
	       setExcelRow(sheet, dataStyle, "Escalation Caps", 		form.getInternalSummary().getEscalationCap(), 			rowCount++);
	       setExcelRow(sheet, dataStyle, "Net Price Realization", 	form.getInternalSummary().getNetPriceRealization(), 	rowCount++);
	       setExcelRow(sheet, dataStyle, "CSA Elimination", 		form.getInternalSummary().getCsaElimination(), 			rowCount++);
	       // To add Saudi discount if catalog name is 'GE90'
	       if(null != form.getDefaultCatalog() && form.getDefaultCatalog().toUpperCase().equals("GE90")) {
	    	   setExcelRow(sheet, dataStyle, "Saudi Discount (%) ", form.getInternalSummary().getSaudiRagNet(),				rowCount++);
	       }
	       setExcelRow(sheet, dataStyle, "Net GEES Price Realization", form.getInternalSummary().getGessPriceRealization(), rowCount++);
	       setExcelRow(sheet, dataStyle, "Volume Realization", 		form.getInternalSummary().getVolumeRealization(), 		rowCount++);
	       setExcelRow(sheet, dataStyle, "Net GEES Realization", 	form.getInternalSummary().getGessRealization(), 		rowCount++);

	       
	       row = sheet.createRow(rowCount++);
	       row = sheet.createRow(rowCount++);
	       
	       /* =============================================================
	        * To add External summary
	        * =============================================================
	        */
	       {
	    	   colCount = 0;
	           row = sheet.createRow(rowCount++);
	           cell = row.createCell(colCount++);
	           cell.setCellStyle(headerStyle);
	           cell.setCellValue("EXTERNAL SUMMARY");

	           cell = row.createCell(colCount++);
	           cell.setCellStyle(headerStyle);
	           
	           cell = row.createCell(colCount++);
	           cell.setCellStyle(headerStyle);
	           
	           sheet.addMergedRegion( new Region(rowCount - 1, (short) 0, (rowCount - 1), (short)2) );
	           //sheet.addMergedRegion( new CellRangeAddress(rowCount - 1, rowCount - 1, 0, 2) );//A25:C25
	       }
	       
	       {
	    	   colCount = 0;
	    	   row = sheet.createRow(rowCount++);
	           
	           cell = row.createCell(colCount++);
	           cell.setCellStyle(headerStyle);
	           cell.setCellValue(BLANK);
	           
	           cell = row.createCell(colCount++);
	           cell.setCellStyle(headerStyle);
	           cell.setCellValue("% of "+ (form.getPrctgOfYear()));
	           
	           cell = row.createCell(colCount++);
	           cell.setCellStyle(headerStyle);
	           cell.setCellValue("$");
	       }	       
	       
	       
	       setExcelRow(sheet, dataStyle, "Gross Price Realization", form.getExternalSummary().getGrossPriceRealization(), rowCount++);
	       setExcelRow(sheet, dataStyle, "Escalation Caps", 		form.getExternalSummary().getEscalationCap(), 		  rowCount++);
	       setExcelRow(sheet, dataStyle, "Price Subtotal", 			form.getExternalSummary().getPriceSubTotal(), 		  rowCount++);
	       setExcelRow(sheet, dataStyle, "Volume Realization", 		form.getExternalSummary().getVolumeRealization(), 	  rowCount++);
	       setExcelRow(sheet, dataStyle, "Net External Realization", form.getExternalSummary().getExternalRealization(),  rowCount++);
	       
	       row = sheet.createRow(rowCount++);
	       row = sheet.createRow(rowCount++);
	       
	       
	       /* =============================================================
	        * To add WIN RATE ANALYSIS 
	        * =============================================================
	        */
	       {
	    	   colCount = 0;
	           row = sheet.createRow(rowCount++);
	           cell = row.createCell(colCount++);
	           cell.setCellStyle(headerStyle);
	           cell.setCellValue("WIN RATE ANALYSIS");

	           cell = row.createCell(colCount++);
	           cell.setCellStyle(headerStyle);
	           
	           cell = row.createCell(colCount++);
	           cell.setCellStyle(headerStyle);
	           
	           sheet.addMergedRegion( new Region(rowCount - 1, (short) 0, (rowCount - 1), (short)2) );
	           //sheet.addMergedRegion( new CellRangeAddress(rowCount - 1, rowCount - 1, 0, 2) );//A34:C34
	       }
	       
	       {
	    	   colCount = 0;
	    	   row = sheet.createRow(rowCount++);
	           
	           cell = row.createCell(colCount++);
	           cell.setCellStyle(headerStyle);
	           cell.setCellValue(BLANK);
	           
	           cell = row.createCell(colCount++);
	           cell.setCellStyle(headerStyle);
	           cell.setCellValue("% ");
	           
	           cell = row.createCell(colCount++);
	           cell.setCellStyle(headerStyle);
	           cell.setCellValue("$");
	       }	       
	       
	       
	       setExcelRow(sheet, dataStyle, "Gross Escalation", form.getWinRateAnalysis().getGrossEscalation(), rowCount++);
	       setExcelRow(sheet, dataStyle, "Escalation Caps", form.getWinRateAnalysis().getEscalationCap(), rowCount++);
	       setExcelRow(sheet, dataStyle, "Net Price", form.getWinRateAnalysis().getNetPrice(), rowCount++);
	       
	       // to resize the first column
//	       sheet.autoSizeColumn(0); 
//	       sheet.autoSizeColumn(1); 
	       sheet.setDefaultColumnWidth((short)20);

	    } finally {
	       sheet=null;
	       
	    }
	    
	    
	    return workBook;
	}

	/**
	 * Method to add top scenario information rows
	 * @param sheet
	 * @param dataStyle
	 * @param rowCount
	 * @param key
	 * @param val
	 */
	private void setTopRowData(final HSSFSheet sheet, final HSSFCellStyle dataStyle, 
			final int rowCount, final String key, final Object val) {
		short colCount = 0;
		HSSFRow row = sheet.createRow(rowCount);
		HSSFCell cell = row.createCell(colCount++);
		cell.setCellStyle(dataStyle);
		cell.setCellValue(key);
       
		cell = row.createCell(colCount++);
		cell.setCellStyle(dataStyle);
		this.setCellValue(cell, val);
	}


	/**
	 * 
	 * @param sheet
	 * @param dataStyle
	 * @param rowCount
	 * @param techLvl
	 * @param lowWin
	 * @param highWin
	 */
	private void setEscValues(final HSSFSheet sheet, final HSSFCellStyle dataStyle,
			final int rowCount, final String techLvl, final Object lowWin, final Object highWin) {
		short colCount = 0;
		HSSFRow row = sheet.createRow(rowCount);
		HSSFCell cell = row.createCell(colCount++);
		cell.setCellStyle(dataStyle);
		cell.setCellValue(techLvl);
       
		cell = row.createCell(colCount++);
		cell.setCellStyle(dataStyle);
		this.setCellValue(cell, lowWin);
		
		cell = row.createCell(colCount++);
		cell.setCellStyle(dataStyle);
		this.setCellValue(cell, highWin);
	}


	/**
	 * 
	 * @param cell
	 * @param val
	 */
	private void setCellValue(final HSSFCell cell, final Object val) {
		if(val == null ) {
			cell.setCellValue(BLANK);
		} else if(val instanceof String ) {
			cell.setCellValue(val.toString());
		} else if (val instanceof Double) {
			cell.setCellValue(((Double) val).doubleValue());
		} else if(val instanceof Long ) {
			cell.setCellValue(((Long) val).doubleValue());
		}
	}
	
	/**
	 * 
	 * @param wbSheet
	 * @param styleObj
	 * @param labelVal
	 * @param percent
	 * @param price
	 * @param rowCount
	 */
	private void setExcelRow(final HSSFSheet wbSheet, final HSSFCellStyle styleObj,
			final String label, final PricePercentTO val,  final int rowCount) {
		short colCount = 0;
		HSSFRow sheetRow = wbSheet.createRow(rowCount);


		HSSFCell cell = sheetRow.createCell(colCount++);
		cell.setCellStyle(styleObj);
		this.setCellValue(cell, label);

		cell = sheetRow.createCell(colCount++);
		cell.setCellStyle(styleObj);
		this.setCellValue(cell, val.getPercentage());

		cell = sheetRow.createCell(colCount++);
		cell.setCellStyle(styleObj);
		this.setCellValue(cell, val.getPrice());
	}

	/**
	 * 
	 * @return the style of header.
	 */
	private HSSFCellStyle getHeaderStyle() {
		HSSFFont font = workBook.createFont();
        font.setFontName(HSSFFont.FONT_ARIAL);
   	    font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
   	    font.setFontHeightInPoints((short) 10);
    
   	    HSSFCellStyle style = workBook.createCellStyle();
   	    style.setFont(font);
   	    style.setAlignment(HSSFCellStyle.ALIGN_CENTER);

   	    
   	    style.setFillForegroundColor(HSSFColor.GREY_50_PERCENT.index);
        style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
        
        
//      style.setBorderBottom(CellStyle.BORDER_THIN);
//      style.setBottomBorderColor(HSSFColor.BLACK.index);
//      style.setBorderLeft(CellStyle.BORDER_THIN);
//      style.setLeftBorderColor(HSSFColor.BLACK.index);
//      style.setBorderRight(CellStyle.BORDER_THIN);
//      style.setRightBorderColor(HSSFColor.BLACK.index);
//      style.setBorderTop(CellStyle.BORDER_THIN);
//      style.setTopBorderColor(HSSFColor.BLACK.index);
      
      
      style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
      style.setBottomBorderColor(HSSFColor.BLACK.index);
      style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
      style.setLeftBorderColor(HSSFColor.BLACK.index);
      style.setBorderRight(HSSFCellStyle.BORDER_THIN);
      style.setRightBorderColor(HSSFColor.BLACK.index);
      style.setBorderTop(HSSFCellStyle.BORDER_THIN);
      style.setTopBorderColor(HSSFColor.BLACK.index);
        
        style.setWrapText(false);
        
        return style;
        
	}
	
	/**
	 * 
	 * @return the style of header.
	 */
	private HSSFCellStyle getDataStyle() {
		HSSFFont font = workBook.createFont();
        font.setFontName(HSSFFont.FONT_ARIAL);
        font.setFontHeightInPoints((short) 10);
   
        HSSFCellStyle style = workBook.createCellStyle();
        style.setFont(font);
        
//        style.setBorderBottom(CellStyle.BORDER_THIN);
//        style.setBottomBorderColor(HSSFColor.BLACK.index);
//        style.setBorderLeft(CellStyle.BORDER_THIN);
//        style.setLeftBorderColor(HSSFColor.BLACK.index);
//        style.setBorderRight(CellStyle.BORDER_THIN);
//        style.setRightBorderColor(HSSFColor.BLACK.index);
//        style.setBorderTop(CellStyle.BORDER_THIN);
//        style.setTopBorderColor(HSSFColor.BLACK.index);
        
        
        style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        style.setBottomBorderColor(HSSFColor.BLACK.index);
        style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        style.setLeftBorderColor(HSSFColor.BLACK.index);
        style.setBorderRight(HSSFCellStyle.BORDER_THIN);
        style.setRightBorderColor(HSSFColor.BLACK.index);
        style.setBorderTop(HSSFCellStyle.BORDER_THIN);
        style.setTopBorderColor(HSSFColor.BLACK.index);
        
        
        style.setWrapText(false);
        
        return style;
	}
	
	/**
	 * 
	 * @return the style of header.
	 */
	private HSSFCellStyle getUncheckedStyle() {
		HSSFFont font = workBook.createFont();
        font.setFontName(HSSFFont.FONT_ARIAL);
        font.setFontHeightInPoints((short) 10);
   
        HSSFCellStyle style = workBook.createCellStyle();
        style.setFont(font);

   	    style.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
        style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
        
//        style.setBorderBottom(CellStyle.BORDER_THIN);
//        style.setBottomBorderColor(HSSFColor.BLACK.index);
//        style.setBorderLeft(CellStyle.BORDER_THIN);
//        style.setLeftBorderColor(HSSFColor.BLACK.index);
//        style.setBorderRight(CellStyle.BORDER_THIN);
//        style.setRightBorderColor(HSSFColor.BLACK.index);
//        style.setBorderTop(CellStyle.BORDER_THIN);
//        style.setTopBorderColor(HSSFColor.BLACK.index);
        
        
        style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        style.setBottomBorderColor(HSSFColor.BLACK.index);
        style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        style.setLeftBorderColor(HSSFColor.BLACK.index);
        style.setBorderRight(HSSFCellStyle.BORDER_THIN);
        style.setRightBorderColor(HSSFColor.BLACK.index);
        style.setBorderTop(HSSFCellStyle.BORDER_THIN);
        style.setTopBorderColor(HSSFColor.BLACK.index);
        
        
        style.setWrapText(false);
        
        return style;
	}
	

	
}
