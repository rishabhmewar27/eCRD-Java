/**
 * Copyright (C) 2011 General Electric Company
 * All rights reserved
 */
package ecrd.pricing.helper;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import ecrd.common.eCRDCommand;
import ecrd.pricing.bo.ECRDAddEditScenarioBo;
import ecrd.pricing.form.DomainValuesTO;
import ecrd.pricing.form.ECRDAddEditScenarioForm;
import ecrd.pricing.form.ECRDEditProjectForm;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDUtil;
import ecrd.biz.*;
import geae.office.spreadsheet.excel.GEAEExcelWorkbook;

/**
 *
 * @author NGTAPXS
 *
 */
public class ECRDAddEditScenarioHelper implements eCRDCommand {
	private static final Logger LOGGER = Logger.getLogger("ECRDAddEditScenarioHelper.class");
	private static final long serialVersionUID = 1L;

	private ECRDAddEditScenarioForm addEditProjectForm;

	private ECRDAddEditScenarioBo addEditProjectBO;

	public ECRDAddEditScenarioHelper()
	{
		this.addEditProjectForm = new ECRDAddEditScenarioForm();
		this.addEditProjectBO = new ECRDAddEditScenarioBo();

	}


//	@Override
	public String perform(HttpServletRequest request) throws Exception {
		String strReturnURL = "";
		String strScreenAction = "";
		HttpSession session = request.getSession();


		try {
			strScreenAction = eCRDUtil.verifyNull(request.getParameter("hdnScreenAction"));
			addEditProjectForm.setMessage("");// to reset message initially

			if ((eCRDConstants.getActionId("eCRD_SCENARIO_DEFAULT_DATA")).equals(strScreenAction)) {

				// Flow to get default win matrix values.
				addEditProjectForm.clear();
				String projectName = request.getParameter("projectName");
				String projectId = request.getParameter("projectId");
				String catalogName = request.getParameter("txtCatalogName");

				if((catalogName == null || catalogName.equalsIgnoreCase("")) && (session.getAttribute("catalogName") != null)){
					catalogName = session.getAttribute("catalogName").toString();
				}

				session.setAttribute("projectId", projectId);
				session.setAttribute("projectName", projectName);
				session.setAttribute("catalogName", catalogName);

				this.addEditProjectForm.setProjectId(Integer.valueOf(projectId));
				this.addEditProjectForm.setProjectName(projectName);

				this.addEditProjectBO.getDefaultValues(this.addEditProjectForm);
		///		System.out.println();
				//session.setAttribute("chkdFlag", addEditProjectForm.isDefaultEscChkd());
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-pricingAddEditScenario";

			} else if ((eCRDConstants.getActionId("eCRD_EDIT_SCENARIO")).equals(strScreenAction)) {

				String defaultEscChkd = request.getParameter("defaultEscChkd");
				this.addEditProjectForm.setDefaultEscChkd("on".equals(defaultEscChkd) ? true : false);
				// To handle edit scenario event from edit project tab. Flow to get calculated output.
				addEditProjectForm.clear();

				String projectName = request.getParameter("projectName");
				String projectId = request.getParameter("projectId");
				String scenarioId = request.getParameter("catalog");
				String scenarioName = request.getParameter("scenarioName");
				String catalogName = request.getParameter("txtCatalogName");

				if((projectName == null || projectName.equalsIgnoreCase(""))
						&& (session.getAttribute("projectName") != null)) {
					projectName = session.getAttribute("projectName").toString();
				}
				if((scenarioId == null || scenarioId.equalsIgnoreCase(""))
						&& (session.getAttribute("scenarioId") != null)){
					scenarioId = (session.getAttribute("scenarioId").toString());
				}
				if((scenarioName == null || scenarioName.equalsIgnoreCase(""))
						&& (session.getAttribute("scenarioName") != null)){
					scenarioName = session.getAttribute("scenarioName").toString();
				}
				if((projectId == null || projectId.equalsIgnoreCase(""))
						&& (session.getAttribute("projectId") != null)){
					projectId = session.getAttribute("projectId").toString();
				}
				if((catalogName == null || catalogName.equalsIgnoreCase(""))
						&& (session.getAttribute("catalogName") != null)){
					catalogName = session.getAttribute("catalogName").toString();
				}

				session.setAttribute("projectId", projectId);
				session.setAttribute("scenarioId", scenarioId);
				session.setAttribute("projectName", projectName);
				session.setAttribute("scenarioName", scenarioName);
				session.setAttribute("catalogName", catalogName);


				this.addEditProjectForm.setProjectId(Integer.valueOf(projectId));
				this.addEditProjectForm.setProjectName(projectName);
				this.addEditProjectForm.setScenarioId(Integer.valueOf(scenarioId));
				this.addEditProjectForm.setScenarioName(scenarioName);

				populateForm(request, this.addEditProjectForm);

				this.addEditProjectBO.getScenarionValues(this.addEditProjectForm);
				//session.setAttribute("chkdFlag", addEditProjectForm.isDefaultEscChkd());
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-pricingAddEditScenario";

			} else if ((eCRDConstants.getActionId("eCRD_SCENARIO_SAVE")).equals(strScreenAction)) {
				// Flow to edit scenario and get calculated output.

				String defaultEscChkd = request.getParameter("defaultEscChkd");
				this.addEditProjectForm.setDefaultEscChkd("on".equals(defaultEscChkd) ? true : false);
				this.addEditProjectForm.setSaudiDiscount(eCRDUtil.verifyDoubleObj(request.getParameter("saudiDiscount")));
				populateForm(request, this.addEditProjectForm);


				if(null == addEditProjectForm.getScenarioId()) {
					String scenarioName = request.getParameter("ScenarioName");
					// Check for special characters.
					if(eCRDUtil.checkSplChars(eCRDUtil.verifyNull(scenarioName))) {
						this.addEditProjectForm.setScenarioName(eCRDUtil.verifyNull(scenarioName));
						// to create a new scenario
						addEditProjectBO.createScenario(this.addEditProjectForm);
						//session.setAttribute("chkdFlag", addEditProjectForm.isDefaultEscChkd());
						session.setAttribute("scenarioId", addEditProjectForm.getScenarioId());
						session.setAttribute("scenarioName", scenarioName);
					}
				} else {
					session.setAttribute("projectId", addEditProjectForm.getProjectId());
					session.setAttribute("scenarioId", addEditProjectForm.getScenarioId());
					session.setAttribute("projectName", addEditProjectForm.getProjectName());
					session.setAttribute("scenarioName", addEditProjectForm.getScenarioName());
					// to update an existing scenario
					this.addEditProjectBO.reCalculateScenario(this.addEditProjectForm);
					///session.setAttribute("chkdFlag", addEditProjectForm.isDefaultEscChkd());
				}
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-pricingAddEditScenario";

			} else if ((eCRDConstants.getActionId("eCRD_SCENARIO_DELETE")).equals(strScreenAction)) {
				// Flow to delete scenario and get output message.
				this.addEditProjectBO.deleteScenario(this.addEditProjectForm);

				ECRDEditProjectForm editProject=(ECRDEditProjectForm)eCRDUtil.getFromSessionApp(request,"editProjectForm");
				List scnTemp  = (List) editProject.getMapDrpDwn().get("scnList");


				if(scnTemp != null ) {
					int count = scnTemp.size();
					DomainValuesTO scnTmp = null;
					if (count!=0) {
						for (int i = 0; i < count; i++) {

							scnTmp = (DomainValuesTO) scnTemp.get(i);
							if ((scnTmp.getName().equalsIgnoreCase(addEditProjectForm.getScenarioName()))) {
								scnTemp.remove(i);
								count--;
							}
						}
					}
				}

				addEditProjectForm.clear();
				session.setAttribute("scenarioName", "");
				session.setAttribute("scenarioId", null);

				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-pricingViewModifyProject";

			} else if ((eCRDConstants.getActionId("eCRD_SCENARIO_FINALIZE")).equals(strScreenAction)) {
				// Flow to finalize scenario.

				String futureEffectiveDate=request.getParameter("hdnFutureDate");
				GEAEExcelWorkbook workBook=this.addEditProjectBO.finalizeScenario(this.addEditProjectForm,futureEffectiveDate);

				 System.out.println("********************************************************************* from db workBook="+workBook+"futureEffectiveDate="+futureEffectiveDate);
        		   eCRDUtil.loadInSession(request, "workBook",workBook);
        		  System.out.println("********************************************************************* workBook loaded in session***************");

                 addEditProjectForm.clear();
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-pricingViewModifyProject";

			} else if((eCRDConstants.getActionId("eCRD_REPAIR_DETAILS_APPLY")).equals(strScreenAction)) {
				String manualOverrideEsc = request.getParameter("manualOverrideEsc");
				String repairSeqId = (String) request.getSession().getAttribute("repairSeqId");
				addEditProjectBO.applyToRepair(addEditProjectForm, repairSeqId, manualOverrideEsc);
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-pricingAddEditScenario";

			}

			eCRDUtil.loadInSession(request, "editScenarioForm", this.addEditProjectForm);

		} catch (Exception exp) {
			LOGGER.info("Error Message :" + exp.getMessage());
			throw exp;
		}

		return strReturnURL;

	}

	/**
	 *
	 * @param req
	 * @param form
	 * @return
	 */
	private boolean populateForm(final HttpServletRequest req, final ECRDAddEditScenarioForm form) {
		if (form.isDefaultEscChkd()) {
			form.setDefaultEscalation(eCRDUtil.verifyDoubleObj(req.getParameter("defaultEsc")));
		} else {
			form.setWinHighHigh(eCRDUtil.verifyDoubleObj(req.getParameter("winHighHigh")));
			form.setWinHighMed(eCRDUtil.verifyDoubleObj(req.getParameter("winHighMed")));
			form.setWinHighLow(eCRDUtil.verifyDoubleObj(req.getParameter("winHighLow")));
			form.setWinLowHigh(eCRDUtil.verifyDoubleObj(req.getParameter("winLowHigh")));
			form.setWinLowMed(eCRDUtil.verifyDoubleObj(req.getParameter("winLowMed")));
			form.setWinLowLow(eCRDUtil.verifyDoubleObj(req.getParameter("winLowLow")));
			form.setLowWinPercentage(eCRDUtil.verifyDoubleObj(req.getParameter("lowWinPercentage")));
		}

		return true;
	}

	}
