/**
 * Copyright (C) 2011 General Electric Company
 * All rights reserved
 */
package ecrd.pricing.helper;


import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

import ecrd.common.eCRDCommand;
import ecrd.pricing.bo.ECRDAddProjectBo;
import ecrd.pricing.form.ECRDAddProjectForm;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDUtil;
/**
 * 
 * @author NGTAPXS
 *
 */
public class ECRDAddProjectHelper implements eCRDCommand {
	
	private static final long serialVersionUID = 5121481739592343741L;
	private static final Logger LOGGER = Logger.getLogger("ECRDAddProjectHelper.class");
	private final  ECRDAddProjectForm addProjectForm;
	
	
	public ECRDAddProjectHelper()
	{
		this.addProjectForm = new ECRDAddProjectForm();
	}


	//@Override
	public String perform(HttpServletRequest request) throws Exception {
		ECRDAddProjectBo projectBo = new ECRDAddProjectBo();
		String strAction = eCRDUtil.verifyNull(request.getParameter("hdnScreenAction"));
		String strCont = "";
		eCRDUtil.removeFromSessionApp(request, "addProjectForm");
		try
		{

			if ("".equals(strAction))
			{
				// To populate the Engine Module List
				eCRDUtil.clearSession(request);
				strCont = eCRDConstants.STRCONTJSP + "ecrd-pricingAddProject";
			}
			else if ((eCRDConstants.getActionId("eCRD_CREATE_PROJECT")).equals(strAction))
			{
				// Check for special characters.
				if(eCRDUtil.checkSplChars(eCRDUtil.verifyNull(request.getParameter("txtProjectName")))) {
					
					addProjectForm.setProjectName(eCRDUtil.verifyNull(request.getParameter("txtProjectName")));
					addProjectForm.setDefaultCaltalog(eCRDUtil.verifyNull(request.getParameter("catalogSelect")));
					addProjectForm.setMeteroStartDate(eCRDUtil.verifyNull(request.getParameter("meteroStartDate")));
					addProjectForm.setMeteroEndDate(eCRDUtil.verifyNull(request.getParameter("meteroEndDate")));
					addProjectForm.setCsaShopVisit(eCRDUtil.verifyInt(
							(eCRDUtil.verifyNull(request.getParameter("csaShopVisit")))));
					addProjectForm.setWwShopVisit((eCRDUtil.verifyInt(
							(eCRDUtil.verifyNull(request.getParameter("wwShopVisit"))))));
					addProjectForm.setTmShopVisit(eCRDUtil.verifyInt(
							(eCRDUtil.verifyNull(request.getParameter("tmShopVisit")))));
					addProjectForm.setExternalShopVisit(eCRDUtil.verifyInt(
							(eCRDUtil.verifyNull(request.getParameter("extShopVisit")))));
					addProjectForm.setAvgDiscount(new Double (eCRDUtil.verifyDouble(
							(eCRDUtil.verifyNull(request.getParameter("avgDiscount"))))));
					addProjectForm.setAnnualFactor(new Double(eCRDUtil.verifyDouble(
							(eCRDUtil.verifyNull(request.getParameter("annualFactor"))))));
					
					projectBo.addProjectBo(addProjectForm);
				
					if(eCRDUtil.contains(addProjectForm.getErrorMessage(), "Project Added Successfully"))
					{
						
					strCont = eCRDConstants.STRCONTJSP + "ecrd-pricingViewModifyProject";
					}
					else if(!(eCRDUtil.contains(addProjectForm.getErrorMessage(),"Project Added Successfully")))
					{
						strCont = eCRDConstants.STRCONTJSP + "ecrd-pricingAddProject";
					}
				} else {
					strCont = eCRDConstants.STRCONTJSP + "ecrd-pricingAddProject";
				}
				
			}
			
			else if ((eCRDConstants.getActionId("eCRD_PROJECT_LIST")).equals(strAction))
		      {
				
				addProjectForm.setMeteroStartDate(eCRDUtil.verifyNull(request.getParameter("meteroStartDate")));
				addProjectForm.setMeteroEndDate(eCRDUtil.verifyNull(request.getParameter("meteroEndDate")));
				addProjectForm.setCopyExistingProject(eCRDUtil.verifyNull(request.getParameter("copyExistingProject")));
				addProjectForm.setCsaShopVisit(eCRDUtil.verifyInt(
						(eCRDUtil.verifyNull(request.getParameter("csaShopVisit")))));
				addProjectForm.setTmShopVisit(eCRDUtil.verifyInt(
						(eCRDUtil.verifyNull(request.getParameter("tmShopVisit")))));
				addProjectForm.setExternalShopVisit(eCRDUtil.verifyInt(
						(eCRDUtil.verifyNull(request.getParameter("externalShopVisit")))));
				addProjectForm.setAvgDiscount(new Double(eCRDUtil.verifyDouble
						((eCRDUtil.verifyNull(request.getParameter("avgDiscount"))))));
				addProjectForm.setAnnualFactor(new Double(eCRDUtil.verifyDouble
						((eCRDUtil.verifyNull(request.getParameter("annualFactor"))))));
				addProjectForm.setWwShopVisit((eCRDUtil.verifyInt
						((eCRDUtil.verifyNull(request.getParameter("wwShopVisit"))))));
				
				addProjectForm.setMeteroStartDate(eCRDUtil.verifyNull(request.getParameter("meteroStartDate")));
				addProjectForm.setMeteroEndDate(eCRDUtil.verifyNull(request.getParameter("metreoEndDate")));
				projectBo.getProjectList(addProjectForm);
				projectBo.getCatalogList(addProjectForm);
				addProjectForm.setProjectName("");
				addProjectForm.setDefaultCaltalog("");
				addProjectForm.setCopyExistingProject("no");
				addProjectForm.setIsExisting("no");
				
				strCont = eCRDConstants.STRCONTJSP + "ecrd-pricingAddProject";
				
				 eCRDUtil.loadInSessionApp(request, "addProjectForm", addProjectForm);
			}
			else if ((eCRDConstants.getActionId("eCRD_PROJECT_DETAILS")).equals(strAction) 
					&& request.getParameter("checkbox").equalsIgnoreCase("on"))
		      {
				addProjectForm.setProjectId(Integer.parseInt(request.getParameter("projectList")));
				projectBo.fetchProjectDetailsBo(addProjectForm);
					addProjectForm.setCopyExistingProject("yes");
					addProjectForm.setProjectName("");
					addProjectForm.setIsExisting("yes");
				strCont = eCRDConstants.STRCONTJSP + "ecrd-pricingAddProject";
			}
			else if ((eCRDConstants.getActionId("eCRD_PROJECT_DETAILS")).equals(strAction) 
					&& !request.getParameter("checkbox").equalsIgnoreCase("on"))
		      {
				addProjectForm.setProjectId(Integer.parseInt(request.getParameter("projectList")));
				projectBo.fetchProjectDetailsBo(addProjectForm);
				strCont = eCRDConstants.STRCONTJSP + "ecrd-pricingAddProject";
			}
			  
		}	
	      catch(Exception exp)
	      {
	    	  LOGGER.info("Exception Occured:" + exp.getMessage());
	      }
	      
	      eCRDUtil.loadInSessionApp(request, "addProjectForm", addProjectForm);
		return strCont;
	}
}
