/**
 * Copyright (C) 2011 General Electric Company
 * All rights reserved
 */
package ecrd.pricing.helper;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import ecrd.common.eCRDBusinessBean;
import ecrd.common.eCRDCommand;
import ecrd.common.eCRDDataBean;
import ecrd.pricing.bo.ECRDDefaultEscCapBo;
import ecrd.pricing.form.ECRDDefaultEscCapForm;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDUtil;
import geae.dao.GEAEResultSet;
import geae.util.format.GEAETag;

/**
 * 
 * @author NGTAPXS
 *
 */
public class ECRDDefaultEscalationCapHelper implements eCRDCommand
{
	private static final long serialVersionUID = -1310396413877727977L;

	private final  ECRDDefaultEscCapForm escForm;
	
	private ECRDDefaultEscCapBo escBo = new ECRDDefaultEscCapBo();
	
	public ECRDDefaultEscalationCapHelper()
	{
		this.escForm = new ECRDDefaultEscCapForm();
	}
	public String perform(HttpServletRequest request) throws Exception {
		String strCont = "";
		String strAction = eCRDUtil.verifyNull(request.getParameter("hdnScreenAction"));
		
		if ((eCRDConstants.getActionId("eCRD_ESCALATION_CAP")).equals(strAction))
	      {
			
			  escForm.setErrorMessage("");
			  escForm.setEscCap(null);
			  escForm.setEngineMdl(null);
			  escForm.setCustomer(null);
			  escBo.getEscCapBo(escForm);
			  getCustomerEscalationCap(request);
			  strCont = eCRDConstants.STRCONTJSP + "ecrd-pricingSetDefaultEscCap";
			  		
	      }
		if ((eCRDConstants.getActionId("eCRD_ESCALATION_CAP_UPT")).equals(strAction))
	      {
			
			escForm.setCustomer(request.getParameter("catalog"));
			escForm.setEngineMdl(request.getParameter("engineModel"));
			escForm.setEscCap((request.getParameter("txtEscalationCap")));
			//s ret_type_pattern type_pattern.id_pattern)
			 //ret_type_pattern type_pattern.id_pattern) ret_type_pattern type_pattern.id_pattern)
			  escBo.updateEscCapBo(escForm);
			  getCustomerEscalationCap(request);
			  strCont = eCRDConstants.STRCONTJSP + "ecrd-pricingSetDefaultEscCap";
			  		
	      }
		if ((eCRDConstants.getActionId("eCRD_GET_ENGINE_MODELS")).equals(strAction))
	      {
			
			escForm.setCustomer(request.getParameter("catalog"));
			
			//s ret_type_pattern type_pattern.id_pattern)
			 //ret_type_pattern type_pattern.id_pattern) ret_type_pattern type_pattern.id_pattern)
			  escForm.setEngineMdl("");
			  escBo.getEngineModelsBo(escForm);
			  //getCustomerEscalationCap(request);
			  strCont = eCRDConstants.STRCONTJSP + "ecrd-pricingSetDefaultEscCap";
			  		
	      }
		
		if ((eCRDConstants.getActionId("eCRD_GET_ENGINE_MODELS")).equals(strAction))
	      {
			
			escForm.setCustomer(request.getParameter("catalog"));
			
			//s ret_type_pattern type_pattern.id_pattern)
			 //ret_type_pattern type_pattern.id_pattern) ret_type_pattern type_pattern.id_pattern)
			  escBo.getEngineModelsBo(escForm);
			  //getCustomerEscalationCap(request);
			  strCont = eCRDConstants.STRCONTJSP + "ecrd-pricingSetDefaultEscCap";
			  		
	      }
		
		if ((eCRDConstants.getActionId("eCRD_GET_ESC_CAP")).equals(strAction))
	      {
			
			escForm.setCustomer(request.getParameter("catalog"));
			escForm.setEngineMdl(request.getParameter("engineModel"));
			
			//s ret_type_pattern type_pattern.id_pattern)
			 //ret_type_pattern type_pattern.id_pattern) ret_type_pattern type_pattern.id_pattern)
			  escBo.getEscalationCapBo(escForm);
			  //getCustomerEscalationCap(request);
			  strCont = eCRDConstants.STRCONTJSP + "ecrd-pricingSetDefaultEscCap";
			  		
	      }
		
		  eCRDUtil.loadInSessionApp(request, "escForm", escForm);
		return  strCont;
	}
	
	public void getCustomerEscalationCap(HttpServletRequest request) throws Exception
	{

		eCRDBusinessBean objeCRDBusinessBean = null;
		GEAEResultSet rsFormatted;
		GEAEResultSet rsEngineCatalog;
		eCRDDataBean objeCRDDataBean = null;
		String strActionId = "";
		ArrayList arrLstInParam = null;
		//String strReport ="";
		
		try
		{
			
				

			///rsFormatted = new GEAEResultSet();
			///rsEngineCatalog = new GEAEResultSet();
			objeCRDDataBean = new eCRDDataBean();
			arrLstInParam = new ArrayList();

			objeCRDBusinessBean = new eCRDBusinessBean();
			strActionId = eCRDConstants.getActionId("eCRD_GET_CUSTOMER_ESC");
			
			
			rsEngineCatalog = objeCRDBusinessBean.populateComponentList(strActionId, arrLstInParam);//new
			//strReport = eCRDUtil.verifyNull(request.getParameter("hdnReport"));
			rsFormatted = formatCustomerEscResultSet(rsEngineCatalog);//new
			objeCRDDataBean.setCache(rsFormatted);
			eCRDUtil.loadInSession(request, "eCRDCustomerEsc", objeCRDDataBean);
		}
		finally
		{

			rsEngineCatalog = null;
			rsFormatted = null;
			objeCRDDataBean = null;
			objeCRDBusinessBean = null;
			strActionId = null;
			arrLstInParam = null;

		}

	}
	
	
	private GEAEResultSet formatCustomerEscResultSet(GEAEResultSet rsSearchResults) throws Exception
	{

		GEAEResultSet rsFormattedRS = null;
		ArrayList arrlstTemp = null;
		GEAETag geAETag = null;
		String escCap = "";
		String rsEscCap;
		
		try
		{
			rsFormattedRS = new GEAEResultSet();
			rsSearchResults.setCurrentRow(0);
			while (rsSearchResults.next())
			{

				arrlstTemp = new ArrayList();
				
				geAETag = new GEAETag( rsSearchResults.getString("engine_model"),rsSearchResults.getString("engine_model"));
				arrlstTemp.add(geAETag);
				geAETag = new GEAETag( rsSearchResults.getString("customer_name"),rsSearchResults.getString("customer_name"));
				arrlstTemp.add(geAETag);
				
				rsEscCap = rsSearchResults.getString("esc_cap");
				if (null == rsEscCap && "".equals(rsEscCap)) {
					escCap = "";
				} else if (("0").equals(rsEscCap)) {
					escCap = "N";
				} else {
					escCap = rsEscCap;
				}
				
				geAETag = new GEAETag(escCap,escCap);
				arrlstTemp.add(geAETag);

				rsFormattedRS.addRow(arrlstTemp);
				arrlstTemp = null;
				geAETag = null;
			}
			rsFormattedRS.setColumnHeading(1, "Engine Model");
			rsFormattedRS.setColumnHeading(2, "Customer Name");
			rsFormattedRS.setColumnHeading(3, "Escalation Cap");
			
			rsFormattedRS.sort(1, true);
			return rsFormattedRS;
		}
		finally
		{
			rsFormattedRS = null;
			arrlstTemp = null;
			geAETag = null;
		}

	}
}