/**
 * Copyright (C) 2011 General Electric Company
 * All rights reserved
 */
package ecrd.pricing.helper;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import ecrd.common.eCRDCommand;
import ecrd.pricing.bo.ECRDDefaultPricingAllEngineBo;
import ecrd.pricing.form.ECRDDefaultPricingAllEngineForm;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDUtil;
/**
 * 
 * @author NGTAPXS
 *
 */
public class ECRDDefaultPricingAllEngineHelper implements eCRDCommand
{
	private static final long serialVersionUID = 1L;
	private List attributeNameList;
	
	private ECRDDefaultPricingAllEngineForm pricingDefaultForm;
	
	private ECRDDefaultPricingAllEngineBo allEngineBo;
	
	public ECRDDefaultPricingAllEngineHelper() {
		this.pricingDefaultForm = new ECRDDefaultPricingAllEngineForm();
		allEngineBo = new ECRDDefaultPricingAllEngineBo();
		
		attributeNameList = new ArrayList();
		attributeNameList.add("defaultEsc");
		attributeNameList.add("winLowLow");
		attributeNameList.add("winHighLow");
		attributeNameList.add("winLowMed");
		attributeNameList.add("winHighMed");
		attributeNameList.add("winLowHigh");
		attributeNameList.add("winHighHigh");
		attributeNameList.add("lowWinPercentage");
	}

//	@Override
	public String perform(HttpServletRequest request) throws Exception {
		String strReturnURL = "";
		String strScreenAction = "";
		
			strScreenAction = eCRDUtil.verifyNull(request.getParameter("hdnScreenAction"));
			
			if ("".equals(strScreenAction) || (eCRDConstants.getActionId("eCRD_DEFAULT_ALL_DATA")).equals(strScreenAction)) {
				
				this.allEngineBo.getDefualtPricingAllEngine(this.pricingDefaultForm);
				eCRDUtil.loadInSession(request, "pricingDefaultForm", this.pricingDefaultForm);
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-pricingSetDefault";
				
			} else if((eCRDConstants.getActionId("eCRD_DEFAULT_ALL_SAVE")).equals(strScreenAction)) {
				
				boolean isPopulated = populateForm(request, pricingDefaultForm );
				if(isPopulated) {
					this.allEngineBo.saveDefualtPricingAllEngine(this.pricingDefaultForm);
					eCRDUtil.loadInSession(request, "pricingDefaultForm", this.pricingDefaultForm);
				}
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-pricingSetDefault";
			}
			
		
			return strReturnURL;
		
		
		
	}

	/**
	 * 
	 * @param req
	 * @param form
	 * @return
	 */
	private boolean populateForm(final HttpServletRequest req, final ECRDDefaultPricingAllEngineForm form) {
		for(int cntr = 0;cntr < attributeNameList.size(); cntr++){
			String name = attributeNameList.get(cntr).toString();
			if(req.getParameter(name) == null || "".equals(req.getParameter(name)) || 
					eCRDUtil.verifyDoubleObj(req.getParameter(name)) == null) {
				return false;
			}
		}
		form.setDefaultEscalation(eCRDUtil.verifyDoubleObj(req.getParameter("defaultEsc")));
		form.setWinHighHigh(eCRDUtil.verifyDoubleObj(req.getParameter("winHighHigh")));
		form.setWinHighMed(eCRDUtil.verifyDoubleObj(req.getParameter("winHighMed")));
		form.setWinHighLow(eCRDUtil.verifyDoubleObj(req.getParameter("winHighLow")));
		form.setWinLowHigh(eCRDUtil.verifyDoubleObj(req.getParameter("winLowHigh")));
		form.setWinLowMed(eCRDUtil.verifyDoubleObj(req.getParameter("winLowMed")));
		form.setWinLowLow(eCRDUtil.verifyDoubleObj(req.getParameter("winLowLow")));
		form.setLowWinPercentage(eCRDUtil.verifyDoubleObj(req.getParameter("lowWinPercentage")));
		
		return true;
	}

}