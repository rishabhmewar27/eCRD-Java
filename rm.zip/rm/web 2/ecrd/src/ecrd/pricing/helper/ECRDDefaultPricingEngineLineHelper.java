/**
 * Copyright (C) 2011 General Electric Company
 * All rights reserved
 */
package ecrd.pricing.helper;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import ecrd.common.eCRDCommand;
import ecrd.pricing.bo.ECRDDefaultPricingEngineLineBo;
import ecrd.pricing.form.ECRDDefaultPricingAllEngineForm;
import ecrd.pricing.form.ECRDDefaultPricingEngineLineForm;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDUtil;

/**
 * 
 * @author NGTAPXS
 *
 */
public class ECRDDefaultPricingEngineLineHelper implements eCRDCommand {
	
	/**
	 * 
	 */
	///private static final Logger LOGGER = Logger.getLogger("ECRDDefaultPricingEngineLineHelper.class");
	private static final long serialVersionUID = 1L;

	private List attributeNameList;
	
	private ECRDDefaultPricingEngineLineForm form;
	
	private ECRDDefaultPricingEngineLineBo engineLineBo;
	
	public ECRDDefaultPricingEngineLineHelper() {
		this.form = new ECRDDefaultPricingEngineLineForm();
		engineLineBo = new ECRDDefaultPricingEngineLineBo();
		
		attributeNameList = new ArrayList();
		attributeNameList.add("defaultEsc");
		attributeNameList.add("winLowLow");
		attributeNameList.add("winHighLow");
		attributeNameList.add("winLowMed");
		attributeNameList.add("winHighMed");
		attributeNameList.add("winLowHigh");
		attributeNameList.add("winHighHigh");
		attributeNameList.add("lowWinPercentage");
	}
	
	
//	@Override
	public String perform(final HttpServletRequest request) throws Exception {
		String strReturnURL = "";
		String strScreenAction = "";
		
			strScreenAction = eCRDUtil.verifyNull(request.getParameter("hdnScreenAction"));
			
			if ("".equals(strScreenAction)) {
				this.engineLineBo.getEngineLine(this.form);
				eCRDUtil.loadInSession(request, "pricingDefaultEngLineForm", this.form);
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-pricingSetDefaultEngineLine";

			} else if ((eCRDConstants.getActionId("eCRD_DEFAULT_ENG_LN_DATA")).equals(strScreenAction)) {
				String engineLine = request.getParameter("hdnEngLine");
				this.form.setEngineLine(engineLine);
				
				this.engineLineBo.getDefualtPricingEngineLine(this.form);
				eCRDUtil.loadInSession(request, "pricingDefaultEngLineForm", this.form);
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-pricingSetDefaultEngineLine";

			} else if((eCRDConstants.getActionId("eCRD_DEFAULT_ENG_LN_SAVE")).equals(strScreenAction)) {
				
				boolean isPopulated = populateForm(request, form );
				if(isPopulated) {
					this.engineLineBo.saveDefaultEngLineValues(this.form);
					eCRDUtil.loadInSession(request, "pricingDefaultEngLineForm", this.form);
				}
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-pricingSetDefaultEngineLine";
			}
		return strReturnURL;
	}


	/**
	 * 
	 * @param req
	 * @param form
	 * @return
	 */
	private boolean populateForm(final HttpServletRequest req, final ECRDDefaultPricingAllEngineForm formNew) {
		for(int i = 0;i < attributeNameList.size(); i++){
			String name = attributeNameList.get(i).toString();
			if(req.getParameter(name) == null || "".equals(req.getParameter(name)) ||
					eCRDUtil.verifyDoubleObj(req.getParameter(name)) == null) {
				return false;
			}
		}
		formNew.setDefaultEscalation(eCRDUtil.verifyDoubleObj(req.getParameter("defaultEsc")));
		formNew.setWinHighHigh(eCRDUtil.verifyDoubleObj(req.getParameter("winHighHigh")));
		formNew.setWinHighMed(eCRDUtil.verifyDoubleObj(req.getParameter("winHighMed")));
		formNew.setWinHighLow(eCRDUtil.verifyDoubleObj(req.getParameter("winHighLow")));
		formNew.setWinLowHigh(eCRDUtil.verifyDoubleObj(req.getParameter("winLowHigh")));
		formNew.setWinLowMed(eCRDUtil.verifyDoubleObj(req.getParameter("winLowMed")));
		formNew.setWinLowLow(eCRDUtil.verifyDoubleObj(req.getParameter("winLowLow")));
		formNew.setLowWinPercentage(eCRDUtil.verifyDoubleObj(req.getParameter("lowWinPercentage")));
		
		return true;
	}

}