/**
 * Copyright (C) 2011 General Electric Company
 * All rights reserved
 */
package ecrd.pricing.helper;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;


import ecrd.common.eCRDCommand;
import ecrd.pricing.bo.ECRDEditProjectBo;
import ecrd.pricing.form.ECRDEditProjectForm;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDUtil;
/**
 * 
 * @author NGTAPXS
 *
 */
public class ECRDEditProjectHelper implements eCRDCommand
{
	private static final long serialVersionUID = -5578982084663737006L;

	private ECRDEditProjectForm editProjectForm;
	
	String strCont = "";
	public ECRDEditProjectHelper()
	{
		this.editProjectForm = new ECRDEditProjectForm();
	}


	//@Override
	public String perform(HttpServletRequest request) throws Exception {
		
		ECRDEditProjectBo projectBo = new ECRDEditProjectBo();
		
		HttpSession session = request.getSession();
		
		String strAction = eCRDUtil.verifyNull(request.getParameter("hdnScreenAction"));
		  if ((eCRDConstants.getActionId("eCRD_PROJECT_LIST")).equals(strAction))
	      {
			  
			  session.setAttribute("projectId", Integer.valueOf("0"));
				session.setAttribute("scenarioId", Integer.valueOf("0"));
				session.setAttribute("projectName", "");
				session.setAttribute("scenarioName", "");
				editProjectForm.setBlank(true);
			  		projectBo.editExistingProject(editProjectForm);
			  		editProjectForm.setProjectName("");
	      }
		
		  if ((eCRDConstants.getActionId("eCRD_PROJECT_DETAILS")).equals(strAction))
	      {
			String projectId = "";
			projectId =	request.getParameter("projectList");
			if(projectId == null)projectId="";
			 if(projectId.equalsIgnoreCase("")) {
				editProjectForm.setProjectId(Integer.parseInt(session.getAttribute("projectId").toString()));
			}
			 else if((projectId) != null) {
					editProjectForm.setProjectId(Integer.parseInt(projectId));
					session.setAttribute("scenarioName","");
				}
			
			projectBo.fetchProjectDetailsBo(editProjectForm);
		  }
		 
		  
			if ((eCRDConstants.getActionId("eCRD_UPDATE_PROJECT")).equals(strAction))
			{
				String catalogName = request.getParameter("txtCatalogName");
				if((catalogName == null || catalogName.equalsIgnoreCase("")) &&(session.getAttribute("catalogName")!=null)){
					catalogName = session.getAttribute("catalogName").toString();
				}
				session.setAttribute("catalogName", catalogName);
				
				editProjectForm.setProjectName(request.getParameter("projectName"));
				editProjectForm.setProjectId(Integer.parseInt(request.getParameter("projectList")));
				editProjectForm.setDefaultCaltalog(eCRDUtil.verifyNull(request.getParameter("txtCatalogName")));
				editProjectForm.setMeteroStartDate(eCRDUtil.verifyNull(request.getParameter("meteroStartDate")));
				editProjectForm.setMeteroEndDate(eCRDUtil.verifyNull
						(request.getParameter("meteroEndDate")));
				editProjectForm.setCsaShopVisit(eCRDUtil.verifyInt(
						(eCRDUtil.verifyNull(request.getParameter("csaShopVisit")))));
				editProjectForm.setWwShopVisit((eCRDUtil.verifyInt(
						(eCRDUtil.verifyNull(request.getParameter("wwShopVisit"))))));
				editProjectForm.setTmShopVisit(eCRDUtil.verifyInt(
						(eCRDUtil.verifyNull(request.getParameter("tmShopVisit")))));
				editProjectForm.setExternalShopVisit(eCRDUtil.verifyInt(
						(eCRDUtil.verifyNull(request.getParameter("extShopVisit")))));
				editProjectForm.setAvgDiscount(new Double(eCRDUtil.verifyDouble(
						(eCRDUtil.verifyNull(request.getParameter("avgDiscount"))))));
				editProjectForm.setAnnualFactor(new Double(eCRDUtil.verifyDouble(
						(eCRDUtil.verifyNull(request.getParameter("annualFactor"))))));
				editProjectForm.setSaudiRag((eCRDUtil.verifyInt((eCRDUtil.verifyNull(request.getParameter("txtSaudiRag"))))));
				
				

				projectBo.editProjectBo(editProjectForm);
				ECRDEditProjectForm sessForm = (ECRDEditProjectForm)eCRDUtil.getFromSessionApp(request, "editProjectForm");
				if(sessForm.getMapDrpDwn().get("scnList") != null)
					editProjectForm.getMapDrpDwn().put("scnList",sessForm.getMapDrpDwn().get("scnList"));
				strCont = eCRDConstants.STRCONTJSP + "ecrd-pricingViewModifyProject";
			} 
			
			if ((eCRDConstants.getActionId("eCRD_PRCNGCOMP_LIST")).equals(strAction))
			{
				strCont = eCRDConstants.STRCONTJSP + "ecrd-pricingModifyProject";
				//return strCont;
			}
			
			  if ((eCRDConstants.getActionId("eCRD_DELETE_PROJECT")).equals(strAction))
		      {
					session.setAttribute("catalogName", "");
				  editProjectForm.setProjectId(Integer.parseInt(request.getParameter("projectList")));
				  		projectBo.deleteExistingProject(editProjectForm);
				  		if(editProjectForm.getErrorMessage().indexOf("blue")>0)
				  		{
				  		session.setAttribute("scenarioName", "");
						session.setAttribute("projectName", "");
				  		}
		      }
			  if ((eCRDConstants.getActionId("eCRD_CREATE_PROJECT")).equals(strAction))
				{

					editProjectForm.setProjectName(eCRDUtil.verifyNull(request.getParameter("txtProjectName")));
					editProjectForm.setDefaultCaltalog(eCRDUtil.verifyNull(request.getParameter("catalogSelect")));
					editProjectForm.setMeteroStartDate(eCRDUtil.verifyNull
							(request.getParameter("meteroStartDate")));
					editProjectForm.setMeteroEndDate(eCRDUtil.verifyNull(request.getParameter("meteroEndDate")));
					editProjectForm.setCsaShopVisit(eCRDUtil.verifyInt(
							(eCRDUtil.verifyNull(request.getParameter("csaShopVisit")))));
					editProjectForm.setWwShopVisit((eCRDUtil.verifyInt
							((eCRDUtil.verifyNull(request.getParameter("wwShopVisit"))))));
					editProjectForm.setTmShopVisit(eCRDUtil.verifyInt(
							(eCRDUtil.verifyNull(request.getParameter("tmShopVisit")))));
					editProjectForm.setExternalShopVisit(eCRDUtil.verifyInt(
							(eCRDUtil.verifyNull(request.getParameter("extShopVisit")))));
					editProjectForm.setAvgDiscount(new Double(eCRDUtil.verifyDouble(
							(eCRDUtil.verifyNull(request.getParameter("avgDiscount"))))));
					editProjectForm.setAnnualFactor(new Double(eCRDUtil.verifyDouble(
							(eCRDUtil.verifyNull(request.getParameter("annualFactor"))))));
					editProjectForm.setSaudiRag((eCRDUtil.verifyInt((eCRDUtil.verifyNull(request.getParameter("saudiRag"))))));
					session.setAttribute("projectId", null);
					session.setAttribute("scenarioId", null);
					session.setAttribute("projectName", null);
					session.setAttribute("scenarioName", null);
					projectBo.addProjectBo(editProjectForm);
				}
		strCont = eCRDConstants.STRCONTJSP + "ecrd-pricingViewModifyProject";
		
		 eCRDUtil.loadInSessionApp(request, "editProjectForm", editProjectForm);
		return strCont;
	}
	}
