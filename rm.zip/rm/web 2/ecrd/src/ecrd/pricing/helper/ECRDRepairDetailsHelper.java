/**
 * Copyright (C) 2011 General Electric Company
 * All rights reserved
 */
package ecrd.pricing.helper;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import ecrd.common.eCRDCommand;
import ecrd.pricing.bo.ECRDRepairDetailsBo;
import ecrd.pricing.form.ECRDRepairDetailsForm;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDUtil;
/**
 * 
 * @author NGTAPXS
 *
 */
public class ECRDRepairDetailsHelper implements eCRDCommand {

	private static final long serialVersionUID = 1L;

	private ECRDRepairDetailsForm form;

	private ECRDRepairDetailsBo repairDetailsBO;
	public ECRDRepairDetailsHelper() {
		form = new ECRDRepairDetailsForm();
		repairDetailsBO = new ECRDRepairDetailsBo();
	}

	public String perform(HttpServletRequest request) throws Exception {
		String strReturnURL = "";
		String strScreenAction = "";
		HttpSession session = request.getSession();

			strScreenAction = eCRDUtil.verifyNull(request.getParameter("hdnScreenAction"));
			
			if((eCRDConstants.getActionId("eCRD_REPAIR_DETAILS_GET_DATA")).equals(strScreenAction)){
				String projectId = session.getAttribute("projectId").toString();
				String scenarioId = session.getAttribute("scenarioId").toString();
				String repairSeqId = "";
				
				if( request.getParameter("repairSeqId") != null)
					repairSeqId = request.getParameter("repairSeqId").toString();
				if(session.getAttribute("repairSeqId") != null && repairSeqId.equalsIgnoreCase(""))
					repairSeqId = session.getAttribute("repairSeqId").toString();
				
				session.setAttribute("repairSeqId", repairSeqId);
			
				
				form.setProjectId(Integer.valueOf(projectId));
				form.setScenarioId(Integer.valueOf(scenarioId));
				form.setRepairSeq(Integer.valueOf(repairSeqId));
				form.setHdnScreenAction(strScreenAction);
				
				repairDetailsBO.getRepairDetails(form);
				eCRDUtil.loadInSession(request, "repairDetailsForm", this.form);
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-pricingRepairDetails";
				
			} else if((eCRDConstants.getActionId("eCRD_REPAIR_DETAILS_SAVE_DATA")).equals(strScreenAction)) {
				String manualOverrideEsc = request.getParameter("manualOverrideEsc");
				form.setManualOverrideEsc(eCRDUtil.verifyInt(manualOverrideEsc));
				
				repairDetailsBO.saveRepairDetails(form);
				eCRDUtil.loadInSession(request, "repairDetailsForm", this.form);
				strReturnURL = eCRDConstants.STRCONTJSP + "ecrd-pricingRepairDetails";
				
			}

		
		return strReturnURL;
	}

}
