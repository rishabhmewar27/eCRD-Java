/**
 *  Project     :   eCRD
 *  Program     :   eCRDControllerServlet.java
 *  Author      :   Patni Team
 *  Date        :   October 2004
 *  Security    :   Classified/Unclassified
 *  Restrictions:   GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 *
 *  ****************************************************
 *  *  Copyright(Year) with all rights reserved        *
 *  *          General Electric Company                *
 *  ****************************************************
 *  Description:   Description of the class
 *
 *
 *  Revision Log  (mm/dd/yy initials description)
 *  --------------------------------------------------------
 *  Patni Team    October 02, 2004  Created
 *
 */
package ecrd.servlet.controller;
import java.io.IOException;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import ecrd.common.eCRDCommand;
import ecrd.common.eCRDCommandFactory;
import ecrd.biz.eCRDUser;
import ecrd.common.eCRDXMLParser;
import ecrd.util.eCRDConstants;
import ecrd.util.eCRDUtil;
import ecrd.exception.eCRDException;
import ecrd.common.eCRDScreenAccessParser;

/**
 *  This Servlet is used to transfer control to requested URI. Controller
 *  instantiates appropriate helper depending on hidden Screen Name and calls
 *  its Execute method & takes target URI path from Execute method of helper.
 *
 * @author     Patni Team
 * @created    December 13, 2003
 */
public class eCRDControllerServlet extends HttpServlet
{
	private ServletContext ctxServlet = null;
	private eCRDCommandFactory objCommandFactory = null;

	/**
	 *  <pre>
	 * This method is invoked by the container when a servlet is initialized
	 * @param  config  Description of the Parameter
	 */
	public void init(ServletConfig config)
	{
		ctxServlet = config.getServletContext();
	}

	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException
	{
		doPost(req, res);
	}

	/**
	 *  <pre>
	 * This method is invoked by the container when a request arrives
	 * @param  request                        Description of the Parameter
	 * @param  response                       Description of the Parameter
	 * @exception  ServletException           Description of the Exception
	 * @exception  IOException                Description of the Exception
	 * @throws  ServletException,IOException  </pre>
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		eCRDCommand objeCRDCommand = null;
		String strForwardURL = null;
		String strAFSPath = "";
		String strBasePath = "";
		RequestDispatcher objDispatcher = null;
		String strScreenName = null;
		HttpSession session = null;
		
		HashMap hmUserAccess = null;
		eCRDUser objeCRDUser = null;

		try
		{
			session = request.getSession();
			if (session.isNew())
			{
				session.invalidate();
				throw new Exception("eCRD_SESSION");
			}
			if ("".equals(eCRDUtil.getAFSPath()) || eCRDUtil.getAFSPath() == null)
			{
				strAFSPath = (String) session.getAttribute("xmlpath");
				eCRDUtil.setAFSPath(strAFSPath);
			}
			if ("".equals(eCRDUtil.getBasePath()) || eCRDUtil.getBasePath() == null)
			{
				strBasePath = (String) session.getAttribute("basePath");
				eCRDUtil.setBasePath(strBasePath);
			}

			if (!eCRDConstants.isXmlParsed())
			{
				eCRDXMLParser objXmlParser = new eCRDXMLParser(eCRDUtil.getAFSPath() + eCRDConstants.STRCONSTXML, false);
				eCRDConstants.setAll(objXmlParser);
			}
			objeCRDUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser");
			if (objeCRDUser == null)
			{
				objeCRDUser = new eCRDUser(eCRDUtil.verifyNull(request.getRemoteUser()));
				eCRDUtil.loadInSessionApp(request, "objeCRDUser", objeCRDUser);
			}

			
			hmUserAccess = (HashMap) eCRDUtil.getFromSessionApp(request, "eCRDUserAccess");
			if (hmUserAccess == null)
			{
				hmUserAccess = eCRDScreenAccessParser.parseeCRDScreenAccess();
				eCRDUtil.loadInSessionApp(request, "eCRDUserAccess", hmUserAccess);
			}

			strScreenName = request.getParameter("hdnScreenName");
			objCommandFactory = eCRDCommandFactory.getInstance();
            objeCRDCommand = (eCRDCommand) session.getAttribute(strScreenName);
			if (objeCRDCommand == null)
			{
				objeCRDCommand = objCommandFactory.getValue(strScreenName);
				session.setAttribute(strScreenName, objeCRDCommand);
			}
            strForwardURL = objeCRDCommand.perform(request);
			objDispatcher = ctxServlet.getRequestDispatcher(strForwardURL);
			objDispatcher.forward(request, response);
		}
		catch(eCRDException objeCRDException)
		{
			objeCRDException.setObjExp((Exception)objeCRDException);
			request.setAttribute("objeCRDException", objeCRDException);
			strForwardURL = eCRDConstants.STRAPPCONTRLJSP + "?cont=ecrd-error";
			objDispatcher = ctxServlet.getRequestDispatcher(strForwardURL);
			objDispatcher.forward(request, response);
		}
		catch (Exception objExp)
		{
			eCRDException objeCRDException = new eCRDException();
			objExp.printStackTrace();
			objeCRDException.setObjExp(objExp);
			objeCRDException.setExcpId(objExp.toString());
			request.setAttribute("objeCRDException", objeCRDException);
			strForwardURL = eCRDConstants.STRAPPCONTRLJSP + "?cont=ecrd-error";
			objDispatcher = ctxServlet.getRequestDispatcher(strForwardURL);
			objDispatcher.forward(request, response);
		}
		finally
		{
			strForwardURL = null;
		}
	}
}
