/**
 *  Project     :   eCRD
 *  Program     :   eCRDConstants.java
 *  Author      :   Patni Team
 *  Date        :   October 2004
 *  Security    :   Classified/Unclassified
 *  Restrictions:   GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 *
 *  ****************************************************
 *  *  Copyright(Year) with all rights reserved        *
 *  *          General Electric Company                *
 *  ****************************************************
 *  Description:   Description of Class
 *
 *
 *  Revision Log  (mm/dd/yy initials description)
 *  --------------------------------------------------------
 *  Patni Team    October 2004  Created
 *
 */
package ecrd.util;
import java.util.HashMap;
import java.util.StringTokenizer;
import ecrd.common.eCRDXMLParser;
/**
 *  <pre>
 *  This class is used to store the values which will be
 *  constant(will not change) throughout the eCRD application
 * </pre>
 *
 * @author     Patni Team
 * @created    May 20, 2004
 */
public class eCRDConstants
{
	
	/**beginning changes by rishabh mewar **/
		private static HashMap hmRepairInd = null;
		private static HashMap hmCatalogInd = null;
	/**end of changes by rishabh mewar **/
	
	
	private static HashMap hmPaths = null;
	private static HashMap hmGeneral = null;
	public  static HashMap hmException = null;
	private static HashMap hmRoles = null;
	private static HashMap hmMessage = null;
	private static HashMap hmActionIds = null;
	private static HashMap hmTabContRelation = null;
	private static HashMap hmRepairTypes = null;
	private static HashMap hmRepairRefTypes = null;
	private static HashMap hmPriceTypes = null;
	private static HashMap hmRuleLevel = null;
	private static HashMap hmCycClass = null;
	private static HashMap hmPriceListReportOpt = null;
	private static HashMap hmCompRepair = null;
	private static HashMap hmTCRoles = null;
	private static HashMap hmDefaultStartDate =null;
	private static HashMap hmDefaultEndDate = null;
	private static HashMap hmAdhocColumns = null;
	//Added by Bora
	private static HashMap hmEnhancedAdhocColumns = null;
	//End Bora
	private static HashMap hmYear = null;
	/**
	* this boolean variable is used to determine whether Xml is already 
	parsed.
	* if this variable is False then xml will be parsed otherwise it will 
	not be parsed.
	*/
	private static boolean blnXmlParsed = false;
	/**
	 * GENERAL node starts
	 * this can be used to put any general constants which cannot be 
	classified as already
	 * available
	 */
	public static String SAMPLE = "";
	public static String eCRD_DS_ID = "";
	public static String APPLICATION_CODE = "";
	public static String LOGGER_PORTAL_ID = "";
	public static String LOGGER_APP_ID = "";
	public static String ECRD_ADHOC_DEF_SELECTED= null;
	public static String ECRD_ADHOC_DEF_SEQ= null;
	//Added by Bora
	public static String ECRD_ENHANCED_ADHOC_DEF_SELECTED= null;
	public static String ECRD_ENHANCED_ADHOC_DEF_SEQ= null;
	//End Bora
	public static String EXCEL_COLUMN_WIDTH = null; 
	/**
	 * GENERAL node ends
	 */
	/**
	 * Exception node starts
	 * this can be used to put any Exception constants which cannot be 
	classified as already
	 * available
	 */
	public static String eCRD_DATABASE_ERR = "";
	public static String eCRD_NO_DATA = "";
	/**
	 * Exception node ends
	 */
	/** Paths Start */
	/**  Stores the log folder name for hrw application. */
	public static String STR_LOG_FOLDER = "";
	/**
	 *  Stores value "/fw/jsp/appcont.jsp". Used to specify path of the 
	appcont
	 *  controller JSP.
	 */
	public static String STRAPPCONTRLJSP = "";
	/**
	 *  Stores value "/index.jsp". Used to specify path of the index JSP in 
	hrw
	 *  generated mails.
	 */
	public static String STRINDEXJSP = "";
	/**
	 *  Stores value "contloc". Used to specify path of the controller JSP 
	in hrw
	 *  generated mails.
	 */
	public static String STRCONTLOC = "";
	/**
	 *  Stores value "cont". Used to specify the hidden variable cont to 
	submit the
	 *  JSP to the target.
	 */
	public static String STRCONT = "";
	/*Added by Deepa for 
	 * cont value to be appended whil redirecting.*/
	public static String STRCONTJSP = "";
	/**
	 *  Stores value "ecrd/xml/procedure.xml". Used to specify path of the
	 *  procedure xml.
	 */
	public static String STRPROCXML = "";
	/**
	 *  Stores value "ecrd/xml/command.xml". Used to specify path of the 
	command
	 *  xml.
	 */
	public static String STRCOMDXML = "";
	public final static String STRCONSTXML = "ecrd/xml/eCRDConstants.xml";
	
	public static String STRGEIMG = null;
	public static String STRGEIMG_NEW = null;
	public static String STRGEINSPRAFONT = null;
	/**
	 *  Stores value "ecrd/xml/defaultvalues.xml". Used to specify path of 
	the
	 *  defaultvalues xml.
	 */
	public static String STRDEFVALXML = "";
	/**
	 *  Stores value "ecrd/xml/message.xml". Used to specify path of the 
	message
	 *  xml.
	 */
	public static String STRMESGXML = "";
	public static String STRBASECSSPATH = "";
	/**  Path of base js folder*/
	public static String STRBASEJSPATH = "";
	/**  Path of base js folder*/
	public static String STRBASEJSPPATH = "";
	/**  Path of base image folder*/
	public static String STRBASEIMGPATH = "";
	/**  Path of page include.jsp */
	public static String STRPAGEINCL = "";
	/**  eCRD path */
	public static String STRCTRL = "";
	public static String LOGFILE_PATH = "";
	public static String eCRDDWNLOAD = "";
	/** Paths End */
	public static String STRUPLOADPATH = "";
	/** NRCDB Start*/
	//public final static String eCRD_NON_ROW_CACHE_DATA_BEAN =mNonRowCacheFDB";
	/** NRCDB End*/
	public static String STRSCREENACCESSXML = "";
	public static String EXCEL_UPLOAD_PATH = "";
	public static String CSV_DOWNLOAD = "";
	/**  Roles--Start   */
	public static String ROLE_ADMINISTRATOR = "";
	public static String ROLE_TECH_COORD = "";
	public static String ROLE_CSM = "";
	public static String ROLE_GUEST = "";
    public static String ROLE_PMANAGER = "";
	/**  Roles--End   */
    
    /***9292_eCRD_Batch_Download_Upload_Mapping*/
    public static String ROLE_ADMIN = "ADMIN";
    /**End*/
    
	/**  Message--Start   */
	public static String PLEASE_WAIT = "";
	public static String EXCEL_UPLOAD_SUCCESS = "";
	public static String ADD_COMP_SUCC = "";
	public static String ADD_COMP_FAIL = "";
	public static String MODIFY_COMP_SUCC = "";
	public static String MODIFY_COMP_FAIL = "";
	public static String COMP_ALREADY_EXISTS = "";
	public static String MAP_COMP_SUCC = "";
	public static String MAP_COMP_FAIL = "";
	public static String ADD_FACT_SUCC = "";
	public static String MODIFY_FACT_SUCC = "";
	public static String MODIFY_FACT_FAIL = "";
	public static String ADD_FACT_FAIL = "";
	public static String FACT_ALREADY_EXISTS = "";
	public static String DATA_UPLOAD_WITH_WARNING = "";
	/**  Message--End   */
	/**Action list**/
	public static String ACT_ID_USER_INFO = "";
	/**End Action List **/
	/*Row Delimiter value set*/
	public static final String STRROWDELIM = "$";
	/*Column Delimiter Value set*/
	public static final String STRCOLUMNDELIM = "^";
	/*Used to indentify a grouped repair*/
	public static final String STRGROUPREPAIR = "PR";
	/*Used to identify Individual repair*/
	public static final String STRINDIVIDUALREPAIR = "IR";
	/*Used to identify Individual repair*/
	public static final String STRMERGEREPAIR = "MR";
	/*Used to identify Individual repair*/
	public static final String STRSLITREPAIR = "SR";
	
	/*Used to identify Special Individual repair*/
	public static final String STRSPECIALINDIVIDUALREPAIR = "SI";
	
	/*Used to indentify a Special  grouped repair*/
	public static final String STRSPECIALGROUPREPAIR = "SG";
	
	/*Used to indentify wether Associate Event is saved*/
	public static final String STRASSOCIATEEVENTSAVED = "Save";
	
	/*Used to indentify a true value */
	public static final String STRTRUE = "Y";
	public static final String STRFALSE = "N";
	/*Used to fetch data from master table*/
	public static final String STRMASTERDATA = "M";
	/*Used to fetch data from staging table*/
	public static final String STRSTAGINGDATA = "S";
	/*Key to be used while setting/getting the catalog in/from session*/
	public static final String STRCATALOG = "eCRDCatalog";
	/*Used to Get All Site  */
	public static final String STRSITE = "ALL";
	/*Used to check if the catlog type is default*/
	public static final String STRDEFAULTCATALOGTYPE = "D";
	/*Used to check if the catlog type is customer type*/
	public static final String STRCUSTOMERCATALOGTYPE = "C";
	/*Used to fetch engine model code*/
	public static final String STRENGINEMODELCODE = "eCRDEngineModelCode";
	/*Used to fetch engine module code*/
	public static final String STRENGINEMODULECODE = "eCRDEngineModuelCode";
	/*Used to fetch component code*/
	public static final String STRCOMPONENTCODE = "eCRDComponentCode";
	
	//9292_Shyamala Radhakrishnan	
	/*Used to fetch component code*/
	public static final String STRCOMPONENTDESC = "eCRDComponentDesc";
	//end
	
	/*Used to fetch Repair Sequence Id*/
	public static final String STRREPAIRSEQID = "strRepairSeqId";

	/*Used to fetch Repair Type*/
	public static final String STRREPAIRTYPE  = "strRepairType";
	
	
	
	
	/**beginning of changes by rishabh mewar**/
	
	
		/*Used to fetch Catalog Cat Ind*/
		public static final String STRCATLOGCATIND  = "strCatalogInd";
		
		/*Used to fetch Repair Cat Ind*/
		public static final String STRREPAIRCATIND  = "strRepairInd";
		
		/*Used to check if the Catalog Cat Ind is 'GE' */
		public static final String STRCATALOGCATINDGE = "GE";
		
		/*Used to check if the Catalog Cat Ind is 'RPL' */
		public static final String STRCATALOGCATINDRPL = "RPL";
		
		/*Used to check if the Catalog Cat Ind is 'OVH' */
		public static final String STRCATALOGCATINDOVH = "OVH";
		
		/*Used to check if the Catalog Cat Ind is 'ACC' */
		public static final String STRCATALOGCATINDACC = "ACC";
		
		/*Used to check if the Catalog Cat Ind is 'ALL' */
		public static final String STRCATALOGCATINDALL = "ALL";
		
		/*Used to check if the Repair Cat Ind is 'GE' */
		public static final String STRREPAIRCATINDGE = "GE";
		
		/*Used to check if the Repair Cat Ind is 'RPL' */
		public static final String STRREPAIRCATINDRPL = "RPL";
		
		/*Used to check if the Repair Cat Ind is 'OVH' */
		public static final String STRREPAIRCATINDOVH = "OVH";
		
		/*Used to check if the Repair Cat Ind is 'ACC' */
		public static final String STRREPAIRCATINDACC = "ACC";
		
		/*Used to check if the Repair Cat Ind is 'ALL' */
		public static final String STRREPAIRCATINDALL = "ALL";


	/**end of changes by rishabh mewar**/
	
	
	
	
	
	/*Used to check whether component is found or not*/
	public static final String STRCHECKIFCOMPONENTFOUND = "eCRDComponentFound";
	
	/*Used to check if component is not found*/
	public static final String STRCOMPONENTNOTFOUND = "COMPONENT_NOT_FOUND";
	
	/*Used to fetch component modifcation message*/
	public static final String STRCOMPONENTUPDATEDMSG = "eCRDComponentUpdateMsg";
	
	/*Used to differentiate between reports */
	public static final String STRENGREVYIELD = "eCRDENGREVYIELD";
	public static final String STRADHOCREPAIRREP= "eCRDADHOCREPORT";
	//Added by Bora
	public static final String STRENADHOCREPAIRREP= "eCRDENHADHOCREPORT";
	//End Bora
		
	/*Used for Rule Levels*/
	public static final String STRCATALOGLEVEL = "C";
	public static final String STRMODULELEVEL = "M";
	public static final String STRCOMPONENTLEVEL = "CO";
	public static final String STRREPAIRLEVEL = "R";
	public static final String STRCATALOGRULE = "eCRDCatalogRules";
	
	public static final String STRINCREASE = "Increase";
	
	public static final String STRDECREASE = "Decrease";
	
	public static final String STRENGMODELCONST = "Z";
	
	
	public static final String STRPRICECHANGELISTINGREPORTYRL = "PriceChangeListingReportYrly";
	public static final String STRDUMMYSTRING = "^^";
    
    //Started :: Component Excel Header
    
    public static final String STRMODULESEQID  = "Engine Module Seq Id";
    public static final String STRMODULENAME   = "Engine Module";
    public static final String STRCOMPCODE     = "Component Code";
    public static final String STRCOMPDESC     = "Component Description";
    public static final String STRLOCATIONID   = "Location Id";
    public static final String STRLOCATIONNAME = "Location Name";
    public static final String STRPRIMARYSITE  = "Primary Site (Y/N)";
    public static final String STRHIDDENSITE   = "Hidden Site (Y/N)";
    public static final String STRDELETESITE   = "Delete Site (Y/N)";
    
    //Ended   ::  Component Excel Header
    
//Started :: Component Excel Header for eCRDBatchDownloadUploadMapping
    
    public static final String STRMODEL  = "Engine Model";
    public static final String STRMODULE   = "Engine Module";
    public static final String STRCOMCODE     = "Component Code";
    public static final String STRCOMDESC     = "Component Description";
    public static final String STROSBCODE = "OSB Component Code";
    public static final String STRCSITE   = "Site";
    public static final String STRLASTUPDATE  = "Last Updated Date (MM/DD/YYYY)";
    public static final String STRACTIVEID   = "Active Indicator";
    
    public static final String STRMSG = "Errors in the file uploaded are shown below. All rows with valid data are updated in the database.";
    public static final String STRDATAMSG = "EXCEL HAS NO MAPPING DATA TO UPLOAD.";
    public static final String STRLIMITMSG = "EXCEEDED THE MAXIMUM NUMBER OF ROW LIMIT";
    //Ended   ::  Component Excel Header for eCRDBatchDownloadUploadMapping
	
	/**
	 * <pre>
	 * Method to calls all the setter methods
	 * @param objParser <code>eCRDXMLParser</code>
	 * @throws Exception
	 * </pre>
	 */
	public static final void setAll(eCRDXMLParser objParser) throws Exception
	{
		try
		{
			setGenaral(objParser);
			setException(objParser);
			setPaths(objParser);
			setRoles(objParser);
			setMessage(objParser);
			setAction_Ids(objParser);
			setContTabs(objParser);
			setRepairTypes(objParser);
			setRepairRefFormats(objParser);
			setPriceTypes(objParser);
			setRuleLevel(objParser);
			setCycClass(objParser);
			setPriceListReportOpt(objParser);
			// added by deepa to set the Component drop down 
			setCompRepair(objParser);
			//ADDED BY GAYATRI TO SET THE DEFAULT START DATE
			setDefault_StartDate(objParser);
			setDefault_EndDate(objParser); 
			setAdhocColumns(objParser);
			//Added by Bora
			setEnhancedAdhocColumns(objParser);
			//End Bora
			setYear(objParser);
			setXmlParsed(true);
		}
		catch (Exception e)
		{
			throw new Exception("eCRDConstants:setAll(): " + e.toString());
		}
	}
	/**
	 * <pre>
	 * Method to set all the General constants used in eCRD application.
	 * @param objParser <code>eCRDXMLParser</code>
	 * @throws Exception
	 * </pre>
	 */
	private static final void setGenaral(eCRDXMLParser objParser) throws Exception
	{
		hmGeneral = new HashMap();
		try
		{
			hmGeneral = objParser.performParse("GENERAL");
			SAMPLE = (String) hmGeneral.get("SAMPLE");
			APPLICATION_CODE = (String) hmGeneral.get("APPLICATION_CODE");
			eCRD_DS_ID = (String) hmGeneral.get("eCRD_DS_ID");
			LOGGER_PORTAL_ID = (String) hmGeneral.get("LOGGER_PORTAL_ID");
			LOGGER_APP_ID = (String) hmGeneral.get("LOGGER_APP_ID");
			ECRD_ADHOC_DEF_SELECTED = (String) hmGeneral.get("ECRD_ADHOC_DEF_SELECTED");
			ECRD_ADHOC_DEF_SEQ =(String) hmGeneral.get("ECRD_ADHOC_DEF_SEQ");
			//Added by Bora
			ECRD_ENHANCED_ADHOC_DEF_SELECTED = (String) hmGeneral.get("ECRD_ENHANCED_ADHOC_DEF_SELECTED");
			ECRD_ENHANCED_ADHOC_DEF_SEQ =(String) hmGeneral.get("ECRD_ENHANCED_ADHOC_DEF_SEQ");
			//End Bora
			EXCEL_COLUMN_WIDTH = (String)hmGeneral.get("EXCEL_COLUMN_WIDTH");
		}
		catch (Exception e)
		{
			throw new Exception("eCRDConstants:setGenaral(): " + e.toString());
		}
	}
	/**
	 * <pre>
	 * Method to set all the General constants used in eCRD application.
	 * @param objParser <code>eCRDXMLParser</code>
	 * @throws Exception
	 * </pre>
	 */
	private static final void setException(eCRDXMLParser objParser) throws Exception
	{
		hmException = new HashMap();
		try
		{
			hmException = objParser.performParse("EXCEPTION");
			eCRD_DATABASE_ERR = (String) hmException.get("eCRD_DATABASE_ERR");
			eCRD_NO_DATA = (String) hmException.get("eCRD_NO_DATA");
		}
		catch (Exception e)
		{
			throw new Exception("eCRDConstants:setException(): " + e.toString());
		}
	}
	/**
	 * <pre>
	 * Method to get the descriptions of Exceptions used in eCRD application.
	 * @param 	strErrorCode	The code given to the error message
	 * @return 	String			The actual Error message as defined in the 
	eCRDConstants.xml
	 * @throws Exception
	 * </pre>
	 */
	public static final String getException(String strErrorCode) throws Exception
	{
		return eCRDUtil.verifyNull((String) hmException.get(strErrorCode));
	}
	/**
	 * <pre>
	 * Method to set all the Paths used in eCRD application.
	 * @param objParser <code>eCRDXMLParser</code>
	 * @throws Exception
	 * </pre>
	 */
	private static final void setPaths(eCRDXMLParser objParser) throws Exception
	{
		hmPaths = new HashMap();
		try
		{
			hmPaths = objParser.performParse("PATHS");
			STR_LOG_FOLDER = (String) hmPaths.get("LOG_FOLDER_PATH");
			STRAPPCONTRLJSP = (String) hmPaths.get("APPCONTRLJSP");
			STRINDEXJSP = (String) hmPaths.get("INDEXJSP");
			STRCONTLOC = (String) hmPaths.get("CONTLOC");
			STRCONT = (String) hmPaths.get("CONT");
			//Added by Deepa.
			STRCONTJSP = (String) hmPaths.get("CONTJSP");
			STRPROCXML = (String) hmPaths.get("PROCXML");
			STRGEIMG =  (String) hmPaths.get("STRGEIMG");
			//STRGEIMG_NEW =  (String) hmPaths.get("STRGEIMG_NEW");
			//Added by Sachin 
			STRGEIMG_NEW =  (String) hmPaths.get("STRGEIMG");

			STRGEINSPRAFONT =  (String) hmPaths.get("STRGEINSPRAFONT"); 
			STRCOMDXML = (String) hmPaths.get("COMDXML");
			//STRCONSTXML = (String) hmPaths.get("CONSTXML");
			STRDEFVALXML = (String) hmPaths.get("DEFVALXML");
			STRMESGXML = (String) hmPaths.get("MESGXML");
			STRBASECSSPATH = (String) hmPaths.get("BASECSS_PATH");
			STRBASEJSPATH = (String) hmPaths.get("BASEJS_PATH");
			STRBASEJSPPATH = (String) hmPaths.get("BASEJSP_PATH");
			STRBASEIMGPATH = (String) hmPaths.get("BASEIMG_PATH");
			STRPAGEINCL = (String) hmPaths.get("PAGEINCL");
			STRCTRL = (String) hmPaths.get("CTRL");
			STRUPLOADPATH = (String) hmPaths.get("UPLOAD_FILE");
			STRSCREENACCESSXML = (String) hmPaths.get("SCREENACCESSXML");
			LOGFILE_PATH = (String) hmPaths.get("LOGFILE_PATH");
			eCRDDWNLOAD = (String) hmPaths.get("DWNLDCTRL");
			EXCEL_UPLOAD_PATH = (String) hmPaths.get("EXCEL_UPLOAD_PATH");
			CSV_DOWNLOAD = (String) hmPaths.get("CSV_DOWNLOAD");
		}
		catch (Exception e)
		{
			throw new Exception("eCRDConstants:setPaths(): " + e.toString());
		}
	}
	/**
	   * <pre>
	   * Method to set all the Excel Templates used in eCRD application.
	   * @param objParser <code>eCRDXMLParser</code>
	   * @throws Exception
	   * </pre>
	   */
	/**
	 * <pre>
	 * Method to set all the Roles used in eCRD application.
	 * @param objParser <code>eCRDXMLParser</code>
	 * @throws Exception
	 * </pre>
	 */
	private static final void setRoles(eCRDXMLParser objParser) throws Exception
	{
		hmRoles = new HashMap();
		try
		{
			hmRoles = objParser.performParse("ROLES");
			ROLE_ADMINISTRATOR = (String) hmRoles.get("ADMIN");
			ROLE_TECH_COORD = (String) hmRoles.get("COORDINATOR");
			ROLE_CSM = (String) hmRoles.get("CSCMaintenance");
			ROLE_GUEST = (String) hmRoles.get("GUEST");
            ROLE_PMANAGER = (String) hmRoles.get("ProgramManager");
		}
		catch (Exception e)
		{
			throw new Exception("eCRDConstants:setRoles(): " + e.toString());
		}
	}
	/**
	 * <pre>
	 * Method to get all the Roles used in eCRD application.
	 * @param 
	 * @throws
	 * </pre>
	 */
	public static final HashMap getRoles()
	{
		return hmRoles;
	}
	/**
		 * <pre>
		 * Method to get all the Roles used by TC in eCRD application.
		 * @param 
		 * @throws
		 * </pre>
		 */
	public static final HashMap getRolesTC() throws Exception
	{
		HashMap hmTCRoles = null;
		try
		{
			hmTCRoles = new HashMap();
			hmTCRoles.put("COORDINATOR", (String) hmRoles.get("COORDINATOR"));
			hmTCRoles.put("CSCMaintenance", (String) hmRoles.get("CSCMaintenance"));
			hmTCRoles.put("GUEST", (String) hmRoles.get("GUEST"));
			return hmTCRoles;
		}
		catch (Exception e)
		{
			throw new Exception("eCRDConstants:setRoles(): " + e.toString());
		}
	}
	/**
	 * <pre>
	 * Method to set all the paths used in eCRD application.
	 * @param objParser <code>eCRDXMLParser</code>
	 * @throws Exception
	 * </pre>
	 */
	private static final void setMessage(eCRDXMLParser objParser) throws Exception
	{
		hmMessage = new HashMap();
		try
		{
			hmMessage = objParser.performParse("MESSAGE");
			PLEASE_WAIT = (String) hmMessage.get("PLEASE_WAIT");
			EXCEL_UPLOAD_SUCCESS = (String) hmMessage.get("EXCEL_UPLOAD_SUCCESS");
			ADD_COMP_SUCC = (String) hmMessage.get("ADD_COMP_SUCC");
			ADD_COMP_FAIL = (String) hmMessage.get("ADD_COMP_FAIL");
			MODIFY_COMP_SUCC = (String) hmMessage.get("MODIFY_COMP_SUCC");
			MODIFY_COMP_FAIL = (String) hmMessage.get("MODIFY_COMP_FAIL");
			COMP_ALREADY_EXISTS = (String) hmMessage.get("COMP_ALREADY_EXISTS");
			MAP_COMP_SUCC = (String) hmMessage.get("MAP_COMP_SUCC");
			MAP_COMP_FAIL = (String) hmMessage.get("MAP_COMP_FAIL");
			ADD_FACT_SUCC = (String) hmMessage.get("ADD_FACT_SUCC");
			ADD_FACT_FAIL = (String) hmMessage.get("ADD_FACT_FAIL");
			MODIFY_FACT_SUCC = (String) hmMessage.get("MODIFY_FACT_SUCC");
			MODIFY_FACT_FAIL = (String) hmMessage.get("MODIFY_FACT_FAIL");
			FACT_ALREADY_EXISTS = (String) hmMessage.get("FACT_ALREADY_EXISTS");
			DATA_UPLOAD_WITH_WARNING = (String) hmMessage.get("DATA_UPLOAD_WITH_WARNING");
		}
		catch (Exception e)
		{
			throw new Exception("eCRDConstants:setMessage(): " + e.toString());
		}
	}
	/**
	 * <pre>
	 * Method to get the descriptions of Messages used in eCRD application.
	 * @param 	strMsgCode	The code given to the message
	 * @return 	String		The actual Message as defined in the 
	eCRDConstants.xml
	 * @throws Exception
	 * </pre>
	 */
	public static final String getMessage(String strMsgCode) throws Exception
	{
		return eCRDUtil.verifyNull((String) hmMessage.get(strMsgCode));
	}
	/**
	 * <pre>
	 * Method to set all the Action Ids for Procedure call
	 * used in eCRD application.
	 * @param objParser <code>eCRDXMLParser</code>
	 * @throws Exception
	 * </pre>
	 */
	private static final void setAction_Ids(eCRDXMLParser objParser) throws Exception
	{
		hmActionIds = new HashMap();
		try
		{
			hmActionIds = objParser.performParse("ACTION_ID");
		}
		catch (Exception e)
		{
			throw new Exception("eCRDConstants:setAction_Ids(): " + e.toString());
		}
	}
	/**
	 * @return
	 */
	public static boolean isXmlParsed()
	{
		return blnXmlParsed;
	}
	/**
	 * @param b
	 */
	private static void setXmlParsed(boolean b)
	{
		blnXmlParsed = b;
	}
	/**
		 * <pre>
		 * Method to set all the Cont tab relationships for Procedure call
		 * used in eCRD application.
		 * @param objParser <code>eCRDXMLParser</code>
		 * @throws Exception
		 * </pre>
		 */
	private static void setContTabs(eCRDXMLParser objParser) throws Exception
	{
		hmTabContRelation = new HashMap();
		try
		{
			hmTabContRelation = objParser.performParse("CONT_TABS");
		}
		catch (Exception e)
		{
			throw new Exception("eCRDContTabs(): " + e.toString());
		}
	}
	/**
	 * <pre>
	 * Method to get tab index and page url for a con value
	 * used in eCRD application.
	 * Index 0 of the int array is tab index and 1 is page URL which will be 
	string 
	 * @param strCont <code>String</code>
	 * @return intReturnValue <code>int[] </code>
	 * @throws Exception
	 * </pre>
	 */
	public static int[] getTabIndexPageUrl(String strCont) throws Exception
	{
		StringTokenizer strtkn = null;
		String strHmValue = "";
		int[] intReturnValue = null;
		int intCtr = 0;
		try
		{
			intReturnValue = new int[2];
			strHmValue = (String) hmTabContRelation.get(strCont);
			strHmValue = eCRDUtil.verifyNull(strHmValue);
			strtkn = new StringTokenizer(strHmValue, ",");
			if (strtkn.countTokens() != 2)
			{
				throw new Exception("Entry in constants Xml incorect");
			}
			while (strtkn.hasMoreTokens())
			{
				intReturnValue[intCtr] = Integer.parseInt(strtkn.nextToken());
				intCtr++;
			}
			return intReturnValue;
		}
		finally
		{
			strtkn = null;
		}
	}
	/**
	 * <pre>
	 * Method to get Action ID from eCRDConstants.Xml
	 * used in eCRD application.
	 * Key is the tag which is defined in the Action id section of 
	Constants.xml 
	 * @param strKey <code>String</code>
	 * @return String <code>String</code>
	 * @throws Exception
	 * </pre>
	 */
	public static String getActionId(String strKey) throws Exception
	{
		return eCRDUtil.verifyNull((String) hmActionIds.get(strKey));
	}
	/**
	 * <pre>
	 * Method to set list of all Repair Types 
	 * used in eCRD application.
	 * @param objParser <code>eCRDXMLParser</code>
	 * @throws Exception
	 * </pre>
	 */
	private static final void setRepairTypes(eCRDXMLParser objParser) throws Exception
	{
		hmRepairTypes = new HashMap();
		try
		{
			hmRepairTypes = objParser.performParse("REPAIR_TYPES");
		}
		catch (Exception e)
		{
			throw new Exception("eCRDConstants:setRepairTypes(): " + e.toString());
		}
	}
	/**
	 * <pre>
	 * Method to get list of all Repair Types 
	 * used in eCRD application.
	 * @return HashMap
	 * @throws Exception
	 * </pre>
	 */
	public static final HashMap getRepairTypes() throws Exception
	{
		return hmRepairTypes;
	}
	
	
	
	
	/**beginning of changes by rishabh mewar**/
	
	
	
	/**
	 * <pre>
	 * Method to set list of all Repair Cat Ind used in eCRD application.
	 * @param objParser <code>eCRDXMLParser</code>
	 * @throws Exception
	 * </pre>
	 */
	private static final void setRepairInd(eCRDXMLParser objParser) throws Exception
	{
		hmRepairInd = new HashMap();
		try
		{
			hmRepairInd = objParser.performParse("REPAIR_IND");
		}
		catch (Exception e)
		{
			throw new Exception("eCRDConstants:setRepairInd(): " + e.toString());
		}
	}
	
	
	
	/**
	 * <pre>
	 * Method to get list of all Repair Cat Ind used in eCRD application.
	 * @return HashMap
	 * @throws Exception
	 * </pre>
	 */
	public static final HashMap getRepairInd() throws Exception
	{
		return hmRepairInd;
	}
	
	
	
	/**
	 * <pre>
	 * Method to set list of all Catalog Cat Ind used in eCRD application.
	 * @param objParser <code>eCRDXMLParser</code>
	 * @throws Exception
	 * </pre>
	 */
	private static final void setCatalogInd(eCRDXMLParser objParser) throws Exception
	{
		hmCatalogInd = new HashMap();
		try
		{
			hmCatalogInd = objParser.performParse("CATALOG_IND");
		}
		catch (Exception e)
		{
			throw new Exception("eCRDConstants:setCatalogInd(): " + e.toString());
		}
	}
	
	
	
	/**
	 * <pre>
	 * Method to get list of all Repair Cat Ind used in eCRD application.
	 * @return HashMap
	 * @throws Exception
	 * </pre>
	 */
	public static final HashMap getCatalogInd() throws Exception
	{
		return hmCatalogInd;
	}

	
	
	
/**end of changes by rishabh mewar**/
	
	
	
	
	
	/**
	 * <pre>
	 * Method to set list of all Repair Reference Formats
	 * used in eCRD application.
	 * @param objParser <code>eCRDXMLParser</code>
	 * @throws Exception
	 * </pre>
	 */
	private static final void setRepairRefFormats(eCRDXMLParser objParser) throws Exception
	{
		hmRepairRefTypes = new HashMap();
		try
		{
			hmRepairRefTypes = objParser.performParse("REPAIR_REF_FORMATS");
		}
		catch (Exception e)
		{
			throw new Exception("eCRDConstants:setRepairRefFormats(): " + e.toString());
		}
	}
	/**
	 * <pre>
	 * Method to get list of all Repair Types 
	 * used in eCRD application.
	 * @return HashMap
	 * @throws Exception
	 * </pre>
	 */
	public static final HashMap getRepairRefFormats() throws Exception
	{
		return hmRepairRefTypes;
	}
	/**
	 * <pre>
	 * Method to set list of all Price Types
	 * used in eCRD application.
	 * @param objParser <code>eCRDXMLParser</code>
	 * @throws Exception
	 * </pre>
	 */
	private static final void setPriceTypes(eCRDXMLParser objParser) throws Exception
	{
		hmPriceTypes = new HashMap();
		try
		{
			hmPriceTypes = objParser.performParse("PRICE_TYPES");
		}
		catch (Exception e)
		{
			throw new Exception("eCRDConstants:setPriceTypes(): " + e.toString());
		}
	}
	/**
	 * <pre>
	 * Method to get list of all Price Types 
	 * used in eCRD application.
	 * @return HashMap
	 * @throws Exception
	 * </pre>
	 */
	public static final HashMap getPriceTypes() throws Exception
	{
		return hmPriceTypes;
	}
	/**
	 * <pre>
	 * Method to set list of all Rule Levels 
	 * used in eCRD application.
	 * @param objParser <code>eCRDXMLParser</code>
	 * @throws Exception
	 * </pre>
	 */
	private static final void setRuleLevel(eCRDXMLParser objParser) throws Exception
	{
		hmRuleLevel = new HashMap();
		try
		{
			hmRuleLevel = objParser.performParse("RULE_LEVEL");
		}
		catch (Exception e)
		{
			throw new Exception("eCRDConstants:setRuleLevel(): " + e.toString());
		}
	}
	/**
	 * <pre>
	 * Method to get list of all Rule Levels
	 * used in eCRD application.
	 * @return HashMap
	 * @throws Exception
	 * </pre>
	 */
	public static final HashMap getRuleLevel() throws Exception
	{
		return hmRuleLevel;
	}
	/**
	 * <pre>
	 * Method to set list of all Cycle Validation Classes
	 * used in eCRD application.
	 * @param objParser <code>eCRDXMLParser</code>
	 * @throws Exception
	 * </pre>
	 */
	private static final void setCycClass(eCRDXMLParser objParser) throws Exception
	{
		hmCycClass = new HashMap();
		try
		{
			hmCycClass = objParser.performParse("CYC_CLASS");
		}
		catch (Exception e)
		{
			throw new Exception("eCRDConstants:setCycClass(): " + e.toString());
		}
	}
	/**
	 * <pre>
	 * Method to get list of all Cycle Validation Classes
	 * used in eCRD application.
	 * @return HashMap
	 * @throws Exception
	 * </pre>
	 */
	public static final HashMap getCycClass() throws Exception
	{
		return hmCycClass;
	}
	/**
	 * <pre>
	 * Method to set list of options for Price Listing Report
	 * used in eCRD application.
	 * @param objParser <code>eCRDXMLParser</code>
	 * @throws Exception
	 * </pre>
	 */
	private static final void setPriceListReportOpt(eCRDXMLParser objParser) throws Exception
	{
		hmPriceListReportOpt = new HashMap();
		try
		{
			hmPriceListReportOpt = objParser.performParse("PRICE_LIST_REPORT_OPT");
		}
		catch (Exception e)
		{
			throw new Exception("eCRDConstants:setPriceListReportOpt(): " + e.toString());
		}
	}
	/**
	 * <pre>
	 * Method to get list of options for Price Listing Report
	 * used in eCRD application.
	 * @return HashMap
	 * @throws Exception
	 * </pre>
	 */
	public static final HashMap getPriceListReportOpt() throws Exception
	{
		return hmPriceListReportOpt;
	}
	/**
		 * <pre>
		 * Method to set list of all Rule Levels 
		 * used in eCRD application.
		 * @param objParser <code>eCRDXMLParser</code>
		 * @throws Exception
		 * </pre>
		 */
	private static final void setCompRepair(eCRDXMLParser objParser) throws Exception
	{
		hmCompRepair = new HashMap();
		try
		{
			hmCompRepair = objParser.performParse("COMP_REPAIR");
		}
		catch (Exception e)
		{
			throw new Exception("eCRDConstants:setCompRepair(): " + e.toString());
		}
	}
	/**
		 * <pre>
		 * Method to set the Default Start Dates
		 * @param objParser <code>eCRDXMLParser</code>
		 * @throws Exception
		 * </pre>
		 */
		private static final void setDefault_StartDate(eCRDXMLParser objParser) throws Exception
		{
			hmDefaultStartDate = new HashMap();
			try
			{
				hmDefaultStartDate = objParser.performParse("DEFAULT_START_DATE");
			}
			catch (Exception e)
			{
				throw new Exception("eCRDConstants:setDefault_StartDate(): " + e.toString());
			}
		}
	/**
		 * <pre>
		 * Method to get Default Start Dates from eCRDConstants.Xml
		 * used in eCRD application.
		 * Key is the tag which is defined in the Default_Start_Dates section of Constants.xml 
		 * @param strKey <code>String</code>
		 * @return String <code>String</code>
		 * @throws Exception
		 * </pre>
		 */
		public static String getDefault_StartDate(String strKey) throws Exception
		{
			return eCRDUtil.verifyNull((String) hmDefaultStartDate.get(strKey));
		}
		/**
		 * @return
		 */
	/**
	 * <pre>
	 * Method to get list of all Rule Levels
	 * used in eCRD application.
	 * @return HashMap
	 * @throws Exception
	 * </pre>
	 */
	public static final HashMap getCompRepair() throws Exception
	{
		return hmCompRepair;
	}
	
	/**
	 * <pre>
	 * Method to get Default End Dates from eCRDConstants.Xml
	 * used in eCRD application.
	 * Key is the tag which is defined in the Default_Start_Dates section of Constants.xml 
	 * @param strKey <code>String</code>
	 * @return String <code>String</code>
	 * @throws Exception
	 * </pre>
	 */
	public static String getDefault_EndDate(String strKey) throws Exception
	{
		return eCRDUtil.verifyNull((String) hmDefaultEndDate.get(strKey));
	}
	
	/**
	 * <pre>
	 * Method to set the Default End Dates
	 * @param objParser <code>eCRDXMLParser</code>
	 * @throws Exception
	 * </pre>
	 */
	private static final void setDefault_EndDate(eCRDXMLParser objParser) throws Exception
	{
		hmDefaultEndDate = new HashMap();
		try
		{
			hmDefaultEndDate = objParser.performParse("DEFAULT_END_DATE");
		}
		catch (Exception e)
		{
			throw new Exception("eCRDConstants:setDefault_EndDate(): " + e.toString());
		}
	}
	/**
	 * <pre>
	 * Method to set the Adhoc Columns
	 * @param objParser <code>eCRDXMLParser</code>
	 * @throws Exception
	 * </pre>
	 */
	private static final void setAdhocColumns(eCRDXMLParser objParser) throws Exception
	{
		hmAdhocColumns = new HashMap();
		try
		{
			hmAdhocColumns = objParser.performParse("ADHOC_COLUMNS");
		}
		catch (Exception e)
		{
			throw new Exception("eCRDConstants:setAdhocColumns(): " + e.toString());
		}
	}
	/**
	 * <pre>
	 * Method to get Adhocs Columns from eCRDConstants.Xml
	 * used in eCRD application.
	 * Key is the tag which is defined in the ADHOC_COLUMNS section of Constants.xml 
	 * @param strKey <code>String</code>
	 * @return String <code>String</code>
	 * @throws Exception
	 * </pre>
	 */
	public static String getAdhocColumns(String strKey) throws Exception
	{
		return eCRDUtil.verifyNull((String) hmAdhocColumns.get(strKey));
	}
	//Added by Bora
	/**
	 * <pre>
	 * Method to set the Enhanced Adhoc Columns
	 * @param objParser <code>eCRDXMLParser</code>
	 * @throws Exception
	 * </pre>
	 */
	private static final void setEnhancedAdhocColumns(eCRDXMLParser objParser) throws Exception
	{
		hmEnhancedAdhocColumns = new HashMap();
		try
		{
			hmEnhancedAdhocColumns = objParser.performParse("ENHANCED_ADHOC_COLUMNS");
		}
		catch (Exception e)
		{
			throw new Exception("eCRDConstants:setEnhancedAdhocColumns(): " + e.toString());
		}
	}
	//End Bora
	
	//Added by Bora
	/**
	 * <pre>
	 * Method to get Enhanced Adhocs Columns from eCRDConstants.Xml
	 * used in eCRD application.
	 * Key is the tag which is defined in the ENHANCED_ADHOC_COLUMNS section of Constants.xml 
	 * @param strKey <code>String</code>
	 * @return String <code>String</code>
	 * @throws Exception
	 * </pre>
	 */
	public static String getEnhancedAdhocColumns(String strKey) throws Exception
	{
		return eCRDUtil.verifyNull((String) hmEnhancedAdhocColumns.get(strKey));
	}
	//End Bora
	/**
	 * <pre>
	 * Method to set the Year
	 * @param objParser <code>eCRDXMLParser</code>
	 * @throws Exception
	 * </pre>
	 */
	private static final void setYear(eCRDXMLParser objParser) throws Exception
	{
		hmYear = new HashMap();
		try
		{
			hmYear = objParser.performParse("YEAR");
		}
		catch (Exception e)
		{
			throw new Exception("eCRDConstants:setYear(): " + e.toString());
		}
	}
/**
	 * <pre>
	 * Method to get Default Start Dates from eCRDConstants.Xml
	 * used in eCRD application.
	 * Key is the tag which is defined in the Year section of Constants.xml 
	 * @param strKey <code>String</code>
	 * @return String <code>String</code>
	 * @throws Exception
	 * </pre>
	 */
	public static String getYear(String strKey) throws Exception
	{
		return eCRDUtil.verifyNull((String) hmYear.get(strKey));
	}
	
	public static String STRDISCLAIMER = 
  "------------------------------------------------------------------------------------------------------------------------\n\r"+
  "Disclaimer: This e-mail message contain GE Confidential, proprietary and legally "+
  "privileged information for the sole use of the person or entity to whom this "+
  "message was originally addressed. Any review, e-transmission dissemination or"+
  "other use of or taking of any action in reliance upon this information by "+
  "persons or entities other than the intended recipient is prohibited. If you "+
  "have received this e-mail in error kindly delete this e-mail from your records."+
  "If it appears that this mail has been forwarded to you without proper authority, "+
  "please notify the sender and delete this mail. This email (in whole or in part) is "+
  "not to be reproduced or furnished to third parties or made public without the "+
  "prior express written permission of the sender.\n\r"+
  "------------------------------------------------------------------------------------------------------------------------";
}
