/*
 *  Project     :   eCRD 
 *  Program     :   eCRDLoadMaster.java 
 *  Author      :   Patni Team 
 *  Date        :   October 2004 
 *  Security    :   Classified/Unclassified 
 *  Restrictions:   GE PROPRIETARY INFORMATION, FOR GE USE ONLY 
 *  **************************************************** 
 *  *  Copyright(Year) with all rights reserved        * 
 *  *          General Electric Company                * 
 *  **************************************************** 
 *  Description:   Load Master Details 

 *  Revision Log  (mm/dd/yy initials description) 
 *  -------------------------------------------------------- 
 *  Patni Team    October 2004  Created 
 *
 */
package ecrd.util;
import ecrd.biz.eCRDUser;
import ecrd.common.eCRDDBMediator;
import ecrd.exception.eCRDException;
import geae.dao.GEAEResultSet;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
/** 
 * Contains all methods for loading master data 
 */ 
public class eCRDLoadMaster 
 { 
  public eCRDLoadMaster() 
  { } 
  /** 
  * Returns HTML code of Odrop down generated from resultSet retrieved from database containing Engine Family 
  * @return                          HTML string for rendering combo box containing Engine Families 
  */ 
  public static GEAEResultSet getEngineFamilyList() throws Exception 
  { 
   ArrayList arrlstInpParam = null; 
   ArrayList arrlstOutParam = null; 
   String strActionId = null; 
   GEAEResultSet rsEngineFamily = null; 
//   eCRDException objException = null; 
   try 
   { 
    strActionId = eCRDConstants.getActionId("eCRD_LIST_ENGINE_FAMILY"); 
    
    //ArrayList of Input Parameters 
    arrlstInpParam = new ArrayList(); 
    //ArrayList of Output Parameters 
    arrlstOutParam = new ArrayList(); 
    // Call this function to retrieve details engine family 
    arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam); 
    
    //Set all parameters as retrieved from the database 
    rsEngineFamily = (GEAEResultSet) arrlstOutParam.get(0); 
    
    return rsEngineFamily; 
   } 
   finally 
   { 
    arrlstInpParam = null; 
    arrlstOutParam = null; 
    strActionId = null; 
    rsEngineFamily = null; 
   } 
  } 
  /** 
   * Get List of Engine Models in the application. 
   * @return GEAEResultSet 
   *  
   */ 
  public static GEAEResultSet getEngineModelList() throws Exception 
  { 
   ArrayList arrlstInpParam = null; 
   ArrayList arrlstOutParam = null; 
   String strActionId = null; 
//   String strErrorMsg = null; 
   GEAEResultSet rsEngineModelList = null; 
   try 
   { 
    //Set the action this to call procedure to laod engine model details 
    strActionId = eCRDConstants.getActionId("eCRD_LIST_ENGINE_MODEL"); 
    //ArrayList of Input Parameters 
    arrlstInpParam = new ArrayList(); 
    //ArrayList of Output Parameters 
    arrlstOutParam = new ArrayList(); 
    // Call this function to retrieve details of the engine model from database 
    arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam); 
    //Set all parameters as retrieved from the database 
    rsEngineModelList = (GEAEResultSet) arrlstOutParam.get(0); 
    return rsEngineModelList; 
   } 
   finally 
   { 
    arrlstInpParam = null; 
    arrlstOutParam = null; 
    strActionId = null; 
//    strErrorMsg = null; 
    rsEngineModelList = null; 
   } 
  }
 
  /** ---- Added By Santosh ---- **/
  /** 
   * Get List of Site in the application. 
   * @return GEAEResultSet 
   *  
   */ 
  public static GEAEResultSet getSiteList() throws Exception 
  { 
   ArrayList arrlstInpParam = null; 
   ArrayList arrlstOutParam = null; 
   String strActionId = null; 
//   String strErrorMsg = null; 
   GEAEResultSet rsSiteList = null; 
   try 
   { 
    //Set the action this to call procedure to laod engine model details 
    strActionId = eCRDConstants.getActionId("eCRD_LIST_SITE"); 
    //ArrayList of Input Parameters 
    arrlstInpParam = new ArrayList(); 
    //ArrayList of Output Parameters 
    arrlstOutParam = new ArrayList(); 
    // Call this function to retrieve details of the engine model from database 
    arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam); 
    //Set all parameters as retrieved from the database 
    rsSiteList = (GEAEResultSet) arrlstOutParam.get(0); 
    return rsSiteList; 
   } 
   finally 
   { 
    arrlstInpParam = null; 
    arrlstOutParam = null; 
    strActionId = null; 
//    strErrorMsg = null; 
    rsSiteList = null; 
   } 
  } 
  
  /** ---- Ended By Santosh ---- **/ 
  
  
  /** 
   * Get List of all modules for a particular modele in the active default Catalog. 
   * @return GEAEResultSet 
   */ 
  public static GEAEResultSet getMasterModuleList(String strEngineModel) throws Exception 
  { 
   ArrayList arrlstInpParam = null; 
   ArrayList arrlstOutParam = null; 
   String strActionId = null; 
//   String strErrorMsg = null; 
   GEAEResultSet rsModuleList = null; 
   eCRDException objException = null; 
   try 
   { 
    if (strEngineModel == null) 
    { 
     objException = new eCRDException(); 
     objException.setExcpId("ENGINE_MODEL_NULL"); 
     throw objException; 
    } 
    //Set the action id to call procedure to load master module details 
    strActionId = eCRDConstants.getActionId("eCRD_LIST_MASTER_MODULE"); 
    //ArrayList of Input Parameters 
    arrlstInpParam = new ArrayList(); 
    //ArrayList of Output Parameters 
    arrlstOutParam = new ArrayList(); 
    //Pass inout parameter 
    arrlstInpParam.add(strEngineModel.toUpperCase()); 
    // Call this function to retrieve details default catalog modules 
    arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam); 
    //Set all parameters as retrieved from the database 
    rsModuleList = (GEAEResultSet) arrlstOutParam.get(0); 
    return rsModuleList; 
   } 
   finally 
   { 
    arrlstInpParam = null; 
    arrlstOutParam = null; 
    strActionId = null; 
//    strErrorMsg = null; 
    rsModuleList = null; 
   } 
  } 
 
/*9292_eCRD_Phase4_Site mapping_Shyamala Radhakrishnan	 
 * Retrieve site for a component 
 */ 
 public static GEAEResultSet getSiteListComp(HttpServletRequest request, String strModule, String Comp, String strCompDesc, String strCompType) throws Exception 
 { 
	 ArrayList arrlstInpParam = null; 
	 ArrayList arrlstOutParam = null; 
	 String strActionId = null; 
	 String strUserRole = null;
	 String strUserId = null;

	 GEAEResultSet rsSiteList = null; 
	 eCRDException objException = null;
	 eCRDUser objeCRDUser = null;
	 try 
	 { 
		 if (strModule == null) 
		 { 
			 objException = new eCRDException(); 
			 objException.setExcpId("SITE_NULL"); 
			 throw objException; 
		 } 
		 objeCRDUser = (eCRDUser)eCRDUtil.getFromSessionApp(request,"objeCRDUser"); 
		 //Set the action id to call procedure to load master Site details   
		 strActionId = eCRDConstants.getActionId("eCRD_LIST_COMP_SITE");
		 //	Set the user role 
		 strUserRole = objeCRDUser.getRole();
		 //	Set the user id
		 strUserId = objeCRDUser.getUserId();
		 //  ArrayList of Input Parameters   
		 arrlstInpParam = new ArrayList(); 
		 //ArrayList of Output Parameters   
		 arrlstOutParam = new ArrayList(); 
		 //Pass inout parameter   
	  
		 if(strCompType.equals("Code")) 
		 { 
			 strCompDesc = ""; 
		 } 
		 else 
		 { 
			 Comp = ""; 
		 } 
    
		 arrlstInpParam.add(strModule.toUpperCase()); 
		 arrlstInpParam.add(Comp.toUpperCase()); 
		 arrlstInpParam.add(strCompDesc);
//bug_fix		 
         
		 arrlstInpParam.add(strUserId.toUpperCase());
		 arrlstInpParam.add(strUserRole.toUpperCase());
		 // Call this function to retrieve site   
		 arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam); 
		 //Set all parameters as retrieved from the database   
		 rsSiteList = (GEAEResultSet) arrlstOutParam.get(0); 
		 return rsSiteList; 
	 } 
	 finally 
	 { 
		 arrlstInpParam = null; 
		 arrlstOutParam = null; 
		 strActionId = null; 
		 rsSiteList = null; 
		 objeCRDUser = null;
	 } 
  } 
    
 
    
  
    // Started for  Component Download : October release 2006 
    /** 
     * Get List of all modules for a particular modele in the active default Catalog. 
     * @return GEAEResultSet 
     */ 
    public static ArrayList getMasterModuleLocationList(String strEngineModel) throws Exception 
     { 
        ArrayList arrlstInpParam = null; 
        ArrayList arrlstOutParam = null; 
        String strActionId = null; 
        GEAEResultSet rsModuleList = null; 
        GEAEResultSet rsLocationList = null; 
        eCRDException objException = null; 
        ArrayList arrlstModuleLoc = null; 
         
        try 
         { 
            if (strEngineModel == null) 
             { 
                objException = new eCRDException(); 
                objException.setExcpId("ENGINE_MODEL_NULL"); 
                throw objException; 
             } 
            //Set the action id to call procedure to load master module details 
            strActionId = eCRDConstants.getActionId("eCRD_LIST_MASTER_MODULE_LOCATION"); 
            //ArrayList of Input Parameters 
            arrlstInpParam = new ArrayList(); 
            //ArrayList of Output Parameters 
            arrlstOutParam = new ArrayList(); 
            //ArrayList of Resultsets 
            arrlstModuleLoc = new ArrayList(); 
            //Pass inout parameter 
            arrlstInpParam.add(strEngineModel.toUpperCase()); 
            // Call this function to retrieve details default catalog modules 
            arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam); 
            //Set all parameters as retrieved from the database 
             
            rsModuleList = (GEAEResultSet) arrlstOutParam.get(0); 
            rsLocationList = (GEAEResultSet) arrlstOutParam.get(1); 
             
            //Two Result sets added to Arraylist 1st: Module List , 2nd: Location List 
            arrlstModuleLoc.add(rsModuleList); 
            arrlstModuleLoc.add(rsLocationList); 
            return arrlstModuleLoc; 
         } 
        finally 
         { 
            arrlstInpParam = null; 
            arrlstOutParam = null; 
            strActionId = null; 
//          strErrorMsg = null; 
            rsModuleList = null; 
         } 
     } 
    // Ended for  Component Download : October release 2006 
  /** 
   * Get List of all modules for a particular modele in the specified catalog. 
   * @return GEAEResultSet 
   */ 
  public static GEAEResultSet getModuleList(String strCatalogSeqId) throws Exception 
  { 
   ArrayList arrlstInpParam = null; 
   ArrayList arrlstOutParam = null; 
   String strActionId = null; 
//   String strErrorMsg = null; 
   GEAEResultSet rsModuleList = null; 
   eCRDException objException = null; 
   try 
   { 
    if (strCatalogSeqId == null) 
    { 
     objException = new eCRDException(); 
     objException.setExcpId("SET_PARAMETERS_NULL"); 
     throw objException; 
    } 
    //Set the action id to call procedure to load master module details 
    strActionId = eCRDConstants.getActionId("eCRD_LIST_MODULE"); 
    //ArrayList of Input Parameters 
    arrlstInpParam = new ArrayList(); 
    //ArrayList of Output Parameters 
    arrlstOutParam = new ArrayList(); 
    //Pass inout parameter 
    arrlstInpParam.add(strCatalogSeqId); 
    // Call this function to retrieve details default catalog modules 
    arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam); 
    //Set all parameters as retrieved from the database 
    rsModuleList = (GEAEResultSet) arrlstOutParam.get(0); 
    return rsModuleList; 
   } 
   finally 
   { 
    arrlstInpParam = null; 
    arrlstOutParam = null; 
    strActionId = null; 
//    strErrorMsg = null; 
    rsModuleList = null; 
   } 
  } 
  /** 
   * Get the list of components from the current default catalog based on the Engine  
   * Model and Module 
   * @param strCatalogCode 
   * @param strEngineModelCode 
   * @param strModuleCode 
   * @return ArrayList 
   */ 
  public static GEAEResultSet getComponentList(String strCatalogCode, String strModuleCode) throws Exception 
  { 
   ArrayList arrlstInpParam = null; 
   ArrayList arrlstOutParam = null; 
   String strActionId = null; 
//   String strErrorMsg = null; 
   GEAEResultSet rsComponentList = null; 
   eCRDException objException = null; 
   try 
   { 
    if (strCatalogCode == null || strModuleCode == null) 
    { 
     objException = new eCRDException(); 
     objException.setExcpId("SET_PARAMETERS_NULL"); 
     throw objException; 
    } 
    //intCatalogseqId = new Integer(strCatalogCode); 
    //Set the action id to call procedure to laod component details 
    strActionId = eCRDConstants.getActionId("eCRD_LIST_COMPONENTS"); 
    //ArrayList of Input Parameters 
    arrlstInpParam = new ArrayList(); 
    //ArrayList of Output Parameters 
    arrlstOutParam = new ArrayList(); 
    //Pass inout parameter 
    arrlstInpParam.add(strCatalogCode); 
    arrlstInpParam.add(strModuleCode); 
    // Call this function to retrieve details from database 
    arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam); 
    //Set all parameters as retrieved from the database 
    rsComponentList = (GEAEResultSet) arrlstOutParam.get(0); 
    return rsComponentList; 
   } 
   finally 
   { 
    arrlstInpParam = null; 
    arrlstOutParam = null; 
    strActionId = null; 
//    strErrorMsg = null; 
    rsComponentList = null; 
    objException = null; 
   } 
  } 
  /** 
   * Get the list of repairs from the catalog selected based on the Engine Model and  
   * Module and component. 
   * @param inyCatalogSeqId 
   * @param strEngineModelCode 
   * @param strModuleCode 
   * @param strComponentCode 
   * @return ArrayList 
   */ 
  public static GEAEResultSet getRepairList(String strCatalogSeqId, String strModuleCode, String strComponentCode) throws Exception 
  { 
   ArrayList arrlstInpParam = null; 
   ArrayList arrlstOutParam = null; 
   String strActionId = null; 
//   String strErrorMsg = null; 
   GEAEResultSet rsRepairList = null; 
   eCRDException objException = null; 
   try 
   { 
    if (strCatalogSeqId == null || strModuleCode == null || strComponentCode == null) 
    { 
     objException = new eCRDException(); 
     objException.setExcpId("SET_PARAMETERS_NULL"); 
     throw objException; 
    } 
    //Set the action id to call procedure to list repairs for the selected component 
    strActionId = eCRDConstants.getActionId("eCRD_LIST_REPAIRS"); 
    //ArrayList of Input Parameters 
    arrlstInpParam = new ArrayList(); 
    //ArrayList of Output Parameters 
    arrlstOutParam = new ArrayList(); 
    //Pass inout parameter 
    arrlstInpParam.add(strCatalogSeqId); 
    arrlstInpParam.add(strModuleCode); 
    arrlstInpParam.add(strComponentCode); 
    // Call this function to retrieve details of repairs from database 
    arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam); 
    //Set all parameters as retrieved from the database 
    rsRepairList = (GEAEResultSet) arrlstOutParam.get(0); 
    return rsRepairList; 
   } 
   finally 
   { 
    arrlstInpParam = null; 
    arrlstOutParam = null; 
    strActionId = null; 
//    strErrorMsg = null; 
    rsRepairList = null; 
    objException = null; 
   } 
  } 
  /** 
   * Populates list of all repair types 
   * @return ArrayList 
   */ 
  /*public ArrayList getRepairTypes() throws Exception  
  { 
   return null; 
  }*/ 
  /** 
   * Get list of all Repair Reference number formats 
   * @return ArrayList 
   */ 
  /*public ArrayList getRepairRefFormats() throws Exception 
  { 
   return null; 
  }*/ 
  /** 
   * Get List of price types. 
   * @return ArrayList 
   */ 
  /*public ArrayList getPriceTypes() throws Exception 
  { 
   return null; 
  }*/ 
  /** 
   * Get List of all sites for the application. The fields retrieved are location_code and location_name. 
   * @return GEAEResultSet  
   */ 
/*  public static GEAEResultSet getSiteList() throws Exception 
  { 
   ArrayList arrlstInpParam = null; 
   ArrayList arrlstOutParam = null; 
   String strActionId = null; 
   String strErrorMsg = null; 
   GEAEResultSet rsSiteList = null; 
   eCRDUser objeCRDNewUser = null; 
   HttpServletRequest request = null; 
   String strLoginRole=null; 
   try 
   { 
    //Set the action id to call procedure to list user details 
    strActionId = eCRDConstants.getActionId("eCRD_LIST_SITES"); 
    //ArrayList of Input Parameters 
    arrlstInpParam = new ArrayList(); 
    //ArrayList of Output Parameters 
    arrlstOutParam = new ArrayList(); 
    //objeCRDNewUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser"); 
    //strLoginRole = objeCRDNewUser.getRole(); 
    
    // Call this function to retrieve details of the sites from database 
    arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam); 
    //Set all parameters as retrieved from the database 
    rsSiteList = (GEAEResultSet) arrlstOutParam.get(0); 
    return rsSiteList; 
   } 
   finally 
   { 
    arrlstInpParam = null; 
    arrlstOutParam = null; 
    strActionId = null; 
    strErrorMsg = null; 
    rsSiteList = null; 
    //objeCRDNewUser=null; 
    //strLoginRole=null; 
   } 
  }*/ 
  
  public static GEAEResultSet getSiteList(HttpServletRequest request) throws Exception 
  { 
   ArrayList arrlstInpParam = null; 
   ArrayList arrlstOutParam = null; 
   
   String strActionId = ""; 
   String strLoginRole=""; 
   String strUserId = ""; 
    
   GEAEResultSet rsSiteList = null; 
   
   eCRDUser objeCRDUser = null; 
    
   try 
   { 
    //Set the action id to call procedure to list user details 
    strActionId = eCRDConstants.getActionId("eCRD_LIST_SITES"); 
    
    arrlstInpParam = new ArrayList(); 
    arrlstOutParam = new ArrayList(); 
    
    objeCRDUser = (eCRDUser)eCRDUtil.getFromSessionApp(request,"objeCRDUser"); 
    strLoginRole = objeCRDUser.getRole(); 
    strUserId = objeCRDUser.getUserId(); 
    
    arrlstInpParam.add(strLoginRole); 
    arrlstInpParam.add(strUserId); 
    
    // Call this function to retrieve details of the sites from database 
    arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam); 
    
    //Set all parameters as retrieved from the database 
    rsSiteList = (GEAEResultSet) arrlstOutParam.get(0); 
    return rsSiteList; 
   } 
   finally 
   { 
    arrlstInpParam = null; 
    arrlstOutParam = null; 
    strActionId = ""; 
    strLoginRole=""; 
    rsSiteList = null; 
    objeCRDUser=null;  
   } 
  } 
 /* Added By Prathima for Getting customer for report  */ 
 
  public static GEAEResultSet getCustomerListReport(String strCustomerCode ,String strEngineModel,String strActive) throws Exception 
{ 
ArrayList arrlstInParam = null; 
ArrayList arrlstOutParam = null; 
String strActionId = null;  
GEAEResultSet rsCustomerList = null; 
try 
{ 
//Set the action id to call procedure to list user roles 
strActionId = eCRDConstants.getActionId("eCRD_CUSTOMER_LIST_REPORT"); 
//ArrayList of Input Parameters 
arrlstInParam = new ArrayList(); 
arrlstInParam.add(strCustomerCode.toUpperCase()); 
arrlstInParam.add(strActive);
arrlstInParam.add(strEngineModel);
//ArrayList of Output Parameters 
arrlstOutParam = new ArrayList(); 
// Call this function to retrieve list of users  
arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInParam); 
//Set all parameters as retrieved from the database 
rsCustomerList = (GEAEResultSet) arrlstOutParam.get(0); 

System.out.println("SANTOSH IN TEST for Getting customer List "+rsCustomerList.size());

} 
finally 
{ 
arrlstInParam = null; 
arrlstOutParam = null; 
strActionId = null; 
//strErrorMsg = null; 
} 
return rsCustomerList; 
} 
  
/* Added By Prathima for Getting customer for report  */   
  public static GEAEResultSet getSiteListWithoutAll(HttpServletRequest request) throws Exception 
  { 
   ArrayList arrlstInpParam = null; 
   ArrayList arrlstOutParam = null; 
   
   String strActionId = ""; 
   String strLoginRole=""; 
   String strUserId = ""; 
    
   GEAEResultSet rsSiteList = null; 
   
   eCRDUser objeCRDUser = null; 
    
   try 
   { 
    //Set the action id to call procedure to list user details 
    strActionId = eCRDConstants.getActionId("eCRD_LIST_SITES_WITHOUT_ALL"); 
    
    arrlstInpParam = new ArrayList(); 
    arrlstOutParam = new ArrayList(); 
    
    objeCRDUser = (eCRDUser)eCRDUtil.getFromSessionApp(request,"objeCRDUser"); 
    strLoginRole = objeCRDUser.getRole(); 
    strUserId = objeCRDUser.getUserId(); 
    
    arrlstInpParam.add(strLoginRole); 
    arrlstInpParam.add(strUserId); 
    
    // Call this function to retrieve details of the sites from database 
    arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam); 
    
    //Set all parameters as retrieved from the database 
    rsSiteList = (GEAEResultSet) arrlstOutParam.get(0); 
    return rsSiteList; 
   } 
   finally 
   { 
    arrlstInpParam = null; 
    arrlstOutParam = null; 
    strActionId  = null; 
    strLoginRole = null; 
    rsSiteList = null; 
    objeCRDUser=null;  
   } 
  } 
  public static ArrayList getSiteListForComp(HttpServletRequest request 
             ,String strCompCode 
             ,String strModSeq 
             ) throws Exception 
   { 
    ArrayList arrlstInpParam = null; 
    ArrayList arrlstOutParam = null; 
    
    String strActionId       = null; 
    String strLoginRole      = null; 
    String strUserId         = null; 
    String strUserSite       = null; 
    GEAEResultSet rsSiteList = null; 
   
    eCRDUser objeCRDUser     = null; 
    
    try 
    { 
     //Set the action id to call procedure to list user details 
     strActionId = eCRDConstants.getActionId("eCRD_LIST_SITES_FOR_COMP"); 
    
     arrlstInpParam = new ArrayList(); 
     arrlstOutParam = new ArrayList(); 
     
     objeCRDUser  = (eCRDUser)eCRDUtil.getFromSessionApp(request,"objeCRDUser"); 
     strLoginRole = objeCRDUser.getRole(); 
     strUserId    = objeCRDUser.getUserId(); 
     strUserSite  = objeCRDUser.getSite().getSiteCode(); 
     arrlstInpParam.add(strLoginRole); 
     arrlstInpParam.add(strUserId); 
     arrlstInpParam.add(strUserSite); 
     arrlstInpParam.add(strCompCode); 
     arrlstInpParam.add(strModSeq); 
     
     // Call this function to retrieve details of the sites from database 
     arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam); 
    
     //Set all parameters as retrieved from the database 
     //rsSiteList = (GEAEResultSet) arrlstOutParam.get(0); 
     return arrlstOutParam; 
    } 
    finally 
    { 
     arrlstInpParam = null; 
     arrlstOutParam = null; 
     strActionId  = null; 
     strLoginRole = null; 
     rsSiteList = null; 
     objeCRDUser=null;  
    } 
   } 
 
  
  
  /** 
   * Retrive list of Rule Levels for customer catalog (Catalog, Module, Component,  
   * Reapir etc.) 
   * @return ArrayList 
   */ 
  /*public ArrayList getLevels() throws Exception 
  { 
   return null; 
  }*/ 
  /** 
   * Get list of years from current year onwards 
   * @return ArrayList 
   */ 
  /*public ArrayList getYears() throws Exception 
  { 
   return null; 
  }*/ 
  /** 
   * Get list of all classes for cycle validation. 
   * @return ArrayList 
   */ 
  public static GEAEResultSet getCycClassList() throws Exception 
  { 
   GEAEResultSet rsClassList = null; 
   ArrayList arrlstInpParam = null; 
   ArrayList arrlstOutParam = null; 
   String strActionId = null; 
   try 
   { 
    // Set the action id to call procedure to list user roles 
    strActionId = eCRDConstants.getActionId("eCRD_LIST_CLASS"); 
    //ArrayList of Input Parameters 
    arrlstInpParam = new ArrayList(); 
    //ArrayList of Output Parameters 
    arrlstOutParam = new ArrayList(); 
    // Call this function to retrieve list of users  
    arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam); 
    //Set all parameters as retrieved from the database 
    rsClassList = (GEAEResultSet) arrlstOutParam.get(0); 
   } 
   finally 
   { } 
   return rsClassList; 
  } 
  
  /** 
    * Get List of Events in the databasse. Returned resultset will have Event code and Event Name as attributes. 
    * @return GEAEResultSet 
    */ 
  
  public static GEAEResultSet getEvents() throws Exception 
  { 
    ArrayList arrlstInParam = null; 
    ArrayList arrlstOutParam = null; 
    String strActionId = null; 
    //String strErrorMsg = null; 
    GEAEResultSet rsEventList = null; 
    try 
    { 
     //Set the action id to call procedure to list user roles 
     strActionId = eCRDConstants.getActionId("eCRD_EVENT_LIST"); 
     //ArrayList of Input Parameters 
     arrlstInParam = new ArrayList(); 
     //ArrayList of Output Parameters 
     arrlstOutParam = new ArrayList(); 
     // Call this function to retrieve list of users  
     arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInParam); 
     //Set all parameters as retrieved from the database 
     rsEventList = (GEAEResultSet) arrlstOutParam.get(0); 
     
 
    } 
    finally 
    { 
     arrlstInParam = null; 
     arrlstOutParam = null; 
     strActionId = null; 
//     strErrorMsg = null; 
    } 
    return rsEventList; 
  } 
 
  /** 
    * Get List of Events from the data base associated with the 
    * particular Group. 
    *  
    * @return ArrayList  
    */  
  public static ArrayList getEventsRelatedToGroup(String strGroupCode) throws Exception 
  { 
   String strActionId = ""; 
   ArrayList arrlstInParam = null; 
   ArrayList arrlstOutParam = null; 
   GEAEResultSet rsEvents = null; 
   ArrayList arrlstEvents = null; 
    try 
   { 
    strActionId = eCRDConstants.getActionId("eCRD_EVENTS_RELATED_TO_GROUP"); 
    arrlstInParam = new ArrayList(); 
    arrlstOutParam = new ArrayList(); 
    arrlstEvents = new ArrayList(); 
    arrlstInParam.add(strGroupCode); 
    arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId,arrlstInParam); 
    rsEvents = (GEAEResultSet)arrlstOutParam.get(0); 
    rsEvents.setCurrentRow(0); 
    
    while(rsEvents.next()) 
    { 
     arrlstEvents.add(rsEvents.getString(1)); 
    } 
    return arrlstEvents;  
   } 
    finally 
   { 
    strActionId = ""; 
    arrlstInParam = null; 
    arrlstOutParam = null; 
    rsEvents = null; 
    arrlstEvents = null; 
       
   } 
   
  }  
 
 
  /** 
   * Get List of Roles in the system. Returned resultset will have ROLE_CODE and ROLE_NAME as attributes. 
   * @return GEAEResultSet 
   */ 
  public static GEAEResultSet getRoleList() throws Exception 
  { 
   ArrayList arrlstInpParam = null; 
   ArrayList arrlstOutParam = null; 
   String strActionId = null; 
//   String strErrorMsg = null; 
   GEAEResultSet rsRoleList = null; 
   //eCRDUser objeCRDNewUser = null; 
   //HttpServletRequest request = null; 
   //String strLoginRole=null; 
   try 
   { 
    
    //Set the action id to call procedure to list user roles 
    strActionId = eCRDConstants.getActionId("eCRD_LIST_ROLES"); 
    //ArrayList of Input Parameters 
    arrlstInpParam = new ArrayList(); 
    //ArrayList of Output Parameters 
    arrlstOutParam = new ArrayList(); 
    //objeCRDNewUser = (eCRDUser) eCRDUtil.getFromSessionApp(request, "objeCRDUser"); 
    //strLoginRole = objeCRDNewUser.getRole(); 
    //arrlstInpParam.add(strLoginRole); 
    // Call this function to retrieve list of users  
    arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam); 
    //Set all parameters as retrieved from the database 
    rsRoleList = (GEAEResultSet) arrlstOutParam.get(0); 
   } 
   finally 
   { 
    arrlstInpParam = null; 
    arrlstOutParam = null; 
    strActionId = null; 
//    strErrorMsg = null; 
   } 
   return rsRoleList; 
  } 
  /** 
   * Get a selected List of Customers in the system. Returned resultset will have CUSTOMER_CODE and CUSTOMER_NAME as attributes. 
   * @return GEAEResultSet 
   */ 
  public static GEAEResultSet getCustomerList(String strCustomerCode 
               ,String strActive) throws Exception 
  { 
   ArrayList arrlstInParam = null; 
   ArrayList arrlstOutParam = null; 
   String strActionId = null; 
//   String strErrorMsg = null; 
   GEAEResultSet rsCustomerList = null; 
   try 
   { 
    //Set the action id to call procedure to list user roles 
    strActionId = eCRDConstants.getActionId("eCRD_CUSTOMER_LIST"); 
    //ArrayList of Input Parameters 
    arrlstInParam = new ArrayList(); 
    arrlstInParam.add(strCustomerCode.toUpperCase()); 
    arrlstInParam.add(strActive); 
    //ArrayList of Output Parameters 
    arrlstOutParam = new ArrayList(); 
    // Call this function to retrieve list of users  
    arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInParam); 
    //Set all parameters as retrieved from the database 
    rsCustomerList = (GEAEResultSet) arrlstOutParam.get(0); 
   } 
   finally 
   { 
    arrlstInParam = null; 
    arrlstOutParam = null; 
    strActionId = null; 
//    strErrorMsg = null; 
   } 
   return rsCustomerList; 
  } 
  /** 
  * Get entire  List of Customers in the system. Returned resultset will have CUSTOMER_CODE and CUSTOMER_NAME as attributes. 
  * @return GEAEResultSet 
  */ 
  public static GEAEResultSet getMasterCustomerList() throws Exception 
   { 
    ArrayList arrlstInParam = null; 
    ArrayList arrlstOutParam = null; 
    String strActionId = null; 
    String strCustomerCode = ""; 
//    String strErrorMsg = null; 
    GEAEResultSet rsCustomerList = null; 
    try 
    { 
     //Set the action id to call procedure to list user roles 
     strActionId = eCRDConstants.getActionId("eCRD_MASTER_CUSTOMER_LIST"); 
     //ArrayList of Input Parameters 
     arrlstInParam = new ArrayList(); 
     arrlstInParam.add(strCustomerCode); 
     //ArrayList of Output Parameters 
     arrlstOutParam = new ArrayList(); 
     // Call this function to retrieve list of users  
     arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInParam); 
     //Set all parameters as retrieved from the database 
     rsCustomerList = (GEAEResultSet) arrlstOutParam.get(0); 
    } 
    finally 
    { 
     arrlstInParam = null; 
     arrlstOutParam = null; 
     strActionId = null; 
//     strErrorMsg = null; 
    } 
    return rsCustomerList; 
   } 
  /** 
   * Get list of features for the Price Listing changes report. e.g Added Repairs,  
   * Deleted Repairs, Modified Repairs. 
   * @return ArrayList 
   */ 
  /*public ArrayList getPriceListReportFeature() throws Exception 
  { 
   return null; 
  } 
  */ 
 } 
 

 