//Source file: D:\\ECRD\\SOURCE CODE\\ecrd\\util\\eCRDSearchBean.java
/**
 *  Project     :   eCRD
 *  Program     :   eCRDSearchBean.java
 *  Author      :   Patni Team
 *  Date        :   October 2004
 *  Security    :   Classified/Unclassified
 *  Restrictions:   GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 *
 *  ****************************************************
 *  *  Copyright(Year) with all rights reserved        *
 *  *          General Electric Company                *
 *  ****************************************************
 *  Description:   Description of Class
 *
 *
 *  Revision Log  (mm/dd/yy initials description)
 *  --------------------------------------------------------
 *  Patni Team    October 2004  Created
 *  Patni Team    12th Jun 2006 Modified getRepairListing()
 */

package ecrd.util;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import ecrd.biz.eCRDChildRepair;
import ecrd.biz.eCRDComponent;
import ecrd.biz.eCRDCustomerCatalog;
import ecrd.biz.eCRDEngineModel;
import ecrd.biz.eCRDGroupedRepair;
import ecrd.biz.eCRDIndRepair;
import ecrd.biz.eCRDModule;
import ecrd.biz.eCRDRepairPricing;
import ecrd.common.eCRDDBMediator;
import ecrd.exception.eCRDException;
import geae.dao.GEAEResultSet;
import geae.util.format.GEAETag;
//import ecrd.exception.eCRDException;

public class eCRDSearchBean
{

	public eCRDSearchBean()
	{

	}

	/**
	 * Returns list of customers based on partial customer code passed.
	 * @param strCustomerCode
	 * @return String[][]
	 */
	public String[][] searchCustomer(String strCustomerCode)
	{
		return null;
	}

	/**
	 * Returns a list of Components based on the Engine Model, module and partial
	 * component code passed.
	 * The fields returned for each component are :
	 * Component Code, Component Name
	 * @param strEngineModelCode
	 * @param strModuleCode
	 * @param strComponentCode
	 * @return String[][]
	 */
	public String[][] searchComponent(String strEngineModelCode, String strModuleCode, String strComponentCode)
	{
		return null;
	}

	/**
	* Returns list of components based on Engine Model, Module  and
	 * partial component code.
	 * Output fields :
	 * Reapir Code,
	 * Repair Description.
	 * @param strEngineModelCode
	 * @param strModuleCode
	 * @param strComponentCode
	 * @param strRepairCode - Repair code passed would be partial.
	 * @return String[][]
	 */
	public ArrayList findComponentCode(String strEngineModelCode, String strModuleCode, String strComponentType, String strComponentCode, String strActionId) throws Exception
	{
		ArrayList arrlstInpParam = new ArrayList();
		ArrayList arrlstOutParam = new ArrayList();
				
		
		arrlstInpParam.add(strEngineModelCode);
		arrlstInpParam.add(strModuleCode);
		arrlstInpParam.add(strComponentType);
		arrlstInpParam.add(strComponentCode);
		arrlstInpParam.add("");
		
		try
		{
			//strActionId = eCRDConstants.getActionId(strActionId);
			arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);
		}
		finally
		{
			arrlstInpParam = null;
		}
		return arrlstOutParam;
	}

	/**
	 * Returns list of repairs based on Engine Model, Module, Component Code and
	 * partial repair code.
	 * Output fields :
	 * Reapir Code,
	 * Repair Description.
	 * @param strEngineModelCode
	 * @param strModuleCode
	 * @param strComponentCode
	 * @param strRepairCode - Repair code passed would be partial.
	 * @return String[][]
	 */								//changes by rishabh mewar
	public ArrayList findRepairCode( String strEngineModelCode, String strModuleCode, String strComponentType, String strComponentCode, String strRepairType, String strRepairCode, String strActionId)
		throws Exception
	{
		ArrayList arrlstInpParam = new ArrayList();
		ArrayList arrlstOutParam = new ArrayList();

		arrlstInpParam.add(strEngineModelCode);
		arrlstInpParam.add(strModuleCode);
		arrlstInpParam.add(strComponentType);
		arrlstInpParam.add(strComponentCode);
		arrlstInpParam.add(strRepairType);
		arrlstInpParam.add(strRepairCode);
		
	//	arrlstInpParam.add(strRepairInd); //changes by rishabh mewar
		
		try
		{
			//strActionId = eCRDConstants.getActionId(strActionId);
			arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);
		}
		finally
		{
			arrlstInpParam = null;
		}
		return arrlstOutParam;
	}

	/**
	 * Returns list of repairs based on Engine Model, Module, Component Code.
	 *
	 * Output fields :
	 * Reapir Code,
	 * Repair Description.
	 * @param strEngineModelCode
	 * @param strModuleCode
	 * @param strComponentCode
	 * @param strRepairCode - Repair code passed would be partial.
	 * @return String[][]
	 */
	public ArrayList getRepairListing(String strCatalogSeqId, String strEngineModelCode, String strModuleCode, String strComponentType, String strComponentCode, String strActionId,String strUserRole) throws Exception
	{
		ArrayList arrlstInpParam = new ArrayList();
		ArrayList arrlstOutParam = new ArrayList();
		
		arrlstInpParam.add(strCatalogSeqId);
		arrlstInpParam.add(strEngineModelCode);
		arrlstInpParam.add(strModuleCode);
		arrlstInpParam.add(strComponentType);
		arrlstInpParam.add(strComponentCode);

		/* 12-Jun-2006 Patni - User Role should be passed only if the Action is eCRDRepairListing - Begin */
		//arrlstInpParam.add(strUserRole);

		if("eCRDRepairListing".equals(strActionId))
		{
			arrlstInpParam.add(strUserRole);
		}
		/* 12-Jun-2006 Patni - User Role should be passed only if the Action is eCRDRepairListing - End */

		try
		{
			//System.out.println("strActionId --------------- > "+strActionId);
			arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);
		}
		finally
		{
			arrlstInpParam = null;
		}
		return arrlstOutParam;
	}

	/**
	 * Returns list of users based on partial user id passed.
	 * The output contains:
	 * User Id, User Name, EMail Id.
	 * @param strUserId
	 * @return String[][]
	 */
	public String[][] searchUser(String strUserId)
	{
		return null;
	}

	/**
		  * Get List of Engine Models in the application.
		  * @return GEAEResultSet
		  *
		  */
	public static GEAEResultSet getEngineModelList() throws Exception
	{
		ArrayList arrlstInpParam = null;
		ArrayList arrlstOutParam = null;
		String strActionId = null;
		GEAEResultSet rsEngineModelList = null;

		try
		{
			//Set the action this to call procedure to laod engine model details
			strActionId = eCRDConstants.getActionId("eCRD_GET_DEFAULT_CATALOGLIST");

			//ArrayList of Input Parameters
			arrlstInpParam = new ArrayList();
			//ArrayList of Output Parameters
			arrlstOutParam = new ArrayList();

			// Call this function to retrieve details of the engine model from database
			arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);

			//Set all parameters as retrieved from the database
			rsEngineModelList = (GEAEResultSet) arrlstOutParam.get(0);
			return rsEngineModelList;
		}
		finally
		{
			arrlstInpParam = null;
			arrlstOutParam = null;
			strActionId = null;
		}
	}

	/**
		 * Returns list of groups present
		 * @return GEAEResultSet 
		 */


		public GEAEResultSet listGroups() throws Exception
		{

			ArrayList arrlstOutParam = null;
			ArrayList arrLstInParam = null;
			GEAEResultSet geaersetUserList = null;
			String strAction =null;
			

			try
			{

				arrlstOutParam = new ArrayList();
				strAction = eCRDConstants.getActionId("eCRD_EMAIL_GROUP");
				arrlstOutParam = eCRDDBMediator.doDBOperation(strAction,arrLstInParam);
				geaersetUserList = (GEAEResultSet) arrlstOutParam.get(0);
				return geaersetUserList;
			}
			finally
			{
				arrlstOutParam = null;
				geaersetUserList = null;

			}
		}

	/**
		 * Returns list of users based on partial user id passed.
		 * The output contains:
		 * User Id, User Name, EMail Id.
		 * @param strUserId
		 * @return String[][]
		 */


	public GEAEResultSet searchModule(String strEngModelCode) throws Exception
	{

		String strScreenAction = "";
		ArrayList arrLstInParam = null;
		ArrayList arrLstOutParam = null;
		arrLstInParam = new ArrayList();
		arrLstOutParam = new ArrayList();
		GEAEResultSet geaersetModules = null;
		try
		{

			strScreenAction = eCRDConstants.getActionId("eCRD_LIST_ENGMODULE");
			arrLstInParam.add(strEngModelCode.toUpperCase());
			arrLstInParam.add("y");

			arrLstOutParam = eCRDDBMediator.doDBOperation(strScreenAction, arrLstInParam);
			geaersetModules = (GEAEResultSet) arrLstOutParam.get(0);
			return geaersetModules;
		}
		finally
		{
			arrLstInParam = null;
			arrLstOutParam = null;
			geaersetModules = null;
		}

	}

	public static GEAEResultSet getPriceList(String strEngModel, String strPriceDesc, String strStartDate, String strEndDate) throws Exception
	{
		ArrayList arrlstInpParam = null;
		ArrayList arrlstOutParam = null;
		String strActionId = null;
		GEAEResultSet rsPriceList = null;

		try
		{
			//Set the action this to call procedure to laod engine model details
			strActionId = eCRDConstants.getActionId("eCRD_PRICE_LIST_REPORT");

			//ArrayList of Input Parameters
			arrlstInpParam = new ArrayList();
			//ArrayList of Output Parameters
			arrlstOutParam = new ArrayList();

			arrlstInpParam.add(strEngModel);
			arrlstInpParam.add(strPriceDesc);
			arrlstInpParam.add(strStartDate);
			arrlstInpParam.add(strEndDate);

			// Call this function to retrieve details of the engine model from database
			arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);
			//Set all parameters as retrieved from the database
			rsPriceList = (GEAEResultSet) arrlstOutParam.get(0);
			return rsPriceList;
		}
		finally
		{
			arrlstInpParam = null;
			arrlstOutParam = null;
			strActionId = null;
		}
	}
	
	
	/* Added By Santosh for Price Listing Report */
	public static ArrayList getPriceListForReport(String strEngModel, String strPriceDesc, String strStartDate, String strEndDate) throws Exception
	{
		ArrayList arrlstInpParam = null;
		ArrayList arrlstOutParam = null;
		String strActionId = null;
		GEAEResultSet rsPriceList = null;

		try
		{
			//Set the action this to call procedure to laod engine model details
			strActionId = eCRDConstants.getActionId("eCRD_PRICE_LIST_REPORT");

			//ArrayList of Input Parameters
			arrlstInpParam = new ArrayList();
			//ArrayList of Output Parameters
			arrlstOutParam = new ArrayList();

			arrlstInpParam.add(strEngModel);
			arrlstInpParam.add(strPriceDesc);
			arrlstInpParam.add(strStartDate);
			arrlstInpParam.add(strEndDate);

			// Call this function to retrieve details of the engine model from database
			arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);
			//Set all parameters as retrieved from the database
			//rsPriceList = (GEAEResultSet) arrlstOutParam.get(0);
			return arrlstOutParam;
		}
		finally
		{
			arrlstInpParam = null;
			arrlstOutParam = null;
			strActionId = null;
		}
	}
	
	/* Ended By Santosh for Price Listing Report */
	
	
	/*
	 *This method is used to check if repair desc is unique for particular combination 
	 */

	public String checkForUniqueRepairDescOrDispSeq(String strAction, ArrayList arrLstInParam) throws Exception
	{
		System.out.println("strAction==> "+strAction);
        ArrayList arrLstOutParam = null;
		String strMessage = "";
		try
		{
			arrLstOutParam = new ArrayList();
			arrLstOutParam = eCRDDBMediator.doDBOperation(strAction, arrLstInParam);
			strMessage = eCRDUtil.verifyNull((String) arrLstOutParam.get(0));
			return strMessage;
		}
		finally
		{
			arrLstOutParam = null;
		}
	}

	/*
	 * This method is used to check whether component code/description is unique or not
	 *
	 */
	public String checkForUniqueComponentCodeDesc(String strAction, ArrayList arrLstInParam) throws Exception
	{
		ArrayList arrLstOutParam = null;
		String strMessage = "";
		try
		{
			arrLstOutParam = new ArrayList();
			arrLstOutParam = eCRDDBMediator.doDBOperation(strAction, arrLstInParam);
			strMessage = eCRDUtil.verifyNull((String) arrLstOutParam.get(0));
			return strMessage;
		}
		finally
		{
			arrLstOutParam = null;
		}
	}
	public GEAEResultSet SearchUserData(String strAction, ArrayList arrlstInpParam) throws Exception
	{

		ArrayList arrlstOutParam = null;
		GEAEResultSet geaersetUserList = null;

		try
		{

			arrlstOutParam = new ArrayList();
			arrlstOutParam = eCRDDBMediator.doDBOperation(strAction, arrlstInpParam);
			geaersetUserList = (GEAEResultSet) arrlstOutParam.get(0);
			return geaersetUserList;
		}
		finally
		{
			arrlstOutParam = null;
			geaersetUserList = null;

		}
	}
	/**
		 * 
		 * @param request
		 * @return
		 * @throws Exception
		 */
	public static GEAEResultSet getSplitListing(HttpServletRequest request) throws Exception
	{
		GEAEResultSet geaersetSplitRep = null;
		GEAETag geaeTag = null;
		eCRDCustomerCatalog objeCRDCustomerCatalog = null;
		eCRDEngineModel objeCRDEngineModel = null;
		eCRDException objeCRDException = null;
		eCRDGroupedRepair objeCRDGroupedRepair = null;
		eCRDChildRepair objeCRDChildRepair = null;
		eCRDIndRepair objeCRDIndRepair = null;
		eCRDRepairPricing objeCRDRepairPricing = null;
		eCRDComponent objeCRDComponent = null;
		eCRDModule objeCRDModule = null;

		ArrayList arrlstEachRow = null;
		ArrayList arrlstRepais = null;

		String strModuleCd = null;
		String strCompCd = null;
		String strHref = null;
		String strAllRepsSaved = null;
		String strDispSeq = null;
		int intRepairSize = 0;
		int intNoOfRepsSaved = 0;
		try
		{
			objeCRDCustomerCatalog = (eCRDCustomerCatalog) eCRDUtil.getFromSession(request, eCRDConstants.STRCATALOG);
			geaersetSplitRep = new GEAEResultSet();
			if (objeCRDCustomerCatalog == null)
			{
				objeCRDException = new eCRDException();
				objeCRDException.setExcpId("CATALOG_NOT_SET");
				throw objeCRDException;
			}
			objeCRDEngineModel = objeCRDCustomerCatalog.getEngineModel();
			if (objeCRDEngineModel == null)
			{
				objeCRDException = new eCRDException();
				objeCRDException.setExcpId("MODEL_NOT_SET");
				throw objeCRDException;
			}
			strModuleCd = request.getParameter("hdnEngineModule");
			strCompCd = request.getParameter("hdnComponent");
			objeCRDModule = objeCRDEngineModel.getModule(strModuleCd);
			objeCRDComponent = objeCRDModule.getComponent(strCompCd);

			arrlstRepais = objeCRDComponent.getRepairs(eCRDConstants.STRSLITREPAIR, "S");
			intRepairSize = arrlstRepais.size();

			for (int intCtr = 0; intCtr < intRepairSize; intCtr++)
			{
				arrlstEachRow = new ArrayList();
				objeCRDIndRepair = (eCRDIndRepair) arrlstRepais.get(intCtr);
				objeCRDRepairPricing = objeCRDIndRepair.getObjRepairPricing();
				if (objeCRDRepairPricing != null)
				{
					strDispSeq = eCRDUtil.verifyNull(objeCRDRepairPricing.getRepairSeqNo());
				}
				else
				{
					strDispSeq = "";
				}
				arrlstEachRow.add(strDispSeq);
				//arrlstEachRow.add(objeCRDIndRepair.getStrRepairCode());
				strHref = "<A HREF='javascript:fnSplitModifyRepair(" + objeCRDIndRepair.getStrRepairCode() + ")" + "'>" + objeCRDIndRepair.getStrRepairDesc() + "</A>";
				objeCRDIndRepair.getStrRepairDesc();
				geaeTag = new GEAETag(objeCRDIndRepair.getStrRepairDesc(), strHref);
				arrlstEachRow.add(geaeTag);

				if (objeCRDRepairPricing == null)
				{
					geaeTag = new GEAETag("Not Saved", "<IMG src='" + eCRDUtil.getBasePath() + eCRDConstants.STRCTRL + "/img/icon_delete.gif' ALT='Data Not Saved' width='20' height='20'></IMG>");
				}
				else
				{
					intNoOfRepsSaved++;
					geaeTag = new GEAETag("Saved", "<IMG src='" + eCRDUtil.getBasePath() + eCRDConstants.STRCTRL + "/img/icon_checkmark.gif' ALT='Data Saved' width='20' height='20'></IMG>");
				}

				arrlstEachRow.add(geaeTag);
				geaersetSplitRep.addRow(arrlstEachRow);
				arrlstEachRow = null;
			}
			if (intNoOfRepsSaved == intRepairSize)
			{
				strAllRepsSaved = "Y";
			}
			else
			{
				strAllRepsSaved = "N";
			}
			geaersetSplitRep.setColumnHeading(1, "Disp Seq");
			geaersetSplitRep.setColumnHeading(2, "Repairs");
			geaersetSplitRep.setColumnHeading(3, "Saved ?");
			eCRDUtil.loadInSession(request, "strAllRepsSaved", strAllRepsSaved);
			return geaersetSplitRep;

		}
		finally
		{
			geaersetSplitRep = null;
			geaeTag = null;
			objeCRDCustomerCatalog = null;
			objeCRDEngineModel = null;
			objeCRDException = null;
			objeCRDGroupedRepair = null;
			objeCRDChildRepair = null;
			objeCRDIndRepair = null;
			objeCRDRepairPricing = null;
			objeCRDComponent = null;
			objeCRDModule = null;
			arrlstEachRow = null;
			arrlstRepais = null;
			strModuleCd = null;
			strCompCd = null;

		}
	}
	
	public GEAEResultSet getCatalogDetails(String strActionId, ArrayList arrlstInParam) throws Exception
	{
		GEAEResultSet rsResults = null;
		ArrayList arrlstOutParam = null;
		try
		{
			arrlstOutParam = new ArrayList();
			arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInParam);
			rsResults = (GEAEResultSet)arrlstOutParam.get(0);
			return rsResults;
		}
		finally
		{
			arrlstOutParam = null;
		}
	}
	/**
	 * Method to Add selected repairs in CSC
	 * @author Patni
	 *
	 */
	public String addRepairtoCSC(String strRepairIds, String strCustomerCatalogId, String strDefaultCatalogId, String strActionId, String strUserId) throws Exception
	{
		String strMessage = null;
		ArrayList arrlstInParam = null;
		ArrayList arrlstOutParam = null;
		try
		{
			arrlstInParam = new ArrayList();
			arrlstOutParam = new ArrayList();
			arrlstInParam.add(strRepairIds);
			arrlstInParam.add(strCustomerCatalogId);
			arrlstInParam.add(strDefaultCatalogId);
			arrlstInParam.add(strUserId);
			
			arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId,arrlstInParam);
			strMessage = eCRDUtil.verifyNull((String)arrlstOutParam.get(0));
			return strMessage;
		}
		finally
		{
		}
	}
	
	/**
	 * Returns list of repairs in the Default Catalog which are not present in Customer Specific Catalog
	 * based on Engine Model, Module, Component Code.
	 *
	 * Output fields :
	 * Reapir Code,
	 * Repair Description.
	 * @param strEngineModelCode
	 * @param strModuleCode
	 * @param strComponentCode
	 * @param strRepairCode - Repair code passed would be partial.
	 * @return String[][]
	 */
	public ArrayList getDefaultRepairListing(String strCatalogSeqId, String strEngineModelCode, String strModuleCode, String strComponentType, String strComponentCode, String strActionId) throws Exception
	{
		ArrayList arrlstInpParam = new ArrayList();
		ArrayList arrlstOutParam = new ArrayList();

		arrlstInpParam.add(strCatalogSeqId);
		arrlstInpParam.add(strEngineModelCode);
		arrlstInpParam.add(strModuleCode);
		arrlstInpParam.add(strComponentType);
		arrlstInpParam.add(strComponentCode);

		try
		{
			arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInpParam);
		}
		finally
		{
			arrlstInpParam = null;
		}
		return arrlstOutParam;
	}
}
