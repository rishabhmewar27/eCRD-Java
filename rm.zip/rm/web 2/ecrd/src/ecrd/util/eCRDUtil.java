//Source file: D:\\ECRD\\SOURCE CODE\\ecrd\\util\\eCRDUtil.java --


/**
 *  Project     :   eCRD
 *  Program     :   eCRDUtil.java
 *  Author      :   Patni Team
 *  Date        :   October 2004
 *  Security    :   Classified/Unclassified
 *  Restrictions:   GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 *
 *  ****************************************************
 *  *  Copyright(Year) with all rights reserved        *
 *  *          General Electric Company                *
 *  ****************************************************
 *  Description:   Description of Class
 *
 *
 *  Revision Log  (mm/dd/yy initials description)
 *  --------------------------------------------------------
 *  Patni Team   October 2004  Created
 *
 */
package ecrd.util;
import geae.dao.GEAEResultSet;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.PrintStream;
import java.io.RandomAccessFile;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.StringTokenizer;
import java.util.Date;
import java.lang.String;
import java.math.BigDecimal;

import ecrd.common.eCRDSessionMap;
import ecrd.exception.eCRDException;
import geae.util.GEAEConfigProvider;
import geae.util.GEAELogger;
import java.util.Iterator;
import ecrd.common.eCRDDBMediator;
import java.util.Set;
import ecrd.biz.eCRDComponent;
/**
 *  Description of the Class
 *
 * @author     Patni Computer
 * @created    December 13, 2003
 */
public class eCRDUtil
{
	public static final String POINT = ".";  
	 public static final String STRING_NULL = "null";
	 public static final String OBJECT_NULL = null;
	 public static final String INACTIVE = "0";
	 public static final String DBNULL = "NULL";




	/**  This variable is used to store the AFS Path. */
	private static String strAFSPath = "";

	/**  This variable is used to store the Base Path. */
	private static String strBasePath = "";

	/**  This variable is used to store the standard date format. */
	private static SimpleDateFormat sdf = new SimpleDateFormat("M/dd/yyyy");
	/**
	 *  <pre>
	 * This method is used to set the AFS path
	 * @param  strPath  The new aFSPath value
	 */
	public static void setAFSPath(String strPath)
	{
		strAFSPath = strPath;
	}

	/**
	 *  <pre>
	 * This method is used to get the AFS path
	 * @return        String  </pre> Returns AFSPath
	 */
	public static String getBasePath()
	{
		return strBasePath;
	}

	/**  <pre>
	* This method is used to set the Base path
	* @param  strPath  The new aFSPath value
	*/
	public static void setBasePath(String strPath)
	{
		strBasePath = strPath;
	}

	/**
		*  <pre>
		* This method is used to get the Base path
		* @return        String  </pre> Returns BasePath
		*/
	public static String getAFSPath()
	{
		return strAFSPath;
	}
	/**
	 *  If String is null returns empty String
	 *
	 * @param  inputStr  String to be verified for null value
	 * @return           If inputStr is empty, it rerurns empty string, else the same string.
	 */
	public final static String verifyNullNoTrim(String inputStr)
	{
		if (inputStr == null)
		{
			return "";
		}
		return inputStr;
	}
	/**
	 *  If String is null returns empty String
	 *
	 * @param  inputStr  String to be verified for null value
	 * @return           If inputStr is empty, it rerurns empty string, else returns trimmed string.
	 */
	public final static String verifyNull(String inputStr)
	{
		if (inputStr == null)
		{
			return "";
		}
		return inputStr.trim();
	}

	/**	This method takes in year(number) as input String. Increments the Year & returns it as a string.
		Method throws NumberFormatException if input String is not a Number.
		 * @param  strInp  String value, which needs to be increamented.
		 * @return   Either Increatented String, or empty string if input string could not be converted to int
		 */
	public static String incrementString(String strInp) throws NumberFormatException
	{
		int intValue = 0;
		String returnString = "";

		try
		{
			intValue = Integer.parseInt(strInp);
		}
		catch (NumberFormatException e)
		{
			return "";
		}

		intValue++;
		returnString = intValue + "";
		return returnString;
	}

	/**
	 * * Parses a String and returns a double
	 * @param  strInpFlt  String to be verified for it's value to be double
	 * @return            If string input could be converted to double, it returns that double value, else returns 0
	 */
	public final static double verifyDouble(String strInpFlt)
	{
		double doubleOut = 0;

		try
		{
			doubleOut = Double.parseDouble(strInpFlt);
			return doubleOut;
		}
		catch (NumberFormatException objExp)
		{
			doubleOut = 0;
			return doubleOut;
		}
	}
	/**
		 * * Parses a String and returns a Double
		 */
		public final static Double verifyDoubleObj(String strInpFlt)
		{
			Double doubleOut = null;
			try
			{
				if(strInpFlt==null || "".equals(strInpFlt))
				{
					return null;
				}
				doubleOut = new Double(Double.parseDouble(strInpFlt));
				return doubleOut;
			}
			catch (NumberFormatException objExp)
			{
				return doubleOut;
			}
		}
	/**
	 * Parses a String and returns a float
	 * @param  strInpFlt  String to be verified for it's value to be float
	 * @return            If string input could be converted to float, it returns that float value, else returns 0
	 */
	public final static float verifyFloat(String strInpFlt)
	{
		float fltOut = 0;

		try
		{
			fltOut = Float.parseFloat(strInpFlt);
			return fltOut;
		}
		catch (NumberFormatException objExp)
		{
			fltOut = 0;
			return fltOut;
		}
	}

	/**
	 * Parses the string and returns and integer value
	 *
	 * @param  strInpInt  String to be verified for it's value to be int
	 * @return            If string input could be converted to int, it returns that int value, else returns 0
	 */
	public final static int verifyInt(String strInpInt)
	{
		int intOut = 0;

		try
		{
			intOut = Integer.parseInt(strInpInt);
			return intOut;
		}
		catch (NumberFormatException objExp)
		{
			intOut = 0;
			return intOut;
		}
	}
	/**
		 * Parses the string and returns and Integer
		 */
		public final static Integer verifyIntObj(String strInpInt)
		{
			Integer intOut = null;

			try
			{
				if(strInpInt==null || "".equals(strInpInt))
				{
					return null;
				}
				intOut = new Integer(Integer.parseInt(strInpInt));
				return intOut;
			}
			catch (NumberFormatException objExp)
			{
				return intOut;
			}
		}

	/**
	 * Format a float value upto a precision specified in the parameters
	 *
	 * @param  	p_value  		float value to be formatted
	 * @param	int_precision	number of digits precision required
	 * @return  String  returns String value of float with requested precision
	 */

	public static String Format(float p_value, int intPrecision)
	{
		String l_NewOut = "";
		StringBuffer strBufFormat;
		int intCount;

		strBufFormat = new StringBuffer("#########0.");

		for (intCount = 0; intCount < intPrecision; intCount++)
		{
			strBufFormat.append("0");
		}

		NumberFormat formatter = new DecimalFormat(strBufFormat.toString());
		//return formatter.format(p_value);
		l_NewOut = formatter.format((double) p_value);

		/*
				if (l_NewOut.equals("-0.00")) {
					l_NewOut = "0.00";
				}
		*/
		return l_NewOut;
	}

	/**
	 *   Format a float value and returns 0.00
	 *
	 * @param  p_value  Float value to be formatted
	 * @return          returns String value of float with 2 decimal precision
	 */
	public static String Format(float p_value)
	{
		String l_NewOut = "";

		NumberFormat formatter = new DecimalFormat("#########0.00");
		//return formatter.format(p_value);
		l_NewOut = formatter.format((double) p_value);
		if (l_NewOut.equals("-0.00"))
		{
			l_NewOut = "0.00";
		}
		return l_NewOut;
	}

	/**
	 * Format a double value upto a precision specified in the parameters
	 *
	 * @param  p_value  		double value to be formatted
	 * @param	int_precision	number of digits precision required
	 * @return  String  returns String value of double with requested precision
	 */

	public static String Format(double p_value, int intPrecision)
	{
		String l_NewOut = "";
		StringBuffer strBufFormat;
		int intCount;

		strBufFormat = new StringBuffer("#########0.");

		for (intCount = 0; intCount < intPrecision; intCount++)
		{
			strBufFormat.append("0");
		}

		NumberFormat formatter = new DecimalFormat(strBufFormat.toString());
		//return formatter.format(p_value);
		l_NewOut = formatter.format(p_value);

		/*
				if (l_NewOut.equals("-0.00")) {
					l_NewOut = "0.00";
				}
		*/
		return l_NewOut;
	}

	/**
	 * Format a double value and returns 0.00
	 *
	 * @param  p_value  double value to be formatted
	 * @return  String  returns String value of double with 2 decimal precision
	 */

	public static String Format(double p_value)
	{
		String l_NewOut = "";

		NumberFormat formatter = new DecimalFormat("#########0.00");
		//return formatter.format(p_value);
		l_NewOut = formatter.format(p_value);
		if (l_NewOut.equals("-0.00"))
		{
			l_NewOut = "0.00";
		}
		return l_NewOut;
	}
	/**
	 *  Gets the currentYear attribute of the LCSUtil class
	 * @return        The currentYear value
	 */
	public final static int getCurrentYear()
	{
		int currYear;
		Calendar rightNow = Calendar.getInstance();

		currYear = rightNow.get(Calendar.YEAR);
		return currYear;
	}

	/**
	 * Formats a string with the separator and returns it with a break
	 * @param  inputStr  String to be formatted
	 * @param  strSep    Seperator used in the string
	 * @return           Returns a string with breaks instead of seperator used
	 */
	public final static String reFormat(String inputStr, String strSep)
	{
		StringTokenizer st = new StringTokenizer(verifyNull(inputStr), strSep);
		StringBuffer strBuff = new StringBuffer("");

		while (st.hasMoreTokens())
		{
			strBuff.append(st.nextToken());
			strBuff.append("<BR>");

		}

		return strBuff.toString();
	}

	/**
	 * Formats a string  and returns it with a break
	 *
	 * @param  strNonFormString  Formats the string and changes the spaces to breaks.
	 * @return                   String formatted to have breaks instead of spaces.
	 */
	public final static String formatString(String strNonFormString) throws Exception
	{
		StringTokenizer strtkn = null;
		String strReturnString = "";
		int intCtr = 0;
		int intRetLength = 0;

		try
		{
			strNonFormString = verifyNull(strNonFormString);
			if (strNonFormString.length() > 50)
			{
				strtkn = new StringTokenizer(strNonFormString, " ");
				intRetLength = strtkn.countTokens();
				while (strtkn.hasMoreTokens())
				{
					strReturnString = strReturnString + strtkn.nextToken() + " ";
					intRetLength = intRetLength - 1;
					while (intCtr < 5)
					{
						strReturnString = strReturnString + strtkn.nextToken() + " ";
						intRetLength = intRetLength - 1;
						intCtr = intCtr + 1;
					}
					intCtr = 0;
					//if(intRetLength!=0)
					strReturnString = strReturnString + "<BR/>";
				}
			}
			else
			{
				strReturnString = strNonFormString;
			}
		}
		finally
		{
			strtkn = null;
		}
		return strReturnString;
	}

	/**
	 *  This method will return the
	 *  float value with the given precesion value.
	 *
	 * @param  strValue      (String), intPrecesion (int)
	 * @param  intPrecesion  precision required
	 * @return               return the float value with the given precesion value
	 */
	public final static float getFloatPrecesion(String strValue, int intPrecesion)
	{
		//this is the multiplication factor value.
		int intMultipicationValue = 10;
		Float FValue = new Float(strValue);
		float fValue = 0;

		//if there is no value then return 0.
		if ("".equals(strValue))
		{
			return fValue;
		}

		//if precesion is 0 then return the int value of the value sent .
		if (intPrecesion == 0)
		{
			return (int) (FValue.floatValue());
		}

		//determine the multiplication factor. it depend on the precession
		for (int intValue = 0; intValue < intPrecesion - 1; intValue++)
		{
			intMultipicationValue = intMultipicationValue * 10;
		}

		int intValueConverted = (int) (FValue.floatValue() * intMultipicationValue);

		fValue = ((float) intValueConverted / intMultipicationValue);

		return fValue;
	}

	/**
	 *  This method will return the
	 *  float value with the given precesion value.
	 *
	 * @param  fValue        float to be converted to have specified precision
	 * @param  intPrecesion  required precision
	 * @return               float value with the specified precision
	 */
	public final static float getFloatPrecesion(float fValue, int intPrecesion)
	{
		//this is the multiplication factor value.

		int intMultipicationValue = 10;

		//if precesion is 0 then return the int value of the value sent .
		if (intPrecesion == 0)
		{
			return (int) fValue;
		}

		//determine the multiplication factor. it depend on the precession
		for (int intValue = 0; intValue < intPrecesion - 1; intValue++)
		{
			intMultipicationValue = intMultipicationValue * 10;
		}

		int intValueConverted = (int) ((fValue) * intMultipicationValue);

		fValue = ((float) intValueConverted / intMultipicationValue);

		return fValue;
	}

	/**
	 *  This method will return the
	 *  double value with the given precesion value.
	 *
	 * @param  strValue      String value to be converted to double with the specified precision
	 * @param  intPrecesion  required precision
	 * @return               double value with the specified precision
	 */
	public final static double getDoublePrecesion(String strValue, int intPrecesion)
	{
		//this is the multiplication factor value.
		int intMultipicationValue = 10;
		Double DValue = new Double(strValue);
		double dValue = 0;

		//if there is no value then return 0.
		if ("".equals(strValue))
		{

			return dValue;

		}

		//if precesion is 0 then return the int value of the value sent .
		if (intPrecesion == 0)
		{
			return (int) (DValue.doubleValue());
		}

		//determine the multiplication factor. it depend on the precession
		for (int intValue = 0; intValue < intPrecesion - 1; intValue++)
		{
			intMultipicationValue = intMultipicationValue * 10;
		}

		int intValueConverted = (int) (DValue.doubleValue() * intMultipicationValue);

		dValue = ((double) intValueConverted / intMultipicationValue);

		return dValue;
	}

	/**
	 * If string is null returns 0
	 *
	 * @param  inputStr  String to be verified for null value
	 * @return           Returns trimmed version of input string, and zero if input string was null
	 */
	public final static String verifyNullReturnZero(String inputStr)
	{
		if (inputStr == null || "".equals(inputStr))
		{
			return "0";
		}
		return inputStr.trim();
	}

	/**
	 * <pre>
	 * This Method resetResultSet() is to initialize the resultSet
	 * @param GEAEResultSet rs The resultset to be reset
	 * @return GEAEResultSet   The resultset with current record set to zero
	 * </pre>
	 **/
	public static GEAEResultSet resetResultSet(GEAEResultSet rs) throws Exception
	{
		if (rs.getCurrentRow() > 0)
			rs.setCurrentRow(0);
		return rs;
	}

	/**
	 * <pre>
	 * This Method checkNull() is to check the null or None and return ""
	 * @param String pStr String to be checked for null or 'None'
	 * @return String 	  Empty string if input string was null or 'None', and trimmed version of string otherwise
	 * </pre>
	 **/
	public static final String checkNull(String pStr)
	{
		if ((pStr == null) || ("None".equals(pStr)))
		{
			pStr = "";
		}
		return pStr.trim();
	}

	/**
	 * <pre>
	 * For formatting the html strings before displaying
	 * @param  String	HTML String to be formatted
	 * @return String	Formatted HTML String
	 * </pre>
	 **/

	public static String formatHTMLString(String strSource)
	{
		if (!(strSource == null || strSource.equals("")))
		{
			strSource = replaceString(strSource, "\r\n", "&#13;");
			strSource = replaceString(strSource, "\r", "&#10;");
			strSource = replaceString(strSource, "\n", "&#13;");
			strSource = replaceString(strSource, "\"", "&#34;");
			strSource = replaceString(strSource, "\'", "&#39;");
			strSource = replaceString(strSource, "<", "&lt;");
			strSource = replaceString(strSource, ">", "&gt;");

		}
		return strSource;
	}

	/**
	 * <pre>
	 * For formatting the html strings before displaying
	 * @param  String	HTML String to be formatted
	 * @return String	Formatted HTML String, returns null if input string was null
	 * </pre>
	 **/
	public static String getHTMLString(String str)
	{
		if (str == null)
			return null;

		//str = replaceString(str,"&","&amp;");
		str = replaceString(str, "<", "&lt;");
		str = replaceString(str, ">", "&gt;");
		str = replaceString(str, "\"", "&#34;");
		str = replaceString(str, "'", "&#39;");

		// Replace for enter key
		str = replaceString(str, "\r", "&#13;");
		str = replaceString(str, "\n", "&#10;");

		return str;

	}

	/**
	 * <pre>
	 * This method replaces every occurrence of the string, that needs to be replaced,
	 * with the new string passed as an argument
	 * @param strOriginal        Original String
	 * @param strToReplace       A String To be Replaced
	 * @param strToReplaceWith   The String to be Replaced with
	 * @return - The replaced String
	 * </pre>
	 **/

	public static String replaceString(String strOriginal, String strToReplace, String strToReplaceWith)
	{

		int intLoc = -1;
		int intStrReplLen = 0;
		int intStart = 0;

		String strToAL = "";
		String strFromAL = "";

		if ((strOriginal != null) && (strToReplace != null) && (strToReplaceWith != null))
		{
			intStrReplLen = strToReplace.length();
			strFromAL = strOriginal;
			intLoc = strOriginal.indexOf(strToReplace);
			if (intLoc != -1)
			{
				do
				{
					intLoc = strFromAL.indexOf(strToReplace);
					if (intLoc != -1)
					{
						strToAL += strFromAL.substring(intStart, intLoc);
						strToAL += strToReplaceWith;
						strFromAL = strFromAL.substring(intLoc + intStrReplLen);
					}
				}
				while (intLoc != -1);
				if ((strFromAL != null) && (strFromAL.length() > 0))
				{
					strToAL += strFromAL;
				}
			}
			else
			{
				strToAL = strFromAL;
			}
		}
		else
		{
			return null;
		}
		return strToAL;
	}
	/*
	 * This Method Returns the String Value For the input double value
	 * E.g.  9.99999999999999E12  - 9999999999999.99
	 *
	 */
	public static final String formatDoubleToFloat(double strDblValue)
	{
		String strFloatValue = "";
		try
		{
			strFloatValue = "" + NumberFormat.getInstance().format(strDblValue);
			strFloatValue = replaceString(strFloatValue,",","");
			return strFloatValue;
		}
		finally
		{
			strFloatValue = null;
		}
	}

	/**
	 * <pre>
	 * This Method makeItZero() is to check the null or "" and return "0"
	 * @param String pStr String to be made zero if null or empty
	 * @return String	  Returns 0 in string, if input string is null or empty
	 * </pre>
	 **/
	public static final String makeItZero(String pStr)
	{
		if (pStr == null)
		{
			return "0";
		}

		pStr = pStr.trim();
		if ("".equals(pStr))
		{
			return "0";
		}
		return pStr;
	}

	/**
	 * <pre>
	 * Method converts a string to String array
	 * @param pStrInput Input String
	 * @param pStrSeperator String separator
	 * @return  A String Array of separated strings
	 * @exception Exception
	 * </pre>
	 **/
	public static GEAEResultSet getSelectedOptionsFirst(GEAEResultSet rsMasterList, ArrayList arrLstSelectedOptions) throws Exception
	{
		GEAEResultSet rsOutput = new GEAEResultSet();
		ArrayList arrLstOutput = null;
		try
		{
			if (rsMasterList != null && arrLstSelectedOptions != null)
			{
				if (arrLstSelectedOptions.size() <= 0)
				{
					rsOutput = rsMasterList;
				}
				else
				{
					rsMasterList.setCurrentRow(0);
					while (rsMasterList.next())
					{
						if (arrLstSelectedOptions.contains(rsMasterList.getString(1)))
						{
							arrLstOutput = new ArrayList();
							arrLstOutput.add(rsMasterList.getString(1));
							arrLstOutput.add(rsMasterList.getString(2));
							rsOutput.addRow(arrLstOutput);
						}
					}
					rsMasterList.setCurrentRow(0);
					while (rsMasterList.next())
					{
						if (!arrLstSelectedOptions.contains(rsMasterList.getString(1)))
						{
							arrLstOutput = new ArrayList();
							arrLstOutput.add(rsMasterList.getString(1));
							arrLstOutput.add(rsMasterList.getString(2));
							rsOutput.addRow(arrLstOutput);
						}
					}
				}
			}
			return rsOutput;
		}
		finally
		{
			arrLstOutput = null;
		}
	}

	/**
	 * <pre>
	 * Method converts a two dimensional string array to resultset
	 * @param String[][] The two dimensional String array to be converted to resultset
	 * @return  GEAEResultSet The resultset converted from 2D array
	 * @exception Exception
	 * </pre>
	 **/
	public static GEAEResultSet getRSFrom2DStringArray(String[][] strArrInput) throws Exception
	{
		GEAEResultSet rsOutput = new GEAEResultSet();
		ArrayList arrLstOutput = null;
		try
		{
			if (strArrInput != null && strArrInput.length > 0)
			{
				for (int i = 0; i < strArrInput.length; i++)
				{
					arrLstOutput = new ArrayList();
					for (int j = 0; j < strArrInput[0].length; j++)
					{
						arrLstOutput.add(strArrInput[i][j]);
					}
					rsOutput.addRow(arrLstOutput);
				}
			}
			return rsOutput;
		}
		finally
		{
			arrLstOutput = null;
		}
	}

	/**
	 * <pre>
	 * Method converts a string to String array
	 * @param pStrInput Input String delimited by seperator and to be converted into an array
	 * @param pStrSeperator String separator used in the input string
	 * @return  A String Array of separated strings
	 * @exception Exception
	 * </pre>
	 **/
	public static String[] getStringArrayFromString(String pStrInput, String pStrSeperator) throws Exception
	{
		String[] strArrOutput = { "" };
		ArrayList arrLstInput = null;
		int intLen = 0;
		try
		{
			arrLstInput = convertStringToArrayList(pStrInput, pStrSeperator);

			if (arrLstInput != null)
			{
				intLen = arrLstInput.size();
				strArrOutput = new String[intLen];
				for (int i = 0; i < intLen; i++)
				{
					strArrOutput[i] = verifyNull((String) arrLstInput.get(i));
				}
			}
		}
		finally
		{
			arrLstInput = null;
		}
		return strArrOutput;
	}

	/**
	 * <pre>
	 * This method creates an arraylist from the string passed as an argument
	 * that has values that are separated by Specified Separator Character.
	 * The method returns null for the string of the size of the delimiter.
	 * @param strInputParam  A String delimited by Separator
	 * @param strSeparator   Separator String
	 * @return - ArrayList of separated strings
	 * @exception Exception
	 * </pre>
	 **/
	public static ArrayList convertStringToArrayList(String strInputParam, String strSeparator) throws Exception
	{
		int intLoc = -1;
		String strFromInput = "";
		String strSep = "";
		int intStrSepLen = 0;
		int intStart = 0;
		ArrayList arrLstTemp = null;

		try
		{
			if ((strInputParam != null) && (strSeparator != null))
			{
				arrLstTemp = new ArrayList();
				strSep = new String(strSeparator);
				strFromInput = new String(strInputParam);

				if (((strInputParam.trim()).length() <= (strSeparator.trim()).length()) || strSeparator.trim().equals(strInputParam.trim()))
				{
					return arrLstTemp;
				}

				if (strSep != null)
				{
					intStrSepLen = strSep.length();
				}
				if (intStrSepLen > 0)
				{
					intLoc = strFromInput.indexOf(strSep);
					if (intLoc != -1)
					{
						do
						{
							intLoc = strFromInput.indexOf(strSep);
							if (intLoc != -1)
							{
								arrLstTemp.add(strFromInput.substring(intStart, intLoc).trim());
								strFromInput = strFromInput.substring(intLoc + intStrSepLen);
							}
						}
						while (intLoc != -1);
						if (strFromInput != null)
						{
							arrLstTemp.add(strFromInput.trim());
						}
					}
					else
					{
						arrLstTemp.add(strFromInput.trim());
					}
				}
				else
				{
					arrLstTemp.add(strFromInput.trim());
				}
			}
			else
			{
				return null;
			}

			if ((arrLstTemp != null) && (arrLstTemp.size() > 0))
			{
				return arrLstTemp;
			}
			else
			{
				return null;
			}
		}
		finally
		{
			strFromInput = null;
			strSep = null;
		}
	}

	/**
	 * <pre>
	 * This method creates a Delimited String From an Arraylist
	 * @param arrLstValues   ArrayList Of Values To be Converted to string
	 * @param strDelimeter   Any Character/String separator
	 * @return - The delimited String
	 * @exception Exception
	 * </pre>
	 **/
	public static String convertArrayListtoString(ArrayList arrLstValues, String strDelimeter) throws Exception
	{

		int i = 0;
		int intDelLength = 0;
		int intArrLstCount = 0;

		String strToReturn = "";
		String strToAdd = "";

		try
		{

			if (arrLstValues != null && arrLstValues.size() <= 0)
			{
				return "";
			}

			intDelLength = (verifyNull(strDelimeter)).length();
			if ((arrLstValues != null) && (strDelimeter != null) && (intDelLength > 0))
			{
				intArrLstCount = arrLstValues.size();
				for (i = 0; i < intArrLstCount; i++)
				{
					strToAdd = (String) arrLstValues.get(i);
					strToReturn = strToReturn + strToAdd + strDelimeter;
				}
				strToReturn = strToReturn.substring(0, (strToReturn.length() - intDelLength));
			}
		}
		finally
		{
			strToAdd = null;
		}
		return (strToReturn);
	}
	/**
	 * <pre>
	 * This method is used to populate  a select box from a GEAEResultSet
	 * With All option after Select..
	 * @param  rsetGeaers <code> GEAEResultSet </code> GEAEResultset from
	 * which the select box will be populated
	 * @param  strSelectedValue <code> String </code> The value which will be selected
	 * in the select box
	 * @param  <code> blnSplcase </code> If this value is set to false then
	 * showing an Option selected, it will do a equals check between GEAEResultSet string
	 * and strSelectedValue and if set to true it will do an
	 * rs.getString(1).indexOf(strSelectedValue) check.
	 * @return <code> String </code> HTML code of drop down
	 * </pre>
	 */
	public static String populateOptionsWithAll(GEAEResultSet rsetGeaers, String strSelectedValue, boolean blnSplcase) throws Exception
	{
		boolean blnFound = false;
		String strOption_code = "";
		StringBuffer sbOutBuffer = null;
		try
		{
			sbOutBuffer = new StringBuffer();
			//IF null empty String will be returned
			if (null != rsetGeaers)
			{
				rsetGeaers.setCurrentRow(0);
				sbOutBuffer.append("<OPTION VALUE=\"\">Select...</OPTION>");
				sbOutBuffer.append("<OPTION VALUE=\"ALL\" ");
				if (blnSplcase)
				{
					if (!(blnFound) && (!(("ALL".indexOf(strSelectedValue)) == -1)) && (!"".equals(strSelectedValue)))
					{
						sbOutBuffer.append(" SELECTED ");
						blnFound = true;
					}
				}
				else
				{
					if (!(blnFound) && ("ALL".trim().equals(strSelectedValue.trim())))
					{
						sbOutBuffer.append(" SELECTED ");
						blnFound = true;
					}
				}
				sbOutBuffer.append(">All</OPTION>");
				while (rsetGeaers.next())
				{
					strOption_code = rsetGeaers.getString(1).trim();
					sbOutBuffer.append("<OPTION VALUE=\"" + strOption_code + "\"");

					if (blnSplcase)
					{
						if (!(blnFound) && (!((strOption_code.indexOf(strSelectedValue)) == -1)) && (!"".equals(strSelectedValue)))
						{
							sbOutBuffer.append(" SELECTED ");
							blnFound = true;
						}
					}
					else
					{
						if (!(blnFound) && (strOption_code.trim().equals(strSelectedValue.trim())))
						{
							sbOutBuffer.append(" SELECTED ");
							blnFound = true;
						}
					}

					sbOutBuffer.append(">");
					sbOutBuffer.append(rsetGeaers.getString(2).trim());
					sbOutBuffer.append("</OPTION>\n");
				} //end of while
			} //end of if
		}
		finally
		{
			strOption_code = "";
		}
		return sbOutBuffer.toString();
	}
	/**
	 * <pre>
	 * This method is used to populate  a select box from a GEAEResultSet
	 * @param  rsetGeaers <code> GEAEResultSet </code> GEAEResultset from
	 * which the select box will be populated
	 * @param  strSelectedValue <code> String </code> The value which will be selected
	 * in the select box
	 * @param  <code> blnSplcase </code> If this value is set to false then
	 * showing an Option selected, it will do a equals check between GEAEResultSet string
	 * and strSelectedValue and if set to true it will do an
	 * rs.getString(1).indexOf(strSelectedValue) check.
	 * @return <code> String </code> HTML code of drop down
	 * </pre>
	 */
	public static String populateOptions(GEAEResultSet rsetGeaers, String strSelectedValue, boolean blnSplcase) throws Exception
	{
		boolean blnFound = false;
		String strOption_code = "";
		StringBuffer sbOutBuffer = null;
		try
		{
			sbOutBuffer = new StringBuffer();
			//IF null empty String will be returned
			if (null != rsetGeaers)
			{
				rsetGeaers.setCurrentRow(0);
				sbOutBuffer.append("<OPTION VALUE=\"\">Select...</OPTION>");
				while (rsetGeaers.next())
				{
					strOption_code = rsetGeaers.getString(1).trim();
                    sbOutBuffer.append("<OPTION VALUE=\"" + strOption_code + "\"");



                    if (blnSplcase)
					{
						if (!(blnFound) && (!((strOption_code.indexOf(strSelectedValue)) == -1)) && (!"".equals(strSelectedValue)))
						{
							sbOutBuffer.append(" SELECTED ");
							blnFound = true;
						}
					}
					else
					{

						if (!(blnFound) && (strOption_code.trim().equals(strSelectedValue.trim())))
						{
                            System.out.println("blnSplcase :- " + blnSplcase);
                            System.out.println("blnFound : -" + blnFound);
                            System.out.println("strOption_code :- " + strOption_code);
                            System.out.println("strSelectedValue :- " + strSelectedValue);
							sbOutBuffer.append(" SELECTED ");
							blnFound = true;
						}
					}

					sbOutBuffer.append(">");
					sbOutBuffer.append(rsetGeaers.getString(2).trim());
					sbOutBuffer.append("</OPTION>\n");

				} //end of while
			} //end of if
		}
		finally
		{
			strOption_code = "";
		}
		return sbOutBuffer.toString();
	}

	/**
	 * <pre>
	 * This method is used to populate  a select box from a GEAEResultSet
	 * @param  rsetGeaers <code> GEAEResultSet </code> GEAEResultset from
	 * which the select box will be populated
	 * @param  strSelectedValue <code> String </code> The value which will be selected
	 * in the select box
	 * @param  <code> blnSplcase </code> If this value is set to false then
	 * showing an Option selected, it will do a equals check between GEAEResultSet string
	 * and strSelectedValue and if set to true it will do an
	 * rs.getString(1).indexOf(strSelectedValue) check.
	 * @param  intCodeCol <code> int </code> This value gives the position of Code in the
	 * resultSet and does away with the dependency of having to always store the code
	 * previous to value in ResultSet
	 * @param  intValueColumn <code> int </code> This value gives the position of Code in the
	 * resultSet
	 * @return <code> String </code> HTML code of drop down
	 * </pre>
	 */

	public static String populateOptions(GEAEResultSet rsetGeaers, String strSelectedValue, boolean blnSplcase, int intCodeCol, int intValueColumn) throws Exception
	{
		boolean blnFound = false;
		String strOption_code = "";
		StringBuffer sbOutBuffer = null;
		try
		{
			sbOutBuffer = new StringBuffer();

			//IF null empty String will be returned
			if (null != rsetGeaers)
			{
				rsetGeaers.setCurrentRow(0);
				sbOutBuffer.append("<OPTION VALUE=\"\">Select...</OPTION>");
				while (rsetGeaers.next())
				{
					strOption_code = rsetGeaers.getString(intCodeCol).trim();
					sbOutBuffer.append("<OPTION VALUE=\"" + strOption_code + "\"");

					if (blnSplcase)
					{
						if (!(blnFound) && (!((strOption_code.indexOf(strSelectedValue)) == -1)) && (!"".equals(strSelectedValue)))
						{
							sbOutBuffer.append(" SELECTED ");
							blnFound = true;
						}
					}
					else
					{
						if (!(blnFound) && (strOption_code.trim().equals(strSelectedValue.trim())))
						{
							sbOutBuffer.append(" SELECTED ");
							blnFound = true;
						}
					}

					sbOutBuffer.append(">");
					sbOutBuffer.append(rsetGeaers.getString(intValueColumn).trim());
					sbOutBuffer.append("</OPTION>\n");
				} //end of while
			} //end of if
		}
		finally
		{
			strOption_code = "";
		}
		return sbOutBuffer.toString();
	}

	/**
		 * <pre>
		 * This method is used to populate  a select box from a HashMap.values().toString()
		 * @param  strDropDown <code> String </code> HashMap.values().toString()is
		 * passed as strDropdown.
		 * @param  strSelectedValue <code> String </code> The value which will be selected
		 * in the select box
		 * @param  <code> blnSplcase </code> If this value is set to false then
		 * showing an Option selected, it will do a equals check between GEAEResultSet string
		 * and strSelectedValue and if set to true it will do an
		 * rs.getString(1).indexOf(strSelectedValue) check.
		 * @return <code> String </code> HTML code of drop down
		 * </pre>
		 */

	public static String populateOptions(String strDropDown, String strSelectedValue, boolean blnSplcase) throws Exception
	{
		boolean blnFound = false;
		String strOption_code = "";
		StringBuffer sbOutBuffer = new StringBuffer();
		ArrayList arrlstDD = convertStringToArrayList(strDropDown, ",");
		int intCount = 0;
		try
		{
			//IF null empty String will be returned
			if (null != arrlstDD)
				intCount = arrlstDD.size();

			if (intCount > 0)
				sbOutBuffer.append("<OPTION VALUE=\"\">Select...</OPTION>");

			for (int i = intCount - 1; i >= 0; i--)
			{
				strOption_code = ((String) arrlstDD.get(i)).trim();
				sbOutBuffer.append("<OPTION VALUE=\"" + strOption_code + "\"");

				if (blnSplcase)
				{
					if (!(blnFound) && (!((strOption_code.indexOf(strSelectedValue)) == -1)) && (!"".equals(strSelectedValue)))
					{
						sbOutBuffer.append(" SELECTED ");
						blnFound = true;
					}
				}
				else
				{
					if (!(blnFound) && (strOption_code.trim().equals(strSelectedValue.trim())))
					{
						sbOutBuffer.append(" SELECTED ");
						blnFound = true;
					}
				}

				sbOutBuffer.append(">");
				sbOutBuffer.append(((String) arrlstDD.get(i)).trim());
				sbOutBuffer.append("</OPTION>\n");
			} //end of FOR
		}
		finally
		{
			strOption_code = "";
		}
		return sbOutBuffer.toString();
	}

	/**
		 * <pre>
		 * This method is used to populate  a select box of years.No of years and base year
		 * are passed as input parameters.
		 * @param  intBaseYear <code> int </code> The base year from which to start
		 * counting
		 * @param  intNoOfYears <code> int</code> The number of years from base year
		 * that needs to be populated in the select box.
		 * @return <code> String </code> HTML code of drop down
		 * </pre>
		 */

	public static String populateYearOptions(int intBaseYear, int intNoOfYears, String strSelectedValue) throws Exception
	{
		StringBuffer sbOutBuffer = new StringBuffer();

		boolean blnFound = false;
		try
		{

			sbOutBuffer.append("<OPTION VALUE=\"\">Select...</OPTION>");
			for (int intCount = 0; intCount < intNoOfYears; intCount++)
			{
				sbOutBuffer.append("<OPTION VALUE=\"" + (intBaseYear + intCount) + "\"");
				if ("".equals(strSelectedValue))
				{
					strSelectedValue = "0";
				}

				if ((!blnFound) && strSelectedValue.trim() != null && ((intBaseYear + intCount) == Integer.parseInt(strSelectedValue.trim())))
				{
					sbOutBuffer.append(" SELECTED ");
					blnFound = true;
				}
				sbOutBuffer.append(">");
				sbOutBuffer.append("" + (intBaseYear + intCount));
				sbOutBuffer.append("</OPTION>\n");
			}
		}
		finally
		{
		}
		return sbOutBuffer.toString();
	}

	/**
		 * <pre>
		 * This method is used to populate  a select box of years.No of years and base year
		 * are passed as input parameters.
		 * @param  intBaseYear <code> int </code> The base year from which to start
		 * counting
		 * @param  intNoOfYears <code> int</code> The number of years from base year
		 * that needs to be populated in the select box.
		 * @return <code> String </code> HTML code of drop down
		 * </pre>
		 */

	public static String populateYearOptions(int intBaseYear, int intNoOfYears) throws Exception
	{
		StringBuffer sbOutBuffer = new StringBuffer();
		try
		{
			sbOutBuffer.append("<OPTION VALUE=\"\">Select...</OPTION>");
			for (int intCount = 0; intCount < intNoOfYears; intCount++)
			{
				sbOutBuffer.append("<OPTION VALUE=\"" + (intBaseYear + intCount) + "\"");
				sbOutBuffer.append(">");
				sbOutBuffer.append("" + (intBaseYear + intCount));
				sbOutBuffer.append("</OPTION>\n");
			}
		}
		finally
		{
		}
		return sbOutBuffer.toString();
	}

	/**
	   * <pre>
	   * Method to escape single and double quote and back slash within a string
	   * @author Patni , Offshore
	   * @param  str <code> String </code> String in which the
	   *         quotes to be escaped is present.
	   * @return String
	   * @throws  Exception if error occurs while processing.
	   * </pre>
	   */
	public static String replaceQuoteForJS(String str) throws Exception
	{
		try
		{
			return escapeString(escapeString(escapeString(str, "\\"), "'"), "\"");
		}
		catch (Exception exception)
		{
			throw new Exception("Error in eCRDUtil.replaceQuoteForJS::" + exception);
		}
	}

	/**
	* <pre>
	* Method to escape characters within a String. It uses '\' as
	* escape character.
	* @author Patni , Offshore
	* @param  str <code> String </code> String in which the
	*         characters to be escaped is present.
	* @param  strEsc <code> String </code> String which is to be
	*         escaped.
	* @return <code> String </code>
	* @throws  Exception if error occurs while processing.
	* </pre>
	*/
	public static String escapeString(String str, String strEsc) throws Exception
	{
		int intLength = 0;
		String strTemp = "";
		StringBuffer buff = new StringBuffer("");
		try
		{
			intLength = verifyNull(str).length();

			for (int intC = 1; intC <= intLength; intC++)
			{
				strTemp = str.substring(intC - 1, intC);
				if (strTemp.equals(strEsc))
				{
					buff = new StringBuffer(str);
					buff = buff.insert(intC - 1, "\\");
					str = buff.toString();
					intLength++;
					intC++;
				}
			}
			return str;
		}
		finally
		{
			strTemp = null;
			buff = null;
		}
	}

	/**
	* Used for replacing single quote with a HTML printable single quote.
	* @param str <code> String </code> Original String
	* @param quoteType <code> String </code> Represents type of quote
	* @return String New String after replacing a single quote with a HTML
	* printable single quote.
	* @throws  Exception if error occurs while processing.
	*/
	public static String replaceQuote(String str, String quoteType) throws Exception
	{
		String replaceString = "";
		String resultString = "";
		String searchString = quoteType;
		int i;

		try
		{
			if ("'".equals(quoteType))
			{
				replaceString = "&#39;";
			}
			else
			{
				replaceString = "&#34;";
			}
			if (str != null)
			{
				do
				{
					i = str.indexOf(searchString);
					if (i != -1)
					{
						resultString = str.substring(0, i);
						resultString = resultString + replaceString;
						resultString = resultString + str.substring(i + searchString.length());
						str = resultString;
					}
				}
				while (i != -1);
			}
			else
			{
				str = "";
			}
			return str;
		}
		finally
		{
			replaceString = null;
			resultString = null;
			searchString = null;
		}
	}
	/**
	 * <pre>
	 * This method creates an arraylist from the string passed as an argument
	 * that has values that are separated by Specified Separator Character.
	 * @param strInputParam  A String delimited by Separator
	 * @param strSeparator   Separator String
	 * @return - ArrayList of separated strings
	 * @exception Exception
	 * </pre>
	 **/
	public static ArrayList convertToAL(String strInputParam, String strSeparator) throws Exception
	{
		ArrayList arrLstTemp = null;
		StringTokenizer strTknInp = null;
		try
		{
			strInputParam = eCRDUtil.verifyNull(strInputParam);
			strSeparator = eCRDUtil.verifyNull(strSeparator);
			arrLstTemp = new ArrayList();

			if ("".equals(strInputParam) || "".equals(strSeparator))
			{
				return arrLstTemp;
			}
			else
			{
				strTknInp = new StringTokenizer(strInputParam, strSeparator);
				while (strTknInp.hasMoreTokens())
				{
					arrLstTemp.add((String) strTknInp.nextToken().trim());
				}
				return arrLstTemp;
			}
		}
		finally
		{
			arrLstTemp = null;
			strTknInp = null;
		}
	}

	/**
	 * <pre>
	 * This method puts the specified value with the specified key in eCRDSessionMap in the session
	 * @param  request	The request object, using which this method takes the session
	 * @param  strKey	The name with which the value needs to be put in session (inside eCRDSessionMap - hashmap)
	 * @param  value	The value to be put against the specified name in session (inside eCRDSessionMap - hashmap)
	 * </pre>
	 **/

	public static void loadInSession(javax.servlet.http.HttpServletRequest request, String strKey, Object value)
	{
		javax.servlet.http.HttpSession session = request.getSession();
		eCRDSessionMap objeCRDSessionMap = null;
		if (session.getAttribute("eCRDSessionMap") == null)
		{
			objeCRDSessionMap = new eCRDSessionMap();
			objeCRDSessionMap.setData(strKey, value);
			session.setAttribute("eCRDSessionMap", objeCRDSessionMap);
		}
		else
		{
			objeCRDSessionMap = (eCRDSessionMap) session.getAttribute("eCRDSessionMap");
			objeCRDSessionMap.setData(strKey, value);
		}
	}

	/**
	 * <pre>
	 * This method retrieves the value stored in session against the specified strKey
	 * @param  	request	The request object, using which this method takes the session
	 * @param  	strKey	The name with which the value was stored in session (inside eCRDSessionMap - hashmap)
	 * @return	Object	The value found against the key and null otherwise
	 * </pre>
	 **/

	public static Object getFromSession(javax.servlet.http.HttpServletRequest request, String strKey)
	{
		javax.servlet.http.HttpSession session = request.getSession();
		eCRDSessionMap objeCRDSessionMap = null;
		if (session.getAttribute("eCRDSessionMap") == null)
		{
			objeCRDSessionMap = new eCRDSessionMap();
			session.setAttribute("eCRDSessionMap", objeCRDSessionMap);
			return null;
		}
		else
		{
			objeCRDSessionMap = (eCRDSessionMap) session.getAttribute("eCRDSessionMap");
			return (Object) objeCRDSessionMap.getData(strKey);
		}
	}

	/**
	 * <pre>
	 * This method removes the value stored in session against the specified strKey
	 * @param  	request	The request object, using which this method takes the session
	 * @param  	strKey	The name with which the value was stored in session (inside eCRDSessionMap - hashmap)
	 * </pre>
	 **/

	public static void removeFromSession(javax.servlet.http.HttpServletRequest request, String strKey)
	{
		javax.servlet.http.HttpSession session = request.getSession();
		eCRDSessionMap objeCRDSessionMap = null;
		if (session.getAttribute("eCRDSessionMap") == null)
		{
			objeCRDSessionMap = new eCRDSessionMap();
			session.setAttribute("eCRDSessionMap", objeCRDSessionMap);
		}
		else
		{
			objeCRDSessionMap = (eCRDSessionMap) session.getAttribute("eCRDSessionMap");
			objeCRDSessionMap.removeData(strKey);
		}
	}

	/**
	 * <pre>
	 * This method clears all the values stored in session
	 * @param  	request	The request object, using which this method takes the session
	 * </pre>
	 **/

	public static void clearSession(javax.servlet.http.HttpServletRequest request)
	{
		javax.servlet.http.HttpSession session = request.getSession();
		session.removeAttribute("eCRDSessionMap");
	}

	/*Metods for session vars which are used for the whole Application -- start */
	/**
	 * <pre>
	 * This method puts the specified value with the specified key in eCRDSessionMap in the session
	 * This hashmap holds the values which are used across the application.
	 * @param  request	The request object, using which this method takes the session
	 * @param  strKey	The name with which the value needs to be put in session (inside eCRDSessionMap - hashmap)
	 * @param  value	The value to be put against the specified name in session (inside eCRDSessionMap - hashmap)
	 * </pre>
	 **/

	public static void loadInSessionApp(javax.servlet.http.HttpServletRequest request, String strKey, Object value)
	{
		javax.servlet.http.HttpSession session = request.getSession();
		eCRDSessionMap objeCRDSessionMap = null;
		if (session.getAttribute("eCRDSessionMapApp") == null)
		{
			objeCRDSessionMap = new eCRDSessionMap();
			objeCRDSessionMap.setData(strKey, value);
			session.setAttribute("eCRDSessionMapApp", objeCRDSessionMap);
		}
		else
		{
			objeCRDSessionMap = (eCRDSessionMap) session.getAttribute("eCRDSessionMapApp");
			objeCRDSessionMap.setData(strKey, value);
		}
	}

	/**
	 * <pre>
	 * This method retrieves the value stored in session (to be used across the application) against the specified strKey
	 * @param  	request	The request object, using which this method takes the session
	 * @param  	strKey	The name with which the value was stored in session (inside eCRDSessionMap - hashmap)
	 * @return	Object	The value found against the key and null otherwise
	 * </pre>
	 **/

	public static Object getFromSessionApp(javax.servlet.http.HttpServletRequest request, String strKey)
	{
		javax.servlet.http.HttpSession session = request.getSession();
		eCRDSessionMap objeCRDSessionMap = null;
		if (session.getAttribute("eCRDSessionMapApp") == null)
		{
			objeCRDSessionMap = new eCRDSessionMap();
			session.setAttribute("eCRDSessionMapApp", objeCRDSessionMap);
			return null;
		}
		else
		{
			objeCRDSessionMap = (eCRDSessionMap) session.getAttribute("eCRDSessionMapApp");
			return (Object) objeCRDSessionMap.getData(strKey);
		}
	}

	/**
	 * <pre>
	 * This method removes the value stored in session against the specified strKey
	 * @param  	request	The request object, using which this method takes the session
	 * @param  	strKey	The name with which the value was stored in session (inside eCRDSessionMap - hashmap)
	 * </pre>
	 **/

	public static void removeFromSessionApp(javax.servlet.http.HttpServletRequest request, String strKey)
	{
		javax.servlet.http.HttpSession session = request.getSession();
		eCRDSessionMap objeCRDSessionMap = null;
		if (session.getAttribute("eCRDSessionMapApp") == null)
		{
			objeCRDSessionMap = new eCRDSessionMap();
			session.setAttribute("eCRDSessionMapApp", objeCRDSessionMap);
		}
		else
		{
			objeCRDSessionMap = (eCRDSessionMap) session.getAttribute("eCRDSessionMapApp");
			objeCRDSessionMap.removeData(strKey);
		}
	}

	/*Metods for session vars which are used for the whole Application -- end */

	/**
	 * <pre>
	 * Method to check whether the Date is in correct format and
	 * return the date in required format
	 * @param dateIn  <code>Date</code>
	 * @param strDateFormat   <code>String</code>
	 * @returns strOutDate <code>String</code>
	 * @throws Exception
	 * </pre>
	 */
	public static String isValidDate(Date dateIn, String strDateFormat) throws Exception
	{
		//date format used to parse the input date
		SimpleDateFormat sdtFormat = null;
		//date object to be used
		Date date = null;
		//return string date
		String strOutDate = "";
		try
		{
			sdtFormat = new SimpleDateFormat("EEE MMM dd hh:mm:ss z yyyy");
			date = sdtFormat.parse(dateIn + "");
			//"Tue Jul 01 00:00:00 GMT+05:30 2003");
			sdtFormat = new SimpleDateFormat(strDateFormat);
			strOutDate = sdtFormat.format(date);
		}
		catch (ParseException objParseException)
		{
			/*
			 * When date is in Incorrect format
			 */
			strOutDate = "";
		}
		catch (IllegalArgumentException objIllArgException)
		{
			/*
			 * When  strDateFormat is incorrect
			 */
			strOutDate = "";
		}
		finally
		{
			sdtFormat = null;
			date = null;
		}
		return strOutDate;

	}
	/**
		 * <pre>
		 * Method to check whether the Date is in correct format and
		 * return the date in required format
		 * @param dateIn  <code>Date</code>
		 * @param strDateFormat   <code>String</code>
		 * @returns strOutDate <code>String</code>
		 * @throws Exception
		 * </pre>
		 */
	public static String isValidDate(String strDateIn, String strDateFormat) throws Exception
	{
		//date format used to parse the input date
		SimpleDateFormat sdtFormat = null;

		//date object to be used
		Date date = null;

		//return string date
		String strOutDate = "";
		try
		{
			sdtFormat = new SimpleDateFormat(strDateFormat);
			date = sdtFormat.parse(strDateIn);
			sdtFormat = new SimpleDateFormat(strDateFormat);
			strOutDate = sdtFormat.format(date);
		}
		catch (ParseException objParseException)
		{
			/*
			 * When date is in Incorrect format
			 */
			strOutDate = "";
		}
		catch (IllegalArgumentException objIllArgException)
		{
			/*
			 * When  strDateFormat is incorrect
			 */
			strOutDate = "";
		}
		finally
		{
			sdtFormat = null;
			date = null;
		}
		return strOutDate;
	}

	public static String validateUser(HashMap hmContValues, String strCont, String strRole) throws Exception
	{
		String strValid = "false";
		ArrayList arrlstRole = null;

		try
		{
			if (hmContValues != null) // && !"".equals(strCont))
			{

				if (hmContValues.containsKey(strCont))
				{

					arrlstRole = (ArrayList) hmContValues.get(strCont);

					if (arrlstRole.contains((String) strRole))
					{
						strValid = "true";
					}
					else
					{
						strValid = "false";
					}
				}
			}
			return strValid;
		}
		finally
		{
			strValid = null;
			arrlstRole = null;
		}
	}
	/** Method to log errors using GEAELogger.
	 * @param strUser <code>String</code> ID of the logged in User.
	 * @param strException <code>String</code> Exception Message to be logged.
	 */
	public static final void logError(String strUser, Exception objException)
	{
		String strRegion = "";
		ByteArrayOutputStream objBytArr = null;
		PrintStream objPS = null;
		String strException = "";
		String strStackTrace = "";
		eCRDException objeCRDException = null;

		try
		{
			objBytArr = new ByteArrayOutputStream();
			objPS = new PrintStream(objBytArr);
			objException.printStackTrace(objPS);
			strStackTrace = objBytArr.toString();
			strException = objException.toString() + "\r\n";
			if (objException instanceof eCRDException)
			{
				objeCRDException = (eCRDException) objException;
				strException = strException + "Eception Code :- " + objeCRDException.getErrorIdentifer() + "\r\n";
				strException = strException + "Eception Message :- " + objeCRDException.getErrorDesc() + "\r\n";
			}
			strException = strException + strStackTrace;
			strRegion = verifyNull(GEAEConfigProvider.getInstance().getRegion());

			if ("".equals(strRegion) || "l".equals(strRegion))
			{
				//Showing exception on console for local region
				setLogMessage(eCRDConstants.LOGFILE_PATH, strUser, strException);
			}
			else
			{
				//					Logging to the GEAELogger if Region is DEV, QA or PROD.
				GEAELogger.getInstance().logError(eCRDConstants.LOGGER_APP_ID, eCRDConstants.LOGGER_PORTAL_ID, strUser, strException);
			} //end of if-else
		}
		catch (Exception e)
		{
			//Suppressing logging exceptions
			e.printStackTrace();
		}
		finally
		{
			strRegion = null;
			objBytArr = null;
			objPS = null;
			strException = null;
		}
	}

	/**
	 * Method to log the Exception messages.
	 * @param strLogFilePath <code>String</code> Path of Log file
	 * @param strUser <code>String</code> User ID
	 * @param strMsg <code>String</code> Exception message
	 */
	public static void setLogMessage(String strLogFilePath, String strUser, String strMsg) throws Exception
	{
		RandomAccessFile raf = null;
		GregorianCalendar calendar = null;
		StringBuffer strBuff = null;
		try
		{
			raf = new RandomAccessFile(eCRDUtil.getAFSPath() + strLogFilePath, "rw");

			calendar = new GregorianCalendar();

			strBuff = new StringBuffer(2024);
			strBuff.append("Date: ").append(calendar.get(Calendar.DATE));
			strBuff.append(":").append(calendar.get(Calendar.MONTH));
			strBuff.append(":").append(calendar.get(Calendar.YEAR));
			strBuff.append("  --  Time:").append(calendar.get(Calendar.HOUR_OF_DAY));
			strBuff.append(":").append(calendar.get(Calendar.MINUTE));
			strBuff.append(" \r\n");
			strBuff.append("User ID: ").append(strUser);
			strBuff.append(" \r\n");
			strBuff.append("Exception: ").append(strMsg).append("\r\n");
			strBuff.append("===================================================================\r\n \r\n \r\n");

			raf.seek(raf.length());
			raf.writeBytes(strBuff.toString());
		}
		catch (Exception e)
		{
			//Don't throw loggin exceptions
		}
		finally
		{
			if (null != raf)
			{
				raf.close();
			}
			raf = null;
			strBuff = null;
			calendar = null;
		}
	} //end of getErrorLogFlag if false
	/**
	 * Formats a string  and returns it with a break
	 *
	 * @author                   shenoyra
	 * @version
	 * @param  strNonFormString  Description of the Parameter
	 * @return                   Description of the Return Value
	 * @since
	 */
	public final static String formatStringForDisplay(String strToBeFormatted) throws Exception
	{
		StringTokenizer strtkn = null;
		String strFcastDescSub = "";
		String strReturn = "";

		int intCtr = 0;
		int intRetLength = 0;
		try
		{

			strToBeFormatted = verifyNull(strToBeFormatted);

			if (!"".equals(strToBeFormatted))
			{
				if (strToBeFormatted.length() > 30)
				{
					while (intCtr < strToBeFormatted.length())
					{
						if ((strToBeFormatted.length() - intCtr) < 30)
						{
							strFcastDescSub = strToBeFormatted.substring(intCtr);
						}
						else
						{
							strFcastDescSub = strToBeFormatted.substring(intCtr, intCtr + 30);
						}

						strReturn += strFcastDescSub + "<BR>";

						intCtr = intCtr + 30;
					}
				}
				else
				{
					return strReturn += strToBeFormatted;
				}
			}
		}
		catch (Exception objExp)
		{
			throw new Exception(objExp.getMessage());
		}
		return strReturn;
	}

	/**
	 * <pre>
	 * This method is used to populate  a select box from a HashMap.values().toString()
	 * @param  strDropDown <code> String </code> HashMap.values().toString()is
	 * passed as strDropdown.
	 * @param  strSelectedValue <code> String </code> The value which will be selected
	 * in the select box
	 * @param  <code> blnSplcase </code> If this value is set to false then
	 * showing an Option selected, it will do a equals check between GEAEResultSet string
	 * and strSelectedValue and if set to true it will do an
	 * rs.getString(1).indexOf(strSelectedValue) check.
	 * @return <code> String </code> HTML code of drop down
	 * </pre>
	 */

	public static String populateBusinessOptions(String strDropDown, String strSelectedValue, boolean blnSplcase) throws Exception
	{
		boolean blnFound = false;
		String strOption_code = "";
		String strOptionValue = "";
		String strOptionName = "";
		StringTokenizer strToken = null;
		StringBuffer sbOutBuffer = new StringBuffer();
		ArrayList arrlstDDOrig = convertStringToArrayList(strDropDown, ",");
		//This method will get the arrayList
		// sorted the way we have kept in the XML.
		ArrayList arrlstDD = getSortedArrayList(arrlstDDOrig);
		int intCount = 0;
		try
		{
			//IF null empty String will be returned
			if (null != arrlstDD)
				//intCount = arrlstDD.size();
				intCount = 0;

			if (intCount < arrlstDD.size())
				sbOutBuffer.append("<OPTION VALUE=\"\">Select...</OPTION>");

			for (int i = 0; i < arrlstDD.size(); i++)
			{
				strOption_code = ((String) arrlstDD.get(i)).trim();
				strToken = new StringTokenizer(strOption_code, "^");
				while (strToken.hasMoreTokens())
				{
					strOptionName = strToken.nextToken();
					strOptionValue = strToken.nextToken();
				}

				//sbOutBuffer.append("<OPTION VALUE=\"" + strOption_code + "\"");
				sbOutBuffer.append("<OPTION VALUE=\"" + strOptionValue + "\"");
				if (blnSplcase)
				{
					if (!(blnFound) && (!((strOption_code.indexOf(strSelectedValue)) == -1)) && (!"".equals(strSelectedValue)))
					{
						sbOutBuffer.append(" SELECTED ");
						blnFound = true;
					}
				}
				else
				{
					if (!(blnFound) && (strOption_code.trim().equals(strSelectedValue.trim())))
					{
						sbOutBuffer.append(" SELECTED ");
						blnFound = true;
					}
				}

				sbOutBuffer.append(">");
				//sbOutBuffer.append(((String)arrlstDD.get(i)).trim());
				sbOutBuffer.append(strOptionName);
				sbOutBuffer.append("</OPTION>\n");
			} //end of FOR
		}
		finally
		{
			strOption_code = "";
		}
		return sbOutBuffer.toString();
	}

	/**
	 *
	 * @author
	 *
	 * This method returns a string with date & time separated by an underscore
	 * e.g. if todays date is 30 June 2004 and time 6:30:23 PM then
	 * it will return 30_06_2004_18_30_23
	 * This can be used in Upload modules to get Date-Time stamped folder
	 */

	public static String getDateTimeFolder() throws Exception
	{
		Date dtToday = null;
		Date date = null;
		String strUploadDate = "";
		String strTime = "";
		String strOutHour = "";
		String strOutYear = "";
		String strOutMonth = "";
		String strOutDay = "";
		String strOutMinute = "";
		String strOutSecond = "";
		SimpleDateFormat sdtFormatDB = null;

		try
		{
			dtToday = new Date();
			strUploadDate = "" + dtToday;
			SimpleDateFormat sdtFormat = new SimpleDateFormat("EEE MMM dd hh:mm:ss z yyyy");

			date = sdtFormat.parse(strUploadDate);
			sdtFormatDB = new SimpleDateFormat("dd");
			strOutDay = sdtFormatDB.format(date);

			sdtFormatDB = new SimpleDateFormat("MM");
			strOutMonth = sdtFormatDB.format(date);

			sdtFormatDB = new SimpleDateFormat("yyyy");
			strOutYear = sdtFormatDB.format(date);

			sdtFormatDB = new SimpleDateFormat("hh");
			strOutHour = sdtFormatDB.format(date);

			sdtFormatDB = new SimpleDateFormat("mm");
			strOutMinute = sdtFormatDB.format(date);

			sdtFormatDB = new SimpleDateFormat("ss");
			strOutSecond = sdtFormatDB.format(date);

			strTime = strOutDay + "_" + strOutMonth + "_" + strOutYear + "_" + strOutHour + "_" + strOutMinute + "_" + strOutSecond;

			return strTime;
		}
		finally
		{
			dtToday = null;
			date = null;
			strUploadDate = null;
			strTime = null;
			strOutHour = null;
			strOutYear = null;
			strOutMonth = null;
			strOutDay = null;
			strOutMinute = null;
			strOutSecond = null;
			sdtFormatDB = null;
		}
	}

	/**
	* @param String
	* @return boolean
	* @author patni
	* This method deletes file from AFS path provided filename and parent directory
	* is provided e.g. direcory_name/file_name
	*
	*/

	public static boolean deleteFile(String strFullName) throws Exception
	{
		File dir = null;
		File file = null;
		String strFilepath = "";
		boolean blnDeleted = false;

		try
		{
			if (strFullName.lastIndexOf('/') != -1)
			{
				strFilepath = strFullName.substring(0, strFullName.lastIndexOf('/'));
			}
			dir = new File(eCRDUtil.getAFSPath() + eCRDConstants.EXCEL_UPLOAD_PATH + strFilepath);
			//Deltes file from Server HDD
			if (dir.exists() && dir.isDirectory())
			{
				String[] children = dir.list();
				int intFileCount = children.length;
				if (children != null)
				{
					for (int i = 0; i < children.length; i++)
					{
						file = new File(dir + "/" + children[i]);
						if (file.exists() && file.isFile())
						{
							blnDeleted = file.delete();
						}
					}
					blnDeleted = dir.delete();

				}
			}

		}
		finally
		{
			dir = null;
			file = null;
			strFilepath = null;
		}
		return blnDeleted;
	}

	/**
	 *
	 * @author patni
	 *
	 * To change the template for this generated type comment go to
	 * Window>Preferences>Java>Code Generation>Code and Comments
	 */

	public static String checkFileSize(String strFullName) throws Exception
	{
		File dir = null;
		File file = null;
		String strFilepath = "";
		boolean blnDeleted = false;
		long fileSize = 0L;
		String strErrorMsg = "";
		String[] children = null;
		try
		{
			strFilepath = strFullName.substring(0, strFullName.lastIndexOf('/'));
			dir = new File(eCRDUtil.getAFSPath() + eCRDConstants.EXCEL_UPLOAD_PATH + strFilepath);

			//Checks the size of file
			if (dir.exists() && dir.isDirectory())
			{
				children = dir.list();

				int intFileCount = children.length;
				if (children != null)
				{
					for (int i = 0; i < children.length; i++)
					{
						file = new File(dir + "/" + children[i]);
						if (file.exists() && file.isFile())
						{
							fileSize = file.length();
							if (fileSize == 0L)
							{
								strErrorMsg = "eCRD_ZERO_FILE";
								blnDeleted = file.delete();
							}
						}
					}
					blnDeleted = dir.delete();

				}
			}
			return strErrorMsg;
		}
		finally
		{
			dir = null;
			file = null;
			strFilepath = null;
		}
	}

	public static String getStyleTag() throws Exception
	{
		return "<STYLE type=text/css>"
			+ ".c3 {BACKGROUND-COLOR: #cccccc}"
			+ ".c4 {BACKGROUND-COLOR: #ffffff}"
			+ ".c5 {BACKGROUND-COLOR: #333333}"
			+ ".c6 {BACKGROUND-COLOR: #9999cc}"
			+ ".c7 {BACKGROUND-COLOR: #99cc99}"
			+ ".f1 {FONT-WEIGHT: bold; FONT-SIZE: 11px; FONT-FAMILY: Verdana,Arial,Helvetica; TEXT-DECORATION: none}"
			+ ".f2 {FONT-SIZE: 11px; FONT-FAMILY: Verdana,Arial,Helvetica}"
			+ ".f3 {FONT-WEIGHT: bold; FONT-SIZE: 12px; FONT-FAMILY: Verdana,Arial,Helvetica; TEXT-DECORATION: none}"
			+ ".f1r {FONT-WEIGHT: bold; FONT-SIZE: 11px; COLOR: #ff0000; FONT-FAMILY: Verdana,Arial,Helvetica; TEXT-DECORATION: none}"
			+ ".c3f3 {FONT-WEIGHT: bold; FONT-SIZE: 10px; FONT-FAMILY: Verdana,Arial,Helvetica; BACKGROUND-COLOR: #cccccc; TEXT-DECORATION: none}"
			+ ".c4f4 {FONT-SIZE: 12px; FONT-FAMILY:Verdana,Arial,Helvetica;  BACKGROUND-COLOR: #ffffff; TEXT-DECORATION: none}"
			+ ".h1 {FONT-SIZE: 18px; COLOR: #9999cc; FONT-FAMILY: Verdana,Arial,Helvetica; TEXT-DECORATION: none}"
			+ ".font9{font-family: Verdana, Arial, Helvetica;font-size: 13px;font-style: normal;color: #666666;background: #EAEAEA;font-weight: 800}"
			+ "</STYLE>";
	}

	/**
	 * @param int
	 * @return Color
	 * @author patni
	 * This method is color generator and returns a color object for the supplied integer
	 * is provided e.g. direcory_name/file_name
	 *
	 */
	public static String setSymbol(String strValue, String strSymbol)
	{
		if ("$".equals(strSymbol))
		{
			strValue = strSymbol + strValue;
		}
		else if ("%".equals(strSymbol))
		{
			strValue = strValue + strSymbol;
		}
		return strValue;
	}
	/**
	 * @param
	 * @return ArrayList
	 * @author patni
	 * This method is used to instantiate an arraylist of string arrays
	 * which stores the jsp's to be shown
	 * in the apply rules tabs
	 */
	public static ArrayList getCustCatalogRulesTabs() throws Exception
	{
		ArrayList arrlstTabList = null;
		try
		{
			arrlstTabList = new ArrayList();
			arrlstTabList.add(new String[] { "Rules Criteria", eCRDConstants.STRBASEJSPPATH + "eCRDRulesCriteria.jsp" });
			arrlstTabList.add(new String[] { "Apply Rules", eCRDConstants.STRBASEJSPPATH + "eCRDContractualRules.jsp" });
			arrlstTabList.add(new String[] { "View Rules", eCRDConstants.STRBASEJSPPATH + "eCRDViewRules.jsp" });
			arrlstTabList.add(
				new String[] {
					"Merge/Split Repairs",
					eCRDConstants.STRBASEJSPPATH + "eCRDMergeSplitRepair.jsp",
					eCRDConstants.STRBASEJSPPATH + "eCRDMergeRepairs.jsp",
					eCRDConstants.STRBASEJSPPATH + "eCRDSplitRepair.jsp",
					eCRDConstants.STRBASEJSPPATH + "eCRDSpitRepairsSave.jsp",
					eCRDConstants.STRBASEJSPPATH + "eCRDAddCompRepair.jsp" });
			return arrlstTabList;
		}
		finally
		{

		}
	}

	/**
		 * @param
		 * @return ArrayList
		 * @author patni
		 * This method is used to instantiate an arraylist of string arrays
		 * which stores the jsp's to be shown
		 * in the add component tabs
		 */
	public static ArrayList getAddComponentTabs() throws Exception
	{
		ArrayList arrlstTabList = null;
		try
		{
			arrlstTabList = new ArrayList();
			arrlstTabList.add(new String[] { "Component", eCRDConstants.STRBASEJSPPATH + "eCRDAddComponentDetails.jsp" });
			arrlstTabList.add(new String[] { "Repair", eCRDConstants.STRBASEJSPPATH + "eCRDAddCompRepair.jsp" });
			arrlstTabList.add(new String[] { "Repair List", eCRDConstants.STRBASEJSPPATH + "eCRDViewRepairs.jsp" });
			return arrlstTabList;
		}
		finally
		{

		}
	}

	/**			 * @param
			 * @return ArrayList
			 * @author patni
			 * This method is used to instantiate an arraylist of string arrays
			 * which stores the jsp's to be shown
			 * in the manage component Repair tabs
			 */
	public static ArrayList getMergeRepairTabs() throws Exception
	{
		ArrayList arrlstTabList = null;
		try
		{
			arrlstTabList = new ArrayList();
			arrlstTabList.add(new String[] { "Component Listing", eCRDConstants.STRBASEJSPPATH + "" });
			arrlstTabList.add(new String[] { "Repair Pricing", eCRDConstants.STRBASEJSPPATH + "" });
			arrlstTabList.add(new String[] { "Repair Listing", eCRDConstants.STRBASEJSPPATH + "" });
			arrlstTabList.add(new String[] { "Merge Repair", eCRDConstants.STRBASEJSPPATH + "eCRDMergeRepairs.jsp" });
			return arrlstTabList;
		}
		finally
		{

		}
	}

	/**			 * @param
			 * @return ArrayList
			 * @author patni
			 * This method is used to instantiate an arraylist of string arrays
			 * which stores the jsp's to be shown
			 * in the manage Emails Tabs.
			 */

	public static ArrayList getEmailGroupsTabs() throws Exception
	{
		ArrayList arrlstTabList = null;
		try
		{
			arrlstTabList = new ArrayList();
			arrlstTabList.add(new String[] { "Add Users", eCRDConstants.STRBASEJSPPATH + "eCRDAddUserInGroup.jsp" });
			arrlstTabList.add(new String[] { "Associate Events", eCRDConstants.STRBASEJSPPATH + "eCRDAssociateEvent.jsp" });

			return arrlstTabList;
		}
		finally
		{
			arrlstTabList = null;
		}
	}

	/**
		 * @param
		 * @return ArrayList
		 * @author patni
		 * This method is used to instantiate an arraylist of string arrays
		 * which stores the jsp's to be shown
		 * in the apply rules tabs
		 */
	public static ArrayList getCustCatalogTabs() throws Exception
	{
		ArrayList arrlstTabList = null;
		try
		{
			arrlstTabList = new ArrayList();
			arrlstTabList.add(new String[] { "Add Repair", eCRDConstants.STRBASEJSPPATH + "eCRDAddRepairComponent.jsp" });
			arrlstTabList.add(new String[] { "Repair", eCRDConstants.STRBASEJSPPATH + "eCRDAddCompRepair.jsp" });
			arrlstTabList.add(new String[] { "View Repairs", eCRDConstants.STRBASEJSPPATH + "eCRDViewRepairs.jsp" });
			return arrlstTabList;
		}
		finally
		{

		}
	}

	/**
	 * @param
	 * @return ArrayList
	 * @author patni
	 * This method is used to instantiate an arraylist of string arrays
	 * which stores the jsp's to be shown
	 * in the apply rules tabs
	 */
	public static ArrayList getCompRepairCatalogTabs() throws Exception
	{
		ArrayList arrlstTabList = null;
		try
		{
			arrlstTabList = new ArrayList();
			arrlstTabList.add(new String[] { "Component Listing", eCRDConstants.STRBASEJSPPATH + "eCRDComponentListing.jsp" });
			arrlstTabList.add(new String[] { "Repair Listing", eCRDConstants.STRBASEJSPPATH + "eCRDViewRepairs.jsp" });
			arrlstTabList.add(new String[] { "Repair Pricing", eCRDConstants.STRBASEJSPPATH + "eCRDAddCompRepair.jsp" });
			return arrlstTabList;
		}
		finally
		{

		}
	}

	//Ehren start
	/**
	 * @param
	 * @return ArrayList
	 * @author patni
	 * This method is used to instantiate an arraylist of string arrays
	 * which stores the jsp's to be shown
	 * in the Add repair to CSC tabs
	 */
	public static ArrayList getCompRepairDefaultCatalogTabs() throws Exception
	{
		ArrayList arrlstTabList = null;
		try
		{
			arrlstTabList = new ArrayList();
			arrlstTabList.add(new String[] { "Component Listing", eCRDConstants.STRBASEJSPPATH + "eCRDComponentListingDefault.jsp" });
			arrlstTabList.add(new String[] { "Repair Listing", eCRDConstants.STRBASEJSPPATH + "eCRDViewRepairsDefault.jsp" });
			return arrlstTabList;
		}
		finally
		{

		}
	}

	//Ehren end
	/**
	* <pre>
	* This Method formatDate() accepts the calender controls list box values and concatinates
	* and returns as a string of format dd/mm/yyyy
	* @param String strDD,String strMM,String strYYYY
	* @return String
	* </pre>
	**/
	public static final String formatDate(String strDD, String strMM, String strYYYY) throws Exception
	{
		String strDate = null;
		if (strMM.trim().equals("") || strDD.trim().equals("") || strYYYY.trim().equals(""))
		{
			return strDate = "";
		}
		else
		{
			strDate = strMM.trim() + "/" + strDD.trim() + "/" + strYYYY.trim();
			return strDate;
		}

	}

	/**
	* <pre>
	* This Method getDay() accepts a string value of date and returns the numeric values of Day of String date
	* and returns as a string
	* @param String strDate
	* @return String
	* </pre>
	**/
	public static final String getDay(String strDate) throws Exception
	{
		String strDD = null;

		if ("".equals(strDate))
		{
			strDD = "";
		}
		else
		{
			if (strDate.length() == 1)
			{
				strDate = "0".concat(strDate);
			}
			strDD = new java.text.SimpleDateFormat("dd").format(sdf.parse(strDate));

		}

		return strDD;
	}

	/**
	* <pre>
	* This Method getMonth() accepts a string value of date and returns the numeric values of Month of String date
	* and returns as a string
	* @param String strDate
	* @return String
	* </pre>
	**/
	public static final String getMonth(String strDate) throws Exception
	{
		String strMM = null;

		if ("".equals(strDate))
		{
			strMM = "";

		}
		else
		{
			if (strDate.length() == 1)
			{
				strDate = "0".concat(strDate);
			}
			strMM = new java.text.SimpleDateFormat("M").format(sdf.parse(strDate));
		}

		return strMM;
	}

	/**
	* <pre>
	* This Method getYear() accepts a string value of date and returns the numeric values of Year of String date
	* and returns as a string
	* @param String strDate
	* @return String
	* </pre>
	**/
	public static final String getYear(String strDate) throws Exception
	{
		String strYYYY = null;
		if (strDate.length() == 1)
		{
			strDate = "000".concat(strDate);
		}
		if (strDate.length() == 2)
		{
			strDate = "00".concat(strDate);
		}
		if (strDate.length() == 3)
		{
			strDate = "0".concat(strDate);
		}
		if ("".equals(strDate))
		{
			strYYYY = "";
		}
		else
		{
			strYYYY = new java.text.SimpleDateFormat("yyyy").format(sdf.parse(strDate));
		}

		return strYYYY;
	}

	public static ArrayList getApprovalTabs() throws Exception
	{
		ArrayList arrlstTabList = null;
		try
		{
			arrlstTabList = new ArrayList();
			arrlstTabList.add(new String[] { "Component", eCRDConstants.STRBASEJSPPATH + "eCRDApprExistComponent.jsp", eCRDConstants.STRBASEJSPPATH + "eCRDAddComponentDetails.jsp" });
			arrlstTabList.add(new String[] { "Repair", eCRDConstants.STRBASEJSPPATH + "eCRDApprvRepairDetails.jsp", eCRDConstants.STRBASEJSPPATH + "eCRDAddCompRepair.jsp" });
			arrlstTabList.add(new String[] { "View Repairs", eCRDConstants.STRBASEJSPPATH + "eCRDViewRepairs.jsp" });
			return arrlstTabList;
		}
		finally
		{

		}
	}
	public static String convertToDisplayDateFormat(String strDate) throws Exception
	{
		StringTokenizer stDate = new StringTokenizer(strDate, "/");
		String strMonth = "";
		String strDay = "";
		String strYear = "";
		if (stDate.countTokens() < 3)
		{
			return "";
		}
		else
		{
			strMonth = convertToString(Integer.parseInt(stDate.nextToken()));
			strDay = stDate.nextToken();
			strYear = stDate.nextToken();

			return strDay + "-" + strMonth + "-" + strYear;
		}

	}
	/**
			 * this method converts a int  into corresponding String denoting the corresponding month.
			 * @param String
			 * @return int
			 *
			 */

	public static String convertToString(int i)
	{
		String strMonth = "";
		switch (i)
		{
			case 1 :
				strMonth = "Jan";
				break;
			case 2 :
				strMonth = "Feb";
				break;
			case 3 :
				strMonth = "Mar";
				break;
			case 4 :
				strMonth = "Apr";
				break;
			case 5 :
				strMonth = "May";
				break;
			case 6 :
				strMonth = "Jun";
				break;
			case 7 :
				strMonth = "Jul";
				break;
			case 8 :
				strMonth = "Aug";
				break;
			case 9 :
				strMonth = "Sep";
				break;
			case 10 :
				strMonth = "Oct";
				break;
			case 11 :
				strMonth = "Nov";
				break;
			case 12 :
				strMonth = "Dec";
				break;
		}
		return strMonth;
	}
    /**
     * this method converts a Date String  into proper format.
     * @param String
     * @return String
     * Patni 25-May-06 for Contract Start and End Date added in UI. 
     */
	public static String convertCntrctDateString(String strDate)
	{   
	    StringTokenizer stDate = null;
	    String strRetDate = "";
	    String strDay = "";
	    String strMon = "";
	    String strYear = "";
	    stDate = new StringTokenizer(strDate, "-");
	    strYear = stDate.nextToken();
	    strMon = stDate.nextToken();
	    strDay = stDate.nextToken().substring(0,2);
	    strRetDate = strMon + "/" + strDay + "/" + strYear;
	    return strRetDate;

	}
    /*Patni 25-May-06 for Contract Start and End Date added in UI. End*/
    /**
			 * this method converts a Date String  into proper format.
			 * @param String
			 * @return String
			 *
			 */
	public static String convertDateString(String strDate)
	{
		StringTokenizer stDate = null;
		String strRetDate = "";
		String strDay = "";
		String strMon = "";
		String strYear = "";
		stDate = new StringTokenizer(strDate, "-");
		strDay = stDate.nextToken();
		strMon = convertToInt(stDate.nextToken());
		strYear = stDate.nextToken();
		strRetDate = strMon + "/" + strDay + "/" + strYear;
		return strRetDate;

	}
	/**
			 * this method converts a Month String  into corresponding int.
			 * @param String
			 * @return int
			 *
			 */
	public static String convertToInt(String strMonth)
	{
		String strMon = "";
		if ("Jan".equals(strMonth))
		{
			strMon = "01";
		}
		else if ("Feb".equals(strMonth))
		{
			strMon = "02";
		}
		else if ("Mar".equals(strMonth))
		{
			strMon = "03";
		}
		else if ("Apr".equals(strMonth))
		{
			strMon = "04";
		}
		else if ("May".equals(strMonth))
		{
			strMon = "05";
		}
		else if ("Jun".equals(strMonth))
		{
			strMon = "06";
		}
		else if ("Jul".equals(strMonth))
		{
			strMon = "07";
		}
		else if ("Aug".equals(strMonth))
		{
			strMon = "08";
		}
		else if ("Sep".equals(strMonth))
		{
			strMon = "09";
		}
		else if ("Oct".equals(strMonth))
		{
			strMon = "10";
		}
		else if ("Nov".equals(strMonth))
		{
			strMon = "11";
		}
		else if ("Dec".equals(strMonth))
		{
			strMon = "12";
		}
		return strMon;
	}
	/**
		 * this method converts a hasmap into drop down.
		 * @param hmOptions
		 * @return
		 * @throws Exception
		 */
	public static String populateOptions(HashMap hmOptions, String strSelectedValue, boolean blnSplcase) throws Exception
	{
		boolean blnFound = false;
		Set keySet;
		StringBuffer strBuff = null;
		Iterator tmpIterator = null;
		String strKey = null;
		String strDelimiter = ",";
		StringBuffer sbOutBuffer = null;
		String strValue = null;
		String strTxt = "";
		String strOption_code = "";

		try
		{
			sbOutBuffer = new StringBuffer();
			strBuff = new StringBuffer();

			if (hmOptions.size() > 0)
				sbOutBuffer.append("<OPTION VALUE=\"\">Select...</OPTION>");

			keySet = hmOptions.keySet();
			tmpIterator = keySet.iterator();
			while (tmpIterator.hasNext())
			{
				strValue = (String) tmpIterator.next();
				strTxt = (String) hmOptions.get(strValue);

				strOption_code = strValue;
				sbOutBuffer.append("<OPTION VALUE=\"" + strOption_code + "\"");

				if (blnSplcase)
				{
					if (!(blnFound) && (!((strOption_code.indexOf(strSelectedValue)) == -1)) && (!"".equals(strSelectedValue)))
					{
						sbOutBuffer.append(" SELECTED ");
						blnFound = true;
					}
				}
				else
				{
					if (!(blnFound) && (strOption_code.trim().equals(strSelectedValue.trim())))
					{
						sbOutBuffer.append(" SELECTED ");
						blnFound = true;
					}
				}

				sbOutBuffer.append(">");
				sbOutBuffer.append(strTxt);
				sbOutBuffer.append("</OPTION>\n");
			}

			return (sbOutBuffer.toString());
		}
		finally
		{
			sbOutBuffer = null;
		}
	}
	public static ArrayList getEmaiID(eCRDComponent objComponent) throws Exception
	{

		String strActionId = null;
		ArrayList arlstMail = null;
		ArrayList arlstInParam = null;
		ArrayList arlstOutParam = null;
		GEAEResultSet rsMailId = null;
		try
		{
			arlstInParam = new ArrayList();
			arlstMail = new ArrayList();
			strActionId = eCRDConstants.getActionId("eCRD_GET_APPRV_EMAIL_ADDR");

			arlstInParam.add(objComponent.getComponentCode());
			arlstInParam.add(objComponent.getModule().getModuleCode());

			arlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arlstInParam);

			rsMailId = (GEAEResultSet) arlstOutParam.get(0);

			while (rsMailId.next())
			{
				arlstMail.add(rsMailId.getString(1));
			}
			/*for(intRSMailIdSize=0;intRSMailIdSize<rsMailId.size();intRSMailIdSize++)
			{
				arlstMail.add(rsMailId.getString(0));
				rsMailId.next();
			}*/

			return arlstMail;
		}
		finally
		{
			arlstInParam = null;
		}

	}

	public static boolean retBoolean(String strBoolean)
	{
		if (strBoolean.toUpperCase().equals("Y") || strBoolean.toUpperCase().equals("TRUE"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	public static String retString(boolean blnString)
	{
		if (blnString)
		{
			return "Y";
		}
		else
		{
			return "N";
		}
	}

	/**
		* <pre>
		* This Method is used to compare two dates.
		* The date formats expected are mm/dd/yy or mm/dd/yyyy.
		* The first argument is compared with the second and the difference of the two
		* is returned.
		* If the second argument is null then the first is compared with the current date.
		* @param  strDbDate   The First date (passed as String) Parameter to be compared
		* @param  strUserDt   The Second date (passed as String) Parameter to be compared
		* @return -  Returns positive if the first is greater than the second.
		* Returns negative if the first is lesser than the second.
		* Returns 0 for the equality.
		* @exception Exception
		* </pre>
		*/

	public static int compareDates(String strDbDate, String strUserDt) throws Exception
	{
		int intMM = 0;
		int intDD = 0;
		int intYY = 0;
		String strMM = null;
		String strDD = null;
		String strYY = null;
		StringTokenizer stDate = null;
		GregorianCalendar gcDbdate = null;
		GregorianCalendar gcCurrDt = null;

		try
		{

			if ((strDbDate != null) && (strDbDate.trim().length() >= 8))
			{
				stDate = new StringTokenizer(strDbDate, "/");

				//strMM = strDbDate.substring(0,2);
				strMM = stDate.nextToken();
				intMM = Integer.parseInt(strMM);

				strDD = stDate.nextToken();
				//strDD = strDbDate.substring(3,5);
				intDD = Integer.parseInt(strDD);

				strYY = stDate.nextToken();
				//strYY = strDbDate.substring(6);
				intYY = Integer.parseInt(strYY);

				//Y2K check imposed as Workfleet APIs return date as mm/dd/yy
				if (intYY < 50)
				{
					if (intYY < 10)
					{
						strYY = "200" + intYY;
					}
					else
					{
						strYY = "20" + intYY;
					}
				}
				else
				{
					if (intYY < 100)
					{
						strYY = "19" + intYY;
					}
				}
				intYY = Integer.parseInt(strYY);
			}

			gcDbdate = new GregorianCalendar(intYY, intMM - 1, intDD);

			intMM = 0;
			intDD = 0;
			intYY = 0;
			strMM = null;
			strDD = null;
			strYY = null;

			if ((strUserDt != null) && (strUserDt.trim().length() >= 8))
			{
				//if ((strUserDt!=null) && (strUserDt.length()>=8))
				//{
				strMM = strUserDt.substring(0, 2);
				intMM = Integer.parseInt(strMM);

				strDD = strUserDt.substring(3, 5);
				intDD = Integer.parseInt(strDD);

				strYY = strUserDt.substring(6);
				intYY = Integer.parseInt(strYY);

				//Y2K check imposed as Workfleet APIs return date as mm/dd/yy
				if (intYY < 50)
				{
					if (intYY < 10)
					{
						strYY = "200" + intYY;
					}
					else
					{
						strYY = "20" + intYY;
					}
				}
				else
				{
					if (intYY < 100)
					{
						strYY = "19" + intYY;
					}
				}
				intYY = Integer.parseInt(strYY);

				gcCurrDt = new GregorianCalendar(intYY, intMM - 1, intDD);
				//}
			}
			else
			{
				//get the current date
				gcCurrDt = new GregorianCalendar();
			}
			return getDaysDifference(gcCurrDt, gcDbdate);
		}
		finally
		{

		}
	}

	/**
		* <pre>
		* This method is used to give the Days Difference Between Two Dates
		* The first argument is compared with the second and Difference of the two in
		* terms of days is returned. The dates are expected in GregorianCalender formats.
		* @param  g1   First Date as GregorianCalendar object
		* @param  g2   Second Date as GregorianCalendar object
		* @return - The difference in the two dates.
		* @exception Exception
		* </pre>
		*/

	public static int getDaysDifference(GregorianCalendar g1, GregorianCalendar g2) throws Exception
	{
		int elapsed = 0;
		GregorianCalendar gc1, gc2;
		boolean blnNegative = false;
		try
		{
			if (g2.after(g1))
			{
				gc2 = (GregorianCalendar) g2.clone();
				gc1 = (GregorianCalendar) g1.clone();
			}
			else
			{
				gc2 = (GregorianCalendar) g1.clone();
				gc1 = (GregorianCalendar) g2.clone();
				blnNegative = true;
			}

			gc1.clear(Calendar.MILLISECOND);
			gc1.clear(Calendar.SECOND);
			gc1.clear(Calendar.MINUTE);
			gc1.clear(Calendar.HOUR_OF_DAY);
			gc1.clear(Calendar.HOUR);

			gc2.clear(Calendar.MILLISECOND);
			gc2.clear(Calendar.SECOND);
			gc2.clear(Calendar.MINUTE);
			gc2.clear(Calendar.HOUR_OF_DAY);
			gc2.clear(Calendar.HOUR);

			while (gc1.before(gc2))
			{
				gc1.add(Calendar.DATE, 1);
				elapsed++;
			}
			if (blnNegative)
			{
				elapsed = 0 - elapsed;
			}
			return elapsed;
		}
		finally
		{

		}
	}

	/**
		* @param ArrayList
		* @return Double
		* @author patni
		* This method will get the arrayList sorted the way we have kept in the XML.
		*/
	public static ArrayList getSortedArrayList(ArrayList arrSource)
	{
		ArrayList arrReturn = new ArrayList();

		try
		{
			for (int intLoopReturn = 0; intLoopReturn < arrSource.size(); intLoopReturn++)
			{

				for (int intLoopSource = 0; intLoopSource < arrSource.size(); intLoopSource++)
				{
					String strTemp = ((String) arrSource.get(intLoopSource)).trim();

					int intOrder = Integer.parseInt(strTemp.substring(0, 2));

					if (intOrder == intLoopReturn + 1)
					{
						arrReturn.add(strTemp.substring(2, strTemp.length()));
						break;
					}
					strTemp = null;
					intOrder = 0;
				}
			}
		}
		catch (Exception e)
		{
			return arrReturn;
		}

		return arrReturn;
	}
	public static String[] convertArrayListtoArray(ArrayList arrLstValues) throws Exception
	{

		int i = 0;
		int intArrLstCount = 0;

		String arrToReturn[] = null;

		try
		{

			if (arrLstValues != null && arrLstValues.size() <= 0)
			{
				return null;
			}
			else
			{
				intArrLstCount = arrLstValues.size();
				arrToReturn = new String[intArrLstCount];

				for (i = 0; i < intArrLstCount; i++)
				{
					arrToReturn[i] = (String) arrLstValues.get(i);
				}
			}
		}
		finally
		{

		}
		return (arrToReturn);
	}

	public static String populateOptionsWithoutSelect(GEAEResultSet rsetGeaers, String strSelectedValue, boolean blnSplcase) throws Exception
	{
		boolean blnFound = false;
		String strOption_code = "";
		StringBuffer sbOutBuffer = null;
		try
		{
			sbOutBuffer = new StringBuffer();
			//IF null empty String will be returned
			if (null != rsetGeaers)
			{
				rsetGeaers.setCurrentRow(0);
				while (rsetGeaers.next())
				{
					strOption_code = rsetGeaers.getString(1).trim();
					sbOutBuffer.append("<OPTION VALUE=\"" + strOption_code + "\"");

					if (blnSplcase)
					{
						if (!(blnFound) && (!((strOption_code.indexOf(strSelectedValue)) == -1)) && (!"".equals(strSelectedValue)))
						{
							sbOutBuffer.append(" SELECTED ");
							blnFound = true;
						}
					}
					else
					{
						if (!(blnFound) && (strOption_code.trim().equals(strSelectedValue.trim())))
						{
							sbOutBuffer.append(" SELECTED ");
							blnFound = true;
						}
					}

					sbOutBuffer.append(">");
					sbOutBuffer.append(rsetGeaers.getString(2).trim());
					sbOutBuffer.append("</OPTION>\n");
				} //end of while
			} //end of if
		}
		finally
		{
			strOption_code = "";
		}
		return sbOutBuffer.toString();
	}
	/*
	 * method returns the object itlself if not null else returns "" for SQL
	 */
	public static Object verifyNullReturnObject(Object obj)
	{
		if(obj==null)
		{
			return "";
		}
		else
		{
			return obj;
		}
	}
	//public class Constants {
	//	STRING_NULL="";
	//}
//	public static final String Constants = ".";

	//TCS-2011
	public static ArrayList getPricingSetDefault() throws Exception
	{
		ArrayList arrlstTabList = null;
		try
		{
			arrlstTabList = new ArrayList();
			arrlstTabList.add(new String[] { "Default All Engine", eCRDConstants.STRBASEJSPPATH + "/pricing/DefaultAllEngine.jsp" });
			arrlstTabList.add(new String[] { "Default Engine Line", eCRDConstants.STRBASEJSPPATH + "/pricing/DefaultLine.jsp" });
			arrlstTabList.add(new String[] { "Default Escalation Cap", eCRDConstants.STRBASEJSPPATH + "/pricing/DefaultEscCap.jsp" });
			//System.out.println("getPricingSetDefault------ In util tab settin "  + arrlstTabList.get(0));
		//	System.out.println("getPricingSetDefault------ In util tab settin 2 "  + arrlstTabList.get(1));
			return arrlstTabList ;
		}
		finally
		{

		}
	}
	
	//TCS-2011
	public static ArrayList getPricingAddModifyPrj() throws Exception
	{
		ArrayList arrlstTabList = null;
		try
		{
			arrlstTabList = new ArrayList();
			arrlstTabList.add(new String[] { "Edit Project", eCRDConstants.STRBASEJSPPATH + "pricing/ViewModifyProject.jsp" });
			arrlstTabList.add(new String[] { "Add/Edit Scenario", eCRDConstants.STRBASEJSPPATH + "pricing/AddEditScenario.jsp" });
			arrlstTabList.add(new String[] { "Component", eCRDConstants.STRBASEJSPPATH + "pricing/eCRDPricingComponentList.jsp" });
			arrlstTabList.add(new String[] { "Repairs", eCRDConstants.STRBASEJSPPATH + "pricing/eCRDPricingRepairList.jsp" });
			arrlstTabList.add(new String[] { "Repair Details", eCRDConstants.STRBASEJSPPATH + "pricing/eCRDPricingRepairDetails.jsp" });
			arrlstTabList.add(new String[] { "eCRD Data", eCRDConstants.STRBASEJSPPATH + "pricing/eCRDPricingCRMData.jsp" });
			arrlstTabList.add(new String[] { "Metreo Data", eCRDConstants.STRBASEJSPPATH + "pricing/eCRDPricingMetrioData.jsp" });
			arrlstTabList.add(new String[] { "Win Rate", eCRDConstants.STRBASEJSPPATH + "pricing/eCRDPricingWinRate.jsp" });
			

			  
			 
			return arrlstTabList ;
		}
		finally
		{

		}
	}
	
	
	/**
	  * @usage : If parameter is null then the method returns 0.0. Otherwise a
	  *        Double version of the String form of the object is returned.
	  *
	  * @returns : Double version of the parameter's String form
	  */
	 public static Double setDouble(final Object object) {
	  final String string = setString(object);
	  String strRepresentation = "";
	 
	  double representation = 0.00;
	 
	  try {
	   representation = (string.length() <= 0 ? 0.00 : Double
	     .parseDouble(string));
	   strRepresentation = formatNumber(representation, 8, true);
	   representation = Double.parseDouble(strRepresentation);
	  } catch (final NumberFormatException exception) {
	   representation = 0.00;
	  }
	 
	  return new Double(representation);
	 }
	 
	 public static double setDouble(final Object object, final int index) {
	  final String string = setString(object);
	  String strRepresentation = "";
	  double representation = 0.00;
	 
	  try {
	 
	   representation = (string.length() <= 0 ? 0.00 : Double
	     .parseDouble(string));
	   strRepresentation = formatNumber(representation, index, true);
	   representation = Double.parseDouble(strRepresentation);
	  } catch (final NumberFormatException exception) {
	   representation = 0.00;
	  }
	 
	  return representation;
	 }
	
	 /**
	  * @usage : If parameter is null then the method returns 0. Otherwise a
	  *        Integer version of the String form of the object is returned.
	  *
	  * @returns : Integer version of the parameter's String form
	  */
	 public static int setInt(final Object object) {
	  final String string = setString(object);
	  int representation = 0;
	 
	  try {
	   representation = (string.length() <= 0 ? 0 : Integer
	     .parseInt(string));
	  } catch (final Exception exception) {
	   representation = 0;
	  }
	 
	  return representation;
	 }

	 /**
	  * @usage : If parameter is null then the method returns 0. Otherwise a Long
	  *        version of the String form of the object is returned.
	  *
	  * @returns : Long version of the parameter's String form
	  */
	 public static long setLong(final Object object) {
	  final String string = setString(object);
	 
	  long representation = 0;
	 
	  try {
	   representation = (string.length() <= 0 ? 0 : Long.parseLong(string));
	  } catch (final Exception exception) {
	   representation = 0;
	  }
	 
	  return representation;
	 }
	/**
	  * @usage : If parameter is 0 then the method returns an Empty string.
	  *        Otherwise a String form of the number is returned.
	  *
	  * @returns : String version of the parameter
	  * Added
	  */
	 public static String setString(final double number) {
	  String representation = "";
	  representation = (number == 0.00) ? "" : "" + number;
	  // String representation=(Double.valueOf(number)).toString();
	  BigDecimal bigDcml;
	  if (contains(representation,".") && contains(representation,"E")) {
	   bigDcml = new BigDecimal(Double.parseDouble(representation));
	   representation = contains(bigDcml.toString(),".") ? bigDcml
	     .toString() : bigDcml.toString() + ".00";
	 
	  }
	  return representation;
	 }
	 
	 
	 public static String setString(final int number) {
		  String representation = "";
		  representation = (number == 0.00) ? "" : "" + number;
		  // String representation=(Double.valueOf(number)).toString();
		  BigDecimal bigDcml;
		  if (contains(representation,".") && contains(representation,"E")) {
		   bigDcml = new BigDecimal(Integer.parseInt(representation));
		   representation = bigDcml.toString();
		 
		  }
		  return representation;
		 }
	 
	 
	 /**
	  * @usage : If parameter is null then the method returns an Empty string.
	  *        Otherwise a trimmed version of the String form of the object is
	  *        returned.
	  *
	  * @returns : Trimmed version of the parameter's String form
	  */
	 public static String setString(final Object object) {
	  BigDecimal bigDcml = null;
	  String representation = (object == null ? "" : object.toString().trim());
	  representation = (representation.equalsIgnoreCase(DBNULL) ? ""
	    : representation);
	  representation = (representation
	    .equalsIgnoreCase(STRING_NULL) ? "" : representation);
	  representation = (representation.equalsIgnoreCase("-9999") ? null
	    : representation);
	 
	  if ((representation != null) && contains(representation,".") && contains(representation,"E")) {
	   bigDcml = new BigDecimal(Double.parseDouble(representation));
	   representation = contains(bigDcml.toString(),".") ? bigDcml
	     .toString() : bigDcml.toString() + ".00";
	 
	  }
	 
	  return representation;
	 }
	 

	 public static String formatNumber(final double number,
	    final long precision, final boolean checkZero) {
	   final String formatted = formatBigDecimal(number, (int) precision);
	   String processed = "";
	  
	   if (precision > 0) {
	    final int index = formatted.indexOf(POINT);
	    final String integral = setString(formatted.substring(0, index));
	    String decimal = setString(formatted.substring(index + 1));
	  
	    while ((decimal.length() > 0)
	      && decimal.substring(decimal.length() - 1)
	        .equalsIgnoreCase(INACTIVE)) {
	     decimal = setString(decimal.substring(0, decimal.length() - 1));
	    }
	  
	    if (decimal.length() > 0) {
	     processed = integral + POINT + decimal;
	    } else {
	     processed = integral;
	    }
	   } else {
	    processed = formatted;
	   }
	  
	   if (checkZero) {
	    final int newIndex = processed.indexOf(POINT);
	    processed = (newIndex < 0) && (Long.parseLong(processed) == 0) ? ""
	      : "" + processed;
	   }
	  
	   return processed;
	  }
	  
	  public static String formatDecimal(final double number, final long precision) {
	   final double factor = Math.pow(10, precision);
	   final BigDecimal formated_number = valueOf(Math.round(number
	     * factor)
	     / factor);
	   return addPrecision("" + formated_number, "" + precision);
	  }
	  
	  public static String formatBigDecimal(final double number,
	  /* final long precision */final int precision) {
	   /*
	    * final double factor = Math.pow(10, precision); final BigDecimal
	    * formated_number = BigDecimal.valueOf(Math.round(number factor) /
	    * factor); return addPrecision("" + formated_number.toPlainString(), "" +
	    * precision);
	    */
	  
	   final BigDecimal bd = new BigDecimal(String.valueOf(number));
	   String bdnew = bd.setScale(precision, BigDecimal.ROUND_HALF_UP)
	     .toString();
	   if (Double.parseDouble(bdnew) == 0.0) {
	    bdnew = "0.0";
	   } // Changed on 15th Mar 2010
	   return addPrecision("" + bdnew, "" + precision);
	  
	  }// Modified on 11 Mar 2010
	  
	  public static String addPrecision(final String number,
	    final String precision) {
	   String strNewNumber = number;
	   if (Integer.parseInt(precision) == 0) {
	    return strNewNumber;
	   }
	  
	   final int deci_point = strNewNumber.indexOf('.');
	  
	   if (deci_point == 0) {
	    strNewNumber = "0" + strNewNumber;
	   }
	   if (deci_point < 1) {
	    return addPrecision(strNewNumber + ".0", precision);
	   } else {
	    if (strNewNumber.length() - deci_point - 1 < Integer
	      .parseInt(precision)) {
	     return addPrecision(strNewNumber + "0", precision);
	    } else {
	     return (strNewNumber.substring(0, deci_point
	       + Integer.parseInt(precision) + 1));
	    }
	   }
	  }
	  public static boolean contains(String str1, String str2)   
	  {   
	    return str1.indexOf(str2) != -1;   
	  } 
	  public static BigDecimal valueOf(double val) {  
		   // Reminder: a zero double returns '0.0', so we cannot fastpath    
		 // to use the constant ZERO.  This might be important enough to    
		 // justify a factory approach, a cache, or a few private    
		 // constants, later.    
		 return new BigDecimal(Double.toString(val)); 
	  }

	  /**
	   * Common method to get saudi display flag.
	   * @param catalog
	   * @return
	   */
	  public static boolean isSaudiFieldApplicable(final String catalog) {  
		 return ("GE90".equalsIgnoreCase(catalog)); 
	  }

	  /**
	   * Catlog year
	   * @return
	   * @throws ParseException
	   */
	  public static String getCatalogCreationYear() throws ParseException {
		  Calendar cal = Calendar.getInstance();
//		  SimpleDateFormat sdf = new SimpleDateFormat("MMM/dd/yyyy");
//		  cal.setTime(sdf.parse("Jan/31/2012"));
		  if(cal.get(Calendar.MONTH) + 1==1) { // if Moth is January
				return setString((cal.get(Calendar.YEAR)));
		  }	else {
				return setString((cal.get(Calendar.YEAR) + 1));
		  }
	  }

	  /**
	   * Method to check special characters.
	   * @param argValue
	   * @return
	   */
	  public static boolean checkSplChars(String argValue) {
			char[] wildCharArray = new char[]{'`','~','!','@','#','$','%','^','&','"','\'',';','{','}','[',']','|','\\','/','<','>','?','+','='};
			for (int cnt = 0; cnt < wildCharArray.length; cnt++) {
				if (argValue.indexOf(wildCharArray[cnt]) >= 0) {
					return false;
				}
			}
		    return true;
		}

}