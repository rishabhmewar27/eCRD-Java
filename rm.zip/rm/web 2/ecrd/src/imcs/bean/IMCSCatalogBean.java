// Copyright (C) 2000 General Electric Company 
// All rights reserved

package imcs.bean;

/**
 * @author 226855
 *
 */
public class IMCSCatalogBean {
	
	protected String partNumber;
	protected String ataKeyword;
	protected String leadTime;
	protected String unitPrice;
	protected String uPQ;
	
	/**
	 * @return Returns the ataKeyword.
	 */
	public String getAtaKeyword() {
		return ataKeyword;
	}
	/**
	 * @return Returns the leadTime.
	 */
	public String getLeadTime() {
		return leadTime;
	}
	/**
	 * @return Returns the partNumber.
	 */
	public String getPartNumber() {
		return partNumber;
	}
	/**
	 * @return Returns the unitPrice.
	 */
	public String getUnitPrice() {
		return unitPrice;
	}
	/**
	 * @return Returns the uPQ.
	 */
	public String getUPQ() {
		return uPQ;
	}
	/**
	 * @param ataKeyword The ataKeyword to set.
	 */
	public void setAtaKeyword(String ataKeyword) {
		this.ataKeyword = ataKeyword;
	}
	/**
	 * @param leadTime The leadTime to set.
	 */
	public void setLeadTime(String leadTime) {
		this.leadTime = leadTime;
	}
	/**
	 * @param partNumber The partNumber to set.
	 */
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	/**
	 * @param unitPrice The unitPrice to set.
	 */
	public void setUnitPrice(String unitPrice) {
		this.unitPrice = unitPrice;
	}
	/**
	 * @param upq The uPQ to set.
	 */
	public void setUPQ(String upq) {
		uPQ = upq;
	}

}
