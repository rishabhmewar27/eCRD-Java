// Copyright (C) 2000 General Electric Company 
// All rights reserved 

package imcs.bean;

/**
 * @author 226855
 *
 */
public class IMCSComponentRepairBean extends IMCSCatalogBean{

	private String engineName;
	private String engineMdlNum;
	private String engineMainTitlePage;
	private String engineTitlePage;
	private String enginePreamble;
	private String catalogId;
	private String effctiveDate;
	private String moduleName;
	private String compCode;
	private String compParts;
	private String repairSites;
	private String ataRepairNumber;
	private String repairDescription;
	private String tatDays;
	private String price;
	private String partNumber;
	private String repairDisplayId;
	private String repairType;
	private String parentRepairId;
	private String repairComments;
	private String repairId;
	private String compLvlBaselineTAT;
	
	
	/**beginning of changes by rishabh mewar**/
	private String inspectionTAT;
	private String averageTAT;
	private String nteTAT;
/**end of changes by rishabh mewar**/
	
	
	
	/**
	 * 
	 */
	public IMCSComponentRepairBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
/**beginning of changes by rishabh mewar**/
	
	public String getInspectionTat() {
		return inspectionTAT;
	}
	
	public void setInspectionTat(String inspectionTAT) {
		this.inspectionTAT = inspectionTAT;
	}
	
	public String getAverageTat() {
		return averageTAT;
	}
	
	public void setAverageTat(String averageTAT) {
		this.averageTAT = averageTAT;
	}
	
	public String getNteTat() {
		return nteTAT;
	}
	
	public void setNteTat(String inspectionTAT) {
		this.nteTAT = nteTAT;
	}

/**end of chnages by rishabh mewar**/
	
	
	
	
	/**
	 * @return Returns the ataRepairNumber.
	 */
	public String getAtaRepairNumber() {
		return ataRepairNumber;
	}

	/**
	 * @return Returns the compCode.
	 */
	public String getCompCode() {
		return compCode;
	}

	/**
	 * @return Returns the compLvlBaselineTAT.
	 */
	public String getCompLvlBaselineTAT() {
		return compLvlBaselineTAT;
	}

	/**
	 * @return Returns the compParts.
	 */
	public String getCompParts() {
		return compParts;
	}

	/**
	 * @return Returns the moduleName.
	 */
	public String getModuleName() {
		return moduleName;
	}

	/**
	 * @return Returns the parentRepairId.
	 */
	public String getParentRepairId() {
		return parentRepairId;
	}

	/**
	 * @return Returns the partNumber.
	 */
	public String getPartNumber() {
		return partNumber;
	}

	/**
	 * @return Returns the price.
	 */
	public String getPrice() {
		return price;
	}

	/**
	 * @return Returns the repairComments.
	 */
	public String getRepairComments() {
		return repairComments;
	}

	/**
	 * @return Returns the repairDescription.
	 */
	public String getRepairDescription() {
		return repairDescription;
	}

	/**
	 * @return Returns the repairDisplayId.
	 */
	public String getRepairDisplayId() {
		
		return repairDisplayId;
	}

	/**
	 * @return Returns the repairId.
	 */
	public String getRepairId() {
		return repairId;
	}

	/**
	 * @return Returns the repairSites.
	 */
	public String getRepairSites() {
		return repairSites;
	}

	/**
	 * @return Returns the repairType.
	 */
	public String getRepairType() {
		return repairType;
	}

	/**
	 * @return Returns the tatDays.
	 */
	public String getTatDays() {
		return tatDays;
	}

	/**
	 * @param ataRepairNumber The ataRepairNumber to set.
	 */
	public void setAtaRepairNumber(String ataRepairNumber) {
		this.ataRepairNumber = ataRepairNumber;
	}

	/**
	 * @param compCode The compCode to set.
	 */
	public void setCompCode(String compCode) {
		this.compCode = compCode;
	}

	/**
	 * @param compLvlBaselineTAT The compLvlBaselineTAT to set.
	 */
	public void setCompLvlBaselineTAT(String compLvlBaselineTAT) {
		this.compLvlBaselineTAT = compLvlBaselineTAT;
	}

	/**
	 * @param compParts The compParts to set.
	 */
	public void setCompParts(String compParts) {
		this.compParts = compParts;
	}

	/**
	 * @param moduleName The moduleName to set.
	 */
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	/**
	 * @param parentRepairId The parentRepairId to set.
	 */
	public void setParentRepairId(String parentRepairId) {
		this.parentRepairId = parentRepairId;
	}

	/**
	 * @param partNumber The partNumber to set.
	 */
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	/**
	 * @param price The price to set.
	 */
	public void setPrice(String price) {
		this.price = price;
	}

	/**
	 * @param repairComments The repairComments to set.
	 */
	public void setRepairComments(String repairComments) {
		this.repairComments = repairComments;
	}

	/**
	 * @param repairDescription The repairDescription to set.
	 */
	public void setRepairDescription(String repairDescription) {
		this.repairDescription = repairDescription;
	}

	/**
	 * @param repairDisplayId The repairDisplayId to set.
	 */
	public void setRepairDisplayId(String repairDisplayId) {
		this.repairDisplayId = repairDisplayId;
	}

	/**
	 * @param repairId The repairId to set.
	 */
	public void setRepairId(String repairId) {
		this.repairId = repairId;
	}

	/**
	 * @param repairSites The repairSites to set.
	 */
	public void setRepairSites(String repairSites) {
		this.repairSites = repairSites;
	}

	/**
	 * @param repairType The repairType to set.
	 */
	public void setRepairType(String repairType) {
		this.repairType = repairType;
	}

	/**
	 * @param tatDays The tatDays to set.
	 */
	public void setTatDays(String tatDays) {
		this.tatDays = tatDays;
	}

	/**
	 * @return Returns the catalogId.
	 */
	public String getCatalogId() {
		return catalogId;
	}

	/**
	 * @return Returns the effctiveDate.
	 */
	public String getEffctiveDate() {
		return effctiveDate;
	}

	/**
	 * @param catalogId The catalogId to set.
	 */
	public void setCatalogId(String catalogId) {
		this.catalogId = catalogId;
	}

	/**
	 * @param effctiveDate The effctiveDate to set.
	 */
	public void setEffctiveDate(String effctiveDate) {
		this.effctiveDate = effctiveDate;
	}

	/**
	 * @return Returns the engineMainTitlePage.
	 */
	public String getEngineMainTitlePage() {
		return engineMainTitlePage;
	}

	/**
	 * @return Returns the engineName.
	 */
	public String getEngineName() {
		return engineName;
	}

	/**
	 * @return Returns the enginePreamble.
	 */
	public String getEnginePreamble() {
		return enginePreamble;
	}

	/**
	 * @return Returns the engineTitlePage.
	 */
	public String getEngineTitlePage() {
		return engineTitlePage;
	}

	/**
	 * @param engineMainTitlePage The engineMainTitlePage to set.
	 */
	public void setEngineMainTitlePage(String engineMainTitlePage) {
		this.engineMainTitlePage = engineMainTitlePage;
	}

	/**
	 * @param engineName The engineName to set.
	 */
	public void setEngineName(String engineName) {
		this.engineName = engineName;
	}

	/**
	 * @param enginePreamble The enginePreamble to set.
	 */
	public void setEnginePreamble(String enginePreamble) {
		this.enginePreamble = enginePreamble;
	}

	/**
	 * @param engineTitlePage The engineTitlePage to set.
	 */
	public void setEngineTitlePage(String engineTitlePage) {
		this.engineTitlePage = engineTitlePage;
	}

	/**
	 * @return Returns the engineMdlNum.
	 */
	public String getEngineMdlNum() {
		return engineMdlNum;
	}

	/**
	 * @param engineMdlNum The engineMdlNum to set.
	 */
	public void setEngineMdlNum(String engineMdlNum) {
		this.engineMdlNum = engineMdlNum;
	}
}
