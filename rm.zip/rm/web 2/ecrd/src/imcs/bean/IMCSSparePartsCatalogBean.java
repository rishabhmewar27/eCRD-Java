// Copyright (C) 2000 General Electric Company 
// All rights reserved

package imcs.bean;

/**
 * @author 226855
 *
 */
public class IMCSSparePartsCatalogBean extends IMCSCatalogBean{

	private String engineName;
	private String engineMainTitlePage;
	private String engineTitlePage;
	private String enginePreamble;
	private String headerLeft;
	private String headerCenterLeft;
	private String headerCenterRight;
	private String headerRight;
	private String headerCenter;
	private String headerMargin;
	private String headerDownLeft;
	private String footerMargin;
	private String footerCenter;
	private String footerLeft;
	/**
	 * @return Returns the engineMainTitlePage.
	 */
	public String getEngineMainTitlePage() {
		return engineMainTitlePage;
	}
	/**
	 * @return Returns the engineName.
	 */
	public String getEngineName() {
		
		return engineName;
	}
	/**
	 * @return Returns the enginePreamble.
	 */
	public String getEnginePreamble() {
		return enginePreamble;
	}
	/**
	 * @return Returns the engineTitlePage.
	 */
	public String getEngineTitlePage() {
		return engineTitlePage;
	}
	/**
	 * 
	 * @return Returns the headerLeft.
	 */	
	public String getHeaderLeft() {
		return headerLeft;
	}
	/**
	 * 
	 * @return Returns the headerRight.
	 */
	
	public String getHeaderRight() {
		return headerRight;
	}
	/**
	 * 
	 * @return Returns the headerCenterLeft.
	 */
	public String getHeaderCenterLeft() {
		
		return headerCenterLeft;
	}
	/**
	 * 
	 * @return Returns the headerCenterRight.
	 */
	
	public String getHeaderCenterRight() {
		return headerCenterRight;
	}
	/**
	 * 
	 * @return Returns the headerCenter.
	 */
	
	public String getHeaderCenter() {
		return headerCenter;
	}
	/**
	 * 
	 * @return Returns the footerLeft.
	 */
	
	public String getFooterLeft() {
		
		return footerLeft;
	}
	/**
	 * 
	 * @return Returns the footerCenter.
	 */
	
	public String getFooterCenter() {
		return footerCenter;
	}
	/**
	 * 
	 * @return Returns the headerDownLeft.
	 */
	public String getHeaderDownLeft() {
		return headerDownLeft;
	}
	
	/**
	 * 
	 * @return Returns the footerMargin.
	 */
	
	public String getFooterMargin() {
		return footerMargin;
	}
	/**
	 * 
	 * @param footerMargin The footerMargin to set.
	 */
	public void setFooterMargin(String footerMargin) {
		this.footerMargin = footerMargin;
	}
	/**
	 * 
	 * @return Retrns the headerMargin
	 */
	public String getHeaderMargin() {
		return headerMargin;
	}
	/**
	 * 
	 * @param headerMargin The header Margin is set
	 */
	public void setHeaderMargin(String headerMargin) {
		this.headerMargin = headerMargin;
	}
	
	/**
	 * @param engineMainTitlePage The engineMainTitlePage to set.
	 */
	public void setEngineMainTitlePage(String engineMainTitlePage) {
		this.engineMainTitlePage = engineMainTitlePage;
	}
	/**
	 * @param engineName The engineName to set.
	 */
	public void setEngineName(String engineName) {
		this.engineName = engineName;
	}
	/**
	 * @param enginePreamble The enginePreamble to set.
	 */
	public void setEnginePreamble(String enginePreamble) {
		this.enginePreamble = enginePreamble;
	}
	/**
	 * @param engineTitlePage The engineTitlePage to set.
	 */
	public void setEngineTitlePage(String engineTitlePage) {
		this.engineTitlePage = engineTitlePage;
	}
	/**
	 * 
	 * @param headerLeft The headerLeft is set
	 */
	public void setHeaderLeft(String headerLeft) {
		this.headerLeft = headerLeft;
	}
	/**
	 * 
	 * @param headerCenterLeft The headerCenterLeft to set
	 */
	public void setHeaderCenterLeft(String headerCenterLeft) {
		this.headerCenterLeft = headerCenterLeft;
	}
	/**
	 * 
	 * @param headerCenterRight The headerCenterRight to set
	 */
	
	public void setHeaderCenterRight(String headerCenterRight) {
		this.headerCenterRight = headerCenterRight;
	}
	/**
	 * 
	 * @param headerRight The headerRight to set
	 */
	public void setHeaderRight(String headerRight) {
		this.headerRight = headerRight;
	}
	/**
	 * 
	 * @param headerCenter The headerCenter to set
	 */
	public void setHeaderCenter(String headerCenter) {
		this.headerCenter = headerCenter;
	}
	/**
	 * 
	 * @param footerLeft The footerLeft to set
	 */
	public void setFooterLeft(String footerLeft) {
		this.footerLeft = footerLeft;
	}
	/**
	 * 
	 * @param footerCenter The footerCenter to set
	 */
		public void setFooterCenter(String footerCenter) {
		this.footerCenter = footerCenter;
	}
	/**
	 * 
	 * @param headerDownLeft The headerDownLeft to set
	 */
	public void setHeaderDownLeft(String headerDownLeft) {
		this.headerDownLeft = headerDownLeft;
	}
}