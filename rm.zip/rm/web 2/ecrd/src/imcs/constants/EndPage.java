// Copyright (C) 2000 General Electric Company
// All rights reserved

package imcs.constants;

import java.awt.Color;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Font;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfPageEventHelper;
import com.lowagie.text.pdf.PdfTable;
import com.lowagie.text.pdf.PdfWriter;

/**
 * Demonstrates the use of PageEvents.
 */
public class EndPage extends PdfPageEventHelper {


	Font geINSPIRA12B;
	Font geINSPIRA11B;
	Font geINSPIRA8;
	Font geINSPIRA9BG;
	Font geINSPIRA9B;
	Font geINSPIRA10B;
	Font geINSPIRA9G;

	BaseFont bfGEInspRg;

	String engineName;
	String headerMargin;
	String headerLeft;
	String headerCenterLeft;
	String headerCenterRight;
	String headerRight;
	String headerCenter;
	String headerDownLeft;
	String footerMargin;
	String footerLeft;
	String footerCenter;

	/**Instance of the logger class for logging debug and error messages. */
	private static final Logger LOGGER = Logger.getLogger("EndPage.class");

	{
		PropertyConfigurator.configure("properties/BatchLog4j.properties");
	}

	public EndPage() {
		super();

		// TODO Auto-generated constructor stub
	}
	/**
	 *
	 * @param props
	 */

	public EndPage(String[] props) {
		this();

		this.engineName = props[0];
		this.headerMargin = props[1];
		this.headerLeft = props[2];
		this.headerCenterLeft = props[3];
		this.headerCenterRight = props[4];
		this.headerRight = props[5];
		this.headerCenter = props[6];
		this.headerDownLeft = props[7];
		this.footerMargin = props[8];
		this.footerLeft = props[9];
		this.footerCenter = props[10];

		// TODO Auto-generated constructor stub
	}

    /**
     * This method is called at end of each PDF page created. It adds header & footer to that page.
     *
     */
    public void onEndPage(PdfWriter writer, Document document) {
        try {
           	setFonts();
            Rectangle page = document.getPageSize();
            document.setMargins(-20,-20,90,54);
            BaseFont bfGaramond = BaseFont.createFont("./styles/GARA.TTF", BaseFont.CP1252,BaseFont.EMBEDDED);
            Font[] fonts = new Font[5];
            fonts[1] = new Font(bfGaramond, 10);
            fonts[2] = new Font(bfGaramond, 8);

            String [] strHeaderMargins = this.headerMargin.split(",");
            float [] headerMargins = new float[strHeaderMargins.length];
            for (int i = 0; i < headerMargins.length; i++){
            	headerMargins[i] = Float.parseFloat(strHeaderMargins[i]);
            }
           	float [] tableCols1 = headerMargins;

            PdfPTable head = new PdfPTable(tableCols1);
         if(engineName.startsWith("CFM56")){
        //	LOGGER.debug("Setting header footer for CFM56");
            PdfPCell cellData = new PdfPCell(new  Phrase(this.headerLeft,fonts[1]));
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setColspan(1);
			cellData.setVerticalAlignment(PdfPCell.ALIGN_TOP);
			cellData.setHorizontalAlignment(PdfPCell.ALIGN_CENTER);
			head.addCell(cellData);
			cellData = null;

            cellData = new PdfPCell(new Phrase(this.headerCenterLeft,fonts[1]));
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setColspan(1);
			cellData.setVerticalAlignment(PdfPCell.ALIGN_TOP);
			cellData.setHorizontalAlignment(PdfPCell.ALIGN_CENTER);
			head.addCell(cellData);

            cellData = new PdfPCell(new Phrase(this.headerCenterRight,fonts[1]));
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setColspan(1);
			cellData.setVerticalAlignment(PdfPCell.ALIGN_TOP);
			cellData.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);
			head.addCell(cellData);

			cellData = new PdfPCell(new Phrase(this.headerRight,fonts[1]));
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setColspan(1);
			cellData.setVerticalAlignment(PdfPCell.ALIGN_TOP);
			cellData.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
			head.addCell(cellData);

            cellData = new PdfPCell(new Phrase(this.headerDownLeft,fonts[2]));
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setColspan(1);
			cellData.setPaddingTop(5f);
			cellData.setPaddingRight(154f);
			cellData.setVerticalAlignment(PdfPCell.ALIGN_TOP);
			cellData.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);
			head.addCell(cellData);

			cellData = new PdfPCell(new Phrase(this.headerCenter,fonts[2]));
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setColspan(1);
			cellData.setPaddingTop(5f);
			cellData.setPaddingRight(100f);
			cellData.setVerticalAlignment(PdfPCell.ALIGN_CENTER);
			cellData.setHorizontalAlignment(PdfPCell.ALIGN_CENTER);
			head.addCell(cellData);

			cellData = new PdfPCell(new Phrase(""));
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setColspan(1);
			cellData.setVerticalAlignment(PdfPCell.ALIGN_CENTER);
			cellData.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
			head.addCell(cellData);

			cellData = new PdfPCell(new Phrase(""));
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setColspan(6);
			cellData.setVerticalAlignment(PdfPCell.ALIGN_CENTER);
			cellData.setHorizontalAlignment(PdfPCell.ALIGN_CENTER);
			cellData.setFixedHeight(25f);
			head.addCell(cellData);

			cellData = new PdfPCell(new Phrase(""));
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setColspan(6);
			cellData.setVerticalAlignment(PdfPCell.ALIGN_CENTER);
			cellData.setHorizontalAlignment(PdfPCell.ALIGN_CENTER);
			cellData.setFixedHeight(25f);
			head.addCell(cellData);
	/** Used page.height() & page.width() for itext1.4.2.jar  */

            head.setTotalWidth(page.width() - document.leftMargin() - document.rightMargin());
            head.writeSelectedRows(0, -1, document.leftMargin(), page.height() - document.topMargin() + head.getTotalHeight(),writer.getDirectContent());

            String [] strFooterMargins = footerMargin.split(",");
            float [] footerMargins = new float[strFooterMargins.length];
            for (int i = 0; i < strFooterMargins.length; i++){

            	footerMargins[i] = Float.parseFloat(strFooterMargins[i]);
            }

            float [] footerCols = footerMargins;
            PdfPTable foot = new PdfPTable(footerCols);

            cellData = new PdfPCell(new Phrase(this.footerLeft,fonts[2]));
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setPaddingTop(5);
			cellData.setColspan(1);
			cellData.setVerticalAlignment(PdfPCell.ALIGN_CENTER);
			cellData.setHorizontalAlignment(PdfPCell.ALIGN_CENTER);
			foot.addCell(cellData);

			cellData = new PdfPCell(new Phrase(this.footerCenter,fonts[2]));
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setPaddingTop(15f);
			cellData.setColspan(1);
			cellData.setVerticalAlignment(PdfPCell.ALIGN_CENTER);
			cellData.setHorizontalAlignment(PdfPCell.ALIGN_CENTER);
			cellData.setFixedHeight(25f);
			foot.addCell(cellData);

			cellData = new PdfPCell(new Phrase("",fonts[2]));
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setColspan(6);
			cellData.setVerticalAlignment(PdfPCell.ALIGN_CENTER);
			cellData.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);
			cellData.setFixedHeight(25f);
			foot.addCell(cellData);

            foot.setTotalWidth(page.width() - document.leftMargin() - document.rightMargin());

            foot.writeSelectedRows(0, -1, document.leftMargin(), document.bottomMargin(),
                   writer.getDirectContent());
            }
            else{
   //         	LOGGER.debug("Setting header footer for Engine other than CFM56");
            	PdfPCell cellData = new PdfPCell(new  Phrase(this.headerLeft,geINSPIRA12B));
     			cellData.setBorder(Rectangle.NO_BORDER);
     			cellData.setColspan(1);
     			cellData.setVerticalAlignment(PdfPCell.ALIGN_TOP);
     			cellData.setHorizontalAlignment(PdfPCell.ALIGN_CENTER);
     			head.addCell(cellData);
     			cellData = null;

                cellData = new PdfPCell(new Phrase(this.headerCenterLeft,geINSPIRA9B));
     			cellData.setBorder(Rectangle.NO_BORDER);
     			cellData.setColspan(1);
     			cellData.setPaddingRight(38f);
     			cellData.setVerticalAlignment(PdfPCell.ALIGN_TOP);
     			cellData.setHorizontalAlignment(PdfPCell.ALIGN_CENTER);
     			head.addCell(cellData);

                cellData = new PdfPCell(new Phrase(this.headerCenterRight,geINSPIRA11B));
     			cellData.setBorder(Rectangle.NO_BORDER);
     			cellData.setColspan(1);
     			cellData.setVerticalAlignment(PdfPCell.ALIGN_TOP);
     			cellData.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);
     			head.addCell(cellData);

     			cellData = new PdfPCell(new Phrase(this.headerRight,geINSPIRA10B));
     			cellData.setBorder(Rectangle.NO_BORDER);
     			cellData.setColspan(1);
     			cellData.setVerticalAlignment(PdfPCell.ALIGN_TOP);
     			cellData.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
     			head.addCell(cellData);

                cellData = new PdfPCell(new Phrase(this.headerDownLeft,geINSPIRA8));
     			cellData.setBorder(Rectangle.NO_BORDER);
     			cellData.setColspan(1);
     			cellData.setPaddingTop(5f);
     			cellData.setPaddingRight(180f);
     			cellData.setVerticalAlignment(PdfPCell.ALIGN_TOP);
     			cellData.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);
     			head.addCell(cellData);

     			cellData = new PdfPCell(new Phrase(this.headerCenter,geINSPIRA8));
     			cellData.setBorder(Rectangle.NO_BORDER);
     			cellData.setColspan(1);
     			cellData.setPaddingTop(5f);
     			cellData.setPaddingRight(100f);
     			cellData.setVerticalAlignment(PdfPCell.ALIGN_CENTER);
     			cellData.setHorizontalAlignment(PdfPCell.ALIGN_CENTER);
     			head.addCell(cellData);

     			cellData = new PdfPCell(new Phrase(""));
     			cellData.setBorder(Rectangle.NO_BORDER);
     			cellData.setColspan(1);
     			cellData.setVerticalAlignment(PdfPCell.ALIGN_CENTER);
     			cellData.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
     			head.addCell(cellData);

     			cellData = new PdfPCell(new Phrase(""));
     			cellData.setBorder(Rectangle.NO_BORDER);
     			cellData.setColspan(6);
     			cellData.setVerticalAlignment(PdfPCell.ALIGN_CENTER);
     			cellData.setHorizontalAlignment(PdfPCell.ALIGN_CENTER);
     			cellData.setFixedHeight(25f);
     			head.addCell(cellData);

     			cellData = new PdfPCell(new Phrase(""));
     			cellData.setBorder(Rectangle.NO_BORDER);
     			cellData.setColspan(6);
     			cellData.setVerticalAlignment(PdfPCell.ALIGN_CENTER);
     			cellData.setHorizontalAlignment(PdfPCell.ALIGN_CENTER);
     			cellData.setFixedHeight(25f);
     			head.addCell(cellData);

                 head.setTotalWidth(page.width() - document.leftMargin() - document.rightMargin());
                 head.writeSelectedRows(0, -1, document.leftMargin(), page.height() - document.topMargin() + head.getTotalHeight(),writer.getDirectContent());

           /*      String [] strFooterMargins = footerMargin.split(",");
                 float [] footerMargins = new float[strFooterMargins.length];
                 for (int i = 0; i < strFooterMargins.length; i++){

                 	footerMargins[i] = Float.parseFloat(strFooterMargins[i]);
                 }

                 float [] footerCols = footerMargins;
          */   // PdfPTable foot = new PdfPTable(footerCols);

                float[] footerWidths = {190, 370};
                PdfPTable foot = new PdfPTable(footerWidths);
                foot.setWidthPercentage(100);
                foot.setHorizontalAlignment(PdfTable.ALIGN_CENTER);

                cellData = new PdfPCell(new Phrase("Revised April 1, 2009",geINSPIRA9B));
     			cellData.setBorder(Rectangle.NO_BORDER);
     			cellData.setPaddingTop(10);
     	//		cellData.setPaddingRight(12);
     			cellData.setColspan(1);
     			cellData.setVerticalAlignment(PdfPCell.ALIGN_CENTER);
     			cellData.setHorizontalAlignment(PdfPCell.ALIGN_CENTER);
     			foot.addCell(cellData);

                cellData = new PdfPCell(new Phrase(this.footerLeft,geINSPIRA9G));
     			cellData.setBorder(Rectangle.NO_BORDER);
     			cellData.setPaddingTop(10);
     	//		cellData.setPaddingRight(12);
     			cellData.setColspan(1);
     			cellData.setVerticalAlignment(PdfPCell.ALIGN_CENTER);
     			cellData.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
     			foot.addCell(cellData);
     	/*
     			cellData = new PdfPCell(new Phrase(this.footerCenter,geINSPIRA8));
     			cellData.setBorder(Rectangle.NO_BORDER);
     			cellData.setPaddingTop(20f);
     			cellData.setColspan(1);
     			cellData.setVerticalAlignment(PdfPCell.ALIGN_CENTER);
     			cellData.setHorizontalAlignment(PdfPCell.ALIGN_CENTER);
     			cellData.setFixedHeight(25f);
     			foot.addCell(cellData);

     			cellData = new PdfPCell(new Phrase("",geINSPIRA8));
     			cellData.setBorder(Rectangle.NO_BORDER);
     			cellData.setColspan(6);
     			cellData.setVerticalAlignment(PdfPCell.ALIGN_CENTER);
     			cellData.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);
     			cellData.setFixedHeight(25f);
     			foot.addCell(cellData);
          */
                foot.setTotalWidth(page.width() - document.leftMargin() - document.rightMargin());

               foot.writeSelectedRows(0, -1, document.leftMargin(), document.bottomMargin(),writer.getDirectContent());
           }
        }catch(IOException e){
        	LOGGER.error("IO Error :: " + e.getMessage());
        }catch(DocumentException e){
        	LOGGER.error("Document Error :: " + e.getMessage());
        }//catch(Exception e){
        //	LOGGER.error(" Error :: " + e.getMessage());
        //}


    }
/**
 * The method set the required fonts
 *
 */
    private void setFonts()
	{
		try
		{
			bfGEInspRg = BaseFont.createFont("./styles/GEInspiraReg.TTF",  BaseFont.CP1252,BaseFont.EMBEDDED);

			geINSPIRA12B = new Font(bfGEInspRg,12.5f,Font.BOLD);
			geINSPIRA11B = new Font(bfGEInspRg,8.5f,Font.NORMAL);
			geINSPIRA10B = new Font(bfGEInspRg,8.5f,Font.BOLD);
			geINSPIRA8 = new Font(bfGEInspRg,8,0,new Color(0,0,0));
			geINSPIRA9B = new Font(bfGEInspRg,9,Font.BOLD,new Color(0,0,0));
			geINSPIRA9BG = new Font(bfGEInspRg,9,Font.BOLD,new Color(128,128,128));
			geINSPIRA9G = new Font(bfGEInspRg,9,Font.NORMAL,new Color(128,128,128));

		}catch(FileNotFoundException e){
        	LOGGER.error("Runtime Error :: " + e.getMessage());
        }
        catch (Exception e) {
            LOGGER.error("Error :: " + e.getMessage());
        }
	}
 }