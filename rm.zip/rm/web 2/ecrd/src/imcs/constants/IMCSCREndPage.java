// Copyright (C) 2000 General Electric Company 
// All rights reserved

package imcs.constants;

import java.awt.Color;
import java.io.IOException;

import org.apache.log4j.PropertyConfigurator;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Font;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfPageEventHelper;
import com.lowagie.text.pdf.PdfWriter;

import ecrd.util.eCRDConstants;
import ecrd.util.eCRDUtil;

/**
 * Demonstrates the use of PageEvents.
 */
public class IMCSCREndPage extends PdfPageEventHelper {
    
	
	Font geInspira7;
	Font geInspira8B;

	BaseFont bfGEInspRg;
	
	private String intModules;
	
	/**Instance of the logger class for logging debug and error messages. */
//	private static final Logger LOGGER = Logger.getLogger("IMCSCREndPage.class");
/*	
	{
		PropertyConfigurator.configure("properties/BatchLog4j.properties");
	}
*/	
	public IMCSCREndPage() {
		super();
	}
	/**
	 * 
	 * @param intModules
	 */
	
	public IMCSCREndPage(String intModules) {
		this();
		this.intModules = intModules;
	}
   
    /**
     * @see com.lowagie.text.pdf.PdfPageEventHelper#onEndPage(com.lowagie.text.pdf.PdfWriter, com.lowagie.text.Document)
     */
    public void onEndPage(PdfWriter writer, Document document) {
        try {
        	setFonts();
            Rectangle page = document.getPageSize();
        
            document.setMargins(30, 30, 20, 45);
    //      LOGGER.debug("page height width " + page.getHeight() + " " + page.getWidth());
            PdfPCell cellData = null;
            
            PdfPTable geFooter = new PdfPTable(new float[]{500,95});
            
			cellData = new PdfPCell(new Phrase("GE Proprietary and Confidential Information", geInspira7));
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setPaddingTop(5f);
			cellData.setVerticalAlignment(PdfPCell.ALIGN_BOTTOM);
			cellData.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
			geFooter.addCell(cellData);
			cellData = null;
						
			cellData = new PdfPCell(new Phrase(" ", geInspira8B));
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setVerticalAlignment(PdfPCell.ALIGN_BOTTOM);
			cellData.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);
			geFooter.addCell(cellData);
			cellData = null;
			            
			cellData = new PdfPCell(new Phrase(" ", geInspira8B));
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setVerticalAlignment(PdfPCell.ALIGN_BOTTOM);
			cellData.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);
			geFooter.addCell(cellData);
			cellData = null;
			
			cellData = new PdfPCell(new Phrase(" ", geInspira8B));
			cellData.setBorder(Rectangle.NO_BORDER);
			cellData.setVerticalAlignment(PdfPCell.ALIGN_BOTTOM);
			cellData.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);
			geFooter.addCell(cellData);
			cellData = null;
			            
            geFooter.setTotalWidth(600 - document.leftMargin() - document.rightMargin());
            
            geFooter.writeSelectedRows(0, -1, document.leftMargin(), document.bottomMargin(),
                   writer.getDirectContent());
        }catch (Exception e) {
        	e.printStackTrace();
		}
        
    }
/**
 * The method sets the required fonts
 *
 */
    private void setFonts() 
	{
		try
		{
			bfGEInspRg = BaseFont.createFont(eCRDUtil.getAFSPath() + eCRDConstants.STRCTRL + eCRDConstants.STRGEINSPRAFONT,  BaseFont.CP1252,BaseFont.EMBEDDED);

			geInspira7 = new Font(bfGEInspRg,7,0,new Color(0,0,0));
			geInspira8B = new Font(bfGEInspRg,9,Font.BOLD,new Color(0,0,0));
			
		}catch(IOException e){
			e.getMessage();
		}catch(DocumentException e){
			e.getMessage();
		}catch(Exception e){
			e.getMessage();
		}
	}
/**
 * @return Returns the intModules.
 */
public String getIntModules() {
	return intModules;
}
/**
 * @param intModules The intModules to set.
 */
public void setIntModules(String intModules) {
	this.intModules = intModules;
}
}

