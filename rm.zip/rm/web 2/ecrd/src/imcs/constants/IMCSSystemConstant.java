// Copyright (C) 2000 General Electric Company 
// All rights reserved

/**
 * Module:       IMCSSystemConstant.java
 * Author:       Tata Consultancy Services
 * Project:      
 * Date Written: 
 * Security:     Unclassified
 * Restrictions: GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 *
 *     ****************************************************
 *     *  Copyright (2000) with all rights reserved       *
 *     *          General Electric Company                *
 *     ****************************************************
 *
 * Description:  
 *
 * Revision Log  (mm/dd/yy initials description)
 * --------------------------------------------------------------
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */

package imcs.constants;

import java.awt.Color;
import java.io.IOException;

import com.lowagie.text.DocumentException;
import com.lowagie.text.Font;
import com.lowagie.text.pdf.BaseFont;

/**
 * 
 * @author 226855
 * 
 */
public class IMCSSystemConstant {

	public static final String COMP_REP_TITLE_TEXT_1 = "GE Proprietary\nInformation\n";

	public static final String COMP_REP_TITLE_TEXT_2 = "The information contained in this document is\n"
			+ "GE proprietary information and is disclosed in\n"
			+ "confidence. It is the property of GE and shall\n"
			+ "not be used, disclosed to others or reproduced\n"
			+ "without the express written consent of GE. If\n"
			+ "consent is given for reproduction in whole or\n"
			+ "in part, this notice and the notice set forth on\n"
			+ "each page of this document shall appear in\n"
			+ "any such reproduction in whole or in part. The\n"
			+ "information contained in this document may\n"
			+ "also be controlled by U.S. export control laws.\n "
			+ "Unauthorized export or re-export is prohibited.\n\n"
			+ "GE Aviation\n" + "Cincinnati, Ohio\n\n";

	public static final String RELATIVE_PDF_FILE_PATH = "./pdf/";

	public static final String PDF_FILE_EXTENSION_PATH = ".pdf";

	public static final String RELATIVE_IMAGES_FILE_PATH = "./images/";

	private Font geINSPIRA12;

	private Font geINSPIRA20B;

	private Font geINSPIRA22;

	private Font geINSPIRA11B;

	private Font geINSPIRA9B;

	private Font geINSPIRA8;

	private Font geINSPIRA8B;

	private Font geINSPIRA10;

	private Font geINSPIRA6;

	private Font geINSPIRA7;

	private Font geINSPIRA16;

	private Font geINSPIRA12G;

	private Font geINSPIRA120;

	private Font geINSPIRA20G;

	private Font geINSPIRA13;

	private Font geINSPIRA14B;

	private Font geINSPIRA4;

	private BaseFont bfGEInspRg;

	/**
	 * The method sets the required fonts
	 * 
	 */
	public IMCSSystemConstant() {
			try {
				bfGEInspRg = BaseFont.createFont("./styles/GEInspiraReg.TTF",
						BaseFont.CP1252, BaseFont.EMBEDDED);
						geINSPIRA12 = new Font(bfGEInspRg, 12, 0, new Color(0, 0, 0));
			geINSPIRA13 = new Font(bfGEInspRg, 13, 0, new Color(0, 0, 0));
			geINSPIRA20B = new Font(bfGEInspRg, 20, Font.BOLD);
			geINSPIRA14B = new Font(bfGEInspRg, 14, Font.BOLD);
			geINSPIRA16 = new Font(bfGEInspRg, 16, 0, new Color(0, 0, 0));
			geINSPIRA22 = new Font(bfGEInspRg, 22);
			geINSPIRA6 = new Font(bfGEInspRg, 6, 0, new Color(0, 0, 0));
			geINSPIRA7 = new Font(bfGEInspRg, 7, 0, new Color(0, 0, 0));
			geINSPIRA8 = new Font(bfGEInspRg, 8, 0, new Color(0, 0, 0));
			geINSPIRA8B = new Font(bfGEInspRg, 9, Font.BOLD, new Color(0, 0, 0));
			geINSPIRA9B = new Font(bfGEInspRg, 9, Font.BOLD, new Color(255,
					255, 255));
			geINSPIRA10 = new Font(bfGEInspRg, 10);
			geINSPIRA11B = new Font(bfGEInspRg, 11, Font.BOLD);
			geINSPIRA12G = new Font(bfGEInspRg, 12, 0, new Color(192, 192, 192));
			geINSPIRA120 = new Font(bfGEInspRg, 120, 0, new Color(0, 0, 0));
			geINSPIRA20G = new Font(bfGEInspRg, 20, 0, new Color(192, 192, 192));
			geINSPIRA4 = new Font(bfGEInspRg, 4);
			} catch (DocumentException e) {
				e.getMessage();
			} catch (IOException e) {
				e.getMessage();
			}
		}

	/**
	 * @return Returns the bfGEInspRg.
	 */
	public BaseFont getBfGEInspRg() {
		return bfGEInspRg;
	}

	/**
	 * @return Returns the cOMP_REP_TITLE_TEXT_1.
	 */
	public String getCOMPREPTITLETEXT1() {
		return COMP_REP_TITLE_TEXT_1;
	}

	/**
	 * @return Returns the cOMP_REP_TITLE_TEXT_2.
	 */
	public String getCOMPREPTITLETEXT2() {
		return COMP_REP_TITLE_TEXT_2;
	}

	/**
	 * @return Returns the geINSPIRA10.
	 */
	public Font getGeINSPIRA10() {
		return geINSPIRA10;
	}

	/**
	 * @return Returns the geINSPIRA11B.
	 */
	public Font getGeINSPIRA11B() {
		return geINSPIRA11B;
	}

	/**
	 * @return Returns the geINSPIRA12.
	 */
	public Font getGeINSPIRA12() {
		return geINSPIRA12;
	}

	/**
	 * @return Returns the geINSPIRA120.
	 */
	public Font getGeINSPIRA120() {
		return geINSPIRA120;
	}

	/**
	 * @return Returns the geINSPIRA12G.
	 */
	public Font getGeINSPIRA12G() {
		return geINSPIRA12G;
	}

	/**
	 * @return Returns the geINSPIRA13.
	 */
	public Font getGeINSPIRA13() {
		return geINSPIRA13;
	}

	/**
	 * @return Returns the geINSPIRA14B.
	 */
	public Font getGeINSPIRA14B() {
		return geINSPIRA14B;
	}

	/**
	 * @return Returns the geINSPIRA16.
	 */
	public Font getGeINSPIRA16() {
		return geINSPIRA16;
	}

	/**
	 * @return Returns the geINSPIRA20B.
	 */
	public Font getGeINSPIRA20B() {
		return geINSPIRA20B;
	}

	/**
	 * @return Returns the geINSPIRA20G.
	 */
	public Font getGeINSPIRA20G() {
		return geINSPIRA20G;
	}

	/**
	 * @return Returns the geINSPIRA22.
	 */
	public Font getGeINSPIRA22() {
		return geINSPIRA22;
	}

	/**
	 * @return Returns the geINSPIRA4.
	 */
	public Font getGeINSPIRA4() {
		return geINSPIRA4;
	}

	/**
	 * @return Returns the geINSPIRA6.
	 */
	public Font getGeINSPIRA6() {
		return geINSPIRA6;
	}

	/**
	 * @return Returns the geINSPIRA7.
	 */
	public Font getGeINSPIRA7() {
		return geINSPIRA7;
	}

	/**
	 * @return Returns the geINSPIRA8.
	 */
	public Font getGeINSPIRA8() {
		return geINSPIRA8;
	}

	/**
	 * @return Returns the geINSPIRA8B.
	 */
	public Font getGeINSPIRA8B() {
		return geINSPIRA8B;
	}

	/**
	 * @return Returns the geINSPIRA9B.
	 */
	public Font getGeINSPIRA9B() {
		return geINSPIRA9B;
	}

	/**
	 * @param geINSPIRA10 The geINSPIRA10 to set.
	 */
	public void setGeINSPIRA10(Font geINSPIRA10) {
		this.geINSPIRA10 = geINSPIRA10;
	}

	/**
	 * @param geINSPIRA11B The geINSPIRA11B to set.
	 */
	public void setGeINSPIRA11B(Font geINSPIRA11B) {
		this.geINSPIRA11B = geINSPIRA11B;
	}

	/**
	 * @param geINSPIRA12 The geINSPIRA12 to set.
	 */
	public void setGeINSPIRA12(Font geINSPIRA12) {
		this.geINSPIRA12 = geINSPIRA12;
	}

	/**
	 * @param geINSPIRA120 The geINSPIRA120 to set.
	 */
	public void setGeINSPIRA120(Font geINSPIRA120) {
		this.geINSPIRA120 = geINSPIRA120;
	}

	/**
	 * @param geINSPIRA12G The geINSPIRA12G to set.
	 */
	public void setGeINSPIRA12G(Font geINSPIRA12G) {
		this.geINSPIRA12G = geINSPIRA12G;
	}

	/**
	 * @param geINSPIRA13 The geINSPIRA13 to set.
	 */
	public void setGeINSPIRA13(Font geINSPIRA13) {
		this.geINSPIRA13 = geINSPIRA13;
	}

	/**
	 * @param geINSPIRA14B The geINSPIRA14B to set.
	 */
	public void setGeINSPIRA14B(Font geINSPIRA14B) {
		this.geINSPIRA14B = geINSPIRA14B;
	}

	/**
	 * @param geINSPIRA16 The geINSPIRA16 to set.
	 */
	public void setGeINSPIRA16(Font geINSPIRA16) {
		this.geINSPIRA16 = geINSPIRA16;
	}

	/**
	 * @param geINSPIRA20B The geINSPIRA20B to set.
	 */
	public void setGeINSPIRA20B(Font geINSPIRA20B) {
		this.geINSPIRA20B = geINSPIRA20B;
	}

	/**
	 * @param geINSPIRA20G The geINSPIRA20G to set.
	 */
	public void setGeINSPIRA20G(Font geINSPIRA20G) {
		this.geINSPIRA20G = geINSPIRA20G;
	}

	/**
	 * @param geINSPIRA22 The geINSPIRA22 to set.
	 */
	public void setGeINSPIRA22(Font geINSPIRA22) {
		this.geINSPIRA22 = geINSPIRA22;
	}

	/**
	 * @param geINSPIRA4 The geINSPIRA4 to set.
	 */
	public void setGeINSPIRA4(Font geINSPIRA4) {
		this.geINSPIRA4 = geINSPIRA4;
	}

	/**
	 * @param geINSPIRA6 The geINSPIRA6 to set.
	 */
	public void setGeINSPIRA6(Font geINSPIRA6) {
		this.geINSPIRA6 = geINSPIRA6;
	}

	/**
	 * @param geINSPIRA7 The geINSPIRA7 to set.
	 */
	public void setGeINSPIRA7(Font geINSPIRA7) {
		this.geINSPIRA7 = geINSPIRA7;
	}

	/**
	 * @param geINSPIRA8 The geINSPIRA8 to set.
	 */
	public void setGeINSPIRA8(Font geINSPIRA8) {
		this.geINSPIRA8 = geINSPIRA8;
	}

	/**
	 * @param geINSPIRA8B The geINSPIRA8B to set.
	 */
	public void setGeINSPIRA8B(Font geINSPIRA8B) {
		this.geINSPIRA8B = geINSPIRA8B;
	}

	/**
	 * @param geINSPIRA9B The geINSPIRA9B to set.
	 */
	public void setGeINSPIRA9B(Font geINSPIRA9B) {
		this.geINSPIRA9B = geINSPIRA9B;
	}

	
}
