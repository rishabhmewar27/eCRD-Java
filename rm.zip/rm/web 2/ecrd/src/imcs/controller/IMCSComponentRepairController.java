// Copyright (C) 2000 General Electric Company 
// All rights reserved 

package imcs.controller;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import imcs.bean.IMCSComponentRepairBean;
import imcs.constants.IMCSSystemConstant;
import imcs.utilities.IMCSCRPdfCreator;
import imcs.utilities.IMCSUtility;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfImportedPage;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfWriter;
/**
 * 
 * @author 226855
 *
 */
public class IMCSComponentRepairController {

	/** Instance of the logger class for logging debug and error messages. */
	private static final Logger LOGGER = Logger
			.getLogger("IMCSComponentRepairController.class");
/**
 * 
 * @param imcsCrClBean
 */
	public void createCompRepairPDF(IMCSComponentRepairBean imcsCrClBean) {
		try {
			PropertyConfigurator.configure("properties/BatchLog4j.properties");
			LOGGER.debug("Inside IMCSSparePartsController");
			LOGGER.debug("Engine Name " + imcsCrClBean.getEngineName());
			LOGGER.debug("Engine Model Num " + imcsCrClBean.getEngineMdlNum());
			ArrayList pdfData = new ArrayList();
			IMCSCRPdfCreator imcsCrPDFCreator = null;
			String engineName = imcsCrClBean.getEngineName();
			
			if("CF34-3RJ&BJ".equalsIgnoreCase(engineName)){
				String engineMdl = imcsCrClBean.getEngineMdlNum();
				String[] arrEngName = {"CF34-3RJ","CF34-3BJ"};
				String [] arrEngMdls = engineMdl.split("_");
				for(int i = 0; i < arrEngMdls.length; i++)
				{
					imcsCrPDFCreator = new IMCSCRPdfCreator();
					imcsCrClBean.setEngineName(arrEngName[i]);
					imcsCrClBean.setEngineMdlNum(arrEngMdls[i]);
					imcsCrPDFCreator.getPDFReport(pdfData, imcsCrClBean,new ArrayList());
				}
			}else{
				imcsCrPDFCreator = new IMCSCRPdfCreator();
				imcsCrPDFCreator.getPDFReport(pdfData, imcsCrClBean,new ArrayList());
			}
			
			pdfData.add(new PdfReader(IMCSSystemConstant.RELATIVE_IMAGES_FILE_PATH + imcsCrClBean.getEngineMainTitlePage()));
			pdfData.add(new PdfReader(IMCSSystemConstant.RELATIVE_PDF_FILE_PATH + imcsCrClBean.getEngineName() + "_CR_final.pdf"));
			
			if("CF34-3RJ&BJ".equalsIgnoreCase(engineName)){
				pdfData.add(new PdfReader("./pdf/CF34-3RJ_CR.pdf"));
				//pdfData.add(new PdfReader("./pdf/CF34-3BJ_CR.pdf"));
				IMCSUtility.copyMyPdfs(pdfData,imcsCrClBean.getEngineName(),"CR");
				IMCSUtility.deleteCRPDFs("CF34-3RJ");
				IMCSUtility.deleteCRPDFs("CF34-3BJ");
				IMCSUtility.deleteCRPDFs(imcsCrClBean.getEngineName());
			}else{
			//	pdfData.add(new PdfReader(IMCSSystemConstant.RELATIVE_PDF_FILE_PATH + imcsCrClBean.getEngineName() + "_CR.pdf"));
				IMCSUtility.copyMyPdfs(pdfData,imcsCrClBean.getEngineName(),"CR");
				IMCSUtility.deleteCRPDFs(imcsCrClBean.getEngineName());
			}
			
			
			
			
		} catch (FileNotFoundException e) {
			LOGGER.error(" Error :: " + e.getMessage());
		} catch (Exception e) {
			LOGGER.error(" Error :: " + e.getMessage());
		}
	}
	
	public static boolean concatPDFs(ArrayList streamOfPDFFiles,
		OutputStream outputStream, boolean paginate) {
		Document document = new Document();
		document.setMargins(0, 0, -20, -20);
		boolean flag = false;
		try {
			ArrayList pdfs = streamOfPDFFiles;
			ArrayList readers = new ArrayList();
			int totalPages = 0;
			Iterator iteratorPDFs = pdfs.iterator();
			// Create Readers for the pdfs.
			while (iteratorPDFs.hasNext()) {
				InputStream pdf = (InputStream) iteratorPDFs.next();
				PdfReader pdfReader = new PdfReader(pdf);
				readers.add(pdfReader);
				totalPages += pdfReader.getNumberOfPages();
			}
			// Create a writer for the outputstream
			PdfWriter writer = PdfWriter.getInstance(document, outputStream);
			document.open();
			BaseFont bf = BaseFont.createFont(BaseFont.HELVETICA,
					BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
			PdfContentByte cb = writer.getDirectContent();
			// Holds the PDF
			// data
			PdfImportedPage page;
			int currentPageNumber = 0;
			int pageOfCurrentReaderPDF = 0;
			Iterator iteratorPDFReader = readers.iterator();
			// Loop through the PDF files and add to the output.
			while (iteratorPDFReader.hasNext()) {
				PdfReader pdfReader = (PdfReader) iteratorPDFReader.next();
				// Create a new page in the target for each source page.
				while (pageOfCurrentReaderPDF < pdfReader.getNumberOfPages()) {
					document.newPage();
					pageOfCurrentReaderPDF++;
					currentPageNumber++;
					page = writer.getImportedPage(pdfReader,
							pageOfCurrentReaderPDF);
					cb.addTemplate(page, 0, 0);
					// Code for pagination.
					if (paginate) {
						cb.beginText();
						cb.setFontAndSize(bf, 9);
						cb.showTextAligned(PdfContentByte.ALIGN_CENTER, ""
								+ currentPageNumber + " of " + totalPages, 520,
								5, 0);
						cb.endText();
					}
				}
				pageOfCurrentReaderPDF = 0;
			}

			outputStream.flush();
			document.close();
			outputStream.close();
			flag = true;
		} catch (IOException e) {
			LOGGER.error(" IO Error :: " + e.getMessage());
		} catch (DocumentException e) {
			LOGGER.error(" Document Error :: " + e.getMessage());
		} catch (Exception e) {
			LOGGER.error(" Error :: " + e.getMessage());
		} finally {
			if (document.isOpen())
				document.close();
			try {
				if (outputStream != null)
					outputStream.close();
			} catch (IOException ioe) {
				LOGGER.error(" Error :: " + ioe.getMessage());
			}
		}
		
		return flag;
	}
/**
 * 
 *
 */
	public void test() {
		try {
			ArrayList pdfData = new ArrayList();
			IMCSComponentRepairBean imcsCRBean = new IMCSComponentRepairBean();
			imcsCRBean.setCatalogId("2854");
			imcsCRBean.setEngineName("4C");
			imcsCRBean.setEffctiveDate("01/16/2008");
			IMCSCRPdfCreator imcsCrPDFCreator = new IMCSCRPdfCreator();
			imcsCrPDFCreator.getPDFReport(pdfData, imcsCRBean, new ArrayList());

		} catch (FileNotFoundException e) {
			LOGGER.error(" Error :: " + e.getMessage());
		} catch (Exception e) {
			LOGGER.error(" Error :: " + e.getMessage());
		}
	}
/**
 * 
 * @param args
 */
	public static void main(String[] args) {
		IMCSComponentRepairController ci = new IMCSComponentRepairController();
		ci.test();
	}

}
