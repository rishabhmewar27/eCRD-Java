// Copyright (C) 2000 General Electric Company 
// All rights reserved

package imcs.controller;

import imcs.bean.IMCSComponentRepairBean;
import imcs.bean.IMCSSparePartsCatalogBean;
import imcs.constants.IMCSSystemConstant;
import imcs.utilities.IMCSBatchProperties;
import imcs.utilities.IMCSUtility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import imcs.controller.IMCSComponentRepairController;
import imcs.controller.IMCSSparePartsController;
import com.lowagie.text.pdf.PdfReader;

public class IMCSController {

	/** Instance of the logger class for logging debug and error messages. */
	private static Logger logger = Logger.getLogger("IMCSController.class");

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		IMCSController imcsController = new IMCSController();

		Properties appProps = new Properties();
		try {
			FileInputStream in = new FileInputStream(
					"./properties/IMCSBatchProperties.properties");
			PropertyConfigurator.configure("properties/BatchLog4j.properties");
			appProps.load(in);
			in.close();
		} catch (FileNotFoundException e) {
			logger.debug("Properties file not found. Terminating application.");
			logger.error("Fatal error occurred:", e);
		} catch (IOException e) {
			logger.debug("IO exception occured. Cannot read from properties file. Terminating application.");
			logger.error("Fatal error occured:", e);
	
		}

		/*
		 * Reading all properties from the properties file and setting into the
		 * properties object appProps.
		 */
		IMCSBatchProperties imcsBatchProperties = IMCSBatchProperties
				.getInstance();
		imcsBatchProperties.setImcsBatchProperties(appProps);

		String BatchSP_Engine = (String) imcsBatchProperties
				.getImcsProperty(IMCSBatchProperties.BATCH_SP_ENGINE);
		logger.debug("BatchSP_Engine = " + BatchSP_Engine);

		imcsController.runSPBatch(BatchSP_Engine, imcsBatchProperties);

		Properties appCRProps = new Properties();
		try {
			FileInputStream in = new FileInputStream(
					"./properties/IMCSCompRepairProperties.properties");
			PropertyConfigurator.configure("properties/BatchLog4j.properties");
			appCRProps.load(in);
			in.close();
		} catch (FileNotFoundException e) {
			logger.debug("Properties file not found. Terminating application.");
			logger.error("Fatal error occurred:", e);
		} catch (IOException e) {
			logger.debug("IO exception occured. Cannot read from properties file. Terminating application.");
			logger.error("Fatal error occured:", e);
		}

		/*
		 * Reading all properties from the properties file and setting into the
		 * properties object appProps.
		 */
		IMCSBatchProperties imcsCRProperties = IMCSBatchProperties
				.getInstance();
		imcsCRProperties.setImcsBatchProperties(appCRProps);

		String engCRName = (String) imcsCRProperties
				.getImcsProperty(IMCSBatchProperties.BATCH_CR_ENGINES);
		logger.debug("engCRName = " + engCRName);

		String engMdlName = (String) imcsCRProperties
				.getImcsProperty(IMCSBatchProperties.BATCH_CR_ENGINE_MDLS);
		logger.debug("engMdlName = " + engMdlName);
/*
		try {
			imcsController.runCRBatch(engCRName, engMdlName, imcsCRProperties);
		} catch (IOException e) {
			logger.error("ERROR :: " + e.getMessage());
		}catch (Exception e) {
			logger.error("ERROR :: " + e.getMessage());
		}
*/
	}

	/**
	 * 
	 * @param spEngineFamily
	 * @param imcsBatchProperties
	 * @return
	 */
	public String runSPBatch(String spEngineFamily,
			IMCSBatchProperties imcsBatchProperties) {
		IMCSSparePartsController imcsSpController = new IMCSSparePartsController();
		IMCSSparePartsCatalogBean imcsSpBean;
		String[] spEngineArr = spEngineFamily.split(",");
		try {
			for (int i = 0; i < spEngineArr.length; i++) {
				logger.debug("Start PDF Creation for Engine : "
						+ spEngineArr[i]);
				if ("CF6".equalsIgnoreCase(spEngineArr[i])) {
					logger.debug("the final engine=" + spEngineArr[i]);
					imcsSpBean = new IMCSSparePartsCatalogBean();
					imcsSpBean.setEngineName(spEngineArr[i]);
					File pdfCF6 = new File(
							IMCSSystemConstant.RELATIVE_PDF_FILE_PATH
									+ imcsSpBean.getEngineName()
									+ "_Main_Catalog.pdf");
					File pdfCF6A = new File(
							IMCSSystemConstant.RELATIVE_PDF_FILE_PATH
									+ imcsSpBean.getEngineName()
									+ "_Aviall_Catalog.pdf");
					File pdfCF6T = new File(
							IMCSSystemConstant.RELATIVE_PDF_FILE_PATH
									+ imcsSpBean.getEngineName()
									+ "_Tech_Catalog.pdf");
					if (pdfCF6.exists() && pdfCF6A.exists() && pdfCF6T.exists()) {
						logger.debug("inside concate CF6_Main");
						ArrayList concatCF6Pdfs = new ArrayList();
						concatCF6Pdfs.add(new PdfReader(
								IMCSSystemConstant.RELATIVE_PDF_FILE_PATH
										+ imcsSpBean.getEngineName()
										+ "_Main_Catalog.pdf"));
						concatCF6Pdfs.add(new PdfReader(
								IMCSSystemConstant.RELATIVE_PDF_FILE_PATH
										+ imcsSpBean.getEngineName()
										+ "_Aviall_Catalog.pdf"));
						concatCF6Pdfs.add(new PdfReader(
								IMCSSystemConstant.RELATIVE_PDF_FILE_PATH
										+ imcsSpBean.getEngineName()
										+ "_Tech_Catalog.pdf"));
						
						IMCSUtility.copyMyPdfs(concatCF6Pdfs, imcsSpBean.getEngineName(), "SP");
						
						IMCSUtility.addPageNumbersForCF6("CF6_Catalog",10);
						
						IMCSUtility.deleteCF6PDFs(imcsSpBean.getEngineName());
						IMCSUtility.deletePDFs(imcsSpBean.getEngineName());
						File file = new File(IMCSSystemConstant.RELATIVE_PDF_FILE_PATH + "CF6_Catalog_final.pdf");
					    file.renameTo(new File(IMCSSystemConstant.RELATIVE_PDF_FILE_PATH + "CF6_Catalog.pdf"));
					}
				} else if ("CFM56_Inc".equalsIgnoreCase(spEngineArr[i])) {
					logger.debug("the final engine=" + spEngineArr[i]);
					imcsSpBean = new IMCSSparePartsCatalogBean();
					imcsSpBean.setEngineName(spEngineArr[i]);
					File pdfCFM56 = new File(
							IMCSSystemConstant.RELATIVE_PDF_FILE_PATH
									+ imcsSpBean.getEngineName()
									+ "_Main_Catalog.pdf");
					File pdfCFM56T = new File(
							IMCSSystemConstant.RELATIVE_PDF_FILE_PATH
									+ imcsSpBean.getEngineName()
									+ "_ThrustRev_Catalog.pdf");
					logger.debug("the engine name" + pdfCFM56T);
					if (pdfCFM56.exists() && pdfCFM56T.exists()) {
						logger.debug("inside concate CFM56_Inc_Main");
						ArrayList concatCFM56Pdfs = new ArrayList();
						concatCFM56Pdfs.add(new PdfReader(
								IMCSSystemConstant.RELATIVE_PDF_FILE_PATH
										+ imcsSpBean.getEngineName()
										+ "_Main_Catalog.pdf"));
						concatCFM56Pdfs.add(new PdfReader(
								IMCSSystemConstant.RELATIVE_PDF_FILE_PATH
										+ imcsSpBean.getEngineName()
										+ "_ThrustRev_Catalog.pdf"));
						IMCSUtility.copyMyPdfs(concatCFM56Pdfs, imcsSpBean
								.getEngineName(), "SP");
						
						IMCSUtility.addPageNumbersForCF6("CFM56_Inc_Catalog",10);
						
						IMCSUtility.deleteCFM56PDFs(imcsSpBean.getEngineName());
						IMCSUtility.deletePDFs(imcsSpBean.getEngineName());
						File file = new File(IMCSSystemConstant.RELATIVE_PDF_FILE_PATH + "CFM56_Inc_Catalog_final.pdf");
					    file.renameTo(new File(IMCSSystemConstant.RELATIVE_PDF_FILE_PATH + "CFM56_Inc_Catalog.pdf"));
					}
				} else if ("CFM56_SA".equalsIgnoreCase(spEngineArr[i])) {
					logger.debug("the final engine=" + spEngineArr[i]);
					imcsSpBean = new IMCSSparePartsCatalogBean();
					imcsSpBean.setEngineName(spEngineArr[i]);
					File pdfCFM56s = new File(
							IMCSSystemConstant.RELATIVE_PDF_FILE_PATH
									+ imcsSpBean.getEngineName()
									+ "_Main_Catalog.pdf");
					File pdfCFM56Ts = new File(
							IMCSSystemConstant.RELATIVE_PDF_FILE_PATH
									+ imcsSpBean.getEngineName()
									+ "_ThrustRev_Catalog.pdf");
					if (pdfCFM56s.exists() && pdfCFM56Ts.exists()) {
						logger.debug("inside concate CFM56_SA_Main");
						ArrayList concatCFM56Pdfs = new ArrayList();
						concatCFM56Pdfs.add(new PdfReader(
								IMCSSystemConstant.RELATIVE_PDF_FILE_PATH
										+ imcsSpBean.getEngineName()
										+ "_Main_Catalog.pdf"));
						concatCFM56Pdfs.add(new PdfReader(
								IMCSSystemConstant.RELATIVE_PDF_FILE_PATH
										+ imcsSpBean.getEngineName()
										+ "_ThrustRev_Catalog.pdf"));
						IMCSUtility.copyMyPdfs(concatCFM56Pdfs, imcsSpBean
								.getEngineName(), "SP");
						
						IMCSUtility.addPageNumbersForCF6("CFM56_SA_Catalog",10);
						
						IMCSUtility.deleteCFM56PDFs(imcsSpBean.getEngineName());
						IMCSUtility.deletePDFs(imcsSpBean.getEngineName());
						File file = new File(IMCSSystemConstant.RELATIVE_PDF_FILE_PATH + "CFM56_SA_Catalog_final.pdf");
					    file.renameTo(new File(IMCSSystemConstant.RELATIVE_PDF_FILE_PATH + "CFM56_SA_Catalog.pdf"));
					  
					}
				}else if ("CF34_Airline".equalsIgnoreCase(spEngineArr[i])) {
					logger.debug("the final engine=" + spEngineArr[i]);
					imcsSpBean = new IMCSSparePartsCatalogBean();
					imcsSpBean.setEngineName(spEngineArr[i]);
					File pdfCF34_Airline = new File(
							IMCSSystemConstant.RELATIVE_PDF_FILE_PATH
									+ imcsSpBean.getEngineName()
									+ "_Main_Catalog.pdf");
					File pdfCF34_Airline_Aviall = new File(
							IMCSSystemConstant.RELATIVE_PDF_FILE_PATH
									+ imcsSpBean.getEngineName()
									+ "_Aviall_Catalog.pdf");
					
					if (pdfCF34_Airline.exists() && pdfCF34_Airline_Aviall.exists()) {
						logger.debug("inside concate CF34_Main");
						ArrayList concatCF34Pdfs = new ArrayList();
						concatCF34Pdfs.add(new PdfReader(
								IMCSSystemConstant.RELATIVE_PDF_FILE_PATH
										+ imcsSpBean.getEngineName()
										+ "_Main_Catalog.pdf"));
						concatCF34Pdfs.add(new PdfReader(
								IMCSSystemConstant.RELATIVE_PDF_FILE_PATH
										+ imcsSpBean.getEngineName()
										+ "_Aviall_Catalog.pdf"));
												
						IMCSUtility.copyMyPdfs(concatCF34Pdfs, imcsSpBean.getEngineName(), "SP");
						
						IMCSUtility.addPageNumbersForCF6("CF34_Airline_Catalog",10);
						
						IMCSUtility.deleteCF6PDFs(imcsSpBean.getEngineName());
						IMCSUtility.deletePDFs(imcsSpBean.getEngineName());
						File file = new File(IMCSSystemConstant.RELATIVE_PDF_FILE_PATH + "CF34_Airline_Catalog_2009.pdf");
					    file.renameTo(new File(IMCSSystemConstant.RELATIVE_PDF_FILE_PATH + "CF34_Airline_Catalog.pdf"));
					}
				}else if ("CF34_General_Aviation".equalsIgnoreCase(spEngineArr[i])) {
					logger.debug("the final engine=" + spEngineArr[i]);
					imcsSpBean = new IMCSSparePartsCatalogBean();
					imcsSpBean.setEngineName(spEngineArr[i]);
					File pdfCF34_Airline = new File(
							IMCSSystemConstant.RELATIVE_PDF_FILE_PATH
									+ imcsSpBean.getEngineName()
									+ "_Main_Catalog.pdf");
					File pdfCF34_Airline_Aviall = new File(
							IMCSSystemConstant.RELATIVE_PDF_FILE_PATH
									+ imcsSpBean.getEngineName()
									+ "_Aviall_Catalog.pdf");
					
					if (pdfCF34_Airline.exists() && pdfCF34_Airline_Aviall.exists()) {
						logger.debug("inside concate CF34_Main");
						ArrayList concatCF34Pdfs = new ArrayList();
						concatCF34Pdfs.add(new PdfReader(
								IMCSSystemConstant.RELATIVE_PDF_FILE_PATH
										+ imcsSpBean.getEngineName()
										+ "_Main_Catalog.pdf"));
						concatCF34Pdfs.add(new PdfReader(
								IMCSSystemConstant.RELATIVE_PDF_FILE_PATH
										+ imcsSpBean.getEngineName()
										+ "_Aviall_Catalog.pdf"));
												
						IMCSUtility.copyMyPdfs(concatCF34Pdfs, imcsSpBean.getEngineName(), "SP");
						
						IMCSUtility.addPageNumbersForCF6("CF34_General_Aviation_Catalog",10);
						
						IMCSUtility.deleteCF6PDFs(imcsSpBean.getEngineName());
						IMCSUtility.deletePDFs(imcsSpBean.getEngineName());
						File file = new File(IMCSSystemConstant.RELATIVE_PDF_FILE_PATH + "CF34_General_Aviation_Catalog_2009.pdf");
					    file.renameTo(new File(IMCSSystemConstant.RELATIVE_PDF_FILE_PATH + "CF34_General_Aviation_Catalog.pdf"));
					}
				}else {
					String engineMainTitlePg = "" + spEngineArr[i]
							+ ".Main_Title_Page";
					String spEngMainTtlPg = (String) imcsBatchProperties
							.getImcsProperty(engineMainTitlePg);
					logger.debug("property name = " + engineMainTitlePg
							+ " spEngMainTtlPg = " + spEngMainTtlPg);

					String enginePreamble = spEngineArr[i] + ".Preamble";
					String spEngPreamble = (String) imcsBatchProperties
							.getImcsProperty(enginePreamble);
					logger.debug("property name = " + enginePreamble
							+ " spEngPreamble = " + spEngPreamble);

					String engineTitlePg = "" + spEngineArr[i] + ".Title_Page";
					String spEngTtlPg = (String) imcsBatchProperties
							.getImcsProperty(engineTitlePg);
					logger.debug("property name = " + engineTitlePg
							+ " spEngTtlPg = " + spEngTtlPg);

					String headerMargin = "" + spEngineArr[i] + ".headerMargin";
					String spHeaderMargin = (String) imcsBatchProperties
							.getImcsProperty(headerMargin);
					logger.debug("property name = " + headerMargin
							+ " spHeaderMargin = " + spHeaderMargin);

					String headerLeft = "" + spEngineArr[i] + ".headerLeft";
					String spHeaderLeft = (String) imcsBatchProperties
							.getImcsProperty(headerLeft);
					logger.debug("property name = " + headerLeft
							+ " spHeaderLeft = " + spHeaderLeft);

					String headerCenterLeft = "" + spEngineArr[i]
							+ ".headerCenterLeft";
					String spHeaderCenterLeft = (String) imcsBatchProperties
							.getImcsProperty(headerCenterLeft);
					logger.debug("property name = " + headerCenterLeft
							+ "spHeaderCenterLeft = " + spHeaderCenterLeft);

					String headerCenterRight = "" + spEngineArr[i]
							+ ".headerCenterRight";
					String spHeaderCenterRight = (String) imcsBatchProperties
							.getImcsProperty(headerCenterRight);
					logger.debug("property name = " + headerCenterRight
							+ "spHeaderCenterRight = " + spHeaderCenterRight);

					String headerRight = "" + spEngineArr[i] + ".headerRight";
					String spHeaderRight = (String) imcsBatchProperties
							.getImcsProperty(headerRight);
					logger.debug("property name = " + headerRight
							+ " spHeaderRight = " + spHeaderRight);

					String headerCenter = "" + spEngineArr[i] + ".headerCenter";
					String spHeaderCenter = (String) imcsBatchProperties
							.getImcsProperty(headerCenter);
					logger.debug("property name = " + headerCenter
							+ " spHeaderCenter = " + spHeaderCenter);

					String headerDownLeft = "" + spEngineArr[i]
							+ ".headerDownLeft";
					String spHeaderDownLeft = (String) imcsBatchProperties
							.getImcsProperty(headerDownLeft);
					logger.debug("property name = " + headerDownLeft
							+ " spHeaderDownLeft = " + spHeaderDownLeft);

					String footerMargin = "" + spEngineArr[i] + ".footerMargin";
					String spFooterMargin = (String) imcsBatchProperties
							.getImcsProperty(footerMargin);
					logger.debug("property name = " + footerMargin
							+ " spFooterMargin = " + spFooterMargin);

					String footerLeft = "" + spEngineArr[i] + ".footerLeft";
					String spFooterLeft = (String) imcsBatchProperties
							.getImcsProperty(footerLeft);
					logger.debug("property name = " + footerLeft
							+ " spFooterLeft = " + spFooterLeft);

					String footerCenter = "" + spEngineArr[i] + ".footerCenter";
					String spFooterCenter = (String) imcsBatchProperties
							.getImcsProperty(footerCenter);
					logger.debug("property name = " + footerCenter
							+ "spFooterCenter = " + spFooterCenter);

					imcsSpBean = new IMCSSparePartsCatalogBean();
					imcsSpBean.setEngineName(spEngineArr[i]);
					imcsSpBean.setEngineMainTitlePage(spEngMainTtlPg);
					imcsSpBean.setEnginePreamble(spEngPreamble);
					imcsSpBean.setEngineTitlePage(spEngTtlPg);
					imcsSpBean.setHeaderMargin(spHeaderMargin);
					imcsSpBean.setHeaderLeft(spHeaderLeft);
					imcsSpBean.setHeaderCenterLeft(spHeaderCenterLeft);
					imcsSpBean.setHeaderCenterRight(spHeaderCenterRight);
					imcsSpBean.setHeaderRight(spHeaderRight);
					imcsSpBean.setHeaderCenter(spHeaderCenter);
					imcsSpBean.setHeaderDownLeft(spHeaderDownLeft);
					imcsSpBean.setFooterMargin(spFooterMargin);
					imcsSpBean.setFooterLeft(spFooterLeft);
					imcsSpBean.setFooterCenter(spFooterCenter);

					imcsSpController.createSparePartPDF(imcsSpBean);
					logger.debug("END PDF Creation for Engine : "
							+ spEngineArr[i]);
				}
			}
		} catch (IOException e) {
			logger.error(" IO Error :: " + e.getMessage());
		} catch (Exception e) {
			logger.error(" Error :: " + e.getMessage());
		}
		return null;
	}

	/**
	 * 
	 * @param crEngineFamily
	 * @param crEngMdlNums
	 * @param imcsBatchProperties
	 * @return null
	 * @throws IOException 
	 */
	public String runCRBatch(String crEngineFamily, String crEngMdlNums,
			IMCSBatchProperties imcsBatchProperties) throws IOException {
		String[] crEngineArr1 = crEngineFamily.split(",");
		FileInputStream in = null;
		for (int i = 0; i < crEngineArr1.length; i++) {
			Properties appCRProps = new Properties();
			try {
				in = new FileInputStream(
						"./properties/IMCSCompRepairProperties.properties");
				PropertyConfigurator
						.configure("properties/BatchLog4j.properties");
				appCRProps.load(in);
				in.close();
			} catch (FileNotFoundException e) {
				logger.debug("Properties file not found. Terminating application.");
				logger.error("Fatal error occurred:", e);
			} catch (IOException e) {
				logger.debug("IO exception occured. Cannot read from properties file. Terminating application.");
				logger.error("Fatal error occured:", e);
			} catch (Exception e) {
				logger.debug("Exception occured. Terminating application.");
				logger.error("Fatal error occured:", e);
			} finally{
				in.close();
			}

			/*
			 * Reading all properties from the properties file and setting into
			 * the properties object appProps.
			 */
			IMCSBatchProperties imcsCRProperties = IMCSBatchProperties
					.getInstance();
			imcsCRProperties.setImcsBatchProperties(appCRProps);

			String engCRName = (String) imcsCRProperties
					.getImcsProperty(IMCSBatchProperties.BATCH_CR_ENGINES);
			logger.debug("engCRName = " + engCRName);

			String engMdlName = (String) imcsCRProperties
					.getImcsProperty(IMCSBatchProperties.BATCH_CR_ENGINE_MDLS);
			logger.debug("engMdlName = " + engMdlName);

			IMCSComponentRepairController imcsCrController = new IMCSComponentRepairController();
			IMCSComponentRepairBean imcsCrBean;
			String[] crEngineArr = crEngineFamily.split(",");
			String[] crEngineMdlArr = crEngMdlNums.split(",");

			logger.debug("Start PDF Creation for Engine : " + crEngineArr[i]);

			imcsCrBean = new IMCSComponentRepairBean();
			imcsCrBean.setEngineName(crEngineArr[i]);
			imcsCrBean.setEngineMdlNum(crEngineMdlArr[i]);

			String engineTitlePg = crEngineArr[i] + ".Title_Page";
			logger.debug("property name = " + engineTitlePg);
			String crEngMainTtlPg = (String) imcsBatchProperties
					.getImcsProperty(engineTitlePg);
			logger.debug("crEngMainTtlPg = " + crEngMainTtlPg);
			imcsCrBean.setEngineMainTitlePage(crEngMainTtlPg);
			imcsCrController.createCompRepairPDF(imcsCrBean);

			logger.debug("END PDF Creation for Engine : " + crEngineArr[i]);
		}

		return null;
	}

}
