// Copyright (C) 2000 General Electric Company 
// All rights reserved 

package imcs.controller;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import imcs.bean.IMCSSparePartsCatalogBean;
import imcs.constants.IMCSSystemConstant;
import imcs.dao.IMCSSparePartsDAO;
import imcs.utilities.IMCSPDFCreator;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfImportedPage;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfWriter;

public class IMCSSparePartsController {

	/** Instance of the logger class for logging debug and error messages. */
	private static final Logger LOGGER = Logger
			.getLogger("IMCSSparePartsController.class");

	public void createSparePartPDF(IMCSSparePartsCatalogBean imcsSpClBean) {
		PropertyConfigurator.configure("properties/BatchLog4j.properties");
		LOGGER.debug("Engine Name " + imcsSpClBean.getEngineName());
		LOGGER.debug("Engine Main Title Page "
				+ imcsSpClBean.getEngineMainTitlePage());
		LOGGER.debug("Title Page " + imcsSpClBean.getEngineTitlePage());
		LOGGER.debug("Preamble " + imcsSpClBean.getEnginePreamble());
		ArrayList pdfs = new ArrayList();
		ArrayList pdfData = null;
		IMCSPDFCreator imcsPDFCreator = null;
		IMCSSparePartsDAO iDao = new IMCSSparePartsDAO();
		try {
			String engName = imcsSpClBean.getEngineName();
			if ("CF6_Aviall".equals(engName)) {
				String ttlPg = imcsSpClBean.getEngineTitlePage();
				pdfs.add(new PdfReader(
						IMCSSystemConstant.RELATIVE_IMAGES_FILE_PATH + ttlPg
								+ IMCSSystemConstant.PDF_FILE_EXTENSION_PATH));
				pdfData = iDao.getSparePartDetails(imcsSpClBean
						.getEngineName());
				imcsPDFCreator = new IMCSPDFCreator();
				imcsPDFCreator.createSpClPDF(pdfData, imcsSpClBean, pdfs,0);
			} else if (engName.matches("CF6_Tech")) {
				String ttlPg = imcsSpClBean.getEngineTitlePage();
				pdfs.add(new PdfReader(
						IMCSSystemConstant.RELATIVE_IMAGES_FILE_PATH + ttlPg
								+ IMCSSystemConstant.PDF_FILE_EXTENSION_PATH));
				pdfData = iDao.getSparePartDetails(imcsSpClBean
						.getEngineName());
				imcsPDFCreator = new IMCSPDFCreator();
				imcsPDFCreator.createSpClPDF(pdfData, imcsSpClBean, pdfs,0);
			} else if (engName.matches("CFM56_SA_ThrustRev")) {
				String ttlPg = imcsSpClBean.getEngineTitlePage();
				pdfs.add(new PdfReader(
						IMCSSystemConstant.RELATIVE_IMAGES_FILE_PATH + ttlPg
								+ IMCSSystemConstant.PDF_FILE_EXTENSION_PATH));
				pdfData = iDao.getSparePartDetails(imcsSpClBean
						.getEngineName());
				imcsPDFCreator = new IMCSPDFCreator();
				imcsPDFCreator.createSpClPDF(pdfData, imcsSpClBean, pdfs,0);
			} else if (engName.matches("CFM56_Inc_ThrustRev")) {
				String ttlPg = imcsSpClBean.getEngineTitlePage();
				pdfs.add(new PdfReader(
						IMCSSystemConstant.RELATIVE_IMAGES_FILE_PATH + ttlPg
								+ IMCSSystemConstant.PDF_FILE_EXTENSION_PATH));
				pdfData = iDao.getSparePartDetails(imcsSpClBean
						.getEngineName());
				imcsPDFCreator = new IMCSPDFCreator();
				imcsPDFCreator.createSpClPDF(pdfData, imcsSpClBean, pdfs,0);
			} else if (engName.matches("CF6")) {
				pdfData = iDao.getSparePartDetails(imcsSpClBean
						.getEngineName());
				imcsPDFCreator = new IMCSPDFCreator();
				imcsPDFCreator.createSpClPDF(pdfData, imcsSpClBean, pdfs,0);
			} else if (engName.matches("CFM56_Inc")) {
				pdfData = iDao.getSparePartDetails(imcsSpClBean
						.getEngineName());
				imcsPDFCreator = new IMCSPDFCreator();
				imcsPDFCreator.createSpClPDF(pdfData, imcsSpClBean, pdfs,0);
			} else if (engName.matches("CFM56_SA")) {
				pdfData = iDao.getSparePartDetails(imcsSpClBean
						.getEngineName());
				imcsPDFCreator = new IMCSPDFCreator();
				imcsPDFCreator.createSpClPDF(pdfData, imcsSpClBean, pdfs,0);
			}else if ("CF34_Airline_Aviall".equals(engName) || "CF34_General_Aviation_Aviall".equals(engName)) {
				String ttlPg = imcsSpClBean.getEngineTitlePage();
				pdfs.add(new PdfReader(
						IMCSSystemConstant.RELATIVE_IMAGES_FILE_PATH + ttlPg
								+ IMCSSystemConstant.PDF_FILE_EXTENSION_PATH));
				pdfData = iDao.getSparePartDetails(imcsSpClBean
						.getEngineName());
				imcsPDFCreator = new IMCSPDFCreator();
				imcsPDFCreator.createSpClPDF(pdfData, imcsSpClBean, pdfs,0);
			}else {
				String mainTtlPg = imcsSpClBean.getEngineMainTitlePage();
				String ttlPg = imcsSpClBean.getEngineTitlePage();
				String preAmble = imcsSpClBean.getEnginePreamble();
				pdfs.add(new PdfReader(
						IMCSSystemConstant.RELATIVE_IMAGES_FILE_PATH
								+ mainTtlPg
								+ IMCSSystemConstant.PDF_FILE_EXTENSION_PATH));
				pdfs.add(new PdfReader(
						IMCSSystemConstant.RELATIVE_IMAGES_FILE_PATH + preAmble
								+ IMCSSystemConstant.PDF_FILE_EXTENSION_PATH));
				pdfs.add(new PdfReader(
						IMCSSystemConstant.RELATIVE_IMAGES_FILE_PATH + ttlPg
								+ IMCSSystemConstant.PDF_FILE_EXTENSION_PATH));
				
				int staticPageSize = 0;
				staticPageSize = (new PdfReader(IMCSSystemConstant.RELATIVE_IMAGES_FILE_PATH + preAmble
						+ IMCSSystemConstant.PDF_FILE_EXTENSION_PATH)).getNumberOfPages();
				LOGGER.debug("staticPageSize = " + staticPageSize);
				
				pdfData = iDao.getSparePartDetails(imcsSpClBean
						.getEngineName());
				imcsPDFCreator = new IMCSPDFCreator();
				imcsPDFCreator.createSpClPDF(pdfData, imcsSpClBean, pdfs, staticPageSize);
			}
			LOGGER.debug("pdfData " + pdfData.size());
		} catch (FileNotFoundException e) {
			LOGGER.error(" Error :: " + e.getMessage());
		} catch (Exception e) {
			LOGGER.error(" Error :: " + e.getMessage());
		}
	}

	/**
	 * The method to concate Pdfs
	 * 
	 * @param streamOfPDFFiles
	 * @param outputStream
	 * @param paginate
	 */
	public static void concatPDFs(ArrayList streamOfPDFFiles,
			OutputStream outputStream, boolean paginate) {
		Document document = new Document();
		document.setMargins(0, 0, -20, -20);

		try {
			ArrayList pdfs = streamOfPDFFiles;
			ArrayList readers = new ArrayList();
			int totalPages = 0;
			Iterator iteratorPDFs = pdfs.iterator();
			// Create Readers for the pdfs.
			while (iteratorPDFs.hasNext()) {
				InputStream pdf = (InputStream) iteratorPDFs.next();
				PdfReader pdfReader = new PdfReader(pdf);
				readers.add(pdfReader);
				totalPages += pdfReader.getNumberOfPages();
			}
			// Create a writer for the outputstream
			PdfWriter writer = PdfWriter.getInstance(document, outputStream);
			document.open();
			BaseFont bf = BaseFont.createFont(BaseFont.HELVETICA,
					BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
			PdfContentByte cb = writer.getDirectContent();
			// Holds the PDF
			// data
			PdfImportedPage page;
			int currentPageNumber = 0;
			int pageOfCurrentReaderPDF = 0;
			Iterator iteratorPDFReader = readers.iterator();
			// Loop through the PDF files and add to the output.
			while (iteratorPDFReader.hasNext()) {
				PdfReader pdfReader = (PdfReader) iteratorPDFReader.next();
				// Create a new page in the target for each source page.
				while (pageOfCurrentReaderPDF < pdfReader.getNumberOfPages()) {
					document.newPage();
					pageOfCurrentReaderPDF++;
					currentPageNumber++;
					page = writer.getImportedPage(pdfReader,
							pageOfCurrentReaderPDF);
					cb.addTemplate(page, 0, 0);
					// Code for pagination.
					if (paginate) {
						cb.beginText();
						cb.setFontAndSize(bf, 9);
						cb.showTextAligned(PdfContentByte.ALIGN_CENTER, ""
								+ currentPageNumber + " of " + totalPages, 520,
								5, 0);
						cb.endText();
					}
				}
				pageOfCurrentReaderPDF = 0;
			}

			outputStream.flush();
			document.close();
			outputStream.close();
		} catch (IOException e) {
			LOGGER.error(" IO Error :: " + e.getMessage());
		} catch (DocumentException e) {
			LOGGER.error(" Document Error :: " + e.getMessage());
		} catch (Exception e) {
			LOGGER.error(" Error :: " + e.getMessage());
		} finally {
			if (document.isOpen())
				document.close();
			try {
				if (outputStream != null)
					outputStream.close();
			} catch (IOException ioe) {
				LOGGER.error(" Error :: " + ioe.getMessage());
			}
		}
	}

}
