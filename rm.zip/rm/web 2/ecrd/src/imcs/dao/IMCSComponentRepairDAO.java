// Copyright (C) 2000 General Electric Company 
// All rights reserved

package imcs.dao;

import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import oracle.jdbc.driver.OracleCallableStatement;
import oracle.jdbc.driver.OracleTypes;

import org.apache.log4j.Logger;

import ecrd.common.eCRDDBMediator;
import geae.dao.GEAEResultSet;

import imcs.bean.IMCSComponentRepairBean;

/**
 * @author 226855
 * 
 */
public class IMCSComponentRepairDAO {

	/** Instance of the LOGGER class for logging debug and error messages. */
	private static final Logger LOGGER = Logger
			.getLogger("IMCSSparePartsDAO.class");

	/**
	 * This method is used to fetch Component Repair Details from Database.
	 * 
	 * @param engineMdlId
	 * @param arrlstInParam
	 * @return
	 * @throws SQLException 
	 * @throws SQLException
	 * @throws Exception
	 */
	public ArrayList getCompRepairDetails(String engineMdlId,ArrayList arrlstInParam) throws Exception{
		ArrayList arrLstResult = new ArrayList();
		ArrayList arrLstParentResult = new ArrayList();
		ArrayList arrLstParentCols = new ArrayList();
		ArrayList arrLstChildResult = new ArrayList();
		ArrayList arrLstChildCols = new ArrayList();
		ArrayList arrLstParentComp = new ArrayList();
		ArrayList arrLstChildComp = new ArrayList();
		CallableStatement cstmt = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ResultSet rset1 = null;
		ResultSet rset2 = null;
		String year = null;
		String strQueryString = "";
		Connection conn = null;
		int catalogSeqId = 0;
		String effDate = null;
		IMCSComponentRepairBean imcsParentBean = null;
		IMCSComponentRepairBean imcsChildBean = null;

		try {
			IMCSConnectionManager con = new IMCSConnectionManager();
			conn = con.getCROracleJDBCConnection();

			String query = "select max(catalog_seq_id) "
					+ "from crd_e_catalog c " + "where c.eng_mdl_number = ? "
					+ "and c.catalog_type = 'D' "
					+ "order by c.catalog_seq_id desc";
			pstmt = conn.prepareStatement(query);
			LOGGER.debug("@@@@@@@@@@@@ procedure called " + query);
			pstmt.setString(1, engineMdlId);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				catalogSeqId = rs.getInt(1);
			}
			LOGGER.debug("catalogSeqId = " + catalogSeqId);
			Calendar cal = Calendar.getInstance();
			Date dt = cal.getTime();
			SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy");
			LOGGER.debug("dt 1 = " + df.format(dt));
			cal.add(Calendar.MONTH, 6);
			dt = cal.getTime();
			LOGGER.debug("dt 2 = " + df.format(dt));
			effDate = df.format(dt);
			LOGGER.debug("Calling Procedure...." + catalogSeqId + " " + effDate);
			strQueryString = "{call crd.ecrd_reports_pkg.ecrd_catalog_gen_dtls_prc(?, ?, ?, ?, ?)}";
			cstmt = conn.prepareCall(strQueryString,
					ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_UPDATABLE);
			cstmt.setInt(1, catalogSeqId);
			cstmt.setString(2, effDate);
			cstmt.registerOutParameter(3, OracleTypes.CURSOR);
			cstmt.registerOutParameter(4, OracleTypes.CURSOR);
			cstmt.registerOutParameter(5, OracleTypes.VARCHAR);
			cstmt.execute();
			rset1 = ((OracleCallableStatement) cstmt).getCursor(3);
			rset2 = ((OracleCallableStatement) cstmt).getCursor(4);
			year = (String) cstmt.getString(5);

			ResultSetMetaData rsmdParent = null;
			rsmdParent = rset1.getMetaData();
			if (rsmdParent != null) {
				for (int i = 1; i <= rsmdParent.getColumnCount(); i++) {
					if ("Component Code".equalsIgnoreCase(rsmdParent
							.getColumnName(i))) {
						arrLstParentCols.add("Comp\nCode");
					} else {
						arrLstParentCols.add(rsmdParent.getColumnName(i));
					}
				}
			}
			ResultSetMetaData rsmdChild = null;
			rsmdChild = rset2.getMetaData();
			if (rsmdChild != null) {
				for (int j = 1; j <= rsmdChild.getColumnCount(); j++) {
					if ("Component Code".equalsIgnoreCase(rsmdChild
							.getColumnName(j))) {
						arrLstChildCols.add("Comp\nCode");
					} else {
						arrLstChildCols.add(rsmdChild.getColumnName(j));
					}
				}
			}
			while (rset1.next()) {
				imcsParentBean = new IMCSComponentRepairBean();
				imcsParentBean.setModuleName(rset1.getString("MODULE_NAME"));
				imcsParentBean.setCompCode(rset1.getString("Component Code"));
				imcsParentBean.setCompParts(rset1.getString("Component/Parts"));
				imcsParentBean.setRepairSites(rset1.getString("Repair Sites"));
				imcsParentBean.setAtaRepairNumber(rset1.getString("ATA/Repair Number"));
				imcsParentBean.setRepairDescription(rset1.getString("Repair Description"));
				imcsParentBean.setTatDays(rset1.getString("TAT Days"));
				imcsParentBean.setPrice(rset1.getString("Price"));
				imcsParentBean.setPartNumber(rset1.getString("Part Number"));
				imcsParentBean.setRepairDisplayId(rset1.getString("Repair display Id"));
				imcsParentBean.setRepairType(rset1.getString("Repair Type"));
				imcsParentBean.setParentRepairId(rset1.getString("Parent Repair Id"));
				imcsParentBean.setRepairComments(rset1.getString("Repair Comments"));
				imcsParentBean.setRepairId(rset1.getString("Repair Id"));
				imcsParentBean.setCompLvlBaselineTAT(rset1.getString("Component Level Baseline TAT"));
				
				/**beginning changes by rishabh mewar **/

				imcsParentBean.setInspectionTat(rset1.getString("Inspection TAT"));
				imcsParentBean.setAverageTat(rset1.getString("Average TAT"));
				imcsParentBean.setNteTat(rset1.getString("Nte TAT"));
			
			/**end of changes by rishabh mewar **/
				
				
				arrLstParentResult.add(imcsParentBean);
				arrLstParentComp.add(rset1.getString("Component Code"));
			}
			while (rset2.next()) {
				imcsChildBean = new IMCSComponentRepairBean();
				imcsChildBean.setModuleName(rset2.getString("Module_Name"));
				imcsChildBean.setCompCode(rset2.getString("Component Code"));
				imcsChildBean.setCompParts(rset2.getString("Component/Parts"));
				imcsChildBean.setRepairSites(rset2.getString("Repair Sites"));
				imcsChildBean.setAtaRepairNumber(rset2.getString("ATA/Repair Number"));
				imcsChildBean.setRepairDescription(rset2.getString("Repair Description"));
				imcsChildBean.setTatDays(rset2.getString("TAT Days"));
				imcsChildBean.setPrice(rset2.getString("Price"));
				imcsChildBean.setPartNumber(rset2.getString("Part Number"));
				imcsChildBean.setRepairDisplayId(rset2.getString("Repair display Id"));
				imcsChildBean.setRepairType(rset2.getString("Repair Type"));
				imcsChildBean.setParentRepairId(rset2.getString("Parent Repair Id"));
				imcsChildBean.setRepairComments(rset2.getString("Repair Comments"));
				imcsChildBean.setRepairId(rset2.getString("Repair Id"));
				imcsChildBean.setCompLvlBaselineTAT(rset2.getString("Component Level Baseline TAT"));
				
				/**beginning changes by rishabh mewar **/

				imcsChildBean.setInspectionTat(rset2.getString("Inspection TAT"));
				imcsChildBean.setAverageTat(rset2.getString("Average TAT"));
				imcsChildBean.setNteTat(rset2.getString("Nte TAT"));
			
			/**end of changes by rishabh mewar **/
				
				arrLstChildResult.add(imcsChildBean);
				arrLstChildComp.add(rset2.getString("Component Code"));
			}
			arrLstResult.add(arrLstParentResult);
			arrLstResult.add(arrLstParentCols);
			arrLstResult.add(arrLstChildResult);
			arrLstResult.add(arrLstChildCols);
			arrLstResult.add(year);
			LOGGER.debug("year = " + year);
		
		} catch (SQLException e) {
			LOGGER.error(" SQL Error :: " + e.getMessage());
		}catch (IOException e) {
			LOGGER.error(" IO Error :: " + e.getMessage());
		}finally {
			if(conn != null)
				conn.close();
			if(rs != null)
				rs.close();
			if(pstmt != null)
				pstmt.close();
			if(rset1 != null)
				rset1.close();
			if(cstmt != null)
				cstmt.close();
			if(rset2 != null)
				rset2.close();
			
			IMCSConnectionManager.closeSQL(conn);
			IMCSConnectionManager.closeSQL(rs);
			IMCSConnectionManager.closeSQL(pstmt);
			IMCSConnectionManager.closeSQL(rset1);
			IMCSConnectionManager.closeSQL(cstmt);
			IMCSConnectionManager.closeSQL(rset2);
		}
		return arrLstResult;
	}

	/**
	 * This method is used to fetch Component Repair Details from Database.
	 * 
	 * @param engineMdlId
	 * @param arrlstInParam
	 * @return
	 * @throws SQLException 
	 * @throws SQLException
	 * @throws Exception
	 */
	public ArrayList getCompRepairDetailsWeb(String strActionId, ArrayList arrlstInParam) throws Exception{
		ArrayList arrLstResult = new ArrayList();
		ArrayList arrLstParentResult = new ArrayList();
		ArrayList arrLstParentCols = new ArrayList();
		ArrayList arrLstChildResult = new ArrayList();
		ArrayList arrLstChildCols = new ArrayList();
		ArrayList arrLstParentComp = new ArrayList();
		ArrayList arrLstChildComp = new ArrayList();
		
		GEAEResultSet rset1 = null;
		GEAEResultSet rset2 = null;
		String year = null;
		
		ArrayList arrlstOutParam = null;
		ArrayList arrlstFinal1 = new ArrayList();
		ArrayList arrlstFinal2 = new ArrayList();
		
		IMCSComponentRepairBean imcsParentBean = null;
		IMCSComponentRepairBean imcsChildBean = null;

		String strPrevModule = "";
		String strCurrModule = "";			
		try {
			
			arrlstOutParam = eCRDDBMediator.doDBOperation(strActionId, arrlstInParam);
			rset1 = (GEAEResultSet) arrlstOutParam.get(0);
			rset2 = (GEAEResultSet) arrlstOutParam.get(1);
			year = (String)arrlstOutParam.get(2);
			
			ResultSetMetaData rsmdParent = null;
			rsmdParent = rset1.getMetaData();
			if (rsmdParent != null) {
				for (int i = 1; i <= rsmdParent.getColumnCount(); i++) {
					if ("Component Code".equalsIgnoreCase(rsmdParent
							.getColumnName(i))) {
						arrLstParentCols.add("Comp\nCode");
					} else {
						arrLstParentCols.add(rsmdParent.getColumnName(i));
					}
				}
			}
			ResultSetMetaData rsmdChild = null;
			rsmdChild = rset2.getMetaData();
			if (rsmdChild != null) {
				for (int j = 1; j <= rsmdChild.getColumnCount(); j++) {
					if ("Component Code".equalsIgnoreCase(rsmdChild
							.getColumnName(j))) {
						arrLstChildCols.add("Comp\nCode");
					} else {
						arrLstChildCols.add(rsmdChild.getColumnName(j));
					}
				}
			}
			while (rset1.next()) {
				strPrevModule = rset1.getString(1);
								
				imcsParentBean = new IMCSComponentRepairBean();
				imcsParentBean.setModuleName(rset1.getString(1));
				imcsParentBean.setCompCode(rset1.getString(2));
				imcsParentBean.setCompParts(rset1.getString(3));
				imcsParentBean.setRepairSites(rset1.getString(4));
				imcsParentBean.setAtaRepairNumber(rset1.getString(5));
				imcsParentBean.setRepairDescription(rset1.getString(6));
				imcsParentBean.setTatDays(rset1.getString(7));
				imcsParentBean.setPrice(rset1.getString(8));
				imcsParentBean.setPartNumber(rset1.getString(9));
				imcsParentBean.setRepairDisplayId(rset1.getString(10));
				imcsParentBean.setRepairType(rset1.getString(11));
				imcsParentBean.setParentRepairId(rset1.getString(12));
				imcsParentBean.setRepairComments(rset1.getString(13));
				imcsParentBean.setRepairId(rset1.getString(14));
				imcsParentBean.setCompLvlBaselineTAT(rset1.getString(15));
				
				imcsParentBean.setDisplaySeqId(rset1.getString(16));
				
				
				/**beginning changes by rishabh mewar **/

				imcsParentBean.setInspectionTat(rset1.getString(17));
				imcsParentBean.setAverageTat(rset1.getString(18));
				imcsParentBean.setNteTat(rset1.getString(19));
				
			/**end of changes by rishabh mewar **/
				
				
		//		System.out.println("strCurrModule = " + strCurrModule);
		//		System.out.println("strPrevModule = " + strPrevModule);
				if(strCurrModule.equalsIgnoreCase(strPrevModule))
				{
					arrLstParentResult.add(imcsParentBean);
				}else{
			//		System.out.println("arrLstParentResult size = " + arrLstParentResult.size());
					if(arrLstParentResult.size() != 0){
						arrlstFinal1.add(arrLstParentResult);
						arrLstParentResult = new ArrayList();
						arrLstParentResult.add(imcsParentBean);
					}else{
						arrLstParentResult.add(imcsParentBean);
					}
				}
			//	arrlstFinal1.add(arrLstParentResult);
				arrLstParentComp.add(rset1.getString(2));
				
				strCurrModule = strPrevModule;
			}
			
			if(arrLstParentResult.size() > 0){
				arrlstFinal1.add(arrLstParentResult);
			}
			System.out.println("arrlstFinal1 size == " + arrlstFinal1.size());
		//	compareModuleOrder(arrlstFinal);
			
			Collections.sort(arrlstFinal1,new IMCSModuleNameComparator());
			
			for(int i = 0; i < arrlstFinal1.size(); i++)
			{
				ArrayList arrLst3 = (ArrayList)arrlstFinal1.get(i);
				IMCSComponentRepairBean compBean = (IMCSComponentRepairBean)arrLst3.get(0);
				String strModName = compBean.getModuleName();
				System.out.println("strModuleName1 = " + i + " = " + strModName);
				System.out.println("arrLst3 size = " + i + " = " + arrLst3.size());
			}
			
			strCurrModule = "";
			strPrevModule = "";
			
			while (rset2.next()) {
				strPrevModule = rset2.getString(1);
				imcsChildBean = new IMCSComponentRepairBean();
				imcsChildBean.setModuleName(rset2.getString(1));
				imcsChildBean.setCompCode(rset2.getString(2));
				imcsChildBean.setCompParts(rset2.getString(3));
				imcsChildBean.setRepairSites(rset2.getString(4));
				imcsChildBean.setAtaRepairNumber(rset2.getString(5));
				imcsChildBean.setRepairDescription(rset2.getString(6));
				imcsChildBean.setTatDays(rset2.getString(7));
				imcsChildBean.setPrice(rset2.getString(8));
				imcsChildBean.setPartNumber(rset2.getString(9));
				imcsChildBean.setRepairDisplayId(rset2.getString(10));
				imcsChildBean.setRepairType(rset2.getString(11));
				imcsChildBean.setParentRepairId(rset2.getString(12));
				imcsChildBean.setRepairComments(rset2.getString(13));
				imcsChildBean.setRepairId(rset2.getString(14));
				imcsChildBean.setCompLvlBaselineTAT(rset2.getString(15));
				
				
				imcsChildBean.setDisplaySeqId(rset2.getString(16));
				
				/**beginning changes by rishabh mewar **/

				imcsChildBean.setInspectionTat(rset2.getString(17));
				imcsChildBean.setAverageTat(rset2.getString(18));
				imcsChildBean.setNteTat(rset2.getString(19));
				
			/**end changes by rishabh mewar **/
				
				if(strCurrModule.equalsIgnoreCase(strPrevModule))
				{
					arrLstChildResult.add(imcsChildBean);
				}else{
		//			System.out.println("arrLstChildResult size = " + arrLstChildResult.size());
					if(arrLstChildResult.size() != 0){
						arrlstFinal2.add(arrLstChildResult);
						arrLstChildResult = new ArrayList();
						arrLstChildResult.add(imcsChildBean);
					}else{
						arrLstChildResult.add(imcsChildBean);
					}
				}
		//		arrLstChildResult.add(imcsChildBean);
				arrLstChildComp.add(rset2.getString(2));
				
				strCurrModule = strPrevModule;
			}
			if(arrLstChildResult.size() > 0){
				arrlstFinal2.add(arrLstChildResult);
			}
			System.out.println("arrlstFinal2 size == " + arrlstFinal2.size());
			//	compareModuleOrder(arrlstFinal);
				
				Collections.sort(arrlstFinal2,new IMCSModuleNameComparator());
				
				for(int i = 0; i < arrlstFinal2.size(); i++)
				{
					ArrayList arrLst3 = (ArrayList)arrlstFinal2.get(i);
					IMCSComponentRepairBean compBean = (IMCSComponentRepairBean)arrLst3.get(0);
					String strModName = compBean.getModuleName();
					System.out.println("strModuleName2 = " + i + " = " + strModName);
				}
			
			arrLstResult.add(arrlstFinal1);
			arrLstResult.add(arrLstParentCols);
			arrLstResult.add(arrlstFinal2);
			arrLstResult.add(arrLstChildCols);
			arrLstResult.add(year);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}catch (IOException e) {
			e.printStackTrace();
		}finally {
	
		}
		return arrLstResult;
	}
	

	public static String toString(HashMap hsMap) {
		StringBuffer strBuf = new StringBuffer();
		LOGGER.debug("TOSTRING ");
		Set arrSet = hsMap.keySet();
		Iterator itr = arrSet.iterator();
		while (itr.hasNext()) {
			strBuf.append(((Integer) itr.next()).toString());
		}
		String keyVals = strBuf.toString();
		LOGGER.debug("keyVals = " + keyVals);

		strBuf = new StringBuffer();

		Collection arrLst = hsMap.values();
		Iterator itr1 = arrLst.iterator();
		while (itr1.hasNext()) {
			strBuf.append(((Integer) itr1.next()).toString());
		}
		String mapVals = strBuf.toString();
		LOGGER.debug("mapVals = " + mapVals);

		return keyVals + "\n" + mapVals;
	}
	
	public void compareModuleOrder(ArrayList finalModuleLst)
	{
		ArrayList[] tempLst = new ArrayList[finalModuleLst.size()];
		String[] moduleNames = new String[finalModuleLst.size()];
	
		IMCSComponentRepairBean compBean = null;
		System.out.println("finalModuleLst.size() === " + finalModuleLst.size());
	/*	for(int i = 0; i < finalModuleLst.size(); i++)
		{
			ArrayList arrLst1 = (ArrayList)finalModuleLst.get(i);
			tempLst.add(i,arrLst1);
		}
	*/
		for(int i = 0; i < finalModuleLst.size(); i++)
		{
			ArrayList arrLst2 = (ArrayList)finalModuleLst.get(i);
			System.out.println("arrLst === " + arrLst2.size());
			compBean = (IMCSComponentRepairBean)arrLst2.get(0);
			moduleNames[i] = compBean.getModuleName();
			
		}
		
		for(int i = 0; i < finalModuleLst.size(); i++)
		{
			ArrayList arrLst2 = (ArrayList)finalModuleLst.get(i);
			System.out.println("arrLst2 = " + arrLst2.size());
			compBean = (IMCSComponentRepairBean)arrLst2.get(0);
			String strModName = compBean.getModuleName();
			System.out.println("strModName " + i + " = " + strModName);
			if(strModName.equalsIgnoreCase("Fan"))
			{
			//	tempLst.add(0,arrLst2);
				tempLst[0] = arrLst2;
			}else if(strModName.equalsIgnoreCase("Booster"))
			{
			//	tempLst.add(1,arrLst2);
				if(getModuleMatch("Fan",moduleNames))
					tempLst[1] = arrLst2;
				else
					tempLst[0] = arrLst2;
			}else if(strModName.equalsIgnoreCase("Compressor"))
			{
				if(getModuleMatch("Fan",moduleNames)){
					if(getModuleMatch("Booster",moduleNames)){
						tempLst[2] = arrLst2;
					}else{
						tempLst[1] = arrLst2;
					}
				}else{
					tempLst[0] = arrLst2;
				}
			}else if(strModName.equalsIgnoreCase("Combustor"))
			{
				if(getModuleMatch("Fan",moduleNames)){
					if(getModuleMatch("Booster",moduleNames)){
						if(getModuleMatch("Compressor",moduleNames)){
							tempLst[3] = arrLst2;
						}else{
							tempLst[2] = arrLst2;
						}
					}else if(getModuleMatch("Compressor",moduleNames)){
						tempLst[2] = arrLst2;
					}else {
						tempLst[1] = arrLst2;
					}
				}else{
					tempLst[0] = arrLst2;
				}
			}else if(strModName.equalsIgnoreCase("Combustor, CRF"))
			{
				if(getModuleMatch("Fan",moduleNames)){
					if(getModuleMatch("Booster",moduleNames)){
						if(getModuleMatch("Compressor",moduleNames)){
							if(getModuleMatch("Combustor",moduleNames)){
								tempLst[4] = arrLst2;
							}else{
								tempLst[3] = arrLst2;
							}
						}else if(getModuleMatch("Combustor",moduleNames)){
							tempLst[3] = arrLst2;
						}
					}else if(getModuleMatch("Compressor",moduleNames)){
								if(getModuleMatch("Combustor",moduleNames)){
									tempLst[3] = arrLst2;
								}else{
									tempLst[2] = arrLst2;
								}
					}else if(getModuleMatch("Combustor",moduleNames)){
							tempLst[2] = arrLst2;
					}
				}else{
					if(getModuleMatch("Booster",moduleNames)){
						if(getModuleMatch("Compressor",moduleNames)){
							if(getModuleMatch("Combustor",moduleNames)){
								tempLst[3] = arrLst2;
							}else{
								tempLst[2] = arrLst2;
							}
						}else if(getModuleMatch("Combustor",moduleNames)){
							tempLst[2] = arrLst2;
						}
					}else if(getModuleMatch("Compressor",moduleNames)){
							if(getModuleMatch("Combustor",moduleNames)){
								tempLst[2] = arrLst2;
							}else{
								tempLst[1] = arrLst2;
							}
					}else if(getModuleMatch("Combustor",moduleNames)){
						tempLst[1] = arrLst2;
					}
				}
			}else if(strModName.equalsIgnoreCase("HPT"))
			{
				tempLst[5] = arrLst2;	
			}else if(strModName.equalsIgnoreCase("Turbine Mid Frame"))
			{
				tempLst[6] = arrLst2;	
			}else if(strModName.equalsIgnoreCase("Turbine Center Frame"))
			{
				tempLst[7] = arrLst2;	
			}else if(strModName.equalsIgnoreCase("LPT"))
			{
				tempLst[8] = arrLst2;	
			}else if(strModName.equalsIgnoreCase("Other"))
			{
				tempLst[9] = arrLst2;	
			}else if(strModName.equalsIgnoreCase("Miscellaneous"))
			{
				tempLst[10] = arrLst2;	
			}
	    }
		
		for(int i = 0; i < tempLst.length; i++)
		{
			ArrayList arrLst3 = (ArrayList)tempLst[i];
			compBean = (IMCSComponentRepairBean)arrLst3.get(0);
			String strModName = compBean.getModuleName();
			System.out.println("strModuleName = " + i + " = " + strModName);
		}
	}
	
	private boolean getModuleMatch(String moduleName, String[] moduleList){
		boolean flag = false;
		for(int j = 0; j < moduleList.length; j++){
			if(moduleName.equalsIgnoreCase(moduleList[j])){
				flag = true;
				break;
			}
		}
		return flag;
	}
}
