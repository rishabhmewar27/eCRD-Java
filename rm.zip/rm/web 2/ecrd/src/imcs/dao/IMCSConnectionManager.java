// Copyright (C) 2000 General Electric Company 
// All rights reserved

package imcs.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import imcs.utilities.IMCSBatchProperties;

public class IMCSConnectionManager {
	
	private Connection dbConnection;
	/**Instance of the logger class for logging debug and error messages. */
	private static Logger logger = Logger.getLogger("IMCSConnectionManager.class");
	
	private String dsIDSparePartURL;
	private String dsSPUserName;
	private String dsSPPassword;
	private String dsIDCRPartURL;
	private String dsCRUserName;
	private String dsCRPassword;
	
	public IMCSConnectionManager() throws IOException{
		Properties appProps = new Properties();
		FileInputStream in = null;
		try {
			in = new FileInputStream("./properties/IMCSBatchProperties.properties");
			PropertyConfigurator.configure("properties/BatchLog4j.properties");
			appProps.load(in);
			in.close();
		} catch (FileNotFoundException e) {			
			logger.debug("Properties file not found. Terminating application.");
			logger.error("Fatal error occurred:",e);
		} catch (IOException e) {			
			logger.debug("IO exception occured. Cannot read from properties file. Terminating application.");
			logger.error("Fatal error occured:",e);
		} finally{
			if(in != null)
				in.close();
		}
		IMCSBatchProperties imcsBatchProperties = IMCSBatchProperties.getInstance();
		imcsBatchProperties.setImcsBatchProperties(appProps);
		dsIDSparePartURL = (String) imcsBatchProperties.getImcsProperty (IMCSBatchProperties.DB_SP_URL);
		dsSPUserName = (String) imcsBatchProperties.getImcsProperty (IMCSBatchProperties.DB_SP_USERID);
		dsSPPassword = (String) imcsBatchProperties.getImcsProperty (IMCSBatchProperties.DB_SP_PWD);
		dsIDCRPartURL = (String) imcsBatchProperties.getImcsProperty (IMCSBatchProperties.DB_CR_URL);
		dsCRUserName = (String) imcsBatchProperties.getImcsProperty (IMCSBatchProperties.DB_CR_USERID);
		dsCRPassword = (String) imcsBatchProperties.getImcsProperty (IMCSBatchProperties.DB_CR_PWD);
	}
	
	/**
	 * The Java file is connected to the Oracle dataBase
	 * @return The dataBase connection is returned
	 */
	public Connection getSPOracleJDBCConnection(){
		try { 
			Class.forName("oracle.jdbc.driver.OracleDriver"); //Or any other driver
			
			dbConnection = DriverManager.getConnection(dsIDSparePartURL,
					dsSPUserName, dsSPPassword);
		}catch(java.lang.ClassNotFoundException e) {
			logger.error("ClassNotFoundException: ");
			logger.error(e.getMessage());
		}catch(SQLException ex) {
			logger.error("SQLException: " + ex.getMessage());
		}catch(Exception x){ 
			logger.debug( "Unable to load the driver class!" );
			logger.error(" Error :: " + x.getMessage());
		}
		logger.debug("Connection Established.");
		return dbConnection;
	}
/**
 * The Java file is connected to the Oracle dataBase
 * @return The dataBase connection is returned
 */
	
	public Connection getCROracleJDBCConnection(){
		try { 
			Class.forName("oracle.jdbc.driver.OracleDriver"); //Or any other driver
			logger.debug(dsIDCRPartURL + " " + dsCRUserName + " " + dsCRPassword);
			dbConnection = DriverManager.getConnection(dsIDCRPartURL, dsCRUserName, dsCRPassword);
		}catch(java.lang.ClassNotFoundException e) {
			logger.error("ClassNotFoundException: ");
			logger.error(e.getMessage());
		}catch(SQLException ex) {
			logger.error("SQLException: " + ex.getMessage());
		}catch(Exception x){ 
			logger.debug( "Unable to load the driver class!" );
			logger.error(" Error :: " + x.getMessage());
		}
		logger.debug("Connection Established.");
		return dbConnection;
	}
	
	
	/**
	 * This method will close a java.SQL.Connection. 
	 * 
	 * @param conn  java.SQL.Connection to be closed
	 */
		public static void closeSQL(Connection conn) {
	        try {
	            if (conn != null) {
	                conn.close();
	            }
	        } catch (Exception e) {
	            logger.error("Unable to close jdbc/sql connection: " + e.getMessage(), e);
	        }
	    }

	    /**
	     * This method will close a java.SQL.Statement.
	     * 
		 * @param stmt  SQL Statement to be closed
		 */
		 public static void closeSQL(Statement stmt) {
	        try {
	            if (stmt != null) {
	                stmt.close();
	            }
	        } catch (Exception e) {
	            logger.error("Unable to close sql statement: " + e.getMessage(), e);
	        }
	    }

	    /**
	     * This method will close a java.SQL.ResultSet
	     * 
		 * @param rs  ResultSet to be closed
		 */
		
	    public static void closeSQL(ResultSet rs) {
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (Exception e) {
	            logger.error("Unable to close results: " + e.getMessage(), e);
	        }
	    }

	    /**
	     * This method will close a java.SQL.PreparedStatement.
	     * 
		 * @param pstmt  PreparedStatement to be closed
	     */
		   
	    public static void closeSQL(PreparedStatement pstmt) {
	        try {
	            if (pstmt != null) {
	                pstmt.close();
	            }
	        } catch (Exception e) {
	            logger.error("Unable to close prepared statement: " + e.getMessage(), e);
	        }
	    }
	
	    /**
		 * @return Returns the dbConnection.
		 */
		public Connection getDbConnection() {
			return dbConnection;
		}

		/**
		 * @return Returns the dsCRPassword.
		 */
		public String getDsCRPassword() {
			return dsCRPassword;
		}

		/**
		 * @return Returns the dsCRUserName.
		 */
		public String getDsCRUserName() {
			return dsCRUserName;
		}

		/**
		 * @return Returns the dsIDCRPart_URL.
		 */
		public String getDsIDCRPartURL() {
			return dsIDCRPartURL;
		}

		/**
		 * @return Returns the dsIDSparePartURL.
		 */
		public String getDsIDSparePartURL() {
			return dsIDSparePartURL;
		}

		/**
		 * @return Returns the dsSPPassword.
		 */
		public String getDsSPPassword() {
			return dsSPPassword;
		}

		/**
		 * @return Returns the dsSPUserName.
		 */
		public String getDsSPUserName() {
			return dsSPUserName;
		}

		/**
		 * @param dbConnection The dbConnection to set.
		 */
		public void setDbConnection(Connection dbConnection) {
			this.dbConnection = dbConnection;
		}

		/**
		 * @param dsCRPassword The dsCRPassword to set.
		 */
		public void setDsCRPassword(String dsCRPassword) {
			this.dsCRPassword = dsCRPassword;
		}

		/**
		 * @param dsCRUserName The dsCRUserName to set.
		 */
		public void setDsCRUserName(String dsCRUserName) {
			this.dsCRUserName = dsCRUserName;
		}

		/**
		 * @param dsIDCRPart_URL The dsIDCRPart_URL to set.
		 */
		public void setDsIDCRPartURL(String dsIDCRPartURL) {
			this.dsIDCRPartURL = dsIDCRPartURL;
		}

		/**
		 * @param dsIDSparePartURL The dsIDSparePartURL to set.
		 */
		public void setDsIDSparePartURL(String dsIDSparePartURL) {
			this.dsIDSparePartURL = dsIDSparePartURL;
		}

		/**
		 * @param dsSPPassword The dsSPPassword to set.
		 */
		public void setDsSPPassword(String dsSPPassword) {
			this.dsSPPassword = dsSPPassword;
		}

		/**
		 * @param dsSPUserName The dsSPUserName to set.
		 */
		public void setDsSPUserName(String dsSPUserName) {
			this.dsSPUserName = dsSPUserName;
		}

		public static void main(String[] args) throws Exception {
  /*    IMCSConnectionManager con = new IMCSConnectionManager();
	    Connection conn = con.getSPOracleJDBCConnection();
				
	    if(conn != null){
	       logger.debug("Got Connection.");
	       DatabaseMetaData meta = conn.getMetaData();
	       logger.debug("Driver Name : " + meta.getDriverName());
	       logger.debug("Driver Version : " + meta.getDriverVersion());
	       conn.close();
	    }else{
		    logger.debug("Could not Get Connection");
	    }
	  */  
	}

	

}
