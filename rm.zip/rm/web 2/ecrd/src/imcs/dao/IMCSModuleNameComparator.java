/**
 * 
 */
package imcs.dao;

import imcs.bean.IMCSComponentRepairBean;

import java.util.ArrayList;
import java.util.Comparator;

/**
 * @author 226855
 *
 */
public class IMCSModuleNameComparator implements Comparator{

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public int compare(Object arg0, Object arg1) {

		ArrayList firstModule = (ArrayList) arg0; 
	     
		ArrayList secondModule = (ArrayList) arg1; 
	    
		IMCSComponentRepairBean compBean1 = (IMCSComponentRepairBean)firstModule.get(0);
		String strModName1 = compBean1.getModuleName();
		int moduleNum1 = 0;
	//	System.out.println("strModName1 = " + strModName1);
		
		IMCSComponentRepairBean compBean2 = (IMCSComponentRepairBean)secondModule.get(0);
		String strModName2 = compBean2.getModuleName();
		int moduleNum2 = 0;
	//	System.out.println("strModName2 = " + strModName2);
		
		moduleNum1 = getModuleNumber(strModName1);
		moduleNum2 = getModuleNumber(strModName2); 

	//	System.out.println("moduleNum1 " + moduleNum1);
	//	System.out.println("moduleNum2 " + moduleNum2);
		
		if(moduleNum1 < moduleNum2)
			return 0;
		else
			return 1;

	}
	
	private int getModuleNumber(String moduleName){
		int moduleNum = 0;
		
		if(moduleName.equalsIgnoreCase("Fan")){
			moduleNum = 1;
		}else if(moduleName.equalsIgnoreCase("Booster")){
			moduleNum = 2;
		}else if(moduleName.equalsIgnoreCase("Compressor")){
			moduleNum = 3;
		}else if(moduleName.equalsIgnoreCase("Combustor")){
			moduleNum = 4;
		}else if(moduleName.equalsIgnoreCase("Combustor, CRF")){
			moduleNum = 5;
		}else if(moduleName.equalsIgnoreCase("HPT")){
			moduleNum = 6;
		}else if(moduleName.equalsIgnoreCase("Turbine Mid Frame")){
			moduleNum = 7;
		}else if(moduleName.equalsIgnoreCase("Turbine Center Frame")){
			moduleNum = 8;
		}else if(moduleName.equalsIgnoreCase("LPT")){
			moduleNum = 9;
		}else if(moduleName.equalsIgnoreCase("Other Components")){
			moduleNum = 10;
		}else if(moduleName.equalsIgnoreCase("Miscellaneous")){
			moduleNum = 11;
		}
		
		
		
		return moduleNum;
	}

}
