// Copyright (C) 2000 General Electric Company 
// All rights reserved
/**
 * Module:       IMCSSparePartsDAO.java
 * Author:       Tata Consultancy Services
 * Project:      IMCS
 * Date Written: 08/14/2008
 * Security:     Unclassified
 * Restrictions: GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 *
 *     ****************************************************
 *     *  Copyright (2000) with all rights reserved       *
 *     *          General Electric Company                *
 *     ****************************************************
 *
 * Description:  This class contains methods for PCV Section Screens.
 *
 * Revision Log  (mm/dd/yy initials description)
 * --------------------------------------------------------------
 *
 */
package imcs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import imcs.dao.IMCSConnectionManager;

import imcs.bean.IMCSSparePartsCatalogBean;

/**
 * <p>
 * Title: IMCSSparePartsDAO
 * </p>
 * 
 * <p>
 * Description: This class is used to fetch the data related with Spare Parts
 * Application. This class contains methods which will fetch Spare Part Catalog
 * from the database.
 * </p>
 * 
 * @author
 * 
 */
public class IMCSSparePartsDAO {

	// private String DSID_SPARE_PART = IMCSSystemConstant.DSID_Spare_Part;

	/** Instance of the LOGGER class for logging debug and error messages. */
	private static final Logger LOGGER = Logger.getLogger("IMCSSparePartsDAO.class");

	/**
	 * This method is used to fetch Spare Parts Details from Database.
	 * 
	 * @param catalogId
	 * @return
	 * @throws SQLException
	 * @throws Exception
	 */
	public ArrayList getSparePartDetails(String catalogId)
			throws Exception {

		PreparedStatement pstmt1 = null;
		PreparedStatement pstmt2 = null;
		ResultSet rs1 = null;
		ResultSet rs2 = null;
		Connection conn = null;
		ArrayList engineData = new ArrayList();
		IMCSSparePartsCatalogBean bean = null;
		try {
			IMCSConnectionManager con = new IMCSConnectionManager();
		    conn = con.getSPOracleJDBCConnection();
			
			if ("GE90".equals(catalogId)) {
				String GE90 = "SELECT DISTINCT " 
							 +	"PART_NUMBER, ATA_KEYWORD," 
							 +	"decode(LEAD_TIME, 0, 'QUOTE', LEAD_TIME) AS LEAD_TIME,"
							 +	"decode(UNIT_PACK_QTY, 0, 1, UNIT_PACK_QTY) AS UNIT_PACK_QTY,"
							 +  "decode(PROPOSED_CTLG_PRICE, 0,'QUOTE',PROPOSED_CTLG_PRICE) AS PROPOSED_CTLG_PRICE "
							 +	"FROM "
							 +  "PDW_CATALOG_PRICE_DTLS " 
							 +	"WHERE "
							 +	"AVIALL_FLAG IS NULL AND PLATFORM = ? "
							 +	"and sign(ascii(PART_NUMBER)-58) >= 0 "
							 +	"order by part_number";
				pstmt1 = conn.prepareStatement(GE90);
				LOGGER.debug("@@@@@@@@@@@@ procedure called " + GE90);
				pstmt1.setString(1, catalogId);
				
				rs1 = pstmt1.executeQuery();
				rs1.setFetchSize(200);
				
				String sqlGE90 = "SELECT DISTINCT " 
								 + "PART_NUMBER, ATA_KEYWORD, "
								 + "decode(LEAD_TIME, 0, 'QUOTE', LEAD_TIME) AS LEAD_TIME,"
								 + "decode(UNIT_PACK_QTY, 0, 1, UNIT_PACK_QTY) AS UNIT_PACK_QTY,"
								 + "decode(PROPOSED_CTLG_PRICE, 0,'QUOTE',PROPOSED_CTLG_PRICE) AS PROPOSED_CTLG_PRICE "
								 + "FROM "
								 + "PDW_CATALOG_PRICE_DTLS " 
								 + "WHERE "
								 + "AVIALL_FLAG IS NULL AND PLATFORM = ? "
								 + "and sign(ascii(PART_NUMBER)-58) < 0 " 
								 + "order by PART_NUMBER";
				pstmt2 = conn.prepareStatement(sqlGE90);
				LOGGER.debug("@@@@@@@@@@@@ procedure called " + sqlGE90);
				pstmt2.setString(1, catalogId);
				
				rs2 = pstmt2.executeQuery();
				rs2.setFetchSize(200);
				
			} else if ("CF6_Main".equals(catalogId)) {
				String catalogEng = catalogId.substring(0, 3);

				String cf6 = "SELECT DISTINCT "
						+ " PART_NUMBER, ATA_KEYWORD, "
						+ " decode(LEAD_TIME, 0, 'QUOTE', LEAD_TIME) AS LEAD_TIME,"
						+ " decode(UNIT_PACK_QTY, 0, 1, UNIT_PACK_QTY) AS UNIT_PACK_QTY,"
						+ " decode(PROPOSED_CTLG_PRICE, 0,'QUOTE',PROPOSED_CTLG_PRICE) AS PROPOSED_CTLG_PRICE"
						+ " FROM PDW_CATALOG_PRICE_DTLS "
						+ " WHERE AVIALL_FLAG IS NULL AND PLATFORM = ?  AND TECH_CF6_FLAG is NULL"
						+ " and sign(ascii(PART_NUMBER)-58) >= 0 "
						+ "ORDER BY PART_NUMBER";
				pstmt1 = conn.prepareStatement(cf6);
				LOGGER.debug("@@@@@@@@@@@@ procedure called " + cf6);
				pstmt1.setString(1, catalogEng);
				rs1 = pstmt1.executeQuery();
				rs1.setFetchSize(200);
				
				String sqlcf6 = "SELECT DISTINCT "
					+ " PART_NUMBER, ATA_KEYWORD, "
					+ " decode(LEAD_TIME, 0, 'QUOTE', LEAD_TIME) AS LEAD_TIME,"
					+ " decode(UNIT_PACK_QTY, 0, 1, UNIT_PACK_QTY) AS UNIT_PACK_QTY,"
					+ " decode(PROPOSED_CTLG_PRICE, 0,'QUOTE',PROPOSED_CTLG_PRICE) AS PROPOSED_CTLG_PRICE"
					+ " FROM PDW_CATALOG_PRICE_DTLS "
					+ " WHERE AVIALL_FLAG IS NULL AND PLATFORM = ?  AND TECH_CF6_FLAG is NULL"
					+ " and sign(ascii(PART_NUMBER)-58) < 0 "
					+ "ORDER BY PART_NUMBER";
				pstmt2 = conn.prepareStatement(sqlcf6);
				LOGGER.debug("@@@@@@@@@@@@ procedure called " + sqlcf6);
				pstmt2.setString(1, catalogEng);
				
				rs2 = pstmt2.executeQuery();
				rs2.setFetchSize(200);
			} else if ("CF6_Aviall".equals(catalogId)) {
				String catalogEng = catalogId.substring(0, 3);

				String cf6Aviall = "SELECT DISTINCT "
						+ " PART_NUMBER, ATA_KEYWORD, "
						+ " decode(LEAD_TIME, 0, 'QUOTE', LEAD_TIME) AS LEAD_TIME,"
						+ " decode(UNIT_PACK_QTY, 0, 1, UNIT_PACK_QTY) AS UNIT_PACK_QTY,"
						+ " decode(PROPOSED_CTLG_PRICE, 0,'QUOTE',PROPOSED_CTLG_PRICE) AS PROPOSED_CTLG_PRICE"
						+ " FROM PDW_CATALOG_PRICE_DTLS "
						+ " WHERE  AVIALL_FLAG = 'Y' AND PLATFORM = ?  AND TECH_CF6_FLAG is NULL"
						+ " and sign(ascii(PART_NUMBER)-58) >= 0 "
						+ "ORDER BY PART_NUMBER";
				
				pstmt1 = conn.prepareStatement(cf6Aviall);
				LOGGER.debug("@@@@@@@@@@@@ procedure called " + cf6Aviall);
				pstmt1.setString(1, catalogEng);
				rs1 = pstmt1.executeQuery();
				rs1.setFetchSize(200);
				
				String sqlCf6Aviall = "SELECT DISTINCT "
					+ " PART_NUMBER, ATA_KEYWORD, "
					+ " decode(LEAD_TIME, 0, 'QUOTE', LEAD_TIME) AS LEAD_TIME,"
					+ " decode(UNIT_PACK_QTY, 0, 1, UNIT_PACK_QTY) AS UNIT_PACK_QTY,"
					+ " decode(PROPOSED_CTLG_PRICE, 0,'QUOTE',PROPOSED_CTLG_PRICE) AS PROPOSED_CTLG_PRICE"
					+ " FROM PDW_CATALOG_PRICE_DTLS "
					+ " WHERE  AVIALL_FLAG = 'Y' AND PLATFORM = ?  AND TECH_CF6_FLAG is NULL"
					+ " and sign(ascii(PART_NUMBER)-58) < 0 "
					+ "ORDER BY PART_NUMBER";
				
				pstmt2 = conn.prepareStatement(sqlCf6Aviall);
				LOGGER.debug("@@@@@@@@@@@@ procedure called " + sqlCf6Aviall);
				pstmt2.setString(1, catalogEng);
				
				rs2 = pstmt2.executeQuery();
				rs2.setFetchSize(200);
			} else if ("CF6_Tech".equals(catalogId)) {
				String catalogEng = catalogId.substring(0, 3);
				String cf6Tech = "SELECT DISTINCT "
						+ " PART_NUMBER, ATA_KEYWORD, "
						+ " decode(LEAD_TIME, 0, 'QUOTE', LEAD_TIME) AS LEAD_TIME,"
						+ " decode(UNIT_PACK_QTY, 0, 1, UNIT_PACK_QTY) AS UNIT_PACK_QTY,"
						+ " decode(PROPOSED_CTLG_PRICE, 0,'QUOTE',PROPOSED_CTLG_PRICE) AS PROPOSED_CTLG_PRICE"
						+ " FROM PDW_CATALOG_PRICE_DTLS "
						+ " WHERE AVIALL_FLAG IS NULL AND PLATFORM = ? AND TECH_CF6_FLAG ='Y'"
						+ " and sign(ascii(PART_NUMBER)-58) >= 0 "
						+ "ORDER BY PART_NUMBER";
				pstmt1 = conn.prepareStatement(cf6Tech);
				LOGGER.debug("@@@@@@@@@@@@ procedure called " + cf6Tech);
				pstmt1.setString(1, catalogEng);
				rs1 = pstmt1.executeQuery();
				rs1.setFetchSize(200);
				
				String sqlCf6Tech = "SELECT DISTINCT "
					+ " PART_NUMBER, ATA_KEYWORD, "
					+ " decode(LEAD_TIME, 0, 'QUOTE', LEAD_TIME) AS LEAD_TIME,"
					+ " decode(UNIT_PACK_QTY, 0, 1, UNIT_PACK_QTY) AS UNIT_PACK_QTY,"
					+ " decode(PROPOSED_CTLG_PRICE, 0,'QUOTE',PROPOSED_CTLG_PRICE) AS PROPOSED_CTLG_PRICE"
					+ " FROM PDW_CATALOG_PRICE_DTLS "
					+ " WHERE AVIALL_FLAG IS NULL AND PLATFORM = ? AND TECH_CF6_FLAG ='Y'"
					+ " and sign(ascii(PART_NUMBER)-58) < 0 "
					+ " ORDER BY PART_NUMBER";
				pstmt2 = conn.prepareStatement(sqlCf6Tech);
				LOGGER.debug("@@@@@@@@@@@@ procedure called " + sqlCf6Tech);
				pstmt2.setString(1, catalogEng);
				
				rs2 = pstmt2.executeQuery();
				rs2.setFetchSize(200);
				
			} else if (("CFM56_Inc_Main".equals(catalogId))
					|| ("CFM56_SA_Main".equals(catalogId))) {
				String catalogEng = catalogId.substring(0, 3);
				String CFM56 = "SELECT DISTINCT "
						+ " PART_NUMBER, ATA_KEYWORD, "
						+ " decode(LEAD_TIME, 0, 'QUOTE', LEAD_TIME) AS LEAD_TIME,"
						+ " decode(UNIT_PACK_QTY, 0, 1, UNIT_PACK_QTY) AS UNIT_PACK_QTY,"
						+ " decode(PROPOSED_CTLG_PRICE, 0,'QUOTE',PROPOSED_CTLG_PRICE) AS PROPOSED_CTLG_PRICE"
						+ " FROM "
						+ "PDW_CATALOG_PRICE_DTLS "
						+ "WHERE "
						+ "AVIALL_FLAG IS NULL AND PLATFORM = ? and SNECMA_IND is null"
						+ " and sign(ascii(PART_NUMBER)-58) >= 0 "
						+ " ORDER BY PART_NUMBER";
				pstmt1 = conn.prepareStatement(CFM56);
				LOGGER.debug("@@@@@@@@@@@@ procedure called " + CFM56);
				pstmt1.setString(1, catalogEng);
				rs1 = pstmt1.executeQuery();
				rs1.setFetchSize(200);
				
				String sqlCFM56 = "SELECT DISTINCT "
					+ " PART_NUMBER, ATA_KEYWORD, "
					+ " decode(LEAD_TIME, 0, 'QUOTE', LEAD_TIME) AS LEAD_TIME,"
					+ " decode(UNIT_PACK_QTY, 0, 1, UNIT_PACK_QTY) AS UNIT_PACK_QTY,"
					+ " decode(PROPOSED_CTLG_PRICE, 0,'QUOTE',PROPOSED_CTLG_PRICE) AS PROPOSED_CTLG_PRICE"
					+ " FROM "
					+ "PDW_CATALOG_PRICE_DTLS "
					+ "WHERE "
					+ "AVIALL_FLAG IS NULL AND PLATFORM = ? and SNECMA_IND is null"
					+ " and sign(ascii(PART_NUMBER)-58) < 0 "
					+ "ORDER BY PART_NUMBER";
				pstmt2 = conn.prepareStatement(sqlCFM56);
				LOGGER.debug("@@@@@@@@@@@@ procedure called " + sqlCFM56);
				pstmt2.setString(1, catalogEng);
				
				rs2 = pstmt2.executeQuery();
				rs2.setFetchSize(200);
			} else if (("CFM56_Inc_ThrustRev".equals(catalogId)) || ("CFM56_SA_ThrustRev".equals(catalogId))) {
				String catalogEng = catalogId.substring(0, 3);
				String CFM56 = "SELECT DISTINCT "
						+ " PART_NUMBER, ATA_KEYWORD, "
						+ " decode(LEAD_TIME, 0, 'QUOTE', LEAD_TIME) AS LEAD_TIME,"
						+ " decode(UNIT_PACK_QTY, 0, 1, UNIT_PACK_QTY) AS UNIT_PACK_QTY,"
						+ " decode(PROPOSED_CTLG_PRICE, 0,'QUOTE',PROPOSED_CTLG_PRICE) AS PROPOSED_CTLG_PRICE"
						+ " FROM "
						+ "PDW_CATALOG_PRICE_DTLS "
						+ "WHERE "
						+ "AVIALL_FLAG IS NULL AND PLATFORM = ? and SNECMA_IND ='Y'"
						+ " and sign(ascii(PART_NUMBER)-58) >= 0" 
						+ " ORDER BY PART_NUMBER";
				pstmt1 = conn.prepareStatement(CFM56);
				LOGGER.debug("@@@@@@@@@@@@ procedure called " + CFM56);
				pstmt1.setString(1, catalogEng);
				rs1 = pstmt1.executeQuery();
				rs1.setFetchSize(200);
				
				String sqlCFM56 = "SELECT DISTINCT "
					+ " PART_NUMBER, ATA_KEYWORD, "
					+ " decode(LEAD_TIME, 0, 'QUOTE', LEAD_TIME) AS LEAD_TIME,"
					+ " decode(UNIT_PACK_QTY, 0, 1, UNIT_PACK_QTY) AS UNIT_PACK_QTY,"
					+ " decode(PROPOSED_CTLG_PRICE, 0,'QUOTE',PROPOSED_CTLG_PRICE) AS PROPOSED_CTLG_PRICE"
					+ " FROM "
					+ "PDW_CATALOG_PRICE_DTLS "
					+ "WHERE "
					+ "AVIALL_FLAG IS NULL AND PLATFORM = ? and SNECMA_IND ='Y'"
					+ " and sign(ascii(PART_NUMBER)-58) < 0" 
					+ " ORDER BY PART_NUMBER";
				
				pstmt2 = conn.prepareStatement(sqlCFM56);
				LOGGER.debug("@@@@@@@@@@@@ procedure called " + sqlCFM56);
				pstmt2.setString(1, catalogEng);
				
				rs2 = pstmt2.executeQuery();
				rs2.setFetchSize(200);
			} else if ("CF34_Airline_Main".equalsIgnoreCase(catalogId)) {
				String catalogEng = catalogId.substring(0, 4);
				String CF34 = "SELECT DISTINCT "
						+ " PART_NUMBER, ATA_KEYWORD, "
						+ " decode(LEAD_TIME, 0, 'QUOTE', LEAD_TIME) AS LEAD_TIME,"
						+ " decode(UNIT_PACK_QTY, 0, 1, UNIT_PACK_QTY) AS UNIT_PACK_QTY,"
						+ " decode(PROPOSED_CTLG_PRICE, 0,'QUOTE',PROPOSED_CTLG_PRICE) AS PROPOSED_CTLG_PRICE"
						+ " FROM "
						+ "PDW_CATALOG_PRICE_DTLS "
						+ "WHERE "
						+ "AVIALL_FLAG IS NULL AND PLATFORM = ? "
						+ " and sign(ascii(PART_NUMBER)-58) >= 0"
						+ " ORDER BY PART_NUMBER";

				pstmt1 = conn.prepareStatement(CF34);
				LOGGER.debug("@@@@@@@@@@@@ procedure called " + CF34);
				pstmt1.setString(1, catalogEng);
				rs1 = pstmt1.executeQuery();
				rs1.setFetchSize(200);
				
				String sqlCF34 = "SELECT DISTINCT "
					+ " PART_NUMBER, ATA_KEYWORD, "
					+ " decode(LEAD_TIME, 0, 'QUOTE', LEAD_TIME) AS LEAD_TIME,"
					+ " decode(UNIT_PACK_QTY, 0, 1, UNIT_PACK_QTY) AS UNIT_PACK_QTY,"
					+ " decode(PROPOSED_CTLG_PRICE, 0,'QUOTE',PROPOSED_CTLG_PRICE) AS PROPOSED_CTLG_PRICE"
					+ " FROM "
					+ "PDW_CATALOG_PRICE_DTLS "
					+ "WHERE "
					+ "AVIALL_FLAG IS NULL AND PLATFORM = ? "
					+ " and sign(ascii(PART_NUMBER)-58) < 0"
					+ " ORDER BY PART_NUMBER";
				pstmt2 = conn.prepareStatement(sqlCF34);
				LOGGER.debug("@@@@@@@@@@@@ procedure called " + sqlCF34);
				pstmt2.setString(1, catalogEng);
				
				rs2 = pstmt2.executeQuery();
				rs2.setFetchSize(200);
			}else if ("CF34_General_Aviation_Main".equalsIgnoreCase(catalogId)) {
				String catalogEng = catalogId.substring(0, 4);
				String CF34GA = "SELECT DISTINCT " 
						+ " PART_NUMBER, ATA_KEYWORD, "
                		+ " decode(LEAD_TIME, 0, 'QUOTE', LEAD_TIME) AS LEAD_TIME,"
                		+ " decode(UNIT_PACK_QTY, 0, 1, UNIT_PACK_QTY) AS UNIT_PACK_QTY,"
                		+ " decode(PROPOSED_CTLG_PRICE, 0, 'QUOTE', round(PROPOSED_CTLG_PRICE/0.6,2)) AS PROPOSED_CTLG_PRICE"
                		+ " FROM PDW_CATALOG_PRICE_DTLS"
                		+ " WHERE AVIALL_FLAG IS NULL"
                		+ " AND PLATFORM = ? "
                		+ " and sign(ascii(PART_NUMBER) - 58) >= 0"
                		+ " ORDER BY PART_NUMBER";

				pstmt1 = conn.prepareStatement(CF34GA);
				LOGGER.debug("@@@@@@@@@@@@ procedure called " + CF34GA);
				pstmt1.setString(1, catalogEng);
				rs1 = pstmt1.executeQuery();
				rs1.setFetchSize(200);
				
				String sqlCF34GA = "SELECT DISTINCT " 
						   + "PART_NUMBER,ATA_KEYWORD,"
						   + "decode(LEAD_TIME, 0, 'QUOTE', LEAD_TIME) AS LEAD_TIME,"
						   + "decode(UNIT_PACK_QTY, 0, 1, UNIT_PACK_QTY) AS UNIT_PACK_QTY,"
						   + "decode(PROPOSED_CTLG_PRICE, 0, 'QUOTE', round(PROPOSED_CTLG_PRICE/0.6,2)) AS PROPOSED_CTLG_PRICE "
						   + "FROM PDW_CATALOG_PRICE_DTLS "
						   + "WHERE AVIALL_FLAG IS NULL "
						   + "AND PLATFORM = ? and sign(ascii(PART_NUMBER) - 58) < 0 "
						   + " ORDER BY PART_NUMBER ";
				pstmt2 = conn.prepareStatement(sqlCF34GA);
				LOGGER.debug("@@@@@@@@@@@@ procedure called " + sqlCF34GA);
				pstmt2.setString(1, catalogEng);
				
				rs2 = pstmt2.executeQuery();
				rs2.setFetchSize(200);
			}else if ("CF34_General_Aviation_Aviall".equalsIgnoreCase(catalogId)) {
				String catalogEng = catalogId.substring(0, 4);
				String CF34 = "SELECT DISTINCT "
						+ " PART_NUMBER, ATA_KEYWORD, "
						+ " decode(LEAD_TIME, 0, 'QUOTE', LEAD_TIME) AS LEAD_TIME,"
						+ " decode(UNIT_PACK_QTY, 0, 1, UNIT_PACK_QTY) AS UNIT_PACK_QTY,"
						+ " decode(PROPOSED_CTLG_PRICE, 0,'QUOTE',PROPOSED_CTLG_PRICE) AS PROPOSED_CTLG_PRICE"
						+ " FROM "
						+ "PDW_CATALOG_PRICE_DTLS "
						+ "WHERE "
						+ "AVIALL_FLAG = 'Y' AND PLATFORM = ? "
						+ " and sign(ascii(PART_NUMBER)-58) >= 0"
						+ " ORDER BY PART_NUMBER";

				pstmt1 = conn.prepareStatement(CF34);
				LOGGER.debug("@@@@@@@@@@@@ procedure called " + CF34);
				pstmt1.setString(1, catalogEng);
				rs1 = pstmt1.executeQuery();
				rs1.setFetchSize(200);
				
				String sqlCF34 = "SELECT DISTINCT "
					+ " PART_NUMBER, ATA_KEYWORD, "
					+ " decode(LEAD_TIME, 0, 'QUOTE', LEAD_TIME) AS LEAD_TIME,"
					+ " decode(UNIT_PACK_QTY, 0, 1, UNIT_PACK_QTY) AS UNIT_PACK_QTY,"
					+ " decode(PROPOSED_CTLG_PRICE, 0,'QUOTE',PROPOSED_CTLG_PRICE) AS PROPOSED_CTLG_PRICE"
					+ " FROM "
					+ "PDW_CATALOG_PRICE_DTLS "
					+ "WHERE "
					+ "AVIALL_FLAG = 'Y' AND PLATFORM = ? "
					+ " and sign(ascii(PART_NUMBER)-58) < 0"
					+ " ORDER BY PART_NUMBER";
				pstmt2 = conn.prepareStatement(sqlCF34);
				LOGGER.debug("@@@@@@@@@@@@ procedure called " + sqlCF34);
				pstmt2.setString(1, catalogEng);
				
				rs2 = pstmt2.executeQuery();
				rs2.setFetchSize(200);
			}else if ("CF34_Airline_Aviall".equalsIgnoreCase(catalogId)) {
				String catalogEng = catalogId.substring(0, 4);
				String CF34 = "SELECT DISTINCT "
						+ " PART_NUMBER, ATA_KEYWORD, "
						+ " decode(LEAD_TIME, 0, 'QUOTE', LEAD_TIME) AS LEAD_TIME,"
						+ " decode(UNIT_PACK_QTY, 0, 1, UNIT_PACK_QTY) AS UNIT_PACK_QTY,"
						+ " decode(PROPOSED_CTLG_PRICE, 0,'QUOTE',PROPOSED_CTLG_PRICE) AS PROPOSED_CTLG_PRICE"
						+ " FROM "
						+ "PDW_CATALOG_PRICE_DTLS "
						+ "WHERE "
						+ "AVIALL_FLAG = 'Y' AND PLATFORM = ? "
						+ " and sign(ascii(PART_NUMBER)-58) >= 0"
						+ " ORDER BY PART_NUMBER";

				pstmt1 = conn.prepareStatement(CF34);
				LOGGER.debug("@@@@@@@@@@@@ procedure called " + CF34);
				pstmt1.setString(1, catalogEng);
				rs1 = pstmt1.executeQuery();
				rs1.setFetchSize(200);
				
				String sqlCF34 = "SELECT DISTINCT "
					+ " PART_NUMBER, ATA_KEYWORD, "
					+ " decode(LEAD_TIME, 0, 'QUOTE', LEAD_TIME) AS LEAD_TIME,"
					+ " decode(UNIT_PACK_QTY, 0, 1, UNIT_PACK_QTY) AS UNIT_PACK_QTY,"
					+ " decode(PROPOSED_CTLG_PRICE, 0,'QUOTE',PROPOSED_CTLG_PRICE) AS PROPOSED_CTLG_PRICE"
					+ " FROM "
					+ "PDW_CATALOG_PRICE_DTLS "
					+ "WHERE "
					+ "AVIALL_FLAG = 'Y' AND PLATFORM = ? "
					+ " and sign(ascii(PART_NUMBER)-58) < 0"
					+ " ORDER BY PART_NUMBER";
				pstmt2 = conn.prepareStatement(sqlCF34);
				LOGGER.debug("@@@@@@@@@@@@ procedure called " + sqlCF34);
				pstmt2.setString(1, catalogEng);
				
				rs2 = pstmt2.executeQuery();
				rs2.setFetchSize(200);
			}
			
			if(rs1 != null){
				while (rs1.next()) {
					bean = new IMCSSparePartsCatalogBean();
					bean.setPartNumber(rs1.getString("PART_NUMBER"));
					bean.setAtaKeyword(rs1.getString("ATA_KEYWORD"));
					bean.setLeadTime(rs1.getString("LEAD_TIME"));
					bean.setUPQ(rs1.getString("UNIT_PACK_QTY"));
					bean.setUnitPrice(rs1.getString("PROPOSED_CTLG_PRICE"));
					engineData.add(bean);
					bean = null;
				}
			}
			if(rs1 != null){
				while (rs2.next()) {
					bean = new IMCSSparePartsCatalogBean();
					bean.setPartNumber(rs2.getString("PART_NUMBER"));
					bean.setAtaKeyword(rs2.getString("ATA_KEYWORD"));
					bean.setLeadTime(rs2.getString("LEAD_TIME"));
					bean.setUPQ(rs2.getString("UNIT_PACK_QTY"));
					bean.setUnitPrice(rs2.getString("PROPOSED_CTLG_PRICE"));
					engineData.add(bean);
					bean = null;
				}
			}
			LOGGER.debug("engineData size = " + engineData.size());
		} catch (SQLException e) {
			LOGGER.error("SQLException :: " + e.getMessage());
			LOGGER.error(" Error :: " + e.getMessage());
		} catch (Exception e) {
			LOGGER.error("Exception" + e.getMessage());
			LOGGER.error(" Error :: " + e.getMessage());
		} finally {
			if(conn != null)
				conn.close();
			if(rs1 != null)
				rs1.close();
			if(pstmt1 != null)
				pstmt1.close();
			if(rs2 != null)
				rs2.close();
			if(pstmt2 != null)
				pstmt2.close();
			IMCSConnectionManager.closeSQL(conn);
			IMCSConnectionManager.closeSQL(rs1);
			IMCSConnectionManager.closeSQL(pstmt1);
			IMCSConnectionManager.closeSQL(rs2);
			IMCSConnectionManager.closeSQL(pstmt2);
		}
		return engineData;
	}

	/**
	 * Sole entry point to the class and application.
	 * 
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		IMCSSparePartsDAO iDao = new IMCSSparePartsDAO();
		iDao.getSparePartDetails("GE90");
		iDao.getSparePartDetails("CF6_Main");
		iDao.getSparePartDetails("CF6_Tech");
		iDao.getSparePartDetails("CF6_Aviall");
		iDao.getSparePartDetails("CFM56_Inc_Main");
		iDao.getSparePartDetails("CFM56_SA_Main");
		iDao.getSparePartDetails("CFM56_Inc_ThrustRev");
		iDao.getSparePartDetails("CFM56_Inc_ThrustRev");
		iDao.getSparePartDetails("CF34_Airline");
		iDao.getSparePartDetails("CF34_General_Avaition");
	}
}
