// Copyright (C) 2000 General Electric Company 
// All rights reserved 
package imcs.utilities;

import java.util.Properties;

public class IMCSBatchProperties {

	/**
	 * 
	 */
	public IMCSBatchProperties() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	/** Instance of IMCSBatchProperties */
	public static final IMCSBatchProperties imcsBatch = new IMCSBatchProperties ();
	/** Properties object to define all the properties */
	public Properties imcsBatchProperties;
	
	public static final String DB_DRIVER = "db.driver";
	/** This property defines the Database Name which is used for the application */
	public static final String DB_DATABASE_NAME = "db.dbName";
	/** This property defines the User Name to access the database which is used for the application  */
	public static final String DB_USERNAME = "db.username";
	/** This property defines the to access the database which is used for the application  */
	public static final String DB_PASSWORD = "db.password";
	
	public static final String DB_SP_URL = "dbSP.dbUrl";
	
	public static final String DB_SP_USERID = "dbSP.dbUserId";
	
	public static final String DB_SP_PWD = "dbSP.dbPassword";
	
	public static final String DB_CR_URL = "dbCR.dbUrl";
	
	public static final String DB_CR_USERID = "dbCR.dbUserId";
	
	public static final String DB_CR_PWD = "dbCR.dbPassword";
		
	public static final String BATCH_SP_ENGINE = "batchsp.engine";
	
	public static final String SP_GE90_MAIN_TITLE_PAGE = "GE90.Main_Title_Page";
	
	public static final String SP_GE90_PREAMBLE = "GE90.Preamble";
	
	public static final String SP_GE90_TITLE_PAGE = "GE90.Title_Page";
	
	public static final String SP_CFM56_INC_MAIN_MAIN_TITLE_PAGE = "CFM56_Inc.Main_Title_Page";
	
	public static final String SP_CFM56_INC_MAIN_PREAMBLE = "CFM56_Inc.Preamble";
	
	public static final String SP_CFM56_INC_MAIN_TITLE_PAGE = "CFM56_Inc.Title_Page";
	
	public static final String SP_CFM56_SA_MAIN_MAIN_TITLE_PAGE = "CFM56_SA.Main_Title_Page";
	
	public static final String SP_CFM56_SA_MAIN_PREAMBLE = "CFM56_SA.Preamble";
	
	public static final String SP_CFM56_SA_MAIN_TITLE_PAGE = "CFM56_SA.Title_Page";
	
	public static final String SP_CF34_AIRLINE_MAIN_MAIN_TITLE_PAGE = "CF34_Airline_Main.Main_Title_Page";
	
	public static final String SP_CF34_AIRLINE_MAIN_PREAMBLE = "CF34_Airline_Main.Preamble";
	
	public static final String SP_CF34_AIRLINE_MAIN_TITLE_PAGE = "CF34_Airline_Main.Title_Page";
	
	public static final String SP_CF34_GENERAL_AVIATION_MAIN_MAIN_TITLE_PAGE = "CF34_General_Aviation_Main.Main_Title_Page";
	
	public static final String SP_CF34_GENERAL_AVIATION_MAIN_PREAMBLE = "CF34_General_Aviation_Main.Preamble";
	
	public static final String SP_CF34_GENERAL_AVIATION_MAIN_TITLE_PAGE = "CF34_General_Aviation_Main.Title_Page";
	
	public static final String SP_CF34_AIRLINE_AVIALL_TITLE_PAGE = "CF34_Airline_Aviall.Title_Page";
	
	public static final String SP_CF34_GENERAL_AVIATION_AVIALL_TITLE_PAGE = "CF34_General_Aviation_Aviall.Title_Page";
	
	public static final String SP_CF6_MAIN_MAIN_TITLE_PAGE = "CF6_Main.Main_Title_Page";
	
	public static final String SP_CF6_MAIN_PREAMBLE = "CF6_Main.Preamble";
	
	public static final String SP_CF6_MAIN_TITLE_PAGE = "CF6_Main.Title_Page";
	
	public static final String SP_CF6_AVIALL_TITLE_PAGE = "CF6_Aviall.Title_Page";
	
	public static final String SP_CF6_TECH_TITLE_PAGE = "CF6_Tech.Title_Page";
	
	public static final String SP_CFM56_SA_THRUSTREV_TITLE_PAGE = "CFM56_SA_ThrustRev.Title_Page";
	
	public static final String SP_CFM56_INC_THRUSTREV_TITLE_PAGE = "CFM56_Inc_ThrustRev.Title_Page";
	
	public static final String BATCH_CR_ENGINES = "batchcr.engine";
	
	public static final String BATCH_CR_ENGINE_MDLS = "batchcr.engineMdlNum";
	
	public static final String CR_CF34_8C_TITLE_PAGE = "CF34-8C.Title_Page";
	
	public static final String CR_CF34_8E_TITLE_PAGE = "CF34-8E.Title_Page";
	
	public static final String CR_GE90_TITLE_PAGE = "GE90.Title_Page";
	
	public static final String CR_GE90_115B_TITLE_PAGE = "GE90-115B.Title_Page";
	
	public static final String CR_LM1600_TITLE_PAGE = "LM1600.Title_Page";
	
	public static final String CR_LM2500_TITLE_PAGE = "LM2500.Title_Page";
	
	public static final String CR_LM5000_TITLE_PAGE = "LM5000.Title_Page";
	
	public static final String CR_LM6000_TITLE_PAGE = "LM6000.Title_Page";
	
	public static final String CR_CF6_50_TITLE_PAGE = "CF6-50.Title_Page";
	
	public static final String CR_CF6_80A_TITLE_PAGE = "CF6-80A.Title_Page";
	
	public static final String CR_CF6_80C_TITLE_PAGE = "CF6-80C.Title_Page";
	
	public static final String CR_CF6_80E_TITLE_PAGE = "CF6-80E.Title_Page";
	
	public static final String CR_CFM56_3_TITLE_PAGE = "CFM56-3.Title_Page";
	
	public static final String CR_CFM56_5A_TITLE_PAGE = "CFM56-5A.Title_Page";
	
	public static final String CR_CFM56_5B_TITLE_PAGE = "CFM56-5B.Title_Page";
	
	public static final String CR_CFM56_5C_TITLE_PAGE = "CFM56-5C.Title_Page";
	
	public static final String CR_CFM56_7_TITLE_PAGE = "CFM56-7.Title_Page";
	
	public static final String CR_CF34_3RJ_BJ_TITLE_PAGE = "CF34-3RJ&BJ.Title_Page";
		
	/**
	 * This method is used to get IMCSBatchProperties Instance
	 * @return IMCSBatchProperties
	 */
	public static IMCSBatchProperties getInstance () {
		return imcsBatch; 
	}
	
	/**
	 * Setting the IMCS Batch property
	 * @param properties - IMCS Batch property
	 */
	public void setImcsBatchProperties (Properties properties) {
		this.imcsBatchProperties = properties;
	}
	
	/**
	 * Getting the IMCS Batch property
	 * @param propertyKey - property key to get the property 
	 * @return Object - IMCS Batch property
	 */
	public Object getImcsProperty (String propertyKey) {
		return imcsBatchProperties.getProperty(propertyKey);
	}
}
