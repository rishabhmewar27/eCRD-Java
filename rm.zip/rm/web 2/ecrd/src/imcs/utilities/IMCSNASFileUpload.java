// Copyright (C) 2000 General Electric Company 
// All rights reserved 

package imcs.utilities;

import geae.nas.GEAENASDirectory;
import geae.nas.GEAENASDirectoryException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

/**
 * @author 226855
 *
 */
public class IMCSNASFileUpload {
	
	/**Instance of the logger class for logging debug and error messages. */
	private static Logger logger = Logger.getLogger("IMCSNASFileUpload.class");
	/**
	 * 
	 *
	 */
	public void doFileUpload(String fileName){
		
		try {
			
			PropertyConfigurator.configure("properties/BatchLog4j.properties");
			
			logger.debug("--------------- Setting Logger ----------------- ");
			
			GEAENASDirectory dir = new GEAENASDirectory("/opt/shared/data/j2ee/crcc/");
			
			if(dir.canRead())
         		logger.debug("Readable");	     
			else
				logger.debug("Not readable");
			
			if(dir.canWrite())
         		logger.debug("Writable");	     
     	   	else
     	   		logger.debug("Not Writable");     

			java.util.List al = dir.listFiles(); 
		    for(int i = 0; i < al.size(); i++)
		     logger.debug((String)al.get(i));

		    if(dir.uploadFile(new java.io.File(fileName)))
            	 logger.debug("Uploaded ");	     
            else
            	 logger.debug("Not uploaded ");                    

		} catch (GEAENASDirectoryException e) {
			// TODO Auto-generated catch block
			logger.error(" Error :: " + e.getMessage());
		}
	}
}
