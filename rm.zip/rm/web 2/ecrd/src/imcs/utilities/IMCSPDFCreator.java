// Copyright (C) 2000 General Electric Company 
// All rights reserved

package imcs.utilities;

import java.awt.Color;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import imcs.bean.IMCSSparePartsCatalogBean;
import imcs.constants.EndPage;
import imcs.constants.IMCSSystemConstant;

import imcs.utilities.IMCSUtility;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfWriter;

public class IMCSPDFCreator {

	Font geINSPIRA8W;

	Font geINSPIRA7;

	Font geINSPIRA7B;

	BaseFont bfGEInspRg;

	/** Instance of the logger class for logging debug and error messages. */
	private static Logger logger = Logger.getLogger("IMCSPDFCreator.class");

	{
		PropertyConfigurator.configure("properties/BatchLog4j.properties");
	}

	public IMCSPDFCreator() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void createSpClPDF(ArrayList pdfData,
			IMCSSparePartsCatalogBean imcsSpClBean, ArrayList staticPdfs, int staticPageSize) throws Exception{

		logger.debug("Inside createPDF() ");
		logger.debug(Calendar.getInstance().getTime().toString());
		IMCSSparePartsCatalogBean imcsSPBean = null;
		try {
			setFonts();
			Document document = new Document(PageSize.LETTER);
			document.setMargins(-20, -20, 90, 54);

			// step2
			PdfWriter writer = PdfWriter.getInstance(document,
					new FileOutputStream(
							IMCSSystemConstant.RELATIVE_PDF_FILE_PATH
									+ imcsSpClBean.getEngineName()
									+ "_data.pdf"));
			logger.debug("Writer Page Size = " + writer.getPageSize());

			String engName = imcsSpClBean.getEngineName();
			String headerMargin = imcsSpClBean.getHeaderMargin();
			String headerLeft = imcsSpClBean.getHeaderLeft();
			String headerCenterLeft = imcsSpClBean.getHeaderCenterLeft();
			String headerCenterRight = imcsSpClBean.getHeaderCenterRight();
			String headerRight = imcsSpClBean.getHeaderRight();
			String headerCenter = imcsSpClBean.getHeaderCenter();
			String headerDownLeft = imcsSpClBean.getHeaderDownLeft();
			String footerMargin = imcsSpClBean.getFooterMargin();
			String footerLeft = imcsSpClBean.getFooterLeft();
			String footerCenter = imcsSpClBean.getFooterCenter();

			String[] endPageProps = { engName, headerMargin, headerLeft,
					headerCenterLeft, headerCenterRight, headerRight,
					headerCenter, headerDownLeft, footerMargin, footerLeft,
					footerCenter };

			EndPage endPage = new EndPage(endPageProps);

			writer.setPageEvent(endPage);
			// step3
			document.open();
			BaseFont bfArial = BaseFont.createFont("./styles/arial.ttf",
					BaseFont.CP1252, BaseFont.EMBEDDED);
			Font[] fonts = new Font[5];
			fonts[1] = new Font(bfArial, 8);
			fonts[2] = new Font(bfArial, 8, Font.BOLD);
			fonts[3] = new Font(bfArial, 8, Font.BOLD, Color.WHITE);

			// step4
			float[] relativeWidths = { 275, 10, 275 };
			PdfPTable table = new PdfPTable(relativeWidths);
			table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			int NumColumns = 5;

			PdfPTable datatable1 = new PdfPTable(NumColumns);
			PdfPTable datatable2 = new PdfPTable(NumColumns);
			int headerwidths[] = { 70, 40, 40, 40, 20 }; // percentage

			if (engName.startsWith("CFM56")) {
				datatable1.setWidths(headerwidths);
				datatable1.setWidthPercentage(100); // percentage
				datatable1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				datatable1.getDefaultCell().enableBorderSide(Rectangle.BOTTOM);
				datatable1.getDefaultCell().setBorderColorBottom(Color.BLACK);
				datatable1.getDefaultCell().setFixedHeight(10.9f);
				datatable1.getDefaultCell().setBackgroundColor(Color.BLACK);
				datatable1.getDefaultCell().setPaddingLeft(1f);
				datatable1.getDefaultCell().setPaddingRight(1f);
				datatable1.getDefaultCell().setPaddingTop(1f);
				datatable1.getDefaultCell().setPaddingBottom(1f);
				datatable1.getDefaultCell().setHorizontalAlignment(
						Element.ALIGN_LEFT);
				datatable1.getDefaultCell().setVerticalAlignment(
						Element.ALIGN_CENTER);

				datatable1.addCell(new Paragraph("Part Number", fonts[3]));
				datatable1.addCell(new Paragraph("Keyword", fonts[3]));
				datatable1.getDefaultCell().setHorizontalAlignment(
						Element.ALIGN_RIGHT);
				datatable1.addCell(new Paragraph("Unit Price", fonts[3]));
				datatable1.addCell(new Paragraph("Lead Time", fonts[3]));
				datatable1.addCell(new Paragraph("UPQ", fonts[3]));

				datatable1.setHeaderRows(1); // this is the end of the table
												// header

				datatable2.setWidths(headerwidths);
				datatable2.setWidthPercentage(100); // percentage
				datatable2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				datatable2.getDefaultCell().enableBorderSide(Rectangle.BOTTOM);
				datatable2.getDefaultCell().setBorderColorBottom(Color.BLACK);
				datatable2.getDefaultCell().setFixedHeight(10.9f);
				datatable2.getDefaultCell().setBackgroundColor(Color.BLACK);
				datatable2.getDefaultCell().setPaddingLeft(1f);
				datatable2.getDefaultCell().setPaddingRight(1f);
				datatable2.getDefaultCell().setPaddingTop(1f);
				datatable2.getDefaultCell().setPaddingBottom(1f);
				datatable2.getDefaultCell().setHorizontalAlignment(
						Element.ALIGN_LEFT);
				datatable2.getDefaultCell().setVerticalAlignment(
						Element.ALIGN_CENTER);

				datatable2.addCell(new Paragraph("Part Number", fonts[3]));
				datatable2.addCell(new Paragraph("Keyword", fonts[3]));
				datatable2.getDefaultCell().setHorizontalAlignment(
						Element.ALIGN_RIGHT);
				datatable2.addCell(new Paragraph("Unit Price", fonts[3]));
				datatable2.addCell(new Paragraph("Lead Time", fonts[3]));
				datatable2.addCell(new Paragraph("UPQ", fonts[3]));

				datatable2.setHeaderRows(1); // this is the end of the table
												// header

				for (int k = 0; k < pdfData.size(); k = k + 116) {
					for (int i = 0; (i < 58 && ((i + k) < pdfData.size())); i++) {
						imcsSPBean = (IMCSSparePartsCatalogBean) pdfData.get(i
								+ k);

						for (int x = 0; x < NumColumns / 5; x++) {
							datatable1.getDefaultCell().setBackgroundColor(
									Color.WHITE);
							datatable1.getDefaultCell().setHorizontalAlignment(
									Element.ALIGN_LEFT);
							datatable1.addCell(new Phrase(imcsSPBean
									.getPartNumber(), fonts[2]));
							datatable1.addCell(new Phrase(imcsSPBean
									.getAtaKeyword(), fonts[1]));
							datatable1.getDefaultCell().setHorizontalAlignment(
									Element.ALIGN_RIGHT);
							datatable1.addCell(new Phrase(IMCSUtility
									.getDecimal(IMCSUtility.checkNull(imcsSPBean.getUnitPrice(),"")),
									fonts[1]));
							datatable1.addCell(new Phrase(imcsSPBean
									.getLeadTime(), fonts[1]));
							datatable1.addCell(new Phrase(imcsSPBean.getUPQ(),
									fonts[1]));
						}

					}
					// Page Break

					for (int i = 58; (i < 116 && ((i + k) < pdfData.size())); i++) {
						imcsSPBean = (IMCSSparePartsCatalogBean) pdfData.get(i
								+ k);

						for (int x = 0; x < NumColumns / 5; x++) {
							datatable2.getDefaultCell().setBackgroundColor(
									Color.WHITE);
							datatable2.getDefaultCell().setHorizontalAlignment(
									Element.ALIGN_LEFT);
							datatable2.addCell(new Phrase(imcsSPBean
									.getPartNumber(), fonts[2]));
							datatable2.addCell(new Phrase(imcsSPBean
									.getAtaKeyword(), fonts[1]));
							datatable2.getDefaultCell().setHorizontalAlignment(
									Element.ALIGN_RIGHT);
							datatable2.addCell(new Phrase(IMCSUtility
									.getDecimal(IMCSUtility.checkNull(imcsSPBean.getUnitPrice(),"")),
									fonts[1]));
							datatable2.addCell(new Phrase(imcsSPBean
									.getLeadTime(), fonts[1]));
							datatable2.addCell(new Phrase(imcsSPBean.getUPQ(),
									fonts[1]));

						}
						if((i + k + 1) == pdfData.size()){
							datatable2.getDefaultCell().enableBorderSide(Rectangle.BOTTOM);
							datatable2.getDefaultCell().setBorderColorBottom(Color.BLACK);
							datatable2.getDefaultCell().setBackgroundColor(Color.WHITE);
							datatable2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
							datatable2.addCell(new Phrase("", geINSPIRA7B));
							datatable2.addCell(new Phrase("", geINSPIRA7));
							datatable2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
							datatable2.addCell(new Phrase("", geINSPIRA7));
							datatable2.addCell(new Phrase("", geINSPIRA7));
							datatable2.addCell(new Phrase("", geINSPIRA7));
						}

					}
				}

				PdfPTable emptyTable = new PdfPTable(1);
				PdfPCell emptyCell = new PdfPCell();
				emptyCell.setBorder(Rectangle.NO_BORDER);
				emptyTable.setTotalWidth(0.1f);
				emptyTable.addCell(emptyCell);
				table.addCell(datatable1);
				table.addCell(emptyTable);
				table.addCell(datatable2);
				document.add(table);
			} else {
				datatable1.setWidths(headerwidths);
				datatable1.setWidthPercentage(100); // percentage
				datatable1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				datatable1.getDefaultCell().enableBorderSide(Rectangle.BOTTOM);
				datatable1.getDefaultCell().setBorderColorBottom(Color.BLACK);
				datatable1.getDefaultCell().setFixedHeight(10.9f);
				datatable1.getDefaultCell().setBackgroundColor(Color.BLACK);
				datatable1.getDefaultCell().setPaddingLeft(1f);
				datatable1.getDefaultCell().setPaddingRight(1f);
				datatable1.getDefaultCell().setPaddingTop(1f);
				datatable1.getDefaultCell().setPaddingBottom(1f);
				datatable1.getDefaultCell().setHorizontalAlignment(
						Element.ALIGN_LEFT);
				datatable1.getDefaultCell().setVerticalAlignment(
						Element.ALIGN_CENTER);

				datatable1.addCell(new Paragraph("Part Number", geINSPIRA8W));
				datatable1.addCell(new Paragraph("Keyword", geINSPIRA8W));
				datatable1.getDefaultCell().setHorizontalAlignment(
						Element.ALIGN_RIGHT);
				datatable1.addCell(new Paragraph("Unit Price", geINSPIRA8W));
				datatable1.addCell(new Paragraph("Lead Time", geINSPIRA8W));
				datatable1.addCell(new Paragraph("UPQ", geINSPIRA8W));

				datatable1.setHeaderRows(1); // this is the end of the table
												// header
				datatable1.setExtendLastRow(false);
		//		datatable2 = new PdfPTable(NumColumns);
				datatable2.setWidths(headerwidths);
				datatable2.setWidthPercentage(100); // percentage
				datatable2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				datatable2.getDefaultCell().enableBorderSide(Rectangle.BOTTOM);
				datatable2.getDefaultCell().setBorderColorBottom(Color.BLACK);
				datatable2.getDefaultCell().setFixedHeight(10.9f);
				datatable2.getDefaultCell().setBackgroundColor(Color.BLACK);
				datatable2.getDefaultCell().setPaddingLeft(1f);
				datatable2.getDefaultCell().setPaddingRight(1f);
				datatable2.getDefaultCell().setPaddingTop(1f);
				datatable2.getDefaultCell().setPaddingBottom(1f);
				datatable2.getDefaultCell().setHorizontalAlignment(
						Element.ALIGN_LEFT);
				datatable2.getDefaultCell().setVerticalAlignment(
						Element.ALIGN_CENTER);

				datatable2.addCell(new Paragraph("Part Number", geINSPIRA8W));
				datatable2.addCell(new Paragraph("Keyword", geINSPIRA8W));
				datatable2.getDefaultCell().setHorizontalAlignment(
						Element.ALIGN_RIGHT);
				datatable2.addCell(new Paragraph("Unit Price", geINSPIRA8W));
				datatable2.addCell(new Paragraph("Lead Time", geINSPIRA8W));
				datatable2.addCell(new Paragraph("UPQ", geINSPIRA8W));

				datatable2.setHeaderRows(1); // this is the end of the table header
				datatable2.setExtendLastRow(false);
				
				for (int k = 0; k < pdfData.size(); k = k + 116) {
					for (int i = 0; (i < 58 && ((i + k) < pdfData.size())); i++) {
						imcsSPBean = (IMCSSparePartsCatalogBean) pdfData.get(i + k);

						for (int x = 0; x < NumColumns / 5; x++) {
							datatable1.getDefaultCell().setBackgroundColor(
									Color.WHITE);
							datatable1.getDefaultCell().setHorizontalAlignment(
									Element.ALIGN_LEFT);
							datatable1.addCell(new Phrase(imcsSPBean
									.getPartNumber(), geINSPIRA7B));
							datatable1.addCell(new Phrase(imcsSPBean
									.getAtaKeyword(), geINSPIRA7));
							datatable1.getDefaultCell().setHorizontalAlignment(
									Element.ALIGN_RIGHT);
							datatable1.addCell(new Phrase(IMCSUtility
									.getDecimal(IMCSUtility.checkNull(imcsSPBean.getUnitPrice(),"")),
									geINSPIRA7));
							datatable1.addCell(new Phrase(imcsSPBean
									.getLeadTime(), geINSPIRA7));
							datatable1.addCell(new Phrase(imcsSPBean.getUPQ(),
									geINSPIRA7));
						}

					}
					// Page Break

					for (int i = 58; (i < 116 && ((i + k) < pdfData.size())); i++) {
						imcsSPBean = (IMCSSparePartsCatalogBean) pdfData.get(i + k);

						for (int x = 0; x < NumColumns / 5; x++) {
							datatable2.getDefaultCell().setBackgroundColor(
									Color.WHITE);
							datatable2.getDefaultCell().setHorizontalAlignment(
									Element.ALIGN_LEFT);
							datatable2.addCell(new Phrase(imcsSPBean
									.getPartNumber(), geINSPIRA7B));
							datatable2.addCell(new Phrase(imcsSPBean
									.getAtaKeyword(), geINSPIRA7));
							datatable2.getDefaultCell().setHorizontalAlignment(
									Element.ALIGN_RIGHT);
							datatable2.addCell(new Phrase(IMCSUtility
									.getDecimal(IMCSUtility.checkNull(imcsSPBean.getUnitPrice(),"")),geINSPIRA7));
							datatable2.addCell(new Phrase(imcsSPBean
									.getLeadTime(), geINSPIRA7));
							datatable2.addCell(new Phrase(imcsSPBean.getUPQ(),
									geINSPIRA7));
						}
						
						if((i + k + 1) == pdfData.size()){
							datatable2.getDefaultCell().enableBorderSide(Rectangle.BOTTOM);
							datatable2.getDefaultCell().setBorderColorBottom(Color.BLACK);
							datatable2.getDefaultCell().setBackgroundColor(Color.WHITE);
							datatable2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
							datatable2.addCell(new Phrase("", geINSPIRA7B));
							datatable2.addCell(new Phrase("", geINSPIRA7));
							datatable2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
							datatable2.addCell(new Phrase("", geINSPIRA7));
							datatable2.addCell(new Phrase("", geINSPIRA7));
							datatable2.addCell(new Phrase("", geINSPIRA7));
						}
						
					}
				}
				PdfPTable emptyTable = new PdfPTable(1);
				PdfPCell emptyCell = new PdfPCell();
				emptyCell.setBorder(Rectangle.NO_BORDER);
				emptyTable.setTotalWidth(0.1f);
				emptyTable.addCell(emptyCell);
				table.setExtendLastRow(false);
				table.addCell(datatable1);
				table.addCell(emptyTable);
				table.addCell(datatable2);
				document.add(table);
			}

			// step5
			document.close();
			if(!(engName.startsWith("CF6") || engName.startsWith("CFM56") || engName.startsWith("CF34")))
			{
				logger.debug("eng name doesn't start with CF6 or CFM56 or CF34");
				logger.debug("staticPDF size " + staticPdfs.size());				
				IMCSUtility.addPageNumbers(imcsSpClBean.getEngineName() + "_data","SP", staticPageSize);
				staticPdfs.add(new PdfReader(IMCSSystemConstant.RELATIVE_PDF_FILE_PATH
						+ imcsSpClBean.getEngineName()
						+ "_data_final.pdf"));
			}else if(engName.startsWith("CF6") || engName.startsWith("CFM56") || engName.startsWith("CF34")){
				logger.debug("eng name starts with CF6 or CFM56 or CF34");
				logger.debug("staticPDF size " + staticPdfs.size());	
				staticPdfs.add(new PdfReader(IMCSSystemConstant.RELATIVE_PDF_FILE_PATH
						+ imcsSpClBean.getEngineName()
						+ "_data.pdf"));
			}
			
			

			// IMCSUtility.copyMyPdfs(concatPdfs,imcsSpClBean.getEngineName());
			IMCSUtility.copyMyPdfs(staticPdfs, imcsSpClBean.getEngineName(),
					"SP");
			IMCSUtility.deletePDFs(imcsSpClBean.getEngineName());
			if(engName.startsWith("GE90"))
				IMCSUtility.addPageNumbersForCF6("GE90_Catalog",9);

/*		} catch (DocumentException e) {
			logger.error(" Error :: " + e.getMessage());
		} catch (IOException e) {
			logger.error(" Error :: " + e.getMessage());
		} catch (Exception e) {
			logger.error(" Error :: " + e.getMessage());
		}*/
		}catch (Exception e) {
			logger.error(" Exception :: " + e.toString());
			e.printStackTrace();
		}
	}

	/**
	 * The method sets the required fonts
	 * 
	 */

	private void setFonts() {
		try {
			bfGEInspRg = BaseFont.createFont("./styles/GEInspiraReg.TTF",
					BaseFont.CP1252, BaseFont.EMBEDDED);

			geINSPIRA8W = new Font(bfGEInspRg, 8, 0, new Color(255, 255, 255));
			geINSPIRA7 = new Font(bfGEInspRg, 7.5f, Font.NORMAL, new Color(0,
					0, 0));
			geINSPIRA7B = new Font(bfGEInspRg, 7.5f, Font.BOLD, new Color(0, 0,
					0));
		} catch (DocumentException e) {
			logger.error(" Error :: " + e.getMessage());
		} catch (Exception e) {
			logger.error(" Error :: " + e.getMessage());
		}

	}
}
