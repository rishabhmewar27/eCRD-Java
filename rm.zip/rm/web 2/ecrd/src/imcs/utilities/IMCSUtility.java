// Copyright (C) 2000 General Electric Company 
// All rights reserved

package imcs.utilities;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import org.apache.log4j.Logger;

import imcs.constants.IMCSSystemConstant;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PRAcroForm;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfCopy;
import com.lowagie.text.pdf.PdfImportedPage;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfStamper;
import com.lowagie.text.pdf.SimpleBookmark;

public class IMCSUtility {
	
	/**Instance of the logger class for logging debug and error messages. */
	private static Logger logger = Logger.getLogger("IMCSUtility.class");
/**
 * 
 * @param strInput
 * @return the input string.
 */
	public static String checkNull(String strInput) {
		if (strInput == null) {
			return "";
		}
		return strInput;
	}
/**
 * 
 * @param strInput
 * @param strReplace
 * @return the original or the replaced string
 */
	public static String checkNull(String strInput, String strReplace) {

		if (strInput == null || strInput.equals("")) {
			return strReplace;
		}

		return strInput;
	}
	/**
	 * 
	 * @param inputStr
	 * @return 
	 */ 
	public static String verifyNull(String inputStr)
	{
		if (inputStr == null)
		{
			return "";
		}
		return inputStr.trim();
	}
	/**
	 * 
	 * @param date
	 * @return the date format.
	 * @throws ParseException
	 */
	public static Calendar dateStringToDate(String date) throws ParseException {
		SimpleDateFormat eSimpleDateFormat = new SimpleDateFormat("yyyyMMdd",
				Locale.US);
		eSimpleDateFormat.setTimeZone(TimeZone.getTimeZone("EST"));
		eSimpleDateFormat.setLenient(false);
		Date edt = eSimpleDateFormat.parse(date);
		Calendar ecal = Calendar.getInstance();
		ecal.setTime(edt);
		return ecal;
	}
	
	/**
	 * 
	 * @param strEngSeqId
	 * @param strSeparator
	 * @return
	 */
	public static String getDelimitedEngSeqId(String strEngSeqId[],
			String strSeparator) {
		StringBuffer esbfTemp = new StringBuffer();
		if (strEngSeqId != null) {
			for (int ei = 0; ei < strEngSeqId.length; ei++) {
				if (strEngSeqId[ei] != null) {
					esbfTemp = esbfTemp.append(strEngSeqId[ei]).append(
							strSeparator);
				}
			}
		}
		return esbfTemp.toString();
	}
/**
 * 
 * @param str
 * @param pattern
 * @param replace
 * @return
 */
	public static String replaceString(String str, String pattern,
			String replace) {
		if (str != null) {
			int es = 0;
			int ei = 0;
			StringBuffer eResult = new StringBuffer();

			while ((ei = str.indexOf(pattern, es)) >= 0) {
				eResult.append(str.substring(es, ei));
				eResult.append(replace);
				es = ei + pattern.length();
			}
			eResult.append(str.substring(es));
			return eResult.toString();
		} else {
			return "";
		}
	}
	/**
	 * 
	 * @param a
	 * @param b
	 * @return
	 */
	public static int calculateDifference(Date ai, Date bi) {
		int etempDifference = 0;
		int edifference = 0;
		Calendar earlier = Calendar.getInstance();
		Calendar elater = Calendar.getInstance();
		if (ai.compareTo(bi) < 0) {
			earlier.setTime(ai);
			elater.setTime(bi);
		} else {
			earlier.setTime(bi);
			elater.setTime(ai);
		}

		while (earlier.get(Calendar.YEAR) != elater.get(Calendar.YEAR)) {
			etempDifference = 365 * (elater.get(Calendar.YEAR) - earlier
					.get(Calendar.YEAR));
			edifference += etempDifference;

			earlier.add(Calendar.DAY_OF_YEAR, etempDifference);
		}

		if (earlier.get(Calendar.DAY_OF_YEAR) != elater
				.get(Calendar.DAY_OF_YEAR)) {
			etempDifference = elater.get(Calendar.DAY_OF_YEAR)
					- earlier.get(Calendar.DAY_OF_YEAR);
			edifference += etempDifference;

			earlier.add(Calendar.DAY_OF_YEAR, etempDifference);
		}

		return edifference;
	}
	
	/**
	 * 
	 * @param date
	 * @return
	 * 
	 */
	public static String formatDate(String date)

	{
		String eStrFormatDate = "";
		logger.info("Date input --" + date);
		int ea = date.indexOf('-');
		String etemp1 = date.substring(0, ea);
		int eb = date.lastIndexOf('-');
		String etemp2 = date.substring(ea + 1, eb);
		String etemp3 = date.substring(eb + 1);
		logger.info("temp1 = " + etemp1 + "temp2 = " + etemp2 + "temp3 = "
				+ etemp3);
		eStrFormatDate = etemp2 + "/" + etemp3 + "/" + etemp1;
		logger.info("Format Date" + eStrFormatDate);
		return eStrFormatDate;
	}

	/**
	 * <pre>
	 * This method creates an arraylist from the string passed as an argument
	 * that has values that are separated by Specified Separator Character.
	 * The method returns null for the string of the size of the delimiter.
	 * @param strInputParam  A String delimited by Separator
	 * @param strSeparator   Separator String
	 * @return - ArrayList of separated strings
	 * @exception Exception
	 * </pre>
	 **/
	public static ArrayList convertStringToArrayList(String strInputParam, String strSeparator) throws Exception
	{
		int intLoc = -1;
		String strFromInput = "";
		String strSep = "";
		int intStrSepLen = 0;
		int intStart = 0;
		ArrayList arrLstTemp = null;

		try
		{
			if ((strInputParam != null) && (strSeparator != null))
			{
				arrLstTemp = new ArrayList();
				strSep = strSeparator;
				strFromInput = strInputParam;

				if (((strInputParam.trim()).length() <= (strSeparator.trim()).length()) 
								|| strSeparator.trim().equals(strInputParam.trim()))
				{
					return arrLstTemp;
				}

		//		if (strSep != null)
		//		{
					intStrSepLen = strSep.length();
		//		}
				if (intStrSepLen > 0)
				{
					intLoc = strFromInput.indexOf(strSep);
					if (intLoc != -1)
					{
						do
						{
							intLoc = strFromInput.indexOf(strSep);
							if (intLoc != -1)
							{
								arrLstTemp.add(strFromInput.substring(intStart, intLoc).trim());
								strFromInput = strFromInput.substring(intLoc + intStrSepLen);
							}
						}
						while (intLoc != -1);
						if (strFromInput != null)
						{
							arrLstTemp.add(strFromInput.trim());
						}
					}
					else
					{
						arrLstTemp.add(strFromInput.trim());
					}
				}
				else
				{
					arrLstTemp.add(strFromInput.trim());
				}
			}
			else
			{
				return null;
			}

			if ((arrLstTemp != null) && (arrLstTemp.size() > 0))
			{
				return arrLstTemp;
			}
			else
			{
				return null;
			}
		}
		finally
		{
			strFromInput = null;
			strSep = null;
		}
	}

	
	/**
	 * 
	 * @param pdfsToConcate
	 * @param pdfName
	 */
	public static void copyMyPdfs(ArrayList pdfsToConcate, String pdfName, String type)throws Exception{
		ArrayList pdfs = new ArrayList();
		PdfReader pdfReader = null;
		int preAmble = 0;
	try{
		logger.debug("Inside copyMyPdfs pdfsToConcate " + pdfsToConcate.size());
		logger.debug("preAmble size = " + preAmble);
		for(int i = 0; i < pdfsToConcate.size(); i++){
			pdfReader = (PdfReader)pdfsToConcate.get(i);
			logger.debug("pdfsToConcate " + ((PdfReader)pdfsToConcate.get(i)).getNumberOfPages());
			if( i == 1){
				preAmble = ((PdfReader)pdfsToConcate.get(i)).getNumberOfPages();
			}
			pdfs.add(pdfReader);
		}
		logger.debug("preAmble size = " + preAmble);
		int fi = 0;
		int pageOffset = 0;
        ArrayList master = new ArrayList();
        Document document = null;
        PdfCopy  writer = null;
        
		while (fi < pdfs.size()) {
            // we create a reader for a certain document
            PdfReader reader = (PdfReader)pdfs.get(fi);
            reader.consolidateNamedDestinations();
            // we retrieve the total number of pages
            int ni = reader.getNumberOfPages();
            List bookmarks = SimpleBookmark.getBookmark(reader);
            if (bookmarks != null) {
                if (pageOffset != 0)
                    SimpleBookmark.shiftPageNumbers(bookmarks, pageOffset, null);
                master.addAll(bookmarks);
            }
            pageOffset += ni;
            
            if (fi == 0) {
                // step 1: creation of a document-object
                document = new Document(reader.getPageSizeWithRotation(1));
                document.setMargins( -20,-20,40,90 );
                // step 2: we create a writer that listens to the document
                if("SP".equalsIgnoreCase(type)){
                	writer = new PdfCopy(document, new FileOutputStream(IMCSSystemConstant.RELATIVE_PDF_FILE_PATH 
                											+ pdfName + "_Catalog.pdf"));
                }else{
                	writer = new PdfCopy(document, new FileOutputStream("./pdf/CR_" + pdfName + "_Catalog.pdf"));
                }
                // step 3: we open the document
                document.open();
            }
            // step 4: we add content
            PdfImportedPage page;
            for (int i = 0; i < ni; ) {
                ++i;
                page = writer.getImportedPage(reader, i);
                writer.addPage(page);
            }
            PRAcroForm form = reader.getAcroForm();
            if (form != null)
                writer.copyAcroForm(reader);
            fi++;
        }
        if (!master.isEmpty())
            writer.setOutlines(master);
        // step 5: we close the document
        document.close();
        
	}catch (DocumentException de) {
    	logger.error(" Document Error :: " + de.getMessage());
    }catch (IOException de) {
    	logger.error(" IO Error :: " + de.getMessage());
    }
   
}
	/**
	 * 
	 * @param pdfName
	 */
	public static void addPageNumbers(String pdfName,String type, int staticPageSize)throws Exception{
		
		logger.debug(" PDFName = " + pdfName);
		logger.debug("staticPageSize in addPageNums = " + staticPageSize);
		try {
			 if("SP".equalsIgnoreCase(type)){
			// we create a reader for a certain document
            PdfReader reader = new PdfReader(IMCSSystemConstant.RELATIVE_PDF_FILE_PATH + pdfName 
            								+ IMCSSystemConstant.PDF_FILE_EXTENSION_PATH);
            int ni = reader.getNumberOfPages();
            // we create a stamper that will copy the document to a new file
            PdfStamper stamp = new PdfStamper(reader, new FileOutputStream(IMCSSystemConstant.RELATIVE_PDF_FILE_PATH 
            												+ pdfName + "_final.pdf"));
            //setting font
            IMCSSystemConstant imcs = new IMCSSystemConstant();
            Font pageNumberFont = new Font(imcs.getGeINSPIRA7());
            // adding content to each page
            int ei = 0;
            PdfContentByte under;
            PdfContentByte over;
        //    Image img = Image.getInstance("watermark.jpg");
            BaseFont bf = BaseFont.createFont(BaseFont.HELVETICA, BaseFont.WINANSI, BaseFont.EMBEDDED);
        //    img.setAbsolutePosition(200, 400);
            
            staticPageSize = staticPageSize + 2;
            logger.debug("staticPageSize in addPageNums = " + staticPageSize);
            while (ei < ni) {
            	ei++;
            	// watermark under the existing page
            	under = stamp.getUnderContent(ei);
        //    	under.addImage(img);
            	// text over the existing page
            	logger.debug("ei = " + ei);
                	over = stamp.getOverContent(ei);
	            	over.beginText();
	            	over.setFontAndSize(bf, 9);
	             	over.setTextMatrix(10, 10);
	            // 	if(ei >= staticPageSize){
	            // 		over.showTextAligned(Element.ALIGN_RIGHT, String.valueOf(ei),540,25,0);
	            /* 	}else{
	             		over.showTextAligned(Element.ALIGN_RIGHT, "0" ,540,25,0);
	             	}
                */	over.setFontAndSize(pageNumberFont.getBaseFont(), 10);
	           // 	over.showTextAligned(Element.ALIGN_LEFT, "DUPLICATE", 230, 430, 45);
	            	over.endText();
            	
            }

           // closing PdfStamper will generate the new PDF file
            stamp.close();
        }
		else{
			 PdfReader reader = new PdfReader(IMCSSystemConstant.RELATIVE_PDF_FILE_PATH + pdfName + "_CR.pdf");
			 int ni = reader.getNumberOfPages();
			 PdfStamper stamp = new PdfStamper(reader, new FileOutputStream(IMCSSystemConstant.RELATIVE_PDF_FILE_PATH 
					 				+ pdfName + "_CR_final.pdf"));
			 IMCSSystemConstant imcs = new IMCSSystemConstant();
	         Font pageNumberFont = new Font(imcs.getGeINSPIRA7());
	            // adding content to each page
	            int ei = 0;
	            PdfContentByte under;
	            PdfContentByte over;
	        //    Image img = Image.getInstance("watermark.jpg");
	            BaseFont bf = BaseFont.createFont(BaseFont.HELVETICA, BaseFont.WINANSI, BaseFont.EMBEDDED);
	        //    img.setAbsolutePosition(200, 400);
	            while (ei < ni) {
	            	ei++;
	            	// watermark under the existing page
	            	under = stamp.getUnderContent(ei);
	        //    	under.addImage(img);
	            	// text over the existing page
	            	over = stamp.getOverContent(ei);
	            	over.beginText();
	            	over.setFontAndSize(bf, 9);
	             	over.setTextMatrix(10, 10);
	            	over.showTextAligned(Element.ALIGN_RIGHT, String.valueOf(ei),540,25,0);
	            	over.setFontAndSize(pageNumberFont.getBaseFont(), 10);
	           // 	over.showTextAligned(Element.ALIGN_LEFT, "DUPLICATE", 230, 430, 45);
	            	over.endText();
	           // 	under.endText();
	           // 	logger.debug("under " + under);
		}
	            // closing PdfStamper will generate the new PDF file
	            stamp.close();
		}
		}catch (DocumentException de) {
        	logger.error(" Document Error :: " + de.getMessage());
        }catch (IOException de) {
        	logger.error(" IO Error :: " + de.getMessage());
        }
	}
	
	public static void addPageNumbersForCF6(String pdfName, int staticPageSize){
	try
	{
		logger.debug("staticPageSize in addPageNums = " + staticPageSize);
		logger.debug("inside addPageNumbersForCF6 pdfName = " + pdfName);
//		 we create a reader for a certain document
        PdfReader reader = new PdfReader(IMCSSystemConstant.RELATIVE_PDF_FILE_PATH + pdfName 
        								+ IMCSSystemConstant.PDF_FILE_EXTENSION_PATH);
        int ni = reader.getNumberOfPages();
        // we create a stamper that will copy the document to a new file
        PdfStamper stamp = new PdfStamper(reader, new FileOutputStream(IMCSSystemConstant.RELATIVE_PDF_FILE_PATH 
        												+ pdfName + "_2009.pdf"));
        //setting font
        IMCSSystemConstant imcs = new IMCSSystemConstant();
        Font pageNumberFont = new Font(imcs.getGeINSPIRA7());
        // adding content to each page
        int ei = 0;
        PdfContentByte under;
        PdfContentByte over;
    //    Image img = Image.getInstance("watermark.jpg");
        BaseFont bf = BaseFont.createFont(BaseFont.HELVETICA, BaseFont.WINANSI, BaseFont.EMBEDDED);
    //    img.setAbsolutePosition(200, 400);
        while (ei < ni) {
        	ei++;
        	// watermark under the existing page
        	under = stamp.getUnderContent(ei);
    //    	under.addImage(img);
        	// text over the existing page
        	over = stamp.getOverContent(ei);
        	over.beginText();
        	over.setFontAndSize(bf, 9);
         	over.setTextMatrix(10, 10);
         	logger.debug("staticPageSize in addPageNums = " + staticPageSize);
         	if(ei >= staticPageSize){
         		over.showTextAligned(Element.ALIGN_RIGHT, String.valueOf(ei - staticPageSize + 1),540,25,0);
         	}
        	over.setFontAndSize(pageNumberFont.getBaseFont(), 10);
       // 	over.showTextAligned(Element.ALIGN_LEFT, "DUPLICATE", 230, 430, 45);
        	over.endText();
       // 	under.endText();
       // 	logger.debug("under " + under);
        }

       // closing PdfStamper will generate the new PDF file
        stamp.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void deleteCRPDFs(String fileName) {
	    try {
	      // Construct a File object for the file to be deleted.
	    File target_data_final = new File(IMCSSystemConstant.RELATIVE_PDF_FILE_PATH + fileName + "_CR_final.pdf");
	    File target_data  = new File(IMCSSystemConstant.RELATIVE_PDF_FILE_PATH + fileName + "_CR.pdf");
	     
	      ArrayList files = new ArrayList();
	      files.add(target_data_final);
	      files.add(target_data);
	     
	      logger.debug(target_data_final.exists() + " " + target_data_final.getName());
	      for (int i = 0; i < files.size(); i++)
	      {
	    	  File target = (File)files.get(i);
	    	  if (!target.exists()) 
	    	  {
	    		  logger.error("File " + target.getName()
	    				  + " not present to begin with!");
	    	  }
	      	// Quick, now, delete it immediately:
	    	  if (target.delete()){
	    		 logger.error("** Deleted " + target.getName() + " **");
	    	  }
	    	  else{
	    		    logger.error("Failed to delete " + target.getName());
	    	  }
	     }
	      
	    } catch (SecurityException e) {
	    	 	logger.error("SecurityException : Unable to delete " + fileName + "("
	          + e.getMessage() + ")");
	     }
	  } 
	 
	public static void deletePDFs(String fileName) {
	    try {
	    	logger.debug("Inside deletePDFs");
	      // Construct a File object for the file to be deleted.
	      File target_data_final = new File(IMCSSystemConstant.RELATIVE_PDF_FILE_PATH + fileName + "_data_final.pdf");
	      File target_data = new File(IMCSSystemConstant.RELATIVE_PDF_FILE_PATH + fileName + "_data.pdf");
	     // 
	      ArrayList files = new ArrayList();
	      files.add(target_data_final);
	      files.add(target_data);
	    //  files.add(target_static);
	      for (int i = 0; i < files.size(); i++)
	      {
	    	  File target = (File)files.get(i);
	    	  if (!target.exists()) 
	    	  {
	    		  logger.error("File " + target.getName()
	    				  + " not present to begin with!");
	    	  }
	      	// Quick, now, delete it immediately:
	    	  if (target.delete())
	    		 logger.error("** Deleted " + target.getName() + " **");
	    	  else
	    		 logger.error("Failed to delete " + target.getName());
	     }
	      
	    } catch (SecurityException e) {
	     logger.error("Unable to delete " + fileName + "("
	          + e.getMessage() + ")");
	    }
	  }

	

		public static void deleteCF6PDFs(String fileName) {
	    try {
	    	logger.debug("Inside deleteCF6PDFs");
	      // Construct a File object for the file to be deleted.
	      File target_data_final = new File(IMCSSystemConstant.RELATIVE_PDF_FILE_PATH + fileName + "_Main_catalog.pdf");
	      File target_data = new File(IMCSSystemConstant.RELATIVE_PDF_FILE_PATH + fileName + "_Aviall_catalog.pdf");
	      File target_static = new File(IMCSSystemConstant.RELATIVE_PDF_FILE_PATH + fileName + "_Tech_catalog.pdf");
	      File target_full = new File(IMCSSystemConstant.RELATIVE_PDF_FILE_PATH + fileName + "_Catalog.pdf");
	      ArrayList files = new ArrayList();
	      files.add(target_data_final);
	      files.add(target_data);
	      files.add(target_static);
	      files.add(target_full);
	      for (int i = 0; i < files.size(); i++)
	      {
	    	  File target = (File)files.get(i);
	    	  if (!target.exists()) 
	    	  {
	    		 logger.error("File " + fileName
	    				  + " not present to begin with!");
	    	  }
	      	// Quick, now, delete it immediately:
	    	  if (target.delete())
	    		 logger.error("** Deleted " + fileName + " **");
	    	  else
	    		 logger.error("Failed to delete " + fileName);
	     }
	      
	    } catch (SecurityException e) {
	     logger.error("Unable to delete " + fileName + "("
	          + e.getMessage() + ")");
	    }
	  }
public static void deleteCFM56PDFs(String fileName) {
    try {
    	logger.debug("Inside deleteCFM56PDFs");
      // Construct a File object for the file to be deleted.
      File target_data_1 = new File(IMCSSystemConstant.RELATIVE_PDF_FILE_PATH + fileName + "_Main_catalog.pdf");
      File target_data_2 = new File(IMCSSystemConstant.RELATIVE_PDF_FILE_PATH + fileName + "_ThrustRev_catalog.pdf");
      File target_data_3 = new File(IMCSSystemConstant.RELATIVE_PDF_FILE_PATH + fileName + "_Catalog.pdf");
      ArrayList files = new ArrayList();
      files.add(target_data_1);
      files.add(target_data_2);
      files.add(target_data_3);
      for (int i = 0; i < files.size(); i++)
      {
    	  File target = (File)files.get(i);
    	  if (!target.exists()) 
    	  {
    		 logger.error("File " + fileName
    				  + " not present to begin with!");
    	  }
      	// Quick, now, delete it immediately:
    	  if (target.delete())
    		 logger.error("** Deleted " + fileName + " **");
    	  else
    		 logger.error("Failed to delete " + fileName);
     }
      
    } catch (SecurityException e) {
     logger.error("Unable to delete " + fileName + "("
          + e.getMessage() + ")");
    }
  
  }
/**
 * 
 * @param number
 * @return
 */
public static String getDecimal(String number)
{
	
	if(!"".equals(number) || number != null){
		if("QUOTE".equalsIgnoreCase(number.toUpperCase(Locale.US))){
			return number;
		}else{
			int ei = number.indexOf('.');
			if(ei == 0){
				if(number.length() == 3)
					return "00" + number;
				else if(number.length() == 2)
					return "00" + number + "0";
			}
		
			if(ei != -1){
				String ji = number.substring(ei);
			    
				if(!"".equals(ji) || ji != null){
					if(ji.length() - 1 == 0){
						return number + "00";
					}else if(ji.length() - 1 == 1){
						return number + "0";
					}else if(ji.length() - 1 >= 2){
						return number ;
					}
				}
			}else{
				return number + ".00";
			}
		}
	}
	return "";
}
/**
 * 
 * @param args
 */

 public static void main(String[] args)
    {
	 	String abc = getDecimal("QUOTE");
	 	String abc1 = getDecimal(".5");
	 	String abc2 = getDecimal("12.56");
/*	 	System.out.println("abc = " + abc);
	 	System.out.println("abc = " + abc1);
	 	System.out.println("abc = " + abc2);
	 	System.out.println(abc);
 */   }
}
 



