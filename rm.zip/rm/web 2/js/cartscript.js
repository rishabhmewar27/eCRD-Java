// initializes the cursor to the first qty field
function init(form) {
	if(form != "orderHeader") {
		var myForm = eval("document." + form + ".qty0");
	}else{
		var myForm = eval("document." + form + ".poNumber");
	}
	focusAndSelect(myForm)
}  // end function init()

// sets the focus and selects the value in the field
function focusAndSelect(object) {
    object.focus();
    object.select();
  } // end function focusAndSelect()

// checks to see that the PONumber field isn't blank
// a is the PO field, b is the Ship To field, and c is the MarkFor field
function checkPO(a,b,c) {
	if(a.length <3) {
		alert("Please fill in P.O.# field, must be at least 3 characters.");
	}else if(b == "none") {
		alert("Please choose a Ship To code");
	}else if(document.orderHeader.markFor.options.length > 1 && c == "none") {
		alert("Please choose a Mark For code");
	}else {
		document.orderHeader.submit();
	}
}

// determines if the next button is enabled
function AllowButton(F,form) {
	if (F==false) {
		eval("document." + form + ".next.disabled=true;")
	} else {
		eval("document." + form + ".next.disabled=false;")
	}
} // end function AllowButton(F,form)


// checks each value entered by the user to see if it's numeric and proper quantity
// UPQ,QTY,Price correspond to field values, t is the field object used with focusAndSelect method
function checkShip(t,formname,sd) {
	// check for valid date value only on verify.jsp page
	if(formname == "verifyOrder"){
		if(!isDate(sd.substring(0,4),sd.substring(5,7),sd.substring(8,10))) {
			alert("Invalid ship date.  Please format your date like the following:  'YYYY/MM/DD' ");
			focusAndSelect(t);
		}
	}
} // end function checkShip(t,formname,sd)


// checks each value entered by the user to see if it's numeric and proper quantity
// UPQ,QTY,Price correspond to field values, t is the field object used with focusAndSelect method
function checkUPQ(UPQ,QTY,Price,t,formname) {
	if(!isNumeric(QTY) || QTY == 0) {
		alert("You must enter a valid number in the quantity field.\n");
		focusAndSelect(t);
	} else {
		// see if the QTY is equally divisible by the UPQ
		var divs = QTY % UPQ;
		if (divs > 0) {
			alert("You must enter a value for the Quantity that is equally divisible by the UPQ.\n\nPlease check your values.\n");
			focusAndSelect(t);
		} // end if (divs > 0)
	} // end if(!isNumeric(QTY)) 
} // end function checkUPQ(UPQ,QTY,Price,t,formname)


// checks all the values to see that they are numeric and of proper quantities
// src is either from the field or the next button.
function checkALL(src,thisfield,form,mf) {
	var ckflag=true;
	var val = eval("document." + form + ".TotalNumber.value");
	// loop through each item in basket
	for(var i=0; i<val && ckflag==true; i++) {
		var QTY = eval("document." + form + ".qty" + i + ".value");
		var UPQ = eval("document." + form + ".upq" + i + ".value");
		var Price = eval("document." + form + ".price" + i + ".value");
		var extPrice = eval("document." + form + ".extPrice" + i + ".value");
		// check for valid date value only on verify.jsp page
		if(form == "verifyOrder"){
			var sd = eval("document.verifyOrder.shipDate" + i + ".value");
			if(!isDate(sd.substring(0,4),sd.substring(5,7),sd.substring(8,10))) {
				ckflag=false;
				return ckflag;	
			}
			if(mf > 0){
				var mlen = eval("document.verifyOrder.markFor" + i + ".options.length");
				var mval = eval("document.verifyOrder.markFor" + i + ".options.value");
				if(mlen> 1 && mval == "none") {
					alert("Please select Mark For where applicable");
					ckflag=false;
				}
			}
		}
		// check for numeric value	
		if((!isNumeric(QTY) || QTY == 0) && ckflag==true) {
			ckflag=false;
			return ckflag;
		}
		// if numeric and ckflag is still true, perform calculation to test proper quantity
		if(ckflag==true) {
			var divs = QTY % UPQ;
			if (divs > 0) {
				if(src!="") {
					alert("You must enter a value for the Quantity that is equally divisible by the UPQ.\n\nPlease check your values.\n");
				}
				var myaction = "";
				eval("document." + form + ".action ='" + myaction + "';")
				ckflag=false;
			} else {
				// do Math to perform the calculation
				// remove dollar signs and commas
				var numextprice = RemoveSign(extPrice);
				var numprice = RemoveSign(Price);
				// calculation
				numextprice = QTY * numprice;
				// formatNumber for currency
				numextprice = FormatNumber(numextprice);
				// set the field value
				eval("document." + form + ".extPrice" + i + ".value = '" + numextprice + "';")
				// make sure ckflag is true because the value was correct
				ckflag=true;
			} // end if(divs > 0)
		} // end if(ckflag==true)
	} // end for
	// if src comes from button and the checks are all done, proceed to the orderHeader.jsp page
	if((src!="") && ckflag==true) {
		if(form == "verifyOrder") {
			var myaction = "./appcont.jsp?cont=fw-cartcomplete";
		}else{
			var myaction = "./appcont.jsp?cont=fw-cartheader";
		}
		eval("document." + form + ".action='" + myaction + "';")
		eval("document." + form + ".submit();")
	}
	// if something is wrong, return the flag value
	return ckflag;
} // end function checkALL(src,thisfield,form)



//  THE FOLLOWING CODE IS USED TO PERFORM THE PRICE CALCULATIONS AS THE USER ENTERS THE VALUES
// test to see if the value in the field is numeric
function isNumeric(value) {
	if (value == "")  { 
		return false; 
	}
	if (value.charAt(0) == "-") {
	  start = 1;
	} else {
	  start = 0;
	}
	for (i=start; i<value.length; i++)
	{
	  if (value.charAt(i) < "0") { return false; }
	  if (value.charAt(i) > "9") { return false; }
	}
	return true;
  } // end function isNumeric(value)

//properly format the number for currency
function FormatNumber(Value) 
	{
	var tmp1 = cents = dollars = "";
	var dec = -1;
	var neg = false;
	// perform simple calculation for numeric validity
	Value = "" + (Math.round(Value * 100)/100);
	   // if not a number, end function
	   if (Value == "NaN") {
			Value = "0";
			alert("You have entered a nonnumeric value.\nPlease re-enter your number.")
			return(Value);
		}
	   // if value is negative, send value to formatneg function
	   if (Value.substring(0,1) == "-") {
			Value = FormatNeg(Value)
			neg = true;
		}
	// check for the decimal
	dec = Value.indexOf(".");
	cents = ((dec > 0) ? Value.substring(dec,Value.length) : ".00");
	if (cents.length == 2) cents += "0";
	// format the dollars 
	dollars = "" + parseInt(Value);
	tmp1 = insComma(dollars);
	if (neg == true) {
		Value = "-$";
	} else {
		Value = "$";
	}

	for (i = tmp1.length-1; i >= 0; i--) 
		Value += tmp1.charAt(i);;

	Value +=  cents;
	return(Value);
} // end function FormatNumber(Value)

//format number for negative values
function FormatNeg(Valu) 
	{
	var MyValue = 0;
	var mul = -1;
	if (Valu.substring(0,1) == "-"){
			MyValue= "" + parseFloat(Valu * mul / 1)
			return(MyValue);
		}
	else {
		return(Valu);
		}
	} // end function FormatNeg(Valu)

//remove the dollar sign for calculations
function RemoveSign(Val) 
	{
		var dol = -1;
		var step = 0;

		dol = Val.indexOf("$")
		if (dol >= 0) {
			if (dol == 1) {
				Val = "-" + Val.substring(dol+1,Val.length);
			}
			else {
				Val = Val.substring(dol+1,Val.length);
			}
		}
		Val = RemComma(Val);
		return(Val);
	} // end function RemoveSign(Val)

//remove the commas for calculations
function RemComma(info) 
	{	
		var comma = ",";
		var d = 0;

		for (i = 0; i < info.length; i++)
		  if (info.substring(i, i+1) == comma) d++;

		for (i = 0; i <= d; i++) {
		comma = info.indexOf(",")
			if (comma > 0) {
				info = info.substring(0,comma) + info.substring(comma+1,info.length)
			}
		}
		return(info);
	} // end function RemComma(info)

//insert commas for currency formats
function insComma(data) 
	{
	   var count = i = 0;
	   var tmpStr = "";
	   var comma = ",";

	   for (i = data.length-1; i >= 0; i--) 
	   {
		  if (count == 3)
		  {
			 tmpStr += comma;
			 count = 1;
		  }
		  else  count ++;
		  tmpStr += data.charAt(i);
	   }
	   return(tmpStr);
	} // end function insComma(data)

