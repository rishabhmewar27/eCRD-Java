// This function is uesd to validate Add Compoenent form
// To check whether the user has selected Engine Model and Engine Module
// Input Parameter : Form Object

function fnValidateAddComponent(objForm)
{
   if(objForm.lstEngineModel.selectedIndex==0)
   {
       alertMsgs(eCRDSelEngModel);
       objForm.lstEngineModel.focus();

   }
   else
   {
      if(objForm.lstEngineModule.selectedIndex==0 )
      {
         alertMsgs(eCRDSelEngModule);
         objForm.lstEngineModule.focus();
      }
      else
      {
         objForm.hdnEngineModel.value = objForm.lstEngineModel.options[objForm.lstEngineModel.selectedIndex].value;
         objForm.hdnEngineModule.value = objForm.lstEngineModule.options[objForm.lstEngineModule.selectedIndex].value;
         objForm.hdnEngineModelDesc.value = objForm.lstEngineModel.options[objForm.lstEngineModel.selectedIndex].text;
         objForm.hdnEngineModuleDesc.value = objForm.lstEngineModule.options[objForm.lstEngineModule.selectedIndex].text;
         objForm.hdnScreenAction.value="eCRDComponentDetails";
         objForm.submit();
      }
   }
}


// This function is uesd to Check if component class is changed or not
// Input Parameter : Class of component,Component Code,Form Object

function fnCheckClass(strClass,strCompCode,objForm)
{
   with(objForm)
   {
      for(i=0;i<elements.length;i++)
      {
         if(elements[i].name =="hdnCompCode")
         {
            strTemp = fnTrim(elements[i].value);
            if(strTemp == strCompCode)
            {
               if(elements[i+2].value !=strClass)
               {
                  elements[i+1].value = elements[i].value + "^" + elements[i+2].value;
               }
               else
               {
                  elements[i+1].value ="";
               }
            }
         }
      }
   }
}

// This function is used to Save the Clasiify Componenr List
// Input Parameter : Form Object, Column Dellmiter, Row Delimiter

function fnSaveClassifyCompList(objForm,STRCOLUMNDELIM,STRROWDELIM)
{
   var strCompClass = "";
   with(objForm)
   {
      for(i=0;i<elements.length;i++)
      {
         if(elements[i].name =="hdnCompClass")
         {
            if(fnTrim(elements[i].value)!="")
            {
               strCompClass = strCompClass+ fnTrim(elements[i].value) + STRCOLUMNDELIM +STRROWDELIM;
            }
         }
     }
   }
   if(strCompClass!="")
   {
      with(document.frmSaveClassifyComponent)
      {
         hdnCompClassList.value = strCompClass;
         submit();
      }
   }
   else
   {
      alertMsgs(eCRDChangeCompClass);
   }
}


// This function is used to validate ClassifyComponent Screen
// (whether engine model and module is selected or not

function fnValidateClassifyComponent(objForm)
{
    if(objForm.lstEngineModel.selectedIndex==0)
   {
       alertMsgs(eCRDSelEngModel);
       objForm.lstEngineModel.focus();
   }
   else
   {
      if(objForm.lstEngineModule.selectedIndex==0 )
      {
         alertMsgs(eCRDSelEngModule);
         objForm.lstEngineModule.focus();
      }
      else
      {
         objForm.hdnEngineModel.value = objForm.lstEngineModel.options[objForm.lstEngineModel.selectedIndex].value;
         objForm.hdnEngineModule.value = objForm.lstEngineModule.options[objForm.lstEngineModule.selectedIndex].value;
         objForm.hdnEngineModelDesc.value = objForm.lstEngineModel.options[objForm.lstEngineModel.selectedIndex].text;
         objForm.hdnEngineModuleDesc.value = objForm.lstEngineModule.options[objForm.lstEngineModule.selectedIndex].text;
         objForm.hdnScreenAction.value="eCRDClassifyComponentDetails";
         objForm.submit();
      }
   }
}

// This function is used to change the values of the Engine Module corresponding
// to the value of the Engine Model

function fnChangeEngineModule(objForm)
{
   objForm.hdnEngineModelDesc.value=objForm.lstEngineModel.options[objForm.lstEngineModel.selectedIndex].value;
   objForm.submit();
}


// This function is used to change engine module after selecting engine model
// in case of classify component
// Input parameter : Form Object

function fnChangeEngineModuleForClassify(objForm)
{
   objForm.hdnEngineModel.value=objForm.lstEngineModel.options[objForm.lstEngineModel.selectedIndex].value;
   objForm.hdnScreenAction.value="ClassifyComponent";
   objForm.submit();
}


// This function is used to check if user has selected engine model

function fnSelectEngineModule(objForm)
{
   if(objForm.lstEngineModel.selectedIndex==0)
   {
       alertMsgs(eCRDSelect+ " Engine Model");
       objForm.lstEngineModel.focus();
   }
}

// This function is used to add the site name seletcted from source list to targetlist
// Input Parameters : SourceSiteList,TargetSiteList,objForm

function fnAddSite(SourceSiteList,TargetSiteList,objForm)
{
   fnMoveToHideSiteList(SourceSiteList,objForm.lstSiteListToHide);
   if(fnAddFromSourceListToTargetList(SourceSiteList,TargetSiteList))
   {
          objForm.txtPrimarySite.value = TargetSiteList.options[0].text;
   }
   //   sort(TargetSiteList);
}

// This function is used to move the site selected to site list to hide component
// Input Parameters : SourceSiteList,TargetSiteList

function fnMoveToHideSiteList(SourceSiteList,TargetSiteList)
{
   if(SourceSiteList.selectedIndex >= 0)
	{
      TargetValue = SourceSiteList.options[SourceSiteList.selectedIndex].value;
      TargetText = SourceSiteList.options[SourceSiteList.selectedIndex].text;
	   size = TargetSiteList.length;
      TargetSiteList.length = size + 1;
      TargetSiteList.options[size].value= TargetValue;
   	TargetSiteList.options[size].text = TargetText;
   }
}

// This function is used to move the site selected from the hide site list to the sites for which component hasto be hidden
function fnMoveToHiddenSitesList(objForm,SourceSiteList,TargetSiteList)
{
 var intCaratIndex = 0;
   var selectedSiteCode = '';
if(SourceSiteList.selectedIndex != -1)
{
	intCaratIndex = 	(SourceSiteList.options[SourceSiteList.selectedIndex].value).indexOf("^");

	selectedSiteCode =(SourceSiteList.options[SourceSiteList.selectedIndex].value).substring(0,intCaratIndex);



      if((objForm.hdnSites.value==selectedSiteCode) ||  objForm.hdnSites.value.toUpperCase()=="ALL")
      {
         fnAddFromSourceListToTargetList(SourceSiteList,TargetSiteList);
      }
      else
      {
      alertMsgs(eCRDNoAccessForChangingSite);
      }
   }
   else
   {
      alertMsgs(eCRDNoSiteToMove);
   }
}

// This function is used to move the site name from target list back to source list
// Input Parameters : SourceSiteList,TargetSiteList,objForm

function fnRemoveSite(SourceSiteList,TargetSiteList,objForm,strFrom)
{
   var intCaratIndex = 0;
   var selectedSiteCode = '';
   if(TargetSiteList.selectedIndex != -1)
   {
      intCaratIndex = 	(TargetSiteList.options[TargetSiteList.selectedIndex].value).indexOf("^");

      selectedSiteCode =(TargetSiteList.options[TargetSiteList.selectedIndex].value).substring(0,intCaratIndex);


      if(strFrom =="Approval")
      {
         if(objForm.hdnRequestorSite.value==selectedSiteCode)
         {
            alertMsgs(eCRDNoAccessForChangingSiteOfCreator);
            return false;
         }
      }
      if((objForm.hdnSites.value==selectedSiteCode) ||  objForm.hdnSites.value.toUpperCase()=="ALL")
      {
         if(objForm.hdnFlgChkUser.value=="true" && objForm.hdnSites.value.toUpperCase()!="ALL")
         {
         	alertMsgs(eCRDPendingApprovalCompSite);
         	return;
         }
         fnChangeHiddenSiteList(objForm,TargetSiteList);
         if(fnAddFromSourceListToTargetList(TargetSiteList,SourceSiteList))
         {
                  if(TargetSiteList.length!=0)
                  {
                     objForm.txtPrimarySite.value = TargetSiteList.options[0].text;
                  }
                  else
                  {
                     objForm.txtPrimarySite.value="";
                  }
         }
     }
     else
     {
              alertMsgs(eCRDNoAccessForChangingSite);
     }
   }
	else
	{
	   alertMsgs(eCRDNoSiteToMove);
	}
}

// This function is used to remove the site which is removed from associated site list
// also from the site list for which component has to be hidden.

function fnChangeHiddenSiteList(objForm,TargetSiteList)
{
   flag =-1;
   for(i =0;i<objForm.lstSiteListToHide.length;i++)
   {
      if(TargetSiteList.options[TargetSiteList.selectedIndex].text == objForm.lstSiteListToHide.options[i].text)
      {
         flag=i;
         for(j=i;j<objForm.lstSiteListToHide.length;j++)
         {
            if(j==objForm.lstSiteListToHide.length-1)
            {
               objForm.lstSiteListToHide.options[j] = null;
            }
            else
            {
                  objForm.lstSiteListToHide.options[j].text =objForm.lstSiteListToHide.options[j+1].text ;
                  objForm.lstSiteListToHide.options[j].value = objForm.lstSiteListToHide.options[j+1].value;
            }
         }
      }
   }
   if(flag==-1)
   {
      for(i =0;i<objForm.lstSitesHidden.length;i++)
      {
            if(TargetSiteList.options[TargetSiteList.selectedIndex].text == objForm.lstSitesHidden.options[i].text)
            {
                  for(j=i;j<objForm.lstSitesHidden.length;j++)
                  {
                     if(j==objForm.lstSitesHidden.length-1)
                     {
                        objForm.lstSitesHidden.options[j] = null;
                     }
                     else
                     {
                        objForm.lstSitesHidden.options[j].text =objForm.lstSitesHidden.options[j+1].text ;
                        objForm.lstSitesHidden.options[j].value = objForm.lstSitesHidden.options[j+1].value;
                     }
                 }
            }
         }
      }
   }

// This function is used to remove Part number form list
function fnRemovePart(SourceList)
{
 	if(SourceList.selectedIndex >= 0)
   {
      if(confirm(eCRDConfirmPartDeletion))
      {
         fnRemoveFromList(SourceList);
      }
   }
  	else
   {
		   alertMsgs(eCRDSelectPart);
   		SourceList.focus();
	   	return false;
  	}
}

// This function is used to move element down in the list
function fnMoveListDown(TargetList,strListName,objForm)
{

  var intCaratIndex = 0;
     var selectedSiteCode = '';
     if(TargetList.selectedIndex != -1)
     {
        intCaratIndex = 	(TargetList.options[TargetList.selectedIndex].value).indexOf("^");
         selectedSiteCode =(TargetList.options[TargetList.selectedIndex].value).substring(0,intCaratIndex);
     }
     if(objForm.hdnSites!=null)
     {
  if((objForm.hdnSites.value==selectedSiteCode) ||  objForm.hdnSites.value.toUpperCase()=="ALL")
       {
   	if(objForm.hdnFlgChkUser.value=="true" && objForm.hdnSites.value.toUpperCase()!="ALL")
   	{
   		alertMsgs(eCRDPendingApprovalCompSite);
   		return;
   	}

   	fnMoveDown(TargetList,strListName);
   if(strListName =="Site")
   {
      if(TargetList.options[0].text == 'All')
     	{
     	   objForm.txtPrimarySite.value = TargetList.options[1].text;
     	}
     	else
     	{
         objForm.txtPrimarySite.value = TargetList.options[0].text;
     	}
   }
   }
       else
       {
   	alertMsgs(eCRDNoAccessForChangingSite);
       }

 }
 else
 {
  fnMoveDown(TargetList,strListName);
 }
}

// This function is used to move element up in the list
function fnMoveListUp(TargetList,strListName,objForm)
{
 var intCaratIndex = 0;
     var selectedSiteCode = '';
     if(TargetList.selectedIndex != -1)
     {
        intCaratIndex = 	(TargetList.options[TargetList.selectedIndex].value).indexOf("^");
         selectedSiteCode =(TargetList.options[TargetList.selectedIndex].value).substring(0,intCaratIndex);
     }
     if(objForm.hdnSites!=null)
     {
    if((objForm.hdnSites.value==selectedSiteCode) ||  objForm.hdnSites.value.toUpperCase()=="ALL")
    {
	if(objForm.hdnFlgChkUser.value=="true" && objForm.hdnSites.value.toUpperCase()!="ALL")
	{
		alertMsgs(eCRDPendingApprovalCompSite);
		return;
	}
	fnMoveUp(TargetList,strListName);
	if(strListName =="Site")
	{
		if(TargetList.options[0].text == 'All')
		{
				objForm.txtPrimarySite.value = TargetList.options[1].text;
		}
		else
		{
		   objForm.txtPrimarySite.value = TargetList.options[0].text;
		}
     	}
    }
    else
    {
	alertMsgs(eCRDNoAccessForChangingSite);
    }
    }
    else
    {
    	fnMoveUp(TargetList,strListName);
    }
}

// This function is used to convert string into uppercase
function fnConvUpperCase(inputString)
{
	var finalData='';
	for(var cntLn=0;cntLn<inputString.length;cntLn++)
	{
		var store=inputString.substring(cntLn,cntLn+1);
		if((store>='a')||(store <='z')||(store>='A')||(store <='Z'))
		{
			finalData+= store.toUpperCase();
		}
		else
		{
			finalData+= store;
		}
	}
	return finalData;
}

// This function is used to check if ATA reference number is in correct format
function isATANum(ataNum)
{
	ataNum = fnConvUpperCase(ataNum);
	if(ataNum.substring(0,3)=="GEK")
	{
		/*if(ataNum.substring(3,4)!=" ")
		{
			return false;
		}*/
		return true;
	}
	else if(ataNum.substring(0,2)=="TO")
	{
		if(ataNum.substring(2,3)!=" ")
		{
			return false;
		}
	}
	else if(ataNum.length!=8)
	{
		return false;
	}
	else if((ataNum.substring(2,3)!='-') || (ataNum.substring(5,6)!='-')||(isNaN(ataNum.substring(0,2))) || (isNaN(ataNum.substring(3,5)))||(isNaN(ataNum.substring(6,8))))
	{
		return false;
	}
   return true;
}

// This function is used to update component details
function fnUpdateComponent(objForm,strSiteOnly)
{
   // strSiteOnly = false ---- Only site information has to be saved
   var strSites = "";
   var strList ="";
   var strListText = "";
   if(strSiteOnly=="false")
   {
      if(objForm.lstSitesAssiciated.length==0)
      {
         alertMsgs(eCRDSelectSite);
         objForm.lstClass.focus();
         return false;
      }
      for(i=0; i< objForm.lstSitesAssiciated.length; i++)
      {
         strSites = strSites + objForm.lstSitesAssiciated.options[i].text;
         strList =    strList + objForm.lstSitesAssiciated.options[i].value;
         strListText =    objForm.lstSitesAssiciated.options[i].text;
         strHideCompInd = "N";
         for(j = 0 ;j<objForm.lstSitesHidden.length;j++)
         {
            if(objForm.lstSitesHidden.options[j].text == objForm.lstSitesAssiciated.options[i].text)
            {
               strHideCompInd = "Y";
            }
         }
         if( i != objForm.lstSitesAssiciated.length)
         {
            strList =    strList + eCRDDelimiter + strListText +eCRDDelimiter + strHideCompInd + eCRDDelimiter;
            strSites = strSites + eCRDDelimiter;
         }
      }
      objForm.hdnSitesAssiciatedText.value = strSites;
      objForm.hdnSitesAssiciated.value = strList;
      objForm.hdnScreenAction.value = "eCRDUpdateComponentSite";
      objForm.submit();
   }
   else
   {
      if(fnValidateComponentDetails(objForm,"Modify"))
      {
           objForm.hdnScreenAction.value = "eCRDUpdateComponent";
           objForm.submit();
      }
   }
}


// This function is used to validate component details screen
function fnValidateComponentDetails(objForm,strOperation)
{
   var strList="";
   var strListText="";
   var strSites = "";
   strValue = fnTrim(objForm.txtComponentDescription.value);
   if(strValue =="")
   {
        alertMsgs(eCRDempty + "Component Description");
        objForm.txtComponentDescription.value= "";
        objForm.txtComponentDescription.focus();
        return false;
   }
    if(!fnCheckSplChars(objForm.txtComponentDescription))
   {
       objForm.txtComponentDescription.focus();
       alertMsgs(eCRDSpecialChars + " For Component Description");
 	    return false;
   }
   strValue = fnTrim(objForm.txtATAReferenceNumber.value);
   if(strValue =="")
   {
        alertMsgs(eCRDempty + "ATA Reference Number");
        objForm.txtATAReferenceNumber.value= "";
        objForm.txtATAReferenceNumber.focus();
        return false;
   }
   if(!isATANum(objForm.txtATAReferenceNumber.value))
   {
      alertMsgs(eCRDATAFormat);
      objForm.txtATAReferenceNumber.focus();
      objForm.txtATAReferenceNumber.select();
      return false;
   }
   strValue = fnTrim(objForm.txtBaselineTAT.value);
   if(strValue =="")
   {
        alertMsgs(eCRDempty + "Baseline TAT");
        objForm.txtBaselineTAT.value= "";
        objForm.txtBaselineTAT.focus();
        return false;
   }
   if(isNaN(objForm.txtBaselineTAT.value))
   {
      alertMsgs("Baseline TAT "+eCRDNotNumeric);
      objForm.txtBaselineTAT.focus();
      objForm.txtBaselineTAT.select();
      return false;
   }
   if(objForm.txtBaselineTAT.value.indexOf("-")!=-1)
   {
      alertMsgs("Baseline TAT "+eCRDNonNegative);
      objForm.txtBaselineTAT.focus();
      objForm.txtBaselineTAT.select();
      return false;
   }
   if(strOperation=="Add")
   {
      if(objForm.sel_man_Startdate_DD.value=="")
      {
         alertMsgs(eCRDSelectDate);
         objForm.sel_man_Startdate_DD.focus();
         return false;
      }
      if(objForm.sel_man_Startdate_MM.value=="")
      {
         alertMsgs(eCRDSelectMonth);
         objForm.sel_man_Startdate_MM.focus();
         return false;
      }
      if(objForm.sel_man_Startdate_YYYY.value=="")
      {
         alertMsgs(eCRDSelectYear);
         objForm.sel_man_Startdate_YYYY.focus();
         return false;
      }
      if(!fnValidateCalenderDate(objForm))
      {
         alertMsgs("Component" + eCRDEffectiveDate);
         return false;
      }
   }

   if(strOperation=="Approve")
   {
      if(objForm.sel_man_Startdate_DD.value=="")
      {
         alertMsgs(eCRDSelectDate);
         objForm.sel_man_Startdate_DD.focus();
         return false;
      }
      if(objForm.sel_man_Startdate_MM.value=="")
      {
         alertMsgs(eCRDSelectMonth);
         objForm.sel_man_Startdate_MM.focus();
         return false;
      }
      if(objForm.sel_man_Startdate_YYYY.value=="")
      {
         alertMsgs(eCRDSelectYear);
         objForm.sel_man_Startdate_YYYY.focus();
         return false;
      }

      if(!fnValidateCalenderDate(objForm))
      {
            var dayVal = objForm.sel_man_Startdate_DD.value;
           	var monthVal = objForm.sel_man_Startdate_MM.value;
            var yearVal = objForm.sel_man_Startdate_YYYY.value;
            var fullDateVal =yearVal+ "/" + monthVal + "/"  + dayVal;
            var CompEffDateVal =objForm.hdnComponentEffDate.value;
            arrayOfStrings = objForm.hdnComponentEffDate.value.split("/");
            strCompEffDayToDisplay = arrayOfStrings[1]+"/"+arrayOfStrings[2]+"/"+arrayOfStrings[0];
            if(fnCompareDateFromTo(fullDateVal,CompEffDateVal) == false)
            {
               alertMsgs(eCRDComponentEfftDate+"("+strCompEffDayToDisplay+")");
               return false;
            }
//         alertMsgs("Component" + eCRDEffectiveDate);
  //       return false;
      }
   }

   if(objForm.chkAlternateComponent.checked)
   {
      objForm.hdnAltComponent.value = "Y";
   }
   else
   {
      objForm.hdnAltComponent.value = "N";
   }
   if(objForm.txtQuantityPartsPerSet.value!="")
   {
      if(isNaN(objForm.txtQuantityPartsPerSet.value))
      {
         alertMsgs("Quantity Parts Per Set "+eCRDNotNumeric);
         objForm.txtQuantityPartsPerSet.focus();
         objForm.txtQuantityPartsPerSet.select();
         return false;
      }
   }
   if(objForm.txtComponentShopVisitExposureRate.value!="")
   {
       if(isNaN(objForm.txtComponentShopVisitExposureRate.value))
       {
          alertMsgs("Component Shop Visit Exposure Rate "+eCRDNotNumeric);
          objForm.txtComponentShopVisitExposureRate.focus();
          objForm.txtComponentShopVisitExposureRate.select();
          return false;
       }
       if(parseFloat(objForm.txtComponentShopVisitExposureRate.value) > 999.99)
       {
           alertMsgs("Component Shop Visit Exposure Rate " + eCRDMaxLimitExceeded);
           objForm.txtComponentShopVisitExposureRate.focus();
           objForm.txtComponentShopVisitExposureRate.select();
           return false;
       }
   }
   if(objForm.txtComponentScrapExposureRate.value!="")
   {
      if(isNaN(objForm.txtComponentScrapExposureRate.value))
      {
         alertMsgs("Component Scrap Exposure Rate "+eCRDNotNumeric);
         objForm.txtComponentScrapExposureRate.focus();
         objForm.txtComponentScrapExposureRate.select();
         return false;
      }
      if(parseFloat(objForm.txtComponentScrapExposureRate.value) > 999.99)
      {
        alertMsgs("Component Scrap Exposure Rate " + eCRDMaxLimitExceeded);
        objForm.txtComponentScrapExposureRate.focus();
        objForm.txtComponentScrapExposureRate.select();
        return false;
      }
    }
    if(objForm.txtServiceableAtExposureRate.value!="")
    {
       if(isNaN(objForm.txtServiceableAtExposureRate.value))
       {
           alertMsgs("Serviceable At Exposure Rate "+eCRDNotNumeric);
           objForm.txtServiceableAtExposureRate.focus();
           objForm.txtServiceableAtExposureRate.select();
           return false;
       }
       if(parseFloat(objForm.txtServiceableAtExposureRate.value) > 999.99)
       {
          alertMsgs("Serviceable At Exposure Rate " + eCRDMaxLimitExceeded);
          objForm.txtServiceableAtExposureRate.focus();
          objForm.txtServiceableAtExposureRate.select();
          return false;
      }
    }
    if(objForm.txtAgeRepairYield.value!="")
    {
      if(isNaN(objForm.txtAgeRepairYield.value))
      {
         alertMsgs("% Age Repair Yield "+eCRDNotNumeric);
         objForm.txtAgeRepairYield.focus();
         objForm.txtAgeRepairYield.select();
         return false;
      }
       if(parseFloat(objForm.txtAgeRepairYield.value) > 999.99)
       {
          alertMsgs("% Age Repair Yield " + eCRDMaxLimitExceeded);
          objForm.txtAgeRepairYield.focus();
          objForm.txtAgeRepairYield.select();
          return false;
      }
    }
    if(objForm.lstClass.selectedIndex==0)
   {
      alertMsgs(eCRDSelectClass);
      objForm.lstClass.focus();
      return false;
   }
   if(objForm.lstSitesAssiciated.length==0)
   {
      alertMsgs(eCRDSelectSite);
      objForm.lstSite.focus();
      return false;
   }
   for(i=0; i< objForm.lstSitesAssiciated.length; i++)
    {
       strSites = strSites + objForm.lstSitesAssiciated.options[i].text;
       strList =    strList + objForm.lstSitesAssiciated.options[i].value;
       strListText =    objForm.lstSitesAssiciated.options[i].text;
       strHideCompInd = "N";
       for(j = 0 ;j<objForm.lstSitesHidden.length;j++)
       {
          if(objForm.lstSitesHidden.options[j].text == objForm.lstSitesAssiciated.options[i].text)
          {
             strHideCompInd = "Y";
          }
       }
       if( i != objForm.lstSitesAssiciated.length)
       {
          strList =    strList + eCRDDelimiter + strListText +eCRDDelimiter + strHideCompInd +eCRDDelimiter ;
          strSites = strSites + eCRDDelimiter;
       }
    }
    objForm.hdnSitesAssiciatedText.value = strSites;
    objForm.hdnSitesAssiciated.value = strList;
    strList = "";

// Added new for Hidden Site List
    strSites = "";
    for(i=0; i< objForm.lstSitesHidden.length; i++)
    {
       strSites = strSites + objForm.lstSitesHidden.options[i].text;
       strList =    strList + objForm.lstSitesHidden.options[i].value;
       strListText =    objForm.lstSitesHidden.options[i].text;
       if( i != objForm.lstSitesHidden.length)
       {
          strList =    strList + eCRDDelimiter + strListText +eCRDDelimiter;
          strSites = strSites + eCRDDelimiter;
       }
    }
    objForm.hdnHiddenSitesText.value = strSites;
    objForm.hdnSitesHidden.value = strList;
	
	if(!fnCheckSplChars(objForm.txtPartNumber))
   {
        objForm.txtPartNumber.focus();
        alertMsgs(eCRDSpecialChars + " For Part Number");
       return false;
   }
	
    strList = "";

// End of new code

    for(i=0; i< objForm.lstPartNumbers.length; i++)
    {
       strList =    strList + objForm.lstPartNumbers.options[i].value;
       if( i != objForm.lstPartNumbers.length-1)
       {
               strList =    strList + eCRDDelimiter;
        }
     }
     objForm.hdnPartNumbers.value = strList;
     return true;
}


// This function is used to validate Component details while adding new component
function fnValidateAddComponentDetails(objForm,strRepairType)
{
   if(objForm.txtComponentCode.value.indexOf(" ")!=-1)
   {
         alertMsgs(eCRDWhiteSpacesNotAllowed);
         objForm.txtComponentCode.value= "";
         objForm.txtComponentCode.focus();
         return false;
   }
   strValue = fnTrim(objForm.txtComponentCode.value);
   if(strValue =="")
   {
         alertMsgs(eCRDempty + "Component Code");
         objForm.txtComponentCode.value= "";
         objForm.txtComponentCode.focus();
         return false;
   }
   if(!fnCheckSplChars(objForm.txtComponentCode))
   {
        objForm.txtComponentCode.focus();
        alertMsgs(eCRDSpecialChars + " For Component Code");
       return false;
   }
   if(fnValidateComponentDetails(objForm,"Add"))
   {
      objForm.hdnRepairType.value = strRepairType;
      objForm.submit();
   }
   
}


// This function is used to validate date
function fnValidateCalenderDate(objForm)
{
 	var sysFullDate = objForm.hdnSysDate.value;
   var dayVal = objForm.sel_man_Startdate_DD.value;
  	var monthVal = objForm.sel_man_Startdate_MM.value;
   var yearVal = objForm.sel_man_Startdate_YYYY.value;
   var fullDateVal =yearVal+ "/" + monthVal + "/"  + dayVal;
	if(fnCompareDateFromTo(fullDateVal,sysFullDate) == false)
	{
		return false;
	}
	return true;
}

// This function is used to compare two dates
function fnCompareDateFromTo(start,end)
{
    if ( Date.parse(start)>=Date.parse(end))
    {
         return true;
    }
    else
    {
       return false;
    }
}

// This function is used to modify component details
function fnValidateModifyComponent(objForm)
{
   if(objForm.lstEngineModel.selectedIndex==0)
   {
       alertMsgs(eCRDSelEngModel);
       objForm.lstEngineModel.focus();
       return false;
   }
   else
   {
       if(objForm.lstEngineModule.selectedIndex==0)
      {
          alertMsgs(eCRDSelEngModule);
          objForm.lstEngineModule.focus();
          return false;
      }
      if(objForm.lstComponent.selectedIndex==0 )
      {
         alertMsgs(eCRDSelect+ " Component Code/Description");
         objForm.lstComponent.focus();
         return false;
      }
      if(objForm.txtComponent.value=="")
      {
         objForm.txtComponent.focus();
         alertMsgs(eCRDempty + "Component "  +objForm.lstComponent.options[objForm.lstComponent.selectedIndex].text);
         return false;
      }
      if(objForm.txtATANumber.value!="")
      {
         if(!isATANum(objForm.txtATANumber.value))
         {
            alertMsgs(eCRDATAFormat);
            objForm.txtATAReferenceNumber.focus();
            return false;
         }
      }
      if(objForm.hdnComponentCode.value=="")
      {
         if(objForm.lstComponent.options[objForm.lstComponent.selectedIndex].text=="Description")
         {
            if(objForm.txtComponent.value=="")
            {
                 alertMsgs(eCRDempty + "Component Description");
                 return false;
            }
         }
      }
      objForm.hdnComponent.value =objForm.lstComponent.options[objForm.lstComponent.selectedIndex].text;
      objForm.hdnComponentCode.value = objForm.txtComponent.value;
      objForm.hdnComponentType.value =objForm.lstComponent.options[objForm.lstComponent.selectedIndex].value;
      objForm.hdnEngineModuleDesc.value= objForm.lstEngineModule.options[objForm.lstEngineModule.selectedIndex].text;
      objForm.hdnEngineModel.value = objForm.lstEngineModel.options[objForm.lstEngineModel.selectedIndex].value;
      objForm.hdnEngineModule.value = objForm.lstEngineModule.options[objForm.lstEngineModule.selectedIndex].value;
      objForm.hdnCheckOperation.value="Modify";
      objForm.hdnScreenAction.value="eCRDComponentDetails";
      objForm.submit();
   }
}

// This function is used to get the component code associated with the
// selected component
function fnGetComponentValue(CompCode,CompDesc,objForm)
{
   if(objForm.hdnComponent.value=="Code")
   {
       objForm.hdnComponentValue.value = CompCode;
   }
   if(objForm.hdnComponent.value=="Description")
   {
       objForm.hdnComponentValue.value = CompDesc;
   }
}

// This function is used to submit component table form
function fnSubmitComponentTable(objForm)
{
   if(window.opener.document.frmModifyComponent!=null)
	{
      window.opener.document.frmModifyComponent.txtComponent.value = objForm.hdnComponentValue.value;
	}
	else if(window.opener.document.frmMapComponent!=null)
	{


      window.opener.document.frmMapComponent.txtComponent.value = objForm.hdnComponentValue.value;
//9292_eCRD_Site Mapping      
      window.opener.document.frmMapComponent.hdnEngineModel.value=window.opener.document.frmMapComponent.lstEngineModel.options[window.opener.document.frmMapComponent.lstEngineModel.selectedIndex].value;
      window.opener.document.frmMapComponent.hdnEngineModule.value=window.opener.document.frmMapComponent.lstEngineModule.options[window.opener.document.frmMapComponent.lstEngineModule.selectedIndex].value;
      window.opener.document.frmMapComponent.hdnComponentType.value=window.opener.document.frmMapComponent.lstComponent.options[window.opener.document.frmMapComponent.lstComponent.selectedIndex].value;
      window.opener.document.frmMapComponent.hdnComponent.value=window.opener.document.frmMapComponent.lstComponent.options[window.opener.document.frmMapComponent.lstComponent.selectedIndex].text;
      window.opener.document.frmMapComponent.hdnComponentCode.value=window.opener.document.frmMapComponent.txtComponent.value;
      window.opener.document.frmMapComponent.hdnComponentDesc.value=window.opener.document.frmMapComponent.txtComponent.value;
//end
      window.opener.document.frmMapComponent.submit();
      
	}
	else if(window.opener.document.frmAddRepair!=null)
	{
      window.opener.document.frmAddRepair.txtComponent.value = objForm.hdnComponentValue.value;
	}
   else if(window.opener.document.frmPriceAdjustment!=null)
	{
      window.opener.document.frmPriceAdjustment.txtComponent.value = objForm.hdnComponentValue.value;
	}
	else if(window.opener.document.frmViewModifyComponent!=null)
	{
      window.opener.document.frmViewModifyComponent.txtComponent.value = objForm.hdnComponentValue.value;
	}
   self.close();
}


// This function is used to pop up the component table page
function fnPopComponentTable(objForm,basePath)
{
   var strEngineModel = objForm.lstEngineModel.options[objForm.lstEngineModel.selectedIndex].value;
   var strEngineModule = objForm.lstEngineModule.options[objForm.lstEngineModule.selectedIndex].value;
   if(objForm.lstEngineModel.selectedIndex==0 || strEngineModel=="")
   {
       alertMsgs(eCRDSelEngModel);
       objForm.lstEngineModel.focus();
       return false;
   }
    if(objForm.lstEngineModule.selectedIndex==0)
   {
          alertMsgs(eCRDSelEngModule);
          objForm.lstEngineModule.focus();
          return false;
   }
   if(objForm.lstComponent.selectedIndex==0)
   {
       alertMsgs(eCRDSelect+ " Component Code / Description");
       objForm.lstComponent.focus();
       return false;
   }
   strATAReference = objForm.txtATANumber.value;
   if(strATAReference!="")
   {
      if(!isATANum(strATAReference))
      {
         alertMsgs(eCRDATAFormat);
         objForm.txtATANumber.focus();
         return false;
      }
   }
   var strComponentCode = objForm.txtComponent.value;
   if(strComponentCode=="")
   {
      objForm.txtComponent.focus();
      alertMsgs(eCRDempty + "Component "  +objForm.lstComponent.options[objForm.lstComponent.selectedIndex].text);
      return false;
   }
   else
   {
      strComponent =  objForm.lstComponent.options[objForm.lstComponent.selectedIndex].text;
      features='toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,width=500,height=300';
      dlg = window.open (basePath+"/ecrd?hdnScreenName=eCRDManageComponent&hdnScreenAction=eCRDComponentTable&hdnEngineModuleDesc=" + strEngineModule +"&hdnEngineModelDesc=" + strEngineModel + "&hdnComponent=" + strComponent +"&hdnComponentValue=" + strComponentCode+"&hdnATAReference=" + strATAReference +"&RandomValue="+Math.random(),"Dialog",features);
   }
}

// This function is used to close the popped up window
function fnCancel()
{
   self.close();
}

// This function is used to delete component
function fnDeleteComponent(objForm)
{
   if(confirm(eCRDConfirmCompDelete))
   {
      objForm.hdnScreenAction.value = "eCRDDeleteComponent";
      objForm.submit();
   }
}


function fnContinue(objForm)
{
   if(fnValidateComponentDetails(objForm,"Approve"))
   {
      objForm.submit();
   }
}

function fnSubmitReadOnly(objForm)
{
   //                "ViewRepairs"
   objForm.hdnScreenName.value = "ViewRepairs";
   objForm.hdnScreenAction.value = "ViewRepairs";
   objForm.submit();
}

function fnConvertToUpper(objTxtBox)
{
	objTxtBox.value = objTxtBox.value.toUpperCase();
}

