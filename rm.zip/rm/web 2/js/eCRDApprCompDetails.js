function fnApprove()
{
	if(fnValidateCompAppr())
	{
		if(!fnValidateDate())
		{
			return false;
		}
      if(!fnValidateCalenderDate(document.frmAppExtComp))
      {
         arrayOfStrings =  document.frmAppExtComp.hdnCompEffDate.value.split("/");
         strCompEffDayToDisplay = arrayOfStrings[1]+"/"+arrayOfStrings[2]+"/"+arrayOfStrings[0];
         alertMsgs(eCRDCheckCompEffDate + strCompEffDayToDisplay);
         return false;
      }
      if(fnLtrim(document.frmAppExtComp.txtArRejCom.value)!= "" )
		{
			alert("You can not enter Rejection Comments while approving.");
			return false;
		}
		else
		{
			document.frmAppExtComp.hdnScreenName.value='ApprCompDet';
			document.frmAppExtComp.hdnScreenAction.value='eCRDInsertCompApprovalDet';
		//	alert(document.frmAppExtComp.lstClass.options[document.frmAppExtComp.lstClass.selectedIndex].value);

			if(document.frmAppExtComp.lstClass.options[document.frmAppExtComp.lstClass.selectedIndex].value == "")
			{
				alertMsgs(eCRDSelectClass);
            document.frmAppExtComp.lstClass.focus();
				return false;
			}
			document.frmAppExtComp.hdnClass.value=document.frmAppExtComp.lstClass.options[document.frmAppExtComp.lstClass.selectedIndex].value;
			document.frmAppExtComp.submit();
		}
		
	}
}
function fnReject()
{
		if(fnLtrim(document.frmAppExtComp.txtArRejCom.value)== "" || document.frmAppExtComp.txtArRejCom.value == null)
		{
			alertMsgs(eCRDRejectComments);
			return false;
		}
      if(document.frmAppExtComp.txtArRejCom.value.length > 250)
      {

         alertMsgs(eCRDRejectLength);
         document.frmAppExtComp.txtArRejCom.focus();
         return false;
      }
		else
		{
         document.frmAppExtComp.hdnScreenName.value='ApprCompDet';
         document.frmAppExtComp.hdnScreenAction.value='eCRDRejectComponent';
         document.frmAppExtComp.submit();	
		}
}

function fnValidateCompAppr()
{
	strValue = fnTrim(document.frmAppExtComp.txtCompDesc.value);
   if(strValue =="")
   {
        alertMsgs(eCRDempty + "Component Description");
        document.frmAppExtComp.txtCompDesc.value= "";
        document.frmAppExtComp.txtCompDesc.focus();
        return false;
   }
   if(!fnCheckSplChars(document.frmAppExtComp.txtCompDesc))
   {
       document.frmAppExtComp.txtCompDesc.focus();
       alertMsgs(eCRDSpecialChars + " For Component Description");
 	    return false;
   }
/*if(document.frmAppExtComp.txtCompDesc.value =="" || document.frmAppExtComp.txtCompDesc.value == null)
	{
		alertMsgs(eCRDComponentDesc);
		return false;
	}
*/
   strValue = fnTrim(document.frmAppExtComp.txtAtaRef.value);
   if(strValue =="")
   {
        alertMsgs(eCRDempty + "ATA Reference Number");
        document.frmAppExtComp.txtAtaRef.value= "";
        document.frmAppExtComp.txtAtaRef.focus();
        return false;
   }
   if(!isATANum(document.frmAppExtComp.txtAtaRef.value))
   {
      alertMsgs(eCRDATAFormat);
      document.frmAppExtComp.txtAtaRef.focus();
      document.frmAppExtComp.txtAtaRef.select();
      return false;
   }
/*if(document.frmAppExtComp.txtAtaRef.value=="" || document.frmAppExtComp.txtAtaRef.value == null)
	{
		alertMsgs(eCRDEnter+"ATA Reference Number");
		return false;
	}*/
/*if(document.frmAppExtComp.txtBaseTat.value=="" || document.frmAppExtComp.txtBaseTat.value == null)
	{
		alertMsgs(eCRDEnter+"Base Line TAT");
		return false;
	}*/
   strValue = fnTrim(document.frmAppExtComp.txtBaseTat.value);
   if(strValue =="")
   {
        alertMsgs(eCRDempty + "Baseline TAT");
        document.frmAppExtComp.txtBaseTat.value= "";
        document.frmAppExtComp.txtBaseTat.focus();
        return false;
   }
   if(isNaN(document.frmAppExtComp.txtBaseTat.value))
   {
      alertMsgs("Baseline TAT "+eCRDNotNumeric);
      document.frmAppExtComp.txtBaseTat.focus();
      document.frmAppExtComp.txtBaseTat.select();
      return false;
   }
   if(document.frmAppExtComp.txtBaseTat.value.indexOf("-")!=-1)
   {
      alertMsgs("Baseline TAT "+eCRDNonNegative);
      document.frmAppExtComp.txtBaseTat.focus();
      document.frmAppExtComp.txtBaseTat.select();
      return false;
   }
   if(document.frmAppExtComp.txtQtySet.value!="")
   {
      if(isNaN(document.frmAppExtComp.txtQtySet.value))
      {
         alertMsgs("Quantity Parts Per Set "+eCRDNotNumeric);
         document.frmAppExtComp.txtQtySet.focus();
         document.frmAppExtComp.txtQtySet.select();
         return false;
      }
   }
    if(document.frmAppExtComp.txtSvRate.value!="")
   {
       if(isNaN(document.frmAppExtComp.txtSvRate.value))
       {
          alertMsgs("Component Shop Visit Exposure Rate "+eCRDNotNumeric);
          document.frmAppExtComp.txtSvRate.focus();
          document.frmAppExtComp.txtSvRate.select();
          return false;
       }
       if(parseFloat(document.frmAppExtComp.txtSvRate.value) > 999.99)
       {
           alertMsgs("Component Shop Visit Exposure Rate " + eCRDMaxLimitExceeded);
           document.frmAppExtComp.txtSvRate.focus();
           document.frmAppExtComp.txtSvRate.select();
           return false;
       }
   }
   if(document.frmAppExtComp.txtScrapRate.value!="")
   {
      if(isNaN(document.frmAppExtComp.txtScrapRate.value))
      {
         alertMsgs("Component Scrap Exposure Rate "+eCRDNotNumeric);
         document.frmAppExtComp.txtScrapRate.focus();
         document.frmAppExtComp.txtScrapRate.select();
         return false;
      }
      if(parseFloat(document.frmAppExtComp.txtScrapRate.value) > 999.99)
      {
        alertMsgs("Component Scrap Exposure Rate " + eCRDMaxLimitExceeded);
        document.frmAppExtComp.txtScrapRate.focus();
        document.frmAppExtComp.txtScrapRate.select();
        return false;
      }
    }
    if(document.frmAppExtComp.txtServRate.value!="")
    {
       if(isNaN(document.frmAppExtComp.txtServRate.value))
       {
           alertMsgs("Serviceable At Exposure Rate "+eCRDNotNumeric);
           document.frmAppExtComp.txtServRate.focus();
           document.frmAppExtComp.txtServRate.select();
           return false;
       }
       if(parseFloat(document.frmAppExtComp.txtServRate.value) > 999.99)
       {
          alertMsgs("Serviceable At Exposure Rate " + eCRDMaxLimitExceeded);
          document.frmAppExtComp.txtServRate.focus();
          document.frmAppExtComp.txtServRate.select();
          return false;
      }
    }
    if(document.frmAppExtComp.txtAgeYield.value!="")
    {
      if(isNaN(document.frmAppExtComp.txtAgeYield.value))
      {
         alertMsgs("% Age Repair Yield "+eCRDNotNumeric);
         document.frmAppExtComp.txtAgeYield.focus();
         document.frmAppExtComp.txtAgeYield.select();
         return false;
      }
       if(parseFloat(document.frmAppExtComp.txtAgeYield.value) > 999.99)
       {
          alertMsgs("% Age Repair Yield " + eCRDMaxLimitExceeded);
          document.frmAppExtComp.txtAgeYield.focus();
          document.frmAppExtComp.txtAgeYield.select();
          return false;
      }
    }
	return true;
}

function fnApproveSites(objForm,STRCOLUMNDELIM,STRROWDELIM)
{

	var strValue		= "";
	var strParam		= "";
	var strComment		= "";
	with(objForm)
	{
			
		for(count=0 ; count < elements.length ; count++)
		{
			if(elements[count].checked)
			{
				strValue = elements[count].value;
				if(elements[count+1].name == "txtComment")
				{
					if(fnTrim(elements[count+1].value) == "" || elements[count+1].value == null)
						{
							alertMsgs(eCRDRejectComments);
							elements[count+1].focus();
							return false;
						}
			         if(elements[count+1].value.length >250 )
						{
							alertMsgs(eCRDRejectLength);
							elements[count+1].focus();
							return false;
						}
							
					strComment = elements[count+1].value+STRCOLUMNDELIM;
				}
				else
				{
					strComment = elements[count+2].value+STRCOLUMNDELIM;
				}
				strParam = strParam + strValue+ STRCOLUMNDELIM + strComment + STRROWDELIM;

							
			}
			
		}
	}

	if(strParam == "" || strParam == null)
	{
		alertMsgs(eCRDComponent);
		return false;
	}
	with(document.frmSaveApproveComponent)
	{
		hdnInputParam.value = strParam;
		submit();
	}
	
}


function fnShowHistory(strComponentCode,strModuleCode)
{
	
   features='toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,width=700,height=400';
	dlg = window.open (basePath+"/ecrd?hdnScreenName=ApprCompDet&hdnScreenAction=eCRDShowComponentApprHist&hdnCompCode="+strComponentCode+"&hdnModuleCode="+strModuleCode+"&RandomValue="+Math.random(),"Dialog",features);

}

function fnValidateDate()
{
  with(document.frmAppExtComp)
    {
	  
        strStartDate=fnConvertToString(sel_man_Startdate_DD,sel_man_Startdate_MM,sel_man_Startdate_YYYY);
        if(!fnValidateDateString(strStartDate))
         {
			sel_man_Startdate_DD.focus();
		    return false;
         }
		 else
			return true;
	} 
}

function fnConvertToString(dayDD,monthDD,yearDD)
{

   var dayVal = dayDD.options[dayDD.selectedIndex].value;
   var monthVal = monthDD.options[monthDD.selectedIndex].value;
   var yearVal = yearDD.options[yearDD.selectedIndex].value;
   var fullDateVal =monthVal + "/"  + dayVal+"/"+yearVal;
   return fullDateVal;
}
function fnClose()
{
		window.close();		

}

function isATANum(ataNum)
{
	ataNum = fnConvUpperCase(ataNum);
	if(ataNum.substring(0,3)=="GEK")
	{
		/*if(ataNum.substring(3,4)!=" ")
		{
			return false;
		}*/
          return true;
	}
	else if(ataNum.substring(0,2)=="TO")
	{
		if(ataNum.substring(2,3)!=" ")
		{
			return false;
		}
	}
	else if(ataNum.length!=8)
	{
		return false;
	}
	else if((ataNum.substring(2,3)!='-') || (ataNum.substring(5,6)!='-')||(isNaN(ataNum.substring(0,2))) || (isNaN(ataNum.substring(3,5)))||(isNaN(ataNum.substring(6,8))))
	{
		return false;
	}
   return true;
}
function fnConvUpperCase(inputString)
{
	var finalData='';
	for(var cntLn=0;cntLn<inputString.length;cntLn++)
	{
		var store=inputString.substring(cntLn,cntLn+1);
		if((store>='a')||(store <='z')||(store>='A')||(store <='Z'))
		{
			finalData+= store.toUpperCase();
		}
		else
		{
			finalData+= store;
		}
	}
	return finalData;
}

function fnCompareDateFromTo(start,end)
{
    if ( Date.parse(start)>=Date.parse(end))
    {
         return true;
    }
    else
    {
       return false;
    }
}

function fnValidateCalenderDate(objForm)
{
 	var strCompEffDate = objForm.hdnCompEffDate.value;
   var dayVal = objForm.sel_man_Startdate_DD.value;
  	var monthVal = objForm.sel_man_Startdate_MM.value;
   var yearVal = objForm.sel_man_Startdate_YYYY.value;
   var fullDateVal =yearVal+ "/" + monthVal + "/"  + dayVal;
	if(fnCompareDateFromTo(fullDateVal,strCompEffDate) == false)
	{
		return false;
	}
	return true;
}