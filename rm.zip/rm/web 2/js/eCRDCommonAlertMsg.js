

/**beginning changes by rishabh mewar **/

var eCRDSelRepairInd	= "Please Select Repair Indicator.";	
var eCRDSelCatalogInd	= "Please Select Catalog Indicator.";	
var eCRDCompareRepairInd = "selected Repair Indicator is not associated with selected Repair";	
var eCRDRepairType		= "Please Select Code or Description from the Repair dropdown.";
var eCRDRepairCode		= "Please enter the Repair Code.";
var eCRDRepairDesc		= "Please enter the Repair Description.";

/**end of changes by rishabh mewar **/




var wildCharArray = ['*','&','#','@','<','>','?','/','~',',','`','\'','"','\\','%'];
var eCRD1 		= "This is an eCRD alert.";
var eCRDSelEngFamily	= "Please select an Engine Family.";
var eCRDEngineCode 	= "Please Enter Engine Code.";
var eCRDEngineDescription 	= "Please Enter Engine Description.";
/* 5/5/2006 Patni For eCRD Phase I Enhancement Begin
Added the validation for Catalog Description to be Not NULL*/
var eCRDCatalogDescription 	= "Please Enter Catalog Description.";
/* 5/5/2006 Patni For eCRD Phase I Enhancement End
Added the validation for Catalog Description to be Not NULL*/
var eCRDStartDate	= "Please select Start Date.";
var eCRDEndDate		= "Please select End Date.";
var eCRDDateMismatch	= "Please select End Date greater than Start Date.";
/* 25/5/2006 Patni For eCRD Phase I Enhancement Begin
Added validation to check Contract End Date to be less or equal to End date of Catalog*/
var eCRDContractDateMismatch	= "Please select Contract End Date lesser than or equal to Catalog End Date.";
/* 25/5/2006 Patni For eCRD Phase I Enhancement End
Added validation to check Contract End Date to be less or equal to End date of Catalog*/
var eCRDSelEngModel	= "Please Select Engine Model.";
var eCRDSelEngModule	= "Please Select Engine Module.";
var eCRDDupValues  	= "Entered Value Aready Exists.";
var eCRDSpecialChars = "Special Characters Are Not Allowed.";
var eCRDempty = "Please Enter ";
var eCRDSelect ="Please Select";
var eCRDComponent = "Please Select A Component.";
var eCRDSelectSite ="Please Select The Site To Be Associated With The Component.";
var eCRDSelectFutureEffDate="Please Select Future Effective Date.";
var eCRDSelectDate = "Please Select Date. ";
var eCRDSelectMonth = "Please Select Month. ";
var eCRDSelectYear = "Please Select Year. ";
var eCRDFutureEffDateCheck = "Repair Future Effective Date Should Be Greater Than Effective Date";
var eCRDFirstPosition= " is at First Position.";
var eCRDLastPosition= " is at Last Position.";
var eCRDEffectiveDate = " Effective Date Should Be Greater Than Or Equal To Current Date.";
var eCRDEffectiveEndDate = " End Date Should be Greater than Current Date.";
var eCRDSelectClass = "Please Select Class.";
var eCRDNotNumeric = "Should Be Numeric.";
var eCRDSelectList = "Please Select The Value To Be Moved";
var eCRDCheckValue = "Check The Value Entered.";
var eCRDDelimiter = "^";
var eCRDATAFormat ="ATA ref num must be changed to GEK*/TO*/nn-nn-nn format.";
var eCRDSelFeature = "Please Select a Feature.";
var eCRDUserId="Please Enter Alphanumeric UserId.";
var eCRDValidId="Please Enter Minimum Three Character.";
var eCRDEmail="Please Enter Valid Email Id.";
var eCRDModuleLevel = "Please Select a Module.";
var eCRDComponentLevel = "Please Select a Component.";
var eCRDRepair = "Please Select a Repair.";
var eCRDValidUser="User Dont Have Sufficient Privilage TO Modify User.";
var eCRDFind="Please Click Find Button To Find User.";
var eCRDComponentType="Please Select Code or Description from the Component dropdown.";

var eCRDComponentCode="Please Enter The Component Code.";
var eCRDComponentDesc="Please Enter The Component Description.";

var eCRDRuleType = "Please select a Level at which you want to apply the Rules.";
var eCRDEnter="Please Enter";
var eCRDFindCust="Please Find a customer to Add.";
var eCRDCatalogType = "Please Select Catalog Type.";
var eCRDCatalog = "Please Select Catalog.";
var eCRDEngineModule="Please select Engine Module.";
var eCRDCustomer="Please add a customer.";
var eCRDBlankComponent = "Please Enter a Search Criteria of atleast Two Characters.";
var eCRDBlankCustomer="  Customer name should have atleast three characters.";
var eCRDTurnAround ="Please enter  Turn Around Time.";
var eCRDPriceType ="Please Select A Price Type.";
var eCRDPrice ="Please Enter the Price.";
var eCRDDisplaySeq ="Please enter The Display Sequence.";
/* Patni 29-May-2006 Begin Do not allow '0' in Display Seq Id*/
var eCRDDispSeqNonZero = "Please Enter a Non-Zero Display Sequence Number.";
/* Patni 29-May-2006 End Do not allow '0' in Display Seq Id*/
var eCRDemptyCustomer="Please select a customer.";
var eCRDYear = "Please select a Year on which you want to apply Rules.";
var eCRDCustStartDateMismatch="  of  customer Contract must be less than the catalog.";
var eCRDCustDuplicate	= "Customer Already Present in the List.";
var eCRDAtleastOneRule = "Please select at least one rule to be applied.";
var eCRDNoAccessForChangingSite = "You Do Not Have Rights To Modify This Site.";
var eCRDNotValideCombinationSiteRole="Coordinator Cannot be associated with all the Sites.";
var eCRDMandatory = "Please enter atleast one character";
var eCRDRepairRefNo= "Please enter Repair Reference Number";
var eCRDRejectComments="Please enter Rejection Comments";
var eCRDRepairPrice="Please enter Repair Price";
var eCRDNoCustomer="There are no customers in the table";
var eCRDDispSeqIdNotUnique ="Display Sequence Id Should Be Unique for each Child Repair.";
var eCRDAtLeastOneRepairSite ="There Should Be At Least One Site For A Repair.";
var eCRDChildRepair = "There Should Be At Least One Child Repair.";
var eCRDConfirmPartDeletion = "Are You Sure You Want To Delete This Part Number.";
var eCRDDifferentIndex = "Please enter Distinct Index Values.";
var eCRDDependency = "Please enter a value for Dependency.";
var eCRDMaxRepairSites = "You Can Not Add Any More Site For This Repair.";
var eCRDUniqueRepairSite = "Selected Site Should Be Unique For A Repair.";
var eCRDSelectPart = "Please Select The Part Number To Be Removed.";
var eCRDConfirmModuleDeletion="Are You Sure You want to Delete the Selected Engine Modules?";
var eCRDConfirmCustDeletion="Are You Sure You want to Delete the Customer?";
var eCRDConfirmCompDelete="Are You Sure You want to Delete the Component?";
var eCRDConfirmLastRepairDelete="As this is the only repair under the component, this action will delete the component itself.  Do you want to continue?";
var eCRDConfirmRepairDelete="Are You Sure You want to Delete the Repair?";
var eCRDNoSiteToMove = "Please Select a Site to be moved.";
var eCRDMergeRepair ="There should be atleat two repairs  selected to merge.";
var eCRDAnyOneRule = "Please Select either Escalation or Flow Down Change Ind or Index and Dependency.";
var eCRDEitherIndex = "Please Select either Escalation or Index.";
var eCRDRepairTabMsg = "Please Select repair from Repair List to view repair details.";
var eCRDRepairListingTabMsg = "Please Select Component from Component Listing to see Repair List.";
var eCRDRepairPricingTabMsg = "Please Select Repair from Repair List to view Repair Pricing details.";
var eCRDRepairDescNotUnique="Repair Description  Should Be Unique for each Child Repair. ";
var eCRDNoChanges = "Please Edit Atleast one field and Then Click On the Save Button.";
var eCRDSaveAllSplit = "Please save all Repair Details to Split.";
var eCRDFindComponent = "Please Find A Component.";
var eCRDSelectRulesCriteria = "Please Select the Rule Criteria Before Applying the Rules.";
var eCRDConfirmComponentDeletion="Are You Sure You Want To Delete This Component.";
var eCRDCatalogNumber = "Please Enter the Catalog Number.";
var eCRDDeletedRepair = "This repair has already been deleted";
var eCRDRepairsApprovalListMsg = "This Option is not available for Repair Approvals.";
var eCRDCatalogDesc="Please Enter Catalog Description Less than 100 Characters";
var eCRDContractDesc="Please Enter Contract Description in specified limit";
var eCRDIncrPrice = "Price Cannot Be Incremental For Quote Type";
var eCRDQUOTEPrice = "Please Do Not Enter Price For Quote Type";
var eCRDFutureTATCheck = "Future TAT";
var eCRDFuturePriceCheck ="Future Price";
var eCRDFutureRepEffectiveDate = " Repair Future Effective Date Should Be Greater Than Current Date.";
var eCRDAddComponentDetails = "Please Enter Component Details To Add Repairs";
var eCRDChangeInput = "Please Change atleast one Value";
var eCRDAdhocColSelect = "Please select colum to display";
var eCRDChangeCompClass = "Please Update Component Class";
var eCRDPriceAdjustmentValue ="Price Adjustment Value Should Be Greater Than Zero ";
var eCRDDeleteEmailUser = "Are you sure you want to delete this E-mail from the Group";
var eCRDAddEmail = "There should be atleast one user in the group";
var eCRDemptyGroup=" Please select a group";
var eCRDCheckLessThanZero = "Should Be Greater Than Zero";
var eCRDDeleteGroup= "Are you sure you want to delete this Group";
var eCRDEnterCost = "Please enter Cost";
var eCRDEnterCostCond = "Please select the Condition for Cost";
var eCRDEnterRepCrit   = "Please select atleast one Criteria for report";
var eCRDEnterPriceCrit = "Please enter Criteria for Price Type Correctly";
var eCRDEnterPricCond  = "Please select the Condition for price";
var eCRDComponentEfftDate  = "Component Effective Date Should Be Greater Than Sysdate Or Should be Greater Than Proposed Component Effective Date";
var eCRDRepairEfftectiveDate  = "Repair Effective Date Should Be Greater Than Sysdate Or Should be Greater Than Proposed Repair Effective Date ";
var eCRDRepairEfftDate  = "Repair Effective Date Should Be Greater Than Component Effective Date ";
var eCRDSiteDisplayable= "Please Select Location as a Display column";
var eCRDNoAccessForChangingSiteOfCreator = "You Can Not Move The Site Of The Coordinator Who Has Created This Component.";
var eCRDConfirmSiteDelete = "Are You Sure You Want To Delete This Site";
var eCRDConfirmChildRepairDelete = "Are You Sure You Want To Delete This Child Repair";
var eCRDFutureRepEffDateCheck ="Future Repair Effective Date Should Be Greater Than Repair Effective Date";
var eCRDMaxLimitExceeded = "Can Not Be Greater Than 999.99";
var eCRDAssociateEventSave = "Events not associated with the group . Do you want to continue ?";
var eCRDWhiteSpacesNotAllowed = "White Spaces Are Not Allowed For Component Code";
var eCRDLaborRateExceeded = "Labor Rate Can Not Be Greater Than 9999999999999.99";
var eCRDComments = "Comments should be less than 250 characters";
var eCRDCheckCompEffDate = "Component Effective Date Should Be Greater Than Present Value Which Is ";
var eCRDUncheckPriceOverWriteInd = "You unchecked Price OverWrite Flag. Pricing Changes that you have just done will not be saved. Do you want to Continue?";
var eCRDNonNegative = "Can Not Be Negative";
var eCRDCustomerCatStartDate="Start Date should be greater than 16-Jan-2005";
var eCRDWildCard = "Please Enter Atleast Two Characters For Wild Card Search";
var eCRDEmailSearch ="Please Enter Atleast Three Characters For Search";
var eCRDWildCardTwice = "Cannot Use Wild Card More Than Once";
var eCRDRejectLength = "Rejection comments cannot have more than 250 characters";
var eCRDRepairDescLength = "Repair Description cannot have more than 255 characters";
var eCRDPriceLimit = "Price Can Not Be Greater Than 9999999999999.99";
var eCRDPendingApprovalCompSite="You cannot remove site as site is pending for approval";
var eCRDSelectRepair = "Please select atleast one repair to be added to Customer Specific Catalog."
<!-- Start Rajiv -->
var eCRDEmptyOSBComponent = "Please Specify OSB Component Code.";
var eCRDNoRowSelected = "Please select atleast one row to be deleted to remove mapping."
var eCRDConfirmMapDeletion="Are You Sure You want to Delete the Selected Mapping?";
var eCRDRprEffDateSysdate="You can't enter the Repair Effective Date Less than Today."
var eCRDRprEffDateCompEndDateAlert="Repair Effective Date will not be taken into consideration as it is greater than catalog end date."
var eCRDCompMappingSize="eCRD Component Code size should be less or equal to 20 character."
<!-- End Rajiv -->
/*Patni Changes Start-7/11/2007*/
var eCRDCatalogDateMismatch="Catalog End Date should be greater than current date."
var eCRDContractEndDateMismatch="Contract End Date should be greater than current date"
/*Patni Changes End-7/11/2007*/
function alertMsgs(msg)
{
	alert(msg);
}
