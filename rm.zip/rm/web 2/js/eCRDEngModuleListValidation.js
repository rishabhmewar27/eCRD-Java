



var features;
//function to validate the create Module Page.It includes validation for no values inserted in the Module Description text box.
function fnCreateModuleSubmit()
{
   document.frmCreateNewModule.txtEngModName.value=fnTrim(document.frmCreateNewModule.txtEngModName.value);
    if ((document.frmCreateNewModule.txtEngModName.value == null) || 
      (document.frmCreateNewModule.txtEngModName.value == ""))
   {

       alertMsgs(eCRDEngineModule);
      document.frmCreateNewModule.txtEngModName.focus();
   }

  else if (!fnCheckSplChars(document.frmCreateNewModule.txtEngModName))
   {
       alertMsgs(eCRDSpecialCharacter);
        document.frmCreateNewModule.txtEngModName.value = "";
      document.frmCreateNewModule.txtEngModName.focus();
   }
   else
   {
   document.frmCreateNewModule.hdnScreenName.value="eCRDManageModuleHelper";  
   document.frmCreateNewModule.hdnScreenAction.value="";
  document.frmCreateNewModule.submit();
   self.close();
   }
}

//function for pop up  window for create Module
function fnpopCreateModule(basePath)
{
  features='toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=no,width=500,height=300';
	dlg = window.open (basePath+"/ecrd?hdnScreenName=eCRDManageModuleHelper&hdnScreenAction=CreateModule&RandomValue="+Math.random(),"Dialog",features);
}

//function for pop up  window for modify Module
function fnpopModifyModule(basePath)
{

   features='toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=no,width=500,height=300';
	dlg = window.open (basePath+"/ecrd?hdnScreenName=eCRDManageModuleHelper&hdnScreenAction=ModifyModule&RandomValue="+Math.random(),"Dialog",features);    
}

//function to validate the Modify Module Page.It includes validation for no values inserted in the Module Description text box.
function fnModifyModuleSubmit()
{
      document.frmModifyModule.txtEngModName.value=fnTrim(document.frmModifyModule.txtEngModName.value);

    if ((document.frmModifyModule.txtEngModName.value == null) || 
      (document.frmModifyModule.txtEngModName.value == ""))
   {

       alertMsgs(eCRDEngineModule);
      document.frmModifyModule.txtEngModName.focus();
   }

  else if (!fnCheckSplChars(document.frmModifyModule.txtEngModName))
   {
       alertMsgs(eCRDSpecialCharacter);
        document.frmModifyModule.txtEngModName.value = "";
      document.frmModifyModule.txtEngModName.focus();
   }
   else
   {
   document.frmModifyModule.hdnScreenName.value="eCRDManageModuleHelper";  
   document.frmModifyModule.hdnScreenAction.value="";
  document.frmModifyModule.submit();
   self.close();
   }
}


//function to delete the modules selected in the table to add to the Engine model.
function SelectEngineModel(strName,strCode,basePath)
{
  var strName=strName;

     document.frmManageEngModule.hdnModifyModuleName.value=strName;
    features='toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=no,width=500,height=300';
	dlg = window.open (basePath+"/ecrd?hdnScreenName=eCRDManageModuleHelper&hdnScreenAction=ModifyModule&hdnModifyModuleName="+strName+"&RandomValue="+Math.random(),"Dialog",features);    
   
}

//function to delete the modules selected in the table.
function fnDelEngineModule()
{
	document.frmManageEngModule.hdnDelEngModule.value = getSelectedValues(document.rowcachedform.chkEngModule);

	if(document.frmManageEngModule.hdnDelEngModule.value == "")
	{
		alertMsgs(eCRDEngineModule+" to delete");
		return;
	}
   document.frmManageEngModule.hdnScreenName.value = "eCRDManageModuleHelper";
	document.frmManageEngModule.hdnScreenAction.value = "DeleteModules";
   document.frmManageEngModule.submit();
}


//function to get selected values of checkboxes in a table.
function getSelectedValues(chkBox)

{
	var count = 0;
	var value = "";

	if (typeof chkBox.length == 'number')
	{
		for(count = 0; count < chkBox.length; count++)
		{
			if(chkBox[count].checked)
			{
				value = value + "^^"+ chkBox[count].value ;
			}
		}
	}
	else
	{
		if(chkBox.checked)
			{
				value = chkBox.value + "^^";
			}
	}

		return value;
}


function fnAddModules()
{
	document.frmManageEngModule.hdnSelectedModule.value = getSelectedValues(document.frmManageEngModule.chkAddModule);

	if(document.frmManageEngModule.hdnSelectedModule.value == "")
	{
		alertMsgs(eCRDEngineModule+" to Add");
		return;
	}
   
   document.frmManageEngModule.hdnScreenName.value = "eCRDManageModuleHelper";
	document.frmManageEngModule.hdnScreenAction.value = "AddModules";
   alert("submit");
   document.frmManageEngModule.submit();
}

function fnAddMessage()
{
  alertMsgs(eCRDModuleAdded);
   return;
}

function fnDelMessage()
{
  alertMsgs(eCRDModuleDeleted);
   return;
}

function fnValidateCustCatalog(objForm)
{
   with(objForm)

   if(fnCheckForNullValues(objForm))
   {
      alert("fine");
      startDate = fnValidateCalenderDate(sel_man_Startdate_DD,sel_man_Startdate_MM,sel_man_Startdate_YYYY);
		endDate   = fnValidateCalenderDate(sel_man_Enddate_DD,sel_man_Enddate_MM,sel_man_Enddate_YYYY);
      if(fnCompareDateFromTo(startDate,endDate))
      {
          alert(eCRDDate);
          return false;
      }

        alert("submit");
   }
}

function fnCheckForNullValues(objForm)
{
  
   if(objForm.lstEngMode.selectedIndex==0)
   {
      alertMsgs(eCRDSelectClass+"from the list box for Engine Model");
      objForm.lstEngMode.focus();
      return false;
   }
   if(objForm.sel_man_Startdate_DD.value == "" || objForm.sel_man_Startdate_MM.value == "" ,objForm.sel_man_Startdate_YYYY.value == "")
			 {
				alertMsgs(eCRDEmptyDate +" Start Date");
				return false;
			 }
		if(objForm.sel_man_Enddate_DD.value == "" || objForm.sel_man_Enddate_MM.value == "" ,objForm.sel_man_Enddate_YYYY.value == "")
			 {
				alertMsgs(eCRDEmptyDate +" End Date");
				return false;
			 }
      
   objForm.txtCustCode.value=fnTrim(objForm.txtCustCode.value);
   if(objForm.txtCustCode.value =="")
   {
         alertMsgs(eCRDempty + " for Customer Code");
         objForm.txtCustCode.focus();
         return false;
   }
    if (!fnCheckSplChars(objForm.txtCustCode))
   {
       alertMsgs(eCRDSpecialCharacter);
       objForm.txtCustCode.value = "";

       objForm.txtCustCode.focus();
       return false;
   }
   return true;
}



function fnCompareDateFromTo(start,end)
{
    if ( Date.parse(start)>=Date.parse(end))
    {
         return true;
    }
    else
    {
       return false;
    }
}


 function fnValidateCalenderDate(dayDD,monthDD,yearDD)
{

  var dayVal = dayDD.options[dayDD.selectedIndex].value;
   var monthVal = monthDD.options[monthDD.selectedIndex].value;
   var yearVal = yearDD.options[yearDD.selectedIndex].value;
    var fullDateVal =yearVal+ "/" + monthVal + "/"  + dayVal ;
    return fullDateVal;
}

function fnpopCustTable(basePath)
{

   features='toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=no,width=500,height=300';
	dlg = window.open (basePath+"/ecrd?hdnScreenName=eCRDManageCustomerCatalogHelper&hdnScreenAction=CustomerTable&RandomValue="+Math.random(),"Dialog",features);

    
}

function fnSubmitCustTable(objForm)
{
   strCust=getSelectedRadio(objForm.rdbCust);   
   if(strCust=="")
   {
      alertMsgs(eCRDSelectClass+" from the customer table");
      return;
   }

      self.opener.document.frmCreateCustCatalog.txtCustCode.value=strCust;
      self.close();
} 

function fnCancel()
{
   self.close();
}



//function to get the selected value of the radio button
function getSelectedRadio(radio)
{
   	var count = 0;
	var value = "";
		for(count = 0; count < radio.length; count++)
		{
			if(radio[count].checked)
			{
				value = radio[count].value ;
			}
		}
		return value;

}

//function to display a new table in the same jsp to  add a customer 
function fnAddCustomer()
{
  

    if(document.frmCreateCustCatalog.txtCustCode.value=="")
   {
         alertMsgs(eCRDempty+" for Customer Code");
         return;
   }
   document.frmCreateCustCatalog.hdnAddDelCust.value="AddCust";
   document.frmCreateCustCatalog.hdnAddCustomer.value=document.frmCreateCustCatalog.txtCustCode.value;
      fnRetainval();
   document.frmCreateCustCatalog.hdnScreenName.value="eCRDManageCustomerCatalogHelper";
    document.frmCreateCustCatalog.hdnScreenAction.value="";
    document.frmCreateCustCatalog.submit();
}
function fnRetainval()
{
      
   document.frmCreateCustCatalog.hdnEngModelCode.value=document.frmCreateCustCatalog.lstEngMode.options[document.frmCreateCustCatalog.lstEngMode.selectedIndex].value;
   document.frmCreateCustCatalog.hdnStartDate_DD.value=document.frmCreateCustCatalog.sel_man_Startdate_DD.value;
      document.frmCreateCustCatalog.hdnStartDate_MM.value=document.frmCreateCustCatalog.sel_man_Startdate_MM.value;
   document.frmCreateCustCatalog.hdnStartDate_YY.value=document.frmCreateCustCatalog.sel_man_Startdate_YYYY.value;
      document.frmCreateCustCatalog.hdnEndDate_DD.value=document.frmCreateCustCatalog.sel_man_Enddate_DD.value;
      document.frmCreateCustCatalog.hdnEndDate_MM.value=document.frmCreateCustCatalog.sel_man_Enddate_MM.value;
   document.frmCreateCustCatalog.hdnEndDate_YY.value=document.frmCreateCustCatalog.sel_man_Enddate_YYYY.value;


}
function fnCustCode(strCustCode,strStart_DD,strStart_MM,strStart_YY,strEndDate_DD,strEndDate_MM,strEndDate_YY)
{ 

   document.frmCreateCustCatalog.sel_man_Startdate_DD.value=strStart_DD;
   document.frmCreateCustCatalog.sel_man_Startdate_MM.value=strStart_MM;
   document.frmCreateCustCatalog.sel_man_Startdate_YYYY.value=strStart_YY;
   document.frmCreateCustCatalog.sel_man_Enddate_DD.value=strEndDate_DD;
   document.frmCreateCustCatalog.sel_man_Enddate_MM.value=strEndDate_MM;
   document.frmCreateCustCatalog.sel_man_Enddate_YYYY.value=strEndDate_YY;

   document.frmCreateCustCatalog.txtCustCode.value=strCustCode;
}
 
function  DeleteCustomer(strCust)
{
      document.frmCreateCustCatalog.hdnAddDelCust.value="DelCust";
      document.frmCreateCustCatalog.hdnAddCustomer.value=strCust;
       fnRetainval();
       document.frmCreateCustCatalog.hdnScreenName.value="eCRDManageCustomerCatalogHelper";
    document.frmCreateCustCatalog.hdnScreenAction.value="";
    document.frmCreateCustCatalog.submit();
}

function fnClearCustCodeText()
{
      document.frmCreateCustCatalog.txtCustCode.value="";
}
