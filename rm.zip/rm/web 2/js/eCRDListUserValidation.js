/*This function is called when Add User button is clicked from eCRDListUser.jsp*/
function fnAddUser()
{ 
     
	 document.frmListUser.submit();
	 
}//end of the function fnAddUser()

/********************************************************************************
This function is called from eCRDCreateUser.jsp for foccusing on userid textbox
********************************************************************************/
function fnAddUserFocus()
{
document.frmAddUser.txtUserId.focus();
}//end of function fnAddUserFocus();

/****************************************************************************
This Function is called from eCRDListUser.jsp on clicking of button list user 
*****************************************************************************/
function fnSearch()
{
	
	frmListUser.hdnScreenAction.value="eCRDSearchUser";
	document.frmListUser.submit();
}//end of the fnSearch()
/****************************************************************************
This Function is called from eCRDCreateUser.jsp on clicking of button find 
*****************************************************************************/
function fnPop()
{
	var userid=document.frmAddUser.txtUserId.value;
	var trimUserId=fnTrim(userid);
	var strLength=trimUserId.length;
	if(!fnValidateAlphaNumeric(userid))
	{
		
	}
	
	else{
				if(strLength>2)
				{				
					features='toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=620,height=350,title=LdapUser';
					dlg = window.open (basePath+"/ecrd?hdnScreenName=eCRDListUser&hdnScreenAction=eCRDLdapSearch&txtUserId="+document.frmAddUser.txtUserId.value+"&hdnRandom="+Math.random(),'Search_User',features);    
					dlg.focus();
				}
				else
				{
					 alertMsgs(eCRDValidId);
				}
		}
}//end of function fnpop();

/****************************************************************************
This Function is used to check userid is alphanumeric or not 
@inputPARAM is string userid 
*****************************************************************************/
function  fnValidateAlphaNumeric(strValue)
{
    var i;
    if (strValue =="")
    {
        alertMsgs(eCRDempty+"For UserId");
			return false;
		
    }
    else
    {
        for(i = 0; i < strValue.length; i++)
        {
            if(strValue.charAt(i)==" "  ||
            strValue.charAt(i) == "."   ||
            strValue.charAt(i) == "_"   ||
            strValue.charAt(i) == "@")
            {
				 alertMsgs(eCRDUserId);
				 return false;
					
            }
            else
            {
                if(strValue.charAt(i) < "0" || strValue.charAt(i) > "9")
                {
                    if(strValue.charAt(i) < "a" || strValue.charAt(i) > "z")
                    {
                        if(strValue.charAt(i) < "A" || strValue.charAt(i) > "Z")
                        {
							alertMsgs(eCRDUserId);
                          return false;
                        }
                    }
                }
            }
        }
        
    }
	return true;
}//end of function fnValidateAlphaNumeric

/****************************************************************************
This Function is called when user clicks on submit button of popup window
rowcachedform is passed as input parameter 

*****************************************************************************/

function fnBack(rowcachedform)
{
	
	var count = 1;
	var data = "";
		
		for(count = 1; count < rowcachedform.elements.length; count++)
		{
			if(rowcachedform.elements[count].checked)
			{
				data = rowcachedform.elements[count].value ;
				brkIndex=data.indexOf('^')+1;
				
				userId=data.substring(0,brkIndex-1);
				data = data.substring(brkIndex);
				
				brkIndex  = data.indexOf('^')+1;
				firstName = data.substring(0,brkIndex-1);
				
				data = data.substring(brkIndex);
				brkIndex = data.indexOf('^')+1;

				lastName = data.substring(0,brkIndex-1);
				data = data.substring(brkIndex);
				
				
				emailId = data;
				window.opener.document.frmAddUser.hdnUserId.value=userId;
				window.opener.document.frmAddUser.hdnFName.value=firstName;
				window.opener.document.frmAddUser.hdnLName.value=lastName;
				window.opener.document.frmAddUser.hdnEmail.value=emailId;
				window.opener.document.frmAddUser.hdnScreenAction.value="eCRDSearchDetails"
				window.opener.document.frmAddUser.submit();
				window.close();
			}

		}
}//end of function fnback()

/****************************************************************************
This Function is called when user select userid from listing of user to modify
that user 
*****************************************************************************/
function fnModifyUser(strUserId,strFname,strLname,strRole,strSite,strActive,strEmail,strSiteCode,strRoleCode,strDualRoleIndicator)
{

	frmListUser.hdnScreenAction.value="eCRDModifyUser";
	frmListUser.hdnUserId.value=strUserId;
	frmListUser.hdnFName.value=strFname;
	frmListUser.hdnRole.value=strRole;
	frmListUser.hdnLName.value=strLname;
	frmListUser.hdnSite.value=strSite;
	frmListUser.hdnActive.value=strActive;
	frmListUser.hdnEmail.value=strEmail;
	frmListUser.hdnSiteCode.value=strSiteCode;
	frmListUser.hdnRoleCode.value=strRoleCode;
	frmListUser.hdnDualRoleIndicator.value=strDualRoleIndicator;
	document.frmListUser.submit();
	
}//end of function fnModifyUser()

/****************************************************************************
This function is called when user clicks on add user button of eCRDCreateUser.jsp

*****************************************************************************/
function fnCreatedUser()
{

	if(!fnValidateAlphaNumeric(frmAddUser.txtUserId.value))
	
	{
		
		alertMsgs(eCRDUserId);
	}
	else if(!fnCheckForNullValues(frmAddUser.txtUserId.value))
	{
		frmAddUser.txtUserId.focus();
		alertMsgs(eCRDEnter + " User Id");
	}
	else if(!fnCheckForNullValues(frmAddUser.txtFName.value))
	{

		alertMsgs(eCRDFind)
	}

	else if(!fnCheckForNullValues(frmAddUser.txtLName.value))
	{

		
	}
	else if(!fnCheckForNullValues(frmAddUser.selRole.value))
	{
		frmAddUser.selRole.focus();
		alertMsgs(eCRDSelect + "  User Role");
	}
	else if(!fnCheckForNullValues(frmAddUser.selSite.value))
	{
		frmAddUser.selSite.focus();
		alertMsgs(eCRDSelect + "  User Site");
	}
	else if(document.frmAddUser.selActive.selectedIndex==0)
	{
		frmAddUser.selActive.focus();
		alertMsgs(eCRDSelect+" User Status");
	}
	else if(document.frmAddUser.selDualRoleIndicator.selectedIndex==0)
	{
		frmAddUser.selDualRoleIndicator.focus();
		alertMsgs(eCRDSelect+" Dual Role Indicator (COORDINATOR & CSC Maintenance)");
	}
	else if (!(document.frmAddUser.selRole.value=='COORDINATOR' 
				||document.frmAddUser.selRole.value=='CSCMaintenance')
			&& (document.frmAddUser.selDualRoleIndicator.value=='Y')
			&& (document.frmAddUser.selDualRoleIndicator.selectedIndex==1)) 
	{
			frmAddUser.selDualRoleIndicator.focus();
			alert('Dual Role is only for COORDINATOR & CSC Maintenance roles');
	}
	else{
	frmAddUser.hdnUserId.value=frmAddUser.txtUserId.value;
	frmAddUser.hdnFName.value=frmAddUser.txtFName.value;
	frmAddUser.hdnRole.value=frmAddUser.selRole.value;
	frmAddUser.hdnLName.value=frmAddUser.txtLName.value;
	frmAddUser.hdnSite.value=frmAddUser.selSite.value;
	frmAddUser.hdnEmail.value=frmAddUser.txtEmailId.value;
	frmAddUser.hdnSiteCode.value=document.frmAddUser.selSite.options[document.frmAddUser.selSite.selectedIndex].value;
	frmAddUser.hdnRoleCode.value=document.frmAddUser.selRole.options[document.frmAddUser.selRole.selectedIndex].value;
	frmAddUser.hdnActive.value=document.frmAddUser.selActive.options[document.frmAddUser.selActive.selectedIndex].value;
	frmAddUser.hdnDualRoleIndicator.value=document.frmAddUser.selDualRoleIndicator.value;

	if(frmAddUser.hdnRoleCode.value==frmAddUser.hdnstrRoleCode.value&&frmAddUser.hdnSiteCode.value==frmAddUser.hdnstrSiteCode.value)
	{
	alert(eCRDNotValideCombinationSiteRole);//This Alert popup when User Select COORDINATOR As A Role And ALL Site
	}
	else{
	document.frmAddUser.submit();
	}
	}
}//end of function fnCreatedUser()

/****************************************************************************
This function is called when user clicks on close button of eCRDLdapSearch.jsp
this closes the window popedup.
*****************************************************************************/

function fnCancel()
{
	window.close();
}//end of function fnCancel()

/****************************************************************************
This function is called when user clicks on Update User Profile button of 
eCRDModifyUser.jsp.
*****************************************************************************/

function fnUpdateUser()
{
	if(!fnValidateAlphaNumeric(frmModifyUser.txtUserId.value))
	
	{
		alertMsgs(eCRDUserId);
	}
	else if(!fnCheckForNullValues(frmModifyUser.txtFName.value))
	{
		
		
		frmModifyUser.txtFName.focus();
		alertMsgs(eCRDEnter +"  First Name");
		
	}
	else if(!fncheckValidNameField(frmModifyUser.txtFName))
	{
		frmModifyUser.txtFName.focus();
		alertMsgs(eCRDEnter + " Valid First Name");
	}
	else if(!fnCheckForNullValues(frmModifyUser.txtLName.value))
	{
		frmModifyUser.txtLName.focus();
		alertMsgs(eCRDEnter + "  Last Name");
	}
	else if(!fncheckValidNameField(frmModifyUser.txtLName))
	{
		frmModifyUser.txtLName.focus();
		alertMsgs(eCRDEnter + " Valid Last Name");
	}

	else if(!fnvalidEmail(frmModifyUser.txtEmailId))
	{
		frmModifyUser.txtEmailId.focus();
	}
	else if(!fnCheckForNullValues(frmModifyUser.selRole.value))
	{
		frmModifyUser.selRole.focus();
		alertMsgs(eCRDSelect+" User Role");
	}
	else if(!fnCheckForNullValues(frmModifyUser.selSite.value))
	{
		frmModifyUser.selSite.focus();
		alertMsgs(eCRDSelect+" User Site");
	}
	else if(document.frmModifyUser.selActive.selectedIndex==0)
	{
		frmModifyUser.selActive.focus();
		alertMsgs(eCRDSelect+" User Status");
	}
	else if(document.frmModifyUser.selDualRoleIndicator.selectedIndex==0)
	{
		frmModifyUser.selDualRoleIndicator.focus();
		alertMsgs(eCRDSelect+" Dual Role Indicator (COORDINATOR & CSC Maintenance)");
	}
	else
	{
		if(document.frmModifyUser.selActive.selectedIndex==2)
		{
		 if(!(document.frmModifyUser.hdnPendingComponent.value == 0 &&
		  	 document.frmModifyUser.hdnPendingComponentSite.value == 0 &&
		  	 document.frmModifyUser.hdnPendingRepair.value == 0)
		  	)
		    {
				document.frmModifyUser.selActive.focus();
				alert('User having pending request(s) can\'t be InActive');
				return;
			}
		}

		if (!(document.frmModifyUser.selRole.value=='COORDINATOR' 
					||document.frmModifyUser.selRole.value=='CSCMaintenance')
				&& (document.frmModifyUser.selDualRoleIndicator.value=='Y')
				&& (document.frmModifyUser.selDualRoleIndicator.selectedIndex==1)) 
		{
				frmModifyUser.selDualRoleIndicator.focus();
				alert('Dual Role is only for COORDINATOR & CSC Maintenance roles');
				return;
		}

		frmModifyUser.hdnScreenAction.value="eCRDUpdateUser";
		frmModifyUser.hdnUserId.value=frmModifyUser.txtUserId.value;
		frmModifyUser.hdnFName.value=frmModifyUser.txtFName.value;
		frmModifyUser.hdnLName.value=frmModifyUser.txtLName.value;
		frmModifyUser.hdnEmail.value=frmModifyUser.txtEmailId.value;
		frmModifyUser.hdnSiteCode.value=document.frmModifyUser.selSite.value;
		frmModifyUser.hdnActive.value=document.frmModifyUser.selActive.value;

		if (!(document.frmModifyUser.selRole.value=='COORDINATOR' 
					||document.frmModifyUser.selRole.value=='CSCMaintenance')
				&& (document.frmModifyUser.selDualRoleIndicator.value=='Y')) 
		{
			document.frmModifyUser.selDualRoleIndicator.value = 'N'
		}

		frmModifyUser.hdnDualRoleIndicator.value=document.frmModifyUser.selDualRoleIndicator.value;
	
		if ((frmModifyUser.hdnRoleCode.value==null ||frmModifyUser.hdnRoleCode.value =="")
			&& (document.frmModifyUser.selRole.value==frmModifyUser.hdnstrRoleCode.value)
			&& (frmModifyUser.hdnSiteCode.value==frmModifyUser.hdnstrSiteCode.value)) 
		{
			alert(eCRDNotValideCombinationSiteRole);
			return;
		}

		frmModifyUser.hdnRoleCode.value=document.frmModifyUser.selRole.value;
		document.frmModifyUser.submit();
	}
}//end of function fnUpdateUser()

/****************************************************************************
This function is used for validating Name field in jsp textbox.
*****************************************************************************/

function fnCheckForNullValues(strValue)
{
   strValue = fnTrim(strValue);
   if(strValue =="")
   {
    return false;
   }
   return true;
}//end of function fnCheckForNullValues()

/****************************************************************************
This function is used for validating Name field in jsp textbox.
This function allows only alphabets in the name field 
*****************************************************************************/
function fncheckValidNameField(field)
{

 	for (var i=0; i<(field.value).length; i++)
 	{
 		var valid = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ "
 		var temp = fnTrim(field.value).substring(i, i+1);
		
 		if (valid.indexOf(temp) == "-1")
 		{
			field.focus();
 			return false;
 		}
 	}
	return true;
}//end of function fncheckValidNameField()

function fnIdChanged()
{
	document.frmAddUser.txtFName.value   = "";
	document.frmAddUser.txtLName.value   = "";
	document.frmAddUser.txtEmailId.value = "";
}
function fnUpdateBack()
{
	document.frmModifyUser.hdnScreenName.value= "eCRDListUser";
	document.frmModifyUser.hdnScreenAction.value= "";
	document.frmModifyUser.submit();
}

