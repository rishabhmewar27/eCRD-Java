// This function is used save the changed labor rate for the site
function fnSubmitLaborRate(objForm,strAllLaborRate)
{
	var actualArray = strAllLaborRate.split("^");
	var flag = false;
   var strChangedLaborRate  = "";
	for(i=1;i<actualArray.length;i++)
	{ 
      if(fnTrim(objForm.txtLaborRate[i-1].value) =="")
      {
            alertMsgs(eCRDempty + "Labor Rate");
            objForm.txtLaborRate[i-1].focus();
            return false;
      }
      if(objForm.txtLaborRate[i-1].value.indexOf("-")!=-1)
      {
         alertMsgs(eCRDCheckValue);
         objForm.txtLaborRate[i-1].focus();
         return false;
      }
      if(fnCheckDecimalValue(objForm.txtLaborRate[i-1].value))
      {
            if(eval(fnTrim(objForm.txtLaborRate[i-1].value)) != actualArray[i])
            {
               if(!(actualArray[i] == "" && fnTrim(objForm.txtLaborRate[i-1].value) ==""))
               {
                  if(eval(fnTrim(objForm.txtLaborRate[i-1].value)) <= 9999999999999.99)
                  {
                     strChangedLaborRate = strChangedLaborRate + objForm.hdnSiteId[i-1].value + "^" + objForm.txtLaborRate[i-1].value + "^" + "$";
                     flag = true;
                  }
                  else
                  {
                        alertMsgs(eCRDLaborRateExceeded);
                        return false;
                  }
               }
            }
      }
      else
      {
         alertMsgs(eCRDCheckValue);
         objForm.txtLaborRate[i-1].focus();
         return false;
      }
	}
	if(!flag)
	{
		alertMsgs(eCRDChangeInput);
		return false;
	}
   objForm.hdnSiteLaborRateList.value = fnTrim(strChangedLaborRate);
   objForm.submit();
}

// This function is used to save the changed notification period for class
function fnSubmitNotificationPeriod(objForm,strAllNotificationPeriod)
{
	var actualArray = strAllNotificationPeriod.split("^");
	var flag = false;
   var strChangedNotificationPeriod = "";
   for(i=1;i<actualArray.length;i++)
	{
       if(fnTrim(objForm.txtNotificationPeriod[i-1].value) =="")
      {
            alertMsgs(eCRDempty + "Notification Period");
            objForm.txtNotificationPeriod[i-1].focus();
            return false;
      }
      // Checking if negative value is entered for Notification Period 
      if(objForm.txtNotificationPeriod[i-1].value.indexOf("-")!=-1)
      {
         alertMsgs(eCRDCheckValue);
         objForm.txtNotificationPeriod[i-1].focus();
         return false;
      }
   	if(eval(objForm.txtNotificationPeriod[i-1].value) != actualArray[i])
		{
         strChangedNotificationPeriod = strChangedNotificationPeriod + objForm.hdnClassName[i-1].value + "^" + objForm.txtNotificationPeriod[i-1].value + "^" + "$";
   		flag = true;
		}
	}
	if(!flag)
	{
		alertMsgs(eCRDChangeInput);
		return false;
	}
   objForm.hdnClassPeriodList.value = fnTrim(strChangedNotificationPeriod);
	objForm.submit();
}

// This function is used to pop up the component list
function fnPopComponentTable(objForm,basePath)
{
   var strEngineModel = objForm.lstEngineModel.options[objForm.lstEngineModel.selectedIndex].value;
   var strEngineModule = objForm.lstEngineModule.options[objForm.lstEngineModule.selectedIndex].value;
   if(objForm.lstEngineModel.selectedIndex==0 || strEngineModel=="")
   {
       alertMsgs(eCRDSelEngModel);
       objForm.lstEngineModel.focus();
       return false;
   }
    if(objForm.lstEngineModule.selectedIndex==0)
   {
          alertMsgs(eCRDSelEngModule);
          objForm.lstEngineModule.focus();
          return false;
   }
   if(objForm.lstComponent.selectedIndex==0)
   {
       alertMsgs(eCRDSelect+ " Component Code/Description");
       objForm.lstComponent.focus();
       return false;
   }
   var strComponentCode = objForm.txtComponent.value;
   if(strComponentCode=="")
   {
      objForm.txtComponent.focus();
      alertMsgs(eCRDempty + "Component "  +objForm.lstComponent.options[objForm.lstComponent.selectedIndex].text);
      return false;
   }
   else
   {
      strComponent =  objForm.lstComponent.options[objForm.lstComponent.selectedIndex].text;
      features='toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,width=500,height=300';
      dlg = window.open (basePath+"/ecrd?hdnScreenName=eCRDManageComponent&hdnScreenAction=eCRDComponentTable&hdnEngineModuleDesc=" + strEngineModule +"&hdnEngineModelDesc=" + strEngineModel + "&hdnComponent=" + strComponent+"&hdnComponentValue=" + strComponentCode+"&RandomValue="+Math.random(),"Dialog",features);
   }
}


// This function is used to change the values of the Engine Module corresponding to the // value of the Engine Model 
function fnChangeEngineModule(objForm)
{
   if(objForm.lstEngineModel.selectedIndex==0)
   {
       objForm.lstEngineModule.length=1;
      objForm.lstEngineModule.options[0].text="Select...";
         return false;
   }    
   objForm.hdnEngineModelDesc.value=objForm.lstEngineModel.options[objForm.lstEngineModel.selectedIndex].value;
   objForm.hdnEngineModelDescription.value=objForm.lstEngineModel.options[objForm.lstEngineModel.selectedIndex].text;
   objForm.hdnScreenName.value="eCRDMaintenance";
   objForm.hdnScreenAction.value="eCRDPriceAdjust";
   objForm.submit();
}

// This function is used to check if user has selected engine model
function fnSelectEngineModule(objForm)
{
   if(objForm.lstEngineModel.selectedIndex==0)
   {
       alertMsgs(eCRDSelect+ " Engine Model");
       objForm.lstEngineModel.focus();
   }
}


// This function is used to check if user has selected engine model
function fnSavePriceAdjustment(objForm)
{
    
   if(fnValidatePriceAdjust(objForm))
   {
  var dayVal = objForm.sel_man_Effdate_DD.options[objForm.sel_man_Effdate_DD.selectedIndex].value;
   var monthVal = objForm.sel_man_Effdate_MM.options[objForm.sel_man_Effdate_MM.selectedIndex].value;
   var yearVal = objForm.sel_man_Effdate_YYYY.options[objForm.sel_man_Effdate_YYYY.selectedIndex].value;
   objForm.hdnEffectiveDate.value=monthVal + "/" +dayVal + "/"  +yearVal  ;
   objForm.hdnComponentCode.value=objForm.txtComponent.value;
   objForm.hdnComponent.value=objForm.lstComponent.options[objForm.lstComponent.selectedIndex].text;
   objForm.hdnEngineModuleDesc.value=objForm.lstEngineModule.options[objForm.lstEngineModule.selectedIndex].text;
   objForm.hdnScreenName.value="eCRDMaintenance";
   objForm.hdnScreenAction.value="eCRDSavePriceAdjustment";
   objForm.submit();
   }
}


//This function validates  the Price Adjustment Page
function fnValidatePriceAdjust(objForm)
{
    if(objForm.lstEngineModel.selectedIndex==0)
   {
       alertMsgs(eCRDSelEngModel);
       objForm.lstEngineModel.focus();
       return false;
   }
    if(objForm.lstEngineModule.selectedIndex==0)
   {
          alertMsgs(eCRDSelEngModule);
          objForm.lstEngineModule.focus();
          return false;
   }
   if(objForm.lstComponent.selectedIndex==0)
   {
       alertMsgs(eCRDSelect+ " Component Code/Description");
       objForm.lstComponent.focus();
       return false;
   }
   var strComponentCode = objForm.txtComponent.value;
   if(strComponentCode=="")
   {
      objForm.txtComponent.focus();
      alertMsgs(eCRDempty + "Component "  +objForm.lstComponent.options[objForm.lstComponent.selectedIndex].text);
      return false;
   }
   if(!(objForm.rdIncDec[0].checked || objForm.rdIncDec[1].checked))
   {
       alertMsgs(eCRDSelect+ " Price Change Type");
       return false;
   }
   strPriceVal=objForm.txtPriceVal.value;
   if(strPriceVal=="")
   {
       alertMsgs(eCRDSelect+ " Price Adjustment Value");
       objForm.txtPriceVal.focus();
       return false;
   }
   if(strPriceVal==0 )
   {
       alertMsgs(eCRDPriceAdjustmentValue);
       objForm.txtPriceVal.focus();
       return false;
   }

   if(objForm.sel_man_Effdate_DD.value == "" || objForm.sel_man_Effdate_MM.value == "" || objForm.sel_man_Effdate_YYYY.value == "")
   {
       alertMsgs(eCRDSelect+ " Effective date ");
       return false;
   }

   var dayVal = objForm.sel_man_Effdate_DD.options[objForm.sel_man_Effdate_DD.selectedIndex].value;
   var monthVal = objForm.sel_man_Effdate_MM.options[objForm.sel_man_Effdate_MM.selectedIndex].value;
   var yearVal = objForm.sel_man_Effdate_YYYY.options[objForm.sel_man_Effdate_YYYY.selectedIndex].value;
   strStartDate=monthVal+ "/" + dayVal + "/"  +yearVal  ;
   
     if(!fnValidateDateString(strStartDate))
     {
            objForm.sel_man_Effdate_DD.focus();
            return false;
     }
   sysDate=objForm.hdnSysdate.value;
    strStartDateVal=yearVal+ "/" +monthVal + "/"  +  dayVal ;
  		if(!fnCompareDateFromTo(strStartDateVal,sysDate))
		 {
         alertMsgs(eCRDEffectiveDate);
			 return false;
		 }
       return true;  
}

//function to Compare dates
function fnCompareDateFromTo(start,end)
{
    if ( Date.parse(start)>=Date.parse(end))
    {
         return true;
    }
    else
    {
       return false;
    }
}

function fnCheckDecimalValue(strText)
{
	var strCheckArray = strText.split(".");
   if(strCheckArray.length > 2)
   {
      return false;
   }
   else
   {
      return true;
   }
}