
// This function is used to populate the Module dropdown for a particular engine model

function fnGetModulesForEngineModel(objForm)
{
   objForm.hdnEngineModel.value=objForm.lstEngineModel.options[objForm.lstEngineModel.selectedIndex].value;
   objForm.submit();
}

// This is used to check if any value is null
function fnCheckForNullValues(objForm)
{
   strValue = fnTrim(objForm.txtComponentCode.value);
   if(strValue =="")
   {
         alertMsgs(eCRDempty + " For Component Code");
         objForm.txtComponentCode.value= "";
         objForm.txtComponentCode.focus();
         return false;
   }
   strValue = fnTrim(objForm.txtComponentDescription.value);
   if(strValue =="")
   {
        alertMsgs(eCRDempty + " For Component Description");
        objForm.txtComponentDescription.value= "";
        objForm.txtComponentDescription.focus();
        return false;
   }
   strValue = fnTrim(objForm.txtATAReferenceNumber.value);
   if(strValue =="")
   {
        alertMsgs(eCRDempty + " For ATA Reference Number");
        objForm.txtATAReferenceNumber.value= "";
        objForm.txtATAReferenceNumber.focus();
        return false;
   }
   strValue = fnTrim(objForm.txtBaselineTAT.value);
   if(strValue =="")
   {
        alertMsgs(eCRDempty + " For Baseline TAT");
        objForm.txtBaselineTAT.value= "";
        objForm.txtBaselineTAT.focus();
        return false;
   }
   if(objForm.sel_man_Startdate_DD.value=="")
   {
      alertMsgs(eCRDSelectDate);
      objForm.sel_man_Startdate_DD.focus();
      return false;
   }
   if(objForm.sel_man_Startdate_MM.value=="")
   {
      alertMsgs(eCRDSelectMonth);
      objForm.sel_man_Startdate_MM.focus();
      return false;
   }
   if(objForm.sel_man_Startdate_YYYY.value=="")
   {
      alertMsgs(eCRDSelectYear);
      objForm.sel_man_Startdate_YYYY.focus();
      return false;
   }
   if(objForm.lstClass.selectedIndex==0)
   {
      alertMsgs(eCRDSelectClass);
      objForm.lstClass.focus();
      return false;
   }
   if(objForm.lstSitesAssiciated.length==0)
   {
      alertMsgs(eCRDSelectSite);
      objForm.lstClass.focus();
      return false;
   }
   return true;
}

// This function is used to check special characters entered in any of the fields 
// Component Code and Component Description
function fnCheckSpecialChars(objForm)
{
   if(!fnCheckSplChars(objForm.txtComponentCode))
   {
       objForm.txtComponentCode.focus();
       alertMsgs(eCRDSpecialChars + " For Component Code");
 	    return false;
   }
   if(!fnCheckSplChars(objForm.txtComponentDescription))
   {
       objForm.txtComponentDescription.focus();
       alertMsgs(eCRDSpecialChars + " For Component Description");
 	    return false;
   }
   return true;
}


function fnConvUpperCase(inputString)
{
	var finalData='';
	for(var cntLn=0;cntLn<inputString.length;cntLn++)
	{
		var store=inputString.substring(cntLn,cntLn+1);
		if((store>='a')||(store <='z')||(store>='A')||(store <='Z'))
		{

			finalData+= store.toUpperCase();
		}
		else
		{
			finalData+= store;
		}
	}
	return finalData;
}//End of function

// This function validate component details entered
function fnValidateComponentDetails(objForm)
{
   var strList ="";
   if(fnCheckForNullValues(objForm))
   {
      if(fnCheckSpecialChars(objForm))
      {
         if(!isATANum(objForm.txtATAReferenceNumber.value))
         {
            alertMsgs(eCRDATAFormat);
            objForm.txtATAReferenceNumber.focus();
            return false;
         }
          if(isNaN(objForm.txtBaselineTAT.value))
         {
            alertMsgs("Baseline TAT "+eCRDNotNumeric);
            objForm.txtBaselineTAT.focus();
            return false;
         }
          if(!fnValidateCalenderDate(objForm,objForm.sel_man_Startdate_DD,objForm.sel_man_Startdate_MM,objForm.sel_man_Startdate_YYYY))
          {
             alertMsgs(eCRDComponentEffectiveDate);
             return false;
         }
         if(objForm.txtQuantityPartsPerSet.value!="")
         {
            if(isNaN(objForm.txtQuantityPartsPerSet.value))
            {
               alertMsgs("Quantity Parts Per Set "+eCRDNotNumeric);
               objForm.txtQuantityPartsPerSet.focus();
               return false;
            }
         }
         if(objForm.txtComponentShopVisitExposureRate.value!="")
         {
            if(isNaN(objForm.txtComponentShopVisitExposureRate.value))
            {
               alertMsgs("Component Shop Visit Exposure Rate "+eCRDNotNumeric);
               objForm.txtComponentShopVisitExposureRate.focus();
               return false;
            }
         }
         if(objForm.txtComponentScrapExposureRate.value!="")
         {
            if(isNaN(objForm.txtComponentScrapExposureRate.value))
            {
               alertMsgs("Component Scrap Exposure Rate "+eCRDNotNumeric);
               objForm.txtComponentScrapExposureRate.focus();
               return false;
            }
         }
         if(objForm.txtServiceableAtExposureRate.value!="")
         {
            if(isNaN(objForm.txtServiceableAtExposureRate.value))
            {
               alertMsgs("Serviceable At Exposure Rate "+eCRDNotNumeric);
               objForm.txtServiceableAtExposureRate.focus();
               return false;
            }
         }
         if(objForm.txtAgeRepairYield.value!="")
         {
            if(isNaN(objForm.txtAgeRepairYield.value))
            {
               alertMsgs("% Age Repair Yield "+eCRDNotNumeric);
               objForm.txtAgeRepairYield.focus();
               return false;
            }
         }

         for(i=0; i< objForm.lstSitesAssiciated.length; i++)
         {
            strList =    strList + objForm.lstSitesAssiciated.options[i].text;
            if( i != objForm.lstSitesAssiciated.length-1)
            {
               strList =    strList + eCRDDelimiter;
            }
         }
         objForm.hdnSitesAssiciated.value = strList;
         strList = "";
         for(i=0; i< objForm.lstPartNumbers.length; i++)
         {
            strList =    strList + objForm.lstPartNumbers.options[i].text;
            if( i != objForm.lstPartNumbers.length-1)
            {
               strList =    strList + eCRDDelimiter;
            }
         }
         objForm.hdnPartNumbers.value = strList;
         objForm.submit();
     }
   }
}
// This function is used to validate date
function fnValidateCalenderDate(objForm,dayDD,monthDD,yearDD)
{
 	var sysFullDate = objForm.hdnSysDate.value;
   var dayVal = dayDD.options[dayDD.selectedIndex].value;
	var monthVal = monthDD.options[monthDD.selectedIndex].value;
   var yearVal = yearDD.options[yearDD.selectedIndex].value;
   var fullDateVal =yearVal+ "/" + monthVal + "/"  + dayVal ;
	if(fnCompareDateFromTo(fullDateVal,sysFullDate) == false)
	{
					dayDD.focus();
					return false;
	}
	return true;
}
// This function is used to compare two dates
function fnCompareDateFromTo(start,end)
{
    if ( Date.parse(start)>=Date.parse(end))
    {
         return true;
    }
    else
    {
       return false;
    }
}



// This function is used to get the repair 
//and display its details on Repair Details Page.
function fnSearchRepair(objForm)
{
   
   if(objForm.lstEngineModel.selectedIndex==0)
   {
       alertMsgs(eCRDSelEngModel);
       objForm.lstEngineModel.focus();
       return false;
   }
   if(objForm.lstModule.selectedIndex==0)
   {
	  alertMsgs(eCRDModuleLevel);
	  objForm.lstModule.focus();
	  return false;
   }
   
   if(objForm.lstComponent.selectedIndex==0)
   {
   	  alertMsgs(eCRDComponentType);
   	  objForm.lstComponent.focus();
   	  return false;
   }
   
   
   /**beginning changes by rishabh mewar **/

	   if(objForm.repairInd.selectedIndex == 0)
	   {
	       alertMsgs(eCRDSelRepairInd);
	       objForm.repairInd.focus();
	       return false;
	   }

   /**end changes by rishabh mewar **/

   
   
   if(fnLtrim(fnRtrim(objForm.txtComponent.value))=="" )
   {
				  if(objForm.lstComponent.selectedIndex==1)
				  {
				  				alertMsgs(eCRDComponentCode);
				  }
				  else if(objForm.lstComponent.selectedIndex==2)
				  {
				  				alertMsgs(eCRDComponentDesc);
				  }				
				  objForm.txtComponent.focus();
				  return false;
   }
    
   if(objForm.lstRepair.selectedIndex==0)
  	{
				  alertMsgs(eCRDRepairType);
				  objForm.lstRepair.focus();
				  return false;
		 }

	  if(fnLtrim(fnRtrim(objForm.txtRepair.value))=="" )
	  {
				  if(objForm.lstRepair.selectedIndex==1)
				  {
				  				alertMsgs(eCRDRepairCode);
				  }
				  else if(objForm.lstRepair.selectedIndex==2)
				  {
				  				alertMsgs(eCRDRepairDesc);
				  }				
				  objForm.txtRepair.focus();
				  return false;
	  }
   
   objForm.hdnEngineModel.value=objForm.lstEngineModel.options[objForm.lstEngineModel.selectedIndex].value;
   
   objForm.hdnRepairInd.value=objForm.repairInd.options[objForm.repairInd.selectedIndex].value;	//changes by rishabh mewar
   
   objForm.hdnModule.value=objForm.lstModule.options[objForm.lstModule.selectedIndex].value;
   objForm.hdnComponentDropdown.value=objForm.lstComponent.options[objForm.lstComponent.selectedIndex].value;
   objForm.hdnRepairDropdown.value=objForm.lstRepair.options[objForm.lstRepair.selectedIndex].value;
   objForm.hdnScreenAction.value="RepairDetails";
   objForm.hdnScreenName.value="SearchRepair";
	if(objForm.lstComponent.value == 2)
	{
		if(objForm.hdnFindComponent.value.toUpperCase() != "TRUE" )
		{
		alertMsgs(eCRDFindComponent);
		return false;
		}
	
	}
	/*if(objForm.hdnFindRepair.value.toUpperCase() == "FALSE" )
	{
		alertMsgs("Please Find A Repair");
		return false;
	}*/

   objForm.submit();
}  


	function fnPopComponentTable(basePath)
{	
		
		if(document.frmSearchRepair.lstEngineModel.selectedIndex==0)
		{
		 		alertMsgs(eCRDSelEngModel);
		 		document.frmSearchRepair.lstEngineModel.focus();
					return false;
		}
		hdnEngineModel = document.frmSearchRepair.lstEngineModel.options[document.frmSearchRepair.lstEngineModel.selectedIndex].value;
		if(document.frmSearchRepair.lstModule.selectedIndex==0)
		{
					alertMsgs(eCRDSelEngModule);
					document.frmSearchRepair.lstModule.focus();
					return false;
		}
		hdnEngineModule = document.frmSearchRepair.lstModule.options[document.frmSearchRepair.lstModule.selectedIndex].value;
	
	
		hdnComponent = document.frmSearchRepair.lstComponent.options[document.frmSearchRepair.lstComponent.selectedIndex].value;
		if(hdnComponent == "0")
		{
					alertMsgs(eCRDComponentType);
					document.frmSearchRepair.lstComponent.focus();
					return false;
		}
		if(document.frmSearchRepair.txtComponent.value.length < 2)
		{
		 		alertMsgs(eCRDBlankComponent);
		 		document.frmSearchRepair.txtComponent.focus();
					return false;
		}
		hdnComponentCode = fnLtrim(fnRtrim(document.frmSearchRepair.txtComponent.value));
		//06-August-2007 Patni, special handling for % character
		hdnComponentCode = escape(hdnComponentCode);
		//06-August-2007 Patni end

		var features = "toolbar=no,location=no,width=600,height=400,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,title=Catalog List";
		win = window.open(basePath+"/ecrd?hdnScreenName=SearchRepair&hdnScreenAction=eCRDFindComponent&EngineModel="+hdnEngineModel+"&EngineModule="+hdnEngineModule+"&Component="+hdnComponent+"&ComponentCode="+hdnComponentCode,"",features);    
		
		win.focus();
}

function fnGetCompCodeInSearch(Component,CompCode)
{
			document.frmCompCodeList.hdnSelectedComponentCode.value = Component;
			document.frmCompCodeList.hdnComponentCode.value = CompCode;
			opener.document.frmSearchRepair.hdnComponentCode.value = CompCode;
			opener.document.frmSearchRepair.hdnComponentDropdown.value = opener.document.frmSearchRepair.hdnComponentDropdown.value;
}

function fnSubmitInSearch()
{	
	var parentForm = "frmSearchRepair"; 
	hdnEngineModel = document.frmCompCodeList.hdnEngineModel.value;
	hdnModule = document.frmCompCodeList.hdnModule.value;
	hdnComponentType = document.frmCompCodeList.hdnComponentType.value;
	hdnComponentCode = document.frmCompCodeList.hdnComponentCode.value;
	opener.document.frmSearchRepair.hdnFindComponent.value = "True";
	opener.document.frmSearchRepair.hdnSelectedComponentCode.value=document.frmCompCodeList.hdnSelectedComponentCode.value;
	opener.document.frmSearchRepair.txtComponent.value= document.frmCompCodeList.hdnSelectedComponentCode.value;
	if(document.frmCompCodeList.hdnSelectedComponentCode.value == "" || document.frmCompCodeList.hdnSelectedComponentCode.value == null)
	{
		alertMsgs(eCRDComponent);
		return false;
	}

	window.close();
			
}

function fnPopRepairTable(basePath)
{	
	if(document.frmSearchRepair.lstEngineModel.selectedIndex==0)
	{
			alertMsgs(eCRDSelEngModel);
			document.frmSearchRepair.lstEngineModel.focus();
			return false;
	}
		hdnEngineModel = document.frmSearchRepair.lstEngineModel.options[document.frmSearchRepair.lstEngineModel.selectedIndex].value;
 if(document.frmSearchRepair.lstModule.selectedIndex==0) 
 {	
			alertMsgs(eCRDModuleLevel);
			document.frmSearchRepair.lstModule.focus();
			return false;
	}
	hdnEngineModule = document.frmSearchRepair.lstModule.options[document.frmSearchRepair.lstModule.selectedIndex].value;
	hdnComponent = document.frmSearchRepair.lstComponent.options[document.frmSearchRepair.lstComponent.selectedIndex].value;
	if(hdnComponent == "0")
	{
		alertMsgs(eCRDComponentType);
		document.frmSearchRepair.lstComponent.focus();
		return false;
	}

	hdnComponentCode = fnLtrim(fnRtrim(document.frmSearchRepair.txtComponent.value));
 if(hdnComponentCode == "")
 {
 	if(document.frmSearchRepair.lstComponent.selectedIndex==1)
				  {
				  				alertMsgs(eCRDComponentCode);
				  }
				  else if(document.frmSearchRepair.lstComponent.selectedIndex==2)
				  {
				  				alertMsgs(eCRDComponentDesc);
				  }	
		document.frmSearchRepair.txtComponent.focus();
		return false;
 }	

	
	hdnRepair = document.frmSearchRepair.lstRepair.options[document.frmSearchRepair.lstRepair.selectedIndex].value;
	if(hdnRepair == "0")
	{
		alertMsgs(eCRDRepairType);
		document.frmSearchRepair.lstRepair.focus();
		return false;
	}

	if(document.frmSearchRepair.txtRepair.value.length < 2)
{
	alertMsgs(eCRDBlankComponent);
	document.frmSearchRepair.txtRepair.focus();
	return false;
}

	hdnRepairCode = fnLtrim(fnRtrim(document.frmSearchRepair.txtRepair.value));
	//06 August 2007 Patni, special handling for % character
	hdnRepairCode = escape(hdnRepairCode);
	//06 August 2007 
	hdnComponentStaticCode = document.frmSearchRepair.hdnComponentCode.value;
	//document.frmSearchRepair.hdnFindRepair.value  = "True";
	var features = "toolbar=no,location=no,width=600,height=400,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,title=Catalog List";
	 win = window.open(basePath+"/ecrd?hdnScreenName=SearchRepair&hdnScreenAction=eCRDFindRepair&EngineModel="+hdnEngineModel+"&EngineModule="+hdnEngineModule+"&Component="+hdnComponent+"&ComponentCode="+hdnComponentCode+"&Repair="+hdnRepair+"&RepairCode="+hdnRepairCode+"&ComponentStaticCode="+hdnComponentStaticCode,"",features);    

	win.focus();
}

/*function fnGetRepairCodeInSearch(RepairCode,Repairtype)
{
	document.frmRepairCodeList.hdnSelectedRepairCode.value = RepairCode;
	opener.document.frmSearchRepair.hdnRepairDropdown.value = opener.document.frmSearchRepair.hdnRepairDropdown.value;
	opener.document.frmSearchRepair.hdnRepairType.value = Repairtype;
	
}*/
function fnGetRepairCodeInSearch(RepairCode)
{
	document.frmRepairCodeList.hdnSelectedRepairCode.value = RepairCode;
	opener.document.frmSearchRepair.hdnRepairDropdown.value = opener.document.frmSearchRepair.hdnRepairDropdown.value;
}

function fnSubmitRepairInSearch()
{	
	var parentForm = "frmSearchRepair"; 
	hdnEngineModel = document.frmRepairCodeList.hdnEngineModel.value;
	hdnModule = document.frmRepairCodeList.hdnModule.value;
	hdnComponentType = document.frmRepairCodeList.hdnComponentType.value;
	hdnComponent = document.frmRepairCodeList.hdnComponent.value;
	opener.document.frmSearchRepair.hdnSelectedRepairCode.value=document.frmRepairCodeList.hdnSelectedRepairCode.value;
	opener.document.frmSearchRepair.txtRepair.value = document.frmRepairCodeList.hdnSelectedRepairCode.value;
	if(document.frmRepairCodeList.hdnSelectedRepairCode.value == "" || document.frmRepairCodeList.hdnSelectedRepairCode.value == null)
	{
		alertMsgs(eCRDRepair);
		return false;
	}
	
window.close();
			
}

function fnCancel()
{
	window.close();
}

/*function sethdnFindRepair()
{
	document.frmSearchRepair.hdnFindRepair.value = "false";
}*/
function sethdnFindComponent()
{
	document.frmSearchRepair.hdnFindComponent.value = "false";
}