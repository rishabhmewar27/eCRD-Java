function fnApproveComp()
{
	if(fnLtrim(document.frmViewRepairs.txtArRejCom.value)!= "" )
		{
			alert("You can not enter Rejection Comments while approving.");
			return false;
		}
	document.frmViewRepairs.hdnScreenName.value="ApprCompDet";
	document.frmViewRepairs.hdnScreenAction.value="eCRDInsertCompApprovalDet";
	document.frmViewRepairs.submit();
}

function fnRejectComp()
{
	if(fnLtrim(document.frmViewRepairs.txtArRejCom.value)== "" || document.frmViewRepairs.txtArRejCom.value == null)
		{
			alertMsgs(eCRDRejectComments);
			return false;
		}
      if(document.frmViewRepairs.txtArRejCom.value.length > 250)
      {

         alertMsgs(eCRDRejectLength);
         document.frmViewRepairs.txtArRejCom.focus();
         return false;
      }
	document.frmViewRepairs.hdnScreenName.value="ApprCompDet";
	document.frmViewRepairs.hdnScreenAction.value="eCRDRejectComponent";
	document.frmViewRepairs.submit();
}

function fnAddRepair(objForm,strRepairType)
{
	with(objForm)
	{
		hdnScreenName.value="ecrdRepairDetail";
		hdnScreenAction.value="eCRDAddRepair";
      hdnFrom.value="AddRepair";
		hdnRepairType.value = strRepairType;
		hdnClearArrayListFromSession.value = "Clear";
		submit();
	}
}

function fnAddSpecialRepair(objForm,strRepairType)
{
	if(document.frmSpecialRepair != null)
	{
     if(objForm.name == "frmCustomerCatalogAddRepair")
		{
			with(objForm)
			{
				hdnScreenName.value="ecrdRepairDetail";
				hdnScreenAction.value="eCRDAddSpecialRepair";
				hdnRepairType.value = strRepairType;
				if(selEngineModule.value == "" || selEngineModule.value == null)
				{
					alertMsgs(eCRDSelEngModule);
					return false;
				}

				if(selComponent.value == "" || selComponent.value == null)
				{
					alertMsgs(eCRDComponent);
					return false;
				}
				
			}
		}

			else
		if(objForm.name == "frmViewRepairs")
		{
			with(objForm)
				{
					hdnScreenName.value="ecrdRepairDetail";
					hdnScreenAction.value="eCRDAddSpecialRepair";
					hdnFrom.value="AddRepair";
					hdnRepairType.value = strRepairType;
				}
		}
	}

	//if(document.frmCompRepairListing != null)
   else
	{
		if(objForm.name == "frmViewRepairs")
			{
				with(objForm)
					{
						hdnScreenName.value="ecrdRepairDetail";
						hdnScreenAction.value="eCRDAddRepair";
						hdnFrom.value="AddRepair";
						hdnRepairType.value = strRepairType;
					}
			}
	
	}
   objForm.hdnClearArrayListFromSession.value = "Clear";
	objForm.submit();
}

function fnSubmit(strRepairSeqId,strRepairType,strFrom)
{
	//documest.frmViewRepairs.hdnScreenName.value="ecrdRepairDetail";
	//document.frmViewRepairs.hdnScreenAction.value="eCRDModifyRepair";
	if("ComponentListing" == strFrom || "RepairPricing" == strFrom)
	{
		document.frmViewRepairs.hdnScreenName.value = "ecrdListRepair";
		document.frmViewRepairs.hdnScreenAction.value = "eCRDRepairPricing";
	}
	if("APPROVAL" ==strFrom.toUpperCase() || "MODIFYCOMPAPPROVAL" == strFrom.toUpperCase() || "NEWREPAIRAPPROVAL"==strFrom.toUpperCase())
	{
		document.frmViewRepairs.hdnScreenName.value = "ecrdRepairDetail";
		document.frmViewRepairs.hdnScreenAction.value = "eCRDNewCompRepairDetails";
	
	}
    if("MODREPAIRAPPROVAL" == strFrom.toUpperCase())
	{
		document.frmViewRepairs.hdnScreenName.value = "ApprCompDet";
		document.frmViewRepairs.hdnScreenAction.value = "eCRDLoadApprRepairDetails";
	}

 	if("MODIFY" ==strFrom.toUpperCase() || "ADDREPAIR" == strFrom.toUpperCase())
	{
		document.frmViewRepairs.hdnScreenName.value = "ecrdRepairDetail";
		document.frmViewRepairs.hdnScreenAction.value = "eCRDModifyRepair";
	
	}
	
	
 	if("SPECIALREPAIR" == strFrom.toUpperCase())
	{
		document.frmViewRepairs.hdnScreenName.value = "ecrdRepairDetail";
		document.frmViewRepairs.hdnScreenAction.value = "eCRDModifySpecialRepair";
	
	}

	document.frmViewRepairs.hdnRepairType.value=strRepairType;
	document.frmViewRepairs.hdnRepairCode.value=strRepairSeqId;
	  document.frmViewRepairs.hdnViewRepairs.value = "true";
	document.frmViewRepairs.submit();
}
