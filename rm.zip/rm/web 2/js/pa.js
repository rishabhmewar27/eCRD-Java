// Property Browser javascript
//function showTab(input)
//{
//	document.tabForm.selectedTab.value = input;
//	document.tabForm.tabChange.value = true;
//	document.tabForm.submit();
//}


function setCurrentApp(formObj,selectedTab, op, appid)
{
  formObj.selectedTab.value = selectedTab;
  formObj.op.value = op;
  formObj.selectapp.value = appid;
  formObj.changeApp.value = "changeApp";
  alert(selectedTab);
  alert(op);
  alert(appid);
  formObj.submit();
}
function changeTabName(formName,input)
{
  document.form3.tabView.value = input;
  go(formName,'expandBrowser');
}
function expandAllSections(formName,input)
{
  document.form3.expandAll.value = input;
  go(formName,'expandBrowser');
}
function show(obj, input, anchor)
{
  if(obj.value =='False' || obj.value=='')
  {
    obj.value = "True";
  }
  else
  {
    obj.value = "False";
  }
  document.tabForm.tabView.value = input;
  go(formName,'expandBrowser');
}

function editType(formName,pVal, mVal, cVal, sVal)
{
  document.form3.op.value = "modifyProperty";
  document.form3.propertyID.value = pVal;
  document.form3.multiVal.value = mVal;
  document.form3.constVal.value = cVal;
  // Sara -- changed from   document.form3.secName.value = sVal;
  document.form3.secCode.value = sVal;
  go(formName,'modifyProperty');
}

function writeOut(formName,obj)
{
   var tText = "";
   var size = obj.length;
   for(i =0; i<size; i++)
   {
     if (obj.options[i].value != "-1")
     {
       if (i == 0)
       {
         tText = obj.options[i].value + "^";
       }
       else
       {
         tText += obj.options[i].value + "^";
       }
     }
     else
     {
       alert("No valid values. ");
     }
   }
   document.form3.propertyValues.value = tText;
}

function remove(formName,obj, location)
{
  var size = obj.length;
  var count = 0;
  var t = 0;
  if (size != null)
  {
    for (k=1; k<size; k++)
    {
      if(t == location )
      {
        t++;
      }
      obj.options[count].text  = obj.options[t].text ;
      obj.options[count].value = obj.options[t].value ;
      count++;
      t++;
    }
    obj.length = count;
  }
}

function addparm(formName,list2, val)
{
  var size = list2.length;
  var count = size+1;
  var flag = "false";
  if ( size != null )
  {
    list2.length = count;
    for(i=0;i<size;i++) {
      if(list2.options[i].value==val) {
        flag="true";
        count -= 1;
        list2.length = count;
        break;
      }
    }
    if(flag=="false") {
      list2.options[count-1].text = val;
      list2.options[count-1].value = val;
    }
    else {
      alert("Value Already Added");
    }
  }
}

function addparm(formName,list2, val, name)
{
  var size = list2.length;
  var count = size+1;
  var flag = "false";
  if ( size != null )
  {
    list2.length = count;
    for(i=0;i<size;i++) {
      if(list2.options[i].value==val) {
        flag="true";
        count -= 1;
        list2.length = count;
        break;
      }
    }
    if(flag=="false") {
      list2.options[count-1].text = name;
      list2.options[count-1].value = val;
    }
    else {
      alert("Value Already Added");
    }
  }
}



function adduniquemember(formName,list2, val)
{
  val="uid=" + val + ", ou=people, o=ae.ge.com";
  var size = list2.length;
  var count = size+1;
  var flag = "false";
  if ( size != null )
  {
    list2.length = count;
    for(i=0;i<size;i++) {
      if(list2.options[i].value==val) {
        flag="true";
        count -= 1;
        list2.length = count;
        break;
      }
    }
    if(flag=="false") {
      list2.options[count-1].text = val;
      list2.options[count-1].value = val;
    }
    else {
      alert("Value Already Added");
    }
  }
}

function to(formName,obj1)
{
  var choices = obj1;
  var sel = choices.selectedIndex;
  if (sel !=-1)
  {
    if (choices.options[sel].value != null)
    {
      document.form3.propertyID.value =choices.options[sel].value ;
      go(formName,'modifySearch');
    }
  }
}
function from(formName,obj)
{
  var optSelected = obj;
  var sel = optSelected.selectedIndex;
  if (sel != -1)
  {
    if(optSelected.options[sel].value != null)
    {
      remove(formName,optSelected, sel);
    }
  }
}

function submitSearchVals(formName,obj, val)
{
  writeOut(formName,obj);
  document.form3.propertyID.value = val;
  go(formName,'modifiedSearch');
}

// editProperty.jsp

function goEP(formName,input, id)
{
  document.form3.op.value = input;
  document.form3.entityID.value = id;
  document.form3.submit();
}


// TabControlTag.java

//function goto(input)
//{
//	Document.tabForm.selectedTab.value=input;
//    document.tabForm.submit();
//}


function go(formName,input)
{

	if(input=="addAttributeChanges")
	{
	  document.form3.op.value="viewEntity";
	  document.form3.submit();
	}
	else if(input=="clearAttributeChanges")
	{
	  document.form3.op.value="clearAttributeChanges";
	  document.form3.submit();
	}
	else if(input=="clearSearchCriterion")
	{
	  document.form3.op.value="clearSearchCriterion";
	  document.form3.submit();
	}
	else if(input=="addSearchCriterion")
	{
	  document.form3.op.value="createSearch";
	  document.form3.submit();
	}
	else if(input=="search") {
	  document.form3.op.value = "createSearch";
	  document.form3.submit();
	}
        else if(input=="modifyAdmin")
	{
	  document.form3.op.value="modifyAdmin";
	  document.form3.submit();
	}
        else if(input=="submitCreateUser") {
	  document.createUser.op.value = "submitCreateUser";
          document.createUser.submit();
	}
        else if(input=="submitCreateCompany") {
	  document.createCompany.op.value = "submitCreateCompany";
          document.createCompany.submit();
	}
        else if(input=="confirmDeletePeople") {
          document.form3.deleteUids.value = document.EditSecurity.deleteUids.value;
	  document.form3.op.value = "confirmDeletePeople";
          document.form3.submit();
	}
        else if(input=="deletePeople") {
	  document.form3.op.value = input;
          document.form3.submit();
	}
	else if(input=="submit")
	{
	  var atts = eval("document." + formName + ".attributes[0].value");
	  var users = eval("document." + formName + ".users[0].value");
	  if(atts != "Enter Modifications" && users != "Enter Users")
	  {
		document.form3.op.value="submitMassUpdate";
		document.form3.submit();
	  }else{
		alert("Make sure to enter values for attributes and users to mass update.");
	  }
	}
	else if(input=="cancel")
	{
	  document.form3.op.value='';
	  document.form3.submit();
	}
	else if(input=="removePropertyID")
	{
	  var atts = eval("document." + formName + ".attributes[0].value");
	  var users = eval("document." + formName + ".users[0].value");
	  if(atts!= "Enter Modifications")
	  {
		  document.form3.op.value = "removePropertyID";
		  var sel = eval("document." + formName + ".attributes.selectedIndex");
		  if(sel != -1)
		  {
			var s = eval("document." + formName + ".attributes.options[sel].value");
			if (s!= null)
			{
			  document.form3.propertyID.value = s;
			  document.form3.submit();
			}
		  }
	  }
	}
	else if(input=="removeEntityID")
	{
	  var atts = eval("document." + formName + ".attributes[0].value");
	  var users = eval("document." + formName + ".users[0].value");
	  if(users != "Enter Users")
	  {
		  document.form3.op.value = "removeEntityID";
		  var sel = eval("document." + formName + ".users.selectedIndex");
		  if(sel != -1)
		  {
			var selec = eval("document." + formName + ".users.options[sel].value");
			if (selec != null)
			{
			  document.form3.entityID.value =selec
			  document.form3.submit();
			}
		  }
	  }
	}
    else if(input=="gotohome")
    {
  	  document.form3.op.value = "createSearch";
	  document.form3.submit();
    }
    else if(input=="rollback")
    {
	  document.form3.op.value = "rollBack";
	  document.form3.submit();
    }
    else if(input=="goMassUpdate")
    {
	  document.form3.op.value = "createMassUpdate";
	  document.form3.submit();
    }
    else if(input=="quicksearch")
    {
	  document.form3.op.value = "quickSearch";
	  document.form3.tabChange.value="false";
	  document.form3.selectedTab.value="";
	  document.form3.entityID.value = document.usrInfo.currentEntity.value;
	  document.form3.submit();
    }
    else
    {
     document.form3.op.value = input;
     document.form3.submit();
    }

}

function createWindow(url,name,features)
    {
        var popupwin = window.open(url, name, features);
    }

// Edit Property javascript

function compareText (option1, option2)
{
  return option1.text < option2.text ? -1 :
    option1.text > option2.text ? 1 : 0;
}

function sortSelect (formName,select, compareFunction) {
  if(select.length>0) {
    if (!compareFunction)
      compareFunction = compareText;
    var options = new Array (select.options.length);
    for (var i = 0; i < options.length; i++)
      options[i] =
        new Option (
          select.options[i].text,
          select.options[i].value,
          select.options[i].defaultSelected,
          select.options[i].selected
        );
    options.sort(compareFunction);
    select.options.length = 0;
    for (var i = 0; i < options.length; i++)
      select.options[i] = options[i];
  }
}

function add(formName,list1, list2, sel)
{
  var size = list2.length;
  var count = size+1;
  if ( size != null )
  {
    list2.length = count;
    list2.options[count-1].text  = list1.options[sel].text;
    list2.options[count-1].value = list1.options[sel].value;
  }
}
function toEP(formName,obj1, obj2)
{
  var choices = obj1;
  var optSelected = obj2;
  var sel = choices.selectedIndex;
  var numArr = new Array();
  var remIndex=0;
  if (sel !=-1)
  {
    if (choices.options[sel].value != null)
    {
      for(i=0;i<choices.length;i++)
      {
        if (choices.options[i].selected == true)
        {
          numArr[remIndex] = i;
          add(formName,choices, optSelected, i);
          remIndex++;
        }
      }
      var k = numArr.length;
      for(j=0;j<numArr.length;j++)
      {
        remove(formName,choices, numArr[k-1]);
        k--;
      }
    }
  }
  sortSelect(formName,optSelected, compareText);
}

function submitVals(formName,obj, opVal)
{
  if(document.EditProperty.sMassOp!=null) {
    var isChecked;
    var checkedValue;
    for(var i=0;i<2;i++) {
      var isChecked = document.EditProperty.sMassOp[i].checked;
      if(isChecked) {
        checkedValue = document.EditProperty.sMassOp[i].value;
      }
    }
    document.form3.MassOp.value = checkedValue;
  }

  //writeOut(formName,obj);
  writeOutEP(obj, document.form3.propertyValues);
  go(formName,opVal);
}

function submitSecurity(formName,obj, obj2, opVal)
{
  if(document.EditProperty.sMassOp!=null) {
    var isChecked;
    var checkedValue;
    for(var i=0;i<2;i++) {
      var isChecked = document.EditProperty.sMassOp[i].checked;
      if(isChecked) {
        checkedValue = document.EditProperty.sMassOp[i].value;
      }
    }
    document.form3.MassOp.value = checkedValue;
  }
  writeOutEP(obj, document.form3.propertyValues);
  writeOutEP(obj2, document.form3.securityValues);
  go(formName,opVal);
}

function writeOutEP(obj, obj2)
{
   var tText = "";
   var size = obj.length;
   for(i=0;i<size;i++)
   {
     if (obj.options[i].value != "-1")
     {
       if (i == 0)
       {
         tText = obj.options[i].value + "^";
       }
       else
       {
         tText += obj.options[i].value + "^";
       }
     }
     else
     {
       alert("No valid values. ");
     }
   }
     obj2.value = tText;
}

function update(formName,tText)
{
  document.form3.propertyValues.value = tText + "^";
  go(formName,'submitModifiedProperty');
}

function updateSecurity(formName,tText)
{

//  var isChecked;
//  var checkedValue;
//  for(var i=0;i<4;i++) {
//    var isChecked = document.EditSecurity.genInfo[i].checked;
//    if(isChecked) {
//      checkedValue = document.EditSecurity.genInfo[i].value;
//    }
//  }
//  document.form3.generalGroup.value = checkedValue;
  if(document.EditSecurity.portalInfo1 != null) {
    var isAUchkd = document.EditSecurity.portalInfo1.checked;
    var isAAchkd = document.EditSecurity.portalInfo3.checked;
    var isDUchkd = document.EditSecurity.portalInfo2.checked;
    document.form3.adminUser.value = isAUchkd;
    document.form3.defaultUser.value = isDUchkd;
    document.form3.appadminUser.value = isAAchkd;
  }
  document.form3.propertyValues.value = tText + "^";
  go(formName,'submitModifiedAdmin');
}



