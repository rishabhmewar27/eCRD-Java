This folder should contain web content accessible via browsers
