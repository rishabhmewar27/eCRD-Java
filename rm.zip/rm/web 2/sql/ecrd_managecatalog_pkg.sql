CREATE OR REPLACE PACKAGE ecrd_managecatalog_pkg
AS
/***********************************************************************/
--
-- Copyright Message       : Copyright(c) 2004 GE Aircraft Engines
-- Title                   : eecrd_managecatalog_pkg
-- Author                  : Patni Offshore
-- Company                 : GE Aircraft Engines
-- Date                    : October 2004
-- Purpose                 : File contains Package Spec and body for Procs
--                           for Catalog Creation
--
-- Modifications           :
-- Date                    Description
-- [DD-MMM-YYYY]           A brief description of change should go here like
--                         who had made change, why change was implemented
--                         and where change is made.
--
-- 06-oct-2004             New Code First Version
-- 05-Sep-2006             Patni Team - Modified ecrd_download_batch_prc,
--                                      ecrd_copy_default_catalog_prc,
--                                      ecrd_copy_apply_prc
--
/***********************************************************************/

TYPE STORE_VALUES  IS VARRAY(1000000) OF VARCHAR2(32767);

TYPE result_cursor IS REF CURSOR;

TYPE ecrd_modules IS RECORD
(
    modules_desc          crd_crc_module.module_name%TYPE
);

TYPE ecrd_inflation_index IS RECORD
(
    index_value crd_e_inflation_index.index_value%TYPE,
    index_desp crd_e_inflation_index.index_dependancy%TYPE
);


TYPE ecrd_module_table IS TABLE OF ecrd_modules INDEX BY BINARY_INTEGER;

TYPE ecrd_inflation_index_table IS TABLE OF ecrd_inflation_index INDEX BY BINARY_INTEGER;

TYPE rec_holder IS TABLE OF LONG INDEX BY BINARY_INTEGER;

--
PROCEDURE ecrd_list_catalog_prc
 (
             P_CatalogType_in IN crd_e_catalog.catalog_type%type,
          P_CatalogName_in IN crd_e_catalog.catalog_description%type,
          P_EngineModelCode_in IN crd_e_catalog.eng_mdl_number%type,
          P_ComponentEffDate_in IN varchar2,
          P_ComponentEndDate_in IN varchar2,
            P_CatalogList_out OUT result_cursor
 );

/************************************************************************
 *              PROCEDURE TO CREATE A BLANK CATALOG
 ************************************************************************/


PROCEDURE ecrd_create_blank_catalog_prc(
                                 p_in_eng_code IN crd_crc_eng_mdl_display.ENG_MDL_NUMBER%TYPE
                              ,p_in_eng_desc IN crd_crc_eng_mdl_display.ENG_MDL_DESC%TYPE
                              ,p_in_start_date IN VARCHAR2
                              ,p_in_end_date IN VARCHAR2
                              ,p_in_cat_desc IN crd_e_catalog.CATALOG_DESCRIPTION%TYPE
                              ,p_in_cat_ind IN crd_e_catalog.CAT_IND%TYPE     --changes by vikrant
                              ,p_in_user_id IN crd_crc_user.USERID%TYPE
                              ,p_in_vis_to_cwc IN VARCHAR2
                              ,p_out_cat_seqid OUT VARCHAR2
                              ,p_out_error_msg OUT VARCHAR2);

/************************************************************************
 *              PROCEDURE TO COPY AN EXISTING  DEFAULT CATALOG
 ************************************************************************/

PROCEDURE ecrd_copy_default_catalog_prc(
                                 p_in_copy_seq_id IN crd_e_catalog.CATALOG_SEQ_ID%TYPE
                                 ,p_in_eng_code IN crd_crc_eng_mdl_display.ENG_MDL_NUMBER%TYPE
                                 ,p_in_eng_desc IN crd_crc_eng_mdl_display.ENG_MDL_DESC%TYPE
                                 ,p_in_start_date IN VARCHAR2
                                 ,p_in_end_date IN VARCHAR2
                                 ,p_in_cat_desc IN crd_e_catalog.CATALOG_DESCRIPTION%TYPE
                                 ,p_in_cat_ind IN crd_e_catalog.CAT_IND%TYPE    --changes by vikrant
                                 ,p_in_user_id IN crd_crc_user.USERID%TYPE
                                 ,p_in_vis_to_cwc IN VARCHAR2
                                 ,p_out_cat_seqid OUT VARCHAR2
                                 ,p_out_error_msg OUT VARCHAR2);


/************************************************************************
 *              PROCEDURE TO GET THE LIST OF EXISTING CATALOG
 ************************************************************************/

PROCEDURE ecrd_get_cataloglist_prc     (
                                 p_out_catalog_list   OUT result_cursor
                                 ,p_out_err_msg OUT VARCHAR2
                              );


/************************************************************************
 *              PROCEDURE TO GET THE SEQ ID OF DEFAULT CATALOG
 ************************************************************************/

PROCEDURE ecrd_get_default_seqid_prc(
                                     p_in_eng_code IN crd_crc_eng_mdl_display.ENG_MDL_NUMBER%TYPE
                                  ,p_out_seqid OUT VARCHAR2
                                  ,p_out_error_msg OUT VARCHAR2
                                  );


PROCEDURE ecrd_save_default_catalog_prc(
                                    p_in_eng_model IN crd_crc_eng_mdl_display.ENG_MDL_NUMBER%TYPE
                                       ,p_in_start_date IN VARCHAR2
                                 ,p_in_end_date IN VARCHAR2
                                       ,p_in_cat_desc IN crd_e_catalog.CATALOG_DESCRIPTION%TYPE
                                       ,p_out_error_msg OUT VARCHAR2
                                     );


PROCEDURE ecrd_save_eng_model_prc      (
                                 p_in_eng_family IN VARCHAR2
                                    ,p_in_eng_model IN VARCHAR2
                                 ,p_in_osb_eng_code IN VARCHAR2
                                 ,p_out_error_msg OUT VARCHAR2
                              );


PROCEDURE ecrd_get_model_prc        (
                                       p_in_model_code IN VARCHAR2,
                                 p_out_model_desc OUT VARCHAR2,
                                 p_out_model_cd OUT VARCHAR2
                              );

PROCEDURE ecrd_get_module_prc(
                                     p_in_module_cd IN crd_crc_module.module_seq_id%TYPE,
                                     p_out_module_cd OUT VARCHAR2,
                                     p_out_module_desc OUT VARCHAR2);

PROCEDURE ecrd_save_module_prc(
                                     p_in_model_code IN VARCHAR2,
                                     p_in_module IN VARCHAR2,
                                     p_in_user_id IN VARCHAR2,
                                     p_in_row_delimiter IN VARCHAR2,
                                     p_in_col_delimiter IN VARCHAR2,
                                     p_out_eng_module OUT result_cursor,
                                     p_out_message OUT VARCHAR2);

PROCEDURE ecrd_delimiter_prc(
          p_name_str         IN LONG,
          p_row_delimit      IN VARCHAR2,
          p_field_delimit    IN VARCHAR2,
          p_rec_holder      OUT rec_holder);

PROCEDURE ecrd_remove_module_prc(
          p_in_module_cd IN crd_crc_module.module_seq_id%TYPE,
          p_out_message OUT VARCHAR2);

PROCEDURE ecrd_update_module_prc(
          p_in_module_cd IN crd_crc_module.module_seq_id%TYPE,
          p_in_module_desc IN VARCHAR2,
          p_in_user_id IN crd_crc_user.userid%TYPE,
          p_out_message OUT VARCHAR2);

PROCEDURE ecrd_download_batch_prc(
          p_in_engine_model     IN VARCHAR2,
          p_in_catalog_id       IN VARCHAR2,
          p_in_class            IN VARCHAR2,
          p_in_site             IN VARCHAR2,
          p_catalog_data_cur OUT result_cursor
          );

PROCEDURE ecrd_list_eng_modules_prc(
                   p_in_eng_model_code IN crd_crc_module.eng_mdl_number%TYPE
                   ,p_in_boolean IN VARCHAR2
                  ,p_out_eng_module_cur OUT result_cursor
                  );


PROCEDURE ecrd_update_module_desc_prc(
          p_in_engine_model IN crd_crc_module.eng_mdl_number%TYPE,
          p_in_module_cd IN crd_crc_module.module_seq_id%TYPE,
          p_in_module_desc IN crd_crc_module.module_name%TYPE,
          p_out_message OUT VARCHAR2);

PROCEDURE ecrd_crc_modules_prc(p_out_module_cur OUT result_cursor);
--
PROCEDURE ecrd_get_ctlg_cust_data_prc (p_in_catalog_seq_id        IN crd_e_catalog.catalog_seq_id%TYPE
                                      ,p_out_ctlg_cust_data       OUT result_cursor);
--
PROCEDURE ecrd_get_customer_ctlg_prc (p_in_catalog_seq_id    IN crd_e_catalog.catalog_seq_id%TYPE
                             ,p_out_catalog_data         OUT result_cursor
                                      ,p_out_ctlg_cust_data       OUT result_cursor
                                      ,p_out_escalation_ind OUT VARCHAR2);
--
PROCEDURE ecrd_get_catalog_data_prc(p_in_catalog_seq_id        IN crd_e_catalog.catalog_seq_id%TYPE
                                   ,p_out_catalog_data         OUT result_cursor
                                   ,p_out_escalation_ind OUT VARCHAR2);
--
PROCEDURE ecrd_get_rules_prc(
      p_in_catalog IN VARCHAR2,
      p_in_year IN VARCHAR2,
      p_in_rule_level IN VARCHAR2,
      p_in_module_code IN VARCHAR2,
      p_in_component_code IN crd_e_component.component_code%TYPE,
      p_in_repair_seq_id IN VARCHAR2,
      p_out_rules OUT result_cursor,
      p_out_inflation OUT result_cursor,
      p_out_default_flow OUT result_cursor);
--
PROCEDURE ecrd_create_rule_prc(
      p_in_RuleLevel IN VARCHAR2,
      p_in_catalog_seq_id IN crd_e_catalog.catalog_seq_id%TYPE,
      p_in_ComponentCd IN crd_e_component.component_code%TYPE,
      p_in_ModuleCd IN crd_crc_module.module_seq_id%TYPE,
      p_in_RepairCd IN crd_e_repair.repair_seq_id%TYPE,
      p_in_Year IN VARCHAR2,
      p_in_TAT IN crd_e_ctlg_contracted.tat%TYPE,
      p_in_Discount IN crd_e_ctlg_contracted.discount%TYPE,
      p_in_DefaultValCompare IN crd_e_catalog.calculated_price_default_ind%TYPE,
      p_in_FlowChangesFrmDef IN crd_e_catalog.flowdown_changes_ind%TYPE,
      p_in_Escalation IN crd_e_ctlg_contracted.escalation%TYPE,
      p_in_IndexDep IN VARCHAR2,
      p_in_UserId IN crd_crc_user.userid%TYPE,
      p_out_message OUT VARCHAR2
);
--
PROCEDURE ecrd_view_rules_prc(
      p_in_catalog_seq_id IN VARCHAR2,
      p_in_year IN VARCHAR2,
      p_out_catalog_rules OUT result_cursor,
      p_out_inflation_rules OUT result_cursor,
      p_out_module_rules OUT result_cursor,
      p_out_component_rules OUT result_cursor,
      p_out_repair_rules OUT result_cursor);

PROCEDURE ecrd_copy_apply_prc(
      p_in_catalog_seq_id IN crd_e_catalog.catalog_seq_id%TYPE,
      p_in_user_id IN crd_crc_user.userid%TYPE,
      p_out_message OUT VARCHAR2);

PROCEDURE ecrd_save_cust_catalog_prc(p_in_engine_model_code IN crd_e_catalog.eng_mdl_number%TYPE,
                    p_in_start_date  IN VARCHAR2,
                    p_in_end_date IN VARCHAR2,
                    p_in_customer_code         IN VARCHAR2,
                    p_in_cust_contract_code    IN VARCHAR2,
                    p_in_cust_contract_desc    IN VARCHAR2,
                    p_in_contract_start_date         IN VARCHAR2,
                    p_in_contract_end_date        IN VARCHAR2,
                    p_in_catalog_number             IN crd_e_catalog.catalog_number%TYPE,
                    p_in_catalog_desc             IN crd_e_catalog.catalog_description%TYPE,
                    p_in_cat_ind         IN crd_e_catalog.CAT_IND%TYPE,          --changes by vikrant
                    p_in_parent_catalog_id   IN VARCHAR2,
                    p_in_user_id                   IN crd_crc_user.USERID%TYPE,
                    p_out_catalog_data         OUT result_cursor,
                    p_out_ctlg_cust_data       OUT result_cursor,
                    p_out_cat_seq_id OUT VARCHAR2,
                    p_out_message OUT VARCHAR2,
                    p_out_escalation OUT VARCHAR2
                   );
FUNCTION ecrd_string_seperator_fnc(p_in_instr  IN LONG,
                      p_in_seprator      IN VARCHAR2
                     )
                      RETURN STORE_VALUES;
PROCEDURE ecrd_repair_pricing_prc(
     p_in_rep_seq_id IN crd_e_repair_catalog.repair_seq_id%TYPE,
      p_in_catalog_seq_id IN crd_e_repair_catalog.catalog_seq_id%TYPE,
     p_in_effective_date IN VARCHAR2,
      p_out_message OUT VARCHAR2);


PROCEDURE ecrd_list_engine_catalog_prc(p_in_customer IN crd_e_customer.customer_code%TYPE,
                           p_in_startdate IN VARCHAR2,
                           p_in_enddate IN VARCHAR2,
                           p_in_catalog_type IN VARCHAR2,
                           p_in_catalog_num  IN crd_e_catalog.catalog_number%TYPE,
                           p_in_cat_ind  IN VARCHAR2,    --changes by vikrant
                           p_in_catalog_ind  IN VARCHAR2,
                           p_in_EngineModel IN crd_e_catalog.eng_mdl_number%TYPE,
                           p_out_list_cust_cur OUT result_cursor );


PROCEDURE ecrd_save_catalog_prc( p_in_cat_seq_id IN VARCHAR2,
                          p_in_cat_desc IN crd_e_catalog.CATALOG_DESCRIPTION%TYPE,
                          p_in_cat_end_date IN VARCHAR2,
                          p_in_cust_details IN VARCHAR2,
                          p_in_user_id IN VARCHAR2,
                          p_out_ctlg_cust_data OUT result_cursor,
                          p_out_message OUT VARCHAR2
                          );



PROCEDURE ecrd_update_rule_prc(
      p_in_RuleLevel IN VARCHAR2,
      p_in_catalog_seq_id IN crd_e_catalog.catalog_seq_id%TYPE,
      p_in_ComponentCd IN crd_e_component.component_code%TYPE,
      p_in_ModuleCd IN crd_crc_module.module_seq_id%TYPE,
      p_in_RepairCd IN crd_e_repair.repair_seq_id%TYPE,
      p_in_Year IN VARCHAR2,
      p_in_TAT IN crd_e_ctlg_contracted.tat%TYPE,
      p_in_Discount IN crd_e_ctlg_contracted.discount%TYPE,
      p_in_DefaultValCompare IN crd_e_catalog.calculated_price_default_ind%TYPE,
      p_in_FlowChangesFrmDef IN crd_e_catalog.flowdown_changes_ind%TYPE,
      p_in_Escalation IN crd_e_ctlg_contracted.escalation%TYPE,
      p_in_IndexDep IN VARCHAR2,
      p_in_UserId IN crd_crc_user.userid%TYPE,
      p_out_message OUT VARCHAR2
);

PROCEDURE ecrd_copy_catalog_rule_prc(
      p_in_catalog_seq_id IN VARCHAR2,
      p_in_copied_catalog_seq_id IN VARCHAR2,
      p_in_user_id IN crd_crc_user.userid%TYPE,
      p_out_message OUT VARCHAR2,
      p_flowdown_ind OUT crd_e_catalog.flowdown_changes_ind%TYPE,
      p_defaut_price_ind OUT crd_e_catalog.calculated_price_default_ind%TYPE);

PROCEDURE ecrd_check_rules_prc(
      p_in_catalog IN VARCHAR2,
      p_in_year IN VARCHAR2,
      p_in_rule_level IN VARCHAR2,
      p_in_module_code IN VARCHAR2,
      p_in_component_code IN crd_e_component.component_code%TYPE,
      p_in_repair_seq_id IN VARCHAR2,
      p_out_message OUT VARCHAR);
/*
*/
PROCEDURE ecrd_get_lbr_hrs_prc(p_in_repairs                    IN VARCHAR2
                            ,p_in_user_id             IN crd_crc_user.userid%TYPE
                        ,p_out_lbr_hrs_refcur            OUT result_cursor
                          ,p_out_lbr_rate            OUT result_cursor);
/*
*/
PROCEDURE ecrd_get_childrprs_prc(p_in_repair_seq_id     IN crd_e_repair.parent_repair_seq_id%TYPE
                         ,p_out_children_refcur  OUT result_cursor);
/*
*/
PROCEDURE ecrd_delete_rule_prc(p_in_repair         IN  VARCHAR2
                       ,p_in_catalog_seq_id     IN crd_e_catalog.catalog_seq_id%TYPE
                       );
/*
*/
PROCEDURE ecrd_delete_rule_prc(p_in_year           IN  VARCHAR2,
                        p_in_rule_cd IN VARCHAR2,
                        p_in_component IN VARCHAR2,
                        p_in_module IN VARCHAR2,
                        p_in_repair IN VARCHAR2,
                        p_in_catalog_seq_id     IN crd_e_catalog.catalog_seq_id%TYPE,
                        p_out_message OUT VARCHAR2
                       );

/*
This function checks if there is any ACTIVE customer contract for Specified
Engine Model, Customer Code and Contract Number combination.
It returns 'Y' if found else 'N'.
*/
FUNCTION ecrd_chk_customer_contract_fnc
(
    p_in_engine_model   IN VARCHAR2,
    p_in_customer_code  IN VARCHAR2,
    p_in_contract_number   IN VARCHAR2,
    p_in_cat_start_date   IN VARCHAR2,
    p_in_cat_end_date   IN VARCHAR2
)
RETURN VARCHAR2;
/*
*/
PROCEDURE ecrd_exist_cust_cata_prc(
                       p_in_eng_model IN crd_crc_eng_mdl_display.eng_mdl_number%TYPE,
                       p_in_customer_code IN VARCHAR2,
                       p_in_contract_id IN VARCHAR2,
                       p_in_cata_start_date IN VARCHAR2,
                       p_in_cata_end_date IN VARCHAR2,
                       p_out_message OUT VARCHAR2);
/*
*/
END ecrd_managecatalog_pkg;
/
CREATE OR REPLACE PACKAGE BODY ecrd_managecatalog_pkg AS


  PROCEDURE ecrd_list_catalog_prc
 (
             P_CatalogType_in IN crd_e_catalog.CATALOG_TYPE%type,
          P_CatalogName_in IN crd_e_catalog.catalog_description%type,
          P_EngineModelCode_in IN crd_e_catalog.eng_mdl_number%type,
          P_ComponentEffDate_in IN varchar2,
          P_ComponentEndDate_in IN varchar2,
            P_CatalogList_out OUT result_cursor
 )
    IS
       v_main_query long;
    v_where_query long;
     v_query long;
   BEGIN
--     delete from deepa_test; commit;
    v_main_query:= 'SELECT cec.catalog_seq_id,
                     ccemd.eng_mdl_desc,
                     TO_CHAR(cec.catalog_effective_date) Start_Date,
                     TO_CHAR(cec.catalog_effective_date,''YYYY/MM/DD'') Sortable_Start_Date,
                      TO_CHAR(cec.catalog_end_date) End_Date,
                     TO_CHAR(cec.catalog_end_date,''YYYY/MM/DD'') Sortable_End_Date,
                     cec.catalog_description
               FROM crd_e_catalog cec,
                    crd_crc_eng_mdl_display ccemd
               WHERE
                   cec.eng_mdl_number = ccemd.eng_mdl_number AND
                   cec.catalog_type='|| ''''|| P_CatalogType_in ||'''' ||
                   'AND cec.ENG_MDL_NUMBER ='
                   ||''''|| P_EngineModelCode_in||'''';


   IF  P_CatalogName_in IS NOT NULL
    THEN
       v_where_query:=v_where_query||' AND UPPER(cec.CATALOG_NUMBER) LIKE UPPER('''||P_CatalogName_in||'%'||''')';
    END IF;

   IF  P_ComponentEffDate_in IS NOT NULL
    THEN
       v_where_query:=v_where_query||' AND cec.CATALOG_EFFECTIVE_DATE >= TO_DATE('''||P_ComponentEffDate_in||''',''MM/DD/YYYY'')';
    END IF;

   IF  P_ComponentEndDate_in IS NOT NULL
    THEN
       v_where_query:=v_where_query||' AND cec.CATALOG_END_DATE <= TO_DATE('''||P_ComponentEndDate_in||''',''MM/DD/YYYY'')';
    END IF;

    v_query := v_main_query||v_where_query;

   OPEN P_CatalogList_out
       FOR v_query;
EXCEPTION
WHEN OTHERS
THEN
   RAISE_APPLICATION_ERROR(-20020,'***Error in eCRDManageCatalog_pkg.ecrd_list_catalog_prc-0'||SQLCODE||'-'||SUBSTR(SQLERRM,1,100));
END ecrd_list_catalog_prc;
--
/********************************************************************************/
/* Procedure Name :  ecrd_create_blank_catalog_prc                              */
/*                                                             */
/* Description    :  This procedure is used to Create blank catalog           */
/*                                                                   */
/*                                                          */
/* Input Parameters : Engine Model Code                              */
/*                  Engine Model Description                         */
/*                  Start date,                                      */
/*               End date,                                     */
/*               Catalog desc,                                    */
/*               User Id                                          */
/*                                                                         */
/* Out Parameters :  Catalog seqID                                    */
/*                    Error mesage                                   */
/********************************************************************************/
--
PROCEDURE ecrd_create_blank_catalog_prc(
                                 p_in_eng_code IN crd_crc_eng_mdl_display.ENG_MDL_NUMBER%TYPE
                              ,p_in_eng_desc IN crd_crc_eng_mdl_display.ENG_MDL_DESC%TYPE
                              ,p_in_start_date IN VARCHAR2
                              ,p_in_end_date IN VARCHAR2
                              ,p_in_cat_desc IN crd_e_catalog.CATALOG_DESCRIPTION%TYPE
                              ,p_in_cat_ind IN crd_e_catalog.CAT_IND%TYPE   --changes by vikrant
                              ,p_in_user_id IN crd_crc_user.USERID%TYPE
                              ,p_in_vis_to_cwc IN VARCHAR2
                              ,p_out_cat_seqid OUT VARCHAR2
                              ,p_out_error_msg OUT VARCHAR2
                              )
IS
v_eng_model_cnt NUMBER:=0;
v_in_start_date DATE :=null;
v_in_end_date DATE := null;
v_vis_to_cwc VARCHAR2(10) := NULL;
BEGIN


v_in_start_date := TO_DATE(p_in_start_date,ecrd_utils_pkg.G_DATE_FORMAT);
v_in_end_date   := TO_DATE(p_in_end_date,ecrd_utils_pkg.G_DATE_FORMAT);

/*Checks if the Engine Model alread*/
SELECT COUNT(1)
INTO   v_eng_model_cnt
FROM   crd_crc_eng_mdl_display ccemd
WHERE  ccemd.eng_mdl_number=p_in_eng_code;

   IF p_in_vis_to_cwc =ecrd_utils_pkg.G_CHECKBOX_CHECKED
   THEN
         v_vis_to_cwc := ecrd_utils_pkg.G_DEFAULT_CATALOG_IND ;
   ELSE
         v_vis_to_cwc := ecrd_utils_pkg.G_ASTRIX;
   END IF;

   IF v_eng_model_cnt<> 0
      THEN
        p_out_error_msg:='EXIST';

   ELSE
    BEGIN

   ---            INSERTING INTO ENGINE MODEL TABLE

      INSERT INTO crd_crc_eng_mdl_display ccemd
      (
            ccemd.ENG_MDL_NUMBER
            ,ccemd.ENG_MDL_DESC
            ,ccemd.ENG_MDL_STS_CD
            ,ccemd.CATALOG_IND
            ,ccemd.CREATED_BY
            ,ccemd.CREATION_DATE
            ,ccemd.LAST_UPDATE_DATE
            ,ccemd.LAST_UPDATED_BY
      )
      VALUES
      (
            p_in_eng_code
            ,p_in_eng_desc
            ,ecrd_utils_pkg.G_END_MDL_STS_CODE
            ,v_vis_to_cwc
            ,p_in_user_id
            ,sysdate
            ,sysdate
            ,p_in_user_id
      );


      ---      INSERTING INTO CATALOG TABLE


      INSERT INTO CRD_E_CATALOG cec
      (
            cec.catalog_seq_id
            ,cec.eng_mdl_number
            ,cec.catalog_effective_date
            ,cec.catalog_end_date
            --/* 5/5/2006 Patni For Assigned Catalog Description to Catalog Number Begin*/
            ,cec.catalog_number
            --/* 5/5/2006 Patni For Assigned Catalog Description to Catalog Number End*/
            ,cec.catalog_description
            ,cec.CREATED_BY
            ,cec.CATALOG_TYPE
            ,cec.ACTIVE_IND
            ,cec.creation_date
            ,cec.last_update_date
            ,cec.last_updated_by
            ,cec.CAT_IND    --changes by vikrant
      )
      VALUES
      (
            crd_e_catalog_seq.nextval
            ,p_in_eng_code
            ,v_in_start_date
            ,v_in_end_date
            --/* 5/5/2006 Patni For Assigned Catalog Description to Catalog Number Begin*/
            ,p_in_cat_desc
            --/* 5/5/2006 Patni For Assigned Catalog Description to Catalog Number End*/
            ,p_in_cat_desc
            ,p_in_user_id
            ,ecrd_utils_pkg.G_DEFAULT_CATALOG
            ,ecrd_utils_pkg.G_ACTIVE
            ,sysdate
            ,sysdate
            ,p_in_user_id
            ,p_in_cat_ind    ----changes by vikrant
      );


    ---     SELECTING CATALOG SEQ ID OF NEW DEFAULT CATALOG CREATED


      SELECT cec.CATALOG_SEQ_ID
      INTO p_out_cat_seqid
      FROM crd_e_catalog cec
      WHERE  cec.eng_mdl_number=p_in_eng_code;

---
END;

END IF;

 EXCEPTION
    WHEN OTHERS
   THEN ROLLBACK;
       RAISE_APPLICATION_ERROR (-20021,'ERROR IN ECRD_MANAGECATALOG_PKG.ECRD_CREATE_BLANK_CATALOG_PRC===INSERT IN crd_e_catalog TABLE'||SQLCODE||'-'||SUBSTR(SQLERRM,1,100));


END ecrd_create_blank_catalog_prc;
--
/********************************************************************************/
/* Procedure Name :  ecrd_copy_default_catalog_prc                              */
/*                                                             */
/* Description    :  This procedure is used to Copy an existing catalog       */
/*                                                                   */
/* Input Parameters : Copying Catalog SeqId                             */
/*                  Engine Model Code                                */
/*                  Endine Model Description                         */
/*                  Start date,                                      */
/*               End date,                                     */
/*               Catalog desc,                                    */
/*               User Id                                          */
/*                                                                         */
/* Out Parameters :  Catalog seqID                                    */
/*                    Error mesage                                   */
/********************************************************************************/
----
PROCEDURE ecrd_copy_default_catalog_prc(
                                 p_in_copy_seq_id IN crd_e_catalog.CATALOG_SEQ_ID%TYPE
                                 ,p_in_eng_code IN crd_crc_eng_mdl_display.ENG_MDL_NUMBER%TYPE
                                 ,p_in_eng_desc IN crd_crc_eng_mdl_display.ENG_MDL_DESC%TYPE
                                 ,p_in_start_date IN VARCHAR2
                                 ,p_in_end_date IN VARCHAR2
                                 ,p_in_cat_desc IN crd_e_catalog.CATALOG_DESCRIPTION%TYPE
                                 ,p_in_cat_ind IN crd_e_catalog.CAT_IND%TYPE   --changes by vikrant
                                 ,p_in_user_id IN crd_crc_user.USERID%TYPE
                                 ,p_in_vis_to_cwc IN VARCHAR2
                                 ,p_out_cat_seqid OUT VARCHAR2
                                 ,p_out_error_msg OUT VARCHAR2)

IS

-- Cursor to get the Engine Modules of Engine Model being Copied


   CURSOR c_module_list (v_old_eng_model VARCHAR2)
   IS
      SELECT ccm.MODULE_SEQ_ID,ccm.MODULE_NAME
      FROM CRD_CRC_MODULE ccm
      WHERE ccm.ENG_MDL_NUMBER=v_old_eng_model;



-- Cursor to get Parent/Individual repair of the Engine Model Being copied


    CURSOR c_repair_list(v_module_seq_id NUMBER)
    IS
            SELECT
               cer.REPAIR_SEQ_ID
               ,cer.COMPONENT_CODE
               ,cer.REPAIR_TYPE
               ,cer.REPAIR_DESCRIPTION
               ,cer.PARENT_REPAIR_SEQ_ID
               ,cer.REPAIR_REFERENCE
               ,cer.REPAIR_COMMENTS
               ,cer.REPAIR_REFERENCE_FORMAT
               ,cer.REPAIR_EFFECTIVE_DATE
               ,cer.REPAIR_END_DATE
               ,cer.REPAIR_VOLUME
               ,cer.RPR_OSB_UNIQUE_NUMBER

         FROM     CRD_E_REPAIR cer
         WHERE   cer.module_seq_id = v_module_seq_id
         AND      (cer.repair_type = ecrd_utils_pkg.G_GROUP_REPAIR OR cer.repair_type = ecrd_utils_pkg.G_INDIVIDUAL_REPAIR)           -- don't consider child repairs
         AND      (cer.repair_end_date is NULL or cer.repair_end_date > SYSDATE);


-- Cusrsor for child repair


         CURSOR c_child_repair_list (v_parent_repair_seq_id NUMBER, v_module_seq_id NUMBER)
         IS
         SELECT cer.repair_seq_id
         FROM   CRD_E_REPAIR cer
         WHERE  cer.parent_repair_seq_id = v_parent_repair_seq_id
         AND      cer.module_seq_id = v_module_seq_id
         AND      (cer.repair_end_date is NULL or cer.repair_end_date > SYSDATE);



v_new_cat_seqid         crd_e_catalog.CATALOG_SEQ_ID%TYPE;
v_new_eff_date             crd_e_catalog.CATALOG_EFFECTIVE_DATE%TYPE;
v_old_eng_model         crd_crc_eng_mdl_display.ENG_MDL_NUMBER%TYPE;
v_user_id               VARCHAR2(500):=p_in_user_id;
v_eng_model_cnt         NUMBER:=0;
v_module_seq_id            crd_crc_module.MODULE_SEQ_ID%TYPE;
v_repair_id             crd_e_repair.Repair_Seq_Id%TYPE;
v_child_seq_id          crd_e_repair.Repair_Seq_Id%TYPE;


BEGIN

SELECT COUNT(1)
INTO   v_eng_model_cnt
FROM   crd_crc_eng_mdl_display cem
WHERE  cem.ENG_MDL_NUMBER=p_in_eng_code;


IF v_eng_model_cnt<> 0
   THEN


--- Checks if catalog for the engine model already exist


     p_out_error_msg:='EXIST';

ELSE


---   Creating a new catalog by calling the create catalog procedure


   ecrd_managecatalog_pkg.ecrd_create_blank_catalog_prc( p_in_eng_code
                                           ,p_in_eng_desc
                                              ,p_in_start_date
                                              ,p_in_end_date
                                           ,p_in_cat_desc
                                           ,p_in_cat_ind      ----changes by vikrant
                                           ,p_in_user_id
                                           ,p_in_vis_to_cwc
                                           ,p_out_cat_seqid
                                           ,p_out_error_msg);



-- Get the engine model of the catalog being copied


      SELECT cec.ENG_MDL_NUMBER
      INTO v_old_eng_model
      FROM CRD_E_CATALOG cec
      WHERE cec.CATALOG_SEQ_ID=p_in_copy_seq_id;



-- Get the catalog sequence id and catalog effective date of the newly created catalog


      SELECT       cec.CATALOG_SEQ_ID,
               cec.CATALOG_EFFECTIVE_DATE
      INTO     v_new_cat_seqid
               ,v_new_eff_date
      FROM     crd_e_catalog cec
      WHERE       cec.eng_mdl_number=p_in_eng_code;

dbms_output.put_line('Start of module cursor');
dbms_output.put_line('-------------------------------------');
dbms_output.put_line('v_new_cat_seqid'||v_new_cat_seqid);
dbms_output.put_line('v_new_eff_date'||v_new_eff_date);
dbms_output.put_line('-------------------------------------');
      FOR cv_module IN c_module_list(v_old_eng_model)
            LOOP


      ----     Get new module sequence id



            SELECT CRD_CRC_MODULE_SEQ.nextval
            INTO   v_module_seq_id
            FROM DUAL;



            -- Associate the Module to new engine model. Create new module_seq_id for each module.
            -- Retain Module Name






            INSERT INTO CRD_CRC_MODULE ccm
                 (
                  ccm.ENG_MDL_NUMBER
                  ,ccm.CREATED_BY
                  ,ccm.CREATION_DATE
                  ,ccm.LAST_UPDATED_BY
                  ,ccm.LAST_UPDATE_DATE
                  ,ccm.MODULE_SEQ_ID
                  ,ccm.MODULE_NAME
               )
            VALUES
            (
                  p_in_eng_code
                  ,p_in_user_id
                  ,sysdate
                  ,p_in_user_id
                  ,sysdate
                  ,v_module_seq_id
                  ,cv_module.MODULE_NAME
            );


         -- Insert components for the above Module from engine model being copied to module created above






            INSERT INTO CRD_E_COMPONENT comp1
            (
                  comp1.MODULE_SEQ_ID,
                  comp1.COMPONENT_CODE,
                  comp1.CYCLE_COUNT_CLASS,
                  comp1.COMPONENT_DESCRIPTION,
                  comp1.ATA_REFERENCE_SNUM,
                  comp1.COMPONENT_EFFECTIVE_DATE,
                  comp1.QUANTITY_OF_ENGINE,
                  comp1.SHOP_VISIT_EXPOSURE_RATE,
                  comp1.SCRAP_RATE_AT_EXPOSURE,
                  comp1.SERVICEABLE_AT_EXPOSURE,
                  comp1.REPAIR_YIELD,
                  comp1.COMPONENT_END_DATE,
                  comp1.CREATED_BY,
                  comp1.CREATION_DATE,
                  comp1.LAST_UPDATE_DATE,
                  comp1.LAST_UPDATED_BY
            )

            SELECT
                  v_module_seq_id
                  ,comp1.COMPONENT_CODE
                  ,comp1.CYCLE_COUNT_CLASS
                  ,comp1.COMPONENT_DESCRIPTION
                  ,comp1.ATA_REFERENCE_SNUM
                  ,comp1.COMPONENT_EFFECTIVE_DATE
                  ,comp1.QUANTITY_OF_ENGINE
                  ,comp1.SHOP_VISIT_EXPOSURE_RATE
                  ,comp1.SCRAP_RATE_AT_EXPOSURE
                  ,comp1.SERVICEABLE_AT_EXPOSURE
                  ,comp1.REPAIR_YIELD
                  ,comp1.COMPONENT_END_DATE
                  ,p_in_user_id
                  ,sysdate
                  ,sysdate
                  ,p_in_user_id
            FROM CRD_E_COMPONENT comp1
            WHERE
                 comp1.MODULE_SEQ_ID = cv_module.module_seq_id;


         -- Insert into COMPONENT lOCATION table


            INSERT INTO CRD_E_COMPONENT_LOCATION cecl
            (
                  cecl.MODULE_SEQ_ID
                  ,cecl.COMPONENT_CODE
                  ,cecl.LOCATION_ID
                  ,cecl.SITE_SEQUENCE_NUMBER
                  ,cecl.CREATED_BY
                  ,cecl.CREATION_DATE
                  ,cecl.LAST_UPDATE_DATE
                  ,cecl.LAST_UPDATED_BY
                  ,cecl.ACTIVE_IND
                  ,cecl.HIDE_COMPONENT_IND
            )
            SELECT
                  v_module_seq_id
                  ,cecl1.COMPONENT_CODE
                  ,cecl1.LOCATION_ID
                  ,cecl1.SITE_SEQUENCE_NUMBER
                  ,p_in_user_id
                  ,sysdate
                  ,sysdate
                  ,p_in_user_id
                  ,cecl1.ACTIVE_IND
                  ,ecrd_utils_pkg.G_NO
            FROM   CRD_E_COMPONENT_LOCATION cecl1
            WHERE  cecl1.MODULE_SEQ_ID=cv_module.module_seq_id;

          --- active indicator removed bcoz of integrity constraint

         -- Insert into parts table


            INSERT INTO CRD_E_PART cep
            (
              cep.PART_NUMBER
              ,cep.MODULE_SEQ_ID
              ,cep.COMPONENT_CODE
              ,cep.PART_SEQUENCE_NUMBER
              ,cep.CREATED_BY
              ,cep.CREATION_DATE
              ,cep.LAST_UPDATE_DATE
              ,cep.LAST_UPDATED_BY
              ,cep.ACTIVE_IND
            )
            SELECT
                 cep.PART_NUMBER
                 ,v_module_seq_id
                 ,cep.COMPONENT_CODE
                 ,cep.PART_SEQUENCE_NUMBER
                 ,p_in_user_id
                 ,sysdate
                 ,sysdate
                 ,p_in_user_id
                 ,cep.ACTIVE_IND
            FROM CRD_E_PART cep
            WHERE cep.MODULE_SEQ_ID=cv_module.module_seq_id
            AND     cep.ACTIVE_IND = ecrd_utils_pkg.G_ACTIVE;


         ---                  START OF REPAIR CURSOR


               dbms_output.put_line('Start of Repair cursor');

            FOR cv_repair_list in c_repair_list(cv_module.module_seq_id)
               LOOP

               dbms_output.put_line('Getting new reapir id');


         -- Get new repair seq id


                SELECT crd_e_repair_seq.NEXTVAL
                INTO v_repair_id
                FROM DUAL;







         ---   Insert repairs from modules of model being copied to new model




                INSERT INTO CRD_E_REPAIR cer
                (
                     cer.REPAIR_SEQ_ID
                     ,cer.MODULE_SEQ_ID
                     ,cer.COMPONENT_CODE
                     ,cer.REPAIR_TYPE
                     ,cer.REPAIR_DESCRIPTION
                     ,cer.REPAIR_REFERENCE
                     ,cer.REPAIR_COMMENTS
                     ,cer.REPAIR_EFFECTIVE_DATE
                     ,cer.REPAIR_END_DATE
                     ,cer.REPAIR_VOLUME
                     ,cer.RPR_OSB_UNIQUE_NUMBER
                     ,cer.CREATED_BY
                     ,cer.CREATION_DATE
                     ,cer.LAST_UPDATE_DATE
                     ,cer.LAST_UPDATED_BY
                     ,cer.CAT_IND   --changes by vikrant
                )
                VALUES
                (
                      v_repair_id
                      ,v_module_seq_id
                      ,cv_repair_list.COMPONENT_CODE
                     ,cv_repair_list.REPAIR_TYPE
                     ,cv_repair_list.REPAIR_DESCRIPTION
                     ,cv_repair_list.REPAIR_REFERENCE
                     ,cv_repair_list.REPAIR_COMMENTS
                     ,cv_repair_list.REPAIR_EFFECTIVE_DATE
                     ,cv_repair_list.REPAIR_END_DATE
                     ,cv_repair_list.REPAIR_VOLUME
                     ,cv_repair_list.RPR_OSB_UNIQUE_NUMBER
                     ,p_in_user_id
                     ,sysdate
                     ,sysdate
                     ,p_in_user_id
                     ,p_in_cat_ind   --changes by vikrant
                );



            ---            Insert Parent repair into Repair Catalog table


                INSERT INTO CRD_E_REPAIR_CATALOG cerc
                (
                  /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - Begin */
                  crd_e_repair_catalog_seq_id,
                  /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - End */
                  cerc.CATALOG_SEQ_ID,
                  cerc.EFFECTIVE_DATE,
                  cerc.REPAIR_SEQ_ID,
                  cerc.REPAIR_PRICE,
                  cerc.INCREMENTAL_PRICE_IND,
                  cerc.INCREMENTAL_TAT_IND,
                  cerc.FUTURE_PRICE,
                  cerc.FUTURE_EFFECTIVE_DATE,
                  cerc.PRICE_TYPE,
                  cerc.REPAIR_END_DATE,
                  cerc.REPAIR_DISPLAY_SEQ_ID,
                  cerc.FUTURE_TAT,
                  cerc.CREATED_BY,
                  cerc.CREATION_DATE,
                  cerc.LAST_UPDATE_DATE,
                  cerc.LAST_UPDATED_BY
               )
               SELECT
                  /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - Begin */
                  crd_e_repair_catalog_seq.nextval
                  /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - End */
                  ,v_new_cat_seqid
                  ,cerc1.EFFECTIVE_DATE
                  ,v_repair_id
                  ,cerc1.REPAIR_PRICE
                  ,cerc1.INCREMENTAL_PRICE_IND
                  ,cerc1.INCREMENTAL_TAT_IND
                  ,cerc1.FUTURE_PRICE
                  ,cerc1.FUTURE_EFFECTIVE_DATE
                  ,cerc1.PRICE_TYPE
                  ,cerc1.REPAIR_END_DATE
                  ,cerc1.REPAIR_DISPLAY_SEQ_ID
                  ,cerc1.FUTURE_TAT
                  ,v_user_id
                  ,sysdate
                  ,sysdate
                  ,v_user_id

               FROM CRD_E_REPAIR_CATALOG cerc1
               WHERE
                    cerc1.REPAIR_SEQ_ID = cv_repair_list.repair_seq_id AND
                    cerc1.CATALOG_SEQ_ID = p_in_copy_seq_id
               AND  (cerc1.REPAIR_END_DATE  is NULL or cerc1.REPAIR_END_DATE > SYSDATE);


         ---    Insert into CRD_E_REPAIR_COST table


               INSERT INTO CRD_E_REPAIR_COST cerc
               (
                     cerc.REPAIR_SEQ_ID
                     ,cerc.MODULE_SEQ_ID
                     ,cerc.COMPONENT_CODE
                     ,cerc.LOCATION_ID
                     ,cerc.MATERIAL_COST
                     ,cerc.LABOUR_HOURS
                     ,cerc.CREATED_BY
                     ,cerc.CREATION_DATE
                     ,cerc.LAST_UPDATE_DATE
                     ,cerc.LAST_UPDATED_BY
               )
               SELECT
                     v_repair_id
                     ,v_module_seq_id
                     ,cerc.COMPONENT_CODE
                     ,cerc.LOCATION_ID
                     ,cerc.MATERIAL_COST
                     ,cerc.LABOUR_HOURS
                     ,p_in_user_id
                     ,sysdate
                     ,sysdate
                     ,p_in_user_id

               FROM CRD_E_REPAIR_COST cerc
               WHERE cerc.MODULE_SEQ_ID=cv_module.module_seq_id
               AND     cerc.REPAIR_SEQ_ID=cv_repair_list.repair_seq_id;



               FOR cv_child_repair_list IN c_child_repair_list(cv_repair_list.repair_seq_id, cv_module.module_seq_id)
               LOOP

                  SELECT   crd_e_repair_seq.nextval
                  INTO  v_child_seq_id
                  FROM  DUAL;


         ---    Insert into child repair



                   INSERT INTO CRD_E_REPAIR cer
                   (
                        cer.REPAIR_SEQ_ID
                        ,cer.PARENT_REPAIR_SEQ_ID
                        ,cer.MODULE_SEQ_ID
                        ,cer.COMPONENT_CODE
                        ,cer.REPAIR_TYPE
                        ,cer.REPAIR_DESCRIPTION
                        ,cer.REPAIR_REFERENCE
                        ,cer.REPAIR_COMMENTS
                        ,cer.REPAIR_EFFECTIVE_DATE
                        ,cer.REPAIR_END_DATE
                        ,cer.REPAIR_VOLUME
                        ,cer.RPR_OSB_UNIQUE_NUMBER
                        ,cer.CREATED_BY
                        ,cer.CREATION_DATE
                        ,cer.LAST_UPDATE_DATE
                        ,cer.LAST_UPDATED_BY
                        ,cer.CAT_IND      --changes by vikrant

                   )
                   SELECT

                        v_child_seq_id
                        ,v_repair_id
                        ,v_module_seq_id
                        ,cer1.COMPONENT_CODE
                        ,cer1.REPAIR_TYPE
                        ,cer1.REPAIR_DESCRIPTION
                        ,cer1.REPAIR_REFERENCE
                        ,cer1.REPAIR_COMMENTS
                        ,cer1.REPAIR_EFFECTIVE_DATE
                        ,cer1.REPAIR_END_DATE
                        ,cer1.REPAIR_VOLUME
                        ,cer1.RPR_OSB_UNIQUE_NUMBER
                        ,p_in_user_id
                        ,sysdate
                        ,sysdate
                        ,p_in_user_id
                        ,p_in_cat_ind     --changes by vikrant
                  FROM   CRD_E_REPAIR cer1
                  WHERE  repair_seq_id = cv_child_repair_list.repair_seq_id;


               ---    Inserting child repairs in catalog


                   INSERT INTO CRD_E_REPAIR_CATALOG cerc
                   (
                     /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - Begin */
                     crd_e_repair_catalog_seq_id,
                     /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - End */
                     cerc.CATALOG_SEQ_ID,
                     cerc.EFFECTIVE_DATE,
                     cerc.REPAIR_SEQ_ID,
                     cerc.REPAIR_PRICE,
                     cerc.INCREMENTAL_PRICE_IND,
                     cerc.INCREMENTAL_TAT_IND,
                     cerc.FUTURE_PRICE,
                     cerc.FUTURE_EFFECTIVE_DATE,
                     cerc.PRICE_TYPE,
                     cerc.REPAIR_END_DATE,
                     cerc.REPAIR_DISPLAY_SEQ_ID,
                     cerc.FUTURE_TAT,
                     cerc.CREATED_BY,
                     cerc.CREATION_DATE,
                     cerc.LAST_UPDATE_DATE,
                     cerc.LAST_UPDATED_BY
                  )
                  SELECT
                     /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - Begin */
                     crd_e_repair_catalog_seq.nextval
                     /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - End */
                     ,v_new_cat_seqid
                     ,cerc1.EFFECTIVE_DATE
                        ,v_child_seq_id
                     ,cerc1.REPAIR_PRICE
                     ,cerc1.INCREMENTAL_PRICE_IND
                     ,cerc1.INCREMENTAL_TAT_IND
                     ,cerc1.FUTURE_PRICE
                     ,cerc1.FUTURE_EFFECTIVE_DATE
                     ,cerc1.PRICE_TYPE
                     ,cerc1.REPAIR_END_DATE
                     ,cerc1.REPAIR_DISPLAY_SEQ_ID
                     ,cerc1.FUTURE_TAT
                     ,v_user_id
                     ,sysdate
                     ,sysdate
                     ,v_user_id

                  FROM CRD_E_REPAIR_CATALOG cerc1
                  WHERE
                        cerc1.repair_seq_id = cv_child_repair_list.repair_seq_id
                  AND   cerc1.catalog_seq_id = p_in_copy_seq_id;

               END LOOP;   -- child repair list*/

            END LOOP;   -- repair list loop

dbms_output.put_line('End of repair cursor');

         END LOOP;   -- module list loop

dbms_output.put_line('End of module cursor');

     END IF;
 COMMIT;
 EXCEPTION
       WHEN OTHERS
      THEN ROLLBACK;
      RAISE;
          RAISE_APPLICATION_ERROR (-20021,'ERROR IN ECRD_MANAGECATALOG_PKG.ECRD_COPY_DEFAULT_CATALOG_PRC'||SQLCODE||'-'|| SQLERRM);

END ecrd_copy_default_catalog_prc;


/********************************************************************************/
/* Procedure Name :  ecrd_get_cataloglist_prc                                   */
/*                                                             */
/* Description    :  This procedure is used to retreive  list of existing     */
/*                 catalog which have their own repair enteries            */
/*                 a default catalog                                    */
/*                                                                   */
/*                                                          */
/* Input Parameters : Engine model Code,                             */
/*                                                                         */
/* Out Parameters :  Cursor of existing catalogs,                          */
/*                       Error Mesage                                   */
/********************************************************************************/
--
PROCEDURE ecrd_get_cataloglist_prc(
                                 p_out_catalog_list   OUT result_cursor
                                 ,p_out_err_msg OUT VARCHAR2

                           )

IS

BEGIN

     OPEN   p_out_catalog_list
     FOR

SELECT


   ---      Retreiving a cursor of existing catalogs


     ccemd.ENG_MDL_DESC,
     ccemd.ENG_MDL_NUMBER
     FROM crd_crc_eng_mdl_display ccemd,crd_e_catalog cec
     WHERE
      cec.CATALOG_TYPE=ecrd_utils_pkg.G_DEFAULT_CATALOG
     AND cec.ENG_MDL_NUMBER=ccemd.ENG_MDL_NUMBER
     AND cec.CATALOG_END_DATE >= sysdate;

     EXCEPTION
         WHEN OTHERS
         THEN
         p_out_err_msg  :=substr(SQLERRM,1,50);
         RAISE_APPLICATION_ERROR(-20101,'Error in Get Catalogt List Proc'|| SQLCODE ||  ' - ' || substr(SQLERRM,1,100));

END ecrd_get_cataloglist_prc;
--
/********************************************************************************/
/* Procedure Name :  ecrd_get_default_seqid_prc                                 */
/*                                                             */
/* Description    :  This procedure is used to retreive  sequence id of         */
/*                 a default catalog                                    */
/*                                                                   */
/*                                                          */
/* Input Parameters : Engine model Code,                             */
/*                                                                         */
/* Out Parameters :  Catalog seqID                                    */
/*                   Error Mesage                                    */
/********************************************************************************/
--

PROCEDURE ecrd_get_default_seqid_prc(
                                     p_in_eng_code IN crd_crc_eng_mdl_display.ENG_MDL_NUMBER%TYPE
                                  ,p_out_seqid OUT VARCHAR2
                                  ,p_out_error_msg OUT VARCHAR2
                           )
IS

BEGIN
    BEGIN


      ---    Getting the catalog seq id for the engine model

      commit;
      SELECT cec.CATALOG_SEQ_ID
      INTO p_out_seqid
      FROM crd_e_catalog cec
      WHERE cec.eng_mdl_number=p_in_eng_code
      AND cec.catalog_type = ecrd_utils_pkg.G_DEFAULT_CATALOG
      AND cec.catalog_effective_date <= SYSDATE
      AND cec.catalog_end_date >= SYSDATE;
      EXCEPTION
       WHEN NO_DATA_FOUND
            THEN
               SELECT cec.CATALOG_SEQ_ID
               INTO p_out_seqid
               FROM crd_e_catalog cec
               WHERE cec.eng_mdl_number=p_in_eng_code
               AND cec.catalog_type = ecrd_utils_pkg.G_DEFAULT_CATALOG
               AND cec.catalog_end_date >= SYSDATE;
         WHEN OTHERS THEN
                p_out_seqid := NULL;
    END;

EXCEPTION
   WHEN OTHERS
   THEN
      RAISE_APPLICATION_ERROR (-20020,'Error in ecrd_managecatalog_pkg.ecrd_get_default_seqid_prc -'||SQLCODE||'-'||SUBSTR(SQLERRM,1,100));


END ecrd_get_default_seqid_prc;

---
/***********************************************************************/
---

PROCEDURE ecrd_save_default_catalog_prc(
                                    p_in_eng_model IN crd_crc_eng_mdl_display.ENG_MDL_NUMBER%TYPE
                                       ,p_in_start_date IN VARCHAR2
                                 ,p_in_end_date IN VARCHAR2
                                       ,p_in_cat_desc IN crd_e_catalog.CATALOG_DESCRIPTION%TYPE
                                       ,p_out_error_msg OUT VARCHAR2
                                     )
IS
v_in_start_date DATE :=null;
v_in_end_date DATE := null;

BEGIN

v_in_start_date := TO_DATE(p_in_start_date,'MM/DD/YYYY');
v_in_end_date   := TO_DATE(p_in_end_date,'MM/DD/YYYY');

      INSERT INTO crd_e_catalog cc
      (
            cc.CATALOG_SEQ_ID
            ,cc.ENG_MDL_NUMBER
            ,cc.CATALOG_TYPE
            ,cc.CATALOG_EFFECTIVE_DATE
            ,cc.CATALOG_END_DATE
            ,cc.CATALOG_DESCRIPTION
            ,cc.CREATION_DATE
            ,cc.LAST_UPDATE_DATE
            ,cc.LAST_UPDATED_BY
      )
      VALUES
      (
            crd_e_catalog_SEQ.nextval
            ,p_in_eng_model
            ,'D'
            ,v_in_start_date
            ,v_in_end_date
            ,p_in_cat_desc
            ,sysdate
            ,sysdate
            ,'ngpt1js'
      );



EXCEPTION

      WHEN OTHERS
      THEN
         ROLLBACK;
         p_out_error_msg :='Error encountered in ecrd_save_default_catalog_prc';

END ecrd_save_default_catalog_prc;
---
/***********************************************************************/
PROCEDURE ecrd_save_eng_model_prc(
                              p_in_eng_family IN VARCHAR2
                                 ,p_in_eng_model IN VARCHAR2
                              ,p_in_osb_eng_code IN VARCHAR2
                              ,p_out_error_msg OUT VARCHAR2
                        )

IS
v_eng_model_cnt NUMBER:=0;

BEGIN

SELECT COUNT(1)
INTO   v_eng_model_cnt
FROM   crd_crc_eng_mdl_display cem
WHERE  cem.ENG_MDL_NUMBER=UPPER(p_in_eng_model);


   IF v_eng_model_cnt<> 0
      THEN
        p_out_error_msg:='EXIST';

   ELSE

      INSERT INTO crd_crc_eng_mdl_display cem
      (
--          cem.,
             cem.ENG_MDL_NUMBER
            ,cem.ENG_MDL_STS_CD
            ,cem.CREATED_BY
            ,cem.CREATION_DATE
            ,cem.LAST_UPDATE_DATE
            ,cem.LAST_UPDATED_BY
      )
      VALUES
      (
--          p_in_eng_family,
             p_in_eng_model
            ,p_in_osb_eng_code
            ,'ngpt1js'
            ,sysdate
            ,sysdate
            ,'ngpt1js'
      );
   END IF;

EXCEPTION

   WHEN OTHERS
   THEN
      ROLLBACK;
      p_out_error_msg :='Error encountered in ecrd_create_blank_catalog_prc';



END ecrd_save_eng_model_prc;
---
/***********************************************************************/
---

PROCEDURE ecrd_get_model_prc(
          p_in_model_code IN VARCHAR2,
          p_out_model_desc OUT VARCHAR2,
          p_out_model_cd OUT VARCHAR2)
IS
BEGIN
   BEGIN
      SELECT
         cem.eng_mdl_number,
         cem.eng_mdl_desc
      INTO
         p_out_model_cd,
         p_out_model_desc
      FROM
         crd_crc_eng_mdl_display cem
      WHERE
         cem.eng_mdl_number = p_in_model_code;
      EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         p_out_model_cd := '';
         p_out_model_desc := '';
         RAISE_APPLICATION_ERROR(-20020,'Error in ecrd_managecatalog_pkg.ecrd_get_model_prc'||SQLCODE||'-'||substr(SQLERRM,1,100));
   END;
EXCEPTION
WHEN OTHERS
THEN
   RAISE_APPLICATION_ERROR(-20020,'Error in ecrd_managecatalog_pkg.ecrd_get_model_prc'||SQLCODE||'-'||substr(SQLERRM,1,100));
END ecrd_get_model_prc;

PROCEDURE ecrd_save_module_prc(
          p_in_model_code IN VARCHAR2,
          p_in_module IN VARCHAR2,
          p_in_user_id IN VARCHAR2,
          p_in_row_delimiter IN VARCHAR2,
          p_in_col_delimiter IN VARCHAR2,
          p_out_eng_module OUT result_cursor,
          p_out_message OUT VARCHAR2)
IS
   v_rec_holder rec_holder;
   c_request_record_length    CONSTANT    NUMBER := 1;
   v_ptr        NUMBER := 0;
   v_end        NUMBER := 0;
   v_row        NUMBER := 0;
   v_table ecrd_module_table;
   v_module_seq_id crd_crc_module.module_seq_id%TYPE;
   v_count NUMBER :=0;
BEGIN
   ecrd_delimiter_prc(p_in_module,p_in_row_delimiter,p_in_col_delimiter,v_rec_holder);
   v_end := (v_rec_holder.COUNT - c_request_record_length) + 1;
   v_count := v_rec_holder.COUNT;
   v_ptr := 1;
   v_row := 1;
     -- arrange and populate the respective tables from the train.
   LOOP
   EXIT WHEN v_ptr > v_end;
      v_table(v_row).modules_desc := v_rec_holder(v_ptr);

      v_ptr := v_ptr + c_request_record_length;

      v_row := v_row + 1;

   END LOOP;

   FOR i IN 1..v_table.COUNT
   LOOP
      SELECT
         count(1)
      INTO
         v_count
      FROM
         crd_crc_module cm
      WHERE
         cm.module_name = v_table(i).modules_desc AND
         cm.eng_mdl_number = p_in_model_code;
      IF(v_count > 0)
      THEN
         p_out_message := 'DUPLICATE_MODULE';
         EXIT;
      ELSE
         SELECT
               crd_crc_module_seq.NEXTVAL
          INTO
               v_module_seq_id
        FROM
            DUAL;

        INSERT INTO crd_crc_module
         (
            module_seq_id,
            eng_mdl_number,
            module_name,
            created_by,
            creation_date,
            last_update_date,
            last_updated_by
         )
         VALUES
         (
            v_module_seq_id,
            p_in_model_code,
            v_table(i).modules_desc,
            p_in_user_id,
            SYSDATE,
            SYSDATE,
            p_in_user_id
         );
         p_out_message := 'MODULE_ADDED';
      END IF;
   END LOOP;

   OPEN p_out_eng_module FOR
      SELECT
         cm.module_seq_id Module_Code,
         cm.module_name Module_Desc
      FROM
         crd_crc_module cm
      WHERE
         cm.eng_mdl_number = p_in_model_code;


   COMMIT;
EXCEPTION
WHEN OTHERS
THEN
   ROLLBACK;
   RAISE_APPLICATION_ERROR(-20020,'Error in ecrd_managecatalog_pkg.ecrd_save_module_prc'||SQLCODE||'-'||SQLERRM);
END ecrd_save_module_prc;

PROCEDURE ecrd_delimiter_prc(
          p_name_str         IN LONG,
          p_row_delimit      IN VARCHAR2,
          p_field_delimit    IN VARCHAR2,
          p_rec_holder      OUT rec_holder)
IS

 v_rec_pos1                 NUMBER;
 v_rec_pos2                 NUMBER;
 v_rec_delimiter_length     NUMBER;
 v_field_pos1               NUMBER;
 v_field_pos2               NUMBER;
 v_field_delimiter_length   NUMBER;
 loop_counter               NUMBER;
 num_cols                   NUMBER;
 table_counter              NUMBER;
 col_count                  NUMBER;
 rec_length                 NUMBER;
 v_record                   LONG;
 v_field                    VARCHAR2(1000);

BEGIN

  v_rec_pos1     :=0;
  v_rec_pos2     :=0;
  v_field_pos1   :=0;
  v_field_pos2   :=0;
  loop_counter   :=0;
  table_counter  :=0;

-- outer loop separates out the rows and the inner loop separates out the columns

 LOOP --record loop
   v_rec_pos2    := INSTR(p_name_str,p_row_delimit,v_rec_pos1+1,1) ;
   v_record      := SUBSTR(p_name_str,v_rec_pos1+1,v_rec_pos2-v_rec_pos1-1);
   EXIT WHEN v_rec_pos2 = 0; --exit record loop

   --to get the no of columns for that particular record
   col_count:=0;

   FOR rec_length IN 1..LENGTH(v_record)
   LOOP
       v_field_pos2 := INSTR(v_record,p_field_delimit,v_field_pos1+1,1);
       IF v_field_pos2 = 0
       THEN
          EXIT;
       END IF;
       col_count:=col_count+1;
       v_field_pos1 := v_field_pos2 + LENGTH(p_field_delimit) - 1;
   END LOOP;

    num_cols := col_count+1;
    v_field_pos2:=0;
    v_field_pos1:=0;


   FOR loop_counter IN 1..num_cols - 1

       LOOP -- field loop

           table_counter := table_counter + 1;
           v_field_pos2 := INSTR(v_record,p_field_delimit,v_field_pos1+1,1) ;
           v_field      := LTRIM(RTRIM(SUBSTR(v_record,v_field_pos1+1,v_field_pos2-v_field_pos1-1)));
           p_rec_holder(table_counter)  :=  v_field;
           v_field_pos1 := v_field_pos2 + LENGTH(p_field_delimit) - 1;

           EXIT WHEN v_field_pos2 =0; -- exit field loop

       END LOOP;

       v_field      := SUBSTR(v_record,v_field_pos1+1,LENGTH(v_record));
       table_counter := table_counter + 1;
       p_rec_holder(table_counter)  := v_field;

       -- The separated fields for the record are being held by p_rec_holder.
       -- This is sent to the Action procedure ,sp_display where the business logic for
       -- the separated values is written.

       v_field_pos1 :=0;
       v_field_pos2 :=0;

       v_rec_pos1   :=v_rec_pos2 + LENGTH(p_row_delimit) - 1 ;

 END LOOP;-- end record loop

END ecrd_delimiter_prc;

PROCEDURE ecrd_remove_module_prc(
          p_in_module_cd IN crd_crc_module.module_seq_id%TYPE,
          p_out_message OUT VARCHAR2)
AS
   v_count NUMBER :=0;
BEGIN
   SELECT
      COUNT(1)
   INTO
      v_count
   FROM
      crd_crc_module
   WHERE
      module_seq_id = p_in_module_cd;

   IF(v_count = 0)
   THEN
      p_out_message := 'NO_DATA_FOUND';
   ELSE
      DELETE FROM
         crd_crc_module
      WHERE
         module_seq_id = p_in_module_cd;

   p_out_message := 'DELETE_SUCCESS';
   END IF;

   COMMIT;
EXCEPTION
WHEN OTHERS
THEN
   ROLLBACK;
   RAISE_APPLICATION_ERROR(-20020,'Error in ecrd_managecatalog_pkg.ecrd_remove_module_prc'||SQLCODE||'-'||SUBSTR(SQLERRM,1,100));
END ecrd_remove_module_prc;

PROCEDURE ecrd_get_module_prc(
          p_in_module_cd IN crd_crc_module.module_seq_id%TYPE,
          p_out_module_cd OUT VARCHAR2,
          p_out_module_desc OUT VARCHAR2)
AS
BEGIN

   BEGIN
      SELECT
         cm.module_seq_id,
         cm.module_name
      INTO
         p_out_module_cd,
         p_out_module_desc
      FROM
         crd_crc_module cm
      WHERE
         cm.module_seq_id = p_in_module_cd;
      EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         p_out_module_cd := '';
         p_out_module_desc := '';
   END;

EXCEPTION
WHEN OTHERS
THEN
   RAISE_APPLICATION_ERROR (-20020,'Error in ecrd_managecatalog_pkg.ecrd_get_module_prc -'||SQLCODE||'-'||SUBSTR(SQLERRM,1,100));
END ecrd_get_module_prc;

PROCEDURE ecrd_update_module_prc(
          p_in_module_cd IN crd_crc_module.module_seq_id%TYPE,
          p_in_module_desc IN VARCHAR2,
          p_in_user_id IN crd_crc_user.userid%TYPE,
          p_out_message OUT VARCHAR2)
AS
BEGIN
   UPDATE
      crd_crc_module
   SET
      module_name = p_in_module_desc,
      last_updated_by = p_in_user_id,
      last_update_date = SYSDATE
   WHERE
      module_seq_id = p_in_module_cd;

   COMMIT;
   p_out_message := 'UPDATE_SUCCESS';
EXCEPTION
WHEN OTHERS
THEN
   ROLLBACK;
   RAISE_APPLICATION_ERROR (-20020,'Error in ecrd_managecatalog_pkg.ecrd_update_module_prc - '||SQLCODE||'-'||SUBSTR(SQLERRM,1,100));
END ecrd_update_module_prc;

PROCEDURE ecrd_download_batch_prc(
          p_in_engine_model     IN VARCHAR2,
          p_in_catalog_id       IN VARCHAR2,
          p_in_class         IN VARCHAR2,
          p_in_site             IN VARCHAR2,
          p_catalog_data_cur OUT result_cursor
          )
AS
v_sql VARCHAR2(20000) := '';

BEGIN
    -- 20-06-2006 Patni Query changed to dynamic  query Begin
     IF p_in_class = 'ALL'
     THEN
       --  OPEN p_catalog_data_cur
       --  FOR
       -- Patni 21-Aug-2006 - Included alias name for the Module - Begin
   v_sql:=   'SELECT  distinct module.module_name "Module Name",'||
       -- Patni 21-Aug-2006 - Included alias name for the Module - End
             ' comp.component_description "Component Description", '||
             ' comp.component_code "Component Code", '||
             '  comp.ata_reference_snum "ATA Chapter", ' ||
      -- 16-05-2006 Patni added reapir seq id in the select statement Begin
              ' repcatalog.repair_seq_id "Repair Seq id", '||
      -- 16-05-2006 Patni added reapir seq id in the select statement End
              ' prepair.repair_reference "Repair Reference", '||
              '  prepair.repair_description "Rpr Description", '||

               ' repcatalog.price_type "Price Type", '||
      -- 16-05-2006 Patni commented the Rpr tat to remove the + sign  and displaying the repair tat without sign Begin
      --   DECODE(repcatalog.incremental_tat_ind,'Y','+')||repcatalog.repair_tat "Rpr TAT",
               ' repcatalog.repair_tat "Rpr TAT", '||
      -- 16-05-2006 Patni commented the Rpr tat to remove the + sign  and displaying the repair tat without sign End
      -- 16-05-2006 Patni added incremental_tat_ind in the select statement Begin
               ' repcatalog.incremental_tat_ind "Incremental TaT indicator", '||
      -- 16-05-2006 Patni added incremental_tat_ind in the select statement End

      -- 16-05-2006 Patni commented the Rpr price to remove the + sign  and displaying the repair price wothout sign Begin
      -- DECODE(repcatalog.incremental_price_ind,'Y','+')||repcatalog.repair_price "Rpr Price",
               ' repcatalog.repair_price "Rpr Price", '||
       -- 16-05-2006 Patni commented the Rpr price  to remove the + sign  and displaying the repair price wothout sign End


      -- 16-05-2006 Patni added incremental_price_ind in the select statement Begin
               ' repcatalog.incremental_price_ind "Incremental Price Indicator", '||
      -- 16-05-2006 Patni added incremental_price_ind in the select statement End
                /*DECODE(repcatalog.future_tat,0,'',repcatalog.future_tat) "Future TAT",  --change the column name to future_tat
                DECODE(repcatalog.future_price,0.0,'',repcatalog.future_price) "Future Price",*/
               ' repcatalog.future_tat "Future TAT", '||
               ' repcatalog.future_price "Future Price", '||
               ' to_char(repcatalog.future_effective_date,''MM/dd/yyyy'') "Future Effective date" ' ;
               
              
              
             IF (p_in_site != 'ALL' )
             THEN 
              v_sql := v_sql || ',  NVL(cost.labour_hours,'''') "Labor Hours", '|| 
                    '  NVL(cost.material_cost,'''') "Material Cost" , '||
                    ' ''N'' "Retain Value Indicator" , ' ||
                    ' case when (cost.LAST_UPDATE_DATE > SYSDATE-cycnt.notification_period_in_days) then ''N'' else ''Y'' end case ' ;
             END IF;  
             v_sql := v_sql || ' FROM crd_crc_module module, '||
              ' crd_e_component comp, '||
              ' crd_e_repair prepair, '||
              ' crd_e_repair_catalog repcatalog, '||
              ' crd_e_repair_cost cost, '||
           ' crd_e_component_location cecl , '||
           ' CRD_E_CYCLE_COUNTING_TYPE cycnt '||
         ' WHERE comp.module_seq_id = module.module_seq_id '||
         ' AND prepair.module_seq_id = module.module_seq_id '||
         ' AND module.eng_mdl_number =  ' || ''''|| p_in_engine_model ||'''' || 
         ' AND prepair.component_code = comp.component_code '||
         ' AND repcatalog.catalog_seq_id = '||''''||  p_in_catalog_id  ||'''' || 
         ' AND prepair.repair_seq_id = repcatalog.repair_seq_id '||
         ' AND cost.repair_seq_id(+)= prepair.repair_seq_id '||
         ' AND cost.module_seq_id(+) = prepair.module_seq_id '||
         ' AND cost.component_code(+)= prepair.component_code '||
         ' AND cycnt.cycle_count_class = comp.cycle_count_class ' ;
        
        -- 20-06-2006 Patni Added to check the site value begin  
          IF ( p_in_site != 'ALL')
          THEN 
             v_sql := v_sql || ' AND cost.location_id(+) = '  || ''''||p_in_site||''''||' ' ;
          END IF;
          -- 20-06-2006 Patni Added to check the site value  End
             
         
         v_sql :=  v_sql || ' AND prepair.repair_type <> ' || ''''||ecrd_utils_pkg.G_CHILD_REPAIR||''''||
      '  AND cecl.module_seq_id = prepair.module_seq_id '||
       ' AND cecl.component_code =   prepair.component_code ';
       -- 20-06-2006 Patni Added to check the site value begin 
          IF ( p_in_site != 'ALL')
          THEN 
             v_sql := v_sql || ' AND cecl.location_id = '||  ''''||p_in_site||''''||' ' ;
         END IF;
        -- 20-06-2006 Patni Added to check the site value end    
         v_sql := v_sql  || ' AND cecl.active_ind = '||  ''''||ecrd_utils_pkg.G_ACTIVE||''''||
       ' AND (comp.component_end_date IS NULL OR comp.component_end_date > '|| ''''||SYSDATE||'''' ||')' ||
        '  AND (repcatalog.repair_end_date IS NULL  '||
         ' OR repcatalog.repair_end_date > '|| ''''||SYSDATE||'''' ||')' ||
      '  AND (prepair.repair_end_date IS NULL OR prepair.repair_end_date > '|| ''''||SYSDATE||'''' ||')' ||
       ' ORDER BY module.module_name '||
        ' ,comp.component_description ';
        
        
        
          OPEN p_catalog_data_cur
          FOR v_sql;
          
          
      -- 20-06-2006 Patni Query changed to dynamic  query End
     ELSE
      --   OPEN p_catalog_data_cur
       --  FOR
        -- 20-06-2006 Patni Query changed to dynamic  query Begin
        -- Patni 21-Aug-2006 - Included alias name for the Module - Begin
     v_sql :=  ' SELECT distinct module.module_name "Module Name", '||
        -- Patni 21-Aug-2006 - Included alias name for the Module - End
               ' comp.component_description "Component Description", '||
               ' comp.component_code "Component Code", '||
               ' comp.ata_reference_snum "ATA Chapter", '||
      -- 16-05-2006 Patni added reapir seq id in the select statement Begin
               ' repcatalog.repair_seq_id "Repair Seq id", '||
      -- 16-05-2006 Patni added reapir seq id in the select statement End
               ' prepair.repair_reference "Repair Reference", '||
               ' prepair.repair_description "Rpr Description", '||
               ' repcatalog.price_type "Price Type", '||
       -- 16-05-2006 Patni commented the Rpr tat to remove the + sign  and displaying the repair tat wothout sign Begin
       --   DECODE(repcatalog.incremental_tat_ind,'Y','+')||repcatalog.repair_tat "Rpr TAT",
               ' repcatalog.repair_tat "Rpr TAT", '||
       -- 16-05-2006 Patni commented the Rpr tat to remove the + sign  and displaying the repair tat wothout sign End
     -- 16-05-2006 Patni added incremental_tat_ind in the select statement Begin
               ' repcatalog.incremental_tat_ind "Incremental TaT indicator", '||
      -- 16-05-2006 Patni added incremental_tat_ind in the select statement End
       -- 16-05-2006 Patni commented the Rpr price to remove the + sign  and displaying the repair price wothout sign Begin
      -- DECODE(repcatalog.incremental_price_ind,'Y','+')||repcatalog.repair_price "Rpr Price",
               ' repcatalog.repair_price "Rpr Price", '||
       -- 16-05-2006 Patni commented the Rpr price  to remove the + sign  and displaying the repair price wothout sign End
     -- 16-05-2006 Patni added incremental_price_ind in the select statement Begin
               ' repcatalog.incremental_price_ind "Incremental Price Indicator", '||
      -- 16-05-2006 Patni added incremental_price_ind in the select statement End
                /*DECODE(repcatalog.future_tat,0,'',repcatalog.future_tat) "Future TAT",  --change the column name to future_tat
                DECODE(repcatalog.future_price,0.0,'',repcatalog.future_price) "Future Price",*/
               ' repcatalog.future_tat "Future TAT", '||
               ' repcatalog.future_price "Future Price",'|| 
               ' to_char(repcatalog.future_effective_date,''MM/dd/yyyy'') "Future Effective date" ';

             IF (p_in_site != 'ALL' )
             THEN 
              v_sql := v_sql || ',  NVL(cost.labour_hours,'''') "Labor Hours", '|| 
                    '  NVL(cost.material_cost,'''') "Material Cost" ,'||
                    ' ''N'' "Retain Value Indicator" , ' ||
                    ' case when (cost.LAST_UPDATE_DATE > SYSDATE-cycnt.notification_period_in_days) then ''Y'' else ''N'' end case ' ;
             END IF;  
           
          v_sql := v_sql ||' FROM crd_crc_module module, '||
              ' crd_e_component comp,'||
              ' crd_e_repair prepair,'||
              ' crd_e_repair_catalog repcatalog, '||
              ' crd_e_repair_cost cost,'||
           ' crd_e_component_location cecl , '||
           ' CRD_E_CYCLE_COUNTING_TYPE cycnt '||
          ' WHERE comp.module_seq_id = module.module_seq_id ' ||
       ' AND prepair.module_seq_id = module.module_seq_id '||
       ' AND module.eng_mdl_number = ' || ''''|| p_in_engine_model ||'''' || 
        '  AND prepair.component_code = comp.component_code'||
        '  AND repcatalog.catalog_seq_id = '||''''||  p_in_catalog_id  ||'''' || 
        '  AND prepair.repair_seq_id = repcatalog.repair_seq_id '||
        '  AND cost.repair_seq_id(+)= prepair.repair_seq_id '||
        '  AND cost.module_seq_id(+) = prepair.module_seq_id '||
        '  AND cost.component_code(+)= prepair.component_code ' ||
        '  AND cycnt.cycle_count_class = comp.cycle_count_class ' ;
  -- 20-06-2006 Patni Added to check the site value begin  
          IF ( p_in_site != 'ALL')
          THEN 
             v_sql := v_sql || ' AND cost.location_id(+) = '  || ''''||p_in_site||''''||' ' ;
          END IF;
          -- 20-06-2006 Patni Added to check the site value  End
        
      v_sql := v_sql || ' AND prepair.repair_type <> '|| ''''||ecrd_utils_pkg.G_CHILD_REPAIR||''''||
       ' AND cecl.module_seq_id = prepair.module_seq_id '||
       ' AND cecl.component_code =   prepair.component_code ';
   -- 20-06-2006 Patni Added to check the site value begin 
          IF ( p_in_site != 'ALL')
          THEN 
             v_sql := v_sql || ' AND cecl.location_id = '||  ''''||p_in_site||''''||' ' ;
         END IF;
   -- 20-06-2006 Patni Added to check the site value end    
   
      v_sql := v_sql ||' AND cecl.active_ind = '||  ''''||ecrd_utils_pkg.G_ACTIVE||''''||
      '  AND comp.cycle_count_class ='||  ''''||p_in_class||''''|| 
      '  AND (comp.component_end_date IS NULL OR comp.component_end_date >  '|| ''''||SYSDATE||'''' ||')' ||
      '    AND (repcatalog.repair_end_date IS NULL '||
      '    OR repcatalog.repair_end_date >'|| ''''||SYSDATE||'''' ||')' ||
      '  AND (prepair.repair_end_date IS NULL OR prepair.repair_end_date >  '|| ''''||SYSDATE||'''' ||')' ||
      '  ORDER BY module.module_name,comp.component_description ';
--
       
         OPEN p_catalog_data_cur
         FOR v_sql;
--    -- 20-06-2006 Patni Query changed to dynamic  query End

        END IF;
        EXCEPTION
WHEN OTHERS
THEN
   RAISE_APPLICATION_ERROR (-20021,'Error in ecrd_managecatalog_pkg.ecrd_download_batch_prc-'||SQLCODE||'-'||SUBSTR(SQLERRM,1,100));
END ecrd_download_batch_prc;

PROCEDURE ecrd_crc_modules_prc(p_out_module_cur OUT result_cursor)
IS
BEGIN
      OPEN p_out_module_cur FOR
             SELECT
               DISTINCT
                      cm.module_name

          FROM crd_crc_module cm;
END ecrd_crc_modules_prc;

PROCEDURE ecrd_list_eng_modules_prc(
                   p_in_eng_model_code IN crd_crc_module.eng_mdl_number%TYPE
                   ,p_in_boolean IN VARCHAR2
               ,p_out_eng_module_cur OUT result_cursor
                  )
IS
BEGIN
IF p_in_boolean='y'
THEN
         OPEN p_out_eng_module_cur
         FOR
         SELECT
         DISTINCT
         module_name
         FROM crd_crc_module
          WHERE module_name
          NOT IN(
          SELECT module_name
          FROM crd_crc_module
          WHERE eng_mdl_number=p_in_eng_model_code);

ELSE
         OPEN p_out_eng_module_cur
         FOR
         SELECT
         cm.module_seq_id,
         cm.module_name,
         --cm.created_by,
       UPPER(cru.LAST_NAME)|| ', ' ||UPPER(cru.FIRST_NAME),
         TO_CHAR(cm.creation_date,ecrd_utils_pkg.G_DISPLAY_DATE_FORMAT) creation_date,
         TO_CHAR(cm.creation_date,'YYYY/MM/DD') sortable_creation_date
         FROM   crd_crc_module cm,crd_crc_user cru
         WHERE  cm.eng_mdl_number=p_in_eng_model_code
       and UPPER(cru.USERID)=UPPER(cm.created_by);

END IF;
EXCEPTION
WHEN OTHERS
THEN
   RAISE_APPLICATION_ERROR (-20021,'Error in ecrd_managecatalog_pkg.ecrd_list_eng_modules_prc-'||SQLCODE||'-'||SUBSTR(SQLERRM,1,100));

END ecrd_list_eng_modules_prc;

PROCEDURE ecrd_update_module_desc_prc(
          p_in_engine_model IN crd_crc_module.eng_mdl_number%TYPE,
          p_in_module_cd IN crd_crc_module.module_seq_id%TYPE,
          p_in_module_desc IN crd_crc_module.module_name%TYPE,
          p_out_message OUT VARCHAR2)
IS
BEGIN

   UPDATE
      crd_crc_module
   SET
      module_name = p_in_module_desc
   WHERE
      module_seq_id = p_in_module_cd AND
      eng_mdl_number = p_in_engine_model;

   p_out_message := 'UPDATE_SUCCESS';
EXCEPTION
WHEN OTHERS
THEN
   RAISE_APPLICATION_ERROR (-20021,'Error in ecrd_managecatalog_pkg.ecrd_update_module_desc_prc-'||SQLCODE||'-'||SUBSTR(SQLERRM,1,100));
END ecrd_update_module_desc_prc;
/*

*/
PROCEDURE ecrd_get_ctlg_cust_data_prc (p_in_catalog_seq_id        IN crd_e_catalog.catalog_seq_id%TYPE
                                      ,p_out_ctlg_cust_data       OUT result_cursor)
AS
BEGIN
    OPEN p_out_ctlg_cust_data
    FOR
      SELECT   ccc.customer_code cust_code
            ,cc.customer_name cust_name
            ,ccc.contract_end_date end_date
            ,ccc.contract_number contract_code
            ,ccc.contract_start_date start_date
            ,ccc.customer_contract_description cont_desc
    FROM crd_e_customer_contract ccc
       ,crd_e_customer          cc
    WHERE cc.customer_code   = ccc.customer_code
    AND   ccc.catalog_seq_id = p_in_catalog_seq_id;
EXCEPTION
   WHEN OTHERS
   THEN RAISE;
END ecrd_get_ctlg_cust_data_prc;
/*
*/
PROCEDURE ecrd_get_customer_ctlg_prc (p_in_catalog_seq_id        IN crd_e_catalog.catalog_seq_id%TYPE
                             ,p_out_catalog_data         OUT result_cursor
                                      ,p_out_ctlg_cust_data       OUT result_cursor
                                      ,p_out_escalation_ind OUT VARCHAR2)
AS
BEGIN
    ecrd_get_catalog_data_prc(p_in_catalog_seq_id
                              ,p_out_catalog_data
                              ,p_out_escalation_ind);
    ecrd_get_ctlg_cust_data_prc (p_in_catalog_seq_id
                         ,p_out_ctlg_cust_data);
EXCEPTION
   WHEN OTHERS
   THEN RAISE;
END ecrd_get_customer_ctlg_prc ;

PROCEDURE ecrd_get_rules_prc(
      p_in_catalog IN VARCHAR2,
      p_in_year IN VARCHAR2,
      p_in_rule_level IN VARCHAR2,
      p_in_module_code IN VARCHAR2,
      p_in_component_code IN crd_e_component.component_code%TYPE,
      p_in_repair_seq_id IN VARCHAR2,
      p_out_rules OUT result_cursor,
      p_out_inflation OUT result_cursor,
      p_out_default_flow OUT result_cursor)
IS
v_main_query VARCHAR2(1000) := '';
v_exiting_count NUMBER := 0;
BEGIN
--  delete from roshan_Test;
--  commit;
 -- insert into roshan_test values ('!!!p_in_rule_level',p_in_rule_level);commit;
   IF(p_in_rule_level = 'C')
   THEN
      v_main_query :='SELECT'
                     ||' cecc.tat tat,'
                     ||' cecc.discount discount,'
                     ||' cecc.escalation escalation'
                     ||' FROM'
                     ||' CRD_E_CTLG_CONTRACTED cecc'
                     ||' WHERE'
                     ||' cecc.CATALOG_SEQ_ID = TO_NUMBER('||''''||p_in_catalog||''''||') AND'
                     ||' cecc.year = '||p_in_year;

   ELSIF(p_in_rule_level ='M')
   THEN
      v_main_query := 'SELECT'
                     ||' cecm.tat tat,'
                     ||' cecm.discount discount'
                     ||' FROM'
                     ||' CRD_E_CONTRACTED_MODULE cecm'
                     ||' WHERE'
                     ||' cecm.CATALOG_SEQ_ID = TO_NUMBER('||''''||p_in_catalog||''''||') AND'
                     ||' cecm.MODULE_SEQ_ID = TO_NUMBER('||''''||p_in_module_code||''''||') AND'
                     ||' cecm.year = '||p_in_year;

   ELSIF(p_in_rule_level = 'CO')
   THEN
      v_main_query := 'SELECT'
                     ||' cecc.tat tat,'
                     ||' cecc.discount discount'
                     ||' FROM'
                     ||' CRD_E_CONTRACTED_COMP cecc'
                     ||' WHERE'
                     ||' cecc.CATALOG_SEQ_ID = TO_NUMBER('||''''||p_in_catalog||''''||') AND'
                     ||' cecc.MODULE_SEQ_ID = TO_NUMBER('||''''||p_in_module_code||''''||') AND'
                     ||' cecc.component_code = '||''''||p_in_component_code||''''||' AND'
                     ||' cecc.year = '||p_in_year;

   ELSIF(p_in_rule_level = 'R')
   THEN
      v_main_query := 'SELECT'
                     ||' cecr.tat tat,'
                     ||' cecr.discount discount'
                     ||' FROM'
                     ||' CRD_E_CONTRACTED_REPAIR cecr'
                     ||' WHERE'
                     ||' cecr.CATALOG_SEQ_ID = TO_NUMBER('||''''||p_in_catalog||''''||') AND'
                     ||' cecr.repair_seq_id = TO_NUMBER('||''''||p_in_repair_seq_id||''''||') AND'
                     ||' cecr.year = '||p_in_year;
   END IF;


   --insert into roshan_test values('1',v_main_query);
   commit;

   OPEN p_out_rules
   FOR v_main_query;

   --insert into roshan_test values('2','Main data populated..');
   --commit;

   OPEN p_out_inflation
   FOR
      SELECT
         ceii.index_value index_value,
         ceii.index_dependancy index_dep,
         ceii.year year
      FROM
         CRD_E_INFLATION_INDEX ceii
      WHERE
         ceii.CATALOG_SEQ_ID = p_in_catalog AND
         ceii.year = p_in_year;
   OPEN p_out_default_flow
   FOR
      SELECT
         cec.calculated_price_default_ind calc_price_default_ind,
         cec.flowdown_changes_ind flow_down_ind
      FROM
         CRD_E_CATALOG cec
      WHERE
         cec.catalog_seq_id = p_in_catalog;

--insert into roshan_test values('3','Inflation Index..');
 --  commit;

EXCEPTION
WHEN OTHERS
THEN
   RAISE_APPLICATION_ERROR(-20020,'***Error in eCRD_ManageCatalog_pkg.ecrd_get_rules_prc--'||SQLCODE||'-'||SQLERRM);
END ecrd_get_rules_prc;

PROCEDURE ecrd_create_rule_prc(
      p_in_RuleLevel IN VARCHAR2,
      p_in_catalog_seq_id IN crd_e_catalog.catalog_seq_id%TYPE,
      p_in_ComponentCd IN crd_e_component.component_code%TYPE,
      p_in_ModuleCd IN crd_crc_module.module_seq_id%TYPE,
      p_in_RepairCd IN crd_e_repair.repair_seq_id%TYPE,
      p_in_Year IN VARCHAR2,
      p_in_TAT IN crd_e_ctlg_contracted.tat%TYPE,
      p_in_Discount IN crd_e_ctlg_contracted.discount%TYPE,
      p_in_DefaultValCompare IN crd_e_catalog.calculated_price_default_ind%TYPE,
      p_in_FlowChangesFrmDef IN crd_e_catalog.flowdown_changes_ind%TYPE,
      p_in_Escalation IN crd_e_ctlg_contracted.escalation%TYPE,
      p_in_IndexDep IN VARCHAR2,
      p_in_UserId IN crd_crc_user.userid%TYPE,
      p_out_message OUT VARCHAR2
)
IS
  tab_broken_row ecrd_utils_pkg.gtyp_buf_arr;
  tab_broken_column ecrd_utils_pkg.gtyp_buf_arr;
  v_row_count NUMBER :=0;
  v_index NUMBER :=0;
  v_row_details VARCHAR2(2000) :='';
  v_exisiting_count NUMBER := 0;
  v_all VARCHAR2(1) := 'N';
  v_startYear NUMBER(4) :='';
  v_endYear NUMBER(4) :='';
BEGIN
   IF(p_in_year = 'All')
   THEN
      v_all := 'Y';
   END IF;

   SELECT
      TO_NUMBER(TO_CHAR(catalog_effective_date,'YYYY')),
      TO_NUMBER(TO_CHAR(catalog_end_date,'YYYY'))
   INTO
      v_startYear,
      v_endYear
   FROM
      crd_e_catalog
   WHERE
      catalog_seq_id = p_in_catalog_seq_id;

   IF(p_in_RuleLevel = 'C')
   THEN
      IF((p_in_discount IS NOT NULL AND p_in_discount <> 0) OR (p_in_TAT IS NOT NULL AND p_in_TAT <> 0) OR (p_in_Escalation IS NOT NULL AND p_in_Escalation <> 0.0))
      THEN
         IF(v_all = 'Y')
         THEN
            FOR i IN v_startYear..v_endYear
            LOOP
               INSERT INTO CRD_E_CTLG_CONTRACTED
               (
                  catalog_seq_id,               --1
                  year,                         --2
                  tat,                          --3
                  escalation,                   --4
                  discount,                     --5
                  created_by,                   --6
                  creation_date,                --7
                  last_update_date,             --8
                  last_updated_by               --9
               )
               VALUES
               (
                  p_in_catalog_seq_id,    --1
                  i,                      --2
                  DECODE(p_in_TAT,0,NULL,p_in_TAT),               --3
                  p_in_escalation,        --4
                  p_in_discount,          --5
                  p_in_userid,            --6
                  SYSDATE,                --7
                  SYSDATE,                --8
                  p_in_userid             --9
               );
            END LOOP;
         ELSE
            INSERT INTO CRD_E_CTLG_CONTRACTED
            (
               catalog_seq_id,               --1
               year,                         --2
               tat,                          --3
               escalation,                   --4
               discount,                     --5
               created_by,                   --6
               creation_date,                --7
               last_update_date,             --8
               last_updated_by               --9
            )
            VALUES
            (
               p_in_catalog_seq_id,    --1
               p_in_year,              --2
               DECODE(p_in_TAT,0,NULL,p_in_TAT),               --3
               p_in_escalation,        --4
               p_in_discount,          --5
               p_in_userid,            --6
               SYSDATE,                --7
               SYSDATE,                --8
               p_in_userid             --9
            );
         END IF;
      END IF;

      UPDATE crd_e_catalog
      SET
         calculated_price_default_ind = p_in_DefaultValCompare,
         flowdown_changes_ind = p_in_FlowChangesFrmDef
      WHERE
         catalog_seq_id = p_in_catalog_seq_id;
      IF(p_in_FlowChangesFrmDef = 'N')
      THEN

         IF(p_in_Escalation IS NULL OR p_in_Escalation ='' OR p_in_Escalation = 0.0)
         THEN
         -- Breaking the String into Rows...
            IF(p_in_IndexDep IS NOT NULL OR p_in_IndexDep <> '')
            THEN

            ecrd_utils_pkg.break_into_rows_s_prc(p_in_IndexDep,ecrd_utils_pkg.G_ROW_DELIM,tab_broken_row);

            v_row_count := tab_broken_row.COUNT;

            IF(v_row_count > 0)
            THEN
               FOR v_index IN 1..v_row_count
               LOOP

                  v_row_details := tab_broken_row(v_index);

                  -- Breaking the Rows into Columns...

                  ecrd_utils_pkg.break_into_cols_s_prc(v_row_details,ecrd_utils_pkg.G_COL_DELIM,tab_broken_column);

                  -- inserting the data in inflation table..
                  IF(v_all = 'Y')
                  THEN
                     FOR i IN v_startYear..v_endYear
                     LOOP
                     	IF(tab_broken_column(1) IS NOT NULL)
                        THEN
	                        INSERT INTO CRD_E_INFLATION_INDEX
	                        (
	                           catalog_seq_id,   --1
	                           index_value,      --2
	                           year,             --3
	                           index_dependancy, --4
	                           created_by,       --5
	                           creation_date,    --6
	                           last_update_date, --7
	                           last_updated_by   --8
	                        )
	                        VALUES
	                        (
	                           p_in_catalog_seq_id,    --1
	                           DECODE(tab_broken_column(1),'','',TO_NUMBER(tab_broken_column(1))),  --2
	                           i,                      --3
	                           DECODE(tab_broken_column(1),'','',TO_NUMBER(tab_broken_column(2))),  --4
	                           p_in_UserId,            --5
	                           SYSDATE,                --6
	                           SYSDATE,                --7
	                           p_in_UserId             --8
	                        );
                        END IF;
                     END LOOP;
                  ELSE
                  	IF(tab_broken_column(1) IS NOT NULL)
                     THEN
	                     INSERT INTO CRD_E_INFLATION_INDEX
	                     (
	                        catalog_seq_id,   --1
	                        index_value,      --2
	                        year,             --3
	                        index_dependancy, --4
	                        created_by,       --5
	                        creation_date,    --6
	                        last_update_date, --7
	                        last_updated_by   --8
	                     )
	                     VALUES
	                     (
	                        p_in_catalog_seq_id,    --1
	                        DECODE(tab_broken_column(1),'','',TO_NUMBER(tab_broken_column(1))),  --2
	                        p_in_year,              --3
	                        DECODE(tab_broken_column(1),'','',TO_NUMBER(tab_broken_column(2))),  --4
	                        p_in_UserId,            --5
	                        SYSDATE,                --6
	                        SYSDATE,                --7
	                        p_in_UserId             --8
	                     );
                     END IF;
                  END IF;
               END LOOP;
            END IF;
         END IF;
      END IF;
      END IF;
   ELSIF(p_in_RuleLevel = 'M')
   THEN
      IF((p_in_discount IS NOT NULL AND p_in_discount <> 0) OR (p_in_TAT IS NOT NULL AND p_in_TAT <> 0))
      THEN
         IF(v_all = 'Y')
         THEN
            FOR i IN v_startYear..v_endYear
            LOOP
               INSERT INTO CRD_E_CONTRACTED_MODULE cecm
               (
                  module_seq_id,       --1
                  catalog_seq_id,      --2
                  year,                --3
                  tat,                 --4
                  created_by,          --5
                  discount,            --6
                  creation_date,       --7
                  last_update_date,    --8
                  last_updated_by      --9
               )
               VALUES
               (
                  p_in_ModuleCd,       --1
                  p_in_catalog_seq_id, --2
                  i,                   --3
                  DECODE(p_in_TAT,0,NULL,p_in_TAT),            --4
                  p_in_userId,         --5
                  p_in_Discount,       --6
                  SYSDATE,             --7
                  SYSDATE,             --8
                  p_in_UserId          --9
               );
            END LOOP;
         ELSE
            INSERT INTO CRD_E_CONTRACTED_MODULE cecm
            (
               module_seq_id,       --1
               catalog_seq_id,      --2
               year,                --3
               tat,                 --4
               created_by,          --5
               discount,            --6
               creation_date,       --7
               last_update_date,    --8
               last_updated_by      --9
            )
            VALUES
            (
               p_in_ModuleCd,       --1
               p_in_catalog_seq_id, --2
               p_in_year,           --3
               DECODE(p_in_TAT,0,NULL,p_in_TAT),            --4
               p_in_userId,         --5
               p_in_Discount,       --6
               SYSDATE,             --7
               SYSDATE,             --8
               p_in_UserId          --9
            );
         END IF;
      END IF;
   ELSIF(p_in_RuleLevel = 'CO')
   THEN
      IF((p_in_discount IS NOT NULL AND p_in_discount <> 0) OR (p_in_TAT IS NOT NULL AND p_in_TAT <> 0))
      THEN
         IF(v_all = 'Y')
         THEN
            FOR i IN v_startYear..v_endYear
            LOOP
               INSERT INTO CRD_E_CONTRACTED_COMP
               (
                  module_seq_id,    --1
                  component_code,   --2
                  catalog_seq_id,   --3
                  year,             --4
                  discount,         --5
                  tat,              --6
                  created_by,       --7
                  creation_date,    --8
                  last_update_date, --9
                  last_updated_by   --10
               )
               VALUES
               (
                  p_in_ModuleCd,       --1
                  p_in_ComponentCd,    --2
                  p_in_catalog_seq_id, --3
                  i,                   --4
                  p_in_Discount,       --5
                  DECODE(p_in_TAT,0,NULL,p_in_TAT),            --6
                  p_in_userId,         --7
                  SYSDATE,             --8
                  SYSDATE,             --9
                  p_in_UserId          --10
               );
            END LOOP;
         ELSE
            INSERT INTO CRD_E_CONTRACTED_COMP
            (
               module_seq_id,    --1
               component_code,   --2
               catalog_seq_id,   --3
               year,             --4
               discount,         --5
               tat,              --6
               created_by,       --7
               creation_date,    --8
               last_update_date, --9
               last_updated_by   --10
            )
            VALUES
            (
               p_in_ModuleCd,       --1
               p_in_ComponentCd,    --2
               p_in_catalog_seq_id, --3
               p_in_year,           --4
               p_in_Discount,       --5
               DECODE(p_in_TAT,0,NULL,p_in_TAT),            --6
               p_in_userId,         --7
               SYSDATE,             --8
               SYSDATE,             --9
               p_in_UserId          --10
            );
         END IF;
      END IF;
   ELSIF(p_in_RuleLevel = 'R')
   THEN
      IF((p_in_discount IS NOT NULL AND p_in_discount <> 0) OR (p_in_TAT IS NOT NULL AND p_in_TAT <> 0))
      THEN
         IF(v_all = 'Y')
         THEN
            FOR i IN v_startYear..v_endYear
            LOOP
               INSERT INTO CRD_E_CONTRACTED_REPAIR
               (
                  catalog_seq_id,      --1
                  repair_seq_id,       --2
                  year,                --3
                  discount,            --4
                  tat,                 --5
                  created_by,          --6
                  creation_date,       --7
                  last_update_date,    --8
                  last_updated_by      --9
               )
               VALUES
               (
                  p_in_catalog_seq_id, --1
                  p_in_RepairCd,       --2
                  i,                   --3
                  p_in_Discount,       --4
                  DECODE(p_in_TAT,0,NULL,p_in_TAT),            --5
                  p_in_userId,         --6
                  SYSDATE,             --7
                  SYSDATE,             --8
                  p_in_UserId          --9
               );
            END LOOP;
         ELSE
            INSERT INTO CRD_E_CONTRACTED_REPAIR
            (
               catalog_seq_id,      --1
               repair_seq_id,       --2
               year,                --3
               discount,            --4
               tat,                 --5
               created_by,          --6
               creation_date,       --7
               last_update_date,    --8
               last_updated_by      --9
            )
            VALUES
            (
               p_in_catalog_seq_id, --1
               p_in_RepairCd,       --3
               p_in_year,           --2
               p_in_Discount,       --4
               DECODE(p_in_TAT,0,NULL,p_in_TAT),            --5
               p_in_userId,         --6
               SYSDATE,             --7
               SYSDATE,             --8
               p_in_UserId          --9
            );
         END IF;
      END IF;
   END IF;
   COMMIT;

EXCEPTION
WHEN OTHERS
THEN
   ROLLBACK;
--   p_out_message := 'UNABLE_TO_CREATE_RULE';
   RAISE_APPLICATION_ERROR(-20020,p_in_Discount||'-p_in_Discount -'||p_in_Tat||'-p_in_Tat ***Error in eCRD_ManageCatalog_pkg.ecrd_create_rules_prc--'||SQLCODE||'-'||SUBSTR(SQLERRM,1,100));
END ecrd_create_rule_prc;

PROCEDURE ecrd_view_rules_prc(
      p_in_catalog_seq_id IN VARCHAR2,
      p_in_year IN VARCHAR2,
      p_out_catalog_rules OUT result_cursor,
      p_out_inflation_rules OUT result_cursor,
      p_out_module_rules OUT result_cursor,
      p_out_component_rules OUT result_cursor,
      p_out_repair_rules OUT result_cursor)
IS
v_catalog_query LONG :='';
v_module_query LONG :='';
v_component_query LONG :='';
v_repair_query LONG :='';
v_inflation_query LONG :='';
BEGIN
      v_catalog_query := 'SELECT DISTINCT
                           cecc.year Year,   -- Year
                           '''' Module_Desc,
                           '''' Component_Desc,
                           '''' Repair_Desc,
                           cecc.discount Discount, -- Discount
                           DECODE(cecc.tat,0,''-'',cecc.tat) TAT,    -- TAT
                           cecc.escalation Escalation,   --Escalation
                           0 Index_value,             --Index
                           0 Dependency,              --Dependency..
                           '''' Module_id,
                           '''' Component_id,
                           '''' Repair_id,
                           cec.flowdown_changes_ind flow_down_ind,
                           cec.calculated_price_default_ind default_price_ind
                           FROM
                           crd_e_ctlg_contracted cecc,
                           crd_e_catalog cec
                           WHERE
                           cec.catalog_seq_id = cecc.catalog_seq_id AND
                           cecc.CATALOG_SEQ_ID = '||p_in_catalog_seq_id;
      IF(p_in_year <> 'All')
      THEN
         v_catalog_query := v_catalog_query||' AND  cecc.year = '||p_in_year;
      END IF;


      OPEN p_out_catalog_rules
      FOR
         v_catalog_query;

      v_inflation_query := 'SELECT DISTINCT
                              ceii.year Year,   -- Year
                              '''' Module_Desc,
                              '''' Component_Desc,
                              '''' Repair_Desc,
                              0 Discount, -- Discount
                              0 TAT,      -- TAT
                              0 Escalation,  --Escalation
                              ceii.index_value Index_value, --Index
                              ceii.index_dependancy Dependency, --Dependency..
	                           (SELECT
									  		count(1)
									   FROM
									   	crd_e_inflation_index
									   WHERE
									   	catalog_seq_id = '||p_in_catalog_seq_id||' AND
									   	year = ceii.year
									   GROUP BY year) year_count
                           FROM
                              crd_e_inflation_index ceii
                           WHERE
                           	ceii.catalog_seq_id = '||p_in_catalog_seq_id;

      IF(p_in_year <> 'All')
      THEN
         v_inflation_query := v_inflation_query||' AND  ceii.year = '||p_in_year;
      END IF;


      OPEN p_out_inflation_rules
      FOR
         v_inflation_query;

      v_module_query := 'SELECT DISTINCT
                           cecm.year Year,
                           ccm.module_name Module_Desc,
                           '''' Component_Desc,
                           '''' Repair_Desc,
                           cecm.discount Discount,
                           DECODE(cecm.tat,0,''-'',cecm.tat) TAT,
                           0 Escalation,
                           0 Index_value,
                           0 Dependency,
                           ccm.module_seq_id Module_id,
                           '''' Component_id,
                           '''' Repair_id
                           FROM
                              crd_e_contracted_module cecm,
                              crd_crc_module ccm,
                              crd_e_repair cer
                           WHERE
--            cer.active_ind = ecrd_utils_pkg.G_ACTIVE AND
                              (cer.repair_end_date IS NULL OR
                               cer.repair_end_date > SYSDATE) AND
                               cer.module_seq_id = ccm.module_seq_id AND
                               cecm.catalog_seq_id = '||p_in_catalog_seq_id||' AND
                               cecm.module_seq_id = ccm.module_seq_id';

      IF(p_in_year <> 'All')
      THEN
         v_module_query := v_module_query||' AND  cecm.year = '||p_in_year;
      END IF;
      OPEN p_out_module_rules
      FOR
         v_module_query;

      v_component_query := ' SELECT DISTINCT
                         ceccomp.year Year,
                         ccm.module_name Module_Desc,
                         cec.component_description Component_Desc,
                      ''''  Repair_Desc,
                         ceccomp.discount Discount,
                         DECODE(ceccomp.tat,0,''-'',ceccomp.tat) TAT,
                         0 Escalation,
                         0 Index_value,
                         0 Dependency,
                         ccm.module_seq_id Module_id,
                         ceccomp.component_code Component_id,
                         '''' Repair_id
                        FROM
                           crd_e_contracted_comp ceccomp,
                           crd_e_component cec,
                           crd_e_repair cer,
                           crd_crc_module ccm
                        WHERE
                           ceccomp.catalog_seq_id = '||p_in_catalog_seq_id||' AND
                           cer.component_code = cec.component_code AND
                           cer.module_seq_id = cec.module_seq_id AND
                           ccm.module_seq_id = cec.module_seq_id AND
                           cec.module_seq_id = ceccomp.module_seq_id AND
                           cec.component_code = ceccomp.component_code';

      IF(p_in_year <> 'All')
      THEN
         v_component_query := v_component_query||' AND  ceccomp.year = '||p_in_year;
      END IF;
      OPEN p_out_component_rules
      FOR
        v_component_query;

      v_repair_query := 'SELECT
                              cecr.year Year,
                              ccm.module_name Module_Desc,
                              cec.component_description Component_Desc,
                              cer.repair_description Repair_Desc,
                              cecr.discount Discount,
                              DECODE(cecr.tat,0,''-'',cecr.tat) TAT,
                              0 Escalation,
                              0 Index_value,
                              0 Dependency,
                              ccm.module_seq_id Module_id,
                              cec.component_code Component_id,
                              cer.repair_seq_id Repair_id
                           FROM
                              crd_e_contracted_repair cecr,
                              crd_e_repair cer,
                              crd_e_component cec,
                              crd_crc_module ccm
                           WHERE
                              cecr.catalog_seq_id = '||p_in_catalog_seq_id||' AND
                              cecr.repair_seq_id = cer.repair_seq_id AND
                              cec.component_code = cer.component_code AND
                              cec.module_seq_id = cer.module_seq_id AND
                              ccm.module_seq_id = cer.module_seq_id';

      IF(p_in_year <> 'All')
      THEN
         v_repair_query := v_repair_query||' AND  cecr.year = '||p_in_year;
      END IF;
      OPEN p_out_repair_rules
      FOR
         v_repair_query;


EXCEPTION
WHEN OTHERS
THEN
   RAISE_APPLICATION_ERROR(-20020,'***Error in eCRD_ManageCatalog_pkg.ecrd_view_rules_prc--'||SQLCODE||'-'||SUBSTR(SQLERRM,1,100));
END ecrd_view_rules_prc;

PROCEDURE ecrd_copy_apply_prc(
      p_in_catalog_seq_id IN crd_e_catalog.catalog_seq_id%TYPE,
      p_in_user_id IN crd_crc_user.userid%TYPE,
      p_out_message OUT VARCHAR2)
IS
-- Cursor for finding all the Repairs for selected Catalog for a particular year
CURSOR eCRD_catalog_rules(p_default_catalog_seq_id VARCHAR2)
IS
   SELECT
      cer.repair_seq_id
   FROM
      crd_e_repair cer,
      crd_e_repair_catalog cerc
   WHERE
      cerc.repair_seq_id = cer.repair_seq_id AND
      cerc.catalog_seq_id = p_default_catalog_seq_id AND
      -- PHA 03/09/2005 Added trunc function and new join clause
      (trunc(cer.repair_end_date) > trunc(SYSDATE) OR cer.repair_end_date IS NULL)
      AND cer.repair_type <> ecrd_utils_pkg.g_child_repair;

-- Cursor for finding all the Repairs for selected Modules for a particular year
CURSOR eCRD_module_rules
IS
   SELECT
      cer.repair_seq_id,
      cecm.discount,
      cecm.tat,
      cecm.year
   FROM
      crd_e_contracted_module cecm,
      crd_e_repair cer
   WHERE
      cecm.module_seq_id = cer.module_seq_id AND
      cecm.catalog_seq_id = p_in_catalog_seq_id AND
      -- PHA 03/09/2005 Added trunc function and new join clause
      (trunc(repair_end_date) > trunc(SYSDATE) OR cer.repair_end_date IS NULL)
      AND cer.repair_type <> ecrd_utils_pkg.g_child_repair
   ORDER BY 4 desc;

-- Cursor for finding all the Repairs for selected Component for a particular year
CURSOR eCRD_component_rules
IS
   SELECT DISTINCT
      cer.repair_seq_id,
      ceccomp.discount,
      ceccomp.tat,
      ceccomp.year
   FROM
      crd_e_contracted_comp ceccomp,
      crd_e_repair cer
   WHERE
      cer.component_code = ceccomp.component_code AND
      ceccomp.catalog_seq_id = p_in_catalog_seq_id AND
      -- PHA 03/09/2005 Added trunc function and new join clause
      (trunc(repair_end_date) > trunc(SYSDATE) OR cer.repair_end_date IS NULL)
      AND cer.repair_type <> ecrd_utils_pkg.g_child_repair
      ORDER BY 4 desc;

-- Cursor for finding all the Repairs for selected Repairs for a particular year
CURSOR eCRD_repair_rules
IS
   SELECT
      cer.repair_seq_id,
      cecr.discount,
      cecr.tat,
      cecr.year
   FROM
      crd_e_contracted_repair cecr,
      crd_e_repair cer
   WHERE
      cecr.catalog_seq_id = p_in_catalog_seq_id AND
      -- RR added the join with crd_e_repair table to find out if the repair is still active.
      cer.repair_seq_id = cecr.repair_seq_id AND
      (cer.repair_end_date IS NULL OR trunc(cer.repair_end_date) > trunc(SYSDATE))
      ORDER BY 4 desc;

-- Cursor for finding Child Repair for selected Parent Repair
CURSOR eCRD_Child_repair(p_repair_seq_id IN VARCHAR2)
IS
   SELECT
      repair_seq_id
   FROM
      CRD_E_REPAIR
   WHERE
      parent_repair_seq_id = p_repair_seq_id AND
      -- PHA 03/09/2005 Added trunc function
      (trunc(repair_end_date) > trunc(SYSDATE) OR repair_end_date IS NULL);

-- RR Commented to optimize I M Done while applying catalog level rules
/*CURSOR eCRD_Catalog_Year(p_year IN VARCHAR2)
IS
   SELECT
      year,
      discount,
      tat
   FROM
      crd_e_ctlg_contracted cecc
   WHERE
      catalog_seq_id = p_in_catalog_seq_id
      and year = p_year
      ORDER BY 1 desc;*/

   v_catalog_count NUMBER :=0;
   v_module_count NUMBER :=0;
   v_component_count NUMBER :=0;
   v_repair_count NUMBER :=0;
   v_default_catalog_seq_id crd_e_catalog.catalog_seq_id%TYPE;
   v_engine_model crd_e_catalog.eng_mdl_number%TYPE;
   v_year VARCHAR2(4) :='';
   -- PHA 03/09/2005 Changed the variable declaration. Inititalized with column type.
   v_price crd_e_repair_catalog.repair_price%TYPE := 0.0;
   v_new_price crd_e_repair_catalog.repair_price%TYPE := 0.0;
   v_existing_count NUMBER :=0;
   v_n_step NUMBER := 0;
   v_in_n_step NUMBER :=0;
   v_child_repair_count NUMBER :=0;
   -- PHA 03/09/2005 Changed the variable declaration. Inititalized with column type.
   v_tat crd_e_repair_catalog.repair_tat%TYPE := 0;
   v_new_tat crd_e_repair_catalog.repair_tat%TYPE;
   v_start_date crd_e_catalog.catalog_effective_date%TYPE;
   v_sys_date DATE;
   v_count_in_history NUMBER :=0;
   v_flag VARCHAR2(1) := 'N';
   v_effective_date DATE;
   v_special_ind_repair VARCHAR2(2) := ecrd_utils_pkg.g_special_ind_repair;
   v_special_grp_repair VARCHAR2(2) := ecrd_utils_pkg.g_special_group_repair;
   v_split_repair VARCHAR2(2) := ecrd_utils_pkg.g_split_repair;
   v_merge_repair VARCHAR2(2) := ecrd_utils_pkg.g_merge_repair;
   -- PHA 03/09/2005 Added variable.
   v_err_msg VARCHAR2(250) := '';
   v_rule_discount crd_e_ctlg_contracted.discount%TYPE;
   v_rule_tat crd_e_ctlg_contracted.TAT%TYPE;

   BEGIN
-- let the date be constant for one run of the procedure
-- to ensure we are not inserting same price again and again for same repair
   v_sys_date := SYSDATE;
-- Selecting the engine model of the customer catalog.

   SELECT
      cec.eng_mdl_number,
      cec.catalog_effective_date,
      cec.catalog_effective_date
   INTO
      v_engine_model,
      v_start_date,
      v_effective_date
   FROM
      crd_e_catalog cec
   WHERE
      cec.catalog_seq_id = p_in_catalog_seq_id AND
      cec.active_ind = ecrd_utils_pkg.G_ACTIVE AND
      -- PHA 03/09/2005 Added trunc.
      trunc(cec.catalog_end_date) >= trunc(SYSDATE);

dbms_output.put_line('v_engine_model'||v_engine_model);
v_n_step := 1;

-- Finding if there is rule applied at catalog level for this Customer Catalog
   SELECT
      COUNT(1)
   INTO
      v_catalog_count
   FROM
      crd_e_ctlg_contracted
   WHERE
      catalog_seq_id = p_in_catalog_seq_id;

-- Finding if there is rule applied at Module level for this Customer Catalog
   SELECT
      COUNT(1)
   INTO
      v_module_count
   FROM
      crd_e_contracted_module
   WHERE
      catalog_seq_id = p_in_catalog_seq_id;

-- Finding if there is rule applied at Component level for this Customer Catalog
   SELECT
      COUNT(1)
   INTO
      v_component_count
   FROM
      crd_e_contracted_comp
   WHERE
      catalog_seq_id = p_in_catalog_seq_id;

-- Finding if there is rule applied at Repair level for this Customer Catalog
   SELECT
      COUNT(1)
   INTO
      v_repair_count
   FROM
      crd_e_contracted_repair
   WHERE
      catalog_seq_id = p_in_catalog_seq_id;

v_n_step := 2;

-- Selecting the Default Catalog's seq for selected customer catalog's engine model
-- PHA 03/09/2005 commented code
/*   SELECT
      cec.catalog_seq_id
   INTO
      v_default_catalog_seq_id
   FROM
      crd_e_catalog cec
   WHERE
      cec.catalog_end_date > SYSDATE AND
      cec.catalog_type = ecrd_utils_pkg.G_DEFAULT_CATALOG AND
      cec.eng_mdl_number = v_engine_model AND
      cec.active_ind = ecrd_utils_pkg.G_ACTIVE;
*/
-- calling the standard proc to get default catalog id
ecrd_managecatalog_pkg.ecrd_get_default_seqid_prc(v_engine_model, v_default_catalog_seq_id, v_err_msg);

v_n_step := 3;

-- Getting the current Year..
   SELECT
      TO_CHAR(SYSDATE,'YYYY')
   INTO
      v_year
   FROM
      DUAL;
dbms_output.put_line('v_year'||v_year);

   IF(TO_DATE(v_effective_date) <= TO_DATE(v_sys_date))
   THEN
      v_flag := 'Y';
   END IF;

   -- To set the repair catalog effective data as following.
   --1) If Catalog Effective Date is Future Date then Repair Catalog Effective date will be future Date.
   --2) If Catalog Effective Date is Past Date then Repair Catalog Effective Date will be Sysdate.
   --3) If Catalog Effective Date is Current Date then Repair Catalog Effective Date will be Catalog Effective Date

   IF(TO_DATE(v_effective_date) <= TO_DATE(v_sys_date))
   THEN
      v_start_date := SYSDATE;
/*   ELSE
      v_start_date := v_effective_date;*/
   END IF;
--Creating History Record before Copying repairs.
   INSERT INTO crd_e_repair_catalog_hist
   (
      repair_seq_id,             --1
      catalog_seq_id,            --2
      effective_date,            --3
      staging_history_ind,       --4
      change_start_date,         --5
      repair_price,              --6
      incremental_price_ind,     --7
      repair_tat,                --8
      incremental_tat_ind,       --9
      future_price,              --10
      future_effective_date,     --11
      price_type,                --12
      repair_end_date,           --13
      future_tat,                --14
      repair_display_seq_id,     --15
      price_overwrite_flag_ind,  --16
      created_by,               --17
      creation_date,            --18
      last_update_date,         --19
      last_updated_by           --20
   )
   SELECT
      repair_seq_id,                   --1
      catalog_seq_id,                  --2
      effective_date,                  --3
      ecrd_utils_pkg.G_HISTORY_RECORD, --4
      SYSDATE,                         --5
      repair_price,                    --6
      incremental_price_ind,           --7
      repair_tat,                      --8
      incremental_tat_ind,             --9
      future_price,                    --10
      future_effective_date,           --11
      price_type,                      --12
      repair_end_date,                 --13
      future_tat,                      --14
      repair_display_seq_id,           --15
      price_overwrite_flag_ind,        --16
      p_in_user_id,                    --17
      SYSDATE,                         --18
      SYSDATE,                         --19
      p_in_user_id                     --20
   FROM
      crd_e_repair_catalog
   WHERE
      catalog_seq_id = p_in_catalog_seq_id;

--updating all the record for this catalog with repair_end_date as SYSDATE in crd_e_repair_catalog
-- table only if rules is present atleast one level.
   IF(v_catalog_count > 0 OR v_module_count > 0 OR v_component_count > 0 OR v_repair_count > 0)
   THEN
      UPDATE
         crd_e_repair_catalog
      SET
         repair_end_date = v_sys_date
      WHERE
         catalog_seq_id = p_in_catalog_seq_id AND
         repair_end_date IS NULL AND
         (default_repair_ind = ecrd_utils_pkg.G_NO) AND
         repair_seq_id NOT IN (SELECT
                                 c.repair_seq_id
                               FROM
                               -- PHA Used c as alias for table
                                 crd_e_repair c
                               WHERE
                               -- PHA Removed the NOT keyword.
                                 c.repair_type IN(v_special_ind_repair,
                                                    v_special_grp_repair,
                                                    v_split_repair,
                                                    v_merge_repair) AND
                                 -- PHA 03/09/2005 Added trunc function
                                 (c.repair_end_date IS NULL OR trunc(c.repair_end_date) > trunc(SYSDATE))
                               -- PHA Should not have repairs that are child of SG,  MR
                               UNION
                               SELECT
                                   r.repair_seq_id
                               FROM
                                   crd_e_repair r, crd_e_repair rr
                               WHERE
                                   r.repair_type = ecrd_utils_pkg.g_child_repair AND
                                   r.parent_repair_seq_id = rr.repair_seq_id
                                   and rr.repair_type in (v_special_grp_repair,v_merge_repair)
                                   and (r.repair_end_date is null or trunc(r.repair_end_date) >= trunc(sysdate))
                                   and (rr.repair_end_date is null or trunc(rr.repair_end_date) >= trunc(sysdate))
                              );
   END IF;
v_n_step := 4;

-- Inserting the repair for customer catalog and applying Catalog level rules if present
   IF(v_catalog_count > 0)
   THEN
      FOR ecrd_ref_catalog_cur IN eCRD_catalog_rules(v_default_catalog_seq_id)
      LOOP
dbms_output.put_line('ecrd_ref_catalog_cur.repair_seq_id========'||ecrd_ref_catalog_cur.repair_seq_id);
      --Getting the base price from the default catalog
         BEGIN
            SELECT
               repair_price,
               repair_tat
            INTO
               v_price,
               v_tat
            FROM
               crd_e_repair_catalog
            WHERE
               catalog_seq_id = v_default_catalog_seq_id AND
               repair_seq_id = ecrd_ref_catalog_cur.repair_seq_id
               -- PHA 03/09/2005 Added condition.
            AND (repair_end_date IS NULL OR trunc(repair_end_date) > trunc(sysdate));

            EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               v_price := 0;

               --Patni 24/02/2006 - Begin - Setting TAT to 0, if no data is found
               v_tat   := 0;
               --Patni 24/02/2006 - End - Setting TAT to 0, if no data is found
         END;
      -- Calculating the new Price for customer catalog.
         --FOR ecrd_ref_rules_catalog IN eCRD_Catalog_Year(v_year)
         --LOOP
         -- RR Added select to optimize I M Done while applying catalog level rules
         BEGIN
            SELECT
	       -- Patni 05/05/2006 - Begin - To put 0% discount when discount is Blank
               NVL(discount,0),
	       -- Patni 05/05/2006 - Begin - To put 0% discount when discount is Blank
               tat
            INTO
               v_rule_discount,
               v_rule_tat
            FROM
               crd_e_ctlg_contracted cecc
            WHERE
               catalog_seq_id = p_in_catalog_seq_id
               and year = v_year;
         EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            v_rule_discount := 0;

            --Patni 24/02/2006 - Begin - Setting TAT to 0, if no data is found
            v_rule_tat   := 0;
            --Patni 24/02/2006 - End - Setting TAT to 0, if no data is found
         END;

         --Patni 24/02/2006 - Begin - Initializing the variables
         v_new_price         := NULL;
         v_new_tat           := NULL;
         --Patni 24/02/2006 - End - Initializing the variables

         IF(v_flag = 'Y')
         THEN
            v_new_price := (v_price - (v_price * (v_rule_discount/100)));
            v_new_tat :=  v_rule_tat;
         ELSE
            v_new_price := v_price;
            v_new_tat := v_tat;
         END IF;

         IF(v_new_tat IS NULL)
         THEN
            v_new_tat := v_tat;
         END IF;

         SELECT
            COUNT(1)
         INTO
            v_existing_count
         FROM
            CRD_E_REPAIR_CATALOG
         WHERE
            repair_seq_id = ecrd_ref_catalog_cur.repair_seq_id AND
            catalog_seq_id = p_in_catalog_seq_id
            -- PHA 03/09/2005 commented condition.
            --AND to_date(effective_date) = to_date(v_start_date)
            --AND repair_end_date IS NULL
            ;


         IF(v_existing_count = 0)
         THEN

-- Repair TAT populated with '' for Apply TAT at Component Level by RR on 6th April
            INSERT INTO CRD_E_REPAIR_CATALOG
            (
               /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - Begin */
               crd_e_repair_catalog_seq_id,
               /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - End */
               repair_seq_id,            --1
               catalog_seq_id,           --2
               effective_date,           --3
               repair_price,             --4
               incremental_price_ind,    --5
               repair_tat,               --6
               incremental_tat_ind,      --7
               future_price,             --8
               future_effective_date,    --9
               price_type,               --10
               repair_end_date,          --11
               repair_display_seq_id,    --12
               future_tat,               --13
               price_overwrite_flag_ind, --14
--             active_ind,               --15
               created_by,               --16
               creation_date,            --17
               last_update_date,         --18
               last_updated_by           --19
            -- baseline_tat              --20
            )
            SELECT
               /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - Begin */
               crd_e_repair_catalog_seq.nextval,
               /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - End */
               ecrd_ref_catalog_cur.repair_seq_id, --1
               p_in_catalog_seq_id,          --2
               v_start_date,                 --3
               v_new_price,                  --4
               cerc.incremental_price_ind,   --5
               v_new_tat,		               --6
               cerc.incremental_tat_ind,     --7
               null,                         --8
               null,                         --9
               cerc.price_type,              --10
               null,                         --11
               cerc.repair_display_seq_id,   --12
               null,                         --13
               cerc.price_overwrite_flag_ind,--14
   --            ecrd_utils_pkg.G_ACTIVE,    --15
               p_in_user_id,                 --16
               SYSDATE,                      --17
               SYSDATE,                      --18
               p_in_user_id                  --19
               --cerc.baseline_tat           --20
            FROM
               crd_e_repair_catalog cerc
            WHERE
               cerc.repair_seq_id = ecrd_ref_catalog_cur.repair_seq_id AND
               cerc.catalog_seq_id = v_default_catalog_seq_id AND
               -- PHA 03/09/2005 Added condition.
               (cerc.repair_end_date IS NULL OR trunc(cerc.repair_end_date) > trunc(sysdate));

-- Inserting Child Repairs
            FOR ecrd_ref_child_repair IN eCRD_Child_repair(ecrd_ref_catalog_cur.repair_seq_id)
            LOOP
               SELECT
                  COUNT(1)
               INTO
                  v_child_repair_count
               FROM
                  CRD_E_REPAIR_CATALOG
               WHERE
                  repair_seq_id = ecrd_ref_child_repair.repair_seq_id AND
                  -- PHA 03/09/2005 commented condition.
                  catalog_seq_id = p_in_catalog_seq_id /*AND
                  to_date(effective_date) = to_date(v_start_date) AND
                  repair_end_date IS NULL*/;

               IF(v_child_repair_count = 0)
               THEN
                  INSERT INTO CRD_E_REPAIR_CATALOG
                  (
                     /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - Begin */
                     crd_e_repair_catalog_seq_id,
                     /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - End */
                     repair_seq_id,            --1
                     catalog_seq_id,           --2
                     effective_date,           --3
                     repair_price,             --4
                     incremental_price_ind,    --5
                     repair_tat,               --6
                     incremental_tat_ind,      --7
                     future_price,             --8
                     future_effective_date,    --9
                     price_type,               --10
                     repair_end_date,          --11
                     repair_display_seq_id,    --12
                     future_tat,               --13
                     price_overwrite_flag_ind, --14
      --             active_ind,               --15
                     created_by,               --16
                     creation_date,            --17
                     last_update_date,         --18
                     last_updated_by           --19
                     --baseline_tat            --20
                  )
                  SELECT
                     /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - Begin */
                     crd_e_repair_catalog_seq.nextval,
                     /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - End */
                     ecrd_ref_child_repair.repair_seq_id,   --1
                     p_in_catalog_seq_id,          --2
                     v_start_date,                 --3
                     '',                           --4
                     '',                           --5
                     '',                           --6
                     '',                           --7
                     null,                         --8
                     null,                         --9
                     '',                           --10
                     null,                         --11
                     cerc.repair_display_seq_id,   --12
                     null,                         --13
                     '',                           --14
         --            ecrd_utils_pkg.G_ACTIVE,    --15
                     p_in_user_id,                 --16
                     SYSDATE,                      --17
                     SYSDATE,                      --18
                     p_in_user_id                  --19
                     --cerc.baseline_tat              --20
                  FROM
                     crd_e_repair_catalog cerc
                  WHERE
                     cerc.repair_seq_id = ecrd_ref_child_repair.repair_seq_id AND
                     cerc.catalog_seq_id = v_default_catalog_seq_id
                     -- PHA 03/09/2005 Added condition.
                  AND (cerc.repair_end_date IS NULL OR trunc(cerc.repair_end_date) > trunc(sysdate));
               END IF;
            END LOOP;
         ELSE
--dbms_output.put_line('insert in history');
--                SELECT
--                   COUNT(1)
--                INTO
--                   v_count_in_history
--                FROM
--                   crd_e_repair_catalog_hist
--                WHERE
--                   repair_seq_id = ecrd_ref_catalog_cur.repair_seq_id AND
--                   catalog_seq_id = p_in_catalog_seq_id AND
--                   to_date(effective_date) = to_date(v_start_date) AND
--                   staging_history_ind = ecrd_utils_pkg.G_HISTORY_RECORD AND
--                   TO_DATE(change_start_date) = TO_DATE(SYSDATE);
--
--                IF(v_count_in_history = 0)
--                THEN
--                --Inserting the record in History table.
--    /*             INSERT INTO crd_e_repair_catalog_hist
--                   (
--                      repair_seq_id,             --1
--                      catalog_seq_id,            --2
--                      effective_date,            --3
--                      staging_history_ind,       --4
--                      change_start_date,         --5
--                      repair_price,              --6
--                      incremental_price_ind,     --7
--                      repair_tat,                --8
--                      incremental_tat_ind,       --9
--                      future_price,              --10
--                      future_effective_date,     --11
--                      price_type,                --12
--                      repair_end_date,           --13
--                      future_tat,                --14
--                      repair_display_seq_id,     --15
--                      price_overwrite_flag_ind,  --16
--                      created_by,               --17
--                      creation_date,            --18
--                      last_update_date,         --19
--                      last_updated_by           --20
--                   )
--                   SELECT
--                      repair_seq_id,                   --1
--                      catalog_seq_id,                  --2
--                      effective_date,                  --3
--                      ecrd_utils_pkg.G_HISTORY_RECORD, --4
--                      SYSDATE,                         --5
--                      repair_price,                    --6
--                      incremental_price_ind,           --7
--                      repair_tat,                      --8
--                      incremental_tat_ind,             --9
--                      future_price,                    --10
--                      future_effective_date,           --11
--                      price_type,                      --12
--                      repair_end_date,                 --13
--                      future_tat,                      --14
--                      repair_display_seq_id,           --15
--                      price_overwrite_flag_ind,        --16
--                      p_in_user_id,                    --17
--                      SYSDATE,                         --18
--                      SYSDATE,                         --19
--                      p_in_user_id                     --20
--                   FROM
--                      crd_e_repair_catalog
--                   WHERE
--                      repair_seq_id = ecrd_ref_catalog_cur.repair_seq_id AND
--                      catalog_seq_id = p_in_catalog_seq_id AND
--                      to_date(effective_date) = to_date(v_start_date);
--                END IF;
               --Updating the new Price and updating repair end date to null

--Repair TAT commented by RR on 6th April for Apply TAT at Customer Level req
            UPDATE crd_e_repair_catalog cerc
            SET
               repair_price = v_new_price,
               repair_tat = v_new_tat,
               repair_end_date = NULL,
               last_update_date = SYSDATE,
               last_updated_by = p_in_user_id,
               -- PHA update effective_date
               effective_date = v_start_date
            WHERE
               repair_seq_id = ecrd_ref_catalog_cur.repair_seq_id AND
               -- PHA 03/09/2005 commented condition.
               catalog_seq_id = p_in_catalog_seq_id /*AND
               to_date(effective_date) = to_date(v_start_date)*/
               AND trunc(effective_date) = ( select trunc(max(effective_date))
                                                from crd_e_repair_catalog
                                                where repair_seq_id = ecrd_ref_catalog_cur.repair_seq_id
                                                AND catalog_seq_id = p_in_catalog_seq_id);

            --updating all the child repair for this repair if it is a parent repair.
            FOR ecrd_ref_child_repair IN eCRD_Child_repair(ecrd_ref_catalog_cur.repair_seq_id)
            LOOP
               --updating the repair catalog table for the child repair seting repair end date to null.
               UPDATE crd_e_repair_catalog
               SET
                  repair_end_date = NULL,
                  -- PHA update last update fields
                  last_update_date = SYSDATE,
                  last_updated_by = p_in_user_id,
                  -- PHA update effective_date
                  effective_date = v_start_date
               WHERE
                  repair_seq_id = ecrd_ref_child_repair.repair_seq_id AND
                  -- PHA 03/09/2005 commented condition.
                  catalog_seq_id = p_in_catalog_seq_id /*AND
                  to_date(effective_date) = to_date(v_start_date)*/
                  AND trunc(effective_date) = ( select trunc(max(effective_date))
                                                from crd_e_repair_catalog
                                                where repair_seq_id = ecrd_ref_child_repair.repair_seq_id
                                                AND catalog_seq_id = p_in_catalog_seq_id);
            END LOOP;
         END IF;
   dbms_output.put_line('out of If');
--         END LOOP;
      END LOOP;
   END IF;

v_n_step := 5;

-- Inserting the repair for customer catalog and applying Module level rules if present
   IF(v_module_count > 0)
   THEN
      FOR ecrd_ref_module_cur IN eCRD_module_rules
      LOOP
        --Patni 24/02/2006 - Begin - Rule should be applied only for the current year
        IF(ecrd_ref_module_cur.year = v_year) THEN
        --Patni 24/02/2006 - End - Rule should be applied only for the current year

        --Getting the base price from the default catalog
           BEGIN
              SELECT
                 repair_price,
                 repair_tat
              INTO
                 v_price,
                 v_tat
              FROM
                 crd_e_repair_catalog
              WHERE
                 catalog_seq_id = v_default_catalog_seq_id AND
                 repair_seq_id = ecrd_ref_module_cur.repair_seq_id
                 -- PHA 03/09/2005 Added condition.
              AND (repair_end_date IS NULL OR trunc(repair_end_date) > trunc(SYSDATE));
  --
              EXCEPTION
              WHEN NO_DATA_FOUND
              THEN
                 v_price := 0;

                 --Patni 24/02/2006 - Begin - Setting TAT to 0, if no data is found
                 v_tat   := 0;
                 --Patni 24/02/2006 - End - Setting TAT to 0, if no data is found
           END;
           v_in_n_step := 1;
        -- Calculating the new Price for customer catalog.

           --Patni 24/02/2006 - Begin - Initializing the variables
           v_new_price := NULL;
           v_new_tat   := NULL;
           --Patni 24/02/2006 - End - Initializing the variables

           IF(ecrd_ref_module_cur.year = v_year AND v_flag = 'Y')
           THEN
          -- Patni 05/05/2006 - Begin - To put 0% discount when discount is Blank
            v_rule_discount := NVL(ecrd_ref_module_cur.discount,0);
            v_rule_tat   := ecrd_ref_module_cur.tat;
          -- Patni 05/05/2006 - End - To put 0% discount when discount is Blank
              v_new_price := (v_price - (v_price * (v_rule_discount/100)));
              v_new_tat :=  v_rule_tat;
           ELSE
              v_new_price := v_price;
              v_new_tat := v_tat;
           END IF;
          IF(v_new_tat IS NULL)
           THEN
              v_new_tat := v_tat;
           END IF;

           v_in_n_step := 2;

           SELECT
              COUNT(1)
           INTO
              v_existing_count
           FROM
              CRD_E_REPAIR_CATALOG
           WHERE
               repair_seq_id = ecrd_ref_module_cur.repair_seq_id AND
               -- PHA 03/09/2005 commented condition.
              catalog_seq_id = p_in_catalog_seq_id /*AND
              to_date(effective_date) = to_date(v_start_date);
              AND repair_end_date IS NULL*/;


           v_in_n_step := 3;

  dbms_output.put_line('ecrd_ref_module_cur.repair_seq_id--'||ecrd_ref_module_cur.repair_seq_id);

           IF(v_existing_count = 0)
           THEN
           v_in_n_step := 3.1;

  -- Repair TAT populated with '' for Apply TAT at Component Level by RR on 6th April
              INSERT INTO CRD_E_REPAIR_CATALOG
              (
                 /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - Begin */
                 crd_e_repair_catalog_seq_id,
                 /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - End */
                 repair_seq_id,            --1
                 catalog_seq_id,           --2
                 effective_date,           --3
                 repair_price,             --4
                 incremental_price_ind,    --5
                 repair_tat,               --6
                 incremental_tat_ind,      --7
                 future_price,             --8
                 future_effective_date,    --9
                 price_type,               --10
                 repair_end_date,          --11
                 repair_display_seq_id,    --12
                 future_tat,               --13
                 price_overwrite_flag_ind, --14
  --             active_ind,               --15
                 created_by,               --16
                 creation_date,            --17
                 last_update_date,         --18
                 last_updated_by           --19
        --       baseline_tat              --20
              )
              SELECT
                 /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - Begin */
                 crd_e_repair_catalog_seq.nextval,
                 /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - End */
                 ecrd_ref_module_cur.repair_seq_id,  --1
                 TO_NUMBER(p_in_catalog_seq_id),--2
                 v_start_date,                 --3
                 v_new_price,                  --4
                 cerc.incremental_price_ind,   --5
                 v_new_tat,		               --6
                 cerc.incremental_tat_ind,     --7
                 null,                         --8
                 null,                         --9
                 cerc.price_type,              --10
                 null,                         --11
                 cerc.repair_display_seq_id,   --12
                 null,                         --13
                 cerc.price_overwrite_flag_ind,--14
  --             ecrd_utils_pkg.G_ACTIVE,      --15
                 p_in_user_id,                 --16
                 SYSDATE,                      --17
                 SYSDATE,                      --18
                 p_in_user_id                  --19
                 --cerc.baseline_tat              --20
              FROM
                 crd_e_repair_catalog cerc
              WHERE
                 cerc.repair_seq_id = ecrd_ref_module_cur.repair_seq_id AND
                 cerc.catalog_seq_id = v_default_catalog_seq_id
                 -- PHA 03/09/2005 Added condition.
              AND (cerc.repair_end_date IS NULL OR trunc(cerc.repair_end_date) > trunc(sysdate));

  -- Inserting Child Repairs
              FOR ecrd_ref_child_repair IN eCRD_Child_repair(ecrd_ref_module_cur.repair_seq_id)
              LOOP
                 SELECT
                    COUNT(1)
                 INTO
                    v_child_repair_count
                 FROM
                    CRD_E_REPAIR_CATALOG
                 WHERE
                    repair_seq_id = ecrd_ref_child_repair.repair_seq_id AND
                    -- PHA 03/09/2005 commented condition.
                    catalog_seq_id = p_in_catalog_seq_id /*AND
                    to_date(effective_date) = to_date(v_start_date) AND
                    repair_end_date IS NULL*/;

                 IF(v_child_repair_count = 0)
                 THEN
                    INSERT INTO CRD_E_REPAIR_CATALOG
                    (
                       /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - Begin */
                       crd_e_repair_catalog_seq_id,
                       /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - End */
                       repair_seq_id,            --1
                       catalog_seq_id,           --2
                       effective_date,           --3
                       repair_price,             --4
                       incremental_price_ind,    --5
                       repair_tat,               --6
                       incremental_tat_ind,      --7
                       future_price,             --8
                       future_effective_date,    --9
                       price_type,               --10
                       repair_end_date,          --11
                       repair_display_seq_id,    --12
                       future_tat,               --13
                       price_overwrite_flag_ind, --14
        --             active_ind,               --15
                       created_by,               --16
                       creation_date,            --17
                       last_update_date,         --18
                       last_updated_by           --19
                       --baseline_tat            --20
                    )
                    SELECT
                       /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - Begin */
                       crd_e_repair_catalog_seq.nextval,
                       /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - End */
                       ecrd_ref_child_repair.repair_seq_id,   --1
                       p_in_catalog_seq_id,          --2
                       v_start_date,                 --3
                       '',                           --4
                       '',                           --5
                       '',                           --6
                       '',                           --7
                       null,                         --8
                       null,                         --9
                       '',                           --10
                       null,                         --11
                       cerc.repair_display_seq_id,   --12
                       null,                         --13
                       '',                           --14
           --            ecrd_utils_pkg.G_ACTIVE,    --15
                       p_in_user_id,                 --16
                       SYSDATE,                      --17
                       SYSDATE,                      --18
                       p_in_user_id                  --19
                       --cerc.baseline_tat              --20
                    FROM
                       crd_e_repair_catalog cerc
                    WHERE
                       cerc.repair_seq_id = ecrd_ref_child_repair.repair_seq_id AND
                       cerc.catalog_seq_id = v_default_catalog_seq_id
                       -- PHA 03/09/2005 Added condition
                    AND (cerc.repair_end_date IS NULL OR trunc(cerc.repair_end_date) > trunc(sysdate));
                 END IF;
              END LOOP;
           ELSE
  --             SELECT
  --                COUNT(1)
  --             INTO
  --                v_count_in_history
  --             FROM
  --                crd_e_repair_catalog_hist
  --             WHERE
  --                repair_seq_id = ecrd_ref_module_cur.repair_seq_id AND
  --                catalog_seq_id = p_in_catalog_seq_id AND
  --                to_date(effective_date) = to_date(v_start_date) AND
  --                staging_history_ind = ecrd_utils_pkg.G_HISTORY_RECORD AND
  --                TO_DATE(change_start_date) = TO_DATE(SYSDATE);
  --
  --             IF(v_count_in_history = 0)
  --             THEN
  --              --Inserting the record in History table.
  --                INSERT INTO crd_e_repair_catalog_hist
  --                (
  --                   repair_seq_id,             --1
  --                   catalog_seq_id,            --2
  --                   effective_date,            --3
  --                   staging_history_ind,       --4
  --                   change_start_date,         --5
  --                   repair_price,              --6
  --                   incremental_price_ind,     --7
  --                   repair_tat,                --8
  --                   incremental_tat_ind,       --9
  --                   future_price,              --10
  --                   future_effective_date,     --11
  --                   price_type,                --12
  --                   repair_end_date,           --13
  --                   future_tat,                --14
  --                   repair_display_seq_id,     --15
  --                   price_overwrite_flag_ind,  --16
  --                   created_by,               --17
  --                   creation_date,            --18
  --                   last_update_date,         --19
  --                   last_updated_by           --20
  --                 )
  --                 SELECT
  --                   repair_seq_id,                   --1
  --                   catalog_seq_id,                  --2
  --                   effective_date,                  --3
  --                   ecrd_utils_pkg.G_HISTORY_RECORD, --4
  --                   SYSDATE,                         --5
  --                   repair_price,                    --6
  --                   incremental_price_ind,           --7
  --                   repair_tat,                      --8
  --                   incremental_tat_ind,             --9
  --                   future_price,                    --10
  --                   future_effective_date,           --11
  --                   price_type,                      --12
  --                   repair_end_date,                 --13
  --                   future_tat,                      --14
  --                   repair_display_seq_id,           --15
  --                   price_overwrite_flag_ind,        --16
  --                   p_in_user_id,                    --17
  --                   SYSDATE,                         --18
  --                   SYSDATE,                         --19
  --                   p_in_user_id                     --20
  --                 FROM
  --                   crd_e_repair_catalog
  --                 WHERE
  --                   repair_seq_id = ecrd_ref_module_cur.repair_seq_id AND
  --                   catalog_seq_id = p_in_catalog_seq_id AND
  --                   to_date(effective_date) = to_date(v_start_date);
  --              END IF;
                  --Updating the new Price and updating repair end date to null

  --Repair TAT commented by RR on 6th April for Apply TAT at Customer Level req
               UPDATE crd_e_repair_catalog cerc
               SET
                 repair_price = v_new_price,
                 repair_tat = v_new_tat,
                 repair_end_date = NULL,
                 last_update_date = SYSDATE,
                 last_updated_by = p_in_user_id,
                 -- PHA update effective_date
                 effective_date = v_start_date
               WHERE
                 repair_seq_id = ecrd_ref_module_cur.repair_seq_id AND
                 -- PHA 03/09/2005 commented condition.
                 catalog_seq_id = p_in_catalog_seq_id /*AND
                 to_date(effective_date) = to_date(v_start_date)*/
                 AND trunc(effective_date) = ( select trunc(max(effective_date))
                                                     from crd_e_repair_catalog
                                                     where repair_seq_id = ecrd_ref_module_cur.repair_seq_id
                                                     AND catalog_seq_id = p_in_catalog_seq_id)
  ;

               --updating all the child repair for this repair if it is a parent repair.
               FOR ecrd_ref_child_repair IN eCRD_Child_repair(ecrd_ref_module_cur.repair_seq_id)
               LOOP
                  --updating the repair catalog table for the child repair seting repair end date to null.
                  UPDATE crd_e_repair_catalog
                  SET
                    repair_end_date = NULL,
                    -- PHA update last update fields
                    last_update_date = SYSDATE,
                    last_updated_by = p_in_user_id,
                    -- PHA update effective_date
                    effective_date = v_start_date
                  WHERE
                    repair_seq_id = ecrd_ref_child_repair.repair_seq_id AND
                    -- PHA 03/09/2005 commented condition.
                    catalog_seq_id = p_in_catalog_seq_id /*AND
                    to_date(effective_date) = to_date(v_start_date)*/
                    AND trunc(effective_date) = ( select trunc(max(effective_date))
                                                     from crd_e_repair_catalog
                                                     where repair_seq_id = ecrd_ref_child_repair.repair_seq_id
                                                     AND catalog_seq_id = p_in_catalog_seq_id);
               END LOOP;
           END IF;
           v_in_n_step := 4;

         --Patni 24/02/2006 - Begin - Rule should be applied only for the current year
         END IF;
         --Patni 24/02/2006 - End - Rule should be applied only for the current year

      END LOOP;
   END IF;
v_n_step := 6;

-- Inserting the repair for customer catalog and applying Component level rules if present
   IF(v_component_count > 0)
   THEN
      FOR ecrd_ref_component_cur IN eCRD_component_rules
      LOOP
         --Patni 24/02/2006 - Begin - Rule should be applied only for the current year
         IF(ecrd_ref_component_cur.year = v_year) THEN
         --Patni 24/02/2006 - End - Rule should be applied only for the current year

        --Getting the base price from the default catalog
           BEGIN
              SELECT
                 repair_price,
                 repair_tat
              INTO
                 v_price,
                 v_tat
              FROM
                 crd_e_repair_catalog
              WHERE
                 catalog_seq_id = v_default_catalog_seq_id
                 -- PHA 03/09/2005 Added condition for end date greater than sysdate
                 AND repair_seq_id = ecrd_ref_component_cur.repair_seq_id
                 AND (repair_end_date IS NULL OR trunc(repair_end_date) > trunc(SYSDATE));
              EXCEPTION
              WHEN NO_DATA_FOUND
              THEN
                 v_price := 0;

                 --Patni 24/02/2006 - Begin - Setting TAT to 0, if no data is found
                 v_tat   := 0;
                 --Patni 24/02/2006 - End - Setting TAT to 0, if no data is found
           END;
        -- Calculating the new Price for customer catalog.
        -- Patni 05/05/2006 - Begin - To put 0% discount when discount is Blank
                 v_rule_discount := NVL(ecrd_ref_component_cur.discount,0);
                 v_rule_tat   := ecrd_ref_component_cur.tat;
        -- Patni 05/05/2006 - End - To put 0% discount when discount is Blank
          --Patni 24/02/2006 - Begin - Initializing the variables
           v_new_price := NULL;
           v_new_tat   := NULL;
           --Patni 24/02/2006 - End - Initializing the variables

           IF(ecrd_ref_component_cur.year = v_year AND v_flag = 'Y')
           THEN
              v_new_price := (v_price - (v_price * (v_rule_discount/100)));
              v_new_tat :=  v_rule_tat;
           ELSE
              v_new_price := v_price;
              v_new_tat := v_tat;
           END IF;

           IF(v_new_tat IS NULL)
           THEN
              v_new_tat := v_tat;
           END IF;

           SELECT
              COUNT(1)
           INTO
              v_existing_count
           FROM
              CRD_E_REPAIR_CATALOG
           WHERE
              repair_seq_id = ecrd_ref_component_cur.repair_seq_id AND
              -- PHA 03/09/2005 Commenting the check. Effective date cannot be start date.
              catalog_seq_id = p_in_catalog_seq_id /*AND
               to_date(effective_date) = to_date(v_start_date)*/;
           --AND repair_end_date IS NULL;

  dbms_output.put_line('ecrd_ref_component_cur.repair_seq_id--'||ecrd_ref_component_cur.repair_seq_id);
           IF(v_existing_count = 0)
           THEN
  -- Repair TAT populated with '' for Apply TAT at Component Level by RR on 6th April
              INSERT INTO CRD_E_REPAIR_CATALOG
              (
                 /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - Begin */
                 crd_e_repair_catalog_seq_id,
                 /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - End */
                 repair_seq_id,            --1
                 catalog_seq_id,           --2
                 effective_date,           --3
                 repair_price,             --4
                 incremental_price_ind,    --5
                 repair_tat,               --6
                 incremental_tat_ind,      --7
                 future_price,             --8
                 future_effective_date,    --9
                 price_type,               --10
                 repair_end_date,          --11
                 repair_display_seq_id,    --12
                 future_tat,               --13
                 price_overwrite_flag_ind, --14
  --             active_ind,               --15
                 created_by,               --16
                 creation_date,            --17
                 last_update_date,         --18
                 last_updated_by           --19
           --    baseline_tat              --20
              )
              SELECT
                 /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - Begin */
                 crd_e_repair_catalog_seq.nextval,
                 /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - End */
                 ecrd_ref_component_cur.repair_seq_id,  --1
                 p_in_catalog_seq_id,          --2
                 v_start_date,                 --3
                 v_new_price,                  --4
                 cerc.incremental_price_ind,   --5
                 v_new_tat,		               --6
                 cerc.incremental_tat_ind,     --7
                 null,                         --8
                 null,                         --9
                 cerc.price_type,              --10
                 null,                         --11
                 cerc.repair_display_seq_id,   --12
                 null,                         --13
                 cerc.price_overwrite_flag_ind,--14
     --            ecrd_utils_pkg.G_ACTIVE,    --15
                 p_in_user_id,                 --16
                 SYSDATE,                      --17
                 SYSDATE,                      --18
                 p_in_user_id                  --19
                 --cerc.baseline_tat           --20
              FROM
                 crd_e_repair_catalog cerc
              WHERE
                 cerc.repair_seq_id = ecrd_ref_component_cur.repair_seq_id AND
                 cerc.catalog_seq_id = v_default_catalog_seq_id
                 -- PHA 03/09/2005 Added condition for end date greater than sysdate
               AND (cerc.repair_end_date IS NULL OR trunc(cerc.repair_end_date) > trunc(sysdate));
  --
  -- Inserting Child Repairs
              FOR ecrd_ref_child_repair IN eCRD_Child_repair(ecrd_ref_component_cur.repair_seq_id)
              LOOP
                 SELECT
                    COUNT(1)
                 INTO
                    v_child_repair_count
                 FROM
                    CRD_E_REPAIR_CATALOG
                 WHERE
                    repair_seq_id = ecrd_ref_child_repair.repair_seq_id AND
                    -- PHA 03/09/2005 Commenting the check. Effective date cannot be start date.
                    catalog_seq_id = p_in_catalog_seq_id /*AND
                    to_date(effective_date) = to_date(v_start_date) AND
                    repair_end_date IS NULL*/;

                 IF(v_child_repair_count = 0)
                 THEN
                    INSERT INTO CRD_E_REPAIR_CATALOG
                    (
                       /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - Begin */
                       crd_e_repair_catalog_seq_id,
                       /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - End */
                       repair_seq_id,            --1
                       catalog_seq_id,           --2
                       effective_date,           --3
                       repair_price,             --4
                       incremental_price_ind,    --5
                       repair_tat,               --6
                       incremental_tat_ind,      --7
                       future_price,             --8
                       future_effective_date,    --9
                       price_type,               --10
                       repair_end_date,          --11
                       repair_display_seq_id,    --12
                       future_tat,               --13
                       price_overwrite_flag_ind, --14
        --             active_ind,               --15
                       created_by,               --16
                       creation_date,            --17
                       last_update_date,         --18
                       last_updated_by           --19
                       --baseline_tat            --20
                    )
                    SELECT
                       /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - Begin */
                       crd_e_repair_catalog_seq.nextval,
                       /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - End */
                       ecrd_ref_child_repair.repair_seq_id,   --1
                       p_in_catalog_seq_id,          --2
                       v_start_date,                 --3
                       '',                           --4
                       '',                           --5
                       '',                           --6
                       '',                           --7
                       null,                         --8
                       null,                         --9
                       '',                           --10
                       null,                         --11
                       cerc.repair_display_seq_id,   --12
                       null,                         --13
                       '',                           --14
           --            ecrd_utils_pkg.G_ACTIVE,    --15
                       p_in_user_id,                 --16
                       SYSDATE,                      --17
                       SYSDATE,                      --18
                       p_in_user_id                  --19
                       --cerc.baseline_tat              --20
                    FROM
                       crd_e_repair_catalog cerc
                    WHERE
                       cerc.repair_seq_id = ecrd_ref_child_repair.repair_seq_id AND
                       cerc.catalog_seq_id = v_default_catalog_seq_id
                       -- PHA 03/09/2005 Added condition for greater than sysdate
                    AND (cerc.repair_end_date IS NULL OR trunc(cerc.repair_end_date) > trunc(sysdate));
                 END IF;
              END LOOP;
           ELSE
  --             SELECT
  --                COUNT(1)
  --             INTO
  --                v_count_in_history
  --             FROM
  --                crd_e_repair_catalog_hist
  --             WHERE
  --                repair_seq_id = ecrd_ref_component_cur.repair_seq_id AND
  --             catalog_seq_id = p_in_catalog_seq_id AND
  --                to_date(effective_date) = to_date(v_start_date) AND
  --                staging_history_ind = ecrd_utils_pkg.G_HISTORY_RECORD AND
  --                TO_DATE(change_start_date) = TO_DATE(SYSDATE);
  --
  --             IF(v_count_in_history = 0)
  --             THEN
  --              --Inserting the record in History table.
  --                INSERT INTO crd_e_repair_catalog_hist
  --                (
  --                   repair_seq_id,             --1
  --                   catalog_seq_id,            --2
  --                   effective_date,            --3
  --                   staging_history_ind,       --4
  --                   change_start_date,         --5
  --                   repair_price,              --6
  --                   incremental_price_ind,     --7
  --                   repair_tat,                --8
  --                   incremental_tat_ind,       --9
  --                   future_price,              --10
  --                   future_effective_date,     --11
  --                   price_type,                --12
  --                   repair_end_date,           --13
  --                   future_tat,                --14
  --                   repair_display_seq_id,     --15
  --                   price_overwrite_flag_ind,  --16
  --                   created_by,               --17
  --                   creation_date,            --18
  --                   last_update_date,         --19
  --                   last_updated_by           --20
  --                 )
  --                 SELECT
  --                   repair_seq_id,                   --1
  --                   catalog_seq_id,                  --2
  --                   effective_date,                  --3
  --                   ecrd_utils_pkg.G_HISTORY_RECORD, --4
  --                   SYSDATE,                         --5
  --                   repair_price,                    --6
  --                   incremental_price_ind,           --7
  --                   repair_tat,                      --8
  --                   incremental_tat_ind,             --9
  --                   future_price,                    --10
  --                   future_effective_date,           --11
  --                   price_type,                      --12
  --                   repair_end_date,                 --13
  --                   future_tat,                      --14
  --                   repair_display_seq_id,           --15
  --                   price_overwrite_flag_ind,        --16
  --                   p_in_user_id,                    --17
  --                   SYSDATE,                         --18
  --                   SYSDATE,                         --19
  --                   p_in_user_id                     --20
  --                 FROM
  --                   crd_e_repair_catalog
  --                 WHERE
  --                   repair_seq_id = ecrd_ref_component_cur.repair_seq_id AND
  --                   catalog_seq_id = p_in_catalog_seq_id AND
  --                   to_date(effective_date) = to_date(v_start_date);
  --              END IF;
                  --Updating the new Price and updating repair end date to null

  --Repair TAT commented by RR on 6th April for Apply TAT at Customer Level req
               UPDATE crd_e_repair_catalog cerc
               SET
                 repair_price = v_new_price,
                 repair_tat = v_new_tat,
                 repair_end_date = NULL,
                 last_update_date = SYSDATE,
                 last_updated_by = p_in_user_id,
                 -- PHA update effective_date
                 effective_date = v_start_date
               WHERE
                 repair_seq_id = ecrd_ref_component_cur.repair_seq_id AND
                 -- PHA 03/09/2005 Commenting the check. Effective date cannot be start date.
                 catalog_seq_id = p_in_catalog_seq_id /*AND
                 to_date(effective_date) = to_date(v_start_date)*/
                 AND trunc(effective_date) = ( select trunc(max(effective_date))
                                                     from crd_e_repair_catalog
                                                     where repair_seq_id = ecrd_ref_component_cur.repair_seq_id
                                                     AND catalog_seq_id = p_in_catalog_seq_id)
  ;

               --updating all the child repair for this repair if it is a parent repair.
               FOR ecrd_ref_child_repair IN eCRD_Child_repair(ecrd_ref_component_cur.repair_seq_id)
               LOOP
                  --updating the repair catalog table for the child repair seting repair end date to null.
                  UPDATE crd_e_repair_catalog
                  SET
                    repair_end_date = NULL,
                    -- PHA update last update fields
                    last_update_date = SYSDATE,
                    last_updated_by = p_in_user_id,
                    -- PHA update effective_date
                    effective_date = v_start_date
                  WHERE
                    repair_seq_id = ecrd_ref_child_repair.repair_seq_id AND
                    -- PHA 03/09/2005 Commenting the check. Effective date cannot be start date.
                    catalog_seq_id = p_in_catalog_seq_id /*AND
                    to_date(effective_date) = to_date(v_start_date)*/
                    AND trunc(effective_date) = ( select trunc(max(effective_date))
                                                     from crd_e_repair_catalog
                                                     where repair_seq_id = ecrd_ref_child_repair.repair_seq_id
                                                     AND catalog_seq_id = p_in_catalog_seq_id)
  ;
               END LOOP;
           END IF;

         --Patni 24/02/2006 - Begin - Rule should be applied only for the current year
         END IF;
         --Patni 24/02/2006 - End - Rule should be applied only for the current year

      END LOOP;
   END IF;
v_n_step := 7;
-- Inserting the repair for customer catalog and applying repair level rules if present
   IF(v_repair_count > 0)
   THEN
      FOR ecrd_ref_repair_cur IN eCRD_repair_rules
      LOOP
         --Patni 24/02/2006 - Begin - Rule should be applied only for the current year
         IF(ecrd_ref_repair_cur.year = v_year) THEN
         --Patni 24/02/2006 - End - Rule should be applied only for the current year

        --Getting the base price from the default catalog
           BEGIN
              SELECT
                 repair_price,
                 repair_tat
              INTO
                 v_price,
                 v_tat
              FROM
                 crd_e_repair_catalog
              WHERE
                 catalog_seq_id = v_default_catalog_seq_id AND
                 repair_seq_id = ecrd_ref_repair_cur.repair_seq_id
                 -- PHA 03/09/2005 Added condition
                 AND (repair_end_date IS NULL OR trunc(repair_end_date) > trunc(SYSDATE));
              EXCEPTION
              WHEN NO_DATA_FOUND
              THEN
                 v_price := 0;
                 v_tat := 0;
           END;
           dbms_output.put_line('v_price***'||v_price);
           dbms_output.put_line('v_tat***'||v_tat);
           -- Calculating the new Price for customer catalog.
           -- Patni 05/05/2006 - Begin - To put 0% discount when discount is Blank
           -- Patni 30/05/2006 - Begin - Defect #66
             /* BEGIN
              SELECT
                    NVL(discount,0),
                     tat
               INTO
               v_rule_discount,
               v_rule_tat
               FROM
                   crd_e_contracted_repair
               WHERE
                    catalog_seq_id = p_in_catalog_seq_id AND
                 repair_seq_id = ecrd_ref_repair_cur.repair_seq_id;
              EXCEPTION
               WHEN NO_DATA_FOUND
               THEN
                v_rule_discount := 0;
                 v_rule_tat   := 0;
                 END;*/
                 v_rule_discount := NVL(ecrd_ref_repair_cur.discount,0);
                 v_rule_tat   := NVL(ecrd_ref_repair_cur.tat,0);
             -- Patni 30/05/2006 - End - Defect #66
          -- Patni 05/05/2006 - End - To put 0% discount when discount is Blank
          --Patni 24/02/2006 - Begin - Initializing the variables
           v_new_price := NULL;
           v_new_tat   := NULL;
           --Patni 24/02/2006 - End - Initializing the variables

           IF(ecrd_ref_repair_cur.year = v_year AND v_flag = 'Y')
           THEN
              v_new_price := (v_price - (v_price * (v_rule_discount/100)));
              v_new_tat :=  v_rule_tat;
           ELSE
              v_new_price := v_price;
              v_new_tat := v_tat;
           END IF;

           IF(v_new_tat IS NULL)
           THEN
              v_new_tat := v_tat;
           END IF;
           dbms_output.put_line('v_new_price***'||v_new_price);
           dbms_output.put_line('v_new_tat***'||v_new_tat);
           SELECT
              COUNT(1)
           INTO
              v_existing_count
           FROM
              CRD_E_REPAIR_CATALOG
           WHERE
              repair_seq_id = ecrd_ref_repair_cur.repair_seq_id AND
              -- PHA 03/09/2005 Commenting the check. Effective date cannot be start date.
              catalog_seq_id = p_in_catalog_seq_id /*AND
              to_date(effective_date) = to_date(v_start_date) AND
              repair_end_date IS NULL*/;

           IF(v_existing_count = 0)
           THEN

  -- Repair TAT changes made for Apply TAT at Component Level by RR on 6th April
  -- Following req undone i.e if Incremental TAT is Y then store TAT as 0..
  -- This change is undone and now Default/Rule level TAT will be
  -- stored while copying repairs for which repair level rule is applied.
              INSERT INTO CRD_E_REPAIR_CATALOG
              (
                 /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - Begin */
                 crd_e_repair_catalog_seq_id,
                 /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - End */
                 repair_seq_id,            --1
                 catalog_seq_id,           --2
                 effective_date,           --3
                 repair_price,             --4
                 incremental_price_ind,    --5
                 repair_tat,               --6
                 incremental_tat_ind,      --7
                 future_price,             --8
                 future_effective_date,    --9
                 price_type,               --10
                 repair_end_date,          --11
                 repair_display_seq_id,    --12
                 future_tat,               --13
                 price_overwrite_flag_ind, --14
  --             active_ind,               --15
                 created_by,               --16
                 creation_date,            --17
                 last_update_date,         --18
                 last_updated_by           --19
                 --baseline_tat            --20
              )
              SELECT
                 /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - Begin */
                 crd_e_repair_catalog_seq.nextval,
                 /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - End */
                 ecrd_ref_repair_cur.repair_seq_id,  --1
                 p_in_catalog_seq_id,          --2
                 v_start_date,                 --3
                 v_new_price,                  --4
                 cerc.incremental_price_ind,   --5
                 v_new_tat,     					--6
                 cerc.incremental_tat_ind,     --7
                 null,                         --8
                 null,                         --9
                 cerc.price_type,              --10
                 null,                         --11
                 cerc.repair_display_seq_id,   --12
                 null,                         --13
                 cerc.price_overwrite_flag_ind,--14
     --            ecrd_utils_pkg.G_ACTIVE,    --15
                 p_in_user_id,                 --16
                 SYSDATE,                      --17
                 SYSDATE,                      --18
                 p_in_user_id                  --19
                 --cerc.baseline_tat              --20
              FROM
                 crd_e_repair_catalog cerc
              WHERE
                 cerc.repair_seq_id = ecrd_ref_repair_cur.repair_seq_id AND
                 cerc.catalog_seq_id = v_default_catalog_seq_id
                 -- PHA 03/09/2005 adding condition for greater than sysdate
              AND (cerc.repair_end_date IS NULL OR trunc(cerc.repair_end_date) > trunc(sysdate));
  --

  -- Inserting Child Repairs
              FOR ecrd_ref_child_repair IN eCRD_Child_repair(ecrd_ref_repair_cur.repair_seq_id)
              LOOP
                 SELECT
                    COUNT(1)
                 INTO
                    v_child_repair_count
                 FROM
                    CRD_E_REPAIR_CATALOG
                 WHERE
                    repair_seq_id = ecrd_ref_child_repair.repair_seq_id AND
                    -- PHA 03/09/2005 Commenting the check. Effective date cannot be start date.
                    catalog_seq_id = p_in_catalog_seq_id /*AND
                    to_date(effective_date) = to_date(v_start_date) AND
                    repair_end_date IS NULL*/;

                 IF(v_child_repair_count = 0)
                 THEN
  --dbms_output.put_line('inserting child repairs count is zero so inserting......');
                    INSERT INTO CRD_E_REPAIR_CATALOG
                    (
                       /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - Begin */
                       crd_e_repair_catalog_seq_id,
                       /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - End */
                       repair_seq_id,            --1
                       catalog_seq_id,           --2
                       effective_date,           --3
                       repair_price,             --4
                       incremental_price_ind,    --5
                       repair_tat,               --6
                       incremental_tat_ind,      --7
                       future_price,             --8
                       future_effective_date,    --9
                       price_type,               --10
                       repair_end_date,          --11
                       repair_display_seq_id,    --12
                       future_tat,               --13
                       price_overwrite_flag_ind, --14
        --             active_ind,               --15
                       created_by,               --16
                       creation_date,            --17
                       last_update_date,         --18
                       last_updated_by           --19
                       --baseline_tat            --20
                    )
                    SELECT
                       /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - Begin */
                       crd_e_repair_catalog_seq.nextval,
                       /* Patni 05-Sep-2006 - Included CRD_E_REPAIR_CATALOG_SEQ_ID - End */
                       ecrd_ref_child_repair.repair_seq_id,   --1
                       p_in_catalog_seq_id,          --2
                       v_start_date,                 --3
                       '',                           --4
                       '',                           --5
                       '',                           --6
                       '',                           --7
                       null,                         --8
                       null,                         --9
                       '',                           --10
                       null,                         --11
                       cerc.repair_display_seq_id,   --12
                       null,                         --13
                       '',                           --14
           --            ecrd_utils_pkg.G_ACTIVE,    --15
                       p_in_user_id,                 --16
                       SYSDATE,                      --17
                       SYSDATE,                      --18
                       p_in_user_id                  --19
                       --cerc.baseline_tat              --20
                    FROM
                       crd_e_repair_catalog cerc
                    WHERE
                    -- PHA 03/09/2005 Changing condition
                       cerc.repair_seq_id = ecrd_ref_child_repair.repair_seq_id
                       AND cerc.catalog_seq_id = v_default_catalog_seq_id
                    AND (cerc.repair_end_date IS NULL OR trunc(cerc.repair_end_date) > trunc(sysdate));


                 END IF;
              END LOOP;
           ELSE
--  dbms_output.put_line('in else so moving the record to history');
  --             SELECT
  --                COUNT(1)
  --             INTO
  --                v_count_in_history
  --             FROM
  --                crd_e_repair_catalog_hist
  --             WHERE
  --                repair_seq_id = ecrd_ref_repair_cur.repair_seq_id AND
  --             catalog_seq_id = p_in_catalog_seq_id AND
  --                to_date(effective_date) = to_date(v_start_date) AND
  --                staging_history_ind = ecrd_utils_pkg.G_HISTORY_RECORD AND
  --                TO_DATE(change_start_date) = TO_DATE(SYSDATE);
  --
  --             IF(v_count_in_history = 0)
  --             THEN
  --           --Inserting the record in History table.
  --                INSERT INTO crd_e_repair_catalog_hist
  --                (
  --                   repair_seq_id,             --1
  --                   catalog_seq_id,            --2
  --                   effective_date,            --3
  --                   staging_history_ind,       --4
  --                   change_start_date,         --5
  --                   repair_price,              --6
  --                   incremental_price_ind,     --7
  --                   repair_tat,                --8
  --                   incremental_tat_ind,       --9
  --                   future_price,              --10
  --                   future_effective_date,     --11
  --                   price_type,                --12
  --                   repair_end_date,           --13
  --                   future_tat,                --14
  --                   repair_display_seq_id,     --15
  --                   price_overwrite_flag_ind,  --16
  --                   created_by,               --17
  --                   creation_date,            --18
  --                   last_update_date,         --19
  --                   last_updated_by           --20
  --                 )
  --                 SELECT
  --                   repair_seq_id,                   --1
  --                   catalog_seq_id,                  --2
  --                   effective_date,                  --3
  --                   ecrd_utils_pkg.G_HISTORY_RECORD, --4
  --                   SYSDATE,                         --5
  --                   repair_price,                    --6
  --                   incremental_price_ind,           --7
  --                   repair_tat,                      --8
  --                   incremental_tat_ind,             --9
  --                   future_price,                    --10
  --                   future_effective_date,           --11
  --                   price_type,                      --12
  --                   repair_end_date,                 --13
  --                   future_tat,                      --14
  --                   repair_display_seq_id,           --15
  --                   price_overwrite_flag_ind,        --16
  --                   p_in_user_id,                    --17
  --                   SYSDATE,                         --18
  --                   SYSDATE,                         --19
  --                   p_in_user_id                     --20
  --                 FROM
  --                   crd_e_repair_catalog
  --                 WHERE
  --                   repair_seq_id = ecrd_ref_repair_cur.repair_seq_id AND
  --                   catalog_seq_id = p_in_catalog_seq_id AND
  --                   to_date(effective_date) = to_date(v_start_date);
  --             END IF;
                  --Updating the new Price and updating repair end date to null

  -- Repair TAT changes made for Apply TAT at Component Level by RR on 6th April
  -- Following req undone i.e if Incremental TAT is Y then store TAT as 0..
  -- This change is undone and now Default/Rule level TAT will be
  -- stored while copying repairs for which repair level rule is applied.
              UPDATE crd_e_repair_catalog cerc
              SET
                 repair_price = v_new_price,
                 repair_tat = v_new_tat,
                 repair_end_date = NULL,
                 last_update_date = SYSDATE,
                 last_updated_by = p_in_user_id,
                 -- PHA update effective_date
                 effective_date = v_start_date
              WHERE
                 repair_seq_id = ecrd_ref_repair_cur.repair_seq_id AND
                 -- PHA 03/09/2005 Commenting the check. Effective date cannot be start date.
                 catalog_seq_id = p_in_catalog_seq_id /*AND
                 to_date(effective_date) = to_date(v_start_date)*/
                 AND trunc(effective_date) = ( select trunc(max(effective_date))
                                                     from crd_e_repair_catalog
                                                     where repair_seq_id = ecrd_ref_repair_cur.repair_seq_id
                                                     AND catalog_seq_id = p_in_catalog_seq_id)
  ;

              --updating all the child repair for this repair if it is a parent repair.
              FOR ecrd_ref_child_repair IN eCRD_Child_repair(ecrd_ref_repair_cur.repair_seq_id)
              LOOP
                 --updating the repair catalog table for the child repair seting repair end date to null.
                 UPDATE crd_e_repair_catalog
                 SET
                    repair_end_date = NULL,
                    -- PHA update last update fields
                    last_update_date = SYSDATE,
                    last_updated_by = p_in_user_id,
                    -- PHA update effective_date
                    effective_date = v_start_date
                 WHERE
                    repair_seq_id = ecrd_ref_child_repair.repair_seq_id AND
                    -- PHA 03/09/2005 Commenting the check. Effective date cannot be start date.
                    catalog_seq_id = p_in_catalog_seq_id /*AND
                    to_date(effective_date) = to_date(v_start_date)*/
                    AND trunc(effective_date) = ( select trunc(max(effective_date))
                                                     from crd_e_repair_catalog
                                                     where repair_seq_id = ecrd_ref_child_repair.repair_seq_id
                                                     AND catalog_seq_id = p_in_catalog_seq_id)
  ;
              END LOOP;
           END IF;

         --Patni 24/02/2006 - Begin - Rule should be applied only for the current year
         END IF;
         --Patni 24/02/2006 - End - Rule should be applied only for the current year

      END LOOP;
   END IF;
v_n_step := 7.77;
--moving the deleted records to repair catalog history.
-- PHA 03/09/2005 Commenting this. No need to put repairs ended in history table.
/*
   INSERT INTO crd_e_repair_catalog_hist
   (
      repair_seq_id,             --1
      catalog_seq_id,            --2
      effective_date,            --3
      staging_history_ind,       --4
      change_start_date,         --5
      repair_price,              --6
      incremental_price_ind,     --7
      repair_tat,                --8
      incremental_tat_ind,       --9
      future_price,              --10
      future_effective_date,     --11
      price_type,                --12
      repair_end_date,           --13
      future_tat,                --14
      repair_display_seq_id,     --15
      price_overwrite_flag_ind,  --16
      created_by,               --17
      creation_date,            --18
      last_update_date,         --19
      last_updated_by           --20
   )
   SELECT
      repair_seq_id,                   --1
      catalog_seq_id,                  --2
      effective_date,                  --3
      ecrd_utils_pkg.G_HISTORY_RECORD, --4
      SYSDATE,                         --5
      repair_price,                    --6
      incremental_price_ind,           --7
      repair_tat,                      --8
      incremental_tat_ind,             --9
      future_price,                    --10
      future_effective_date,           --11
      price_type,                      --12
      repair_end_date,                 --13
      future_tat,                      --14
      repair_display_seq_id,           --15
      price_overwrite_flag_ind,        --16
      p_in_user_id,                    --17
      SYSDATE,                         --18
      SYSDATE,                         --19
      p_in_user_id                     --20
   FROM
      crd_e_repair_catalog
   WHERE
      repair_end_date = v_sys_date AND
      catalog_seq_id = p_in_catalog_seq_id;
*/

v_n_step := 8;
p_out_message := 'RULES_COPY_AND_APPLIED';
EXCEPTION
WHEN OTHERS
THEN
   p_out_message := 'RULES_COPYING_FAILED';
   RAISE_APPLICATION_ERROR(-20020,'***Error in eCRD_ManageCatalog_pkg.ecrd_copy_apply_prc--STEP-->'||v_n_step||'***'||'v_in_n_step-->'||v_in_n_step||'###'||SQLCODE||'-'||SUBSTR(SQLERRM,1,100));
END ecrd_copy_apply_prc;

PROCEDURE ecrd_save_cust_catalog_prc(p_in_engine_model_code IN crd_e_catalog.eng_mdl_number%TYPE,
                    p_in_start_date  IN VARCHAR2,
                    p_in_end_date IN VARCHAR2,
                    p_in_customer_code         IN VARCHAR2,
                    p_in_cust_contract_code    IN VARCHAR2,
                    p_in_cust_contract_desc    IN VARCHAR2,
                    p_in_contract_start_date         IN VARCHAR2,
                    p_in_contract_end_date        IN VARCHAR2,
                    p_in_catalog_number             IN crd_e_catalog.catalog_number%TYPE,
                    p_in_catalog_desc             IN crd_e_catalog.catalog_description%TYPE,
                    p_in_cat_ind         IN crd_e_catalog.CAT_IND%TYPE,          --changes by vikrant
                    p_in_parent_catalog_id   IN VARCHAR2,
                    p_in_user_id                   IN crd_crc_user.USERID%TYPE,
                    p_out_catalog_data         OUT result_cursor,
                    p_out_ctlg_cust_data       OUT result_cursor,
                    p_out_cat_seq_id OUT VARCHAR2,
                    p_out_message OUT VARCHAR2,
                    p_out_escalation OUT VARCHAR2
                    )
IS

      v_arr_idx  BINARY_INTEGER := 1;
      v_arr_cust_code STORE_VALUES;
      v_arr_contract_code STORE_VALUES;
       v_arr_contract_desc STORE_VALUES;
      v_arr_start_date STORE_VALUES;
      v_arr_end_date STORE_VALUES;

      v_count         NUMBER(5);
      v_catalog_seq_id crd_e_customer_contract.catalog_seq_id%TYPE;
      v_start_date DATE :=null;
      v_end_date DATE :=null;
      v_step NUMBER :=0;

BEGIN
      dbms_output.put_line(p_in_customer_code);
    v_count := 0;
    v_arr_cust_code := ecrd_string_seperator_fnc(p_in_customer_code,ecrd_utils_pkg.G_COL_DELIM);
   v_arr_contract_code:= ecrd_string_seperator_fnc(p_in_cust_contract_code,ecrd_utils_pkg.G_COL_DELIM);
   v_arr_contract_desc:= ecrd_string_seperator_fnc(p_in_cust_contract_desc,ecrd_utils_pkg.G_COL_DELIM);
   v_arr_start_date:= ecrd_string_seperator_fnc(p_in_contract_start_date,ecrd_utils_pkg.G_COL_DELIM);
   v_arr_end_date:= ecrd_string_seperator_fnc(p_in_contract_end_date,ecrd_utils_pkg.G_COL_DELIM);
   v_step :=1;
   dbms_output.put_line(p_in_start_date||' v_arr_start_date--> '||v_arr_start_date.COUNT||' v_arr_end_date-->'||v_arr_end_date.COUNT);
   dbms_output.put_line('v_arr_start_date(1)-->'||v_arr_start_date(1));
   dbms_output.put_line('v_arr_start_date(2)-->'||v_arr_start_date(2));
   dbms_output.put_line('v_arr_end_date(1)->'||v_arr_end_date(1));
   dbms_output.put_line('v_arr_end_date(2)->'||v_arr_end_date(2));
   v_start_date :=TO_DATE(p_in_start_date,'MM/DD/YYYY');
   v_end_date:=TO_DATE(p_in_end_date,'MM/DD/YYYY');
dbms_output.put_line('v_start_date--'||v_start_date);
dbms_output.put_line('v_end_date--'||v_end_date);
      SELECT
         crd_e_catalog_seq.NEXTVAL
         INTO
         v_catalog_seq_id
            FROM
            DUAL;
v_step :=2;
/************************************************************************
* Inserting into crd_e_catalog
************************************************************************/
--dbms_output.put_line('p_in_catalog_number--'||p_in_catalog_number);
--dbms_output.put_line('v_catalog_seq_id--'||v_catalog_seq_id);
--dbms_output.put_line('p_in_catalog_desc--'||p_in_catalog_desc);
--dbms_output.put_line('p_in_engine_model_code--'||p_in_engine_model_code);
--dbms_output.put_line('TO_CHAR(p_in_start_date)--'||v_start_date);
--dbms_output.put_line('TO_CHAR(p_in_end_date)--'||v_end_date);
--dbms_output.put_line('p_in_user_id--'||p_in_user_id);

      INSERT INTO crd_e_catalog
               (catalog_seq_id,              --1
                catalog_number,              --2
                catalog_description,         --3
                eng_mdl_number,              --4
                catalog_effective_date,      --5
                catalog_end_date,            --6
                catalog_type,                --7
                parent_catalog_seq_id,       --8
                active_ind,                  --9
               created_by,                   --10
               creation_date,                --11
               last_update_date,             --12
               last_updated_by,              --13
               flowdown_changes_ind,         --14
               calculated_price_default_ind,  --15
               CAT_IND   --changes by vikrant
               )
          VALUES
            (v_catalog_seq_id,               --1
            p_in_catalog_number,             --2
            p_in_catalog_desc,               --3
            p_in_engine_model_code,          --4
            v_start_date,                    --5
            v_end_date,                      --6
            'C',                             --7
            p_in_parent_catalog_id,          --8
            ecrd_utils_pkg.G_ACTIVE,         --9
             p_in_user_id,                   --10
             sysdate,                        --11
             sysdate,                        --12
            p_in_user_id,                    --13
            '',                              --14
            '',                               --15
            p_in_cat_ind      ----changes by vikrant
              );
v_step:=3;
    WHILE v_arr_cust_code(v_arr_idx) IS NOT NULL
    LOOP
/************************************************************************
* Inserting into crd-e-customer_contract
************************************************************************/


         v_start_date :=TO_DATE(v_arr_start_date(v_arr_idx),'MM/DD/YYYY');
   v_end_date:=TO_DATE(v_arr_end_date(v_arr_idx),'MM/DD/YYYY');
dbms_output.put_line('v_start_date-->'||v_start_date);
dbms_output.put_line('v_end_date-->'||v_end_date);
        INSERT INTO crd_e_customer_contract
               (catalog_seq_id,                 --1
                customer_code,                  --2
                contract_number,                --3
                contract_start_date,            --4
               contract_end_date,               --5
               customer_contract_description,   --6
               created_by,                      --7
               creation_date,                   --8
               last_update_date,                --9
               last_updated_by                  --10
               )
          VALUES
            (v_catalog_seq_id,                  --1
               v_arr_cust_code(v_arr_idx),      --2
               v_arr_contract_code(v_arr_idx),  --3
               v_start_date,                    --4
               v_end_date ,                     --5
               v_arr_contract_desc(v_arr_idx),                             --6
               p_in_user_id,                    --7
               sysdate,                         --8
               sysdate,                         --9
               p_in_user_id                     --10
              );
      v_arr_idx := v_arr_idx + 1;

      END LOOP;
      v_step:=4;
        p_out_cat_seq_id :=v_catalog_seq_id;
      p_out_message := 'CREATE_SUCCESS';

      ecrd_managecatalog_pkg.ecrd_get_customer_ctlg_prc(v_catalog_seq_id,p_out_catalog_data,
                                                        p_out_ctlg_cust_data,p_out_escalation);
   COMMIT;
EXCEPTION
WHEN OTHERS
THEN
ROLLBACK;
   RAISE_APPLICATION_ERROR(-20020,'***Error in eCRD_ManageCatalog_pkg.ecrd_save_cust_prc--v_step'||v_step||'**'||v_catalog_seq_id||'=='||SQLCODE||'-'||SUBSTR(SQLERRM,1,100));

END ecrd_save_cust_catalog_prc;

FUNCTION ecrd_string_seperator_fnc(p_in_instr  IN LONG,
                                  p_in_seprator      IN VARCHAR2
                                 )
 RETURN STORE_VALUES
 IS
   v_store  STORE_VALUES;
   v_insert    LONG;
   v_pos         NUMBER;
   v_counter   NUMBER;

 BEGIN
   v_store := STORE_VALUES('');
   --------------------------
   v_store.EXTEND(1);
   --------------------------
   v_insert := p_in_instr;
   v_pos := INSTR(v_insert,p_in_seprator, 1, 1);
   v_counter := 1;
   IF v_pos <= 0
   THEN
       v_store (v_counter) :=p_in_instr;
   END IF;
   WHILE(v_pos<>0)
   LOOP
      v_store(v_counter) := SUBSTR(v_insert,1,v_pos-1);
      IF UPPER(v_store(v_counter)) = 'NULL'
      THEN
         v_store(v_counter) := NULL;
      END IF;
      v_insert := SUBSTR(v_insert,v_pos+1);
      v_pos := INSTR(v_insert,p_in_seprator, 1, 1);
      v_counter := v_counter + 1;
      v_store.EXTEND(1);
   END LOOP;

   RETURN v_store;

EXCEPTION
WHEN OTHERS
THEN
     RAISE_APPLICATION_ERROR(-20101,'There is error in ecrd_string_seperator_fnc.'||SQLCODE, TRUE);

END ecrd_string_seperator_fnc;

PROCEDURE ecrd_repair_pricing_prc(
     p_in_rep_seq_id IN crd_e_repair_catalog.repair_seq_id%TYPE,
      p_in_catalog_seq_id IN crd_e_repair_catalog.catalog_seq_id%TYPE,
     p_in_effective_date IN VARCHAR2,
      p_out_message OUT VARCHAR2)
IS
BEGIN

   INSERT INTO crd_e_repair_catalog_hist
                                    (
                               CATALOG_SEQ_ID,
                               REPAIR_SEQ_ID,
                               EFFECTIVE_DATE,
                               STAGING_HISTORY_IND,
                               CHANGE_START_DATE,
                               REPAIR_PRICE,
                               INCREMENTAL_PRICE_IND,
                               REPAIR_TAT,
                               INCREMENTAL_TAT_IND,
                               FUTURE_PRICE,
                               FUTURE_EFFECTIVE_DATE,
                               PRICE_TYPE,
                               REPAIR_END_DATE,
                               --ACTIVE_IND,
                               FUTURE_TAT,
                               CREATED_BY,
                               CREATION_DATE,
                               LAST_UPDATE_DATE,
                               LAST_UPDATED_BY,
                               REPAIR_DISPLAY_SEQ_ID,
                               REQUESTED_BY,
                               REQUESTED_DATE,
                               APPROV_REJECT_BY,
                               APPROVED_REJECTED_DATE,
                               APPROVE_REJECT_STATUS,
                               REJECTION_COMMENTS
                              )
             (
          SELECT
                    CATALOG_SEQ_ID,
                   REPAIR_SEQ_ID,                 -- NUMBER
                   EFFECTIVE_DATE,
                   ecrd_utils_pkg.g_history_record, --HISTORY_STAGING_INDICATOR
                   SYSDATE,                     --CHANGE_START_DATE
                   REPAIR_PRICE,                   --NUMBER
                   INCREMENTAL_PRICE_IND,
                   REPAIR_TAT,
                   INCREMENTAL_TAT_IND,
                   FUTURE_PRICE,
                   FUTURE_EFFECTIVE_DATE,
                   PRICE_TYPE,
                   REPAIR_END_DATE,
                  -- ACTIVE_IND,
                   FUTURE_TAT,
                   CREATED_BY,
                   CREATION_DATE,
                   LAST_UPDATE_DATE,
                   LAST_UPDATED_BY,
                   REPAIR_DISPLAY_SEQ_ID,
                   NULL,       --REQUESTED_BY
                   NULL,   --REQUESTED_DATE
                   NULL,   -- APPROV_REJECT_BY
                   NULL,   -- APPROVED_REJECTED_DATE
                   NULL,   --  APPROVE_REJECT_STATUS
                   NULL    --REJECTION_COMMENTS
         FROM crd_e_repair_catalog crc
         WHERE crc.REPAIR_SEQ_ID = p_in_rep_seq_id
         AND   crc.CATALOG_SEQ_ID = p_in_catalog_seq_id
         AND   TO_DATE(crc.EFFECTIVE_DATE) = TO_DATE(p_in_effective_date,ecrd_utils_pkg.g_date_format)
               );
  /*UPDATE crd_e_repair_catalog
  SET    REPAIR_PRICE
      INCREMENTAL_PRICE_IND
      REPAIR_TAT
      INCREMENTAL_TAT_IND
      FUTURE_PRICE
      FUTURE_EFFECTIVE_DATE
      PRICE_TYPE
      REPAIR_END_DATE
      REPAIR_DISPLAY_SEQ_ID
      FUTURE_TAT
      PRICE_OVERWRITE_FLAG_IND
      ACTIVE_IND
      CREATED_BY
      CREATION_DATE
      LAST_UPDATE_DATE
      LAST_UPDATED_BY
      BASELINE_TAT
   WHERE crc.REPAIR_SEQ_ID = p_in_rep_seq_id
   AND   crc.CATALOG_SEQ_ID = p_in_catalog_seq_id
   AND   TO_DATE(crc.EFFECTIVE_DATE) = TO_DATE(p_in_effective_date,ecrd_utils_pkg.g_date_format
   */
EXCEPTION
WHEN OTHERS
THEN
ROLLBACK;
   RAISE_APPLICATION_ERROR(-20020,'***Error in eCRD_ManageCatalog_pkg.ecrd_repair_pricing_prc--'||SQLCODE||'-'||SUBSTR(SQLERRM,1,100));

END ecrd_repair_pricing_prc;
----------------------------------------

PROCEDURE ecrd_list_engine_catalog_prc(p_in_customer IN crd_e_customer.customer_code%TYPE,
                           p_in_startdate IN VARCHAR2,
                           p_in_enddate IN VARCHAR2,
                           p_in_catalog_type IN VARCHAR2,
                           p_in_catalog_num  IN crd_e_catalog.catalog_number%TYPE,
						   p_in_cat_ind  IN VARCHAR2,    --changes by vikrant
                           p_in_catalog_ind  IN VARCHAR2,                            
                           p_in_EngineModel IN crd_e_catalog.eng_mdl_number%TYPE,
                           p_out_list_cust_cur OUT result_cursor )
IS
    v_main_query long;
    v_where_query long;
--
BEGIN
     v_main_query :='SELECT   cc.CATALOG_SEQ_ID cat_seq_id,
            NVL(cc.catalog_number,cem.ENG_MDL_DESC) Engine_Model, -- Show Catalog Number for Customer Catalog
            cc.catalog_number,cem.ENG_MDL_DESC Engine_Desc,
            cec.customer_name Customer_name,
            cecc.contract_number Contract_number,
            ecrd_managecatalog_pkg.ecrd_get_discount_fnc(cc.CATALOG_SEQ_ID) Discount,
            TO_CHAR(cc.catalog_effective_date,'''||ecrd_utils_pkg.G_DISPLAY_DATE_FORMAT||''') Start_Date,
            TO_CHAR(cc.catalog_effective_date,'||'''YYYY/MM/DD'''||') Sortable_Start_Date,
            TO_CHAR(cc.catalog_end_date,'''||ecrd_utils_pkg.G_DISPLAY_DATE_FORMAT||''') End_Date,
            TO_CHAR(cc.catalog_end_date,'||'''YYYY/MM/DD'''||') Sortable_End_Date,
               cc.catalog_description Description,
            cc.catalog_type   cat_type
            FROM  crd_e_catalog cc,CRD_CRC_ENG_MDL_DISPLAY cem,crd_e_customer_contract cecc,crd_e_customer cec
            WHERE cc.eng_mdl_number = '''||p_in_EngineModel||'''
		 
          AND   cem.ENG_MDL_NUMBER = cc.ENG_MDL_NUMBER
          AND   cc.CATALOG_SEQ_ID = cecc.CATALOG_SEQ_ID(+)
          AND   cecc.customer_code = cec.customer_code(+) ';
    --
    
          
          --AND 	cc.CAT_IND = '''||p_in_cat_ind||'''  "removed from the where condition in above query"
	
--new changes 15-07-19	
	IF p_in_cat_ind = 'ALL' 
     THEN
        v_main_query := v_main_query || '  AND 	cc.CAT_IND IN 
                ( '''||ecrd_utils_pkg.G_CAT_IND_GE||''' , '''||ecrd_utils_pkg.G_CAT_IND_ACC||''' , 
                  '''||ecrd_utils_pkg.G_CAT_IND_RPL||''' , '''||ecrd_utils_pkg.G_CAT_IND_OVH||'''   )   '     ;
     
     ELSE 
        v_main_query := v_main_query || ' AND 	cc.CAT_IND = '''||p_in_cat_ind||''' '  ;
        
     END IF ;
     
     DBMS_OUTPUT.PUT_LINE('Rishabh  :  v_main_query '||v_main_query);
--end of new changes 15-07-19	
          
          
    IF p_in_startdate IS NOT NULL
     THEN
        v_where_query := v_where_query ||'
           AND TO_DATE(cc.catalog_effective_date)>=TO_DATE('''||p_in_startdate||''',''MM/DD/YYYY'')';
     END IF;
     --
      IF p_in_customer IS NOT NULL
     THEN
        v_where_query := v_where_query || '
        AND EXISTS (SELECT DISTINCT catalog_seq_id
                 FROM crd_e_customer_contract crn,crd_e_customer cru
                 WHERE cru.customer_code ='''||p_in_customer||'''
                 AND crn.customer_code = cru.customer_code
                 AND  cc.catalog_seq_id = crn.catalog_seq_id)';
      --The below query is added to fix the Search function using customer name - Kumar
         v_where_query := v_where_query || '
        AND cec.customer_name = (select customer_name from crd_e_customer cust where cust.customer_code = '''||p_in_customer||''')';

     END IF;
     --
     IF  p_in_enddate IS NOT NULL
     THEN
        v_where_query := v_where_query ||'
        AND TO_DATE(cc.catalog_end_date)<=TO_DATE('''||p_in_enddate||''',''MM/DD/YYYY'')';
     END IF;
     --
     IF(p_in_catalog_type <> 'B')
     THEN
         v_where_query := v_where_query ||' AND cc.catalog_type = '''||p_in_catalog_type||'''';
     END IF;
     --
     IF(p_in_catalog_num IS NOT NULL)
     THEN
         v_where_query := v_where_query ||' AND TRIM(UPPER(cc.catalog_number)) LIKE ''%'||TRIM(UPPER(p_in_catalog_num))||'%''';
     END IF;
     IF(p_in_catalog_ind = 'Y')
     THEN
           v_where_query := v_where_query ||' AND cc.catalog_effective_date 	<= SYSDATE ';
            v_where_query := v_where_query ||' AND cc.catalog_end_date 			> SYSDATE ';
     END IF;

   --
   OPEN p_out_list_cust_cur
   FOR v_main_query||v_where_query;
  -- INSERT INTO SANTOSH_TEST VALUES('VJ',v_main_query||v_where_query);
   --

   EXCEPTION
   WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20001,
   'ERROR IN ecrd_managecatalog_pkg.ecrd_list_engine_catalog_prc. :' ||v_main_query||v_where_query||':'
   ||SQLCODE ||  ' - ' || SQLERRM);
END ecrd_list_engine_catalog_prc;

PROCEDURE ecrd_save_catalog_prc( p_in_cat_seq_id IN VARCHAR2,
                          p_in_cat_desc IN crd_e_catalog.CATALOG_DESCRIPTION%TYPE,
                          p_in_cat_end_date IN VARCHAR2,
                          p_in_cust_details IN VARCHAR2,
                          p_in_user_id IN VARCHAR2,
                          p_out_ctlg_cust_data OUT result_cursor,
                          p_out_message OUT VARCHAR2
                          )

IS

v_count number;
v_start_date crd_e_catalog.catalog_effective_date%TYPE;
v_end_date crd_e_catalog.catalog_end_date%TYPE;
--30-May-2006 Defect #59 Variable not required
--v_customer_code crd_e_customer_contract.customer_code%TYPE;
tab_broken_row ecrd_utils_pkg.gtyp_buf_arr;
tab_broken_column ecrd_utils_pkg.gtyp_buf_arr;
v_row_count NUMBER :=0;
v_index NUMBER :=0;
v_row_details VARCHAR2(2000) :='';
v_cnt number :=0;

BEGIN

p_out_message := 'CATALOG_MODIFEIED_FAILED';

INSERT INTO crd_e_catalog_history
(
     catalog_seq_id,
     staging_history_ind,
     change_start_date,
     catalog_number,
     eng_mdl_number,
     catalog_description,
     effective_date,
     end_date,
     created_by,
     catalog_type,
     flowdown_changes_ind,
     calculated_price_default_ind,
     active_ind,
     parent_catalog_id,
     creation_date,
     last_update_date,
     last_updated_by
)
SELECT
     catalog_seq_id,
     ecrd_utils_pkg.G_HISTORY_RECORD,
     SYSDATE,
     catalog_number,
     eng_mdl_number,
     catalog_description,
     catalog_effective_date,
     catalog_end_date,
     p_in_user_id,
     catalog_type,
     flowdown_changes_ind,
     calculated_price_default_ind,
     active_ind,
     parent_catalog_seq_id,
     SYSDATE,
     SYSDATE,
     p_in_user_id
FROM
   crd_e_catalog
WHERE
   catalog_seq_id = p_in_cat_seq_id;

UPDATE crd_e_catalog
SET catalog_description = p_in_cat_desc,
   catalog_end_date    = TO_DATE(p_in_cat_end_date,ecrd_utils_pkg.G_DATE_FORMAT),
   last_updated_by = p_in_user_id,
   last_update_date = SYSDATE
WHERE crd_e_catalog.CATALOG_SEQ_ID = p_in_cat_seq_id;

SELECT catalog_effective_date,
      catalog_end_date
INTO  v_start_date,
     v_end_date
FROM  crd_e_catalog
WHERE  catalog_seq_id = p_in_cat_seq_id;

/* Patni 19-May-2006 Begin Add Contract Start and End Date */

IF p_in_cust_details IS NOT NULL
THEN
        ecrd_utils_pkg.break_into_rows_s_prc(p_in_cust_details,ecrd_utils_pkg.G_ROW_DELIM,tab_broken_row);
        v_row_count := tab_broken_row.COUNT;
        DBMS_OUTPUT.PUT_LINE('v_row_count'||v_row_count);
         FOR v_index IN 1..v_row_count
         LOOP
            v_row_details := tab_broken_row(v_index);
         DBMS_OUTPUT.PUT_LINE('v_row_details'||v_row_details);
            -- Breaking the Rows into Columns...
            ecrd_utils_pkg.break_into_cols_s_prc(v_row_details,ecrd_utils_pkg.G_COL_DELIM,tab_broken_column);

            DBMS_OUTPUT.PUT_LINE('tab_broken_column(1)'||tab_broken_column(1));
            DBMS_OUTPUT.PUT_LINE('tab_broken_column(2)'||tab_broken_column(2));
            DBMS_OUTPUT.PUT_LINE('tab_broken_column(3)'||tab_broken_column(3));
        /* Patni 16-May-2006 Begin Add Contract Start and End Date */
            DBMS_OUTPUT.PUT_LINE('tab_broken_column(4)'||tab_broken_column(4));
           -- tab_broken_column(4) := TO_DATE(tab_broken_column(4),ecrd_utils_pkg.G_DATE_FORMAT);
            --30-May-2006 Defect #59 Begin
            v_cnt:=0;
            select count(0)
            into v_cnt
            from crd_e_customer_contract
            where catalog_seq_id = p_in_cat_seq_id
            and customer_code = tab_broken_column(1)
            and contract_number = tab_broken_column(2);

            IF v_cnt=0 THEN
            --30-May-2006 Defect #59 End
       /* Patni 16-May-2006 End Add Contract Start and End Date */

             INSERT INTO crd_e_customer_contract
               (catalog_seq_id,                 --1
                customer_code,                  --2
                contract_number,                --3
                contract_start_date,            --4
               contract_end_date,               --5
               customer_contract_description,   --6
               created_by,                      --7
               creation_date,                   --8
               last_update_date,                --9
               last_updated_by                  --10
               )
          VALUES
            (p_in_cat_seq_id,                --1
              tab_broken_column(1),    --2
              tab_broken_column(2), --3
               v_start_date,                    --4
               v_end_date,                    --5
               tab_broken_column(3),                              --6
               p_in_user_id,                    --7
               sysdate,                         --8
               sysdate,                         --9
               p_in_user_id                     --10
              );
  /* Patni 19-May-2006 Begin Add Contract Start and End Date */
         ELSE
           UPDATE crd_e_customer_contract
           SET contract_end_date = TO_DATE(tab_broken_column(4),ecrd_utils_pkg.G_DATE_FORMAT),
                 last_update_date = SYSDATE,
                 last_updated_by = p_in_user_id
           WHERE catalog_seq_id = p_in_cat_seq_id
            and customer_code = tab_broken_column(1)
            and contract_number = tab_broken_column(2);
       END IF;
     END LOOP;
END IF;
/*UPDATE
   crd_e_customer_contract
SET
   contract_end_date = v_end_date,
   last_update_date = SYSDATE,
   last_updated_by = p_in_user_id
WHERE
   catalog_seq_id = p_in_cat_seq_id;*/

/* Patni 19-May-2006 End Add Contract Start and End Date */

ecrd_get_ctlg_cust_data_prc (p_in_cat_seq_id
                         ,p_out_ctlg_cust_data);

p_out_message := 'CATALOG_MODIFEIED';

EXCEPTION
WHEN OTHERS THEN
RAISE_APPLICATION_ERROR(-20001,
'ERROR IN ecrd_managecatalog_pkg.ecrd_save_catalog_prc. :'||SQLCODE ||  ' - ' || SQLERRM);

END ecrd_save_catalog_prc;

PROCEDURE ecrd_update_rule_prc(
      p_in_RuleLevel IN VARCHAR2,
      p_in_catalog_seq_id IN crd_e_catalog.catalog_seq_id%TYPE,
      p_in_ComponentCd IN crd_e_component.component_code%TYPE,
      p_in_ModuleCd IN crd_crc_module.module_seq_id%TYPE,
      p_in_RepairCd IN crd_e_repair.repair_seq_id%TYPE,
      p_in_Year IN VARCHAR2,
      p_in_TAT IN crd_e_ctlg_contracted.tat%TYPE,
      p_in_Discount IN crd_e_ctlg_contracted.discount%TYPE,
      p_in_DefaultValCompare IN crd_e_catalog.calculated_price_default_ind%TYPE,
      p_in_FlowChangesFrmDef IN crd_e_catalog.flowdown_changes_ind%TYPE,
      p_in_Escalation IN crd_e_ctlg_contracted.escalation%TYPE,
      p_in_IndexDep IN VARCHAR2,
      p_in_UserId IN crd_crc_user.userid%TYPE,
      p_out_message OUT VARCHAR2
)
IS
  tab_broken_row ecrd_utils_pkg.gtyp_buf_arr;
  tab_broken_column ecrd_utils_pkg.gtyp_buf_arr;
  v_row_count NUMBER :=0;
  v_index NUMBER :=0;
  v_row_details VARCHAR2(2000) :='';
BEGIN
   IF(p_in_RuleLevel = 'C')
   THEN

      UPDATE CRD_E_CTLG_CONTRACTED
      SET
         tat = p_in_TAT,
         escalation = p_in_escalation,
         discount = p_in_discount,
         last_update_date = SYSDATE,
         last_updated_by = p_in_userid
      WHERE
         catalog_seq_id = p_in_catalog_seq_id AND
         year = p_in_year;
      UPDATE crd_e_catalog
      SET
         calculated_price_default_ind = p_in_DefaultValCompare,
         flowdown_changes_ind = p_in_FlowChangesFrmDef
      WHERE
         catalog_seq_id = p_in_catalog_seq_id;

      DELETE
      FROM CRD_E_INFLATION_INDEX
      WHERE
         catalog_seq_id = p_in_catalog_seq_id AND
         year = p_in_year;
      IF(p_in_FlowChangesFrmDef = 'N')
      THEN
         IF(p_in_Escalation IS NULL OR p_in_Escalation ='' OR p_in_Escalation = 0.0)
      	THEN
         -- Breaking the String into Rows...
            IF(p_in_IndexDep IS NOT NULL)
            THEN
		         ecrd_utils_pkg.break_into_rows_s_prc(p_in_IndexDep,ecrd_utils_pkg.G_ROW_DELIM,tab_broken_row);

         v_row_count := tab_broken_row.COUNT;
         FOR v_index IN 1..v_row_count
         LOOP

            v_row_details := tab_broken_row(v_index);
            -- Breaking the Rows into Columns...
            ecrd_utils_pkg.break_into_cols_s_prc(v_row_details,ecrd_utils_pkg.G_COL_DELIM,tab_broken_column);
            -- inserting the data in inflation table..
                  IF(tab_broken_column(1) IS NOT NULL)
                  THEN

               INSERT INTO CRD_E_INFLATION_INDEX
               (
                  catalog_seq_id,   --1
                  index_value,      --2
                  year,             --3
                  index_dependancy, --4
                  created_by,       --5
                  creation_date,    --6
                  last_update_date, --7
                  last_updated_by   --8
               )
               VALUES
               (
                  p_in_catalog_seq_id,    --1
                  DECODE(tab_broken_column(1),'','',TO_NUMBER(tab_broken_column(1))),  --2
                  p_in_year,              --3
                  DECODE(tab_broken_column(2),'','',TO_NUMBER(tab_broken_column(2))),  --4
                  p_in_UserId,            --5
                  SYSDATE,                --6
                  SYSDATE,                --7
                  p_in_UserId             --8
               );
               END IF;
               END LOOP;
            END IF;
            END IF;
         END IF;
   ELSIF(p_in_RuleLevel = 'M')
   THEN
      UPDATE CRD_E_CONTRACTED_MODULE
      SET
         tat = p_in_TAT,
         discount = p_in_discount,
         last_update_date = SYSDATE,
         last_updated_by = p_in_userid
      WHERE
         module_seq_id = p_in_ModuleCd AND
         catalog_seq_id = p_in_catalog_seq_id AND
         year = p_in_year;

   ELSIF(p_in_RuleLevel = 'CO')
   THEN

      UPDATE CRD_E_CONTRACTED_COMP
      SET
         tat = p_in_TAT,
         discount = p_in_discount,
         last_update_date = SYSDATE,
         last_updated_by = p_in_userid
      WHERE
         catalog_seq_id = p_in_catalog_seq_id AND
         module_seq_id = p_in_ModuleCd AND
         component_code = p_in_ComponentCd AND
         year = p_in_year;

   ELSIF(p_in_RuleLevel = 'R')
   THEN

      UPDATE CRD_E_CONTRACTED_REPAIR
      SET
         tat = p_in_TAT,
         discount = p_in_discount,
         last_update_date = SYSDATE,
         last_updated_by = p_in_userid
      WHERE
         catalog_seq_id = p_in_catalog_seq_id AND
         repair_seq_id = p_in_RepairCd AND
         year = p_in_year;

   END IF;

   COMMIT;
   p_out_message := 'UPDATE_RULE_SUCCESS';
EXCEPTION
WHEN OTHERS
THEN
   ROLLBACK;
   p_out_message := 'UPDATE_RULE_FAIL';
-- RAISE_APPLICATION_ERROR(-20020,'***Error in eCRD_ManageCatalog_pkg.ecrd_update_rules_prc--'||SQLCODE||'-'||SUBSTR(SQLERRM,1,100));
END ecrd_update_rule_prc;

PROCEDURE ecrd_copy_catalog_rule_prc(
      p_in_catalog_seq_id IN VARCHAR2,
      p_in_copied_catalog_seq_id IN VARCHAR2,
      p_in_user_id IN crd_crc_user.userid%TYPE,
      p_out_message OUT VARCHAR2,
      p_flowdown_ind OUT crd_e_catalog.flowdown_changes_ind%TYPE,
      p_defaut_price_ind OUT crd_e_catalog.calculated_price_default_ind%TYPE)
IS
v_count NUMBER :=0;
v_engine_model crd_crc_eng_mdl_display.eng_mdl_number%TYPE;
v_engine_desc crd_crc_eng_mdl_display.eng_mdl_desc%TYPE;
v_start_date VARCHAR(20) := '';
v_end_date VARCHAR2(20) := '';
v_catalog_desc crd_e_catalog.catalog_description%TYPE;
v_flowdown_ind crd_e_catalog.flowdown_changes_ind%TYPE;
v_defaut_price_ind crd_e_catalog.calculated_price_default_ind%TYPE;

BEGIN

   SELECT
      COUNT(1)
   INTO
      v_count
   FROM
      (SELECT
          DISTINCT discount
       FROM
          crd_e_ctlg_contracted
       WHERE catalog_seq_id = TO_NUMBER(p_in_copied_catalog_seq_id));

   SELECT
      flowdown_changes_ind,
      calculated_price_default_ind
   INTO
      p_flowdown_ind,
      p_defaut_price_ind
   FROM
      crd_e_catalog
   WHERE
      catalog_seq_id = p_in_copied_catalog_seq_id;

   IF(v_count > 1)
   THEN
      p_out_message := 'RULE_ALREDY_PRESENT';

      -- Deleting all customers for that customer catalog;
      DELETE
      FROM CRD_E_CUSTOMER_CONTRACT
      WHERE
         catalog_seq_id =  TO_NUMBER(p_in_catalog_seq_id);

      -- Deleting from catalog table
      DELETE
      FROM CRD_E_CATALOG
      WHERE
         catalog_seq_id =  TO_NUMBER(p_in_catalog_seq_id);

   ELSE
   -- copy the catalog details for the new Catalog

      INSERT INTO CRD_E_CTLG_CONTRACTED
      (
         catalog_seq_id,
         year,
         tat,
         escalation,
         discount,
         created_by,
         creation_date,
         last_update_date,
         last_updated_by)
         SELECT
            TO_NUMBER(p_in_catalog_seq_id),
            year,
            tat,
            escalation,
            discount,
            p_in_user_id,
            SYSDATE,
            SYSDATE,
            p_in_user_id
         FROM
            crd_e_ctlg_contracted
         WHERE
            catalog_seq_id = TO_NUMBER(p_in_copied_catalog_seq_id);

       UPDATE crd_e_catalog
       SET
         flowdown_changes_ind = p_flowdown_ind,
         calculated_price_default_ind = p_defaut_price_ind
       WHERE
         catalog_seq_id = TO_NUMBER(p_in_catalog_seq_id);
   END IF;
   COMMIT;
EXCEPTION
WHEN OTHERS
THEN
   ROLLBACK;
   p_out_message := '';
   RAISE_APPLICATION_ERROR(-20020,'**Error in eCRD_ManageCatalog_pkg.ecrd_copy_catalog_rule_prc'||SQLCODE||SQLERRM);
END ecrd_copy_catalog_rule_prc;
/*
*/
PROCEDURE ecrd_check_rules_prc(
      p_in_catalog IN VARCHAR2,
      p_in_year IN VARCHAR2,
      p_in_rule_level IN VARCHAR2,
      p_in_module_code IN VARCHAR2,
      p_in_component_code IN crd_e_component.component_code%TYPE,
      p_in_repair_seq_id IN VARCHAR2,
      p_out_message OUT VARCHAR)
IS
v_exiting_count NUMBER := 0;
BEGIN
IF(p_in_rule_level = 'C')
   THEN
      SELECT
         count(1)
      INTO
         v_exiting_count
      FROM
         crd_e_ctlg_contracted
      WHERE
         catalog_seq_id = p_in_catalog AND
         year = p_in_year;

      IF(v_exiting_count > 0)
      THEN
         p_out_message := 'RULE_ALREADY_PRESENT';
      ELSE
         p_out_message := '';
      END IF;

   ELSIF(p_in_rule_level ='M')
   THEN
      SELECT
         count(1)
      INTO
         v_exiting_count
      FROM
         crd_e_contracted_module
      WHERE
         catalog_seq_id = p_in_catalog AND
         module_seq_id = p_in_module_code AND
         year = p_in_year;

      IF(v_exiting_count > 0)
      THEN
         p_out_message := 'RULE_ALREADY_PRESENT';
      ELSE
         p_out_message := '';
      END IF;

   ELSIF(p_in_rule_level = 'CO')
   THEN
      SELECT
         count(1)
      INTO
         v_exiting_count
      FROM
         crd_e_contracted_comp
      WHERE
         catalog_seq_id = p_in_catalog AND
         component_code = p_in_component_code AND
         module_seq_id = p_in_module_code AND
         year = p_in_year;

      IF(v_exiting_count > 0)
      THEN
         p_out_message := 'RULE_ALREADY_PRESENT';
      ELSE
         p_out_message := '';
      END IF;

   ELSIF(p_in_rule_level = 'R')
   THEN
      SELECT
         count(1)
      INTO
         v_exiting_count
      FROM
         crd_e_contracted_repair
      WHERE
         catalog_seq_id = p_in_catalog AND
         repair_seq_id = p_in_repair_seq_id AND
         year = p_in_year;

      IF(v_exiting_count > 0)
      THEN
         p_out_message := 'RULE_ALREADY_PRESENT';
      ELSE
         p_out_message := '';
      END IF;

   END IF;
EXCEPTION
WHEN OTHERS
THEN
   p_out_message := '';
   RAISE_APPLICATION_ERROR(-20020,'**Error in eCRD_ManageCatalog_pkg.ecrd_check_rules_prc'||SQLCODE||SQLERRM);
END ecrd_check_rules_prc;
/*
*/
PROCEDURE ecrd_get_lbr_hrs_prc(p_in_repairs                    IN VARCHAR2
                           ,p_in_user_id             IN crd_crc_user.userid%TYPE
                       ,p_out_lbr_hrs_refcur          OUT result_cursor
                       ,p_out_lbr_rate            OUT result_cursor)
AS
v_query  VARCHAR2(2000):=' ';
v_lbrrt_query  VARCHAR2(2000):=' ';
v_in_query  VARCHAR2(2000):=' ';
v_repairs ecrd_utils_pkg.gtyp_buf_arr;
i_ctr BINARY_INTEGER :=1;
v_count NUMBER(10) :=0 ;
v_user_site crd_crc_user.location_id%TYPE;
BEGIN
   SELECT ccu.location_id
   INTO v_user_site
   FROM crd_crc_user ccu
   WHERE UPPER(ccu.userid) = UPPER(p_in_user_id);
   --
   v_query := '
         SELECT cerc.location_id location_id
                 ,cl.location_desc location_desc
                 ,SUM(cerc.labour_hours)  labour_hours
                 ,SUM(cerc.material_cost) material_cost
         FROM     crd_e_repair_cost              cerc
                  ,crd_e_repair                    cer
                  ,crd_location                    cl
                  ,crd_e_component_location        cecl '
                  ;
   v_query := v_query ||
         '
         WHERE cerc.component_code  =  cer.component_code
         AND   cerc.module_seq_id   =  cer.module_seq_id
         AND   cerc.repair_seq_id   =  cer.repair_seq_id
         AND   cerc.location_id     =  cl.location_id
         AND   cecl.component_code  = cer.component_code
         AND   cecl.location_id     = cl.location_id
         AND   cecl.module_seq_id   = cer.module_seq_id
         AND   cecl.active_ind      =  ''Y'' '
         ;
      --
       IF (v_user_site <> 'ALL')
       THEN
            v_query := v_query ||
                     ' AND cl.location_id = '''||v_user_site||'''  ';
       END IF;
   --
   v_query := v_query ||
         '
         AND  cer.repair_seq_id IN ( ';
         --
         ecrd_utils_pkg.break_into_cols_s_prc(p_in_repairs
                                    ,','
                                    ,v_repairs);
         --
         v_count     := v_repairs.COUNT;
         --
         FOR i_ctr IN 1..v_count
         LOOP
            v_in_query :=v_in_query || ''''||v_repairs(i_ctr)||''',';
         END LOOP;
         v_in_query :=SUBSTR(v_in_query,1,LENGTH(v_in_query)-1) ||') ';
         --
         v_query :=v_query ||    v_in_query|| '
                  GROUP BY cerc.location_id
                     ,cl.location_desc
                  '
                  ;
 v_lbrrt_query :=' SELECT DISTINCT cl.location_id  location_id
                           ,NVL(cl.location_labor_rate,0) location_labor_rate
                     FROM crd_location cl
                         ,crd_e_repair  cer
                        ,crd_e_component_location cecl
                     WHERE cecl.component_code  = cer.component_code
                     AND   cecl.location_id     = cl.location_id
                     AND   cecl.module_seq_id   = cer.module_seq_id
                     AND   cecl.active_ind      =  ''Y'' '
                     ;
     v_lbrrt_query:= v_lbrrt_query ||'
          AND  cer.repair_seq_id IN ( '
          ||   v_in_query  ;
OPEN p_out_lbr_hrs_refcur
FOR
   v_query;
--
OPEN p_out_lbr_rate
FOR
      v_lbrrt_query;
EXCEPTION
   WHEN OTHERS
   THEN
      RAISE_APPLICATION_ERROR(-20020,'--Error in ecrd_managecatalog_pkg.ecrd_get_lbr_hrs_prc : '||SQLERRM);
END ecrd_get_lbr_hrs_prc;
/*
*/
PROCEDURE ecrd_get_childrprs_prc(p_in_repair_seq_id     IN crd_e_repair.parent_repair_seq_id%TYPE
                        ,p_out_children_refcur  OUT result_cursor)
AS
BEGIN
    OPEN  p_out_children_refcur
    FOR
         SELECT  cer.repair_description        repair_desc
                 ,cer.repair_reference          repair_ref
              ,cer.repair_seq_id             repair_seqid
              ,cer.repair_reference_format   repair_ref_format
         FROM crd_e_repair cer
         WHERE cer.parent_repair_seq_id   = p_in_repair_seq_id;
    EXCEPTION
    WHEN OTHERS
    THEN RAISE_APPLICATION_ERROR(-20020,'Error in ecrd_managecatalog_pkg.ecrd_get_childrprs_prc : '||SQLERRM);
END ecrd_get_childrprs_prc;
/*
*/
PROCEDURE ecrd_delete_rule_prc(p_in_repair         IN  VARCHAR2
                       ,p_in_catalog_seq_id     IN crd_e_catalog.catalog_seq_id%TYPE
                       )
AS
v_in_query VARCHAR2(2000):='';
v_query    VARCHAR2(2000):='';
v_count    NUMBER;
i_ctr      NUMBER;
v_repairs  ecrd_utils_pkg.gtyp_buf_arr;
BEGIN
   --
   ecrd_utils_pkg.break_into_cols_s_prc(p_in_repair
                              ,','
                              ,v_repairs);
   --
   v_count     :=v_repairs.COUNT;
   --
   FOR i_ctr IN 1..v_count
   LOOP
      v_in_query :=v_in_query || ''''||v_repairs(i_ctr)||''',';
   END LOOP;
   v_in_query :=SUBSTR(v_in_query,1,LENGTH(v_in_query)-1) ||') ';
      v_query :='DELETE crd_e_contracted_repair
                 WHERE catalog_seq_id =  to_number('||p_in_catalog_seq_id||')
                 AND repair_seq_id IN ( '||v_in_query;
   --
   EXECUTE IMMEDIATE v_query;
   --
   v_query    := NULL;
   v_query    :='DELETE crd_e_repair_catalog
                 WHERE catalog_seq_id =  to_number('||p_in_catalog_seq_id||')
              AND repair_seq_id  IN ('||v_in_query;
   EXECUTE IMMEDIATE v_query;
   --
   COMMIT;
EXCEPTION
       --
       WHEN OTHERS
       THEN
           ROLLBACK;
           RAISE_APPLICATION_ERROR(-20020,'Error in ecrd_managecatalog_pkg.ecrd_delete_rule_prc : '||SQLERRM);
END ecrd_delete_rule_prc;

PROCEDURE ecrd_delete_rule_prc(p_in_year           IN  VARCHAR2,
                        p_in_rule_cd IN VARCHAR2,
                        p_in_component IN VARCHAR2,
                        p_in_module IN VARCHAR2,
                        p_in_repair IN VARCHAR2,
                        p_in_catalog_seq_id     IN crd_e_catalog.catalog_seq_id%TYPE,
                        p_out_message OUT VARCHAR2
                       )
IS
BEGIN
   IF(p_in_rule_cd = 'C')
   THEN

      DELETE FROM CRD_E_CTLG_CONTRACTED
      WHERE
         catalog_seq_id = p_in_catalog_seq_id AND
         year = p_in_year;

      DELETE FROM CRD_E_INFLATION_INDEX
      WHERE
         catalog_seq_id = p_in_catalog_seq_id AND
         year = p_in_year;

   ELSIF(p_in_rule_cd = 'M')
   THEN

      DELETE FROM CRD_E_CONTRACTED_MODULE
      WHERE
         module_seq_id = p_in_module AND
         catalog_seq_id = p_in_catalog_seq_id AND
         year = p_in_year;

   ELSIF(p_in_rule_cd = 'CO')
   THEN

      DELETE FROM CRD_E_CONTRACTED_COMP
      WHERE
         component_code = p_in_component AND
         module_seq_id = p_in_module AND
         catalog_seq_id = p_in_catalog_seq_id AND
         year = p_in_year;

   ELSIF(p_in_rule_cd = 'R')
   THEN

      DELETE FROM CRD_E_CONTRACTED_REPAIR
      WHERE
         repair_seq_id = p_in_repair AND
         catalog_seq_id = p_in_catalog_seq_id AND
         year = p_in_year;

   END IF;

   COMMIT;
   p_out_message := 'DELETE_RULE_SUCCESS';
EXCEPTION
WHEN OTHERS
THEN
   ROLLBACK;
   RAISE_APPLICATION_ERROR(-20020,'Error in ecrd_managecatalog_pkg.ecrd_delete_rule_prc***'||SQLCODE||SQLERRM);
END ecrd_delete_rule_prc;
/*
*/
PROCEDURE ecrd_get_catalog_data_prc(p_in_catalog_seq_id        IN crd_e_catalog.catalog_seq_id%TYPE
                                   ,p_out_catalog_data         OUT result_cursor
                                   ,p_out_escalation_ind OUT VARCHAR2)
AS
v_escalation_count NUMBER ;
v_inflation_count NUMBER;
BEGIN
    OPEN p_out_catalog_data
    FOR
      SELECT  cec.catalog_number catalog_number
            ,cec.parent_catalog_seq_id copied_catalog_seq
            ,cec.catalog_description catalog_desc
            ,TO_CHAR(cec.catalog_end_date,ecrd_utils_pkg.G_DATE_FORMAT) end_date
            ,TO_CHAR(cec.catalog_effective_date,ecrd_utils_pkg.G_DATE_FORMAT) start_date
            ,cec.eng_mdl_number eng_mod_cd
            ,cem.eng_mdl_desc eng_mod_desc
            ,cec.catalog_type catalog_type
            ,DECODE(SIGN(TRUNC(cec.catalog_end_date) - TRUNC(SYSDATE)), 0, 'true',1, 'true', 'false') active
            ,cec.calculated_price_default_ind calc_price_default_ind
            ,cec.flowdown_changes_ind flow_down_ind
   FROM  crd_e_catalog cec
        ,crd_crc_eng_mdl_display cem
   WHERE cec.eng_mdl_number      = cem.eng_mdl_number
   AND  trim(upper(cec.active_ind)) = ecrd_utils_pkg.G_ACTIVE
   AND  cec.catalog_seq_id          = p_in_catalog_seq_id;

   SELECT
      COUNT(1)
   INTO
      v_escalation_count
   FROM
      crd_e_ctlg_contracted cecc
   WHERE
      catalog_seq_id = p_in_catalog_seq_id AND
      escalation IS NOT NULL;

   SELECT
      COUNT(1)
   INTO
      v_inflation_count
   FROM
      crd_e_inflation_index ceii
   WHERE
      catalog_seq_id = p_in_catalog_seq_id;

   IF(v_escalation_count = 0 AND v_inflation_count = 0)
   THEN
      p_out_escalation_ind := 'N';
   ELSE
      p_out_escalation_ind := 'Y';
   END IF;
EXCEPTION
   WHEN OTHERS
   THEN RAISE;
END ecrd_get_catalog_data_prc;
--
FUNCTION ecrd_chk_customer_contract_fnc
(
    p_in_engine_model   IN VARCHAR2,
    p_in_customer_code  IN VARCHAR2,
    p_in_contract_number   IN VARCHAR2,
    p_in_cat_start_date   IN VARCHAR2,
    p_in_cat_end_date   IN VARCHAR2
)
RETURN VARCHAR2
IS
   v_count  NUMBER;     -- Count for record match
BEGIN
   v_count :=0;

   SELECT   COUNT(1)
   INTO  v_count
   FROM  crd_e_catalog  cec,
      crd_e_customer_contract ccc
   WHERE
      cec.catalog_seq_id = ccc.catalog_seq_id
   AND(  (cec.catalog_effective_date <= TO_DATE(p_in_cat_start_date,ecrd_utils_pkg.G_DATE_FORMAT)
         AND cec.catalog_end_date >= TO_DATE(p_in_cat_start_date,ecrd_utils_pkg.G_DATE_FORMAT))
      OR(cec.catalog_effective_date <= TO_DATE(p_in_cat_end_date,ecrd_utils_pkg.G_DATE_FORMAT)
         AND cec.catalog_end_date >= TO_DATE(p_in_cat_end_date,ecrd_utils_pkg.G_DATE_FORMAT))
      OR(cec.catalog_effective_date <= TO_DATE(p_in_cat_start_date,ecrd_utils_pkg.G_DATE_FORMAT)
         AND cec.catalog_end_date >= TO_DATE(p_in_cat_end_date,ecrd_utils_pkg.G_DATE_FORMAT))
      OR(cec.catalog_effective_date >= TO_DATE(p_in_cat_start_date,ecrd_utils_pkg.G_DATE_FORMAT)
         AND cec.catalog_end_date <= TO_DATE(p_in_cat_end_date,ecrd_utils_pkg.G_DATE_FORMAT)))
   AND   ccc.customer_code = p_in_customer_code
   AND   UPPER(ccc.contract_number) = UPPER(p_in_contract_number)
   AND   cec.catalog_type = 'C'
   AND   cec.eng_mdl_number = p_in_engine_model;

   IF (v_count > 0) THEN
      RETURN 'Y';
   ELSE
      RETURN 'N';
   END IF;

EXCEPTION
WHEN OTHERS THEN
   RAISE_APPLICATION_ERROR(-20020,'Error in ecrd_managecatalog_pkg.ecrd_chk_customer_contract_fnc **'||SQLCODE||SQLERRM);

END ecrd_chk_customer_contract_fnc;
--

PROCEDURE ecrd_exist_cust_cata_prc(
                       p_in_eng_model IN crd_crc_eng_mdl_display.eng_mdl_number%TYPE,
                       p_in_customer_code IN VARCHAR2,
                       p_in_contract_id IN VARCHAR2,
                       p_in_cata_start_date IN VARCHAR2,
                       p_in_cata_end_date IN VARCHAR2,
                       p_out_message OUT VARCHAR2)
IS
   v_check_message VARCHAR2(100) := '';
BEGIN

   v_check_message := ecrd_chk_customer_contract_fnc(p_in_eng_model,p_in_customer_code,p_in_contract_id,p_in_cata_start_date,p_in_cata_end_date);

   IF(v_check_message = 'Y')
   THEN
      p_out_message := v_check_message;
   ELSE
      p_out_message := '';
   END IF;

EXCEPTION
WHEN OTHERS THEN
   RAISE_APPLICATION_ERROR(-20020,'Error in ecrd_managecatalog_pkg.ecrd_exist_cust_cata_prc **'||SQLCODE||SQLERRM);
END ecrd_exist_cust_cata_prc;
--
END ecrd_managecatalog_pkg;
/
