CREATE OR REPLACE PACKAGE ecrd_utils_pkg AS                                                                                                                                                                               
--                                                                                                                                                                                                      
TYPE rec_holder IS TABLE OF LONG INDEX BY BINARY_INTEGER;                                                                                                                                               

/* Patni 04-Sep-2006 - Declaring variable of VARRAY - Begin */
TYPE VARRAY_PART IS VARRAY(4000) OF VARCHAR2(4000);
/* Patni 04-Sep-2006 - Declaring variable of VARRAY - End */
                                                                                                                                                                                                        
   G_YEARMONTHDELIM CHAR(1) := '-';                                                                                                                                                                     
                                                                                                                                                                                                        
   G_ROW_DELIM VARCHAR(1) := '$';                                                                                                                                                                       
                                                                                                                                                                                                        
   G_COL_DELIM VARCHAR(1) := '^';                                                                                                                                                                       
                                                                                                                                                                                                        
   G_ADMIN VARCHAR(5):='ADMIN';                                                                                                                                                                         
                                                                                                                                                                                                        
   G_TC VARCHAR(12):='COORDINATOR';                                                                                                                                                                     
                                                                                                                                                                                                        
   G_CSM VARCHAR(20):='CSCMaintenance';                                                                                                                                                                 
                                                                                                                                                                                                        
   G_GUEST VARCHAR(20):='GUEST';                                                                                                                                                                        
                                                                                                                                                                                                        
   G_STAGING VARCHAR(1) :='S';                                                                                                                                                                          
                                                                                                                                                                                                        
   G_MASTER  VARCHAR(1) :='M';                                                                                                                                                                          
                                                                                                                                                                                                        
   G_REQUEST_IN_PROCESS VARCHAR2(20) :='REQUEST_IN_PROCESS';                                                                                                                                            
                                                                                                                                                                                                        
   G_NO VARCHAR(1):='N';                                                                                                                                                                                
                                                                                                                                                                                                        
   G_YES VARCHAR(1):='Y';                                                                                                                                                                               
                                                                                                                                                                                                        
   G_ACCESS_DENIED VARCHAR(14) :='ACCESS_DENIED';                                                                                                                                                       
                                                                                                                                                                                                        
   G_ACTIVE VARCHAR(1) :='Y';                                                                                                                                                                           
                                                                                                                                                                                                        
   G_GROUP_REPAIR VARCHAR(2) :='PR';                                                                                                                                                                    
                                                                                                                                                                                                        
   G_INDIVIDUAL_REPAIR VARCHAR(2) :='IR';                                                                                                                                                               
                                                                                                                                                                                                        
   G_CHILD_REPAIR VARCHAR(2) :='CR';                                                                                                                                                                    
                                                                                                                                                                                                        
   G_DATE_FORMAT  VARCHAR(11) := 'MM/DD/YYYY';                                                                                                                                                          
                                                                                                                                                                                                        
   G_ALL VARCHAR(5) := 'ALL';                                                                                                                                                                           
                                                                                                                                                                                                        
   G_TRUE VARCHAR(6) := 'TRUE';                                                                                                                                                                         
                                                                                                                                                                                                        
   G_FALSE VARCHAR(6) := 'FALSE';                                                                                                                                                                       
                                                                                                                                                                                                        
   G_HISTORY_RECORD VARCHAR2(1) :='H';                                                                                                                                                                  
                                                                                                                                                                                                        
   G_CATALOG_IND VARCHAR2(1) := 'D';                                                                                                                                                                    
                                                                                                                                                                                                        
   G_DEFAULT_CATALOG VARCHAR2(1) := 'D';                                                                                                                                                                
                                                                                                                                                                                                        
   G_CUSTOMER_CATALOG VARCHAR2(1) := 'C';                                                                                                                                                               
                                                                                                                                                                                                        
   G_END_MDL_STS_CODE VARCHAR2(1) :='A';                                                                                                                                                                
                                                                                                                                                                                                        
   G_DEFAULT_CATALOG_IND VARCHAR2(1) :='C';                                                                                                                                                             
                                                                                                                                                                                                        
   G_DISPLAY_DATE_FORMAT VARCHAR(11) := 'DD-Mon-YYYY';                                                                                                                                                  
                                                                                                                                                                                                        
   G_APPROVE_STATUS VARCHAR(1) := 'A';                                                                                                                                                                  
                                                                                                                                                                                                        
   G_REJECT_STATUS VARCHAR(1) := 'R';                                                                                                                                                                   
                                                                                                                                                                                                        
   G_PARENT_REPAIR VARCHAR(2) := 'PR';                                                                                                                                                                  
                                                                                                                                                                                                        
   G_MERGE_REPAIR VARCHAR(2) := 'MR';                                                                                                                                                                   
                                                                                                                                                                                                        
   G_SPECIAL_IND_REPAIR VARCHAR(2) := 'SI';                                                                                                                                                             
                                                                                                                                                                                                        
   G_SPECIAL_GROUP_REPAIR VARCHAR(2) := 'SG';                                                                                                                                                           
                                                                                                                                                                                                        
   G_SPLIT_REPAIR VARCHAR(2) := 'SR';                                                                                                                                                                   
                                                                                                                                                                                                        
   G_PRIMARY_SITE_SEQ NUMBER(1) := 1;                                                                                                                                                                   
                                                                                                                                                                                                        
   G_CHECKBOX_CHECKED VARCHAR(2) := 'on';                                                                                                                                                               
                                                                                                                                                                                                        
   G_ASTRIX VARCHAR(1) := '*';                                                                                                                                                                          
                                                                                                                                                                                                        
   G_ADMIN_FUNCTIONAL_ID VARCHAR(18) :='eCRD-Administrator';                                                                                                                                            
                                                                                                                                                                                                        
   G_EMAIL_SEPARATOR VARCHAR(1) := ',';                                                                                                                                                                 
                                                                                                                                                                                                        
   G_DUMMY_SEPERATOR VARCHAR2(2) := '^^';                                                                                                                                                               
                                                                                                                                                                                                        
   G_USER_ACTIVE VARCHAR(1) := 'A';                                                                                                                                                                     
                                                                                                                                                                                                        
   G_USER_INACTIVE VARCHAR(1) := 'I';  
   
   G_COMP_TIMESTAMP VARCHAR(20) := 'DD-MON-YYYY HH:MI:SS';
   
   
   
   G_CAT_IND_GE VARCHAR2(5) := 'GE' ;
   
   G_CAT_IND_ACC VARCHAR2(5) := 'ACC' ;
   
   G_CAT_IND_RPL VARCHAR2(5) := 'RPL' ;
   
   G_CAT_IND_OVH VARCHAR2(5) := 'OVH' ;
   
                                                                                                                                                                                                        
   TYPE gtyp_buf_arr IS TABLE OF LONG INDEX BY BINARY_INTEGER;                                                                                                                                          
                                                                                                                                                                                                        
                                                                                                                                                                                                        
 PROCEDURE ecrd_delimiter_prc(                                                                                                                                                                          
          p_name_str         IN LONG,                                                                                                                                                                   
          p_row_delimit      IN VARCHAR2,                                                                                                                                                               
          p_field_delimit    IN VARCHAR2,                                                                                                                                                               
          p_rec_holder      OUT rec_holder);                                                                                                                                                            
                                                                                                                                                                                                        
                                                                                                                                                                                                        
PROCEDURE break_into_cols_s_prc(                                                                                                                                                                        
               pl_data_string      IN   LONG,                                                                                                                                                           
               p_col_delimiter     IN   VARCHAR2,                                                                                                                                                       
               ptab_broken_data    OUT  gtyp_buf_arr);                                                                                                                                                  
     --                                                                                                                                                                                                 
                                                                                                                                                                                                        
PROCEDURE break_into_rows_s_prc(                                                                                                                                                                        
               pl_data_string      IN   LONG  DEFAULT NULL,                                                                                                                                             
               p_row_delimiter     IN   VARCHAR2,                                                                                                                                                       
               ptab_broken_data    OUT  gtyp_buf_arr);                                                                                                                                                  
                                                                                                                                                                                                        

/* Patni 04-Sep-2006 - Declaring new function to split the delimited string to an array - Begin */
FUNCTION string_to_array (p_instr IN VARCHAR2, p_delimiter IN VARCHAR2) RETURN VARRAY_PART;
/* Patni 04-Sep-2006 - Declaring new function to split the delimited string to an array - End */
                                                                                                                                                                                                        
END ecrd_utils_pkg;                                                                                                                                                                                     
/

CREATE OR REPLACE PACKAGE BODY ecrd_utils_pkg AS                                                                                                                                                                          
                                                                                                                                                                                                        
                                                                                                                                                                                                        
PROCEDURE ecrd_delimiter_prc(                                                                                                                                                                           
          p_name_str         IN LONG,                                                                                                                                                                   
          p_row_delimit      IN VARCHAR2,                                                                                                                                                               
          p_field_delimit    IN VARCHAR2,                                                                                                                                                               
          p_rec_holder      OUT rec_holder)                                                                                                                                                             
IS                                                                                                                                                                                                      
                                                                                                                                                                                                        
 v_rec_pos1                 NUMBER;                                                                                                                                                                     
 v_rec_pos2                 NUMBER;                                                                                                                                                                     
 v_rec_delimiter_length     NUMBER;                                                                                                                                                                     
 v_field_pos1               NUMBER;                                                                                                                                                                     
 v_field_pos2               NUMBER;                                                                                                                                                                     
 v_field_delimiter_length   NUMBER;                                                                                                                                                                     
 loop_counter               NUMBER;                                                                                                                                                                     
 num_cols                   NUMBER;                                                                                                                                                                     
 table_counter              NUMBER;                                                                                                                                                                     
 col_count                  NUMBER;                                                                                                                                                                     
 rec_length                 NUMBER;                                                                                                                                                                     
 v_record                   LONG;                                                                                                                                                                       
 v_field                    VARCHAR2(1000);                                                                                                                                                             
                                                                                                                                                                                                        
BEGIN                                                                                                                                                                                                   
                                                                                                                                                                                                        
  v_rec_pos1     :=0;                                                                                                                                                                                   
  v_rec_pos2     :=0;                                                                                                                                                                                   
  v_field_pos1   :=0;                                                                                                                                                                                   
  v_field_pos2   :=0;                                                                                                                                                                                   
  loop_counter   :=0;                                                                                                                                                                                   
  table_counter  :=0;                                                                                                                                                                                   
                                                                                                                                                                                                        
-- outer loop separates out the rows and the inner loop separates out the columns                                                                                                                       
                                                                                                                                                                                                        
 LOOP --record loop                                                                                                                                                                                     
   v_rec_pos2    := INSTR(p_name_str,p_row_delimit,v_rec_pos1+1,1) ;                                                                                                                                    
   v_record      := SUBSTR(p_name_str,v_rec_pos1+1,v_rec_pos2-v_rec_pos1-1);                                                                                                                            
   EXIT WHEN v_rec_pos2 = 0; --exit record loop                                                                                                                                                         
                                                                                                                                                                                                        
   --to get the no of columns for that particular record                                                                                                                                                
   col_count:=0;                                                                                                                                                                                        
                                                                                                                                                                                                        
   FOR rec_length IN 1..LENGTH(v_record)                                                                                                                                                                
   LOOP                                                                                                                                                                                                 
       v_field_pos2 := INSTR(v_record,p_field_delimit,v_field_pos1+1,1);                                                                                                                                
       IF v_field_pos2 = 0                                                                                                                                                                              
       THEN                                                                                                                                                                                             
          EXIT;                                                                                                                                                                                         
       END IF;                                                                                                                                                                                          
       col_count:=col_count+1;                                                                                                                                                                          
       v_field_pos1 := v_field_pos2 + LENGTH(p_field_delimit) - 1;                                                                                                                                      
   END LOOP;                                                                                                                                                                                            
                                                                                                                                                                                                        
    num_cols := col_count+1;                                                                                                                                                                            
    v_field_pos2:=0;                                                                                                                                                                                    
    v_field_pos1:=0;                                                                                                                                                                                    
                                                                                                                                                                                                        
                                                                                                                                                                                                        
   FOR loop_counter IN 1..num_cols - 1                                                                                                                                                                  
                                                                                                                                                                                                        
       LOOP -- field loop                                                                                                                                                                               
                                                                                                                                                                                                        
           table_counter := table_counter + 1;                                                                                                                                                          
           v_field_pos2 := INSTR(v_record,p_field_delimit,v_field_pos1+1,1) ;                                                                                                                           
           v_field      := LTRIM(RTRIM(SUBSTR(v_record,v_field_pos1+1,v_field_pos2-v_field_pos1-1)));                                                                                                   
           p_rec_holder(table_counter)  :=  v_field;                                                                                                                                                    
           v_field_pos1 := v_field_pos2 + LENGTH(p_field_delimit) - 1;                                                                                                                                  
                                                                                                                                                                                                        
           EXIT WHEN v_field_pos2 =0; -- exit field loop                                                                                                                                                
                                                                                                                                                                                                        
       END LOOP;                                                                                                                                                                                        
                                                                                                                                                                                                        
       v_field      := SUBSTR(v_record,v_field_pos1+1,LENGTH(v_record));                                                                                                                                
       table_counter := table_counter + 1;                                                                                                                                                              
       p_rec_holder(table_counter)  := v_field;                                                                                                                                                         
                                                                                                                                                                                                        
       -- The separated fields for the record are being held by p_rec_holder.                                                                                                                           
       -- This is sent to the Action procedure ,sp_display where the business logic for                                                                                                                 
       -- the separated values is written.                                                                                                                                                              
                                                                                                                                                                                                        
       v_field_pos1 :=0;                                                                                                                                                                                
       v_field_pos2 :=0;                                                                                                                                                                                
                                                                                                                                                                                                        
       v_rec_pos1   :=v_rec_pos2 + LENGTH(p_row_delimit) - 1 ;                                                                                                                                          
                                                                                                                                                                                                        
 END LOOP;-- end record loop                                                                                                                                                                            
                                                                                                                                                                                                        
END ecrd_delimiter_prc;                                                                                                                                                                                 
                                                                                                                                                                                                        
PROCEDURE break_into_cols_s_prc(                                                                                                                                                                        
     pl_data_string      IN   LONG,                                                                                                                                                                     
     p_col_delimiter     IN   VARCHAR2,                                                                                                                                                                 
     ptab_broken_data    OUT  gtyp_buf_arr                                                                                                                                                              
     )                                                                                                                                                                                                  
IS                                                                                                                                                                                                      
--                                                                                                                                                                                                      
ltab_insert_values gtyp_buf_arr;                                                                                                                                                                        
ll_data_string      LONG          := NULL;                                                                                                                                                              
lb_break_value      BOOLEAN       := TRUE;                                                                                                                                                              
ln_cnt              NUMBER        := 0;                                                                                                                                                                 
ln_start_cut        NUMBER        := 0;                                                                                                                                                                 
ln_stop_cut         NUMBER        := 0;                                                                                                                                                                 
l_delimiter         VARCHAR2(5)   := p_col_delimiter;                                                                                                                                                   
l_delim_len         NUMBER        := LENGTH(l_delimiter);                                                                                                                                               
--                                                                                                                                                                                                      
BEGIN                                                                                                                                                                                                   
--                                                                                                                                                                                                      
     ll_data_string := pl_data_string ;                                                                                                                                                                 
     ltab_insert_values.DELETE;                                                                                                                                                                         
     ln_start_cut := 0;                                                                                                                                                                                 
     ln_stop_cut  := 0;                                                                                                                                                                                 
dbms_output.put_line('ll_data_string IN COLS '||ll_data_string);                                                                                                                                        
     IF(ll_data_string IS NOT NULL )                                                                                                                                                                    
     THEN                                                                                                                                                                                               
dbms_output.put_line('ll_data_string- IN COLS -----> '||ll_data_string);                                                                                                                                
	     WHILE (lb_break_value) LOOP    --Break row data into into individual                                                                                                                              
	--                                    --columns                                                                                                                                                        
	          ln_stop_cut := 0;                                                                                                                                                                            
	          IF (ln_start_cut =0) THEN                                                                                                                                                                    
	               ln_stop_cut :=                                                                                                                                                                          
	                    INSTR(ll_data_string,l_delimiter,ln_start_cut+1,1);                                                                                                                                
	          ELSE                                                                                                                                                                                         
	               ln_stop_cut :=                                                                                                                                                                          
	                    INSTR(ll_data_string,l_delimiter,ln_start_cut,1);                                                                                                                                  
	          END IF;                                                                                                                                                                                      
	--                                                                                                                                                                                                     
	          IF(ln_start_cut = ln_stop_cut) THEN                                                                                                                                                          
	               ltab_insert_values(ltab_insert_values.COUNT + 1) := '';                                                                                                                                 
	          ELSE                                                                                                                                                                                         
	               IF (ln_start_cut = 0) THEN                                                                                                                                                              
	                    ltab_insert_values(ltab_insert_values.COUNT + 1) :=                                                                                                                                
	                         SUBSTR(ll_data_string,ln_start_cut,ln_stop_cut-1 );                                                                                                                           
	               ELSE                                                                                                                                                                                    
	                    ltab_insert_values(ltab_insert_values.COUNT + 1) :=                                                                                                                                
	                         SUBSTR(ll_data_string,ln_start_cut,                                                                                                                                           
	                         ln_stop_cut-ln_start_cut );                                                                                                                                                   
	               END IF;                                                                                                                                                                                 
	          END IF;                                                                                                                                                                                      
	--                                                                                                                                                                                                     
	          ln_start_cut := ln_stop_cut + l_delim_len;                                                                                                                                                   
	          IF (ln_stop_cut = LENGTH(ll_data_string))                                                                                                                                                    
	               OR (ln_start_cut > LENGTH(ll_data_string) )THEN                                                                                                                                         
	               lb_break_value := FALSE;                                                                                                                                                                
	          END IF;                                                                                                                                                                                      
	--                                                                                                                                                                                                     
	     END LOOP; --End of breaking row into column values                                                                                                                                                
     END IF;                                                                                                                                                                                            
     ptab_broken_data := ltab_insert_values;                                                                                                                                                            
--                                                                                                                                                                                                      
EXCEPTION                                                                                                                                                                                               
   WHEN OTHERS THEN                                                                                                                                                                                     
      RAISE;                                                                                                                                                                                            
--                                                                                                                                                                                                      
END break_into_cols_s_prc;                                                                                                                                                                              
--                                                                                                                                                                                                      
------------------------ Header -------------------------------------                                                                                                                                   
-- Program       etst_util_pkg.break_into_rows_s_prc                                                                                                                                                    
-- Author        Patni OffShore Team                                                                                                                                                                    
-- Date          Dec 22, 2003                                                                                                                                                                           
-- Description   Definition for the procedure break_into_cols_s_prc                                                                                                                                     
--               his procedure is used to break the delimmitted data tring                                                                                                                              
--               into rows and columns. Then it calls appropriate procedure                                                                                                                             
--               with colums in an array for each row.                                                                                                                                                  
                                                                                                                                                                                                        
-- Calls         None                                                                                                                                                                                   
-- Parameters    Delimited String (Input)                                                                                                                                                               
--               Delimiter (Input)                                                                                                                                                                      
--               The Broken Data (Output)                                                                                                                                                               
--                                                                                                                                                                                                      
--                      Modification                                                                                                                                                                    
-- Date          Author             Description Of Change                                                                                                                                               
----------------------------------------------------------------------------                                                                                                                            
                                                                                                                                                                                                        
PROCEDURE break_into_rows_s_prc(                                                                                                                                                                        
     pl_data_string      IN   LONG  DEFAULT NULL,                                                                                                                                                       
     p_row_delimiter     IN   VARCHAR2,                                                                                                                                                                 
     ptab_broken_data    OUT  gtyp_buf_arr                                                                                                                                                              
     )                                                                                                                                                                                                  
IS                                                                                                                                                                                                      
--                                                                                                                                                                                                      
ltab_insert_lines gtyp_buf_arr;                                                                                                                                                                         
ll_data_string    LONG          := NULL;                                                                                                                                                                
lb_break_line     BOOLEAN       := TRUE;                                                                                                                                                                
lb_break_value    BOOLEAN       := TRUE;                                                                                                                                                                
ln_cnt            NUMBER        := 0;                                                                                                                                                                   
ln_start_cut      NUMBER        := 0;                                                                                                                                                                   
ln_stop_cut       NUMBER        := 0;                                                                                                                                                                   
l_delimiter      VARCHAR2(5)    := p_row_delimiter;                                                                                                                                                     
                                                                                                                                                                                                        
BEGIN                                                                                                                                                                                                   
                                                                                                                                                                                                        
     ll_data_string := pl_data_string ;                                                                                                                                                                 
     ltab_insert_lines.DELETE;                                                                                                                                                                          
--                                                                                                                                                                                                      
dbms_output.put_line('ll_data_string IN ROWS '||ll_data_string);                                                                                                                                        
	  IF (ll_data_string IS NOT NULL )                                                                                                                                                                     
     THEN                                                                                                                                                                                               
dbms_output.put_line('ll_data_string IN ROWS----> ' ||ll_data_string);                                                                                                                                  
	     WHILE (lb_break_line) LOOP --Logic for breaking into rows                                                                                                                                         
	          IF (ln_start_cut =0) THEN                                                                                                                                                                    
	               ln_stop_cut := INSTR(ll_data_string,l_delimiter,1,1);                                                                                                                                   
	          ELSE                                                                                                                                                                                         
	               ln_stop_cut := INSTR(ll_data_string,l_delimiter,ln_start_cut,1);                                                                                                                        
	          END IF;                                                                                                                                                                                      
	--                                                                                                                                                                                                     
	          IF (ln_start_cut = 0) THEN                                                                                                                                                                   
	               ltab_insert_lines(ltab_insert_lines.COUNT + 1) :=                                                                                                                                       
	                    SUBSTR(ll_data_string,ln_start_cut,ln_stop_cut-1);                                                                                                                                 
	          ELSE                                                                                                                                                                                         
	               ltab_insert_lines(ltab_insert_lines.COUNT + 1) :=                                                                                                                                       
	                    SUBSTR(ll_data_string,ln_start_cut,                                                                                                                                                
	                    ln_stop_cut-ln_start_cut);                                                                                                                                                         
	          END IF;                                                                                                                                                                                      
	--VISHAL CHANGED HERE                                                                                                                                                                                  
	          ln_start_cut := ln_stop_cut + length(p_row_delimiter);                                                                                                                                       
	-- VISHAL CHANGED HERE                                                                                                                                                                                 
	          IF (ln_stop_cut > LENGTH(ll_data_string) - length(p_row_delimiter)) THEN                                                                                                                     
	               lb_break_line := FALSE;                                                                                                                                                                 
	          END IF;                                                                                                                                                                                      
	     END LOOP; --End of breaking the string into rows                                                                                                                                                  
     END IF;                                                                                                                                                                                            
     ptab_broken_data := ltab_insert_lines;                                                                                                                                                             
--                                                                                                                                                                                                      
EXCEPTION                                                                                                                                                                                               
   WHEN OTHERS THEN                                                                                                                                                                                     
      RAISE;                                                                                                                                                                                            
                                                                                                                                                                                                        
END break_into_rows_s_prc;                                                                                                                                                                              

/* Patni 04-Sep-2006 - Declaring new function to split the delimited string to an array - Begin */
------------------------ Header -------------------------------------                                                                                                                                   
-- Program       ecrd_util_pkg.string_to_array 
-- Author        Patni OffShore Team
-- Date          Sep 04, 2006
-- Description   To split the delimited string to an array
-- Calls         None
-- Parameters    Delimited String (Input)
--               Delimiter (Input)
--               Array     (Output)
--
-- Modification
-- Date          Author             Description Of Change
----------------------------------------------------------------------------                                                                                                                            
FUNCTION string_to_array (p_instr IN VARCHAR2, p_delimiter IN VARCHAR2) RETURN VARRAY_PART 
IS v_store   VARRAY_PART;

   v_insert  VARCHAR2(4000);
   v_pos     NUMBER;
   v_counter NUMBER;
   v_len     NUMBER;

BEGIN
     v_store   := VARRAY_PART('');
     v_insert  := p_instr;
     v_pos     := INSTR(v_insert, p_delimiter, 1, 1);
     v_counter := 1;
     v_len     := LENGTH(p_delimiter);
 
     WHILE(v_pos <> 0) 
     LOOP
         v_store(v_counter) := SUBSTR(v_insert, 1, v_pos-1);
         v_insert  := SUBSTR(v_insert, v_pos + v_len);
         v_pos     := INSTR(v_insert, p_delimiter, 1, 1);
         v_counter := v_counter + 1;
         v_store.EXTEND(1);
     END LOOP;
     
     RETURN v_store;

EXCEPTION
WHEN OTHERS THEN
     RAISE;
END  string_to_array;
/* Patni 04-Sep-2006 - Declaring new function to split the delimited string to an array - End */
                                                                                                                                                                                                        
END ecrd_utils_pkg; 
/
